-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game.Players.LocalPlayer
local v2 = script.Parent
local v_u_3 = v2:WaitForChild("Slider")
local v_u_4 = v2:WaitForChild("SuccessZone")
local v_u_5 = script.Parent:WaitForChild("RemoteEvent")
local v6 = game:GetService("UserInputService")
local v7 = game:GetService("TweenService")
local v_u_8 = true
local v_u_9 = v_u_1.Character:WaitForChild("Humanoid"):LoadAnimation(script:WaitForChild("Lockpicking"))
v_u_9:Play()
v_u_1.Character.HumanoidRootPart.Anchored = true
v_u_3.Position = UDim2.new(0, 0, 0, 0)
workspace.CurrentCamera.CameraType = Enum.CameraType.Scriptable
v7:Create(workspace.CurrentCamera, TweenInfo.new(1.2, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
	["CFrame"] = script.Parent.Door.Value.Cam.CFrame
}):Play()
local v_u_10 = v_u_3.Size.X.Scale
local v11 = 1 - v_u_10
local v_u_12 = v7:Create(v_u_3, TweenInfo.new(0.7, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true), {
	["Position"] = UDim2.new(v11, 0, 0, 0)
})
v_u_12:Play()
v6.InputBegan:Connect(function(p13, p14)
	-- upvalues: (ref) v_u_8, (copy) v_u_12, (copy) v_u_3, (copy) v_u_10, (copy) v_u_4, (copy) v_u_5, (copy) v_u_9, (copy) v_u_1
	if not p14 and v_u_8 then
		if p13.UserInputType == Enum.UserInputType.MouseButton1 then
			v_u_12:Cancel()
			local v15 = v_u_3.Position.X.Scale + v_u_10 / 2
			local v16 = v_u_4.Position.X.Scale
			local v17 = v16 + v_u_4.Size.X.Scale
			if v16 <= v15 and v15 <= v17 then
				print("Success!")
				v_u_5:FireServer("Success")
				v_u_9:Stop()
				v_u_1.Character.HumanoidRootPart.Anchored = false
				workspace.CurrentCamera.CameraType = Enum.CameraType.Custom
			else
				print("Failed!")
				v_u_5:FireServer("Failure")
				v_u_9:Stop()
				v_u_1.Character.HumanoidRootPart.Anchored = false
				workspace.CurrentCamera.CameraType = Enum.CameraType.Custom
			end
			v_u_8 = false
		end
	end
end)