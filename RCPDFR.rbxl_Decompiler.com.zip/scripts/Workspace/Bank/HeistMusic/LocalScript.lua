-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

script.Parent.Sound:Play()
script.Parent.TextButton.MouseButton1Click:Connect(function()
	script.Parent.Sound:Destroy()
	script.Parent:Destroy()
end)
task.wait(250)
script.Parent:Destroy()