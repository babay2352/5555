-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = script.Parent.TextLabel
local v2 = game:GetService("TweenService")
v2:Create(v1, TweenInfo.new(1, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
	["TextTransparency"] = 0
}):Play()
task.wait(2.5)
v2:Create(v1, TweenInfo.new(1, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
	["TextTransparency"] = 0.5
}):Play()