-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local _ = workspace.FilteringEnabled
local v_u_1 = script.Parent.Car.Value
require(v_u_1["A-Chassis Tune"])
local _ = v_u_1.Body
local v_u_2 = v_u_1.SmeersLightsHandler
game:GetService("UserInputService").InputBegan:connect(function(p3, p4)
	-- upvalues: (copy) v_u_2
	if not p4 then
		if p3.KeyCode == Enum.KeyCode.Z or p3.KeyCode == Enum.KeyCode.DPadLeft then
			v_u_2:FireServer({
				["ToggleLeftBlink"] = true
			})
			return
		end
		if p3.KeyCode == Enum.KeyCode.C or p3.KeyCode == Enum.KeyCode.DPadRight then
			v_u_2:FireServer({
				["ToggleRightBlink"] = true
			})
			return
		end
		if p3.KeyCode == Enum.KeyCode.L then
			v_u_2:FireServer({
				["ToggleStandlicht"] = true
			})
			return
		end
		if p3.KeyCode == Enum.KeyCode.X then
			v_u_2:FireServer({
				["ToggleHazards"] = true
			})
		end
	end
end)
local v_u_5 = 0
v_u_1.DriveSeat.Changed:Connect(function(p6)
	-- upvalues: (copy) v_u_1, (copy) v_u_2, (ref) v_u_5
	if p6 == "Throttle" then
		if v_u_1.DriveSeat.Throttle ~= -1 then
			v_u_2:FireServer({
				["DisableBrakes"] = true
			})
			goto l2
		end
		v_u_2:FireServer({
			["EnableBrakes"] = true
		})
		local v7 = 0.5681818181818181 * v_u_1.DriveSeat.Velocity.Magnitude
		if math.floor(v7) >= 40 then
			while true do
				local v8 = 0.5681818181818181 * v_u_1.DriveSeat.Velocity.Magnitude
				if math.floor(v8) < 40 then
					v_u_5 = 0
					break
				end
				if v_u_1.DriveSeat.Throttle ~= -1 then
					v_u_5 = 0
					break
				end
				v_u_5 = v_u_5 + 0.05
				wait(0.05)
				if v_u_5 >= 0.2 then
					break
				end
			end
			if v_u_5 < 0.2 then
				v_u_5 = 0
				return
			end
			v_u_5 = 0
			local v9 = 0.5681818181818181 * v_u_1.DriveSeat.Velocity.Magnitude
			if math.floor(v9) >= 40 then
				while true do
					local v10 = 0.5681818181818181 * v_u_1.DriveSeat.Velocity.Magnitude
					if math.floor(v10) >= 40 or v_u_1.DriveSeat.Throttle == -1 then
						v_u_2:FireServer({
							["EnableBrakes"] = true
						})
						wait(0.1)
					end
					local v11 = 0.5681818181818181 * v_u_1.DriveSeat.Velocity.Magnitude
					if math.floor(v11) <= 3 or v_u_1.DriveSeat.Throttle ~= -1 then
						local v12 = 0.5681818181818181 * v_u_1.DriveSeat.Velocity.Magnitude
						if math.floor(v12) <= 3 then
							v_u_2:FireServer({
								["ToggleHazards"] = true
							})
							v_u_2:FireServer({
								["EnableBrakes"] = true
							})
							return
						end
						goto l2
					end
				end
			end
		end
	end
	::l2::
end)
script.Parent.Values.Gear.Changed:connect(function()
	-- upvalues: (copy) v_u_2
	if script.Parent.Values.Gear.Value == -1 then
		v_u_2:FireServer({
			["ReverseOn"] = true
		})
	elseif script.Parent.Values.Gear.Value ~= -1 then
		v_u_2:FireServer({
			["ReverseOff"] = true
		})
	end
end)