-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game.Players.LocalPlayer
local v_u_2 = v_u_1:GetMouse()
local v_u_3 = game:GetService("TweenService")
local v4 = game:GetService("UserInputService")
local v_u_5 = script.Parent.Radar
local v_u_6 = script.Parent.Remote
local v_u_7 = v_u_6.Background2
local v_u_8 = Enum.KeyCode.B
local v_u_9 = false
local v_u_10 = false
local v_u_11 = false
local v_u_12 = false
local v_u_13 = false
local v_u_14 = false
local v_u_15 = false
local v_u_16 = false
local v_u_17 = 1
local v_u_18 = 1
local v_u_19 = {
	15,
	20,
	25,
	30,
	35,
	40,
	45,
	50,
	55,
	60,
	65,
	70,
	75,
	80,
	85,
	90
}
local v_u_20 = {}
local v_u_21 = {}
local function v_u_30(p22, p_u_23, _)
	-- upvalues: (ref) v_u_15, (copy) v_u_5, (ref) v_u_16
	if p22 == "Front" and not v_u_15 then
		v_u_15 = true
		script.F:Play()
		task.wait(0.5)
		script.Speeder:Play()
		task.wait(0.5)
		v_u_5.Front.FAST.TextColor3 = v_u_5.Front.FAST.IlluminatedColor.Value
		v_u_5.Front.LOCK.TextColor3 = v_u_5.Front.LOCK.IlluminatedColor.Value
		local v_u_24 = true
		task.delay(10, function()
			-- upvalues: (ref) v_u_24, (ref) v_u_5
			v_u_24 = false
			v_u_5.Front.SpeedFront2.Text = "000"
		end)
		task.spawn(function()
			-- upvalues: (ref) v_u_24, (copy) p_u_23, (ref) v_u_5
			while v_u_24 and p_u_23 do
				local v25 = p_u_23.Velocity.Magnitude / 1.799
				local v26 = math.floor(v25)
				v_u_5.Front.SpeedFront2.Text = v26
				task.wait(0.1)
			end
		end)
		script.Away:Play()
		task.spawn(function()
			-- upvalues: (ref) v_u_15, (ref) v_u_5
			task.wait(10)
			v_u_15 = false
			v_u_5.Front.FAST.TextColor3 = v_u_5.Front.FAST.OriginalColor.Value
			v_u_5.Front.LOCK.TextColor3 = v_u_5.Front.LOCK.OriginalColor.Value
		end)
	elseif p22 == "Rear" and not v_u_16 then
		v_u_16 = true
		script.R:Play()
		task.wait(0.5)
		script.Speeder:Play()
		task.wait(0.5)
		v_u_5.Rear.FAST.TextColor3 = v_u_5.Rear.FAST.IlluminatedColor.Value
		v_u_5.Rear.LOCK.TextColor3 = v_u_5.Rear.LOCK.IlluminatedColor.Value
		local v_u_27 = true
		task.delay(10, function()
			-- upvalues: (ref) v_u_27, (ref) v_u_5
			v_u_27 = false
			v_u_5.Rear.SpeedRear2.Text = "000"
		end)
		task.spawn(function()
			-- upvalues: (ref) v_u_27, (copy) p_u_23, (ref) v_u_5
			while v_u_27 and p_u_23 do
				local v28 = p_u_23.Velocity.Magnitude / 1.799
				local v29 = math.floor(v28)
				v_u_5.Rear.SpeedRear2.Text = v29
				task.wait(0.1)
			end
		end)
		script.Away:Play()
		task.spawn(function()
			-- upvalues: (ref) v_u_16, (ref) v_u_5
			task.wait(10)
			v_u_16 = false
			v_u_5.Rear.FAST.TextColor3 = v_u_5.Rear.FAST.OriginalColor.Value
			v_u_5.Rear.LOCK.TextColor3 = v_u_5.Rear.LOCK.OriginalColor.Value
		end)
	end
end
v4.InputBegan:Connect(function(p31, p32)
	-- upvalues: (copy) v_u_8, (ref) v_u_10, (copy) v_u_3, (copy) v_u_6
	if p31.KeyCode == v_u_8 and not p32 then
		if not v_u_10 then
			v_u_3:Create(v_u_6, TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
				["Position"] = UDim2.new(0.711, 0, 0.635, 0)
			}):Play()
			v_u_10 = true
			return
		end
		v_u_3:Create(v_u_6, TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
			["Position"] = UDim2.new(0.711, 0, 1.3, 0)
		}):Play()
		v_u_10 = false
	end
end)
v_u_6.ToggleDisplay.MouseButton1Click:Connect(function()
	-- upvalues: (ref) v_u_11, (copy) v_u_3, (copy) v_u_5
	if v_u_11 then
		v_u_3:Create(v_u_5, TweenInfo.new(0.9, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
			["Position"] = UDim2.new(0.5, 0, -1, 0)
		}):Play()
		v_u_11 = false
	else
		v_u_3:Create(v_u_5, TweenInfo.new(0.9, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
			["Position"] = UDim2.new(0.5, 0, 0.103, 0)
		}):Play()
		v_u_11 = true
	end
end)
v_u_6.PlateReader.MouseButton1Click:Connect(function()
	-- upvalues: (ref) v_u_12, (copy) v_u_3, (copy) v_u_5
	if v_u_12 then
		v_u_3:Create(v_u_5.PlateReader, TweenInfo.new(0.9, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
			["Position"] = UDim2.new(0.5, 0, 0.48, 0)
		}):Play()
		v_u_12 = false
	else
		v_u_3:Create(v_u_5.PlateReader, TweenInfo.new(0.9, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
			["Position"] = UDim2.new(1.278, 0, 0.48, 0)
		}):Play()
		v_u_12 = true
	end
end)
v_u_6.Volume.MouseButton1Click:Connect(function()
	-- upvalues: (ref) v_u_9, (copy) v_u_3, (copy) v_u_7
	if v_u_9 then
		v_u_3:Create(v_u_7, TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
			["Position"] = UDim2.new(0.497, 0, 0.5, 0)
		}):Play()
		v_u_9 = false
	else
		v_u_3:Create(v_u_7, TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
			["Position"] = UDim2.new(0.497, 0, 1.17, 0)
		}):Play()
		v_u_9 = true
	end
end)
v_u_7.High.MouseButton1Click:Connect(function()
	-- upvalues: (copy) v_u_3, (copy) v_u_7
	v_u_3:Create(v_u_7.Slider, TweenInfo.new(0.4, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
		["Position"] = UDim2.new(0.25, 0, 0.492, 0)
	}):Play()
	for _, v33 in pairs(script:GetChildren()) do
		if v33:IsA("Sound") and (v33.Name ~= "Click" and v33.Name ~= "Power") then
			v33.Volume = 5
		end
	end
end)
v_u_7.Medium.MouseButton1Click:Connect(function()
	-- upvalues: (copy) v_u_3, (copy) v_u_7
	v_u_3:Create(v_u_7.Slider, TweenInfo.new(0.4, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
		["Position"] = UDim2.new(0.45, 0, 0.492, 0)
	}):Play()
	for _, v34 in pairs(script:GetChildren()) do
		if v34:IsA("Sound") and (v34.Name ~= "Click" and v34.Name ~= "Power") then
			v34.Volume = 2.4
		end
	end
end)
v_u_7.Low.MouseButton1Click:Connect(function()
	-- upvalues: (copy) v_u_3, (copy) v_u_7
	v_u_3:Create(v_u_7.Slider, TweenInfo.new(0.4, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
		["Position"] = UDim2.new(0.585, 0, 0.492, 0)
	}):Play()
	for _, v35 in pairs(script:GetChildren()) do
		if v35:IsA("Sound") and (v35.Name ~= "Click" and v35.Name ~= "Power") then
			v35.Volume = 0.7
		end
	end
end)
v_u_7.Muted.MouseButton1Click:Connect(function()
	-- upvalues: (copy) v_u_3, (copy) v_u_7
	v_u_3:Create(v_u_7.Slider, TweenInfo.new(0.4, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
		["Position"] = UDim2.new(0.756, 0, 0.492, 0)
	}):Play()
	for _, v36 in pairs(script:GetChildren()) do
		if v36:IsA("Sound") and (v36.Name ~= "Click" and v36.Name ~= "Power") then
			v36.Volume = 0
		end
	end
end)
local v_u_37 = nil
v_u_6.Manual.MouseButton1Click:Connect(function()
	-- upvalues: (ref) v_u_14, (ref) v_u_13, (copy) v_u_5, (copy) v_u_6, (copy) v_u_1, (ref) v_u_37, (copy) v_u_21, (copy) v_u_19, (ref) v_u_17, (ref) v_u_15, (copy) v_u_30, (ref) v_u_18, (ref) v_u_16, (copy) v_u_20
	if v_u_14 == false and v_u_13 == true then
		v_u_5.Front.SpeedFront2.Text = "MAN"
		v_u_5.Front.SpeedFront2.Emissive.Visible = true
		v_u_5.Front.SpeedFront.TextColor3 = v_u_5.Rear.SpeedRear.OriginalColor.Value
		v_u_5.Front.SpeedFront.Emissive.Visible = false
		v_u_5.Rear.SpeedRear2.TextColor3 = v_u_5.Front.SpeedFront2.IlluminatedColor.Value
		v_u_5.Rear.SpeedRear.TextColor3 = v_u_5.Rear.SpeedRear.OriginalColor.Value
		v_u_5.Rear.SpeedRear.Emissive.Visible = false
		v_u_5.Rear.SpeedRear2.Text = "MAN"
		v_u_5.Front.XMIT.TextColor3 = v_u_5.Front.XMIT.OriginalColor.Value
		v_u_5.Front.SAME.TextColor3 = v_u_5.Front.SAME.OriginalColor.Value
		v_u_5.Rear.XMIT.TextColor3 = v_u_5.Rear.XMIT.OriginalColor.Value
		v_u_5.Rear.SAME.TextColor3 = v_u_5.Rear.SAME.OriginalColor.Value
		v_u_6.Manual.TextLabel.Text = "AUTO"
		script.Xmit:Play()
		v_u_14 = true
		local v_u_38 = v_u_1.Character.HumanoidRootPart.CFrame
		if v_u_37 then
			v_u_37:Disconnect()
			v_u_37 = nil
		end
		v_u_37 = game:GetService("RunService").RenderStepped:Connect(function()
			-- upvalues: (ref) v_u_1, (copy) v_u_38, (ref) v_u_6, (ref) v_u_5, (ref) v_u_13, (ref) v_u_14, (ref) v_u_21, (ref) v_u_19, (ref) v_u_17, (ref) v_u_15, (ref) v_u_30, (ref) v_u_18, (ref) v_u_16, (ref) v_u_20, (ref) v_u_37
			if v_u_1.Character and v_u_1.Character:FindFirstChild("HumanoidRootPart") then
				if (v_u_1.Character:FindFirstChild("HumanoidRootPart").Position - v_u_38.Position).Magnitude > 10 then
					v_u_6.Manual.TextLabel.Text = "MANUAL"
					v_u_5.Front.SpeedFront2.Text = "ATO"
					v_u_5.Front.SpeedFront2.Emissive.Visible = true
					v_u_5.Front.SpeedFront.TextColor3 = v_u_5.Rear.SpeedRear.IlluminatedColor.Value
					v_u_5.Front.SpeedFront.Emissive.Visible = true
					v_u_5.Rear.SpeedRear2.TextColor3 = v_u_5.Front.SpeedFront2.IlluminatedColor.Value
					v_u_5.Rear.SpeedRear.TextColor3 = v_u_5.Rear.SpeedRear.IlluminatedColor.Value
					v_u_5.Rear.SpeedRear.Emissive.Visible = true
					v_u_5.Rear.SpeedRear2.Text = "ATO"
					v_u_5.Front.XMIT.TextColor3 = v_u_5.Front.XMIT.IlluminatedColor.Value
					v_u_5.Front.SAME.TextColor3 = v_u_5.Front.SAME.IlluminatedColor.Value
					v_u_5.Rear.XMIT.TextColor3 = v_u_5.Rear.XMIT.IlluminatedColor.Value
					v_u_5.Rear.SAME.TextColor3 = v_u_5.Rear.SAME.IlluminatedColor.Value
					local v_u_39 = v_u_38
					local v_u_40 = 175
					task.spawn(function()
						-- upvalues: (ref) v_u_13, (ref) v_u_14, (copy) v_u_39, (copy) v_u_40, (ref) v_u_5, (ref) v_u_21, (ref) v_u_19, (ref) v_u_17, (ref) v_u_15, (ref) v_u_30, (ref) v_u_18, (ref) v_u_16, (ref) v_u_20
						while v_u_13 and not v_u_14 do
							for _, v_u_41 in ipairs(game.Players:GetPlayers()) do
								if v_u_41 ~= game.Players.LocalPlayer then
									local v42 = v_u_41.Character
									local v_u_43 = v42:FindFirstChild("Head")
									if v_u_43 and (v42:FindFirstChild("HumanoidRootPart") and (v_u_43.Position - v_u_39.Position).Magnitude <= v_u_40) then
										local v44 = v_u_39.CFrame.LookVector:Dot((v_u_43.Position - v_u_39.Position).Unit)
										local v45 = math.acos(v44)
										local v46 = math.deg(v45)
										local v_u_47 = nil
										local v_u_48 = nil
										if v46 < 90 then
											v_u_48 = v_u_5.Front.SpeedFront
											v_u_47 = "Front"
										elseif v46 > 90 and v46 < 180 then
											v_u_48 = v_u_5.Rear.SpeedRear
											v_u_47 = "Rear"
										end
										if v_u_47 and not v_u_21[v_u_41.UserId .. "_" .. v_u_47] then
											local v_u_49 = nil
											local v_u_50 = false
											v_u_49 = game:GetService("RunService").Heartbeat:Connect(function()
												-- upvalues: (copy) v_u_43, (ref) v_u_49, (copy) v_u_48, (ref) v_u_19, (ref) v_u_17, (ref) v_u_15, (copy) v_u_50, (ref) v_u_30, (ref) v_u_18, (ref) v_u_16
												if v_u_43 and (v_u_43.Parent and v_u_43:IsDescendantOf(workspace)) then
													v_u_43.Parent:FindFirstChild("HumanoidRootPart")
													local v51 = v_u_43.Velocity.Magnitude / 1.799
													local v52 = math.floor(v51)
													if v_u_43.Parent.Humanoid.Sit == true then
														v_u_48.Text = v52
														local v53 = v_u_48 and (v_u_48.Parent and v_u_48.Parent.Name) or "Front"
														if v53 == "Front" and (v_u_19[v_u_17] < v52 and not (v_u_15 or v_u_50)) then
															v_u_30(v53, v_u_43, v52)
															return
														end
														if v53 == "Rear" and (v_u_19[v_u_18] < v52 and not (v_u_16 or v_u_50)) then
															v_u_30(v53, v_u_43, v52)
															return
														end
													else
														v_u_48.Text = "000"
													end
												else
													if v_u_49 then
														v_u_49:Disconnect()
														v_u_49 = nil
													end
													if v_u_48 then
														v_u_48.Text = "000"
													end
												end
											end)
											local v_u_54 = v_u_49
											v_u_20[v_u_41.UserId .. "_" .. v_u_47] = v_u_54
											v_u_21[v_u_41.UserId .. "_" .. v_u_47] = true
											if v_u_41:FindFirstChild("CarInfo") then
												if v_u_47 == "Front" then
													v_u_5.PlateReader.FRONTPLATE.Text = v_u_41.CarInfo.PlateNumber.Value
													v_u_5.PlateReader.CarMAKE.Text = v_u_41.CarInfo.CarMake.Value
												elseif v_u_47 == "Rear" then
													v_u_5.PlateReader.REARPLATE.Text = v_u_41.CarInfo.PlateNumber.Value
													v_u_5.PlateReader.CarMAKE.Text = v_u_41.CarInfo.CarMake.Value
												end
											end
											task.delay(2, function()
												-- upvalues: (copy) v_u_54, (ref) v_u_48, (ref) v_u_20, (copy) v_u_41, (ref) v_u_47, (ref) v_u_21
												if v_u_54 and v_u_54.Connected then
													v_u_54:Disconnect()
												end
												v_u_48.Text = "000"
												v_u_20[v_u_41.UserId .. "_" .. v_u_47] = nil
												v_u_21[v_u_41.UserId .. "_" .. v_u_47] = nil
											end)
										end
									end
								end
							end
							task.wait(0.1)
						end
					end)
					script.Xmit:Play()
					v_u_14 = false
					if v_u_37 then
						v_u_37:Disconnect()
						v_u_37 = nil
					end
				end
			end
		end)
	elseif v_u_14 == true and v_u_13 == true then
		v_u_6.Manual.TextLabel.Text = "MANUAL"
		v_u_5.Front.SpeedFront2.Text = "ATO"
		v_u_5.Front.SpeedFront2.Emissive.Visible = true
		v_u_5.Front.SpeedFront.TextColor3 = v_u_5.Rear.SpeedRear.IlluminatedColor.Value
		v_u_5.Front.SpeedFront.Emissive.Visible = true
		v_u_5.Rear.SpeedRear2.TextColor3 = v_u_5.Front.SpeedFront2.IlluminatedColor.Value
		v_u_5.Rear.SpeedRear.TextColor3 = v_u_5.Rear.SpeedRear.IlluminatedColor.Value
		v_u_5.Rear.SpeedRear.Emissive.Visible = true
		v_u_5.Rear.SpeedRear2.Text = "ATO"
		v_u_5.Front.XMIT.TextColor3 = v_u_5.Front.XMIT.IlluminatedColor.Value
		v_u_5.Front.SAME.TextColor3 = v_u_5.Front.SAME.IlluminatedColor.Value
		v_u_5.Rear.XMIT.TextColor3 = v_u_5.Rear.XMIT.IlluminatedColor.Value
		v_u_5.Rear.SAME.TextColor3 = v_u_5.Rear.SAME.IlluminatedColor.Value
		local v_u_55 = v_u_1.Character.HumanoidRootPart
		local v_u_56 = 175
		task.spawn(function()
			-- upvalues: (ref) v_u_13, (ref) v_u_14, (copy) v_u_55, (copy) v_u_56, (ref) v_u_5, (ref) v_u_21, (ref) v_u_19, (ref) v_u_17, (ref) v_u_15, (ref) v_u_30, (ref) v_u_18, (ref) v_u_16, (ref) v_u_20
			while v_u_13 and not v_u_14 do
				for _, v_u_57 in ipairs(game.Players:GetPlayers()) do
					if v_u_57 ~= game.Players.LocalPlayer then
						local v58 = v_u_57.Character
						local v_u_59 = v58:FindFirstChild("Head")
						if v_u_59 and (v58:FindFirstChild("HumanoidRootPart") and (v_u_59.Position - v_u_55.Position).Magnitude <= v_u_56) then
							local v60 = v_u_55.CFrame.LookVector:Dot((v_u_59.Position - v_u_55.Position).Unit)
							local v61 = math.acos(v60)
							local v62 = math.deg(v61)
							local v_u_63 = nil
							local v_u_64 = nil
							if v62 < 90 then
								v_u_64 = v_u_5.Front.SpeedFront
								v_u_63 = "Front"
							elseif v62 > 90 and v62 < 180 then
								v_u_64 = v_u_5.Rear.SpeedRear
								v_u_63 = "Rear"
							end
							if v_u_63 and not v_u_21[v_u_57.UserId .. "_" .. v_u_63] then
								local v_u_65 = nil
								local v_u_66 = false
								v_u_65 = game:GetService("RunService").Heartbeat:Connect(function()
									-- upvalues: (copy) v_u_59, (ref) v_u_65, (copy) v_u_64, (ref) v_u_19, (ref) v_u_17, (ref) v_u_15, (copy) v_u_66, (ref) v_u_30, (ref) v_u_18, (ref) v_u_16
									if v_u_59 and (v_u_59.Parent and v_u_59:IsDescendantOf(workspace)) then
										v_u_59.Parent:FindFirstChild("HumanoidRootPart")
										local v67 = v_u_59.Velocity.Magnitude / 1.799
										local v68 = math.floor(v67)
										if v_u_59.Parent.Humanoid.Sit == true then
											v_u_64.Text = v68
											local v69 = v_u_64 and (v_u_64.Parent and v_u_64.Parent.Name) or "Front"
											if v69 == "Front" and (v_u_19[v_u_17] < v68 and not (v_u_15 or v_u_66)) then
												v_u_30(v69, v_u_59, v68)
												return
											end
											if v69 == "Rear" and (v_u_19[v_u_18] < v68 and not (v_u_16 or v_u_66)) then
												v_u_30(v69, v_u_59, v68)
												return
											end
										else
											v_u_64.Text = "000"
										end
									else
										if v_u_65 then
											v_u_65:Disconnect()
											v_u_65 = nil
										end
										if v_u_64 then
											v_u_64.Text = "000"
										end
									end
								end)
								local v_u_70 = v_u_65
								v_u_20[v_u_57.UserId .. "_" .. v_u_63] = v_u_70
								v_u_21[v_u_57.UserId .. "_" .. v_u_63] = true
								if v_u_57:FindFirstChild("CarInfo") then
									if v_u_63 == "Front" then
										v_u_5.PlateReader.FRONTPLATE.Text = v_u_57.CarInfo.PlateNumber.Value
										v_u_5.PlateReader.CarMAKE.Text = v_u_57.CarInfo.CarMake.Value
									elseif v_u_63 == "Rear" then
										v_u_5.PlateReader.REARPLATE.Text = v_u_57.CarInfo.PlateNumber.Value
										v_u_5.PlateReader.CarMAKE.Text = v_u_57.CarInfo.CarMake.Value
									end
								end
								task.delay(2, function()
									-- upvalues: (copy) v_u_70, (ref) v_u_64, (ref) v_u_20, (copy) v_u_57, (ref) v_u_63, (ref) v_u_21
									if v_u_70 and v_u_70.Connected then
										v_u_70:Disconnect()
									end
									v_u_64.Text = "000"
									v_u_20[v_u_57.UserId .. "_" .. v_u_63] = nil
									v_u_21[v_u_57.UserId .. "_" .. v_u_63] = nil
								end)
							end
						end
					end
				end
				task.wait(0.1)
			end
		end)
		script.Xmit:Play()
		v_u_14 = false
		if v_u_37 then
			v_u_37:Disconnect()
			v_u_37 = nil
		end
	end
end)
v_u_5.Power.MouseButton1Click:Connect(function()
	-- upvalues: (ref) v_u_13, (copy) v_u_5, (copy) v_u_1, (copy) v_u_19, (ref) v_u_17, (ref) v_u_15, (copy) v_u_30, (ref) v_u_18, (ref) v_u_16, (ref) v_u_14, (copy) v_u_21, (copy) v_u_20, (ref) v_u_37
	if v_u_13 then
		v_u_13 = false
		script.Power:Play()
		v_u_5.Indicator.Image = "rbxassetid://70388984366997"
		for _, v71 in ipairs(v_u_5.Front:GetChildren()) do
			if v71:IsA("TextLabel") and v71:FindFirstChild("OriginalColor") then
				v71.TextColor3 = v71.OriginalColor.Value
			end
		end
		for _, v72 in pairs(v_u_5.Rear:GetChildren()) do
			if v72:IsA("TextLabel") and v72:FindFirstChild("OriginalColor") then
				v72.TextColor3 = v72.OriginalColor.Value
			end
		end
		v_u_5.Front.SpeedFront.Text = "000"
		v_u_5.Front.SpeedFront2.Text = "000"
		v_u_5.Rear.SpeedRear.Text = "000"
		v_u_5.Rear.SpeedRear2.Text = "000"
		v_u_5.Front.SpeedPatrol.Text = "000"
		v_u_5.Front.SpeedPatrol.Emissive.Visible = false
		v_u_5.Front.SpeedFront.Emissive.Visible = false
		v_u_5.Front.SpeedFront2.Emissive.Visible = false
		v_u_5.Rear.SpeedRear.Emissive.Visible = false
		v_u_5.Rear.SpeedRear2.Emissive.Visible = false
		v_u_5.Front.XMIT.TextColor3 = v_u_5.Front.XMIT.OriginalColor.Value
		v_u_5.Front.SAME.TextColor3 = v_u_5.Front.SAME.OriginalColor.Value
		v_u_5.Rear.XMIT.TextColor3 = v_u_5.Rear.XMIT.OriginalColor.Value
		v_u_5.Rear.SAME.TextColor3 = v_u_5.Rear.SAME.OriginalColor.Value
		for v73, v74 in pairs(v_u_20) do
			if v74 and v74.Connected then
				v74:Disconnect()
			end
			v_u_20[v73] = nil
		end
		if game.Workspace:FindFirstChild("XmitZoneFront") then
			game.Workspace.XmitZoneFront:Destroy()
		end
		if game.Workspace:FindFirstChild("XmitZoneRear") then
			game.Workspace.XmitZoneRear:Destroy()
		end
		v_u_14 = false
		v_u_15 = false
		v_u_16 = false
		if v_u_37 then
			v_u_37:Disconnect()
			v_u_37 = nil
		end
	else
		v_u_13 = true
		script.Power:Play()
		v_u_5.Indicator.Image = "rbxassetid://95666216667827"
		for _, v75 in ipairs(v_u_5.Front:GetChildren()) do
			if v75:IsA("TextLabel") and v75:FindFirstChild("IlluminatedColor") then
				v75.TextColor3 = v75.IlluminatedColor.Value
			end
		end
		for _, v76 in pairs(v_u_5.Rear:GetChildren()) do
			if v76:IsA("TextLabel") and v76:FindFirstChild("IlluminatedColor") then
				v76.TextColor3 = v76.IlluminatedColor.Value
			end
		end
		v_u_5.Front.SpeedFront2.Emissive.Visible = true
		v_u_5.Rear.SpeedRear2.Emissive.Visible = true
		v_u_5.Front.SpeedFront.Emissive.Visible = true
		v_u_5.Rear.SpeedRear.Emissive.Visible = true
		task.wait(2)
		v_u_5.Front.SpeedFront2.Emissive.Visible = false
		v_u_5.Rear.SpeedRear2.Emissive.Visible = false
		v_u_5.Front.SpeedFront.Emissive.Visible = false
		v_u_5.Rear.SpeedRear.Emissive.Visible = false
		for _, v77 in ipairs(v_u_5.Front:GetChildren()) do
			if v77:IsA("TextLabel") and v77:FindFirstChild("IlluminatedColor") then
				v77.TextColor3 = v77.OriginalColor.Value
			end
		end
		for _, v78 in pairs(v_u_5.Rear:GetChildren()) do
			if v78:IsA("TextLabel") and v78:FindFirstChild("IlluminatedColor") then
				v78.TextColor3 = v78.OriginalColor.Value
			end
		end
		v_u_5.Front.SpeedPatrol.TextColor3 = v_u_5.Front.SpeedPatrol.IlluminatedColor.Value
		v_u_5.Front.SpeedPatrol.Emissive.Visible = true
		v_u_5.Front.SpeedFront2.TextColor3 = v_u_5.Front.SpeedFront2.IlluminatedColor.Value
		v_u_5.Front.SpeedFront2.Text = "ATO"
		v_u_5.Front.SpeedFront2.Emissive.Visible = true
		v_u_5.Rear.SpeedRear2.TextColor3 = v_u_5.Front.SpeedFront2.IlluminatedColor.Value
		v_u_5.Rear.SpeedRear2.Text = "ATO"
		v_u_5.Rear.SpeedRear2.Emissive.Visible = true
		task.wait(1)
		script.Xmit:Play()
		v_u_5.Front.XMIT.TextColor3 = v_u_5.Front.XMIT.IlluminatedColor.Value
		v_u_5.Front.SAME.TextColor3 = v_u_5.Front.SAME.IlluminatedColor.Value
		v_u_5.Front.SpeedFront.TextColor3 = v_u_5.Front.SpeedFront.IlluminatedColor.Value
		v_u_5.Front.SpeedFront.Text = "000"
		v_u_5.Front.SpeedFront2.Text = "000"
		v_u_5.Front.SpeedFront.Emissive.Visible = true
		v_u_5.Rear.XMIT.TextColor3 = v_u_5.Front.XMIT.IlluminatedColor.Value
		v_u_5.Rear.SAME.TextColor3 = v_u_5.Front.SAME.IlluminatedColor.Value
		v_u_5.Rear.SpeedRear.TextColor3 = v_u_5.Rear.SpeedRear.IlluminatedColor.Value
		v_u_5.Rear.SpeedRear.Text = "000"
		v_u_5.Rear.SpeedRear2.Text = "000"
		v_u_5.Rear.SpeedRear.Emissive.Visible = true
		local v_u_79 = v_u_1.Character.Head
		local v_u_80 = v_u_5.Front.SpeedPatrol
		local v_u_81 = nil
		local v_u_82 = true
		v_u_81 = game:GetService("RunService").Heartbeat:Connect(function()
			-- upvalues: (copy) v_u_79, (ref) v_u_81, (copy) v_u_80, (ref) v_u_19, (ref) v_u_17, (ref) v_u_15, (copy) v_u_82, (ref) v_u_30, (ref) v_u_18, (ref) v_u_16
			if v_u_79 and (v_u_79.Parent and v_u_79:IsDescendantOf(workspace)) then
				v_u_79.Parent:FindFirstChild("HumanoidRootPart")
				local v83 = v_u_79.Velocity.Magnitude / 1.799
				local v84 = math.floor(v83)
				if v_u_79.Parent.Humanoid.Sit == true then
					v_u_80.Text = v84
					local v85 = v_u_80 and (v_u_80.Parent and v_u_80.Parent.Name) or "Front"
					if v85 == "Front" and (v_u_19[v_u_17] < v84 and not (v_u_15 or v_u_82)) then
						v_u_30(v85, v_u_79, v84)
						return
					end
					if v85 == "Rear" and (v_u_19[v_u_18] < v84 and not (v_u_16 or v_u_82)) then
						v_u_30(v85, v_u_79, v84)
						return
					end
				else
					v_u_80.Text = "000"
				end
			else
				if v_u_81 then
					v_u_81:Disconnect()
					v_u_81 = nil
				end
				if v_u_80 then
					v_u_80.Text = "000"
				end
			end
		end)
		if not v_u_14 then
			local v_u_86 = v_u_1.Character.HumanoidRootPart
			local v_u_87 = 175
			task.spawn(function()
				-- upvalues: (ref) v_u_13, (ref) v_u_14, (copy) v_u_86, (copy) v_u_87, (ref) v_u_5, (ref) v_u_21, (ref) v_u_19, (ref) v_u_17, (ref) v_u_15, (ref) v_u_30, (ref) v_u_18, (ref) v_u_16, (ref) v_u_20
				while v_u_13 and not v_u_14 do
					for _, v_u_88 in ipairs(game.Players:GetPlayers()) do
						if v_u_88 ~= game.Players.LocalPlayer then
							local v89 = v_u_88.Character
							local v_u_90 = v89:FindFirstChild("Head")
							if v_u_90 and (v89:FindFirstChild("HumanoidRootPart") and (v_u_90.Position - v_u_86.Position).Magnitude <= v_u_87) then
								local v91 = v_u_86.CFrame.LookVector:Dot((v_u_90.Position - v_u_86.Position).Unit)
								local v92 = math.acos(v91)
								local v93 = math.deg(v92)
								local v_u_94 = nil
								local v_u_95 = nil
								if v93 < 90 then
									v_u_95 = v_u_5.Front.SpeedFront
									v_u_94 = "Front"
								elseif v93 > 90 and v93 < 180 then
									v_u_95 = v_u_5.Rear.SpeedRear
									v_u_94 = "Rear"
								end
								if v_u_94 and not v_u_21[v_u_88.UserId .. "_" .. v_u_94] then
									local v_u_96 = nil
									local v_u_97 = false
									v_u_96 = game:GetService("RunService").Heartbeat:Connect(function()
										-- upvalues: (copy) v_u_90, (ref) v_u_96, (copy) v_u_95, (ref) v_u_19, (ref) v_u_17, (ref) v_u_15, (copy) v_u_97, (ref) v_u_30, (ref) v_u_18, (ref) v_u_16
										if v_u_90 and (v_u_90.Parent and v_u_90:IsDescendantOf(workspace)) then
											v_u_90.Parent:FindFirstChild("HumanoidRootPart")
											local v98 = v_u_90.Velocity.Magnitude / 1.799
											local v99 = math.floor(v98)
											if v_u_90.Parent.Humanoid.Sit == true then
												v_u_95.Text = v99
												local v100 = v_u_95 and (v_u_95.Parent and v_u_95.Parent.Name) or "Front"
												if v100 == "Front" and (v_u_19[v_u_17] < v99 and not (v_u_15 or v_u_97)) then
													v_u_30(v100, v_u_90, v99)
													return
												end
												if v100 == "Rear" and (v_u_19[v_u_18] < v99 and not (v_u_16 or v_u_97)) then
													v_u_30(v100, v_u_90, v99)
													return
												end
											else
												v_u_95.Text = "000"
											end
										else
											if v_u_96 then
												v_u_96:Disconnect()
												v_u_96 = nil
											end
											if v_u_95 then
												v_u_95.Text = "000"
											end
										end
									end)
									local v_u_101 = v_u_96
									v_u_20[v_u_88.UserId .. "_" .. v_u_94] = v_u_101
									v_u_21[v_u_88.UserId .. "_" .. v_u_94] = true
									if v_u_88:FindFirstChild("CarInfo") then
										if v_u_94 == "Front" then
											v_u_5.PlateReader.FRONTPLATE.Text = v_u_88.CarInfo.PlateNumber.Value
											v_u_5.PlateReader.CarMAKE.Text = v_u_88.CarInfo.CarMake.Value
										elseif v_u_94 == "Rear" then
											v_u_5.PlateReader.REARPLATE.Text = v_u_88.CarInfo.PlateNumber.Value
											v_u_5.PlateReader.CarMAKE.Text = v_u_88.CarInfo.CarMake.Value
										end
									end
									task.delay(2, function()
										-- upvalues: (copy) v_u_101, (ref) v_u_95, (ref) v_u_20, (copy) v_u_88, (ref) v_u_94, (ref) v_u_21
										if v_u_101 and v_u_101.Connected then
											v_u_101:Disconnect()
										end
										v_u_95.Text = "000"
										v_u_20[v_u_88.UserId .. "_" .. v_u_94] = nil
										v_u_21[v_u_88.UserId .. "_" .. v_u_94] = nil
									end)
								end
							end
						end
					end
					task.wait(0.1)
				end
			end)
			return
		end
	end
end)
v_u_6.Front.StartXmit.MouseButton1Click:Connect(function()
	-- upvalues: (ref) v_u_13, (ref) v_u_14, (copy) v_u_5, (copy) v_u_2, (copy) v_u_3, (copy) v_u_19, (ref) v_u_17, (ref) v_u_15, (copy) v_u_30, (ref) v_u_18, (ref) v_u_16, (copy) v_u_1
	if not game.Workspace:FindFirstChild("XmitZoneFront") and (v_u_13 and v_u_14) then
		script.Xmit:Play()
		v_u_5.Front.XMIT.TextColor3 = v_u_5.Front.XMIT.IlluminatedColor.Value
		v_u_5.Front.SAME.TextColor3 = v_u_5.Front.SAME.IlluminatedColor.Value
		local v_u_102 = game.ReplicatedStorage.Radar.XmitZoneFront:Clone()
		v_u_102.Parent = game.Workspace
		local v_u_103 = nil
		local v_u_117 = v_u_2.Move:Connect(function()
			-- upvalues: (ref) v_u_3, (copy) v_u_102, (ref) v_u_2
			local v104 = v_u_3
			local v105 = v_u_102
			local v106 = TweenInfo.new(0.25, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)
			local v107 = {}
			local v108 = CFrame.new(v_u_2.Hit.Position)
			local v109 = CFrame.Angles
			local v110 = -workspace.CurrentCamera.CFrame.LookVector.X
			local v111 = -workspace.CurrentCamera.CFrame.LookVector.Z
			v107.CFrame = v108 * v109(0, math.atan2(v110, v111), 0)
			v104:Create(v105, v106, v107):Play()
			local v112 = workspace
			local v113 = v_u_102.Position
			local v114 = v_u_102.Size.Y / 2
			local v115 = v112:Raycast(v113 - Vector3.new(0, v114, 0), Vector3.new(0, -1, 0) * (v_u_102.Size.Y / 2))
			if v115 and v115.Instance then
				local v116 = v_u_102.Size.Y / 2 - (v_u_102.Position.Y - v115.Position.Y)
				if v116 > 0 then
					v_u_102.Position = v_u_102.Position + Vector3.new(0, v116, 0)
				end
			end
		end)
		v_u_103 = v_u_2.Button1Down:Connect(function()
			-- upvalues: (ref) v_u_117, (ref) v_u_103, (ref) v_u_3, (copy) v_u_102, (ref) v_u_2, (ref) v_u_5, (ref) v_u_19, (ref) v_u_17, (ref) v_u_15, (ref) v_u_30, (ref) v_u_18, (ref) v_u_16, (ref) v_u_1
			v_u_117:Disconnect()
			v_u_103:Disconnect()
			local v118 = v_u_3
			local v119 = v_u_102
			local v120 = TweenInfo.new(0.25, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)
			local v121 = {}
			local v122 = CFrame.new(v_u_2.Hit.Position)
			local v123 = CFrame.Angles
			local v124 = -workspace.CurrentCamera.CFrame.LookVector.X
			local v125 = -workspace.CurrentCamera.CFrame.LookVector.Z
			v121.CFrame = v122 * v123(0, math.atan2(v124, v125), 0)
			v118:Create(v119, v120, v121):Play()
			v_u_5.Front.SpeedFront.Text = "000"
			v_u_5.Front.SpeedFront2.Text = "000"
			v_u_5.Front.SpeedFront.TextColor3 = v_u_5.Front.SpeedFront.IlluminatedColor.Value
			v_u_5.Front.SpeedFront.Emissive.Visible = true
			task.wait(1)
			local v_u_126 = v_u_102
			local v_u_127 = v_u_5.Front.SpeedFront
			local _ = v_u_5.Front.SpeedFront2
			local v_u_128 = "Front"
			task.spawn(function()
				-- upvalues: (copy) v_u_126, (copy) v_u_127, (ref) v_u_19, (ref) v_u_17, (ref) v_u_15, (ref) v_u_30, (ref) v_u_18, (ref) v_u_16, (copy) v_u_128, (ref) v_u_5, (ref) v_u_1
				while v_u_126 and v_u_126.Parent do
					local v129 = workspace:GetPartsInPart(v_u_126)
					for _, v_u_130 in ipairs(v129) do
						if v_u_130.Name == "Head" and v_u_130.Parent:FindFirstChild("Humanoid") then
							local v131 = game.Players:GetPlayerFromCharacter(v_u_130.Parent)
							if v131 then
								local v_u_132 = v_u_127
								local v_u_133 = nil
								local v_u_134 = false
								v_u_133 = game:GetService("RunService").Heartbeat:Connect(function()
									-- upvalues: (copy) v_u_130, (ref) v_u_133, (copy) v_u_132, (ref) v_u_19, (ref) v_u_17, (ref) v_u_15, (copy) v_u_134, (ref) v_u_30, (ref) v_u_18, (ref) v_u_16
									if v_u_130 and (v_u_130.Parent and v_u_130:IsDescendantOf(workspace)) then
										v_u_130.Parent:FindFirstChild("HumanoidRootPart")
										local v135 = v_u_130.Velocity.Magnitude / 1.799
										local v136 = math.floor(v135)
										if v_u_130.Parent.Humanoid.Sit == true then
											v_u_132.Text = v136
											local v137 = v_u_132 and (v_u_132.Parent and v_u_132.Parent.Name) or "Front"
											if v137 == "Front" and (v_u_19[v_u_17] < v136 and not (v_u_15 or v_u_134)) then
												v_u_30(v137, v_u_130, v136)
												return
											end
											if v137 == "Rear" and (v_u_19[v_u_18] < v136 and not (v_u_16 or v_u_134)) then
												v_u_30(v137, v_u_130, v136)
												return
											end
										else
											v_u_132.Text = "000"
										end
									else
										if v_u_133 then
											v_u_133:Disconnect()
											v_u_133 = nil
										end
										if v_u_132 then
											v_u_132.Text = "000"
										end
									end
								end)
								local v_u_138 = v_u_133
								task.delay(2, function()
									-- upvalues: (copy) v_u_138, (ref) v_u_127
									if v_u_138 and v_u_138.Connected then
										v_u_138:Disconnect()
										v_u_127.Text = "000"
									end
								end)
							end
							if v131:FindFirstChild("CarInfo") then
								if v_u_128 == "Front" then
									v_u_5.PlateReader.FRONTPLATE.Text = v_u_1.CarInfo.PlateNumber.Value
									v_u_5.PlateReader.CarMAKE.Text = v_u_1.CarInfo.CarMake.Value
								elseif v_u_128 == "Rear" then
									v_u_5.PlateReader.REARPLATE.Text = v_u_1.CarInfo.PlateNumber.Value
									v_u_5.PlateReader.CarMAKE.Text = v_u_1.CarInfo.CarMake.Value
								end
							end
						end
					end
					task.wait(0.1)
				end
			end)
			v_u_102.Transparency = 1
			v_u_102.CanQuery = true
		end)
	end
end)
v_u_6.Rear.StartXmit.MouseButton1Click:Connect(function()
	-- upvalues: (ref) v_u_13, (ref) v_u_14, (copy) v_u_5, (copy) v_u_2, (copy) v_u_3, (copy) v_u_19, (ref) v_u_17, (ref) v_u_15, (copy) v_u_30, (ref) v_u_18, (ref) v_u_16, (copy) v_u_1
	if not game.Workspace:FindFirstChild("XmitZoneRear") and (v_u_13 and v_u_14) then
		script.Xmit:Play()
		v_u_5.Rear.XMIT.TextColor3 = v_u_5.Rear.XMIT.IlluminatedColor.Value
		v_u_5.Rear.SAME.TextColor3 = v_u_5.Rear.SAME.IlluminatedColor.Value
		local v_u_139 = game.ReplicatedStorage.Radar.XmitZoneRear:Clone()
		v_u_139.Parent = game.Workspace
		local v_u_140 = nil
		local v_u_154 = v_u_2.Move:Connect(function()
			-- upvalues: (ref) v_u_3, (copy) v_u_139, (ref) v_u_2
			local v141 = v_u_3
			local v142 = v_u_139
			local v143 = TweenInfo.new(0.25, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)
			local v144 = {}
			local v145 = CFrame.new(v_u_2.Hit.Position)
			local v146 = CFrame.Angles
			local v147 = -workspace.CurrentCamera.CFrame.LookVector.X
			local v148 = -workspace.CurrentCamera.CFrame.LookVector.Z
			v144.CFrame = v145 * v146(0, math.atan2(v147, v148), 0)
			v141:Create(v142, v143, v144):Play()
			local v149 = workspace
			local v150 = v_u_139.Position
			local v151 = v_u_139.Size.Y / 2
			local v152 = v149:Raycast(v150 - Vector3.new(0, v151, 0), Vector3.new(0, -1, 0) * (v_u_139.Size.Y / 2))
			if v152 and v152.Instance then
				local v153 = v_u_139.Size.Y / 2 - (v_u_139.Position.Y - v152.Position.Y)
				if v153 > 0 then
					v_u_139.Position = v_u_139.Position + Vector3.new(0, v153, 0)
				end
			end
		end)
		v_u_140 = v_u_2.Button1Down:Connect(function()
			-- upvalues: (ref) v_u_154, (ref) v_u_140, (ref) v_u_3, (copy) v_u_139, (ref) v_u_2, (ref) v_u_5, (ref) v_u_19, (ref) v_u_17, (ref) v_u_15, (ref) v_u_30, (ref) v_u_18, (ref) v_u_16, (ref) v_u_1
			v_u_154:Disconnect()
			v_u_140:Disconnect()
			local v155 = v_u_3
			local v156 = v_u_139
			local v157 = TweenInfo.new(0.25, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)
			local v158 = {}
			local v159 = CFrame.new(v_u_2.Hit.Position)
			local v160 = CFrame.Angles
			local v161 = -workspace.CurrentCamera.CFrame.LookVector.X
			local v162 = -workspace.CurrentCamera.CFrame.LookVector.Z
			v158.CFrame = v159 * v160(0, math.atan2(v161, v162), 0)
			v155:Create(v156, v157, v158):Play()
			v_u_5.Rear.SpeedRear.Text = "000"
			v_u_5.Rear.SpeedRear2.Text = "000"
			v_u_5.Rear.SpeedRear.TextColor3 = v_u_5.Rear.SpeedRear.IlluminatedColor.Value
			v_u_5.Rear.SpeedRear.Emissive.Visible = true
			task.wait(1)
			local v_u_163 = v_u_139
			local v_u_164 = v_u_5.Rear.SpeedRear
			local _ = v_u_5.Rear.SpeedRear2
			local v_u_165 = "Rear"
			task.spawn(function()
				-- upvalues: (copy) v_u_163, (copy) v_u_164, (ref) v_u_19, (ref) v_u_17, (ref) v_u_15, (ref) v_u_30, (ref) v_u_18, (ref) v_u_16, (copy) v_u_165, (ref) v_u_5, (ref) v_u_1
				while v_u_163 and v_u_163.Parent do
					local v166 = workspace:GetPartsInPart(v_u_163)
					for _, v_u_167 in ipairs(v166) do
						if v_u_167.Name == "Head" and v_u_167.Parent:FindFirstChild("Humanoid") then
							local v168 = game.Players:GetPlayerFromCharacter(v_u_167.Parent)
							if v168 then
								local v_u_169 = v_u_164
								local v_u_170 = nil
								local v_u_171 = false
								v_u_170 = game:GetService("RunService").Heartbeat:Connect(function()
									-- upvalues: (copy) v_u_167, (ref) v_u_170, (copy) v_u_169, (ref) v_u_19, (ref) v_u_17, (ref) v_u_15, (copy) v_u_171, (ref) v_u_30, (ref) v_u_18, (ref) v_u_16
									if v_u_167 and (v_u_167.Parent and v_u_167:IsDescendantOf(workspace)) then
										v_u_167.Parent:FindFirstChild("HumanoidRootPart")
										local v172 = v_u_167.Velocity.Magnitude / 1.799
										local v173 = math.floor(v172)
										if v_u_167.Parent.Humanoid.Sit == true then
											v_u_169.Text = v173
											local v174 = v_u_169 and (v_u_169.Parent and v_u_169.Parent.Name) or "Front"
											if v174 == "Front" and (v_u_19[v_u_17] < v173 and not (v_u_15 or v_u_171)) then
												v_u_30(v174, v_u_167, v173)
												return
											end
											if v174 == "Rear" and (v_u_19[v_u_18] < v173 and not (v_u_16 or v_u_171)) then
												v_u_30(v174, v_u_167, v173)
												return
											end
										else
											v_u_169.Text = "000"
										end
									else
										if v_u_170 then
											v_u_170:Disconnect()
											v_u_170 = nil
										end
										if v_u_169 then
											v_u_169.Text = "000"
										end
									end
								end)
								local v_u_175 = v_u_170
								task.delay(2, function()
									-- upvalues: (copy) v_u_175, (ref) v_u_164
									if v_u_175 and v_u_175.Connected then
										v_u_175:Disconnect()
										v_u_164.Text = "000"
									end
								end)
							end
							if v168:FindFirstChild("CarInfo") then
								if v_u_165 == "Front" then
									v_u_5.PlateReader.FRONTPLATE.Text = v_u_1.CarInfo.PlateNumber.Value
									v_u_5.PlateReader.CarMAKE.Text = v_u_1.CarInfo.CarMake.Value
								elseif v_u_165 == "Rear" then
									v_u_5.PlateReader.REARPLATE.Text = v_u_1.CarInfo.PlateNumber.Value
									v_u_5.PlateReader.CarMAKE.Text = v_u_1.CarInfo.CarMake.Value
								end
							end
						end
					end
					task.wait(0.1)
				end
			end)
			v_u_139.Transparency = 1
			v_u_139.CanQuery = true
		end)
	end
end)
v_u_6.Front.ClearZone.MouseButton1Click:Connect(function()
	-- upvalues: (copy) v_u_5
	if game.Workspace:FindFirstChild("XmitZoneFront") then
		game.Workspace:FindFirstChild("XmitZoneFront"):Destroy()
		script.Xmit:Play()
		v_u_5.Front.XMIT.TextColor3 = v_u_5.Front.XMIT.OriginalColor.Value
		v_u_5.Front.SAME.TextColor3 = v_u_5.Front.SAME.OriginalColor.Value
		v_u_5.Front.SpeedFront.TextColor3 = v_u_5.Front.SpeedFront.OriginalColor.Value
		v_u_5.Front.SpeedFront.Emissive.Visible = false
		v_u_5.Front.SpeedFront2.Text = "OFF"
	end
end)
v_u_6.Rear.ClearZone.MouseButton1Click:Connect(function()
	-- upvalues: (copy) v_u_5
	if game.Workspace:FindFirstChild("XmitZoneRear") then
		game.Workspace:FindFirstChild("XmitZoneRear"):Destroy()
		script.Xmit:Play()
		v_u_5.Rear.XMIT.TextColor3 = v_u_5.Rear.XMIT.OriginalColor.Value
		v_u_5.Rear.SAME.TextColor3 = v_u_5.Rear.SAME.OriginalColor.Value
		v_u_5.Rear.SpeedRear.TextColor3 = v_u_5.Rear.SpeedRear.OriginalColor.Value
		v_u_5.Rear.SpeedRear.Emissive.Visible = false
		v_u_5.Rear.SpeedRear2.Text = "OFF"
	end
end)
local v_u_176 = v_u_18
local v_u_177 = v_u_17
local v_u_178 = v_u_13
for _, v_u_179 in pairs(v_u_6.Front:GetChildren()) do
	v_u_179.MouseButton1Click:Connect(function()
		-- upvalues: (copy) v_u_3, (copy) v_u_179
		script.Click:Play()
		v_u_3:Create(v_u_179, TweenInfo.new(0.15, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
			["Size"] = UDim2.new(0.203, 0, 0.1, 0)
		}):Play()
		task.wait(0.15)
		v_u_3:Create(v_u_179, TweenInfo.new(0.15, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
			["Size"] = UDim2.new(0.219, 0, 0.116, 0)
		}):Play()
	end)
end
for _, v_u_180 in pairs(v_u_6.Rear:GetChildren()) do
	v_u_180.MouseButton1Click:Connect(function()
		-- upvalues: (copy) v_u_3, (copy) v_u_180
		script.Click:Play()
		v_u_3:Create(v_u_180, TweenInfo.new(0.15, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
			["Size"] = UDim2.new(0.203, 0, 0.1, 0)
		}):Play()
		task.wait(0.15)
		v_u_3:Create(v_u_180, TweenInfo.new(0.15, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
			["Size"] = UDim2.new(0.219, 0, 0.116, 0)
		}):Play()
	end)
end
for _, v_u_181 in pairs(v_u_6:GetChildren()) do
	if v_u_181:IsA("ImageButton") then
		v_u_181.MouseButton1Click:Connect(function()
			-- upvalues: (copy) v_u_3, (copy) v_u_181
			script.Click:Play()
			v_u_3:Create(v_u_181, TweenInfo.new(0.15, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
				["Size"] = UDim2.new(0.605, 0, 0.072, 0)
			}):Play()
			task.wait(0.15)
			v_u_3:Create(v_u_181, TweenInfo.new(0.15, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
				["Size"] = UDim2.new(0.623, 0, 0.078, 0)
			}):Play()
		end)
	end
end
local v_u_182 = false
v_u_6.Front.SetSpeed.MouseButton1Click:Connect(function()
	-- upvalues: (ref) v_u_178, (ref) v_u_182, (ref) v_u_177, (copy) v_u_19, (copy) v_u_5
	if v_u_178 and not v_u_182 then
		v_u_177 = v_u_177 + 1
		v_u_182 = true
		if v_u_177 > #v_u_19 then
			v_u_177 = 1
		end
		local v183 = v_u_5.Front.SpeedFront2
		local v184 = v_u_19[v_u_177]
		v183.Text = "0" .. tostring(v184)
		task.wait(0.25)
		v_u_182 = false
		v_u_5.Front.SpeedFront2.Text = "000"
	end
end)
v_u_6.Rear.SetSpeed.MouseButton1Click:Connect(function()
	-- upvalues: (ref) v_u_178, (ref) v_u_182, (ref) v_u_176, (copy) v_u_19, (copy) v_u_5
	if v_u_178 and not v_u_182 then
		v_u_176 = v_u_176 + 1
		v_u_182 = true
		if v_u_176 > #v_u_19 then
			v_u_176 = 1
		end
		local v185 = v_u_5.Rear.SpeedRear2
		local v186 = v_u_19[v_u_176]
		v185.Text = "0" .. tostring(v186)
		task.wait(1)
		v_u_182 = false
		v_u_5.Rear.SpeedRear2.Text = "000"
	end
end)
v_u_5.Draggable = true
v_u_6.Draggable = true