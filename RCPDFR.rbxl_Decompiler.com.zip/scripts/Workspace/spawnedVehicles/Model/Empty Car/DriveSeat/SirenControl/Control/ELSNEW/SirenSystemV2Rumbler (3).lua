-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game.Workspace:FindFirstChild(script.Parent.Parent.CarName.Value, true).Body
local v2 = game.Players.LocalPlayer:GetMouse()
game:GetService("Players").PlayerAdded:Connect(function(_)
	game.SoundService.RespectFilteringEnabled = false
end)
local v_u_3 = script.Parent.SliderSwitch
local v_u_4 = script.Parent.ELSBeep
local _ = script.Parent.Click
local v_u_5 = v_u_1.ELS.middle
local v_u_6 = {
	["Wail"] = {
		["volume"] = 3
	},
	["Yelp"] = {
		["volume"] = 3
	},
	["Priority"] = {
		["volume"] = 3
	},
	["Manual"] = {
		["volume"] = 3
	},
	["HandsFree"] = {
		["volume"] = 3
	},
	["HornSiren"] = {
		["volume"] = 3
	},
	["WailR"] = {
		["volume"] = 3
	},
	["YelpR"] = {
		["volume"] = 3
	},
	["PriorityR"] = {
		["volume"] = 3
	},
	["ManualR"] = {
		["volume"] = 3
	}
}
local v_u_7 = false
local v_u_8 = nil
local v_u_22 = {
	["f"] = function()
		-- upvalues: (copy) v_u_5, (ref) v_u_7, (copy) v_u_6
		v_u_5.Airhorn:Play()
		if v_u_7 then
			v_u_5.AirhornR:Play()
		end
		for v9, _ in pairs(v_u_6) do
			if v9 ~= "Airhorn" then
				v_u_5[v9].Volume = 0
			end
		end
	end,
	["h"] = function()
		-- upvalues: (copy) v_u_5, (ref) v_u_7, (copy) v_u_6
		v_u_5.HornSiren:Play()
		if v_u_7 then
			v_u_5.HornSirenR:Play()
		end
		for v10, _ in pairs(v_u_6) do
			if v10 ~= "HornSiren" then
				v_u_5[v10].Volume = 0
			end
		end
	end,
	["r"] = function()
		-- upvalues: (copy) v_u_4, (ref) v_u_8, (copy) v_u_5, (ref) v_u_7
		v_u_4:Play()
		if v_u_8 and v_u_8 ~= "Wail" then
			local v11 = v_u_8
			v_u_5[v11]:Stop()
			if v_u_7 then
				v_u_5[v11 .. "R"]:Stop()
			end
		end
		local v12 = not v_u_5.Wail.IsPlaying
		if v12 then
			v_u_5.Wail:Play()
		else
			v_u_5.Wail:Stop()
		end
		if v_u_7 then
			if v12 then
				v_u_5.WailR:Play()
			else
				v_u_5.WailR:Stop()
			end
		end
		v_u_8 = v12 and "Wail" or nil
	end,
	["t"] = function()
		-- upvalues: (copy) v_u_4, (ref) v_u_8, (copy) v_u_5, (ref) v_u_7
		v_u_4:Play()
		if v_u_8 and v_u_8 ~= "Yelp" then
			local v13 = v_u_8
			v_u_5[v13]:Stop()
			if v_u_7 then
				v_u_5[v13 .. "R"]:Stop()
			end
		end
		local v14 = not v_u_5.Yelp.IsPlaying
		if v14 then
			v_u_5.Yelp:Play()
		else
			v_u_5.Yelp:Stop()
		end
		if v_u_7 then
			if v14 then
				v_u_5.YelpR:Play()
			else
				v_u_5.YelpR:Stop()
			end
		end
		v_u_8 = v14 and "Yelp" or nil
	end,
	["g"] = function()
		-- upvalues: (copy) v_u_4, (ref) v_u_8, (copy) v_u_5, (ref) v_u_7
		v_u_4:Play()
		if v_u_8 and v_u_8 ~= "Priority" then
			local v15 = v_u_8
			v_u_5[v15]:Stop()
			if v_u_7 then
				v_u_5[v15 .. "R"]:Stop()
			end
		end
		local v16 = not v_u_5.Priority.IsPlaying
		if v16 then
			v_u_5.Priority:Play()
		else
			v_u_5.Priority:Stop()
		end
		if v_u_7 then
			if v16 then
				v_u_5.PriorityR:Play()
			else
				v_u_5.PriorityR:Stop()
			end
		end
		v_u_8 = v16 and "Priority" or nil
	end,
	["n"] = function()
		-- upvalues: (copy) v_u_4, (ref) v_u_8, (copy) v_u_5, (ref) v_u_7
		v_u_4:Play()
		if v_u_8 and v_u_8 ~= "Manual" then
			local v17 = v_u_8
			v_u_5[v17]:Stop()
			if v_u_7 then
				v_u_5[v17 .. "R"]:Stop()
			end
		end
		local v18 = not v_u_5.Manual.IsPlaying
		if v18 then
			v_u_5.Manual:Play()
		else
			v_u_5.Manual:Stop()
		end
		if v_u_7 then
			if v18 then
				v_u_5.ManualR:Play()
			else
				v_u_5.ManualR:Stop()
			end
		end
		v_u_8 = v18 and "Manual" or nil
	end,
	["y"] = function()
		-- upvalues: (copy) v_u_4, (ref) v_u_8, (copy) v_u_5, (ref) v_u_7
		v_u_4:Play()
		if v_u_8 and v_u_8 ~= "HandsFree" then
			local v19 = v_u_8
			v_u_5[v19]:Stop()
			if v_u_7 then
				v_u_5[v19 .. "R"]:Stop()
			end
		end
		local v20 = not v_u_5.HandsFree.IsPlaying
		if v20 then
			v_u_5.HandsFree:Play()
		else
			v_u_5.HandsFree:Stop()
		end
		if v_u_7 then
			if v20 then
				v_u_5.HandsFreeR:Play()
			else
				v_u_5.HandsFreeR:Stop()
			end
		end
		v_u_8 = v20 and "HandsFree" or nil
	end,
	["j"] = function()
		-- upvalues: (copy) v_u_3, (copy) v_u_1
		v_u_3:Play()
		v_u_1.ELS.StageEvent:FireServer(true)
	end,
	["k"] = function()
		-- upvalues: (copy) v_u_4, (copy) v_u_1
		v_u_4:Play()
		v_u_1.ELS.TAevent:FireServer(true)
	end,
	["["] = function()
		-- upvalues: (copy) v_u_4, (copy) v_u_1
		v_u_4:Play()
		v_u_1.ELS.CruiseEvent:FireServer(true)
	end,
	["]"] = function()
		-- upvalues: (copy) v_u_4, (copy) v_u_1
		v_u_4:Play()
		v_u_1.ELS.TakeDNEvent:FireServer(true)
	end,
	["-"] = function()
		-- upvalues: (copy) v_u_4, (copy) v_u_1
		v_u_4:Play()
		v_u_1.ELS.AlleyEvent:FireServer(true)
	end,
	["="] = function()
		-- upvalues: (ref) v_u_7, (ref) v_u_8, (copy) v_u_5
		v_u_7 = not v_u_7
		if v_u_8 then
			local v21 = v_u_8 .. "R"
			if v_u_7 then
				v_u_5[v21]:Play()
				return
			end
			v_u_5[v21]:Stop()
		end
	end
}
v2.KeyDown:Connect(function(p23)
	-- upvalues: (copy) v_u_22
	if v_u_22[p23] then
		v_u_22[p23]()
	end
end)
v2.KeyUp:Connect(function(p24)
	-- upvalues: (copy) v_u_5, (ref) v_u_7, (copy) v_u_6
	if p24 == "f" then
		v_u_5.Airhorn:Stop()
		if v_u_7 then
			v_u_5.AirhornR:Stop()
		end
		for v25, _ in pairs(v_u_6) do
			if v25 ~= "Airhorn" then
				v_u_5[v25].Volume = v_u_6[v25].volume
			end
		end
		v_u_5.AirhornR:Stop()
		if v_u_7 then
			v_u_5.AirhornRR:Stop()
		end
		for v26, _ in pairs(v_u_6) do
			if v26 ~= "AirhornR" then
				v_u_5[v26].Volume = v_u_6[v26].volume
			end
		end
	elseif p24 == "h" then
		v_u_5.HornSiren:Stop()
		if v_u_7 then
			v_u_5.HornSirenR:Stop()
		end
		for v27, _ in pairs(v_u_6) do
			if v27 ~= "HornSiren" then
				v_u_5[v27].Volume = v_u_6[v27].volume
			end
		end
		v_u_5.HornSirenR:Stop()
		if v_u_7 then
			v_u_5.HornSirenRR:Stop()
		end
		for v28, _ in pairs(v_u_6) do
			if v28 ~= "HornSirenR" then
				v_u_5[v28].Volume = v_u_6[v28].volume
			end
		end
	end
end)