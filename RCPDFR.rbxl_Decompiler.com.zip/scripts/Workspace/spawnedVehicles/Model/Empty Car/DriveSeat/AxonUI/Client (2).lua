-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = script.Parent.fgrain
local v_u_2 = {
	17823920379,
	17823921051,
	17823921432,
	17823921951,
	17823922224
}
local v3 = math.random(10000000, 90000000)
script.Parent.Date.Text = os.date("%Y-%m-%d")
script.Parent.Number.Text = "X" .. tostring(v3)
game.Lighting:GetPropertyChangedSignal("TimeOfDay"):Connect(function()
	local v4 = script.Parent.Time
	local v5 = game.Lighting.TimeOfDay
	v4.Text = string.sub(v5, 1, 5)
end)
spawn(function()
	-- upvalues: (copy) v_u_2, (copy) v_u_1
	while true do
		for _, v6 in pairs(v_u_2) do
			v_u_1.Image = "rbxassetid://" .. v6
			wait(0.05)
		end
	end
end)