-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["Mass_kg"] = 0.0456,
	["Length_mm"] = 280,
	["Force_N"] = 0.163
}
v1.Stiffness_Ndivm = v1.Mass_kg
v1.Damping_N_sdivm = v1.Mass_kg
v1.Velocity_mdivs = 1 / (v1.Length_mm / 1000)
v1.Torque_nm = v1.Force_N / (v1.Length_mm / 1000)
return v1