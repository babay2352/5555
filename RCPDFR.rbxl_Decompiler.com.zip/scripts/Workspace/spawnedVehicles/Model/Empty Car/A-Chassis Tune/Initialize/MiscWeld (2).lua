-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

function MakeWeld(p1, p2, p3, p4)
	local v5 = p3 == nil and "Weld" or p3
	local v6 = Instance.new(v5)
	v6.Part0 = p1
	v6.Part1 = p2
	v6.C0 = p1.CFrame:inverse() * p1.CFrame
	v6.C1 = p2.CFrame:inverse() * p1.CFrame
	v6.Parent = p1
	if v5 == "Motor" and p4 ~= nil then
		v6.MaxVelocity = p4
	end
	return v6
end
function ModelWeld(p7, p8)
	if p7:IsA("BasePart") then
		MakeWeld(p8, p7, "Weld")
	elseif p7:IsA("Model") then
		for _, v9 in pairs(p7:GetChildren()) do
			ModelWeld(v9, p8)
		end
	end
end
car = script.Parent.Parent.Parent
misc = car:WaitForChild("Misc")
car.DriveSeat.ChildAdded:connect(function(p10)
	if p10.Name == "SeatWeld" and (p10:IsA("Weld") and game.Players:GetPlayerFromCharacter(p10.Part1.Parent) ~= nil) then
		p10.C0 = CFrame.new(0, -0.5, 0) * CFrame.fromEulerAnglesXYZ(-1.5707963267948966, 0, 0) * CFrame.Angles(0.22689280275926285, 0, 0)
	end
end)
return {}