-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = script.Parent:WaitForChild("Car").Value
local _ = v1.Body
local v2 = v1.Body.ExhaustSmoke.Parts
while wait(0.12) do
	local v3 = script.Parent.Values.RPM.Value
	v1.exhsmoke:FireServer(v2, v3)
end