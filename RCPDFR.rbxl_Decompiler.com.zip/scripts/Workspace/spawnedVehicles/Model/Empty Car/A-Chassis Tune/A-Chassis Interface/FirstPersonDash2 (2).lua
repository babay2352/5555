-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = Enum.KeyCode.V
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("UserInputService")
local v4 = script.Parent.Car.Value
local v_u_5 = game:GetService("Players").LocalPlayer
local v_u_6 = workspace.CurrentCamera
local v_u_7 = v4.Body.CamLocation
local v_u_8 = {}
local v_u_9 = v_u_6.FieldOfView
local v_u_10 = false
local v_u_11 = false
local v_u_12 = v_u_7:FindFirstChild("DashcamON")
function handleInput(p13, p14)
	-- upvalues: (copy) v_u_1, (ref) v_u_11, (ref) v_u_10
	if not p14 and (p13.KeyCode == v_u_1 and not v_u_11) then
		v_u_11 = true
		v_u_10 = not v_u_10
		if v_u_10 then
			enableCam()
		else
			disableCam()
		end
		v_u_11 = false
	end
end
function enableCam()
	-- upvalues: (copy) v_u_6, (copy) v_u_2, (copy) v_u_5, (copy) v_u_8, (copy) v_u_12
	v_u_6.CameraType = Enum.CameraType.Scriptable
	v_u_2:BindToRenderStep("FirstPerson", Enum.RenderPriority.Camera.Value, updateCam)
	v_u_5.Character.Humanoid:UnequipTools()
	for _, v15 in ipairs(v_u_5.Character:GetDescendants()) do
		if v15:IsA("BasePart") then
			v_u_8[v15] = v15.Transparency
			v15.LocalTransparencyModifier = 1
		end
	end
	v_u_6.FieldOfView = 60
	local v16 = v_u_5.PlayerGui.AxonUI
	v16.Enabled = true
	v16.Client.Enabled = true
	if v_u_12 then
		v_u_12:Play()
	end
end
function disableCam()
	-- upvalues: (copy) v_u_2, (copy) v_u_6, (copy) v_u_9, (copy) v_u_5, (copy) v_u_8
	v_u_2:UnbindFromRenderStep("FirstPerson")
	v_u_6.CameraType = Enum.CameraType.Custom
	v_u_6.FieldOfView = v_u_9
	v_u_6.CameraSubject = v_u_5.Character.Humanoid
	for _, v17 in ipairs(v_u_5.Character:GetDescendants()) do
		if v_u_8[v17] ~= nil then
			v17.LocalTransparencyModifier = v_u_8[v17]
		end
	end
	local v18 = v_u_5.PlayerGui.AxonUI
	v18.Enabled = false
	v18.Client.Enabled = false
end
function updateCam()
	-- upvalues: (copy) v_u_7, (copy) v_u_6, (copy) v_u_3
	local v19 = v_u_7
	local v20 = v_u_6.ViewportSize
	local v21 = v_u_3:GetMouseLocation()
	local v22 = v20 / 2 - v21
	local v23 = v19.CFrame
	local v24 = CFrame.Angles
	local v25 = 90 * v22.X / (v20.X / 2)
	v_u_6.CFrame = v23 * v24(0, math.rad(v25), 0)
end
for _, v26 in ipairs(v_u_5.Character:GetDescendants()) do
	if v26:IsA("BasePart") then
		v_u_8[v26] = v26.Transparency
	end
end
v4.DriveSeat.ChildRemoved:Connect(function(p27)
	if p27.Name == "SeatWeld" then
		disableCam()
	end
end)
v_u_3.InputBegan:Connect(handleInput)