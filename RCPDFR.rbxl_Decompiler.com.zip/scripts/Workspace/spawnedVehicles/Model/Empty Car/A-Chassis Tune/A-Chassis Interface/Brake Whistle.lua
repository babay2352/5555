-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = script.Parent.Car.Value
local v2 = v1.Brakeoverheat
local v3 = workspace.FilteringEnabled
v1.DriveSeat.Brakes:Play()
if v3 then
	v2:FireServer("SoundPlay")
	while wait() do
		v2:FireServer("SoundUpdate", sound)
		if script.Parent.Values.Brake.Value > 0.1 and ((v1.Wheels.RR.RotVelocity.Magnitude + v1.Wheels.FR.RotVelocity.Magnitude + v1.Wheels.FL.RotVelocity.Magnitude + v1.Wheels.RL.RotVelocity.Magnitude) / 4 > 10 and script.Parent.Values.Gear.Value > 0) then
			local v4 = script.Parent.Values.Brake.Value / 2 - 0.35
			sound = math.max(v4, 0)
		else
			local v5 = v1.DriveSeat.Brakes.Volume - 0.35
			sound = math.max(v5, 0)
		end
	end
else
	while wait() do
		if script.Parent.Values.Brake.Value > 0.1 and ((v1.Wheels.RR.RotVelocity.Magnitude + v1.Wheels.FR.RotVelocity.Magnitude + v1.Wheels.FL.RotVelocity.Magnitude + v1.Wheels.RL.RotVelocity.Magnitude) / 4 > 10 and script.Parent.Values.Gear.Value > 0) then
			local v6 = v1.DriveSeat.Brakes
			local v7 = script.Parent.Values.Brake.Value / 2 - 0.35
			v6.Volume = math.max(v7, 0)
		else
			local v8 = v1.DriveSeat.Brakes
			local v9 = v1.DriveSeat.Brakes.Volume - 0.35
			v8.Volume = math.max(v9, 0)
		end
	end
end