-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

script.Parent:WaitForChild("Car")
local v1 = script:WaitForChild("SpotlightValue")
repeat
	wait()
until v1.Value ~= nil
local v_u_2 = script.SpotlightInterface.Spotlight.ControlFrame
local v_u_3 = v1.Value
local v_u_4 = game:GetService("UserInputService")
local v_u_5 = false
v_u_4.InputBegan:Connect(function(p6)
	-- upvalues: (copy) v_u_4, (ref) v_u_5, (copy) v_u_2
	if v_u_4:IsKeyDown(Enum.KeyCode.LeftShift) and p6.KeyCode == Enum.KeyCode.P then
		v_u_5 = not v_u_5
		if v_u_5 then
			v_u_2.Visible = false
			return
		end
		v_u_2.Visible = true
	end
end)
v_u_2.On.MouseButton1Down:Connect(function()
	-- upvalues: (copy) v_u_3
	v_u_3:FireServer("Lights on")
end)
v_u_2.Off.MouseButton1Down:Connect(function()
	-- upvalues: (copy) v_u_3
	v_u_3:FireServer("Lights off")
end)
v_u_2.Right.MouseButton1Down:Connect(function()
	-- upvalues: (copy) v_u_3
	v_u_3:FireServer("Right")
end)
v_u_2.Right.MouseButton1Up:Connect(function()
	-- upvalues: (copy) v_u_3
	v_u_3:FireServer("Stop")
end)
v_u_2.Left.MouseButton1Down:Connect(function()
	-- upvalues: (copy) v_u_3
	v_u_3:FireServer("Left")
end)
v_u_2.Left.MouseButton1Up:Connect(function()
	-- upvalues: (copy) v_u_3
	v_u_3:FireServer("Stop")
end)
v_u_2.Up.MouseButton1Down:Connect(function()
	-- upvalues: (copy) v_u_3
	v_u_3:FireServer("Up")
end)
v_u_2.Down.MouseButton1Down:Connect(function()
	-- upvalues: (copy) v_u_3
	v_u_3:FireServer("Down")
end)
v_u_2.Up.MouseButton1Up:Connect(function()
	-- upvalues: (copy) v_u_3
	v_u_3:FireServer("Stop")
end)
v_u_2.Down.MouseButton1Up:Connect(function()
	-- upvalues: (copy) v_u_3
	v_u_3:FireServer("Stop")
end)