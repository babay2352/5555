-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("TweenService")
local v2 = game:GetService("UserInputService")
local v3 = script.Parent.Parent.Car.Value
local v_u_4 = script.Parent.Parent.Values
local v_u_5 = v3:WaitForChild("LIGHTS")
local v_u_6 = v_u_5.Values
local v_u_7 = script.Parent.GUI
local v_u_8 = script.Parent.Sounds
local v_u_9 = require(v_u_5.Configuration)
local v_u_10 = v_u_6.Lights.Value
local _ = v_u_6.Running.Value
local v_u_11 = false
function doTween(p12, p13, p14, p15, p16)
	-- upvalues: (copy) v_u_1
	v_u_1:Create(p12, TweenInfo.new(p13, p14, p15), p16):Play()
end
local v_u_17 = false
v_u_4.Brake.Changed:Connect(function()
	-- upvalues: (copy) v_u_4, (ref) v_u_17, (copy) v_u_5
	if v_u_4.Brake.Value > 0.02 and not v_u_17 then
		v_u_17 = true
		v_u_5:FireServer("Brake", true)
	elseif v_u_4.Brake.Value <= 0.02 and v_u_17 then
		v_u_17 = false
		v_u_5:FireServer("Brake", false)
	end
end)
v_u_4.Gear.Changed:Connect(function()
	-- upvalues: (copy) v_u_4, (copy) v_u_5
	if v_u_4.Gear.Value == -1 then
		v_u_5:FireServer("Reverse", true)
	else
		v_u_5:FireServer("Reverse", false)
	end
end)
v3.DriveSeat.ChildAdded:Connect(function(_)
	-- upvalues: (copy) v_u_9, (copy) v_u_7, (copy) v_u_5, (copy) v_u_6
	if not v_u_9.RunningHeadlight and v_u_9.RunningOnOpen then
		doTween(v_u_7.ParkLights, 0.15, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
			["ImageTransparency"] = 0
		})
		v_u_5:FireServer("Lights", v_u_6.Lights.Value, true)
	end
end)
task.spawn(function()
	-- upvalues: (copy) v_u_6, (copy) v_u_8, (copy) v_u_7, (copy) v_u_9
	while task.wait() do
		if v_u_6.Indicators.Left.Value then
			v_u_8.TickOn:Play()
			doTween(v_u_7.LeftInd, 0.15, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
				["ImageTransparency"] = 0
			})
			task.wait(v_u_9.IndicatorFlashRate)
			v_u_8.TickOff:Play()
			doTween(v_u_7.LeftInd, 0.15, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
				["ImageTransparency"] = 1
			})
			task.wait(v_u_9.IndicatorFlashRate)
		end
		if v_u_6.Indicators.Right.Value then
			v_u_8.TickOn:Play()
			doTween(v_u_7.RightInd, 0.15, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
				["ImageTransparency"] = 0
			})
			task.wait(v_u_9.IndicatorFlashRate)
			v_u_8.TickOff:Play()
			doTween(v_u_7.RightInd, 0.15, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
				["ImageTransparency"] = 1
			})
			task.wait(v_u_9.IndicatorFlashRate)
		end
		if v_u_6.Indicators.Hazard.Value then
			v_u_8.TickOn:Play()
			doTween(v_u_7.LeftInd, 0.15, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
				["ImageTransparency"] = 0
			})
			doTween(v_u_7.RightInd, 0.15, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
				["ImageTransparency"] = 0
			})
			task.wait(v_u_9.IndicatorFlashRate)
			v_u_8.TickOff:Play()
			doTween(v_u_7.LeftInd, 0.15, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
				["ImageTransparency"] = 1
			})
			doTween(v_u_7.RightInd, 0.15, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
				["ImageTransparency"] = 1
			})
			task.wait(v_u_9.IndicatorFlashRate)
		end
	end
end)
v2.InputEnded:Connect(function(p18, p19)
	-- upvalues: (copy) v_u_9, (ref) v_u_10, (ref) v_u_11, (copy) v_u_7, (copy) v_u_5
	if not p19 and (p18.KeyCode == v_u_9.HighBeamFlash and v_u_10 ~= 2) then
		v_u_11 = false
		doTween(v_u_7.HighBeams, 0.15, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
			["ImageTransparency"] = 1
		})
		if v_u_10 == 1 then
			doTween(v_u_7.LowBeams, 0.15, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
				["ImageTransparency"] = 0
			})
		end
		v_u_5:FireServer("Flash", false)
	end
end)
v2.InputBegan:Connect(function(p20, p21)
	-- upvalues: (copy) v_u_9, (ref) v_u_11, (ref) v_u_10, (copy) v_u_5, (copy) v_u_7, (copy) v_u_6, (copy) v_u_8
	if not p21 then
		if p20.KeyCode == v_u_9.Headlights and not v_u_11 then
			v_u_10 = v_u_10 + 1
			if v_u_10 > 2 then
				v_u_10 = 0
			end
			v_u_5:FireServer("Lights", v_u_10)
			if v_u_10 == 0 then
				doTween(v_u_7.HighBeams, 0.15, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
					["ImageTransparency"] = 1
				})
				if v_u_6.Fogs.Value then
					doTween(v_u_7.FogLights, 0.15, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
						["ImageTransparency"] = 1
					})
					v_u_5:FireServer("Fogs", v_u_6.Fogs.Value, true)
					return
				end
			elseif v_u_10 == 1 then
				doTween(v_u_7.LowBeams, 0.15, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
					["ImageTransparency"] = 0
				})
				if v_u_6.Fogs.Value then
					doTween(v_u_7.FogLights, 0.15, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
						["ImageTransparency"] = 0
					})
					v_u_5:FireServer("Fogs", v_u_6.Fogs.Value, false)
					return
				end
			elseif v_u_10 == 2 then
				doTween(v_u_7.LowBeams, 0.15, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
					["ImageTransparency"] = 1
				})
				doTween(v_u_7.HighBeams, 0.15, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
					["ImageTransparency"] = 0
				})
				return
			end
		else
			if p20.KeyCode == v_u_9.FogLights then
				if v_u_6.Fogs.Value then
					doTween(v_u_7.FogLights, 0.15, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
						["ImageTransparency"] = 1
					})
					v_u_5:FireServer("Fogs", false, false)
				else
					local v22 = true
					if v_u_10 > 0 then
						doTween(v_u_7.FogLights, 0.15, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
							["ImageTransparency"] = 0
						})
					end
					v_u_5:FireServer("Fogs", v22, false)
				end
			end
			if p20.KeyCode == v_u_9.SignalLeft then
				local v23
				if v_u_6.Indicators.Left.Value then
					v_u_8.IndOff:Play()
					v23 = false
				else
					v_u_8.IndOn:Play()
					v23 = true
				end
				v_u_5:FireServer("Signal", "Left", v23)
				return
			end
			if p20.KeyCode == v_u_9.SignalRight then
				local v24
				if v_u_6.Indicators.Right.Value then
					v_u_8.IndOff:Play()
					v24 = false
				else
					v_u_8.IndOn:Play()
					v24 = true
				end
				v_u_5:FireServer("Signal", "Right", v24)
				return
			end
			if p20.KeyCode == v_u_9.Hazards then
				v_u_5:FireServer("Signal", "Hazard", not v_u_6.Indicators.Hazard.Value)
				return
			end
			if p20.KeyCode == v_u_9.RunningLights then
				local v25
				if v_u_6.Running.Value then
					doTween(v_u_7.ParkLights, 0.15, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
						["ImageTransparency"] = 1
					})
					v25 = false
				else
					doTween(v_u_7.ParkLights, 0.15, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
						["ImageTransparency"] = 0
					})
					v25 = true
				end
				v_u_5:FireServer("Lights", v_u_6.Lights.Value, v25)
				return
			end
			if p20.KeyCode == v_u_9.Popups then
				if v_u_9.PopupsEnabled then
					v_u_5:FireServer("Popups", not v_u_6.Popups.Value)
					return
				end
			elseif p20.KeyCode == v_u_9.HighBeamFlash and v_u_10 ~= 2 then
				v_u_11 = true
				doTween(v_u_7.HighBeams, 0.15, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
					["ImageTransparency"] = 0
				})
				if v_u_10 == 1 then
					doTween(v_u_7.LowBeams, 0.15, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, {
						["ImageTransparency"] = 1
					})
				end
				v_u_5:FireServer("Flash", true)
			end
		end
	end
end)