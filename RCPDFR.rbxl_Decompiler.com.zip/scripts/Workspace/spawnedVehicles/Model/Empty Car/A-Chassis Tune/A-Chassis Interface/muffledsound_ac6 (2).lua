-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game.Players.LocalPlayer
repeat
	wait()
until v1
setupmode = "Auto"
soundplugin = "StockSound"
camkey = "v"
level = 50
exceptions = { "Pedal", "Shift" }
smoke = false
backfire = false
horn = false
brakewhistle = false
ignition = false
audioname = "Start"
local v2 = script.soundeffect
if level >= 0 and level <= 100 then
	v2.HighGain = level * -1 / 2
	v2.MidGain = level * -1 / 2
elseif level < 0 then
	v2.HighGain = -0
	v2.MidGain = -0
elseif level > 100 then
	v2.HighGain = -50
	v2.MidGain = -50
end
local v3 = v1:GetMouse()
local v_u_4 = script.Parent:WaitForChild("Car").Value
local v_u_5 = false
local _ = v_u_4.DriveSeat.SeatWeld.Part1
if setupmode == "Manual" then
	if soundplugin == "StockSound" then
		v3.KeyDown:connect(function(p6)
			-- upvalues: (ref) v_u_5, (copy) v_u_4
			if p6 == camkey and v_u_5 == false then
				v_u_5 = true
				local v7 = v_u_4.DriveSeat.Rev
				local v8 = script.soundeffect:Clone()
				v8.Name = "soundeffectCop"
				v8.Parent = v7
			elseif p6 == camkey and v_u_5 == true then
				v_u_5 = false
				v_u_4.DriveSeat.Rev.soundeffectCop:Destroy()
			end
		end)
		v_u_4.DriveSeat.ChildRemoved:Connect(function(p9)
			-- upvalues: (copy) v_u_4
			if p9.Name == "SeatWeld" then
				v_u_4.DriveSeat.Rev.soundeffectCop:Destroy()
			end
		end)
	elseif soundplugin == "SoundSuite" then
		v3.KeyDown:connect(function(p10)
			-- upvalues: (ref) v_u_5, (copy) v_u_4
			if p10 == camkey and v_u_5 == false then
				v_u_5 = true
				local v11 = v_u_4.Body.Exh:GetDescendants()
				for _, v12 in pairs(v11) do
					if v12:IsA("Sound") then
						local v13 = script.soundeffect:Clone()
						v13.Name = "soundeffectCop"
						v13.Parent = v12
					end
				end
			elseif p10 == camkey and v_u_5 == true then
				v_u_5 = false
				local v14 = v_u_4.Body.Exh:GetDescendants()
				for _, v15 in pairs(v14) do
					if v15:IsA("Sound") then
						v15.soundeffectCop:Destroy()
					end
				end
			end
		end)
		v_u_4.DriveSeat.ChildRemoved:Connect(function(p16)
			-- upvalues: (copy) v_u_4
			if p16.Name == "SeatWeld" then
				local v17 = v_u_4.Body.Exh:GetDescendants()
				for _, v18 in pairs(v17) do
					if v18:IsA("Sound") then
						v18.soundeffectCop:Destroy()
					end
				end
			end
		end)
	elseif soundplugin == "1.5 Sound" then
		v3.KeyDown:connect(function(p19)
			-- upvalues: (ref) v_u_5, (copy) v_u_4
			if p19 == camkey and v_u_5 == false then
				v_u_5 = true
				local v20 = v_u_4.Body.Engine:GetDescendants()
				for _, v21 in pairs(v20) do
					if v21:IsA("Sound") then
						local v22 = script.soundeffect:Clone()
						v22.Name = "soundeffectCop"
						v22.Parent = v21
					end
				end
				local v23 = v_u_4.Body.Exhaust:GetDescendants()
				for _, v24 in pairs(v23) do
					if v24:IsA("Sound") then
						local v25 = script.soundeffect:Clone()
						v25.Name = "soundeffectCop"
						v25.Parent = v24
					end
				end
			elseif p19 == camkey and v_u_5 == true then
				v_u_5 = false
				local v26 = v_u_4.Body.Engine:GetDescendants()
				for _, v27 in pairs(v26) do
					if v27:IsA("Sound") then
						v27.soundeffectCop:Destroy()
					end
				end
				local v28 = v_u_4.Body.Exhaust:GetDescendants()
				for _, v29 in pairs(v28) do
					if v29:IsA("Sound") then
						v29.soundeffectCop:Destroy()
					end
				end
			end
			v_u_4.DriveSeat.ChildRemoved:Connect(function(p30)
				-- upvalues: (ref) v_u_4
				if p30.Name == "SeatWeld" then
					local v31 = v_u_4.Body.Engine:GetDescendants()
					for _, v32 in pairs(v31) do
						if v32:IsA("Sound") then
							v32.soundeffectCop:Destroy()
						end
					end
					local v33 = v_u_4.Body.Exhaust:GetDescendants()
					for _, v34 in pairs(v33) do
						if v34:IsA("Sound") then
							v34.soundeffectCop:Destroy()
						end
					end
				end
			end)
		end)
	end
	if smoke == true then
		v3.KeyDown:connect(function(p35)
			-- upvalues: (ref) v_u_5, (copy) v_u_4
			if p35 == camkey and v_u_5 == false then
				local v36 = v_u_4.Wheels:GetChildren()
				for _, v37 in pairs(v36) do
					if v37:IsA("Part") then
						local v38 = script.soundeffect:Clone()
						v38.Name = "soundeffectCop"
						v38.Parent = v37.SQ
					end
				end
			elseif p35 == camkey and v_u_5 == true then
				local v39 = v_u_4.Wheels:GetChildren()
				for _, v40 in pairs(v39) do
					if v40:IsA("Part") then
						v40.SQ.soundeffectCop:Destroy()
					end
				end
			end
			v_u_4.DriveSeat.ChildRemoved:Connect(function(p41)
				-- upvalues: (ref) v_u_4
				if p41.Name == "SeatWeld" then
					local v42 = v_u_4.Wheels:GetChildren()
					for _, v43 in pairs(v42) do
						if v43:IsA("Part") then
							v43.SQ.soundeffectCop:Destroy()
						end
					end
				end
			end)
		end)
	end
	if backfire == true then
		v3.KeyDown:connect(function(p44)
			-- upvalues: (ref) v_u_5, (copy) v_u_4
			if p44 == camkey and v_u_5 == false then
				local v45 = v_u_4.Body.Exhaust:GetChildren()
				for _, v46 in pairs(v45) do
					if v46.Name == "Backfire1" or v46.Name == "Backfire2" then
						local v47 = script.soundeffect:Clone()
						local v48 = script.soundeffect:Clone()
						v47.Name = "soundeffectCop"
						v48.Name = "soundeffectCop"
						v47.Parent = v46.Backfire1
						v48.Parent = v46.Backfire2
					end
				end
			elseif p44 == camkey and v_u_5 == true then
				local v49 = v_u_4.Body.Exhaust:GetChildren()
				for _, v50 in pairs(v49) do
					if v50.Name == "Backfire1" or v50.Name == "Backfire2" then
						v50.Backfire1.soundeffectCop:Destroy()
						v50.Backfire2.soundeffectCop:Destroy()
					end
				end
			end
			v_u_4.DriveSeat.ChildRemoved:Connect(function(p51)
				-- upvalues: (ref) v_u_4
				if p51.Name == "SeatWeld" then
					local v52 = v_u_4.Body.Exhaust:GetDescendants()
					for _, v53 in pairs(v52) do
						if v53.Name == "soundeffectCop" then
							v53:Destroy()
						end
					end
				end
			end)
		end)
	end
	if horn == true then
		v3.KeyDown:connect(function(p54)
			-- upvalues: (ref) v_u_5, (copy) v_u_4
			if p54 == camkey and v_u_5 == false then
				local v55 = v_u_4.DriveSeat
				local v56 = script.soundeffect:Clone()
				v56.Name = "soundeffectCop"
				v56.Parent = v55.Horn
			elseif p54 == camkey and v_u_5 == true then
				v_u_4.DriveSeat.Horn.soundeffectCop:Destroy()
			end
			v_u_4.DriveSeat.ChildRemoved:Connect(function(p57)
				-- upvalues: (ref) v_u_4
				if p57.Name == "SeatWeld" then
					v_u_4.DriveSeat.Horn.soundeffectCop:Destroy()
				end
			end)
		end)
	end
	if brakewhistle == true then
		v3.KeyDown:connect(function(p58)
			-- upvalues: (ref) v_u_5, (copy) v_u_4
			if p58 == camkey and v_u_5 == false then
				local v59 = v_u_4.DriveSeat
				local v60 = script.soundeffect:Clone()
				v60.Name = "soundeffectCop"
				v60.Parent = v59.Brakes
			elseif p58 == camkey and v_u_5 == true then
				v_u_4.DriveSeat.Brakes.soundeffectCop:Destroy()
			end
			v_u_4.DriveSeat.ChildRemoved:Connect(function(p61)
				-- upvalues: (ref) v_u_4
				if p61.Name == "SeatWeld" then
					v_u_4.DriveSeat.Brakes.soundeffectCop:Destroy()
				end
			end)
		end)
	end
	if ignition == true then
		v3.KeyDown:connect(function(p62)
			-- upvalues: (ref) v_u_5, (copy) v_u_4
			if p62 == camkey and v_u_5 == false then
				local v63 = v_u_4.DriveSeat
				local v64 = script.soundeffect:Clone()
				v64.Name = "soundeffectCop"
				v64.Parent = v63[audioname]
			elseif p62 == camkey and v_u_5 == true then
				v_u_4.DriveSeat[audioname].soundeffectCop:Destroy()
			end
			v_u_4.DriveSeat.ChildRemoved:Connect(function(p65)
				-- upvalues: (ref) v_u_4
				if p65.Name == "SeatWeld" then
					v_u_4.DriveSeat[audioname].soundeffectCop:Destroy()
				end
			end)
		end)
	end
elseif setupmode == "Auto" then
	v3.KeyDown:connect(function(p66)
		-- upvalues: (ref) v_u_5, (copy) v_u_4
		if p66 == camkey and v_u_5 == false then
			v_u_5 = true
			local v67 = v_u_4:GetDescendants()
			for _, v68 in pairs(v67) do
				if v68:IsA("Sound") then
					local v69 = script.soundeffect:Clone()
					v69.Name = "soundeffectCop"
					v69.Parent = v68
					for _, v70 in pairs(exceptions) do
						if v68.Name == v70 then
							v68.soundeffectCop:Destroy()
						end
					end
				end
			end
		elseif p66 == camkey and v_u_5 == true then
			v_u_5 = false
			local v71 = v_u_4:GetDescendants()
			for _, v72 in pairs(v71) do
				if v72:IsA("EqualizerSoundEffect") and v72.Name == "soundeffectCop" then
					v72:Destroy()
					v_u_4.DriveSeat.ChildRemoved:Connect(function(p73)
						-- upvalues: (ref) v_u_4
						if p73.Name == "SeatWeld" then
							local v74 = v_u_4:GetDescendants()
							for _, v75 in pairs(v74) do
								if v75:IsA("EqualizerSoundEffect") and v75.Name == "soundeffect" then
									v75:Destroy()
								end
							end
						end
					end)
				end
			end
		end
	end)
end