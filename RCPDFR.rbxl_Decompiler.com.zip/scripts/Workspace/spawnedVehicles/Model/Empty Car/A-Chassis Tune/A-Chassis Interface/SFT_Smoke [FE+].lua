-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	["MaxRate"] = 30,
	["SkidVolume"] = 6
}
local v2 = game.Workspace.FilteringEnabled
local v3 = script.Parent.Car.Value
local v4 = v3:WaitForChild("Smoke_FE")
if v1.MaxRate > 80 then
	print("Softa\'s Smoke Plugin ERROR: MaxRate isn\'t set right, it is recommended to check the settings.")
	v1.MaxRate = 80
elseif v1.MaxRate < 0 then
	print("Softa\'s Smoke Plugin ERROR: MaxRate isn\'t set right, it is recommended to check the settings.")
	v1.MaxRate = 0
end
if v1.SkidVolume < 0 then
	print("Softa\'s Smoke Plugin ERROR: SkidVolume isn\'t set right, it is recommended to check the settings.")
	v1.SkidVolume = 0
elseif v1.SkidVolume > 10 then
	print("Softa\'s Smoke Plugin ERROR: SkidVolume isn\'t set right, it is recommended to check the settings.")
	v1.SkidVolume = 10
end
v1.SkidVolume = 10 - v1.SkidVolume + v1.SkidVolume / 20
v1.SkidVolume = v1.SkidVolume * 10
while wait(0.25) do
	local v5 = Ray.new(v3.Wheels.RL.Position, (v3.Wheels.RL.Arm.CFrame * CFrame.Angles(-1.5707963267948966, 0, 0)).lookVector * (0.05 + v3.Wheels.RL.Size.x / 2))
	local v6 = Ray.new(v3.Wheels.RL.Position, (v3.Wheels.RR.Arm.CFrame * CFrame.Angles(-1.5707963267948966, 0, 0)).lookVector * (0.05 + v3.Wheels.RR.Size.x / 2))
	local v7 = workspace:FindPartOnRay(v5, v3) == nil and 0 or 1
	local v8 = workspace:FindPartOnRay(v6, v3) ~= nil and 1 or 0
	local v9 = v3.Wheels.RL.RotVelocity.Magnitude * v3.Wheels.RL.Size.x / 2 - v3.Wheels.RL.Velocity.Magnitude
	local v10 = math.abs(v9) - 25
	local v11 = math.max(v10, 0)
	local v12 = v1.MaxRate
	local v13 = math.min(v11, v12) * v7
	local v14 = v3.Wheels.RR.RotVelocity.Magnitude * v3.Wheels.RR.Size.x / 2 - v3.Wheels.RR.Velocity.Magnitude
	local v15 = math.abs(v14) - 25
	local v16 = math.max(v15, 0)
	local v17 = v1.MaxRate
	local v18 = math.min(v16, v17) * v8
	if v2 then
		v4:FireServer("smokeUpdate", v13 / 2, v18 / 2, v1.SkidVolume * 1.25)
		v3.Wheels.RL.Smoke.Rate = v13
		v3.Wheels.RR.Smoke.Rate = v18
		v3.Wheels.RL.SkidSound.Volume = v13 / v1.SkidVolume
		v3.Wheels.RR.SkidSound.Volume = v18 / v1.SkidVolume
	else
		v3.Wheels.RL.Smoke.Rate = v13 / 1.5
		v3.Wheels.RR.Smoke.Rate = v18 / 1.5
		v3.Wheels.RL.SkidSound.Volume = v13 / v1.SkidVolume / 1.5
		v3.Wheels.RR.SkidSound.Volume = v18 / v1.SkidVolume / 1.5
	end
end