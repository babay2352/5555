-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = script.Parent.Car.Value
local v_u_2 = require(v_u_1:WaitForChild("A-Chassis Tune"))
local v_u_3 = require(v_u_1["A-Chassis Tune"].Units)
local v_u_4 = v_u_2.FSusStiffness
local v_u_5 = v_u_2.FSusDamping
local v_u_6 = v_u_2.FSusStiffness + 2.4
local v_u_7 = v_u_2.FSusDamping + 500
local v_u_8 = v_u_2.RSusStiffness
local v_u_9 = v_u_2.RSusDamping
local v_u_10 = v_u_2.RSusStiffness + 2.4
local v_u_11 = v_u_2.RSusDamping + 500
local function v_u_17()
	-- upvalues: (copy) v_u_1, (copy) v_u_4, (copy) v_u_6, (copy) v_u_2, (copy) v_u_3, (copy) v_u_5, (copy) v_u_7, (copy) v_u_8, (copy) v_u_10, (copy) v_u_9, (copy) v_u_11
	local v12 = next
	local v13, v14 = v_u_1.Wheels:GetChildren()
	for _, v15 in v12, v13, v14 do
		local v16 = v15:FindFirstChild("SuspensionGeometry") and v15.SuspensionGeometry:FindFirstChild("Spring") or v15:FindFirstChild("Spring")
		if v16 then
			if string.find(v15.Name, "F") then
				v16.Stiffness = (v_u_4 + (v_u_6 - v_u_4) * ((v_u_2.FSusLength - v16.CurrentLength) / v_u_2.FCompressLim)) * 9806.65 * v_u_3.Stiffness_Ndivm
				v16.Damping = (v_u_5 + (v_u_7 - v_u_5) * ((v_u_2.FSusLength - v16.CurrentLength) / v_u_2.FCompressLim)) * v_u_3.Damping_N_sdivm
			else
				v16.Stiffness = (v_u_8 + (v_u_10 - v_u_8) * ((v_u_2.RSusLength - v16.CurrentLength) / v_u_2.RCompressLim)) * 9806.65 * v_u_3.Stiffness_Ndivm
				v16.Damping = (v_u_9 + (v_u_11 - v_u_9) * ((v_u_2.RSusLength - v16.CurrentLength) / v_u_2.RCompressLim)) * v_u_3.Damping_N_sdivm
			end
		end
	end
end
game:GetService("RunService").Heartbeat:Connect(function(_)
	-- upvalues: (copy) v_u_17
	v_u_17()
end)