-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = script.Parent.Values
local v_u_2 = script.Parent.Car.Value
local v3 = game.Players.LocalPlayer
local v4 = require(v_u_2["A-Chassis Tune"].Units)
local v5 = game:GetService("RunService")
local v_u_6 = v_u_2.Body["#Weight"]
local v_u_7 = 1
local v_u_8 = v4.Length_mm / 1000 * 3.6
local v_u_9 = 9.81 * v4.Force_N
v_u_1:WaitForChild("DriveReady")
local v_u_10 = v_u_6:FindFirstChild("WindSound") or Instance.new("Sound", v_u_6)
v_u_10.Name = "WindSound"
v_u_10.RollOffMaxDistance = 30
v_u_10.RollOffMinDistance = 10
v_u_10.Looped = true
v_u_10.SoundId = "rbxassetid://188608071"
local v11 = v_u_10:FindFirstChild("EQ") or Instance.new("EqualizerSoundEffect", v_u_10)
v11.Name = "EQ"
v11.HighGain = -20
v11.LowGain = 10
v11.MidGain = -10
local v_u_12 = v_u_6:FindFirstChild("BodySound") or Instance.new("Sound", v_u_6)
v_u_12.Name = "BodySound"
v_u_12.RollOffMaxDistance = 30
v_u_12.RollOffMinDistance = 10
v_u_12.Looped = true
v_u_12.SoundId = "rbxassetid://4471836491"
v_u_10:Play()
v_u_12:Play()
local v_u_13 = RaycastParams.new()
v_u_13.FilterDescendantsInstances = { v_u_2, v3.Character }
v_u_13.FilterType = Enum.RaycastFilterType.Exclude
local v_u_14 = RaycastParams.new()
v_u_14.FilterDescendantsInstances = {}
v_u_14.FilterType = Enum.RaycastFilterType.Exclude
v5.Heartbeat:Connect(function(p15)
	-- upvalues: (copy) v_u_6, (copy) v_u_13, (ref) v_u_7, (copy) v_u_14, (copy) v_u_2, (copy) v_u_1, (copy) v_u_8, (copy) v_u_9, (copy) v_u_10, (copy) v_u_12
	local v16 = workspace:Raycast(v_u_6.Position, v_u_6.CFrame.LookVector * 1000, v_u_13)
	v_u_7 = 1
	if v16 then
		v_u_14.FilterDescendantsInstances = v16.Instance:GetConnectedParts()
		local v17 = workspace:Raycast(v16.Position, -v16.Instance.Velocity * 0.48, v_u_14)
		if v17 and v17.Instance:IsDescendantOf(v_u_2) then
			v_u_7 = 0.62 + v17.Distance / (v16.Instance.Velocity * 0.48).Magnitude * 0.38
		end
	end
	local v18 = (v_u_1.Velocity.Value - workspace.GlobalWind).Magnitude * v_u_8
	local v19 = -(v18 ^ 2 / 40000) * 375 * v_u_7
	local v20 = -(v18 ^ 2 / 40000) * 390 * v_u_7
	local v21 = 5 * v_u_1.Throttle.Value
	local v22 = v18 ^ 2 * 0.0044
	v_u_6:ApplyImpulseAtPosition(v_u_6.CFrame.UpVector * p15 * v19 * v_u_9, (v_u_6.CFrame * CFrame.new(0, 0, -v_u_6.Size.Z / 2)).Position)
	v_u_6:ApplyImpulseAtPosition(v_u_6.CFrame.UpVector * p15 * (v20 + v21) * v_u_9, (v_u_6.CFrame * CFrame.new(0, 0, v_u_6.Size.Z / 2)).Position)
	v_u_6:ApplyImpulseAtPosition(v_u_6.CFrame.LookVector * p15 * v22 * v_u_9, v_u_6.Position)
	v_u_6:SetAttribute("DownforceF", v19)
	v_u_6:SetAttribute("DownforceR", v20)
	v_u_6:SetAttribute("BlownDiffuserR", v21)
	v_u_6:SetAttribute("DragForce", v22)
	v_u_10.Volume = v18 ^ 2 * 0.45 / 40000
	v_u_12.Volume = v18 ^ 2 * 0 / 40000
end)