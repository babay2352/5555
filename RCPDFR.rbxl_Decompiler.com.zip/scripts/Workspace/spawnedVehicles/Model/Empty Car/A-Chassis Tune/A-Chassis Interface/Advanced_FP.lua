-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = Enum.KeyCode.U
local v_u_2 = game:GetService("RunService")
local v3 = game:GetService("UserInputService")
game.Players.LocalPlayer:GetMouse()
local v4 = script.Parent.Car.Value
local v_u_5 = script.Parent.Values
local v_u_6 = v4.Body.DashCam
local v_u_7 = workspace.CurrentCamera
local v_u_8 = v_u_7.FieldOfView
local v_u_9 = CFrame.new
local v_u_10 = CFrame.Angles
local v_u_11 = math.rad
local v_u_12 = math.clamp
local v_u_13 = string.sub
local v_u_14 = {}
local v_u_15 = 0
local v_u_16 = false
for _, v17 in ipairs(v4.Wheels:GetChildren()) do
	for _, v18 in ipairs(v17:GetDescendants()) do
		if v18:IsA("SpringConstraint") then
			v_u_14[v17.Name] = v18
		end
	end
end
local v_u_19 = 0
local v_u_20 = v_u_9(0, 0, 0)
local function v_u_40()
	-- upvalues: (copy) v_u_14, (copy) v_u_13, (copy) v_u_12, (copy) v_u_9, (ref) v_u_20, (ref) v_u_19, (copy) v_u_10, (copy) v_u_11, (ref) v_u_15, (copy) v_u_7, (copy) v_u_6, (copy) v_u_8, (copy) v_u_5
	local v21 = {
		["Front"] = {},
		["Rear"] = {},
		["Left"] = {},
		["Right"] = {}
	}
	for v22, v23 in pairs(v_u_14) do
		local v24 = v_u_13(v22, 1, 1)
		local v25 = v_u_13(v22, 2, 2)
		local v26 = (v23.CurrentLength - v23.FreeLength) / (v23.MaxLength - v23.MinLength) / 2
		local v27 = v24 == "F" and "Front" or (v24 == "R" and "Rear" or nil)
		local v28 = v21[v27]
		table.insert(v28, v26)
		local v29 = v21[v25 == "L" and "Left" or (v25 == "R" and "Right" or v27)]
		table.insert(v29, v26)
	end
	for v30, v31 in pairs(v21) do
		local v32 = 0
		for _, v33 in ipairs(v31) do
			v32 = v32 + v33
		end
		v21[v30] = v_u_12(v32 / #v31, -1, 1)
	end
	local v34 = {
		["FR"] = v21.Front - v21.Rear,
		["LR"] = v21.Left - v21.Right,
		["All"] = (v21.Front + v21.Rear + v21.Left + v21.Right) / 4
	}
	local v35 = v_u_9(v34.LR * 0.5, v34.All * 0.1, v34.FR * 1)
	local v36 = 10 * v34.LR
	local v37 = v_u_9(0.5 * v35.X + 0.5 * v_u_20.X, 0.5 * v35.Y + 0.5 * v_u_20.Y, 0.5 * v35.Z + 0.5 * v_u_20.Z)
	local v38 = 0.5 * v36 + v_u_19 * 0.5
	v_u_19 = v36
	v_u_20 = v35
	local v39 = v37 * v_u_10(v_u_11(0), v_u_11(v_u_15), (v_u_11(v38)))
	v_u_7.CFrame = v_u_6.CFrame:ToWorldSpace(v39)
	v_u_7.FieldOfView = v_u_8 + v_u_5.Velocity.Value.Magnitude / 30 * 1
end
v3.InputBegan:Connect(function(p41, p42)
	-- upvalues: (copy) v_u_1, (ref) v_u_16, (copy) v_u_7, (copy) v_u_2, (copy) v_u_40, (copy) v_u_8
	if not p42 and p41.KeyCode == v_u_1 then
		v_u_16 = not v_u_16
		if v_u_16 == true then
			v_u_7.CameraType = Enum.CameraType.Scriptable
			v_u_2:BindToRenderStep("AdvCam", Enum.RenderPriority.Camera.Value, v_u_40)
			return
		end
		v_u_2:UnbindFromRenderStep("AdvCam")
		v_u_7.CameraType = Enum.CameraType.Custom
		v_u_7.FieldOfView = v_u_8
	end
end)
v3.InputEnded:Connect(function(p43, p44)
	-- upvalues: (ref) v_u_16, (ref) v_u_15
	if not p44 and v_u_16 == true then
		local _ = p43.KeyCode
		v_u_15 = 0
	end
end)
v4.DriveSeat.ChildRemoved:Connect(function(p45)
	-- upvalues: (copy) v_u_2, (copy) v_u_7, (copy) v_u_8
	if p45.Name == "SeatWeld" then
		v_u_2:UnbindFromRenderStep("AdvCam")
		v_u_7.CameraType = Enum.CameraType.Custom
		v_u_7.FieldOfView = v_u_8
	end
end)