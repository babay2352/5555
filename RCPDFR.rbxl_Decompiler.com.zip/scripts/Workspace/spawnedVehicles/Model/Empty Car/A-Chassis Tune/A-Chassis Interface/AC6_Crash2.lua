-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = script.Parent:WaitForChild("Car").Value
while wait() do
	if v1.Body.Engine.Smoke.Enabled == true then
		script.Parent:WaitForChild("IsOn").Value = false
		if v1.Body.Engine.Fire.Enabled == true then
			script.Parent:WaitForChild("IsOn").Value = false
		end
	end
end