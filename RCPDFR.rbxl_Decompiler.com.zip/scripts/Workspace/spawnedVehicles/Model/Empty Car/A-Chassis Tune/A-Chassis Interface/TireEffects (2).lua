-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {
	Enum.Material.Slate,
	Enum.Material.Concrete,
	Enum.Material.Basalt,
	Enum.Material.Brick,
	Enum.Material.Cobblestone,
	Enum.Material.Rock,
	Enum.Material.Concrete,
	Enum.Material.Pavement,
	Enum.Material.Wood,
	Enum.Material.Salt,
	Enum.Material.Marble,
	Enum.Material.Plastic,
	Enum.Material.SmoothPlastic,
	Enum.Material.Metal,
	Enum.Material.DiamondPlate,
	Enum.Material.CorrodedMetal,
	Enum.Material.Asphalt
}
local v2 = { Enum.Material.Mud, Enum.Material.Ground }
local v3 = { Enum.Material.Grass, Enum.Material.LeafyGrass, Enum.Material.Fabric }
local v4 = { Enum.Material.Pebble }
local v5 = { Enum.Material.Sand, Enum.Material.Sandstone, Enum.Material.Limestone }
local v6 = { Enum.Material.Snow }
local v_u_7 = script.Parent.Car.Value
require(v_u_7["A-Chassis Tune"])
script.Parent:WaitForChild("Values")
local v8 = v_u_7:WaitForChild("EffectHandler")
local v_u_9 = game:GetService("HapticService")
local v_u_10 = game:GetService("UserInputService")
local v11 = {}
for _, v12 in pairs(v_u_7.Wheels:GetChildren()) do
	local v13 = {
		["wheel"] = v12,
		["stress"] = 0,
		["sq_vol"] = 0,
		["sq_ps"] = 0,
		["gs_vol"] = 0,
		["gs_ps"] = 0,
		["gs_eq"] = 0,
		["sn_vol"] = 0,
		["sn_ps"] = 0,
		["sn_eq"] = 0,
		["smoke_rate"] = 0,
		["dirt_rate"] = 0,
		["grass_rate"] = 0,
		["gravel_rate"] = 0,
		["autumn_rate"] = 0,
		["gravel_color"] = ColorSequence.new(Color3.fromRGB(31, 31, 31)),
		["sand_rate"] = 0,
		["sand_color"] = ColorSequence.new(Color3.fromRGB(143, 126, 95)),
		["snow_rate"] = 0
	}
	table.insert(v11, v13)
end
local v_u_14 = false
local v_u_15 = false
local v_u_16 = false
v_u_7.Wheels.FL:WaitForChild("SQ")
local v17 = v_u_7.Wheels.FL.Size.Y / 2 + 0.1
local function v_u_21(p18, p19)
	-- upvalues: (copy) v_u_10, (copy) v_u_9
	if p18 and p19 then
		local v20 = v_u_10:GetLastInputType()
		if v20.Name:find("Gamepad") and (v_u_9:IsVibrationSupported(v20) and v_u_9:IsMotorSupported(v20, p18) == true) then
			v_u_9:SetMotor(v20, p18, p19)
		end
	end
end
local v22 = v_u_7:WaitForChild("Body")
local v_u_23 = v_u_7:WaitForChild("Misc")
local v_u_24 = false
if v_u_10.GamepadConnected then
	for _, v_u_25 in pairs(v22:GetChildren()) do
		if v_u_25.Name:find("Sensor") then
			v_u_25.Touched:connect(function(p26)
				-- upvalues: (copy) v_u_10, (copy) v_u_23, (ref) v_u_24, (copy) v_u_25, (copy) v_u_21
				if v_u_10:GetLastInputType().Name:find("Gamepad") and (v_u_23.E.Value == true and (not v_u_24 and p26:IsA("BasePart"))) then
					if p26.Parent:FindFirstChildOfClass("Humanoid") then
						local v27 = (p26.Velocity - v_u_25.Velocity).Magnitude
						if math.abs(v27) >= 30 and not v_u_24 then
							v_u_24 = true
							v_u_21(Enum.VibrationMotor.Large, 0.5)
							spawn(function()
								-- upvalues: (ref) v_u_21, (ref) v_u_24
								wait(0.5)
								v_u_21(Enum.VibrationMotor.Large, 0)
								v_u_24 = false
							end)
							return
						end
					else
						local v28 = (p26.Velocity - v_u_25.Velocity).Magnitude
						if math.abs(v28) >= 20 and (p26.CanCollide and not v_u_24) then
							v_u_24 = true
							v_u_21(Enum.VibrationMotor.Large, 1)
							spawn(function()
								-- upvalues: (ref) v_u_21, (ref) v_u_24
								wait(0.5)
								v_u_21(Enum.VibrationMotor.Large, 0)
								v_u_24 = false
							end)
						end
					end
				end
			end)
		end
	end
end
local v_u_29 = {}
function LocalUpdate(p30, _, p31, p32, p33, p34, p35, p36, p37, p38)
	-- upvalues: (copy) v_u_10, (ref) v_u_14, (ref) v_u_15, (copy) v_u_7, (ref) v_u_16, (copy) v_u_21, (ref) v_u_29
	local v39 = v_u_10:GetLastInputType()
	if p33 then
		if p30.stress > 0.6 then
			v_u_14 = true
			p30.sq_vol = (p30.stress - 0.1) * 3
			p30.sq_ps = p30.stress + 0.15
			p30.smoke_rate = p30.stress * 20
		else
			p30.sq_vol = p30.stress - 0.1
			p30.sq_ps = p30.stress + 0.15
			p30.smoke_rate = 0
			v_u_14 = false
		end
	else
		v_u_14 = false
		p30.sq_vol = 0
		p30.sq_ps = 0
		p30.smoke_rate = 0
	end
	if p34 then
		v_u_15 = true
		if v_u_7.DriveSeat.Velocity.Magnitude >= 30 then
			p30.dirt_rate = p30.stress * 10 + v_u_7.DriveSeat.Velocity.Magnitude / 10
		else
			p30.dirt_rate = p30.stress * 10
		end
		local v40 = v_u_7.DriveSeat.Velocity.Magnitude <= 0.9 and 0 or 1
		local v41 = p30.stress * 2 + v_u_7.DriveSeat.Velocity.Magnitude / 80 + v40 * 0.5
		local v42 = math.min(v41, 2.1)
		p30.gs_ps = v42 * 0.6
		p30.gs_vol = v42 * 3 * 0.4
		p30.gs_eq = 1 - v42 / 4 * 0.6
	else
		p30.dirt_rate = 0
		if not (p34 or (p35 or (p36 or p37))) then
			p30.gs_vol = 0
			v_u_15 = false
		end
	end
	if p35 then
		v_u_15 = true
		if v_u_7.DriveSeat.Velocity.Magnitude >= 30 then
			p30.gravel_rate = p30.stress * 10 + v_u_7.DriveSeat.Velocity.Magnitude / 10
		else
			p30.gravel_rate = p30.stress * 10
		end
		if p32 == "AutumnGroundLeaves" then
			p30.autumn_rate = p30.gravel_rate
		end
		p30.gravel_color = ColorSequence.new(p31)
		local v43 = v_u_7.DriveSeat.Velocity.Magnitude <= 0.9 and 0 or 1
		local v44 = p30.stress * 2 + v_u_7.DriveSeat.Velocity.Magnitude / 80 + v43 * 0.5
		local v45 = math.min(v44, 2.1)
		p30.gs_ps = v45 * 0.6
		p30.gs_vol = v45 * 3 * 0.4
		p30.gs_eq = 1 - v45 / 4 * 0.6
	else
		p30.gravel_rate = 0
		p30.autumn_rate = 0
		if not (p34 or (p35 or (p36 or p37))) then
			p30.gs_vol = 0
			v_u_15 = false
		end
	end
	if p36 then
		p30.grass_rate = p30.stress * 10
		local v46 = v_u_7.DriveSeat.Velocity.Magnitude <= 0.9 and 0 or 1
		local v47 = p30.stress * 2 + v_u_7.DriveSeat.Velocity.Magnitude / 80 + v46 * 0.5
		local v48 = math.min(v47, 2.1)
		p30.gs_ps = v48 * 0.6
		p30.gs_vol = v48 * 3 * 0.4
		p30.gs_eq = 1 - v48 / 4 * 0.6
	else
		p30.grass_rate = 0
		if not (p34 or (p35 or (p36 or p37))) then
			p30.gs_vol = 0
		end
	end
	if p37 then
		v_u_15 = true
		if v_u_7.DriveSeat.Velocity.Magnitude >= 30 then
			p30.sand_rate = p30.stress * 10 + v_u_7.DriveSeat.Velocity.Magnitude / 10
		else
			p30.sand_rate = p30.stress * 10
		end
		if p32 == "Terrain" then
			p30.sand_color = ColorSequence.new(Color3.fromRGB(143, 126, 95))
		else
			p30.sand_color = ColorSequence.new(p31)
		end
		local v49 = v_u_7.DriveSeat.Velocity.Magnitude <= 0.9 and 0 or 1
		local v50 = p30.stress * 2 + v_u_7.DriveSeat.Velocity.Magnitude / 80 + v49 * 0.5
		local v51 = math.min(v50, 2.1)
		p30.gs_ps = v51 * 0.6
		p30.gs_vol = v51 * 3 * 0.4
		p30.gs_eq = 1 - v51 / 4 * 0.6
	else
		p30.sand_rate = 0
		if not (p34 or (p35 or (p36 or p37))) then
			p30.gs_vol = 0
			v_u_15 = false
		end
	end
	if p38 then
		v_u_16 = true
		if v_u_7.DriveSeat.Velocity.Magnitude >= 30 then
			p30.snow_rate = p30.stress * 10 + v_u_7.DriveSeat.Velocity.Magnitude / 10
		else
			p30.snow_rate = p30.stress * 10
		end
		local v52 = v_u_7.DriveSeat.Velocity.Magnitude <= 0.9 and 0 or 1
		local v53 = p30.stress * 2 + v_u_7.DriveSeat.Velocity.Magnitude / 80 + v52 * 0.5
		local v54 = math.min(v53, 2.1)
		p30.sn_ps = v54 * 0.6
		p30.sn_vol = v54 * 3 * 0.4
		p30.sn_eq = 1 - v54 / 4 * 0.6
	else
		p30.snow_rate = 0
		p30.sn_vol = 0
		v_u_16 = false
	end
	if p30.sq_vol >= 0 then
		if not p30.wheel.SQ.Playing then
			p30.wheel.SQ:Play()
		end
		p30.wheel.SQ.Volume = p30.sq_vol
	elseif p30.wheel.SQ.Playing then
		p30.wheel.SQ:Stop()
	end
	if p30.gs_vol >= 0 then
		if not p30.wheel.GravelSound.Playing then
			p30.wheel.GravelSound:Play()
		end
		p30.wheel.GravelSound.Volume = p30.gs_vol
	elseif p30.wheel.GravelSound.Playing then
		p30.wheel.GravelSound:Stop()
	end
	if p30.sn_vol >= 0 then
		if not p30.wheel.SnowSound.Playing then
			p30.wheel.SnowSound:Play()
		end
		p30.wheel.SnowSound.Volume = p30.sn_vol
	elseif p30.wheel.SnowSound.Playing then
		p30.wheel.SnowSound:Stop()
	end
	if v_u_14 and (not v_u_16 and (not v_u_15 and v39.Name:find("Gamepad"))) then
		local v55 = v_u_21
		local v56 = Enum.VibrationMotor.Small
		local v57 = p30.stress
		v55(v56, (math.min(1, v57)))
	end
	if v_u_15 and (not v_u_16 and (not v_u_14 and v39.Name:find("Gamepad"))) then
		local v58 = v_u_21
		local v59 = Enum.VibrationMotor.Small
		local v60 = p30.stress
		v58(v59, (math.min(0.5, v60)))
	end
	if v_u_16 and (not v_u_15 and (not v_u_14 and v39.Name:find("Gamepad"))) then
		local v61 = v_u_21
		local v62 = Enum.VibrationMotor.Small
		local v63 = p30.stress
		v61(v62, (math.min(0.3, v63)))
	end
	if p30.stress < 0.3 and not (v_u_15 or v_u_16) then
		v_u_21(Enum.VibrationMotor.Small, 0)
	end
	p30.wheel.SQ.PlaybackSpeed = p30.sq_ps
	p30.wheel.GravelSound.PlaybackSpeed = p30.gs_ps
	p30.wheel.GravelSound.PitchShiftSoundEffect.Octave = p30.gs_eq
	p30.wheel.SnowSound.PlaybackSpeed = p30.sn_ps
	p30.wheel.SnowSound.PitchShiftSoundEffect.Octave = p30.sn_eq
	p30.wheel.Smoke.Rate = p30.smoke_rate
	p30.wheel.Dirt.Rate = p30.dirt_rate
	p30.wheel.Grass.Rate = p30.grass_rate
	p30.wheel.Sand.Rate = p30.sand_rate
	p30.wheel.Sand.Color = p30.sand_color
	p30.wheel.Gravel.Rate = p30.gravel_rate
	p30.wheel.Gravel.Color = p30.gravel_color
	p30.wheel.Snow.Rate = p30.snow_rate
	p30.wheel.Autumn.Rate = p30.autumn_rate
	local v64 = v_u_29
	table.insert(v64, p30)
end
v_u_7.DriveSeat.ChildRemoved:connect(function(p65)
	-- upvalues: (copy) v_u_10, (copy) v_u_9, (copy) v_u_21
	if p65.Name == "SeatWeld" and game.Players:GetPlayerFromCharacter(p65.Part1.Parent) == game.Players.LocalPlayer then
		local v66 = v_u_10:GetLastInputType()
		if v66.Name:find("Gamepad") then
			local v67 = v_u_9:IsMotorSupported(v66, Enum.VibrationMotor.Small)
			local v68 = v_u_9:IsMotorSupported(v66, Enum.VibrationMotor.Large)
			if v67 then
				v_u_21(Enum.VibrationMotor.Small, 0)
			end
			if v68 then
				v_u_21(Enum.VibrationMotor.Large, 0)
			end
		end
	end
end)
local v69 = v_u_29
while wait() do
	for _, v70 in pairs(v11) do
		local v71 = false
		local v72 = false
		local v73 = false
		local v74 = false
		local v75 = false
		local v76 = false
		local v77 = v_u_7.DriveSeat.Velocity.Magnitude
		local v78 = v70.wheel.RotVelocity.Magnitude - v77 / 1.298 * (2.6 / v70.wheel.Size.Y)
		local v79 = math.abs(v78) / 15
		local v80 = math.abs(v79)
		if v80 > 0.05 and v70.stress < v80 then
			local v81 = v70.stress + 0.03
			v70.stress = math.min(v81, 1)
		else
			local v82 = v70.stress - 0.03
			v70.stress = math.max(v82, v80)
		end
		local v83 = Ray.new(v70.wheel.Position + Vector3.new(0, 5, 0), Vector3.new(0, -5, 0) * v17)
		local v84, v85
		if game.Workspace:FindFirstChild("PacificoSpeedwayGrassFixed") then
			local v86, v87
			v84, v86, v87, v85 = workspace:FindPartOnRayWithIgnoreList(v83, { v_u_7, game.Workspace.PacificoSpeedwayGrassFixed }, false, true)
		else
			local v88, v89
			v84, v88, v89, v85 = workspace:FindPartOnRay(v83, v_u_7, false, true)
		end
		local v90 = v85 or Enum.Material.Air
		if v84 ~= nil and v84.Name ~= "MountainBackground" then
			for _, v91 in pairs(v1) do
				if v90 == v91 then
					v71 = true
				end
			end
			for _, v92 in pairs(v2) do
				if v90 == v92 then
					v72 = true
				end
			end
			for _, v93 in pairs(v3) do
				if v90 == v93 then
					v74 = true
				end
			end
			for _, v94 in pairs(v4) do
				if v90 == v94 then
					v73 = true
				end
			end
			for _, v95 in pairs(v5) do
				if v90 == v95 then
					v75 = true
				end
			end
			for _, v96 in pairs(v6) do
				if v90 == v96 then
					v76 = true
				end
			end
		end
		if v84 then
			LocalUpdate(v70, v90, v84.Color, v84.Name, v71, v72, v74, v73, v75, v76)
		else
			LocalUpdate(v70, v90, BrickColor.Black(), "")
		end
	end
	v8:FireServer(v69)
	v_u_29 = {}
	v69 = v_u_29
end