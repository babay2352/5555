-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = Enum.KeyCode.V
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("UserInputService")
local v4 = game:GetService("Players")
local v5 = script.Parent.Car.Value
local v_u_6 = v4.LocalPlayer
local v_u_7 = workspace.CurrentCamera
local v_u_8 = v5.Body.CamLocation
local v_u_9 = {}
local v_u_10 = v_u_7.FieldOfView
local v_u_11 = false
local v_u_12 = false
local v_u_13 = v_u_8:FindFirstChild("DashcamON")
function handleInput(p14, p15)
	-- upvalues: (copy) v_u_1, (ref) v_u_12, (ref) v_u_11
	if not p15 and (p14.KeyCode == v_u_1 and not v_u_12) then
		v_u_12 = true
		v_u_11 = not v_u_11
		if v_u_11 then
			enableCam()
		else
			disableCam()
		end
		v_u_12 = false
	end
end
function enableCam()
	-- upvalues: (copy) v_u_7, (copy) v_u_2, (copy) v_u_6, (copy) v_u_9, (copy) v_u_13
	v_u_7.CameraType = Enum.CameraType.Scriptable
	v_u_2:BindToRenderStep("FirstPerson", Enum.RenderPriority.Camera.Value, updateCam)
	v_u_6.Character.Humanoid:UnequipTools()
	for _, v16 in ipairs(v_u_6.Character:GetDescendants()) do
		if v16:IsA("BasePart") then
			v_u_9[v16] = v16.Transparency
			v16.LocalTransparencyModifier = 1
		end
	end
	v_u_7.FieldOfView = 60
	local v17 = v_u_6.PlayerGui.AxonUI
	v17.Enabled = true
	v17.Client.Enabled = true
	if v_u_13 then
		v_u_13:Play()
	end
end
function disableCam()
	-- upvalues: (copy) v_u_2, (copy) v_u_7, (copy) v_u_10, (copy) v_u_6, (copy) v_u_9
	v_u_2:UnbindFromRenderStep("FirstPerson")
	v_u_7.CameraType = Enum.CameraType.Custom
	v_u_7.FieldOfView = v_u_10
	for _, v18 in ipairs(v_u_6.Character:GetDescendants()) do
		if v_u_9[v18] ~= nil then
			v18.LocalTransparencyModifier = v_u_9[v18]
		end
	end
	local v19 = v_u_6.PlayerGui.AxonUI
	v19.Enabled = false
	v19.Client.Enabled = false
end
function updateCam()
	-- upvalues: (copy) v_u_8, (copy) v_u_7, (copy) v_u_3
	local v20 = v_u_8
	local v21 = v_u_7.ViewportSize
	local v22 = v_u_3:GetMouseLocation()
	local v23 = v21 / 2 - v22
	local v24 = v20.CFrame
	local v25 = CFrame.Angles
	local v26 = 90 * v23.X / (v21.X / 2)
	v_u_7.CFrame = v24 * v25(0, math.rad(v26), 0)
end
for _, v27 in ipairs(v_u_6.Character:GetDescendants()) do
	if v27:IsA("BasePart") then
		v_u_9[v27] = v27.Transparency
	end
end
v5.DriveSeat.ChildRemoved:Connect(function(p28)
	if p28.Name == "SeatWeld" then
		disableCam()
	end
end)
v_u_3.InputBegan:Connect(handleInput)