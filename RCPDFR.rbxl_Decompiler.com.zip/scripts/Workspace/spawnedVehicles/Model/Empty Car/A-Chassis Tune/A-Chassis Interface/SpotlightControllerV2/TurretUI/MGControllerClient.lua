-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game.Players.LocalPlayer
local v2 = game:GetService("UserInputService")
local v3 = script.Parent.Vehicle.Value
local v4 = v1:GetMouse()
v4.TargetFilter = v3.Parent
parts = script.Parent.Vehicle.Value.Parent.Turret
function setTurretDirection(p5, p6)
	parts.MantletBase.MainGunWeld.C1 = CFrame.new(0, 0, 0) * CFrame.fromEulerAnglesXYZ(0, p5, 0)
	parts.TurretRing2.TurretRingWeld.C1 = CFrame.new(0, 0, 0) * CFrame.fromEulerAnglesXYZ(0, 0, p6)
end
function determineNewDirections(p7)
	local v8 = parts.TurretRing2
	local v9 = v8.CFrame.lookVector
	local v10 = v9:Dot(p7)
	local v11 = 1.5707963267948966 - math.acos(v10)
	local v12 = (p7 - v10 * v9).unit
	local v13 = ((v8.CFrame - v8.CFrame.p) * CFrame.new(0, -1, 0)).p
	local v14 = v13:Dot(v12)
	local v15 = math.acos(v14)
	if v13:Cross(v12):Dot(v9) < 0 then
		v15 = -v15
	end
	return { v11, v15 }
end
function sign(p16)
	return p16 < 0 and -1 or 1
end
function getSmoothRotation(p17)
	local v18 = p17[1]
	local v19 = p17[2]
	local v20 = v18 - currentElev
	if math.abs(v20) < 0.2 then
		currentElev = v18
	else
		currentElev = currentElev + 0.2 * sign(v20)
	end
	local v21 = v19 - currentRot
	if v21 > 3.141592653589793 then
		v21 = v21 - 6.283185307179586
	elseif v21 < -3.141592653589793 then
		v21 = v21 + 6.283185307179586
	end
	if math.abs(v21) < 0.2 then
		currentRot = v19
	else
		currentRot = currentRot + 0.2 * sign(v21)
	end
	return { v18, v19 }
end
currentElev = 0
currentRot = 0
lastpos = v2:GetMouseLocation()
while wait() do
	if v4 then
		mousePoint = v4.Hit.p
		targetVector = (mousePoint - parts.GunBase.CFrame.p).unit
		targetRotations = determineNewDirections(targetVector)
		newRotations = getSmoothRotation(targetRotations)
		setTurretDirection(currentElev, currentRot)
		wait()
	end
end