-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

script.Parent:WaitForChild("Car")
script.Parent:WaitForChild("IsOn")
script.Parent:WaitForChild("ControlsOpen")
script.Parent:WaitForChild("Values")
local v_u_1 = game.Players.LocalPlayer:GetMouse()
local v_u_2 = game:GetService("UserInputService")
game:GetService("GuiService")
local v_u_3 = game:GetService("TextChatService")
local v_u_4 = script.Parent.Car.Value
local v_u_5 = require(v_u_4["A-Chassis Tune"])
local v_u_6 = v_u_5.WeightScaling * 10
local v_u_7 = v_u_5.BrakeForce * v_u_5.BrakeBias
local v_u_8 = v_u_5.BrakeForce * (1 - v_u_5.BrakeBias)
local v_u_9 = v_u_5.PBrakeForce * v_u_5.PBrakeBias
local v_u_10 = v_u_5.PBrakeForce * (1 - v_u_5.PBrakeBias)
local v_u_11 = v_u_5.EBrakeForce
local v_u_12 = v_u_5.SteerOuter
local v_u_13 = v_u_5.SteerInner
local v_u_14 = v_u_5.RSteerOuter
local v_u_15 = v_u_5.RSteerInner
if not workspace:PGSIsEnabled() then
	error("PGS is not enabled: A-Chassis will not work.")
end
local v_u_16 = v_u_5.AutoStart
if v_u_5.AutoStart and (v_u_5.Engine or v_u_5.Electric) then
	script.Parent.IsOn.Value = true
end
local v_u_17 = v_u_5.IdleThrottle / 100
local v_u_18 = v_u_5.TransModes[1]
local v_u_19 = v_u_5.TCSEnabled
local v_u_20 = v_u_5.ABSEnabled
local v_u_21 = tick()
v_u_4.DriveSeat.ChildRemoved:connect(function(p22)
	if p22.Name == "SeatWeld" and p22:IsA("Weld") then
		script.Parent:Destroy()
	end
end)
local v_u_23 = v_u_5.Controls
local v24 = Instance.new("Folder", script.Parent)
v24.Name = "Controls"
local v_u_25 = false
local v_u_26 = 0
local v_u_27 = 0
local v_u_28 = 0
local v_u_29 = false
local v_u_30 = false
local v_u_31 = false
local v_u_32 = false
local v_u_33 = false
local v_u_34 = false
local v_u_35 = false
local v_u_36 = false
local v_u_37 = 0
local v_u_38 = false
local v_u_39 = 0
local v_u_40 = 0
local v_u_41 = 0
local v_u_42 = 0
local v_u_43 = 0
local v_u_44 = 0
local v_u_45 = 0
local v_u_46 = 0
local v_u_47 = 0
local v_u_48 = 0
local v_u_49 = 0
local v_u_50 = 0
local v_u_51 = 0
local v_u_52 = false
local v_u_53 = 0
local v_u_54 = 0
local v_u_55 = 0
local v_u_56 = 0
local v_u_57 = false
local v_u_58 = 0
local v_u_59 = 0
local v_u_60 = 0
local v_u_61 = false
local v_u_62 = 0
local v_u_63 = 0
local v_u_64 = 0
local v_u_65 = 0
for v_u_66, v67 in pairs(v_u_23) do
	local v_u_68 = Instance.new("StringValue", v24)
	v_u_68.Name = v_u_66
	v_u_68.Value = v67.Name
	v_u_68.Changed:connect(function()
		-- upvalues: (copy) v_u_66, (copy) v_u_68, (copy) v_u_23
		if v_u_66 == "MouseThrottle" or v_u_66 == "MouseBrake" then
			if v_u_68.Value == "MouseButton1" or v_u_68.Value == "MouseButton2" then
				v_u_23[v_u_66] = Enum.UserInputType[v_u_68.Value]
			else
				v_u_23[v_u_66] = Enum.KeyCode[v_u_68.Value]
			end
		else
			v_u_23[v_u_66] = Enum.KeyCode[v_u_68.Value]
			return
		end
	end)
end
local v_u_69 = v_u_5.Peripherals
for v_u_70, v71 in pairs(v_u_69) do
	local v_u_72 = Instance.new("IntValue", v24)
	v_u_72.Name = v_u_70
	v_u_72.Value = v71
	v_u_72.Changed:connect(function()
		-- upvalues: (copy) v_u_72, (copy) v_u_69, (copy) v_u_70
		local v73 = v_u_72
		local v74 = v_u_72.Value
		local v75 = math.max(0, v74)
		v73.Value = math.min(100, v75)
		v_u_69[v_u_70] = v_u_72.Value
	end)
end
function DealWithInput(p76, _)
	-- upvalues: (ref) v_u_36, (copy) v_u_3, (copy) v_u_2, (copy) v_u_23, (ref) v_u_25, (ref) v_u_16, (ref) v_u_18, (ref) v_u_26, (copy) v_u_5, (ref) v_u_31, (ref) v_u_32, (ref) v_u_33, (ref) v_u_34, (ref) v_u_35, (copy) v_u_4, (ref) v_u_17, (ref) v_u_27, (ref) v_u_28, (ref) v_u_29, (ref) v_u_30, (ref) v_u_19, (ref) v_u_20
	if v_u_36 or (v_u_3.ChatInputBarConfiguration.IsFocused or v_u_2:GetFocusedTextBox() ~= nil) then
		v_u_17 = v_u_5.IdleThrottle / 100
		v_u_28 = 0
		v_u_27 = 0
	else
		if (p76.KeyCode == v_u_23.ContlrShiftDown or v_u_25 and p76.KeyCode == v_u_23.MouseShiftDown or not v_u_25 and p76.KeyCode == v_u_23.ShiftDown) and ((v_u_16 and (v_u_18 == "Auto" and (v_u_26 <= 1 and v_u_5.AutoShiftVers == "New")) or (v_u_18 == "Semi" or v_u_18 == "Manual")) and p76.UserInputState == Enum.UserInputState.Begin) then
			if not v_u_31 then
				v_u_31 = true
			end
		elseif (p76.KeyCode == v_u_23.ContlrShiftUp or v_u_25 and p76.KeyCode == v_u_23.MouseShiftUp or not v_u_25 and p76.KeyCode == v_u_23.ShiftUp) and ((v_u_16 and (v_u_18 == "Auto" and (v_u_26 < 1 and v_u_5.AutoShiftVers == "New")) or (v_u_18 == "Semi" or v_u_18 == "Manual")) and p76.UserInputState == Enum.UserInputState.Begin) then
			if not v_u_32 then
				v_u_32 = true
			end
		elseif (p76.KeyCode == v_u_23.ContlrClutch or v_u_25 and p76.KeyCode == v_u_23.MouseClutch or not v_u_25 and p76.KeyCode == v_u_23.Clutch) and v_u_18 == "Manual" then
			if p76.UserInputState == Enum.UserInputState.Begin then
				v_u_33 = true
				v_u_34 = true
			elseif p76.UserInputState == Enum.UserInputState.End then
				v_u_33 = false
				v_u_34 = false
			end
		elseif p76.KeyCode == v_u_23.ContlrPBrake or v_u_25 and p76.KeyCode == v_u_23.MousePBrake or not v_u_25 and p76.KeyCode == v_u_23.PBrake then
			if p76.UserInputState == Enum.UserInputState.Begin then
				v_u_35 = not v_u_35
			elseif p76.UserInputState == Enum.UserInputState.End and v_u_4.DriveSeat.Velocity.Magnitude > 5 then
				v_u_35 = false
			end
		elseif (p76.KeyCode == v_u_23.ContlrToggleTMode or p76.KeyCode == v_u_23.ToggleTransMode) and p76.UserInputState == Enum.UserInputState.Begin then
			local v77 = 1
			for v78, v79 in pairs(v_u_5.TransModes) do
				if v79 == v_u_18 then
					v77 = v78
					break
				end
			end
			local v80 = v77 + 1
			local v81 = #v_u_5.TransModes < v80 and 1 or v80
			v_u_18 = v_u_5.TransModes[v81]
		elseif (v_u_25 or p76.KeyCode ~= v_u_23.Throttle and p76.KeyCode ~= v_u_23.Throttle2) and ((v_u_23.MouseThrottle ~= Enum.UserInputType.MouseButton1 and v_u_23.MouseThrottle ~= Enum.UserInputType.MouseButton2 or p76.UserInputType ~= v_u_23.MouseThrottle) and p76.KeyCode ~= v_u_23.MouseThrottle or not v_u_25) then
			if (v_u_25 or p76.KeyCode ~= v_u_23.Brake and p76.KeyCode ~= v_u_23.Brake2) and ((v_u_23.MouseBrake ~= Enum.UserInputType.MouseButton1 and v_u_23.MouseBrake ~= Enum.UserInputType.MouseButton2 or p76.UserInputType ~= v_u_23.MouseBrake) and p76.KeyCode ~= v_u_23.MouseBrake or not v_u_25) then
				if v_u_25 or p76.KeyCode ~= v_u_23.SteerLeft and p76.KeyCode ~= v_u_23.SteerLeft2 then
					if v_u_25 or p76.KeyCode ~= v_u_23.SteerRight and p76.KeyCode ~= v_u_23.SteerRight2 then
						if p76.KeyCode == v_u_23.ToggleMouseDrive then
							if p76.UserInputState == Enum.UserInputState.End then
								v_u_25 = not v_u_25
								v_u_17 = v_u_5.IdleThrottle / 100
								v_u_27 = 0
								v_u_28 = 0
							end
						elseif v_u_5.TCSEnabled and (v_u_16 and p76.KeyCode == v_u_23.ToggleTCS) or p76.KeyCode == v_u_23.ContlrToggleTCS then
							if p76.UserInputState == Enum.UserInputState.End then
								v_u_19 = not v_u_19
							end
						elseif (v_u_5.ABSEnabled and (v_u_16 and p76.KeyCode == v_u_23.ToggleABS) or p76.KeyCode == v_u_23.ContlrToggleABS) and p76.UserInputState == Enum.UserInputState.End then
							v_u_20 = not v_u_20
						end
					elseif p76.UserInputState == Enum.UserInputState.Begin then
						v_u_28 = 1
						v_u_30 = true
					else
						if v_u_29 then
							v_u_28 = -1
						else
							v_u_28 = 0
						end
						v_u_30 = false
					end
				elseif p76.UserInputState == Enum.UserInputState.Begin then
					v_u_28 = -1
					v_u_29 = true
				else
					if v_u_30 then
						v_u_28 = 1
					else
						v_u_28 = 0
					end
					v_u_29 = false
				end
			elseif p76.UserInputState == Enum.UserInputState.Begin then
				v_u_27 = 1
			else
				v_u_27 = 0
			end
		elseif p76.UserInputState == Enum.UserInputState.Begin and v_u_16 then
			v_u_17 = 1
		else
			v_u_17 = v_u_5.IdleThrottle / 100
		end
		if p76.UserInputType.Name:find("Gamepad") then
			if p76.KeyCode == v_u_23.ContlrSteer then
				if p76.Position.X >= 0 then
					local v82 = v_u_5.Peripherals.ControlRDZone / 100
					local v83 = math.min(0.99, v82)
					local v84 = p76.Position.X
					if v83 < math.abs(v84) then
						v_u_28 = (p76.Position.X - v83) / (1 - v83)
					else
						v_u_28 = 0
					end
				else
					local v85 = v_u_5.Peripherals.ControlLDZone / 100
					local v86 = math.min(0.99, v85)
					local v87 = p76.Position.X
					if v86 < math.abs(v87) then
						v_u_28 = (p76.Position.X + v86) / (1 - v86)
					else
						v_u_28 = 0
					end
				end
			end
			if p76.KeyCode == v_u_23.ContlrThrottle then
				if v_u_16 then
					local v88 = v_u_5.IdleThrottle / 100
					local v89 = p76.Position.Z
					v_u_17 = math.max(v88, v89)
				else
					v_u_17 = v_u_5.IdleThrottle / 100
				end
			end
			if p76.KeyCode == v_u_23.ContlrBrake then
				v_u_27 = p76.Position.Z
				return
			end
		end
	end
end
v_u_2.InputBegan:connect(DealWithInput)
v_u_2.InputChanged:connect(DealWithInput)
v_u_2.InputEnded:connect(DealWithInput)
local v_u_90 = {}
if v_u_5.Config == "FWD" or v_u_5.Config == "AWD" then
	for _, v91 in pairs(v_u_4.Wheels:GetChildren()) do
		if v91.Name == "FL" or (v91.Name == "FR" or v91.Name == "F") then
			table.insert(v_u_90, v91)
		end
	end
end
if v_u_5.Config == "RWD" or v_u_5.Config == "AWD" then
	for _, v92 in pairs(v_u_4.Wheels:GetChildren()) do
		if v92.Name == "RL" or (v92.Name == "RR" or v92.Name == "R") then
			table.insert(v_u_90, v92)
		end
	end
end
local v93 = 0
for _, v94 in pairs(v_u_90) do
	if v93 < v94.Size.x then
		v93 = v94.Size.x
	end
end
for _, v95 in pairs(v_u_4.Wheels:GetChildren()) do
	local v96 = v95["#BV"].MotorMaxTorque - v_u_9
	if math.abs(v96) < 1 then
		::l38::
		local v97 = true
		v_u_35 = v97
	else
		local v98 = v95["#BV"].MotorMaxTorque - v_u_10
		if math.abs(v98) < 1 then
			goto l38
		end
	end
end
function Inputs(p99)
	-- upvalues: (ref) v_u_53, (ref) v_u_17, (copy) v_u_5, (ref) v_u_54, (ref) v_u_27
	local v100 = 60 / (1 / p99)
	if v_u_53 <= v_u_17 then
		local v101 = v_u_17
		local v102 = v_u_53 + v_u_5.ThrotAccel * v100
		v_u_53 = math.min(v101, v102)
	else
		local v103 = v_u_17
		local v104 = v_u_53 - v_u_5.ThrotDecel * v100
		v_u_53 = math.max(v103, v104)
	end
	if v_u_54 <= v_u_27 then
		local v105 = v_u_27
		local v106 = v_u_54 + v_u_5.BrakeAccel * v100
		v_u_54 = math.min(v105, v106)
	else
		local v107 = v_u_27
		local v108 = v_u_54 - v_u_5.BrakeDecel * v100
		v_u_54 = math.max(v107, v108)
	end
end
if v_u_5.SteeringType == "New" then
	v_u_12 = v_u_5.LockToLock * 180 / v_u_5.SteerRatio
	local v109 = v_u_12 - v_u_12 * (1 - v_u_5.Ackerman)
	local v110 = v_u_12 * 1.2
	v_u_13 = math.min(v109, v110)
end
function Steering(p111)
	-- upvalues: (ref) v_u_25, (copy) v_u_1, (copy) v_u_5, (ref) v_u_28, (ref) v_u_49, (copy) v_u_4, (ref) v_u_12, (ref) v_u_13, (copy) v_u_15, (copy) v_u_14
	local v112 = 60 / (1 / p111)
	if v_u_25 then
		local v113 = v_u_1.ViewSizeX * v_u_5.Peripherals.MSteerWidth / 200
		local v114 = math.max(1, v113)
		local v115 = v_u_5.Peripherals.MSteerDZone / 100
		local v116 = (v_u_1.X - v_u_1.ViewSizeX / 2) / v114
		if math.abs(v116) <= v115 then
			v_u_28 = 0
		else
			local v117 = math.abs(v116) - v115
			local v118 = 1 - v115
			local v119 = math.min(v117, v118)
			v_u_28 = (math.max(v119, 0) / (1 - v115)) ^ v_u_5.MSteerExp * (v116 / math.abs(v116))
		end
	end
	if v_u_49 < v_u_28 then
		if v_u_49 < 0 then
			local v120 = v_u_28
			local v121 = v_u_49 + v_u_5.ReturnSpeed * v112
			v_u_49 = math.min(v120, v121)
		else
			local v122 = v_u_28
			local v123 = v_u_49 + v_u_5.SteerSpeed * v112
			v_u_49 = math.min(v122, v123)
		end
	elseif v_u_49 > 0 then
		local v124 = v_u_28
		local v125 = v_u_49 - v_u_5.ReturnSpeed * v112
		v_u_49 = math.max(v124, v125)
	else
		local v126 = v_u_28
		local v127 = v_u_49 - v_u_5.SteerSpeed * v112
		v_u_49 = math.max(v126, v127)
	end
	local v128 = v_u_4.DriveSeat.Velocity.Magnitude / v_u_5.SteerDecay
	local v129 = 1 - v_u_5.MinSteer / 100
	local v130 = 1 - math.min(v128, v129)
	local v131 = v_u_4.DriveSeat.Velocity.Magnitude / v_u_5.RSteerDecay
	local v132 = 1 - v_u_5.MinSteer / 100
	local v133 = 1 - math.min(v131, v132)
	for _, v134 in pairs(v_u_4.Wheels:GetChildren()) do
		if v134.Name == "F" then
			local v135 = v134.Arm.Steer
			local v136 = v_u_4.Wheels.F.Base.CFrame
			local v137 = CFrame.Angles
			local v138 = v_u_49 * v_u_5.SteerInner * v130
			v135.CFrame = v136 * v137(0, -math.rad(v138), 0)
		elseif v134.Name == "FL" then
			if v_u_49 >= 0 then
				local v139 = v134.Arm.Steer
				local v140 = v_u_4.Wheels.FL.Base.CFrame
				local v141 = CFrame.Angles
				local v142 = v_u_49 * v_u_12 * v130
				v139.CFrame = v140 * v141(0, -math.rad(v142), 0)
			else
				local v143 = v134.Arm.Steer
				local v144 = v_u_4.Wheels.FL.Base.CFrame
				local v145 = CFrame.Angles
				local v146 = v_u_49 * v_u_13 * v130
				v143.CFrame = v144 * v145(0, -math.rad(v146), 0)
			end
		elseif v134.Name == "FR" then
			if v_u_49 >= 0 then
				local v147 = v134.Arm.Steer
				local v148 = v_u_4.Wheels.FR.Base.CFrame
				local v149 = CFrame.Angles
				local v150 = v_u_49 * v_u_13 * v130
				v147.CFrame = v148 * v149(0, -math.rad(v150), 0)
			else
				local v151 = v134.Arm.Steer
				local v152 = v_u_4.Wheels.FR.Base.CFrame
				local v153 = CFrame.Angles
				local v154 = v_u_49 * v_u_12 * v130
				v151.CFrame = v152 * v153(0, -math.rad(v154), 0)
			end
		elseif v134.Name == "R" then
			if v_u_5.FWSteer ~= "None" then
				if v_u_5.FWSteer == "Static" then
					local v155 = v134.Arm.Steer
					local v156 = v_u_4.Wheels.R.Base.CFrame
					local v157 = CFrame.Angles
					local v158 = v_u_49 * v_u_15 * v133
					local v159 = 1 - v_u_4.DriveSeat.Velocity.Magnitude / v_u_5.RSteerSpeed
					local v160 = v158 * math.max(0, v159)
					v155.CFrame = v156 * v157(0, math.rad(v160), 0)
				elseif v_u_5.FWSteer == "Speed" then
					local v161 = v134.Arm.Steer
					local v162 = v_u_4.Wheels.R.Base.CFrame
					local v163 = CFrame.Angles
					local v164 = v_u_49 * v_u_15 * v133
					local v165 = v_u_4.DriveSeat.Velocity.Magnitude / v_u_5.RSteerSpeed
					local v166 = v164 * math.min(1, v165)
					v161.CFrame = v162 * v163(0, -math.rad(v166), 0)
				elseif v_u_5.FWSteer == "Both" then
					local v167 = v134.Arm.Steer
					local v168 = v_u_4.Wheels.R.Base.CFrame
					local v169 = CFrame.Angles
					local v170 = v_u_49 * v_u_15 * v133
					local v171 = 1 - v_u_4.DriveSeat.Velocity.Magnitude / v_u_5.RSteerSpeed
					local v172 = v170 * math.max(-1, v171)
					v167.CFrame = v168 * v169(0, math.rad(v172), 0)
				end
			end
		elseif v134.Name == "RL" then
			if v_u_5.FWSteer ~= "None" then
				if v_u_5.FWSteer == "Static" then
					if v_u_49 >= 0 then
						local v173 = v134.Arm.Steer
						local v174 = v_u_4.Wheels.RL.Base.CFrame
						local v175 = CFrame.Angles
						local v176 = v_u_49 * v_u_14 * v133
						local v177 = 1 - v_u_4.DriveSeat.Velocity.Magnitude / v_u_5.RSteerSpeed
						local v178 = v176 * math.max(0, v177)
						v173.CFrame = v174 * v175(0, math.rad(v178), 0)
					else
						local v179 = v134.Arm.Steer
						local v180 = v_u_4.Wheels.RL.Base.CFrame
						local v181 = CFrame.Angles
						local v182 = v_u_49 * v_u_15 * v133
						local v183 = 1 - v_u_4.DriveSeat.Velocity.Magnitude / v_u_5.RSteerSpeed
						local v184 = v182 * math.max(0, v183)
						v179.CFrame = v180 * v181(0, math.rad(v184), 0)
					end
				elseif v_u_5.FWSteer == "Speed" then
					if v_u_49 >= 0 then
						local v185 = v134.Arm.Steer
						local v186 = v_u_4.Wheels.RL.Base.CFrame
						local v187 = CFrame.Angles
						local v188 = v_u_49 * v_u_14 * v133
						local v189 = v_u_4.DriveSeat.Velocity.Magnitude / v_u_5.RSteerSpeed
						local v190 = v188 * math.min(1, v189)
						v185.CFrame = v186 * v187(0, -math.rad(v190), 0)
					else
						local v191 = v134.Arm.Steer
						local v192 = v_u_4.Wheels.RL.Base.CFrame
						local v193 = CFrame.Angles
						local v194 = v_u_49 * v_u_15 * v133
						local v195 = v_u_4.DriveSeat.Velocity.Magnitude / v_u_5.RSteerSpeed
						local v196 = v194 * math.min(1, v195)
						v191.CFrame = v192 * v193(0, -math.rad(v196), 0)
					end
				elseif v_u_5.FWSteer == "Both" then
					if v_u_49 >= 0 then
						local v197 = v134.Arm.Steer
						local v198 = v_u_4.Wheels.RL.Base.CFrame
						local v199 = CFrame.Angles
						local v200 = v_u_49 * v_u_14 * v133
						local v201 = 1 - v_u_4.DriveSeat.Velocity.Magnitude / v_u_5.RSteerSpeed
						local v202 = v200 * math.max(-1, v201)
						v197.CFrame = v198 * v199(0, math.rad(v202), 0)
					else
						local v203 = v134.Arm.Steer
						local v204 = v_u_4.Wheels.RL.Base.CFrame
						local v205 = CFrame.Angles
						local v206 = v_u_49 * v_u_15 * v133
						local v207 = 1 - v_u_4.DriveSeat.Velocity.Magnitude / v_u_5.RSteerSpeed
						local v208 = v206 * math.max(-1, v207)
						v203.CFrame = v204 * v205(0, math.rad(v208), 0)
					end
				end
			end
		elseif v134.Name == "RR" then
			if v_u_5.FWSteer ~= "None" then
				if v_u_5.FWSteer == "Static" then
					if v_u_49 >= 0 then
						local v209 = v134.Arm.Steer
						local v210 = v_u_4.Wheels.RR.Base.CFrame
						local v211 = CFrame.Angles
						local v212 = v_u_49 * v_u_15 * v133
						local v213 = 1 - v_u_4.DriveSeat.Velocity.Magnitude / v_u_5.RSteerSpeed
						local v214 = v212 * math.max(0, v213)
						v209.CFrame = v210 * v211(0, math.rad(v214), 0)
					else
						local v215 = v134.Arm.Steer
						local v216 = v_u_4.Wheels.RR.Base.CFrame
						local v217 = CFrame.Angles
						local v218 = v_u_49 * v_u_14 * v133
						local v219 = 1 - v_u_4.DriveSeat.Velocity.Magnitude / v_u_5.RSteerSpeed
						local v220 = v218 * math.max(0, v219)
						v215.CFrame = v216 * v217(0, math.rad(v220), 0)
					end
				elseif v_u_5.FWSteer == "Speed" then
					if v_u_49 >= 0 then
						local v221 = v134.Arm.Steer
						local v222 = v_u_4.Wheels.RR.Base.CFrame
						local v223 = CFrame.Angles
						local v224 = v_u_49 * v_u_15 * v133
						local v225 = v_u_4.DriveSeat.Velocity.Magnitude / v_u_5.RSteerSpeed
						local v226 = v224 * math.min(1, v225)
						v221.CFrame = v222 * v223(0, -math.rad(v226), 0)
					else
						local v227 = v134.Arm.Steer
						local v228 = v_u_4.Wheels.RR.Base.CFrame
						local v229 = CFrame.Angles
						local v230 = v_u_49 * v_u_14 * v133
						local v231 = v_u_4.DriveSeat.Velocity.Magnitude / v_u_5.RSteerSpeed
						local v232 = v230 * math.min(1, v231)
						v227.CFrame = v228 * v229(0, -math.rad(v232), 0)
					end
				elseif v_u_5.FWSteer == "Both" then
					if v_u_49 >= 0 then
						local v233 = v134.Arm.Steer
						local v234 = v_u_4.Wheels.RR.Base.CFrame
						local v235 = CFrame.Angles
						local v236 = v_u_49 * v_u_15 * v133
						local v237 = 1 - v_u_4.DriveSeat.Velocity.Magnitude / v_u_5.RSteerSpeed
						local v238 = v236 * math.max(-1, v237)
						v233.CFrame = v234 * v235(0, math.rad(v238), 0)
					else
						local v239 = v134.Arm.Steer
						local v240 = v_u_4.Wheels.RR.Base.CFrame
						local v241 = CFrame.Angles
						local v242 = v_u_49 * v_u_14 * v133
						local v243 = 1 - v_u_4.DriveSeat.Velocity.Magnitude / v_u_5.RSteerSpeed
						local v244 = v242 * math.max(-1, v243)
						v239.CFrame = v240 * v241(0, math.rad(v244), 0)
					end
				end
			end
		end
	end
end
local v_u_245 = v_u_5.FinalDrive * v_u_5.FDMult
local v_u_246 = v_u_245 * 30 / 3.141592653589793
local v_u_247 = workspace.Gravity * v_u_5.InclineComp / 32.2
local v_u_248 = v93 * 3.141592653589793 / 60
local v_u_249 = CFrame.Angles(1.5707963267948966, -1.5707963267948966, 0)
local v_u_250 = CFrame.Angles(0, 3.141592653589793, 0)
if not v_u_5.Engine and v_u_5.Electric then
	v_u_5.Redline = v_u_5.E_Redline
	v_u_5.PeakRPM = v_u_5.E_Trans2
	v_u_5.Turbochargers = 0
	v_u_5.Superchargers = 0
	v_u_5.Clutch = false
	v_u_5.IdleRPM = 0
	v_u_5.ClutchType = "Clutch"
	v_u_5.AutoShiftType = "DCT"
	v_u_5.ShiftUpTime = 0.1
	v_u_5.ShiftDnTime = 0.1
end
local v_u_251 = v_u_5.Turbochargers
local v_u_252 = v_u_5.T_Boost * v_u_5.Turbochargers
local v_u_253 = v_u_5.Superchargers
local v_u_254 = v_u_5.S_Boost * v_u_5.Superchargers
local v_u_255 = v_u_5.Horsepower / 100
local v_u_256 = v_u_5.Horsepower * (v_u_252 * (v_u_5.T_Efficiency / 10)) / 7.5 / 2 / 100
local v_u_257 = v_u_5.Horsepower * (v_u_254 * (v_u_5.S_Efficiency / 10)) / 7.5 / 2 / 100
local v_u_258 = v_u_5.PeakRPM / 1000
local v_u_259 = v_u_5.PeakSharpness
local v_u_260 = v_u_5.CurveMult
local v_u_261 = v_u_5.EqPoint / 1000
function CurveN(p262)
	-- upvalues: (copy) v_u_258, (copy) v_u_255, (copy) v_u_260, (copy) v_u_259
	local v263 = p262 / 1000
	local v264 = -(v263 - v_u_258) ^ 2
	local v265 = v_u_255 / v_u_258 ^ 2
	local v266 = v_u_260 ^ (v_u_258 / v_u_255)
	return (v264 * math.min(v265, v266) + v_u_255) * (v263 - v263 ^ v_u_259 / (v_u_259 * v_u_258 ^ (v_u_259 - 1)))
end
local v_u_267 = CurveN(v_u_5.PeakRPM)
function CurveT(p268)
	-- upvalues: (copy) v_u_258, (copy) v_u_256, (copy) v_u_260, (copy) v_u_259
	local v269 = p268 / 1000
	local v270 = -(v269 - v_u_258) ^ 2
	local v271 = v_u_256 / v_u_258 ^ 2
	local v272 = v_u_260 ^ (v_u_258 / v_u_256)
	return (v270 * math.min(v271, v272) + v_u_256) * (v269 - v269 ^ v_u_259 / (v_u_259 * v_u_258 ^ (v_u_259 - 1)))
end
local v_u_273 = CurveT(v_u_5.PeakRPM)
function CurveS(p274)
	-- upvalues: (copy) v_u_258, (copy) v_u_257, (copy) v_u_260, (copy) v_u_259
	local v275 = p274 / 1000
	local v276 = -(v275 - v_u_258) ^ 2
	local v277 = v_u_257 / v_u_258 ^ 2
	local v278 = v_u_260 ^ (v_u_258 / v_u_257)
	return (v276 * math.min(v277, v278) + v_u_257) * (v275 - v275 ^ v_u_259 / (v_u_259 * v_u_258 ^ (v_u_259 - 1)))
end
local v_u_279 = CurveS(v_u_5.PeakRPM)
local v_u_280 = v_u_5.E_Horsepower / 100
local v_u_281 = v_u_5.E_Torque / 100
local v_u_282 = v_u_5.E_Trans1 / 1000
local v_u_283 = v_u_5.E_Trans2 / 1000
local v_u_284 = v_u_5.E_Redline / 1000
function elecHP(p285)
	-- upvalues: (copy) v_u_282, (copy) v_u_5, (copy) v_u_280, (copy) v_u_283, (copy) v_u_284
	local v286 = p285 / 1000
	local v287 = 1e-9
	if v286 <= v_u_282 then
		return (v286 / v_u_282) ^ v_u_5.EH_FrontMult / (1 / v_u_280) * (v286 / v_u_282) + (v286 / v_u_282) ^ (1 / v_u_5.EH_FrontMult) / (1 / v_u_280) * (1 - v286 / v_u_282)
	end
	if v_u_282 < v286 and v286 < v_u_283 then
		return v_u_280
	end
	if v_u_283 <= v286 then
		return v_u_280 - ((v286 - v_u_283) / (v_u_284 - v_u_283)) ^ v_u_5.EH_EndMult / (1 / (v_u_280 * (v_u_5.EH_EndPercent / 100)))
	end
	error("\n\t [AC6C]: Drive initialization failed!" .. "\n\t    An unknown error occured when initializing electric horsepower." .. "\n\t    Please send a screenshot of this message to Avxnturador." .. "\n\t    R: " .. v286 .. ", T1: " .. v_u_282(", T2: ") .. v_u_283(", L: ") .. v_u_284("."))
	return v287
end
function elecTQ(p288)
	-- upvalues: (copy) v_u_282, (copy) v_u_281, (copy) v_u_284, (copy) v_u_5, (copy) v_u_283
	local v289 = p288 / 1000
	local v290 = 1e-9
	if v289 < v_u_282 then
		return v_u_281
	end
	if v_u_282 <= v289 then
		return v_u_281 - ((v289 - v_u_282) / (v_u_284 - v_u_282)) ^ v_u_5.ET_EndMult / (1 / (v_u_281 * (v_u_5.ET_EndPercent / 100)))
	end
	error("\n\t [AC6C]: Drive initialization failed!" .. "\n\t    An unknown error occured when initializing electric torque." .. "\n\t    Please send a screenshot of this message to Avxnturador." .. "\n\t    R: " .. v289 .. ", T1: " .. v_u_282(", T2: ") .. v_u_283(", L: ") .. v_u_284("."))
	return v290
end
function GetNCurve(p291, p292)
	-- upvalues: (copy) v_u_267, (copy) v_u_255, (copy) v_u_261, (copy) v_u_5, (copy) v_u_245, (copy) v_u_6
	local v293 = CurveN(p291) / (v_u_267 / v_u_255)
	local v294 = math.max(v293, 0) * 100
	return v294, v294 * (v_u_261 / p291) * v_u_5.Ratios[p292 + 2] * v_u_245 * v_u_6 * 1000
end
function GetECurve(p295, p296)
	-- upvalues: (copy) v_u_5, (copy) v_u_245, (copy) v_u_6
	local v297 = elecHP(p295)
	local v298 = math.max(v297, 0) * 100
	local v299 = elecTQ(p295)
	local v300 = math.max(v299, 0) * 100
	if p296 == 0 then
		return 0, 0
	end
	local v301 = v300 * v_u_5.Ratios[p296 + 2] * v_u_245 * v_u_6
	return v298, math.max(v301, 0)
end
function GetTCurve(p302, p303)
	-- upvalues: (copy) v_u_273, (copy) v_u_256, (copy) v_u_261, (copy) v_u_5, (copy) v_u_245, (copy) v_u_6
	local v304 = CurveT(p302) / (v_u_273 / v_u_256)
	local v305 = math.max(v304, 0) * 100
	return v305, v305 * (v_u_261 / p302) * v_u_5.Ratios[p303 + 2] * v_u_245 * v_u_6 * 1000
end
function GetSCurve(p306, p307)
	-- upvalues: (copy) v_u_279, (copy) v_u_257, (copy) v_u_261, (copy) v_u_5, (copy) v_u_245, (copy) v_u_6
	local v308 = CurveS(p306) / (v_u_279 / v_u_257)
	local v309 = math.max(v308, 0) * 100
	return v309, v309 * (v_u_261 / p306) * v_u_5.Ratios[p307 + 2] * v_u_245 * v_u_6 * 1000
end
local v_u_310 = {}
local v_u_311 = {}
local v_u_312 = {}
local v_u_313 = {}
for v314, _ in pairs(v_u_5.Ratios) do
	local v315 = (v_u_5.Redline + 100) / 100
	local v316 = {}
	local v317 = {}
	local v318 = {}
	local v319 = {}
	for v320 = 0, math.ceil(v315) do
		local v321 = {}
		local v322 = {}
		local v323 = {}
		local v324 = {}
		if v320 == 0 then
			v321.Horsepower = 0
			v321.Torque = 0
			v322.Horsepower = 0
			v322.Torque = 0
			v323.Horsepower = 0
			v323.Torque = 0
			v324.Horsepower = 0
			v324.Torque = 0
		else
			if v_u_5.Engine then
				local v325, v326 = GetNCurve(v320 * 100, v314 - 2)
				v321.Horsepower = v325
				v321.Torque = v326
				if v_u_251 == 0 then
					v323.Horsepower = 0
					v323.Torque = 0
				else
					local v327, v328 = GetTCurve(v320 * 100, v314 - 2)
					v323.Horsepower = v327
					v323.Torque = v328
				end
				if v_u_253 == 0 then
					v324.Horsepower = 0
					v324.Torque = 0
				else
					local v329, v330 = GetSCurve(v320 * 100, v314 - 2)
					v324.Horsepower = v329
					v324.Torque = v330
				end
			else
				v321.Horsepower = 0
				v321.Torque = 0
				v323.Horsepower = 0
				v323.Torque = 0
				v324.Horsepower = 0
				v324.Torque = 0
			end
			if v_u_5.Electric then
				local v331, v332 = GetECurve(v320 * 100, v314 - 2)
				v322.Horsepower = v331
				v322.Torque = v332
			else
				v322.Horsepower = 0
				v322.Torque = 0
			end
		end
		if v_u_5.Engine then
			local v333, v334 = GetNCurve((v320 + 1) * 100, v314 - 2)
			nhp = v333
			ntq = v334
			if v_u_251 == 0 then
				thp = 0
				ttq = 0
			else
				local v335, v336 = GetTCurve((v320 + 1) * 100, v314 - 2)
				thp = v335
				ttq = v336
			end
			if v_u_253 == 0 then
				shp = 0
				stq = 0
			else
				local v337, v338 = GetSCurve((v320 + 1) * 100, v314 - 2)
				shp = v337
				stq = v338
			end
		else
			nhp = 0
			ntq = 0
			thp = 0
			ttq = 0
			shp = 0
			stq = 0
		end
		if v_u_5.Electric then
			local v339, v340 = GetECurve((v320 + 1) * 100, v314 - 2)
			ehp = v339
			etq = v340
		else
			ehp = 0
			etq = 0
		end
		local v341 = nhp - v321.Horsepower
		local v342 = ntq - v321.Torque
		v321.HpSlope = v341
		v321.TqSlope = v342
		local v343 = ehp - v322.Horsepower
		local v344 = etq - v322.Torque
		v322.HpSlope = v343
		v322.TqSlope = v344
		local v345 = thp - v323.Horsepower
		local v346 = ttq - v323.Torque
		v323.HpSlope = v345
		v323.TqSlope = v346
		local v347 = shp - v324.Horsepower
		local v348 = stq - v324.Torque
		v324.HpSlope = v347
		v324.TqSlope = v348
		v316[v320] = v321
		v317[v320] = v322
		v318[v320] = v323
		v319[v320] = v324
	end
	table.insert(v_u_310, v316)
	table.insert(v_u_311, v317)
	table.insert(v_u_312, v318)
	table.insert(v_u_313, v319)
end
wait()
function Auto()
	-- upvalues: (copy) v_u_90, (ref) v_u_16, (copy) v_u_5, (ref) v_u_26, (ref) v_u_33, (ref) v_u_54, (copy) v_u_4, (ref) v_u_62, (ref) v_u_32, (ref) v_u_38, (copy) v_u_246, (ref) v_u_31, (copy) v_u_248, (copy) v_u_245, (ref) v_u_53
	local v349 = 0
	for _, v350 in pairs(v_u_90) do
		if v349 < v350.RotVelocity.Magnitude then
			v349 = v350.RotVelocity.Magnitude
		end
	end
	if v_u_16 then
		if v_u_5.AutoShiftVers == "Old" and v_u_26 == 0 then
			v_u_26 = 1
			v_u_33 = false
		end
		if v_u_26 >= 1 then
			if v_u_26 == 1 and (v_u_54 > 0 and (v_u_4.DriveSeat.Velocity.Magnitude < 5 and v_u_5.AutoShiftVers == "Old")) then
				v_u_26 = -1
				v_u_33 = false
				return
			end
			if v_u_4.DriveSeat.Velocity.Magnitude > 5 then
				if v_u_5.AutoShiftMode == "RPM" then
					if v_u_62 > v_u_5.PeakRPM + v_u_5.AutoUpThresh then
						if not (v_u_32 or v_u_38) then
							v_u_32 = true
							return
						end
					else
						local v351 = v349 * v_u_5.Ratios[v_u_26 + 1] * v_u_246
						local v352 = v_u_5.Redline + 100
						local v353 = math.min(v351, v352)
						local v354 = v_u_5.IdleRPM
						if math.max(v353, v354) < v_u_5.PeakRPM - v_u_5.AutoDownThresh and (v_u_26 > 1 and not (v_u_31 or v_u_38)) then
							v_u_31 = true
							return
						end
					end
				else
					local v355 = v_u_4.DriveSeat.Velocity.Magnitude
					local v356 = v_u_248 * (v_u_5.PeakRPM + v_u_5.AutoUpThresh) / v_u_5.Ratios[v_u_26 + 2] / v_u_245
					if math.ceil(v356) < v355 then
						if not (v_u_32 or v_u_38) then
							v_u_32 = true
							return
						end
					else
						local v357 = v_u_4.DriveSeat.Velocity.Magnitude
						local v358 = v_u_248 * (v_u_5.PeakRPM - v_u_5.AutoDownThresh) / v_u_5.Ratios[v_u_26 + 1] / v_u_245
						if v357 < math.ceil(v358) and (v_u_26 > 1 and not (v_u_31 or v_u_38)) then
							v_u_31 = true
							return
						end
					end
				end
			end
		elseif v_u_53 - v_u_5.IdleThrottle / 100 > 0 and (v_u_4.DriveSeat.Velocity.Magnitude < 5 and v_u_5.AutoShiftVers == "Old") then
			v_u_26 = 1
			v_u_33 = false
		end
	end
end
function Gear()
	-- upvalues: (copy) v_u_90, (ref) v_u_32, (ref) v_u_38, (ref) v_u_18, (ref) v_u_33, (copy) v_u_5, (ref) v_u_53, (ref) v_u_26, (ref) v_u_16, (ref) v_u_62, (copy) v_u_246, (ref) v_u_31
	local v359 = 0
	for _, v360 in pairs(v_u_90) do
		if v359 < v360.RotVelocity.Magnitude then
			v359 = v360.RotVelocity.Magnitude
		end
	end
	if v_u_32 and not v_u_38 then
		if v_u_18 == "Manual" and not v_u_33 or (v_u_18 == "Manual" and (v_u_5.ClutchRel and v_u_53 - v_u_5.IdleThrottle / 100 > 0) or (v_u_26 == #v_u_5.Ratios - 2 or v_u_18 ~= "Manual" and not v_u_16)) then
			v_u_32 = false
			return
		end
		local v361 = v_u_26 + 3
		local v362 = #v_u_5.Ratios
		local v363 = math.min(v361, v362)
		if v_u_18 ~= "Manual" then
			v_u_38 = true
			if v_u_26 > 0 then
				if v_u_5.AutoShiftType == "DCT" then
					wait(v_u_5.ShiftUpTime)
				elseif v_u_5.AutoShiftType == "Rev" then
					repeat
						wait()
						local v364 = v_u_62
						local v365 = v359 * v_u_5.Ratios[v363] * v_u_246
						local v366 = v_u_5.Redline - v_u_5.RevBounce
						local v367 = math.min(v365, v366)
						local v368 = v_u_5.IdleRPM
					until v364 <= math.max(v367, v368) or (not v_u_16 or v_u_31)
				end
			end
		end
		v_u_32 = false
		v_u_38 = false
		if v_u_18 ~= "Manual" and not v_u_16 then
			return
		end
		local v369 = v_u_26 + 1
		local v370 = #v_u_5.Ratios - 2
		v_u_26 = math.min(v369, v370)
		if v_u_18 ~= "Manual" or v_u_18 == "Manual" and (v_u_26 == 1 and v_u_16) then
			v_u_33 = false
		end
	end
	if v_u_31 and not v_u_38 then
		if v_u_18 == "Manual" and not v_u_33 or (v_u_26 == -1 or v_u_18 ~= "Manual" and not v_u_16) then
			v_u_31 = false
			return
		end
		local v371 = v_u_26 + 1
		local v372 = #v_u_5.Ratios
		local v373 = math.min(v371, v372)
		if v_u_18 ~= "Manual" then
			v_u_38 = true
			if v_u_26 > 1 then
				if v_u_5.AutoShiftType == "DCT" then
					wait(v_u_5.ShiftDnTime)
				elseif v_u_5.AutoShiftType == "Rev" then
					repeat
						wait()
						local v374 = v_u_62
						local v375 = v359 * v_u_5.Ratios[v373] * v_u_246
						local v376 = v_u_5.Redline - v_u_5.RevBounce
						local v377 = math.min(v375, v376)
						local v378 = v_u_5.IdleRPM
					until math.max(v377, v378) <= v374 or (not v_u_16 or v_u_32)
				end
			end
		end
		v_u_31 = false
		v_u_38 = false
		if v_u_18 ~= "Manual" and not v_u_16 then
			return
		end
		local v379 = v_u_26 - 1
		v_u_26 = math.max(v379, -1)
		if v_u_18 ~= "Manual" or v_u_18 == "Manual" and (v_u_26 == -1 and v_u_16) then
			v_u_33 = false
		end
	end
end
local v_u_380 = 0
local v_u_381 = 1
local v_u_382 = 0
local v_u_383 = false
local v_u_384 = tick()
function Engine(p385)
	-- upvalues: (ref) v_u_26, (ref) v_u_38, (ref) v_u_16, (ref) v_u_33, (ref) v_u_50, (ref) v_u_383, (copy) v_u_5, (ref) v_u_32, (ref) v_u_40, (ref) v_u_31, (ref) v_u_18, (ref) v_u_54, (ref) v_u_53, (ref) v_u_51, (ref) v_u_384, (ref) v_u_34, (copy) v_u_90, (ref) v_u_380, (ref) v_u_62, (copy) v_u_246, (ref) v_u_44, (ref) v_u_37, (ref) v_u_47, (ref) v_u_252, (ref) v_u_251, (ref) v_u_56, (ref) v_u_39, (ref) v_u_253, (ref) v_u_382, (ref) v_u_55, (copy) v_u_310, (ref) v_u_48, (ref) v_u_65, (copy) v_u_312, (ref) v_u_46, (ref) v_u_63, (copy) v_u_313, (ref) v_u_64, (ref) v_u_58, (ref) v_u_59, (ref) v_u_43, (copy) v_u_311, (ref) v_u_45, (ref) v_u_41, (ref) v_u_42, (copy) v_u_4, (copy) v_u_247, (copy) v_u_249, (copy) v_u_250, (ref) v_u_61, (ref) v_u_52, (ref) v_u_20, (ref) v_u_35, (ref) v_u_381, (ref) v_u_19, (ref) v_u_60, (copy) v_u_7, (copy) v_u_11, (copy) v_u_9, (copy) v_u_8, (copy) v_u_10
	local v386 = 60 / (1 / p385)
	if (v_u_26 == 0 or v_u_38) and v_u_16 then
		v_u_33 = true
		v_u_50 = 1
		v_u_383 = false
	end
	local v387 = v_u_5.IdleRPM
	local v388 = v_u_5.IdleRPM
	local v389 = v_u_5.Redline
	local v390 = v_u_5.Stall and v_u_5.Clutch and 0 or v387
	if v_u_38 and v_u_32 then
		v_u_40 = 0
	elseif v_u_38 and v_u_31 then
		v_u_40 = v_u_5.ShiftThrot / 100
	elseif v_u_5.AutoShiftVers == "Old" and (v_u_26 == -1 and v_u_18 == "Auto") then
		v_u_40 = v_u_54
	else
		v_u_40 = v_u_53
	end
	if v_u_5.AutoShiftVers == "Old" and (v_u_26 == -1 and v_u_18 == "Auto") then
		v_u_51 = v_u_53 - v_u_5.IdleThrottle / 100
	else
		v_u_51 = v_u_54
	end
	if not v_u_16 then
		v_u_384 = tick()
		v390 = 0
		v388 = 0
		v_u_40 = v_u_5.IdleThrottle / 100
		if v_u_18 ~= "Manual" then
			v_u_26 = 0
			v_u_33 = true
			v_u_50 = 1
		end
	end
	if (v_u_33 and v_u_26 == 0 or v_u_34 and v_u_26 ~= 0) and (v_u_5.NeutralLimit and (v_u_26 == 0 and not v_u_5.LimitClutch or v_u_5.LimitClutch)) then
		v389 = v_u_5.NeutralRevRPM
	end
	local v391 = v_u_40
	local v392 = 0
	local v393 = 0
	for _, v394 in pairs(v_u_90) do
		v392 = v392 + v394.RotVelocity.Magnitude
		v393 = v393 + 1
	end
	local v395 = v392 / v393
	if v_u_380 > v389 + 100 then
		v391 = v_u_5.IdleThrottle / 100
	end
	if v_u_5.Engine or v_u_5.Electric then
		local v396 = v_u_62 - v_u_5.RevDecay * v386 + (v_u_5.RevDecay + v_u_5.RevAccel) * v391 * v386
		local v397 = v_u_5.Redline + 100
		v_u_380 = math.clamp(v396, v388, v397)
	end
	if v_u_380 > v_u_5.Redline then
		if v_u_26 < #v_u_5.Ratios - 2 then
			v_u_380 = v_u_380 - v_u_5.RevBounce
		else
			v_u_380 = v_u_380 - v_u_5.RevBounce * 0.5
		end
	end
	local v398 = v395 * v_u_5.Ratios[v_u_26 + 2] * v_u_246
	if v_u_5.Clutch then
		if script.Parent.Values.AutoClutch.Value and v_u_16 then
			if v_u_5.ClutchType == "Clutch" then
				if v_u_33 then
					v_u_44 = 1
				end
				v_u_44 = v_u_44 * (v_u_5.ClutchEngage / 100)
				local v399 = (v_u_62 - v_u_5.IdleRPM) * v_u_5.ClutchRPMMult / (v_u_5.Redline - v_u_5.IdleRPM)
				local v400 = math.max(v399, 0)
				local v401 = v_u_5.ClutchMode == "New" and 0 or v400
				local v402 = v_u_26
				local v403 = script.Parent.Values.Velocity.Value.Magnitude / v_u_5.SpeedEngage / math.abs(v402) + v401 - v_u_44
				v_u_37 = math.min(v403, 1)
			elseif v_u_5.ClutchType == "CVT" or v_u_5.ClutchType == "TorqueConverter" and v_u_5.TQLock then
				if v_u_40 - v_u_5.IdleThrottle / 100 == 0 and script.Parent.Values.Velocity.Value.Magnitude < v_u_5.SpeedEngage or v_u_40 - v_u_5.IdleThrottle / 100 ~= 0 and (v_u_62 < v_u_5.RPMEngage and v398 < v_u_5.RPMEngage) then
					local v404 = v_u_37 * (v_u_5.ClutchEngage / 100)
					v_u_37 = math.min(v404, 1)
				else
					local v405 = v_u_37 * (v_u_5.ClutchEngage / 100) + (1 - v_u_5.ClutchEngage / 100)
					v_u_37 = math.min(v405, 1)
				end
			elseif v_u_5.ClutchType == "TorqueConverter" and not v_u_5.TQLock then
				local v406 = v_u_62 / v_u_5.Redline * 0.7
				v_u_37 = math.min(v406, 1)
			end
			if v_u_33 then
				v_u_50 = 1
			else
				local v407 = 1 - v_u_37
				v_u_50 = math.min(v407, 1)
			end
			v_u_383 = v_u_50 <= 0.01 and true or v_u_383
		else
			v_u_383 = v_u_5.Stall
			v_u_50 = script.Parent.Values.Clutch.Value
		end
	else
		v_u_383 = false
		if v_u_33 or v_u_38 then
			v_u_50 = 1
		else
			v_u_50 = 0
		end
	end
	local v408 = v_u_380 * v_u_50 + v398 * (1 - v_u_50)
	local v409 = v_u_5.Redline + 100
	local v410 = math.min(v408, v409)
	local v411 = math.max(v410, v390)
	local v412 = v411 - v_u_62
	local v413 = math.abs(v412) / (v_u_5.Flywheel * v386)
	local v414 = v_u_33 and 0 or math.min(v413, 0.9)
	v_u_62 = v_u_62 * v414 + v411 * (1 - v414)
	if v_u_62 <= v_u_5.IdleRPM / 4 and (v_u_383 and tick() - v_u_384 >= 0.2) then
		script.Parent.IsOn.Value = not v_u_5.Stall
	end
	v_u_47 = (v_u_5.Redline + 100) / (v_u_246 * v_u_5.Ratios[v_u_26 + 2])
	if v_u_62 > v_u_5.Redline then
		if v_u_26 < #v_u_5.Ratios - 2 then
			v_u_62 = v_u_62 - v_u_5.RevBounce
		else
			v_u_62 = v_u_62 - v_u_5.RevBounce * 0.5
		end
	end
	local v415 = v_u_252 / v_u_251
	local v416 = v_u_40
	if v_u_5.Engine then
		if v_u_251 == 0 then
			v_u_56 = 0
		else
			v_u_56 = v_u_56 + (v_u_39 * (v416 * 1.2) / v_u_5.Horsepower / 8 - v_u_56 / v415 * (v415 / 15)) * (8 / (v_u_5.T_Size / v386) * 2) / v415 * 15
			if v_u_56 < 0.05 then
				v_u_56 = 0.05
			elseif v_u_56 > 2 then
				v_u_56 = 2
			end
		end
		if v_u_253 == 0 then
			v_u_55 = 0
		else
			if v_u_382 < v416 then
				local v417 = v_u_382 + v_u_5.S_Sensitivity * v386
				v_u_382 = math.min(v416, v417)
			elseif v416 < v_u_382 then
				local v418 = v_u_382 - v_u_5.S_Sensitivity * v386
				v_u_382 = math.max(v416, v418)
			end
			v_u_55 = v_u_62 / v_u_5.Redline * (v_u_382 * 1.5 + 0.5)
		end
	else
		v_u_56 = 0
		v_u_55 = 0
	end
	if v_u_5.Engine then
		local v419 = v_u_310[v_u_26 + 2]
		local v420 = v_u_5.Redline
		local v421 = v_u_62
		local v422 = math.max(0, v421)
		local v423 = math.min(v420, v422) / 100
		local v424 = v419[math.floor(v423)]
		local v425 = v424.Horsepower
		local v426 = v424.HpSlope
		local v427 = v_u_62
		local v428 = v_u_62 / 100
		v_u_48 = v425 + v426 * ((v427 - math.floor(v428)) / 100 % 1)
		local v429 = v424.Torque
		local v430 = v424.TqSlope
		local v431 = v_u_62
		local v432 = v_u_62 / 100
		v_u_65 = v429 + v430 * ((v431 - math.floor(v432)) / 100 % 1)
		if v_u_251 == 0 then
			v_u_46 = 0
			v_u_63 = 0
		else
			local v433 = v_u_312[v_u_26 + 2]
			local v434 = v_u_5.Redline
			local v435 = v_u_62
			local v436 = math.max(0, v435)
			local v437 = math.min(v434, v436) / 100
			local v438 = v433[math.floor(v437)]
			local v439 = v438.Horsepower
			local v440 = v438.HpSlope
			local v441 = v_u_62
			local v442 = v_u_62 / 100
			v_u_46 = (v439 + v440 * ((v441 - math.floor(v442)) / 100 % 1)) * (v_u_56 / 2)
			local v443 = v438.Torque
			local v444 = v438.TqSlope
			local v445 = v_u_62
			local v446 = v_u_62 / 100
			v_u_63 = (v443 + v444 * ((v445 - math.floor(v446)) / 100 % 1)) * (v_u_56 / 2)
		end
		if v_u_253 == 0 then
			v_u_64 = 0
			v_u_58 = 0
		else
			local v447 = v_u_313[v_u_26 + 2]
			local v448 = v_u_5.Redline
			local v449 = v_u_62
			local v450 = math.max(0, v449)
			local v451 = math.min(v448, v450) / 100
			local v452 = v447[math.floor(v451)]
			local v453 = v452.Horsepower
			local v454 = v452.HpSlope
			local v455 = v_u_62
			local v456 = v_u_62 / 100
			v_u_64 = (v453 + v454 * ((v455 - math.floor(v456)) / 100 % 1)) * (v_u_55 / 2)
			local v457 = v452.Torque
			local v458 = v452.TqSlope
			local v459 = v_u_62
			local v460 = v_u_62 / 100
			v_u_58 = (v457 + v458 * ((v459 - math.floor(v460)) / 100 % 1)) * (v_u_55 / 2)
		end
		v_u_59 = v_u_46 + v_u_64
		v_u_43 = v_u_63 + v_u_58
	else
		v_u_48 = 0
		v_u_65 = 0
		v_u_46 = 0
		v_u_63 = 0
		v_u_64 = 0
		v_u_58 = 0
		v_u_59 = 0
		v_u_43 = 0
	end
	if v_u_5.Electric and v_u_26 ~= 0 then
		local v461 = v_u_311[v_u_26 + 2]
		local v462 = v_u_5.Redline
		local v463 = v_u_62
		local v464 = math.max(100, v463)
		local v465 = math.min(v462, v464) / 100
		local v466 = v461[math.floor(v465)]
		local v467 = v466.Horsepower
		local v468 = v466.HpSlope
		local v469 = v_u_62
		local v470 = v_u_62 / 100
		v_u_45 = v467 + v468 * ((v469 - math.floor(v470)) / 100 % 1)
		local v471 = v466.Torque
		local v472 = v466.TqSlope
		local v473 = v_u_62
		local v474 = v_u_62 / 100
		v_u_41 = v471 + v472 * ((v473 - math.floor(v474)) / 100 % 1)
	else
		v_u_45 = 0
		v_u_41 = 0
	end
	v_u_39 = v_u_48 + v_u_59 + v_u_45
	v_u_42 = v_u_65 + v_u_43 + v_u_41
	local v475 = v_u_4.DriveSeat.CFrame.lookVector.y * v_u_247
	if v_u_26 == -1 then
		v475 = -v475
	end
	local v476 = v_u_42
	local v477 = 1 + v475
	v_u_42 = v476 * math.max(1, v477)
	local v478 = 0
	local v479 = 0
	local v480 = 0
	local v481 = 0
	for _, v482 in pairs(v_u_4.Wheels:GetChildren()) do
		if v482.Name == "FL" or (v482.Name == "FR" or v482.Name == "F") then
			v478 = v478 + v482.RotVelocity.Magnitude
			v479 = v479 + 1
		elseif v482.Name == "RL" or (v482.Name == "RR" or v482.Name == "R") then
			v480 = v480 + v482.RotVelocity.Magnitude
			v481 = v481 + 1
		end
	end
	local v483 = v478 / v479
	local v484 = v480 / v481
	local v485 = (v483 + v484) / 2
	for _, v486 in pairs(v_u_4.Wheels:GetChildren()) do
		local _ = (CFrame.new(v486.Position - (v486.Arm.CFrame * v_u_249).lookVector, v486.Position) * v_u_250).lookVector
		local _ = v486.Name == "FL" or v486.Name == "RL"
		local v487 = 1
		local v488 = 1
		local v489 = 1
		local v490 = 1
		local v491 = 1
		if v_u_5.DifferentialType == "Old" then
			if v486.Name == "FL" or v486.Name == "FR" then
				local v492 = (v486.RotVelocity.Magnitude - v483) / v483
				local v493 = v_u_5.FDiffSlipThres
				local v494 = 1 + v492 / (math.max(v493, 1) / 100) * ((v_u_5.FDiffLockThres - 50) / 50)
				local v495 = math.min(1, v494)
				v490 = math.max(0, v495)
				if v_u_5.Config == "AWD" then
					local v496 = (v483 - v485) / v485
					local v497 = v_u_5.CDiffSlipThres
					local v498 = v490 * (1 + v496 / (math.max(v497, 1) / 100) * ((v_u_5.CDiffLockThres - 50) / 50))
					local v499 = math.min(1, v498)
					v490 = math.max(0, v499)
				end
			elseif v486.Name == "RL" or v486.Name == "RR" then
				local v500 = (v486.RotVelocity.Magnitude - v484) / v484
				local v501 = v_u_5.RDiffSlipThres
				local v502 = 1 + v500 / (math.max(v501, 1) / 100) * ((v_u_5.RDiffLockThres - 50) / 50)
				local v503 = math.min(1, v502)
				v490 = math.max(0, v503)
				if v_u_5.Config == "AWD" then
					local v504 = (v484 - v485) / v485
					local v505 = v_u_5.CDiffSlipThres
					local v506 = v490 * (1 + v504 / (math.max(v505, 1) / 100) * ((v_u_5.CDiffLockThres - 50) / 50))
					local v507 = math.min(1, v506)
					v490 = math.max(0, v507)
				end
			end
		elseif v486.Name == "FR" then
			local v508 = (v486.RotVelocity.Magnitude / v_u_4.Wheels.FL.RotVelocity.Magnitude - 1) * (v_u_5.FDiffPreload / 10)
			local v509 = 1 - (v_u_5.FDiffPower / 100 * v508 * v_u_40 + v_u_5.FDiffCoast / 100 * v508 * (1 - v_u_40))
			local v510 = math.min(2, v509)
			local v511 = math.max(0, v510) * 100
			v487 = math.ceil(v511) / 100
			v489 = 2 - v487
		elseif v486.Name == "FL" then
			local v512 = (v486.RotVelocity.Magnitude / v_u_4.Wheels.FR.RotVelocity.Magnitude - 1) * (v_u_5.FDiffPreload / 10)
			local v513 = 1 - (v_u_5.FDiffPower / 100 * v512 * v_u_40 + v_u_5.FDiffCoast / 100 * v512 * (1 - v_u_40))
			local v514 = math.min(2, v513)
			local v515 = math.max(0, v514) * 100
			v489 = math.ceil(v515) / 100
			v487 = 2 - v489
		elseif v486.Name == "RR" then
			local v516 = (v486.RotVelocity.Magnitude / v_u_4.Wheels.RL.RotVelocity.Magnitude - 1) * (v_u_5.RDiffPreload / 10)
			local v517 = 1 - (v_u_5.RDiffPower / 100 * v516 * v_u_40 + v_u_5.RDiffCoast / 100 * v516 * (1 - v_u_40))
			local v518 = math.min(2, v517)
			local v519 = math.max(0, v518) * 100
			v491 = math.ceil(v519) / 100
			v488 = 2 - v491
		elseif v486.Name == "RL" then
			local v520 = (v486.RotVelocity.Magnitude / v_u_4.Wheels.RR.RotVelocity.Magnitude - 1) * (v_u_5.RDiffPreload / 10)
			local v521 = 1 - (v_u_5.RDiffPower / 100 * v520 * v_u_40 + v_u_5.RDiffCoast / 100 * v520 * (1 - v_u_40))
			local v522 = math.min(2, v521)
			local v523 = math.max(0, v522) * 100
			v488 = math.ceil(v523) / 100
			v491 = 2 - v488
		end
		v_u_61 = false
		v_u_52 = false
		local v524 = script.Parent.IsOn.Value and 1 or 0
		local v525 = v_u_40
		local v526 = v_u_51
		local v527 = v_u_33 and 0 or 1
		local v528 = v_u_42
		local v529 = 1
		if v_u_20 and v526 > 0 then
			local v530 = v486.RotVelocity.Magnitude * (v486.Size.x / 2) - v486.Velocity.Magnitude
			v529 = math.abs(v530) - v_u_5.ABSThreshold > 0 and 0 or v529
		end
		v_u_52 = v529 < 1
		local v531 = v_u_35 == true and 1 or 0
		local v532 = false
		for _, v533 in pairs(v_u_90) do
			if v533 == v486 then
				v532 = true
			end
		end
		if v532 then
			if v_u_5.Config == "AWD" then
				local v534 = (v_u_5.TorqueVector + 1) / 2
				if string.find(v486.Name, "F") then
					v528 = v528 * (1 - v534)
				elseif string.find(v486.Name, "R") then
					v528 = v528 * v534
				end
			end
			v_u_381 = 1
			if v_u_19 and v525 > 0 then
				local v535 = v486.RotVelocity.Magnitude * (v486.Size.x / 2) - v486.Velocity.Magnitude
				local v536 = math.abs(v535) - v_u_5.TCSThreshold
				local v537 = math.max(0, v536) / v_u_5.TCSGradient
				v_u_381 = 1 - math.min(v537, 1) * (1 - v_u_5.TCSLimit / 100)
			end
			if v_u_381 < 1 then
				v_u_60 = v_u_381
				v_u_61 = true
			end
			local v538 = v_u_26 == -1 and -1 or 1
			if v_u_5.ClutchKick and (v_u_4.DriveSeat.Velocity.Magnitude < v_u_5.KickSpeedThreshold and (v_u_62 > v_u_5.Redline - v_u_5.KickRPMThreshold and v486["#BV"].MotorMaxTorque < 1)) then
				v528 = v528 * v_u_5.KickMult
			end
			local v539 = v528 * (60 / workspace:GetRealPhysicsFPS()) * (1 + (v486.RotVelocity.Magnitude / (120 - workspace:GetRealPhysicsFPS())) ^ (1.15 + 0.07 * (1 - 60 / workspace:GetRealPhysicsFPS()))) * v525 * v_u_381 * v524 * v527
			if v486.Name == "RR" then
				v486["#AV"].MotorMaxTorque = v539 * v491 * v490
			elseif v486.Name == "RL" then
				v486["#AV"].MotorMaxTorque = v539 * v488 * v490
			elseif v486.Name == "FR" then
				v486["#AV"].MotorMaxTorque = v539 * v487 * v490
			elseif v486.Name == "FL" then
				v486["#AV"].MotorMaxTorque = v539 * v489 * v490
			else
				v486["#AV"].MotorMaxTorque = v539 * v490
			end
			v486["#AV"].AngularVelocity = v_u_47 * v538
			if string.find(v486.Name, "F") then
				v486["#BV"].MotorMaxTorque = v_u_7 * (60 / workspace:GetRealPhysicsFPS()) * v526 * v529 + v_u_11 * ((1 - v525) * (v_u_62 / v_u_5.Redline)) + v_u_9 * v531
			else
				v486["#BV"].MotorMaxTorque = v_u_8 * (60 / workspace:GetRealPhysicsFPS()) * v526 * v529 + v_u_11 * ((1 - v525) * (v_u_62 / v_u_5.Redline)) + v_u_10 * v531
			end
		else
			v486["#AV"].MotorMaxTorque = 0
			v486["#AV"].AngularVelocity = 0
			if string.find(v486.Name, "F") then
				v486["#BV"].MotorMaxTorque = v_u_7 * (60 / workspace:GetRealPhysicsFPS()) * v526 * v529 + v_u_9 * v531
			else
				v486["#BV"].MotorMaxTorque = v_u_8 * (60 / workspace:GetRealPhysicsFPS()) * v526 * v529 + v_u_10 * v531
			end
		end
	end
end
function Flip()
	-- upvalues: (copy) v_u_4, (ref) v_u_57, (ref) v_u_21
	if (v_u_4.DriveSeat.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)).lookVector.y > 0.1 or v_u_57 then
		v_u_21 = tick()
	elseif tick() - v_u_21 >= 3 then
		v_u_57 = true
		local v540 = v_u_4.DriveSeat.Flip
		v540.maxTorque = Vector3.new(10000, 0, 10000)
		v540.P = 3000
		v540.D = 500
		wait(1)
		v540.maxTorque = Vector3.new(0, 0, 0)
		v540.P = 0
		v540.D = 0
		v_u_57 = false
	end
end
local v541 = require(v_u_4["A-Chassis Tune"].README)
print("Novena: AC6C Loaded - Version " .. v541 .. ", Update " .. script.Parent.Version.Value)
game["Run Service"].Heartbeat:connect(function(p542)
	-- upvalues: (ref) v_u_16, (ref) v_u_36, (ref) v_u_26, (ref) v_u_62, (ref) v_u_56, (ref) v_u_252, (ref) v_u_55, (ref) v_u_254, (ref) v_u_48, (ref) v_u_45, (ref) v_u_46, (ref) v_u_64, (ref) v_u_59, (ref) v_u_39, (ref) v_u_65, (copy) v_u_5, (copy) v_u_245, (copy) v_u_6, (ref) v_u_41, (ref) v_u_63, (ref) v_u_58, (ref) v_u_18, (ref) v_u_40, (ref) v_u_51, (ref) v_u_50, (ref) v_u_49, (ref) v_u_28, (ref) v_u_35, (ref) v_u_19, (ref) v_u_61, (ref) v_u_60, (ref) v_u_20, (ref) v_u_52, (ref) v_u_25, (copy) v_u_4
	v_u_16 = script.Parent.IsOn.Value
	v_u_36 = script.Parent.ControlsOpen.Value
	Inputs(p542)
	Steering(p542)
	Gear()
	Engine(p542)
	script.Parent.Values.Gear.Value = v_u_26
	script.Parent.Values.RPM.Value = v_u_62
	script.Parent.Values.Boost.Value = v_u_56 / 2 * v_u_252 + v_u_55 / 2 * v_u_254
	script.Parent.Values.BoostTurbo.Value = v_u_56 / 2 * v_u_252
	script.Parent.Values.BoostSuper.Value = v_u_55 / 2 * v_u_254
	script.Parent.Values.HpNatural.Value = v_u_48
	script.Parent.Values.HpElectric.Value = v_u_45
	script.Parent.Values.HpTurbo.Value = v_u_46
	script.Parent.Values.HpSuper.Value = v_u_64
	script.Parent.Values.HpBoosted.Value = v_u_59
	script.Parent.Values.Horsepower.Value = v_u_39
	script.Parent.Values.TqNatural.Value = v_u_65 / v_u_5.Ratios[v_u_26 + 2] / v_u_245 / v_u_6
	script.Parent.Values.TqElectric.Value = v_u_41 / v_u_5.Ratios[v_u_26 + 2] / v_u_245 / v_u_6
	script.Parent.Values.TqTurbo.Value = v_u_63 / v_u_5.Ratios[v_u_26 + 2] / v_u_245 / v_u_6
	script.Parent.Values.TqSuper.Value = v_u_58 / v_u_5.Ratios[v_u_26 + 2] / v_u_245 / v_u_6
	script.Parent.Values.TqBoosted.Value = script.Parent.Values.TqTurbo.Value + script.Parent.Values.TqSuper.Value
	script.Parent.Values.Torque.Value = script.Parent.Values.TqNatural.Value + script.Parent.Values.TqElectric.Value + script.Parent.Values.TqBoosted.Value
	script.Parent.Values.TransmissionMode.Value = v_u_18
	script.Parent.Values.Throttle.Value = v_u_40
	script.Parent.Values.Brake.Value = v_u_51
	if script.Parent.Values.AutoClutch.Value then
		script.Parent.Values.Clutch.Value = v_u_50
	end
	script.Parent.Values.SteerC.Value = v_u_49
	script.Parent.Values.SteerT.Value = v_u_28
	script.Parent.Values.PBrake.Value = v_u_35
	script.Parent.Values.TCS.Value = v_u_19
	script.Parent.Values.TCSActive.Value = v_u_61
	script.Parent.Values.TCSAmt.Value = 1 - v_u_60
	script.Parent.Values.ABS.Value = v_u_20
	script.Parent.Values.ABSActive.Value = v_u_52
	script.Parent.Values.MouseSteerOn.Value = v_u_25
	script.Parent.Values.Velocity.Value = v_u_4.DriveSeat.Velocity
end)
while wait(0.0667) do
	if v_u_18 == "Auto" then
		Auto()
	end
	if v_u_5.AutoFlip then
		Flip()
	end
end