-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

script.Parent:WaitForChild("Car")
local v1 = script.Parent.AC6_Stock_Gauges.Spotlight
local v_u_2 = script.Parent.Car.Value.Body.Spotlight.RemoteEvent
v1.On.MouseButton1Down:Connect(function()
	-- upvalues: (copy) v_u_2
	v_u_2:FireServer("Lights on")
	script.Parent.AC6_Stock_Gauges.Frame.Beep:Play()
end)
v1.Off.MouseButton1Down:Connect(function()
	-- upvalues: (copy) v_u_2
	v_u_2:FireServer("Lights off")
	script.Parent.AC6_Stock_Gauges.Frame.Beep:Play()
end)
v1.Right.MouseButton1Down:Connect(function()
	-- upvalues: (copy) v_u_2
	v_u_2:FireServer("Right start")
end)
v1.Right.MouseButton1Up:Connect(function()
	-- upvalues: (copy) v_u_2
	v_u_2:FireServer("Right stop")
end)
v1.Left.MouseButton1Down:Connect(function()
	-- upvalues: (copy) v_u_2
	v_u_2:FireServer("Left start")
end)
v1.Left.MouseButton1Up:Connect(function()
	-- upvalues: (copy) v_u_2
	v_u_2:FireServer("Left stop")
end)