-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = script.Parent.Car.Value
local v_u_2 = script.Parent.Values
local v_u_3 = require(v_u_1["A-Chassis Tune"])
local v_u_4 = v_u_1:WaitForChild("cmapi")
local v5 = v_u_2.RPM
local v_u_6 = v_u_2.Throttle
v_u_4:FireServer(v_u_1, "init")
local function v7()
	-- upvalues: (copy) v_u_2, (copy) v_u_4, (copy) v_u_1
	if v_u_2.Parent.IsOn.Value == true then
		v_u_4:FireServer(v_u_1, "play")
	else
		v_u_4:FireServer(v_u_1, "stop")
	end
end
if v_u_2.Parent.IsOn.Value == true then
	v_u_4:FireServer(v_u_1, "play")
else
	v_u_4:FireServer(v_u_1, "stop")
end
v_u_2.Parent.IsOn.Changed:Connect(v7)
v5.Changed:Connect(function(p8)
	-- upvalues: (copy) v_u_4, (copy) v_u_1, (copy) v_u_6, (copy) v_u_3
	v_u_4:FireServer(v_u_1, "update", {
		["rpm"] = p8,
		["throttle"] = v_u_6.Value,
		["tune"] = v_u_3
	})
end)
script.AncestryChanged:Connect(function()
	-- upvalues: (copy) v_u_4, (copy) v_u_1
	if not script:IsDescendantOf(game) then
		v_u_4:FireServer(v_u_1, "cleanup")
	end
end)