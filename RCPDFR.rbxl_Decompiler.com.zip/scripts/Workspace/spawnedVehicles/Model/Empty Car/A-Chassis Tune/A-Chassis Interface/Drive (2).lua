-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

script.Parent:WaitForChild("Car")
script.Parent:WaitForChild("IsOn")
script.Parent:WaitForChild("ControlsOpen")
script.Parent:WaitForChild("Values")
local v_u_1 = game.Players.LocalPlayer
local v_u_2 = v_u_1:GetMouse()
local v_u_3 = game:GetService("UserInputService")
local v_u_4 = game:GetService("GuiService")
local v_u_5 = game:GetService("TextChatService")
local v_u_6 = script.Parent.Car.Value
local v_u_7 = require(v_u_6["A-Chassis Tune"])
local v_u_8 = require(v_u_6["A-Chassis Tune"].Units)
require(v_u_1.PlayerScripts:WaitForChild("PlayerModule"))
local v_u_9 = script.Parent.Values
v_u_1.PlayerGui.ScreenOrientation = Enum.ScreenOrientation.LandscapeSensor
v_u_4.TouchControlsEnabled = false
local v_u_10 = "Tap"
local v_u_11 = { "Tap", "Tilt" }
local v_u_12 = v_u_7.BrakeForce * 9.80665 * v_u_8.Force_N * v_u_7.BrakeBias
local v_u_13 = v_u_7.BrakeForce * 9.80665 * v_u_8.Force_N * (1 - v_u_7.BrakeBias)
local v_u_14 = v_u_7.PBrakeForce * 9.80665 * v_u_8.Force_N * v_u_7.PBrakeBias
local v_u_15 = v_u_7.PBrakeForce * 9.80665 * v_u_8.Force_N * (1 - v_u_7.PBrakeBias)
local v_u_16 = v_u_7.EBrakeForce
local _ = v_u_7.SteerOuter
local _ = v_u_7.SteerInner
local v_u_17 = v_u_7.RSteerOuter
local v_u_18 = v_u_7.RSteerInner
if not workspace:PGSIsEnabled() then
	error("PGS is not enabled: A-Chassis will not work.")
end
local v19 = {
	[true] = 1,
	[false] = 0
}
local v_u_20 = math.min
local v_u_21 = math.max
local v_u_22 = v_u_7.AutoStart
if v_u_7.AutoStart and (v_u_7.Engine or v_u_7.Electric) then
	script.Parent.IsOn.Value = true
end
local _ = v_u_7.BrakeForce * 9.80665 * v_u_8.Force_N
local _ = v_u_7.BrakeBias
local v_u_23 = v_u_7.StartRPM
local v_u_24 = 0
local _ = v_u_7.S_Config
local v_u_25 = v_u_7.CVTMaxRatio
local v_u_26 = v_u_7.Ratios[v_u_24 + 2]
local v_u_27 = v_u_7.TransModes[1]
local v_u_28 = v_u_7.TCSEnabled
local v_u_29 = v_u_7.ABSEnabled
local v_u_30 = tick()
local v_u_31 = CFrame.new()
local v_u_32 = v_u_7.AutoShiftVers
local v_u_33 = Vector3.new()
v_u_6.DriveSeat.ChildRemoved:connect(function(p34)
	-- upvalues: (copy) v_u_4
	if p34.Name == "SeatWeld" and p34:IsA("Weld") then
		v_u_4.TouchControlsEnabled = true
		script.Parent:Destroy()
	end
end)
local v_u_35 = v_u_7.Controls
local v36 = Instance.new("Folder", script.Parent)
v36.Name = "Controls"
local v_u_37 = false
local v_u_38 = false
local v_u_39 = false
local v_u_40 = false
local v_u_41 = 0
local v_u_42 = 0
local v_u_43 = 0
local v_u_44 = false
local v_u_45 = false
local v_u_46 = false
local v_u_47 = false
local v_u_48 = false
local v_u_49 = {}
local v_u_50 = 0
local v_u_51 = {}
local v_u_52 = 0
local v_u_53 = 0
local v_u_54 = false
local v_u_55 = 0
local v_u_56 = 0
local v_u_57 = 0
local v_u_58 = 0
local v_u_59 = 0
local v_u_60 = 0
local v_u_61 = false
local v_u_62 = 0
local v_u_63 = 0
local v_u_64 = 0
local v_u_65 = 0
local v_u_66 = 0
local v_u_67 = 0
local v_u_68 = false
local v_u_69 = 0
local v_u_70 = 0
local v_u_71 = false
local v_u_72 = 0
local v_u_73 = 0
local v_u_74 = 0
local v_u_75 = 0
local v_u_76 = 0
local v_u_77 = 0
local v_u_78 = {}
local v_u_79 = 0
local v_u_80 = 0
local v_u_81 = {}
local v_u_82 = 0
local v_u_83 = 0
local v_u_84 = false
local v_u_85 = 0
local v_u_86 = false
for v_u_87, v88 in next, v_u_35 do
	local v_u_89 = Instance.new("StringValue", v36)
	v_u_89.Name = v_u_87
	v_u_89.Value = v88.Name
	v_u_89.Changed:connect(function()
		-- upvalues: (copy) v_u_87, (copy) v_u_89, (copy) v_u_35
		if v_u_87 == "MouseThrottle" or v_u_87 == "MouseBrake" then
			if v_u_89.Value == "MouseButton1" or v_u_89.Value == "MouseButton2" then
				v_u_35[v_u_87] = Enum.UserInputType[v_u_89.Value]
			else
				v_u_35[v_u_87] = Enum.KeyCode[v_u_89.Value]
			end
		else
			v_u_35[v_u_87] = Enum.KeyCode[v_u_89.Value]
			return
		end
	end)
end
local v_u_90 = v_u_7.Peripherals
for v_u_91, v92 in next, v_u_90 do
	local v_u_93 = Instance.new("IntValue", v36)
	v_u_93.Name = v_u_91
	v_u_93.Value = v92
	v_u_93.Changed:connect(function()
		-- upvalues: (copy) v_u_93, (copy) v_u_90, (copy) v_u_91
		local v94 = v_u_93
		local v95 = v_u_93.Value
		local v96 = math.max(0, v95)
		v94.Value = math.min(100, v96)
		v_u_90[v_u_91] = v_u_93.Value
	end)
end
function GetCarCenter()
	-- upvalues: (copy) v_u_6
	local v97 = Vector3.new()
	local v98 = Vector3.new()
	local v99 = next
	local v100, v101 = v_u_6.Wheels:GetChildren()
	local v102 = 0
	local v103 = 0
	for _, v104 in v99, v100, v101 do
		if v104.Name == "FL" or (v104.Name == "FR" or v104.Name == "F") then
			v97 = v97 + v104.CFrame.p
			v102 = v102 + 1
		else
			v98 = v98 + v104.CFrame.p
			v103 = v103 + 1
		end
	end
	local v105 = v97 / v102
	local v106 = v98 / v103
	return CFrame.lookAt(v106:Lerp(v105, 0.5), v105)
end
v_u_9.AutoClutch.Value = true
function DealWithInput(p107, _)
	-- upvalues: (ref) v_u_37, (copy) v_u_5, (copy) v_u_3, (copy) v_u_35, (ref) v_u_38, (ref) v_u_22, (ref) v_u_27, (ref) v_u_24, (copy) v_u_7, (ref) v_u_46, (ref) v_u_47, (ref) v_u_48, (ref) v_u_39, (ref) v_u_40, (copy) v_u_6, (ref) v_u_41, (ref) v_u_42, (ref) v_u_43, (ref) v_u_44, (ref) v_u_45, (ref) v_u_28, (ref) v_u_29
	if v_u_37 or (v_u_5.ChatInputBarConfiguration.IsFocused or v_u_3:GetFocusedTextBox() ~= nil) then
		v_u_41 = 0
		v_u_43 = 0
		v_u_42 = 0
	else
		if (p107.KeyCode == v_u_35.ContlrShiftDown or v_u_38 and p107.KeyCode == v_u_35.MouseShiftDown or not v_u_38 and p107.KeyCode == v_u_35.ShiftDown) and ((v_u_22 and (v_u_27 == "Auto" and (v_u_24 <= 1 and v_u_7.AutoShiftVers == "New")) or (v_u_27 == "Semi" or v_u_27 == "Manual")) and p107.UserInputState == Enum.UserInputState.Begin) then
			if not v_u_46 then
				v_u_46 = true
			end
		elseif (p107.KeyCode == v_u_35.ContlrShiftUp or v_u_38 and p107.KeyCode == v_u_35.MouseShiftUp or not v_u_38 and p107.KeyCode == v_u_35.ShiftUp) and ((v_u_22 and (v_u_27 == "Auto" and (v_u_24 < 1 and v_u_7.AutoShiftVers == "New")) or (v_u_27 == "Semi" or v_u_27 == "Manual")) and p107.UserInputState == Enum.UserInputState.Begin) then
			if not v_u_47 then
				v_u_47 = true
			end
		elseif (p107.KeyCode == v_u_35.ContlrClutch or v_u_38 and p107.KeyCode == v_u_35.MouseClutch or not v_u_38 and p107.KeyCode == v_u_35.Clutch) and v_u_27 == "Manual" then
			if p107.UserInputState == Enum.UserInputState.Begin then
				v_u_48 = true
				v_u_39 = true
			elseif p107.UserInputState == Enum.UserInputState.End then
				v_u_48 = false
				v_u_39 = false
			end
		elseif p107.KeyCode == v_u_35.ContlrPBrake or v_u_38 and p107.KeyCode == v_u_35.MousePBrake or (not v_u_38 and p107.KeyCode == v_u_35.PBrake or not v_u_38 and p107.KeyCode == v_u_35.PBrake2) then
			if p107.UserInputState == Enum.UserInputState.Begin then
				v_u_40 = not v_u_40
			elseif p107.UserInputState == Enum.UserInputState.End and v_u_6.DriveSeat.AssemblyLinearVelocity.Magnitude > 5 then
				v_u_40 = false
			end
		elseif (p107.KeyCode == v_u_35.ContlrToggleTMode or p107.KeyCode == v_u_35.ToggleTransMode) and p107.UserInputState == Enum.UserInputState.Begin then
			local v108 = 1
			for v109, v110 in next, v_u_7.TransModes do
				if v110 == v_u_27 then
					v108 = v109
					break
				end
			end
			local v111 = v108 + 1
			local v112 = #v_u_7.TransModes < v111 and 1 or v111
			v_u_27 = v_u_7.TransModes[v112]
		elseif (v_u_38 or p107.KeyCode ~= v_u_35.Throttle and p107.KeyCode ~= v_u_35.Throttle2) and ((v_u_35.MouseThrottle ~= Enum.UserInputType.MouseButton1 and v_u_35.MouseThrottle ~= Enum.UserInputType.MouseButton2 or p107.UserInputType ~= v_u_35.MouseThrottle) and p107.KeyCode ~= v_u_35.MouseThrottle or not v_u_38) then
			if (v_u_38 or p107.KeyCode ~= v_u_35.Brake and p107.KeyCode ~= v_u_35.Brake2) and ((v_u_35.MouseBrake ~= Enum.UserInputType.MouseButton1 and v_u_35.MouseBrake ~= Enum.UserInputType.MouseButton2 or p107.UserInputType ~= v_u_35.MouseBrake) and p107.KeyCode ~= v_u_35.MouseBrake or not v_u_38) then
				if v_u_38 or p107.KeyCode ~= v_u_35.SteerLeft and p107.KeyCode ~= v_u_35.SteerLeft2 then
					if v_u_38 or p107.KeyCode ~= v_u_35.SteerRight and p107.KeyCode ~= v_u_35.SteerRight2 then
						if p107.KeyCode == v_u_35.ToggleMouseDrive then
							if p107.UserInputState == Enum.UserInputState.End then
								v_u_38 = not v_u_38
								v_u_41 = 0
								v_u_42 = 0
								v_u_43 = 0
							end
						elseif v_u_7.TCSEnabled and (v_u_22 and p107.KeyCode == v_u_35.ToggleTCS) or p107.KeyCode == v_u_35.ContlrToggleTCS then
							if p107.UserInputState == Enum.UserInputState.End then
								v_u_28 = not v_u_28
							end
						elseif (v_u_7.ABSEnabled and (v_u_22 and p107.KeyCode == v_u_35.ToggleABS) or p107.KeyCode == v_u_35.ContlrToggleABS) and p107.UserInputState == Enum.UserInputState.End then
							v_u_29 = not v_u_29
						end
					elseif p107.UserInputState == Enum.UserInputState.Begin then
						v_u_43 = 1
						v_u_45 = true
					else
						if v_u_44 then
							v_u_43 = -1
						else
							v_u_43 = 0
						end
						v_u_45 = false
					end
				elseif p107.UserInputState == Enum.UserInputState.Begin then
					v_u_43 = -1
					v_u_44 = true
				else
					if v_u_45 then
						v_u_43 = 1
					else
						v_u_43 = 0
					end
					v_u_44 = false
				end
			elseif p107.UserInputState == Enum.UserInputState.Begin then
				v_u_42 = 1
			else
				v_u_42 = 0
			end
		elseif p107.UserInputState == Enum.UserInputState.Begin then
			v_u_41 = 1
		else
			v_u_41 = 0
		end
		if p107.UserInputType.Name:find("Gamepad") then
			if p107.KeyCode == v_u_35.ContlrSteer then
				if p107.Position.X >= 0 then
					local v113 = v_u_7.Peripherals.ControlRDZone / 100
					local v114 = math.min(0.99, v113)
					local v115 = p107.Position.X
					if v114 < math.abs(v115) then
						v_u_43 = (p107.Position.X - v114) / (1 - v114)
					else
						v_u_43 = 0
					end
				else
					local v116 = v_u_7.Peripherals.ControlLDZone / 100
					local v117 = math.min(0.99, v116)
					local v118 = p107.Position.X
					if v117 < math.abs(v118) then
						v_u_43 = (p107.Position.X + v117) / (1 - v117)
					else
						v_u_43 = 0
					end
				end
			end
			if p107.KeyCode == v_u_35.ContlrThrottle then
				local v119 = p107.Position.Z
				v_u_41 = math.max(0, v119)
				return
			end
			if p107.KeyCode == v_u_35.ContlrBrake then
				v_u_42 = p107.Position.Z
				return
			end
		end
	end
end
v_u_3.InputBegan:connect(DealWithInput)
v_u_3.InputChanged:connect(DealWithInput)
v_u_3.InputEnded:connect(DealWithInput)
function DealWithMobileInput()
	-- upvalues: (copy) v_u_1, (ref) v_u_10, (copy) v_u_11, (ref) v_u_41, (ref) v_u_42, (ref) v_u_43, (ref) v_u_44, (ref) v_u_45, (copy) v_u_3
	local v120 = script.Parent.Mobile
	v120.Jump.InputBegan:Connect(function(p121)
		-- upvalues: (ref) v_u_1
		if p121.UserInputType == Enum.UserInputType.Touch then
			v_u_1.Character:FindFirstChildWhichIsA("Humanoid").Jump = true
		end
	end)
	v120.ModeSwitch.MouseButton1Click:Connect(function()
		-- upvalues: (ref) v_u_10, (ref) v_u_11
		v_u_10 = v_u_11[(table.find(v_u_11, v_u_10) or 0) + 1]
		if not v_u_10 then
			v_u_10 = v_u_11[1]
		end
	end)
	local v122 = next
	local v123, v124 = v120.Tap:GetChildren()
	for _, v_u_125 in v122, v123, v124 do
		if v_u_125:IsA("ImageButton") then
			v_u_125.InputBegan:Connect(function(p126)
				-- upvalues: (copy) v_u_125, (ref) v_u_41, (ref) v_u_42, (ref) v_u_43, (ref) v_u_44, (ref) v_u_45
				if p126.UserInputType == Enum.UserInputType.Touch then
					v_u_125.ImageColor3 = Color3.fromRGB(178, 178, 178)
					v_u_125.ImageLabel.ImageColor3 = Color3.new(0, 0, 0)
					v_u_125.ImageLabel.ImageTransparency = 0.5
					if v_u_125.Name == "Throttle" then
						v_u_41 = 1
						return
					elseif v_u_125.Name == "Brake" then
						v_u_42 = 1
						return
					elseif v_u_125.Name == "Left" then
						v_u_43 = -1
						v_u_44 = true
					elseif v_u_125.Name == "Right" then
						v_u_43 = 1
						v_u_45 = true
					end
				else
					return
				end
			end)
			v_u_125.InputEnded:Connect(function(p127)
				-- upvalues: (copy) v_u_125, (ref) v_u_41, (ref) v_u_42, (ref) v_u_45, (ref) v_u_43, (ref) v_u_44
				if p127.UserInputType == Enum.UserInputType.Touch then
					v_u_125.ImageColor3 = Color3.new(0, 0, 0)
					v_u_125.ImageLabel.ImageColor3 = Color3.new(1, 1, 1)
					v_u_125.ImageLabel.ImageTransparency = 0.8
					if v_u_125.Name == "Throttle" then
						v_u_41 = 0
						return
					elseif v_u_125.Name == "Brake" then
						v_u_42 = 0
						return
					elseif v_u_125.Name == "Left" then
						if v_u_45 then
							v_u_43 = 1
						else
							v_u_43 = 0
						end
						v_u_44 = false
					elseif v_u_125.Name == "Right" then
						if v_u_44 then
							v_u_43 = -1
						else
							v_u_43 = 0
						end
						v_u_45 = false
					end
				else
					return
				end
			end)
		end
	end
	local v128 = next
	local v129, v130 = v120.Tilt:GetChildren()
	for _, v_u_131 in v128, v129, v130 do
		if v_u_131:IsA("TextButton") then
			v_u_131.InputBegan:Connect(function(p132)
				-- upvalues: (copy) v_u_131, (ref) v_u_41, (ref) v_u_42
				if p132.UserInputType == Enum.UserInputType.Touch then
					if v_u_131.Name == "Throttle" then
						v_u_41 = 1
					elseif v_u_131.Name == "Brake" then
						v_u_42 = 1
					end
				else
					return
				end
			end)
			v_u_131.InputEnded:Connect(function(p133)
				-- upvalues: (copy) v_u_131, (ref) v_u_41, (ref) v_u_42
				if p133.UserInputType == Enum.UserInputType.Touch then
					if v_u_131.Name == "Throttle" then
						v_u_41 = 0
					elseif v_u_131.Name == "Brake" then
						v_u_42 = 0
					end
				else
					return
				end
			end)
		end
	end
	if v_u_3.GyroscopeEnabled then
		v_u_3.DeviceRotationChanged:Connect(function(p134, _)
			-- upvalues: (ref) v_u_10, (ref) v_u_43
			if v_u_10 == "Tilt" then
				local v135 = p134.Position.Z * 2
				v_u_43 = -math.clamp(v135, -1, 1)
			end
		end)
	end
end
DealWithMobileInput()
local v_u_136 = {}
if v_u_7.Config == "FWD" or v_u_7.Config == "AWD" then
	for _, v137 in next, v_u_6.Wheels:GetChildren() do
		if v137.Name == "FL" or (v137.Name == "FR" or v137.Name == "F") then
			table.insert(v_u_136, v137)
		end
	end
end
if v_u_7.Config == "RWD" or v_u_7.Config == "AWD" then
	for _, v138 in next, v_u_6.Wheels:GetChildren() do
		if v138.Name == "RL" or (v138.Name == "RR" or v138.Name == "R") then
			table.insert(v_u_136, v138)
		end
	end
end
local v139 = 0
for _, v140 in next, v_u_136 do
	if v139 < v140.Size.Y then
		v139 = v140.Size.Y
	end
end
function Inputs(p141)
	-- upvalues: (ref) v_u_67, (ref) v_u_41, (copy) v_u_7, (ref) v_u_53, (ref) v_u_42
	local v142 = 60 / (1 / p141)
	if v_u_67 <= v_u_41 then
		local v143 = v_u_41
		local v144 = v_u_67 + v_u_7.ThrotAccel * v142
		v_u_67 = math.min(v143, v144)
	else
		local v145 = v_u_41
		local v146 = v_u_67 - v_u_7.ThrotDecel * v142
		v_u_67 = math.max(v145, v146)
	end
	if v_u_53 <= v_u_42 then
		local v147 = v_u_42
		local v148 = v_u_53 + v_u_7.BrakeAccel * v142
		v_u_53 = math.min(v147, v148)
	else
		local v149 = v_u_42
		local v150 = v_u_53 - v_u_7.BrakeDecel * v142
		v_u_53 = math.max(v149, v150)
	end
end
local v_u_151 = v_u_7.LockToLock * 180 / v_u_7.SteerRatio
local v152 = v_u_151 - v_u_151 * (1 - v_u_7.Ackerman)
local v153 = v_u_151 * 1.2
local v_u_154 = math.min(v152, v153)
function Steering(p155)
	-- upvalues: (ref) v_u_61, (copy) v_u_7, (ref) v_u_38, (copy) v_u_6, (copy) v_u_8, (copy) v_u_2, (ref) v_u_43, (ref) v_u_66, (ref) v_u_154, (ref) v_u_151, (copy) v_u_18, (copy) v_u_17
	local v156 = 60 / (1 / p155)
	local v157 = v_u_61 or (v_u_7.MSteerUsesContlr and v_u_38 or false)
	local v158 = v157 and (v_u_7.ContlrSteerSpeed > 0 and v_u_7.ContlrSteerSpeed or v_u_7.Steerspeed)
	if not v158 then
		local v159 = v_u_7.SteerSpeed
		local v160 = v_u_6.DriveSeat.AssemblyLinearVelocity.Magnitude / (v_u_8.Velocity_mdivs / 3.6) / v_u_7.SteerSpeedDecay
		local v161 = 1 - v_u_7.MinSteerSpeed / 100
		v158 = v159 * (1 - math.min(v160, v161))
	end
	local v162 = v157 and (v_u_7.ContlrReturnSpeed > 0 and v_u_7.ContlrReturnSpeed or v_u_7.ReturnSpeed)
	if not v162 then
		local v163 = v_u_7.ReturnSpeed
		local v164 = v_u_6.DriveSeat.AssemblyLinearVelocity.Magnitude / (v_u_8.Velocity_mdivs / 3.6) / v_u_7.SteerSpeedDecay
		local v165 = 1 - v_u_7.MinSteerSpeed / 100
		v162 = v163 * (1 - math.min(v164, v165))
	end
	if v_u_38 then
		local v166 = v_u_2.ViewSizeX * v_u_7.Peripherals.MSteerWidth / 200
		local v167 = math.max(1, v166)
		local v168 = v_u_7.Peripherals.MSteerDZone / 100
		local v169 = (v_u_2.X - v_u_2.ViewSizeX / 2) / v167
		if math.abs(v169) <= v168 then
			v_u_43 = 0
		else
			local v170 = math.abs(v169) - v168
			local v171 = 1 - v168
			local v172 = math.min(v170, v171)
			v_u_43 = (math.max(v172, 0) / (1 - v168)) ^ v_u_7.MSteerExp * (v169 / math.abs(v169))
		end
	end
	if v_u_66 < v_u_43 then
		if v_u_66 < 0 then
			local v173 = v_u_43
			local v174 = v_u_66 + v162 * v156
			v_u_66 = math.min(v173, v174)
		else
			local v175 = v_u_43
			local v176 = v_u_66 + v158 * v156
			v_u_66 = math.min(v175, v176)
		end
	elseif v_u_66 > 0 then
		local v177 = v_u_43
		local v178 = v_u_66 - v162 * v156
		v_u_66 = math.max(v177, v178)
	else
		local v179 = v_u_43
		local v180 = v_u_66 - v158 * v156
		v_u_66 = math.max(v179, v180)
	end
	local v181 = v_u_6.DriveSeat.AssemblyLinearVelocity.Magnitude / (v_u_8.Velocity_mdivs / 3.6) / (v_u_7.SteerDecay / (v_u_8.Velocity_mdivs / 3.6))
	local v182 = 1 - v_u_7.MinSteer / 100
	local v183 = 1 - math.min(v181, v182)
	local v184 = v_u_6.DriveSeat.AssemblyLinearVelocity.Magnitude / (v_u_8.Velocity_mdivs / 3.6) / (v_u_7.RSteerDecay / (v_u_8.Velocity_mdivs / 3.6))
	local v185 = 1 - v_u_7.MinSteer / 100
	local v186 = 1 - math.min(v184, v185)
	local v187 = next
	local v188, v189 = v_u_6.Wheels:GetChildren()
	for _, v190 in v187, v188, v189 do
		if v190.Name == "F" then
			local v191 = v190.Arm.Steer
			local v192 = v190.Base.CFrame
			local v193 = CFrame.Angles
			local v194 = v_u_66 * v_u_154 * v183
			v191.CFrame = v192 * v193(0, -math.rad(v194), 0)
		elseif v190.Name == "FL" then
			if v_u_66 >= 0 then
				local v195 = v190.Arm.Steer
				local v196 = v190.Base.CFrame
				local v197 = CFrame.Angles
				local v198 = v_u_66 * v_u_151 * v183
				v195.CFrame = v196 * v197(0, -math.rad(v198), 0)
			else
				local v199 = v190.Arm.Steer
				local v200 = v190.Base.CFrame
				local v201 = CFrame.Angles
				local v202 = v_u_66 * v_u_154 * v183
				v199.CFrame = v200 * v201(0, -math.rad(v202), 0)
			end
		elseif v190.Name == "FR" then
			if v_u_66 >= 0 then
				local v203 = v190.Arm.Steer
				local v204 = v190.Base.CFrame
				local v205 = CFrame.Angles
				local v206 = v_u_66 * v_u_154 * v183
				v203.CFrame = v204 * v205(0, -math.rad(v206), 0)
			else
				local v207 = v190.Arm.Steer
				local v208 = v190.Base.CFrame
				local v209 = CFrame.Angles
				local v210 = v_u_66 * v_u_151 * v183
				v207.CFrame = v208 * v209(0, -math.rad(v210), 0)
			end
		elseif v190.Name == "R" then
			if v_u_7.FWSteer ~= "None" then
				if v_u_7.FWSteer == "Static" then
					local v211 = v190.Arm.Steer
					local v212 = v190.Base.CFrame
					local v213 = CFrame.Angles
					local v214 = v_u_66 * v_u_18 * v186
					local v215 = 1 - v_u_6.DriveSeat.Velocity.Magnitude / v_u_7.RSteerSpeed
					local v216 = v214 * math.max(0, v215)
					v211.CFrame = v212 * v213(0, math.rad(v216), 0)
				elseif v_u_7.FWSteer == "Speed" then
					local v217 = v190.Arm.Steer
					local v218 = v190.Base.CFrame
					local v219 = CFrame.Angles
					local v220 = v_u_66 * v_u_18 * v186
					local v221 = v_u_6.DriveSeat.Velocity.Magnitude / v_u_7.RSteerSpeed
					local v222 = v220 * math.min(1, v221)
					v217.CFrame = v218 * v219(0, -math.rad(v222), 0)
				elseif v_u_7.FWSteer == "Both" then
					local v223 = v190.Arm.Steer
					local v224 = v190.Base.CFrame
					local v225 = CFrame.Angles
					local v226 = v_u_66 * v_u_18 * v186
					local v227 = 1 - v_u_6.DriveSeat.Velocity.Magnitude / v_u_7.RSteerSpeed
					local v228 = v226 * math.max(-1, v227)
					v223.CFrame = v224 * v225(0, math.rad(v228), 0)
				end
			end
		elseif v190.Name == "RL" then
			if v_u_7.FWSteer ~= "None" then
				if v_u_7.FWSteer == "Static" then
					if v_u_66 >= 0 then
						local v229 = v190.Arm.Steer
						local v230 = v190.Base.CFrame
						local v231 = CFrame.Angles
						local v232 = v_u_66 * v_u_17 * v186
						local v233 = 1 - v_u_6.DriveSeat.Velocity.Magnitude / v_u_7.RSteerSpeed
						local v234 = v232 * math.max(0, v233)
						v229.CFrame = v230 * v231(0, math.rad(v234), 0)
					else
						local v235 = v190.Arm.Steer
						local v236 = v190.Base.CFrame
						local v237 = CFrame.Angles
						local v238 = v_u_66 * v_u_18 * v186
						local v239 = 1 - v_u_6.DriveSeat.Velocity.Magnitude / v_u_7.RSteerSpeed
						local v240 = v238 * math.max(0, v239)
						v235.CFrame = v236 * v237(0, math.rad(v240), 0)
					end
				elseif v_u_7.FWSteer == "Speed" then
					if v_u_66 >= 0 then
						local v241 = v190.Arm.Steer
						local v242 = v190.Base.CFrame
						local v243 = CFrame.Angles
						local v244 = v_u_66 * v_u_17 * v186
						local v245 = v_u_6.DriveSeat.Velocity.Magnitude / v_u_7.RSteerSpeed
						local v246 = v244 * math.min(1, v245)
						v241.CFrame = v242 * v243(0, -math.rad(v246), 0)
					else
						local v247 = v190.Arm.Steer
						local v248 = v190.Base.CFrame
						local v249 = CFrame.Angles
						local v250 = v_u_66 * v_u_18 * v186
						local v251 = v_u_6.DriveSeat.Velocity.Magnitude / v_u_7.RSteerSpeed
						local v252 = v250 * math.min(1, v251)
						v247.CFrame = v248 * v249(0, -math.rad(v252), 0)
					end
				elseif v_u_7.FWSteer == "Both" then
					if v_u_66 >= 0 then
						local v253 = v190.Arm.Steer
						local v254 = v190.Base.CFrame
						local v255 = CFrame.Angles
						local v256 = v_u_66 * v_u_17 * v186
						local v257 = 1 - v_u_6.DriveSeat.Velocity.Magnitude / v_u_7.RSteerSpeed
						local v258 = v256 * math.max(-1, v257)
						v253.CFrame = v254 * v255(0, math.rad(v258), 0)
					else
						local v259 = v190.Arm.Steer
						local v260 = v190.Base.CFrame
						local v261 = CFrame.Angles
						local v262 = v_u_66 * v_u_18 * v186
						local v263 = 1 - v_u_6.DriveSeat.Velocity.Magnitude / v_u_7.RSteerSpeed
						local v264 = v262 * math.max(-1, v263)
						v259.CFrame = v260 * v261(0, math.rad(v264), 0)
					end
				end
			end
		elseif v190.Name == "RR" and v_u_7.FWSteer ~= "None" then
			if v_u_7.FWSteer == "Static" then
				if v_u_66 >= 0 then
					local v265 = v190.Arm.Steer
					local v266 = v190.Base.CFrame
					local v267 = CFrame.Angles
					local v268 = v_u_66 * v_u_18 * v186
					local v269 = 1 - v_u_6.DriveSeat.Velocity.Magnitude / v_u_7.RSteerSpeed
					local v270 = v268 * math.max(0, v269)
					v265.CFrame = v266 * v267(0, math.rad(v270), 0)
				else
					local v271 = v190.Arm.Steer
					local v272 = v190.Base.CFrame
					local v273 = CFrame.Angles
					local v274 = v_u_66 * v_u_17 * v186
					local v275 = 1 - v_u_6.DriveSeat.Velocity.Magnitude / v_u_7.RSteerSpeed
					local v276 = v274 * math.max(0, v275)
					v271.CFrame = v272 * v273(0, math.rad(v276), 0)
				end
			elseif v_u_7.FWSteer == "Speed" then
				if v_u_66 >= 0 then
					local v277 = v190.Arm.Steer
					local v278 = v190.Base.CFrame
					local v279 = CFrame.Angles
					local v280 = v_u_66 * v_u_18 * v186
					local v281 = v_u_6.DriveSeat.Velocity.Magnitude / v_u_7.RSteerSpeed
					local v282 = v280 * math.min(1, v281)
					v277.CFrame = v278 * v279(0, -math.rad(v282), 0)
				else
					local v283 = v190.Arm.Steer
					local v284 = v190.Base.CFrame
					local v285 = CFrame.Angles
					local v286 = v_u_66 * v_u_17 * v186
					local v287 = v_u_6.DriveSeat.Velocity.Magnitude / v_u_7.RSteerSpeed
					local v288 = v286 * math.min(1, v287)
					v283.CFrame = v284 * v285(0, -math.rad(v288), 0)
				end
			elseif v_u_7.FWSteer == "Both" then
				if v_u_66 >= 0 then
					local v289 = v190.Arm.Steer
					local v290 = v190.Base.CFrame
					local v291 = CFrame.Angles
					local v292 = v_u_66 * v_u_18 * v186
					local v293 = 1 - v_u_6.DriveSeat.Velocity.Magnitude / v_u_7.RSteerSpeed
					local v294 = v292 * math.max(-1, v293)
					v289.CFrame = v290 * v291(0, math.rad(v294), 0)
				else
					local v295 = v190.Arm.Steer
					local v296 = v190.Base.CFrame
					local v297 = CFrame.Angles
					local v298 = v_u_66 * v_u_17 * v186
					local v299 = 1 - v_u_6.DriveSeat.Velocity.Magnitude / v_u_7.RSteerSpeed
					local v300 = v298 * math.max(-1, v299)
					v295.CFrame = v296 * v297(0, math.rad(v300), 0)
				end
			end
		end
		if v190:GetAttribute("SteerDisabled") then
			v190.Arm.Steer.CFrame = v190.Base.CFrame
		end
	end
end
local v_u_301 = v_u_7.FinalDrive * v_u_7.FDMult
local v_u_302 = v_u_301 * 30 / 3.141592653589793
local v_u_303 = (v_u_7.GravComp > 0 and v_u_7.GravComp or workspace.Gravity) * v_u_7.InclineComp / 35
local v_u_304 = v139 * 3.141592653589793 / 60
local v_u_305 = CFrame.Angles(1.5707963267948966, -1.5707963267948966, 0)
local v_u_306 = CFrame.Angles(0, 3.141592653589793, 0)
if not v_u_7.Engine and v_u_7.Electric then
	v_u_7.Redline = v_u_7.E_Redline
	v_u_7.PeakRPM = v_u_7.E_Trans2
	v_u_7.Turbochargers = 0
	v_u_7.Superchargers = 0
	v_u_7.Clutch = false
	v_u_7.IdleRPM = 0
	v_u_7.ClutchType = "Clutch"
	v_u_7.AutoShiftType = "DCT"
	v_u_7.ShiftUpTime = 0.1
	v_u_7.ShiftDnTime = 0.1
end
local v_u_307 = v_u_7.Turbochargers
local v_u_308 = v_u_7.T_Boost * v_u_7.Turbochargers
local _ = v_u_7.Superchargers
local _ = v_u_7.S_Boost * v_u_7.Superchargers
wait()
function Auto()
	-- upvalues: (copy) v_u_136, (copy) v_u_81, (ref) v_u_22, (copy) v_u_7, (ref) v_u_24, (ref) v_u_48, (ref) v_u_53, (copy) v_u_6, (ref) v_u_23, (ref) v_u_47, (ref) v_u_68, (copy) v_u_302, (ref) v_u_46, (copy) v_u_304, (ref) v_u_26, (copy) v_u_301, (ref) v_u_67
	local v309 = 0
	for _, v310 in next, v_u_136 do
		if v309 < v_u_81[v310.Name] then
			v309 = v_u_81[v310.Name]
		end
	end
	if v_u_22 then
		if v_u_7.AutoShiftVers == "Old" and v_u_24 == 0 then
			v_u_24 = 1
			v_u_48 = false
		end
		if v_u_24 >= 1 then
			if v_u_24 == 1 and (v_u_53 > 0 and (v_u_6.DriveSeat.AssemblyLinearVelocity.Magnitude < 5 and v_u_7.AutoShiftVers == "Old")) then
				v_u_24 = -1
				v_u_48 = false
				return
			end
			if v_u_6.DriveSeat.AssemblyLinearVelocity.Magnitude > 5 and v_u_7.ClutchType ~= "CVT" then
				if v_u_7.AutoShiftMode == "RPM" then
					if v_u_23 > v_u_7.ShiftRPM + v_u_7.AutoUpThresh then
						if not (v_u_47 or v_u_68) then
							v_u_47 = true
							return
						end
					else
						local v311 = v309 * v_u_7.Ratios[v_u_24 + 1] * v_u_302
						local v312 = v_u_7.Redline + 100
						local v313 = math.min(v311, v312)
						if math.max(v313, 0) < v_u_7.ShiftRPM - v_u_7.AutoDownThresh and (v_u_24 > 1 and not (v_u_46 or v_u_68)) then
							v_u_46 = true
							return
						end
					end
				else
					local v314 = v_u_6.DriveSeat.AssemblyLinearVelocity.Magnitude
					local v315 = v_u_304 * (v_u_7.ShiftRPM + v_u_7.AutoUpThresh) / v_u_26 / v_u_301
					if math.ceil(v315) < v314 then
						if not (v_u_47 or v_u_68) then
							v_u_47 = true
							return
						end
					else
						local v316 = v_u_6.DriveSeat.AssemblyLinearVelocity.Magnitude
						local v317 = v_u_304 * (v_u_7.ShiftRPM - v_u_7.AutoDownThresh) / v_u_7.Ratios[v_u_24 + 1] / v_u_301
						if v316 < math.ceil(v317) and (v_u_24 > 1 and not (v_u_46 or v_u_68)) then
							v_u_46 = true
							return
						end
					end
				end
			end
		elseif v_u_67 > 0 and (v_u_6.DriveSeat.AssemblyLinearVelocity.Magnitude < 5 and v_u_7.AutoShiftVers == "Old") then
			v_u_24 = 1
			v_u_48 = false
		end
	end
end
function Gear()
	-- upvalues: (copy) v_u_136, (copy) v_u_81, (ref) v_u_47, (ref) v_u_68, (ref) v_u_27, (ref) v_u_48, (copy) v_u_7, (ref) v_u_67, (ref) v_u_24, (ref) v_u_22, (ref) v_u_23, (copy) v_u_302, (ref) v_u_46
	local v318 = 0
	for _, v319 in next, v_u_136 do
		if v318 < v_u_81[v319.Name] then
			v318 = v_u_81[v319.Name]
		end
	end
	if v_u_47 and not v_u_68 then
		if v_u_27 == "Manual" and not v_u_48 or (v_u_27 == "Manual" and (v_u_7.ClutchRel and v_u_67 > 0) or (v_u_24 == #v_u_7.Ratios - 2 or v_u_27 ~= "Manual" and not v_u_22)) then
			v_u_47 = false
			return
		end
		local v320 = v_u_24 + 3
		local v321 = #v_u_7.Ratios
		local v322 = math.min(v320, v321)
		if v_u_27 ~= "Manual" and v_u_7.ClutchType ~= "CVT" then
			v_u_68 = true
			if v_u_24 > 0 then
				if v_u_7.AutoShiftType == "DCT" then
					wait(v_u_7.ShiftUpTime)
				elseif v_u_7.AutoShiftType == "Rev" then
					repeat
						wait()
						local v323 = v_u_23
						local v324 = v318 * v_u_7.Ratios[v322] * v_u_302
						local v325 = v_u_7.Redline - v_u_7.RevBounce
						local v326 = math.min(v324, v325)
						local v327 = v_u_7.IdleRPM + v_u_7.ClutchIdle
					until v323 <= math.max(v326, v327) or (not v_u_22 or v_u_46)
				end
			end
		end
		v_u_47 = false
		v_u_68 = false
		if v_u_27 ~= "Manual" and not v_u_22 then
			return
		end
		if v322 >= 4 and v_u_7.ClutchType == "CVT" then
			return
		end
		local v328 = v_u_24 + 1
		local v329 = #v_u_7.Ratios - 2
		v_u_24 = math.min(v328, v329)
		if v_u_27 ~= "Manual" or v_u_27 == "Manual" and (v_u_24 == 1 and v_u_22) then
			v_u_48 = false
		end
	end
	if v_u_46 and not v_u_68 then
		if v_u_27 == "Manual" and not v_u_48 or (v_u_24 == -1 or v_u_27 ~= "Manual" and not v_u_22) then
			v_u_46 = false
			return
		end
		local v330 = v_u_24 + 1
		local v331 = #v_u_7.Ratios
		local v332 = math.min(v330, v331)
		if v_u_27 ~= "Manual" then
			v_u_68 = true
			if v_u_24 > 1 then
				if v_u_7.AutoShiftType == "DCT" then
					wait(v_u_7.ShiftDnTime)
				elseif v_u_7.AutoShiftType == "Rev" then
					repeat
						wait()
						local v333 = v_u_23
						local v334 = v318 * v_u_7.Ratios[v332] * v_u_302
						local v335 = v_u_7.Redline - v_u_7.RevBounce
						local v336 = math.min(v334, v335)
						local v337 = v_u_7.IdleRPM + v_u_7.ClutchIdle
					until math.max(v336, v337) <= v333 or (not v_u_22 or v_u_47)
				end
			end
		end
		v_u_46 = false
		v_u_68 = false
		if v_u_27 ~= "Manual" and not v_u_22 then
			return
		end
		local v338 = v_u_24 - 1
		v_u_24 = math.max(v338, -1)
		if v_u_27 ~= "Manual" or v_u_27 == "Manual" and (v_u_24 == -1 and v_u_22) then
			v_u_48 = false
		end
	end
end
local v_u_339 = 0
local v_u_340 = 1
local v_u_341 = false
local v_u_342 = tick()
local v_u_343 = v19[v_u_7.Engine]
local v_u_344 = v_u_7.Torque
local _ = v_u_7.Redline
local _ = v_u_7.IdleRPM
local v_u_345 = v_u_7.ValveSprings
local v_u_346 = v_u_7.ValveFloatSharpness
local v_u_347 = v_u_7.VVLSharpness
local v_u_348 = v_u_7.VVLTime
local v_u_349 = v_u_7.VVLValue
local v_u_350 = v_u_7.HighPerf
local v_u_351 = v_u_7.LowPerf
local v_u_352 = v_u_7.LowPerfSpread
local v_u_353 = v_u_7.ExhaustPressure
local v_u_354 = v_u_7.HorsepowerLimit
local v_u_355 = v19[v_u_7.Electric]
local v_u_356 = v_u_7.E_Torque
local _ = v_u_7.E_Redline
local v_u_357 = v_u_7.E_DropSlope
local v_u_358 = v_u_7.E_TorqueDropRPM
local v_u_359 = v_u_7.E_TorqueDropCurve
local v_u_360 = v_u_7.E_TorqueDropSpread
local v_u_361 = v_u_7.Turbochargers
local v_u_362 = v_u_7.T_Boost
local v_u_363 = v_u_7.T_ExPressFactor
local v_u_364 = v_u_7.T_ExPressInf
local v_u_365 = v_u_7.T_SpoolTimeOffset
local v_u_366 = v_u_7.T_Efficiency
local v_u_367 = v_u_7.T_WGMaxPress
local _ = v_u_7.T_SpoolFactor
local v_u_368 = v_u_7.T_MinBoost
local v_u_369 = v_u_7.Superchargers
local v_u_370 = v_u_7.S_Boost
local v_u_371 = v_u_7.S_HighPerf
local v_u_372 = v_u_7.S_StartBoost
local v_u_373 = v_u_7.S_Efficiency
function Engine(p374)
	-- upvalues: (copy) v_u_6, (copy) v_u_81, (ref) v_u_72, (copy) v_u_136, (ref) v_u_26, (copy) v_u_302, (copy) v_u_7, (ref) v_u_25, (ref) v_u_24, (ref) v_u_69, (ref) v_u_68, (ref) v_u_22, (ref) v_u_48, (ref) v_u_56, (ref) v_u_341, (ref) v_u_57, (ref) v_u_23, (ref) v_u_47, (ref) v_u_46, (ref) v_u_27, (ref) v_u_53, (ref) v_u_67, (ref) v_u_52, (ref) v_u_342, (ref) v_u_39, (ref) v_u_71, (copy) v_u_8, (ref) v_u_339, (copy) v_u_9, (ref) v_u_82, (ref) v_u_55, (ref) v_u_308, (ref) v_u_307, (ref) v_u_73, (copy) v_u_20, (copy) v_u_21, (ref) v_u_83, (copy) v_u_343, (copy) v_u_344, (copy) v_u_346, (copy) v_u_345, (copy) v_u_352, (copy) v_u_351, (copy) v_u_350, (copy) v_u_347, (copy) v_u_348, (copy) v_u_349, (ref) v_u_58, (copy) v_u_368, (copy) v_u_362, (copy) v_u_361, (ref) v_u_59, (copy) v_u_353, (copy) v_u_365, (copy) v_u_363, (copy) v_u_364, (copy) v_u_367, (ref) v_u_60, (ref) v_u_74, (copy) v_u_366, (ref) v_u_75, (ref) v_u_62, (copy) v_u_369, (copy) v_u_370, (copy) v_u_371, (copy) v_u_372, (ref) v_u_63, (copy) v_u_373, (ref) v_u_64, (ref) v_u_65, (ref) v_u_76, (ref) v_u_77, (copy) v_u_355, (copy) v_u_356, (copy) v_u_357, (copy) v_u_358, (copy) v_u_359, (copy) v_u_360, (ref) v_u_79, (ref) v_u_80, (copy) v_u_354, (ref) v_u_50, (copy) v_u_301, (ref) v_u_31, (copy) v_u_303, (copy) v_u_305, (copy) v_u_306, (ref) v_u_29, (ref) v_u_54, (ref) v_u_70, (copy) v_u_51, (ref) v_u_40, (ref) v_u_340, (ref) v_u_28, (ref) v_u_84, (ref) v_u_85, (copy) v_u_49, (copy) v_u_12, (copy) v_u_16, (copy) v_u_14, (copy) v_u_13, (copy) v_u_15
	local v375 = 60 / (1 / p374)
	local v376 = 0
	local v377 = 0
	local v378 = 0
	local v379 = 0
	for _, v380 in next, v_u_6.Wheels:GetChildren() do
		if v380.Name == "FL" or (v380.Name == "FR" or v380.Name == "F") then
			v376 = v376 + v_u_81[v380.Name]
			v377 = v377 + 1
		elseif v380.Name == "RL" or (v380.Name == "RR" or v380.Name == "R") then
			v378 = v378 + v_u_81[v380.Name]
			v379 = v379 + 1
		end
	end
	local _ = (v376 / v377 + v378 / v379) / 2
	local v381 = v_u_72
	local v382 = 0
	local v383 = 0
	for _, v384 in next, v_u_136 do
		v382 = v382 + v_u_81[v384.Name]
		v383 = v383 + 1
	end
	local v385 = v382 / v383
	local v386 = v385 * v_u_26 * v_u_302
	if v_u_7.ClutchType == "CVT" then
		local v387 = v_u_7.CVTRPM * v_u_72 / (v385 * v_u_302)
		local v388 = v_u_7.CVTMinRatio
		local v389 = v_u_7.CVTMaxRatio
		v_u_25 = math.clamp(v387, v388, v389)
	end
	v_u_26 = v_u_7.ClutchType == "CVT" and v_u_25 or v_u_7.Ratios[v_u_24 + 2]
	v_u_69 = (v_u_7.Redline + 100) / (v_u_302 * v_u_26)
	if (v_u_24 == 0 or v_u_68) and v_u_22 then
		v_u_48 = true
		v_u_56 = 1
		v_u_341 = false
	end
	local v390 = v_u_57 - v_u_7.Flywheel
	v_u_57 = math.max(v390, 0)
	if v_u_56 == 1 then
		local v391 = (v_u_23 - v386) / 1000 * v_u_72 * v_u_7.FlywheelEnergy
		v_u_57 = math.max(v391, 0)
	end
	local v392 = v_u_7.Redline + 100
	local v393 = v_u_7.Stall and v_u_7.Clutch and 0 or 1
	if v_u_68 and v_u_47 then
		v_u_72 = v_u_7.IdleThrottle / 100
	elseif v_u_68 and v_u_46 then
		v_u_72 = v_u_7.ShiftThrot / 100
	elseif v_u_7.AutoShiftVers == "Old" and (v_u_24 == -1 and v_u_27 == "Auto") then
		v_u_72 = v_u_53
	else
		local v394 = v_u_67
		local v395 = v_u_7.IdleThrottle / 100
		v_u_72 = math.max(v394, v395)
	end
	if v_u_7.AutoShiftVers == "Old" and (v_u_24 == -1 and v_u_27 == "Auto") then
		v_u_52 = v_u_67
	else
		v_u_52 = v_u_53
	end
	if not v_u_22 then
		v_u_342 = tick()
		v_u_56 = 1
		if not script.Parent.Starting.Value then
			v_u_72 = 0
		end
	end
	if (v_u_48 and v_u_24 == 0 or v_u_39 and v_u_24 ~= 0) and (v_u_7.NeutralLimit and (v_u_24 == 0 and not v_u_7.LimitClutch or v_u_7.LimitClutch)) then
		v392 = v_u_7.NeutralRevRPM
	end
	if v_u_23 >= v_u_7.Redline then
		v_u_71 = true
	elseif v_u_23 < v_u_7.Redline - v_u_7.RevBounce then
		v_u_71 = false
	end
	if v_u_71 then
		v_u_72 = v_u_7.IdleThrottle / 100
	end
	local v396 = v_u_24 < 0 and v_u_7.ReverseSpeed or v_u_7.SpeedLimit
	if v396 > 0 and v_u_6.DriveSeat.AssemblyLinearVelocity.Magnitude >= v396 - v_u_7.SLimitGradient then
		local v397 = v_u_72
		local v398 = (v396 - v_u_6.DriveSeat.AssemblyLinearVelocity.Magnitude / (v_u_8.Velocity_mdivs / 3.6)) / v_u_7.SLimitGradient
		local v399 = math.max(v398, 0)
		local v400 = math.min(v397, v399)
		local v401 = v_u_7.IdleThrottle / 100
		v_u_72 = math.max(v400, v401)
	end
	if v_u_23 < v_u_7.IdleRPM and v_u_22 then
		local v402 = v_u_72
		local v403 = (v_u_7.IdleRPM - v_u_23) / 400
		local v404 = math.clamp(v403, 0, 1)
		v_u_72 = math.max(v402, v404)
	end
	if (v_u_7.Engine or v_u_7.Electric) and not script.Parent.Starting.Value then
		local v405 = v_u_23 - v_u_7.RevDecay * v375 + v_u_7.RevAccel * v381 * v_u_9.Torque.Value * v375
		local v406 = v_u_23 - v_u_7.IdleRPM
		local v407 = math.max(v406, 0)
		local v408 = v_u_7.Redline - v_u_7.IdleRPM
		local v409 = v407 / math.max(v408, 1)
		local v410 = v405 - math.clamp(v409, 0, 1) * v_u_7.RevDecayRPM * v375
		v_u_339 = math.clamp(v410, 1, v392)
	end
	if script.Parent.Starting.Value then
		if v_u_23 > v_u_7.StartRPM then
			script.Parent.IsOn.Value = true
			script.Parent.Starting.Value = false
			v_u_72 = 0
		else
			v_u_339 = v_u_339 + v_u_7.StartRPMAccel
			v_u_72 = 1
		end
	end
	if v_u_7.Clutch then
		if v_u_9.AutoClutch and v_u_22 then
			if v_u_7.ClutchType == "Clutch" or v_u_7.ClutchType == "CVT" then
				if v_u_48 then
					v_u_82 = 1
				end
				v_u_82 = v_u_82 * (v_u_7.ClutchEngage / 100)
				local v411 = v_u_23 * v_u_7.ClutchRPMMult / v_u_7.Redline
				local v412 = math.max(v411, 0)
				local v413 = v_u_7.ClutchMode == "New" and 0 or v412
				local v414 = v_u_24
				local v415 = script.Parent.Values.Velocity.Value.Magnitude / (v_u_8.Velocity_mdivs / 3.6) / v_u_7.SpeedEngage / math.abs(v414) + v413 - v_u_82
				v_u_55 = math.min(v415, 1)
			elseif v_u_7.ClutchType == "TorqueConverter" and v_u_7.TQLock then
				if v_u_72 <= v_u_7.IdleThrottle / 100 and script.Parent.Values.Velocity.Value.Magnitude / (v_u_8.Velocity_mdivs / 3.6) < v_u_7.SpeedEngage or v_u_72 > v_u_7.IdleThrottle / 100 and (v_u_23 < v_u_7.RPMEngage and v386 < v_u_7.RPMEngage) then
					local v416 = v_u_55 * (v_u_7.ClutchEngage / 100)
					v_u_55 = math.min(v416, 1)
				else
					local v417 = v_u_55 * (v_u_7.ClutchEngage / 100) + (1 - v_u_7.ClutchEngage / 100)
					v_u_55 = math.min(v417, 1)
				end
			elseif v_u_7.ClutchType == "TorqueConverter" and not v_u_7.TQLock then
				local v418 = v_u_23 / v_u_7.Redline * 0.7
				v_u_55 = math.min(v418, 1)
			end
			if v_u_48 then
				v_u_56 = 1
			else
				local v419 = 1 - v_u_55
				v_u_56 = math.min(v419, 1)
			end
			v_u_341 = v_u_56 <= 0.01 and true or v_u_341
		else
			v_u_341 = v_u_7.Stall
			v_u_56 = script.Parent.Values.Clutch.Value
		end
	else
		v_u_341 = false
		if v_u_48 or v_u_68 then
			v_u_56 = 1
		else
			v_u_56 = 0
		end
	end
	if v_u_71 or script.Parent.Starting.Value then
		v_u_56 = 1
	end
	if v_u_23 <= v_u_7.IdleRPM + v_u_7.ClutchIdle and v_u_22 then
		local v420 = v_u_56
		local v421 = (v_u_7.IdleRPM + v_u_7.ClutchIdle - v_u_23) / 100
		local v422 = math.clamp(v421, 0, 1)
		v_u_56 = math.max(v420, v422)
	end
	local v423 = v_u_339 * v_u_56 + v386 * (1 - v_u_56)
	local v424 = v_u_7.Redline + 100
	local v425 = math.min(v423, v424)
	local v426 = math.max(v425, v393)
	local v427 = v426 - v_u_23
	local v428 = math.abs(v427) / (v_u_7.Flywheel * v375)
	local v429 = v_u_48 and 0 or math.min(v428, 0.9)
	v_u_23 = v_u_23 * v429 + v426 * (1 - v429)
	local v430 = v_u_23
	v_u_23 = math.clamp(v430, 1, v392)
	if v_u_23 <= v_u_7.IdleRPM / 4 and (v_u_341 and tick() - v_u_342 >= 0.2) then
		script.Parent.IsOn.Value = not v_u_7.Stall
	end
	local _ = v_u_308 / v_u_307
	if v_u_73 < v_u_72 and (v_u_7.Engine and v_u_7.Superchargers > 0) then
		v_u_73 = v_u_20(v_u_73 + v_u_7.S_Sensitivity, v_u_72)
	else
		v_u_73 = v_u_21(v_u_73 - v_u_7.S_Sensitivity, v_u_72)
	end
	local v431 = v_u_73
	local v432 = v_u_23 / 1000
	if v_u_7.Engine then
		local v433 = v_u_343
		local v434 = v_u_344 / 100 - (v_u_346 ^ (v432 - v_u_345) + v_u_352 ^ (v432 - v_u_351)) + (v_u_350 / 10 * v432 + v_u_21(-(1 - v_u_347) ^ (v432 - v_u_348) + v_u_349, 0))
		local v435 = v_u_7.Roughness
		local v436 = 250 * v432 * tick()
		local v437 = v435 * math.sin(v436)
		local v438 = 100 * v432
		local v439 = v437 / math.max(v438, 1)
		local v440 = -v_u_7.Roughness
		local v441 = v_u_7.Roughness
		v_u_83 = 100 * (v433 * v_u_21(v434 + math.clamp(v439, v440, v441), 0)) * (v_u_23 < 10 and 0 or 1)
		v_u_58 = v_u_83 * v432 / 5.252
		if v_u_7.Turbochargers == 0 then
			v_u_75 = 0
			v_u_74 = 0
		else
			local v442 = not v_u_22 and 0 or v_u_368 / 100 * v_u_362 * v_u_361
			local v443 = v_u_72 ^ v_u_7.T_SpoolFactor * v_u_20(v_u_21(v_u_21(v_u_353 * (v_u_58 / 100) - v_u_365, 0) ^ v_u_363 + v_u_364 * (v_u_353 * (v_u_58 / 100)), 0), v_u_361 * (v_u_362 + v_u_21(v_u_353 * (v_u_58 / 100) - v_u_367, 0)))
			v_u_59 = math.max(v443, v442)
			if v_u_60 < v_u_59 then
				local v444 = v_u_60 + v_u_7.T_SpoolIncrease * v_u_72
				local v445 = v_u_59
				local v446 = math.min(v444, v445)
				v_u_60 = math.max(v446, v442)
			elseif v_u_59 < v_u_60 then
				local v447 = v_u_60 * v_u_7.T_SpoolDecrease
				local v448 = v_u_59
				local v449 = math.max(v447, v448)
				v_u_60 = math.max(v449, v442)
			end
			v_u_74 = v_u_21(100 * v_u_366 * v_u_60, 0)
			v_u_75 = v_u_74 * v432 / 5.252
		end
		if v_u_7.Superchargers == 0 then
			v_u_64 = 0
			v_u_63 = 0
		else
			v_u_62 = v431 * v_u_369 * v_u_21(v_u_370 / 10 * v432 - v_u_371 ^ v432 + v_u_372, 0)
			v_u_63 = 100 * (v_u_373 * v_u_62)
			v_u_64 = v_u_63 * v432 / 5.252
		end
		v_u_65 = v_u_75 + v_u_64
		v_u_76 = v_u_74 + v_u_63
	else
		v_u_58 = 0
		v_u_83 = 0
		v_u_75 = 0
		v_u_74 = 0
		v_u_64 = 0
		v_u_63 = 0
		v_u_65 = 0
		v_u_76 = 0
	end
	if v_u_7.Electric and v_u_24 ~= 0 then
		v_u_77 = v_u_21(100 * (v_u_355 * (v_u_356 / 100 - v_u_21(v_u_357 * v432 - v_u_357 * (v_u_358 / 1000), 0) + v_u_359 * v_u_20(v_u_360 ^ (v432 - v_u_358 / 1000) - 1, 0))), 0)
		v_u_79 = v_u_77 * v432 / 5.252
	else
		v_u_79 = 0
		v_u_77 = 0
	end
	local v450 = v_u_20(v_u_83 + v_u_76 + v_u_77, v_u_354 > 0 and (v_u_354 * (5.252 / v432) or (1 / 0)) or (1 / 0))
	v_u_80 = math.clamp(v450, 0, 1000000)
	v_u_50 = v_u_80 * v432 / 5.252
	v_u_80 = v_u_80 * (v_u_26 * v_u_301)
	local v451 = v_u_31.LookVector.Y * v_u_303
	if v_u_24 == -1 then
		v451 = -v451
	end
	local v452 = v_u_80
	local v453 = 1 + v451
	v_u_80 = v452 * math.max(1, v453)
	for _, v454 in next, v_u_6.Wheels:GetChildren() do
		local _ = (CFrame.new(v454.Position - (v454.Arm.CFrame * v_u_305).lookVector, v454.Position) * v_u_306).lookVector
		local _ = v454.Name == "FL" or v454.Name == "RL"
		local v455 = 1
		local v456 = 1
		local v457 = 1
		local v458 = 1
		if v454.Name == "FR" then
			local v459 = (v_u_81[v454.Name] / v_u_81.FL - 1) * (v_u_7.FDiffPreload / 10)
			local v460 = 1 - (v_u_7.FDiffPower / 100 * v459 * v_u_72 + v_u_7.FDiffCoast / 100 * v459 * (1 - v_u_72))
			local v461 = math.min(2, v460)
			local v462 = math.max(0, v461) * 100
			v456 = math.ceil(v462) / 100
			v458 = 2 - v456
		elseif v454.Name == "FL" then
			local v463 = (v_u_81[v454.Name] / v_u_81.FR - 1) * (v_u_7.FDiffPreload / 10)
			local v464 = 1 - (v_u_7.FDiffPower / 100 * v463 * v_u_72 + v_u_7.FDiffCoast / 100 * v463 * (1 - v_u_72))
			local v465 = math.min(2, v464)
			local v466 = math.max(0, v465) * 100
			v458 = math.ceil(v466) / 100
			v456 = 2 - v458
		elseif v454.Name == "RR" then
			local v467 = (v_u_81[v454.Name] / v_u_81.RL - 1) * (v_u_7.RDiffPreload / 10)
			local v468 = 1 - (v_u_7.RDiffPower / 100 * v467 * v_u_72 + v_u_7.RDiffCoast / 100 * v467 * (1 - v_u_72))
			local v469 = math.min(2, v468)
			local v470 = math.max(0, v469) * 100
			v455 = math.ceil(v470) / 100
			v457 = 2 - v455
		elseif v454.Name == "RL" then
			local v471 = (v_u_81[v454.Name] / v_u_81.RR - 1) * (v_u_7.RDiffPreload / 10)
			local v472 = 1 - (v_u_7.RDiffPower / 100 * v471 * v_u_72 + v_u_7.RDiffCoast / 100 * v471 * (1 - v_u_72))
			local v473 = math.min(2, v472)
			local v474 = math.max(0, v473) * 100
			v457 = math.ceil(v474) / 100
			v455 = 2 - v457
		end
		local v475 = script.Parent.IsOn.Value and 1 or 0
		local v476 = v_u_72
		local v477 = v_u_52
		local v478 = v_u_48 and 0 or 1
		local v479 = v_u_23 < v_u_7.IdleRPM and 0 or v478
		local v480 = (v_u_80 + v_u_57) / #v_u_136
		local v481 = 1
		if v_u_29 and v477 > 0 then
			local v482 = v454.RotVelocity.Magnitude * (v454.Size.Y / 2) / (v_u_8.Velocity_mdivs / 3.6) - v454.Velocity.Magnitude / (v_u_8.Velocity_mdivs / 3.6)
			if math.abs(v482) - v_u_7.ABSThreshold > 0 then
				local v483 = v_u_7.ABSLimit / 100
				v481 = math.max(0, v483)
			end
		end
		if v481 < 1 then
			v_u_54 = true
		end
		v_u_70 = v_u_70 + v481
		v_u_51[v454.Name] = 1 - v481
		local v484 = v_u_40 == true and 1 or 0
		local v485 = false
		for _, v486 in next, v_u_136 do
			if v486 == v454 then
				v485 = true
			end
		end
		if v485 then
			if v_u_7.Config == "AWD" then
				local v487 = v_u_7.TorqueVector + 1
				if string.find(v454.Name, "F") then
					v480 = v480 * (2 - v487)
				elseif string.find(v454.Name, "R") then
					v480 = v480 * v487
				end
			end
			v_u_340 = 1
			if v_u_28 and v476 > 0 then
				local v488 = v454.RotVelocity.Magnitude * (v454.Size.Y / 2) / (v_u_8.Velocity_mdivs / 3.6) - v454.Velocity.Magnitude / (v_u_8.Velocity_mdivs / 3.6)
				local v489 = math.abs(v488) - v_u_7.TCSThreshold
				local v490 = math.max(0, v489) / v_u_7.TCSGradient
				v_u_340 = 1 - math.min(v490, 1) * (1 - v_u_7.TCSLimit / 100)
			end
			if v_u_340 < 1 then
				v_u_84 = true
			end
			v_u_85 = v_u_85 + v_u_340
			v_u_49[v454.Name] = 1 - v_u_340
			local v491 = v_u_24 == -1 and -1 or 1
			local v492 = v480 * 1.356 * v_u_8.Torque_nm * (60 / workspace:GetRealPhysicsFPS()) * v476 * v_u_340 * v475 * v479
			if v454.Name == "RR" then
				v454["#AV"].MotorMaxTorque = v492 * v455 * 1
			elseif v454.Name == "RL" then
				v454["#AV"].MotorMaxTorque = v492 * v457 * 1
			elseif v454.Name == "FR" then
				v454["#AV"].MotorMaxTorque = v492 * v456 * 1
			elseif v454.Name == "FL" then
				v454["#AV"].MotorMaxTorque = v492 * v458 * 1
			else
				v454["#AV"].MotorMaxTorque = v492 * 1
			end
			v454["#AV"].AngularVelocity = v_u_69 * v491
			if string.find(v454.Name, "F") then
				v454["#BV"].MotorMaxTorque = v_u_12 * (60 / workspace:GetRealPhysicsFPS()) * v477 * v481 + v_u_16 * ((1 - v476) * (v_u_23 / v_u_7.Redline)) + v_u_14 * v484
			else
				v454["#BV"].MotorMaxTorque = v_u_13 * (60 / workspace:GetRealPhysicsFPS()) * v477 * v481 + v_u_16 * ((1 - v476) * (v_u_23 / v_u_7.Redline)) + v_u_15 * v484
			end
		else
			v454["#AV"].MotorMaxTorque = 0
			v454["#AV"].AngularVelocity = 0
			if string.find(v454.Name, "F") then
				v454["#BV"].MotorMaxTorque = v_u_12 * (60 / workspace:GetRealPhysicsFPS()) * v477 * v481 + v_u_14 * v484
			else
				v454["#BV"].MotorMaxTorque = v_u_13 * (60 / workspace:GetRealPhysicsFPS()) * v477 * v481 + v_u_15 * v484
			end
		end
	end
end
function Suspension()
	-- upvalues: (copy) v_u_6, (copy) v_u_7, (copy) v_u_8
	local v493 = next
	local v494, v495 = v_u_6.Wheels:GetChildren()
	for _, v496 in v493, v494, v495 do
		local v497 = v496:FindFirstChild("Spring", true)
		if v497 then
			local v498 = v497.CurrentLength - v_u_7.RPreCompress - v497.MinLength
			local v499 = v_u_7.RCompressLim
			local v500 = (1 - math.min(v498, v499) / v_u_7.RCompressLim) / (v_u_7.RSusCompAmt / 100)
			if string.find(v496.Name, "F") then
				local v501 = v497.CurrentLength - v_u_7.FPreCompress - v497.MinLength
				local v502 = v_u_7.FCompressLim
				v500 = (1 - math.min(v501, v502) / v_u_7.FCompressLim) / (v_u_7.RSusCompAmt / 100)
			end
			v497.Stiffness = (math.clamp(v500, 0, 1) * (v_u_7.FSusCompStiff - v_u_7.FSusStiffness) + v_u_7.FSusStiffness) * 9806.65 * v_u_8.Stiffness_Ndivm
		end
	end
end
function Flip()
	-- upvalues: (copy) v_u_6, (ref) v_u_86, (ref) v_u_30
	if (v_u_6.DriveSeat.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)).lookVector.y > 0.1 or v_u_86 then
		v_u_30 = tick()
	elseif tick() - v_u_30 >= 3 then
		v_u_86 = true
		local v503 = v_u_6.DriveSeat.Flip
		v503.maxTorque = Vector3.new(10000, 0, 10000)
		v503.P = 3000
		v503.D = 500
		wait(1)
		v503.maxTorque = Vector3.new(0, 0, 0)
		v503.P = 0
		v503.D = 0
		v_u_86 = false
	end
end
local v504 = require(v_u_6["A-Chassis Tune"].README)
print("A-Chassis, Version " .. v504)
game:GetService("RunService").Heartbeat:connect(function(p505)
	-- upvalues: (ref) v_u_85, (copy) v_u_136, (ref) v_u_70, (copy) v_u_6, (ref) v_u_84, (ref) v_u_54, (ref) v_u_22, (ref) v_u_37, (ref) v_u_61, (copy) v_u_3, (ref) v_u_31, (copy) v_u_9, (ref) v_u_24, (ref) v_u_26, (ref) v_u_23, (ref) v_u_60, (ref) v_u_62, (ref) v_u_58, (ref) v_u_79, (ref) v_u_75, (ref) v_u_64, (ref) v_u_65, (ref) v_u_50, (ref) v_u_83, (ref) v_u_77, (ref) v_u_74, (ref) v_u_63, (ref) v_u_76, (copy) v_u_354, (copy) v_u_20, (ref) v_u_27, (ref) v_u_72, (ref) v_u_52, (ref) v_u_41, (ref) v_u_42, (ref) v_u_56, (ref) v_u_66, (ref) v_u_43, (ref) v_u_40, (ref) v_u_28, (ref) v_u_29, (ref) v_u_38, (copy) v_u_49, (copy) v_u_51, (copy) v_u_78, (copy) v_u_81, (ref) v_u_33, (copy) v_u_7, (ref) v_u_10, (copy) v_u_32
	v_u_85 = #v_u_136
	v_u_70 = #v_u_6.Wheels:GetChildren()
	v_u_84 = false
	v_u_54 = false
	v_u_22 = script.Parent.IsOn.Value
	v_u_37 = script.Parent.ControlsOpen.Value
	v_u_61 = string.find(v_u_3:GetLastInputType().Name, "Gamepad") and true or false
	v_u_31 = GetCarCenter()
	v_u_9.Gear.Value = v_u_24
	v_u_9.CurrentRatio.Value = v_u_26
	v_u_9.RPM.Value = v_u_23
	v_u_9.Boost.Value = v_u_60 + v_u_62
	v_u_9.BoostTurbo.Value = v_u_60
	v_u_9.BoostSuper.Value = v_u_62
	v_u_9.HpNatural.Value = v_u_58
	v_u_9.HpElectric.Value = v_u_79
	v_u_9.HpTurbo.Value = v_u_75
	v_u_9.HpSuper.Value = v_u_64
	v_u_9.HpBoosted.Value = v_u_65
	v_u_9.Horsepower.Value = v_u_50
	v_u_9.TqNatural.Value = v_u_83
	v_u_9.TqElectric.Value = v_u_77
	v_u_9.TqTurbo.Value = v_u_74
	v_u_9.TqSuper.Value = v_u_63
	v_u_9.TqBoosted.Value = v_u_74 + v_u_63
	local v506 = v_u_9.Torque
	local v507 = v_u_83 + v_u_76 + v_u_77
	local v508 = v_u_20(v_u_83 + v_u_76 + v_u_77, v_u_354 > 0 and v_u_354 * (5.252 / (v_u_23 / 1000)) or (1 / 0))
	v506.Value = v_u_20(v507, (math.clamp(v508, 0, 1000000)))
	v_u_9.TransmissionMode.Value = v_u_27
	v_u_9.Throttle.Value = v_u_72
	v_u_9.Brake.Value = v_u_52
	v_u_9.IThrottle.Value = v_u_41
	v_u_9.IBrake.Value = v_u_42
	if v_u_9.AutoClutch.Value then
		v_u_9.Clutch.Value = v_u_56
	end
	v_u_9.SteerC.Value = v_u_66
	v_u_9.SteerT.Value = v_u_43
	v_u_9.PBrake.Value = v_u_40
	v_u_9.TCS.Value = v_u_28
	v_u_9.TCSActive.Value = v_u_84
	v_u_9.ABS.Value = v_u_29
	v_u_9.ABSActive.Value = v_u_54
	v_u_9.MouseSteerOn.Value = v_u_38
	v_u_9.Velocity.Value = v_u_6.DriveSeat.AssemblyLinearVelocity
	v_u_9.CarCenter.Value = v_u_31
	for v509, v510 in next, v_u_49 do
		if not v_u_9.TCSTracker:FindFirstChild(v509) then
			Instance.new("NumberValue", v_u_9.TCSTracker).Name = v509
		end
		v_u_9.TCSTracker[v509].Value = v510
	end
	for v511, v512 in next, v_u_51 do
		if not v_u_9.ABSTracker:FindFirstChild(v511) then
			Instance.new("NumberValue", v_u_9.ABSTracker).Name = v511
		end
		v_u_9.ABSTracker[v511].Value = v512
	end
	local v513 = next
	local v514, v515 = v_u_6.Wheels:GetChildren()
	for _, v516 in v513, v514, v515 do
		if not v_u_78[v516.Name] then
			v_u_78[v516.Name] = {}
		end
		local v517 = v_u_78[v516.Name]
		local v518 = v516.RotVelocity.Magnitude
		table.insert(v517, v518)
		if #v_u_78[v516.Name] > 6 then
			table.remove(v_u_78[v516.Name], 1)
		end
		local v519 = 0
		for _, v520 in next, v_u_78[v516.Name] do
			v519 = v519 + v520
		end
		local v521 = v519 / #v_u_78[v516.Name]
		v_u_81[v516.Name] = v521
	end
	local v522 = 0
	for v523, v524 in next, v_u_81 do
		if not v_u_9.WheelSpeeds:FindFirstChild(v523) then
			Instance.new("NumberValue", v_u_9.WheelSpeeds).Name = v523
		end
		v_u_9.WheelSpeeds[v523].Value = v524
		v522 = v522 + v524 * (v_u_6.Wheels[v523].Size.Y / 2)
	end
	v_u_9.AverageRotSpeed.Value = v522 / #v_u_6.Wheels:GetChildren()
	v_u_9.Acceleration.Value = (v_u_6.DriveSeat.AssemblyLinearVelocity - v_u_33) * (1 / p505)
	v_u_33 = v_u_6.DriveSeat.AssemblyLinearVelocity
	v_u_9.DragFactor.Value = 1
	Inputs(p505)
	Steering(p505)
	Gear()
	Engine(p505)
	Suspension()
	if v_u_27 == "Auto" then
		Auto()
	end
	if v_u_7.AutoFlip then
		Flip()
	end
	local v525 = v_u_3:GetLastInputType() == Enum.UserInputType.Touch
	script.Parent.Mobile.Visible = v525
	script.Parent.Mobile.ModeSwitch.Visible = v_u_6.DriveSeat.AssemblyLinearVelocity.Magnitude < 5
	script.Parent.Mobile.ModeSwitch.Text = v_u_10
	script.Parent.Mobile.Jump.Visible = script.Parent.Mobile.ModeSwitch.Visible
	if v525 then
		v_u_7.AutoShiftVers = "Old"
		v_u_27 = "Auto"
	else
		v_u_7.AutoShiftVers = v_u_32
	end
	local v526 = next
	local v527, v528 = script.Parent.Mobile:GetChildren()
	for _, v529 in v526, v527, v528 do
		if v529.ClassName == "Frame" then
			v529.Visible = v_u_10 == v529.Name
		end
	end
end)