-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = {}
local v_u_2 = script.Parent.Parent:WaitForChild("Lights")
local v_u_3 = { Color3.fromRGB(205, 84, 75), Color3.fromRGB(159, 161, 172) }
function v1.WhiteOn()
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	for _, v4 in pairs(v_u_2:GetChildren()) do
		v4.Light.Enabled = true
		v4.Transparency = 0.3
		v4.Color = v_u_3[2]
		v4.Light.Color = v_u_3[2]
	end
end
function v1.RedOn()
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	for _, v5 in pairs(v_u_2:GetChildren()) do
		v5.Color = v_u_3[1]
		v5.Light.Color = v_u_3[1]
	end
end
function v1.Off()
	-- upvalues: (copy) v_u_2
	for _, v6 in pairs(v_u_2:GetChildren()) do
		v6.Light.Enabled = false
		v6.Transparency = 1
	end
end
return v1