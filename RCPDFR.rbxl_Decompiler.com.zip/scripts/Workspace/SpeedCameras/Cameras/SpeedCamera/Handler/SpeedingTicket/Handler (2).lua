-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local _ = game.Players.LocalPlayer
local v_u_1 = game.Lighting
local v_u_2 = script.Parent:WaitForChild("Camera").Value
local v_u_3 = script:WaitForChild("Shutter")
local v_u_4 = script:WaitForChild("Notify")
local v_u_5 = game:GetService("TweenService")
game:GetService("Debris")
local v_u_6 = script.Parent:WaitForChild("SpeedLimit")
local v_u_7 = script.Parent.BottomCornerUI.Notifications:WaitForChild("Alert");
(function()
	-- upvalues: (copy) v_u_3, (copy) v_u_5, (copy) v_u_1, (copy) v_u_7, (copy) v_u_4, (copy) v_u_6, (copy) v_u_2
	v_u_3:Play()
	task.wait(0.2)
	v_u_5:Create(v_u_1, TweenInfo.new(0.3, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
		["ExposureCompensation"] = 1
	}):Play()
	task.wait(0.31)
	v_u_7.Visible = true
	v_u_4:Play()
	v_u_5:Create(v_u_1, TweenInfo.new(0.2, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
		["ExposureCompensation"] = 0
	}):Play()
	local v8 = v_u_6.Speed
	local v9 = v_u_2.Config.SpeedLimit.Value
	v8.Text = tostring(v9)
	v_u_5:Create(v_u_6, TweenInfo.new(0.5, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
		["Position"] = UDim2.new(0.803, 0, 0.703, 0)
	}):Play()
end)()