-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = game:GetService("Players")
local v_u_2 = v_u_1.LocalPlayer
local v_u_3 = game:GetService("Chat")
local v_u_4 = {
	[0] = Color3.fromRGB(242, 243, 243),
	[1] = Color3.fromRGB(255, 255, 255)
}
local v_u_5 = {
	[2] = Color3.fromRGB(0, 255, 0),
	[3] = Color3.fromRGB(255, 255, 255)
}
local v_u_6 = {
	["Players"] = {
		["BackgroundColor3"] = Color3.fromRGB(255, 255, 255),
		["TextColor3"] = Color3.fromRGB(255, 255, 255)
	},
	["\240\159\155\160\239\184\143 Contractor"] = {
		["BackgroundColor3"] = Color3.fromRGB(255, 255, 255),
		["TextColor3"] = Color3.fromRGB(255, 215, 0)
	},
	["\226\156\168 Creator"] = {
		["BackgroundColor3"] = Color3.fromRGB(255, 255, 255),
		["TextColor3"] = Color3.fromRGB(255, 215, 0)
	},
	["\226\154\148\239\184\143 Staff"] = {
		["BackgroundColor3"] = Color3.fromRGB(255, 243, 243),
		["TextColor3"] = Color3.fromRGB(241, 0, 0)
	},
	["\240\159\155\161\239\184\143 Staff Manager"] = {
		["BackgroundColor3"] = Color3.fromRGB(255, 243, 243),
		["TextColor3"] = Color3.fromRGB(241, 0, 0)
	},
	["\226\154\153\239\184\143 Community Organizer"] = {
		["BackgroundColor3"] = Color3.fromRGB(255, 255, 255),
		["TextColor3"] = Color3.fromRGB(255, 215, 0)
	}
}
local function v_u_9()
	-- upvalues: (copy) v_u_1, (copy) v_u_6, (copy) v_u_5, (copy) v_u_4
	for _, v7 in pairs(v_u_1:GetChildren()) do
		local v8 = v_u_6.Players
		if v_u_6[v7:GetRoleInGroup(12254030)] then
			v8 = v_u_6[v7:GetRoleInGroup(12254030)]
		end
		v_u_5[v7.UserId] = v8.TextColor3
		v_u_4[v7.UserId] = v8.BackgroundColor3
	end
end
v_u_9()
v_u_1.PlayerAdded:Connect(function()
	-- upvalues: (copy) v_u_9
	v_u_9()
end)
v_u_1.PlayerRemoving:Connect(function()
	-- upvalues: (copy) v_u_9
	v_u_9()
end)
local v10 = game:GetService("ReplicatedStorage")
local v_u_11 = game:GetService("TextService")
while v_u_2 == nil do
	v_u_1.ChildAdded:wait()
	v_u_2 = v_u_1.LocalPlayer
end
local v12 = v_u_2:WaitForChild("PlayerGui")
local v13, v14 = pcall(function()
	return UserSettings():IsUserFeatureEnabled("UserShouldLocalizeGameChatBubble")
end)
local v_u_15 = v13 and v14
local v16, v17 = pcall(function()
	return UserSettings():IsUserFeatureEnabled("UserChatNewMessageLengthCheck")
end)
local v_u_18 = v16 and v17
local v_u_19 = Enum.Font.SourceSans
local v_u_20 = Enum.FontSize.Size24
local v_u_21 = not v_u_18 and 124 or 128 - utf8.len(utf8.nfcnormalize("...")) - 1
local v_u_22 = {
	["WHITE"] = "dub",
	["BLUE"] = "blu",
	["GREEN"] = "gre",
	["RED"] = "red"
}
local v_u_23 = Instance.new("ScreenGui")
v_u_23.Name = "BubbleChat"
v_u_23.ResetOnSpawn = false
v_u_23.Parent = v12
local function v_u_29()
	local v_u_24 = {
		["data"] = {}
	}
	local v_u_25 = Instance.new("BindableEvent")
	v_u_24.Emptied = v_u_25.Event
	function v_u_24.Size(_)
		-- upvalues: (copy) v_u_24
		return #v_u_24.data
	end
	function v_u_24.Empty(_)
		-- upvalues: (copy) v_u_24
		return v_u_24:Size() <= 0
	end
	function v_u_24.PopFront(_)
		-- upvalues: (copy) v_u_24, (copy) v_u_25
		table.remove(v_u_24.data, 1)
		if v_u_24:Empty() then
			v_u_25:Fire()
		end
	end
	function v_u_24.Front(_)
		-- upvalues: (copy) v_u_24
		return v_u_24.data[1]
	end
	function v_u_24.Get(_, p26)
		-- upvalues: (copy) v_u_24
		return v_u_24.data[p26]
	end
	function v_u_24.PushBack(_, p27)
		-- upvalues: (copy) v_u_24
		local v28 = v_u_24.data
		table.insert(v28, p27)
	end
	function v_u_24.GetData(_)
		-- upvalues: (copy) v_u_24
		return v_u_24.data
	end
	return v_u_24
end
local function v_u_40(p30, p31, p32)
	-- upvalues: (ref) v_u_18
	local v39 = {
		["ComputeBubbleLifetime"] = function(_, p33, p34)
			-- upvalues: (ref) v_u_18
			if p34 then
				if v_u_18 then
					local v35 = utf8.len(utf8.nfcnormalize(p33)) / 75
					return 8 + 7 * math.min(v35, 1)
				else
					local v36 = string.len(p33) / 75
					return 8 + 7 * math.min(v36, 1)
				end
			elseif v_u_18 then
				local v37 = utf8.len(utf8.nfcnormalize(p33)) / 75
				return 12 + 8 * math.min(v37, 1)
			else
				local v38 = string.len(p33) / 75
				return 12 + 8 * math.min(v38, 1)
			end
		end,
		["Origin"] = nil,
		["RenderBubble"] = nil,
		["Message"] = p30
	}
	v39.BubbleDieDelay = v39:ComputeBubbleLifetime(p30, p32)
	v39.BubbleColor = p31
	v39.IsLocalPlayer = p32
	return v39
end
function createChatBubbleMain(p41, p42)
	local v43 = Instance.new("ImageLabel")
	v43.Name = "ChatBubble"
	v43.ScaleType = Enum.ScaleType.Slice
	v43.SliceCenter = p42
	v43.Image = "rbxasset://textures/" .. tostring(p41) .. ".png"
	v43.BackgroundTransparency = 1
	v43.BorderSizePixel = 0
	v43.Size = UDim2.new(1, 0, 1, 0)
	v43.Position = UDim2.new(0, 0, 0, 0)
	return v43
end
function createChatBubbleTail(p44, p45)
	local v46 = Instance.new("ImageLabel")
	v46.Name = "ChatBubbleTail"
	v46.Image = "rbxasset://textures/ui/dialog_tail.png"
	v46.BackgroundTransparency = 1
	v46.BorderSizePixel = 0
	v46.Position = p44
	v46.Size = p45
	return v46
end
function createChatBubbleWithTail(p47, p48, p49, p50)
	local v51 = createChatBubbleMain(p47, p50)
	createChatBubbleTail(p48, p49).Parent = v51
	return v51
end
function createScaledChatBubbleWithTail(p52, p53, p54, p55)
	local v56 = createChatBubbleMain(p52, p55)
	local v57 = Instance.new("Frame")
	v57.Name = "ChatBubbleTailFrame"
	v57.BackgroundTransparency = 1
	v57.SizeConstraint = Enum.SizeConstraint.RelativeXX
	v57.Position = UDim2.new(0.5, 0, 1, 0)
	v57.Size = UDim2.new(p53, 0, p53, 0)
	v57.Parent = v56
	createChatBubbleTail(p54, UDim2.new(1, 0, 0.5, 0)).Parent = v57
	return v56
end
function createChatImposter(p58, p59, p60)
	local v61 = Instance.new("ImageLabel")
	v61.Name = "DialogPlaceholder"
	v61.Image = "rbxasset://textures/" .. tostring(p58) .. ".png"
	v61.BackgroundTransparency = 1
	v61.BorderSizePixel = 0
	v61.Position = UDim2.new(0, 0, -1.25, 0)
	v61.Size = UDim2.new(1, 0, 1, 0)
	local v62 = Instance.new("ImageLabel")
	v62.Name = "DotDotDot"
	v62.Image = "rbxasset://textures/" .. tostring(p59) .. ".png"
	v62.BackgroundTransparency = 1
	v62.BorderSizePixel = 0
	v62.Position = UDim2.new(0.001, 0, p60, 0)
	v62.Size = UDim2.new(1, 0, 0.7, 0)
	v62.Parent = v61
	return v61
end
local v_u_70 = {
	["ChatBubble"] = {},
	["ChatBubbleWithTail"] = {},
	["ScalingChatBubbleWithTail"] = {},
	["CharacterSortedMsg"] = (function()
		-- upvalues: (copy) v_u_29
		local v_u_63 = {
			["data"] = {}
		}
		local v_u_64 = 0
		function v_u_63.Size(_)
			-- upvalues: (ref) v_u_64
			return v_u_64
		end
		function v_u_63.Erase(_, p65)
			-- upvalues: (copy) v_u_63, (ref) v_u_64
			if v_u_63.data[p65] then
				v_u_64 = v_u_64 - 1
			end
			v_u_63.data[p65] = nil
		end
		function v_u_63.Set(_, p66, p67)
			-- upvalues: (copy) v_u_63, (ref) v_u_64
			v_u_63.data[p66] = p67
			if p67 then
				v_u_64 = v_u_64 + 1
			end
		end
		function v_u_63.Get(_, p_u_68)
			-- upvalues: (copy) v_u_63, (ref) v_u_29
			if p_u_68 then
				if not v_u_63.data[p_u_68] then
					v_u_63.data[p_u_68] = {
						["Fifo"] = v_u_29(),
						["BillboardGui"] = nil
					}
					local v_u_69 = nil
					v_u_69 = v_u_63.data[p_u_68].Fifo.Emptied:connect(function()
						-- upvalues: (ref) v_u_69, (ref) v_u_63, (copy) p_u_68
						v_u_69:disconnect()
						v_u_63:Erase(p_u_68)
					end)
				end
				return v_u_63.data[p_u_68]
			end
		end
		function v_u_63.GetData(_)
			-- upvalues: (copy) v_u_63
			return v_u_63.data
		end
		return v_u_63
	end)()
}
local function v75(p71, p72, _, p73, p74)
	-- upvalues: (copy) v_u_70
	v_u_70.ChatBubble[p71] = createChatBubbleMain(p72, p74)
	v_u_70.ChatBubbleWithTail[p71] = createChatBubbleWithTail(p72, UDim2.new(0.5, -14, 1, p73 and -1 or 0), UDim2.new(0, 30, 0, 14), p74)
	v_u_70.ScalingChatBubbleWithTail[p71] = createScaledChatBubbleWithTail(p72, 0.5, UDim2.new(-0.5, 0, 0, p73 and -1 or 0), p74)
end
v75(v_u_22.WHITE, "ui/dialog_white", "ui/chatBubble_white_notify_bkg", false, Rect.new(5, 5, 15, 15))
v75(v_u_22.BLUE, "ui/dialog_blue", "ui/chatBubble_blue_notify_bkg", true, Rect.new(7, 7, 33, 33))
v75(v_u_22.RED, "ui/dialog_red", "ui/chatBubble_red_notify_bkg", true, Rect.new(7, 7, 33, 33))
v75(v_u_22.GREEN, "ui/dialog_green", "ui/chatBubble_green_notify_bkg", true, Rect.new(7, 7, 33, 33))
function v_u_70.SanitizeChatLine(_, p76)
	-- upvalues: (ref) v_u_18, (ref) v_u_21
	if v_u_18 then
		if v_u_21 >= utf8.len(utf8.nfcnormalize(p76)) then
			return p76
		end
		local v77 = utf8.offset(p76, v_u_21 + utf8.len(utf8.nfcnormalize("...")) + 1) - 1
		return string.sub(p76, 1, v77)
	else
		if v_u_21 >= string.len(p76) then
			return p76
		end
		local v78 = v_u_21 + 3
		return string.sub(p76, 1, v78)
	end
end
local function v_u_83(p79)
	-- upvalues: (copy) v_u_23, (copy) v_u_70, (copy) v_u_22
	local v_u_80 = Instance.new("BillboardGui")
	v_u_80.Adornee = p79
	v_u_80.Size = UDim2.new(0, 400, 0, 250)
	v_u_80.StudsOffset = Vector3.new(0, 1.5, 2)
	v_u_80.Parent = v_u_23
	local v_u_81 = Instance.new("Frame")
	v_u_81.Name = "BillboardFrame"
	v_u_81.Size = UDim2.new(1, 0, 1, 0)
	v_u_81.Position = UDim2.new(0, 0, -0.5, 0)
	v_u_81.BackgroundTransparency = 1
	v_u_81.Parent = v_u_80
	local v_u_82 = nil
	v_u_82 = v_u_81.ChildRemoved:connect(function()
		-- upvalues: (copy) v_u_81, (ref) v_u_82, (copy) v_u_80
		if #v_u_81:GetChildren() <= 1 then
			v_u_82:disconnect()
			v_u_80:Destroy()
		end
	end)
	v_u_70:CreateSmallTalkBubble(v_u_22.WHITE).Parent = v_u_81
	return v_u_80
end
function v_u_70.CreateBillboardGuiHelper(_, p84, p85)
	-- upvalues: (copy) v_u_70, (copy) v_u_83
	if p84 and not v_u_70.CharacterSortedMsg:Get(p84).BillboardGui then
		if not p85 and p84:IsA("BasePart") then
			local v86 = v_u_83(p84)
			v_u_70.CharacterSortedMsg:Get(p84).BillboardGui = v86
			return
		end
		if p84:IsA("Model") then
			local v87 = p84:FindFirstChild("Head")
			if v87 and v87:IsA("BasePart") then
				local v88 = v_u_83(v87)
				v_u_70.CharacterSortedMsg:Get(p84).BillboardGui = v88
			end
		end
	end
end
function v_u_70.SetBillboardLODNear(_, p89)
	-- upvalues: (copy) v_u_1
	local v90 = p89.Adornee
	local v91
	if v90 and v_u_1.LocalPlayer.Character then
		v91 = v90:IsDescendantOf(v_u_1.LocalPlayer.Character)
	else
		v91 = nil
	end
	p89.Size = UDim2.new(0, 400, 0, 250)
	p89.StudsOffset = Vector3.new(0, v91 and 1.5 or 2.5, v91 and 2 or 0.1)
	p89.Enabled = true
	local v92 = p89.BillboardFrame:GetChildren()
	for v93 = 1, #v92 do
		v92[v93].Visible = true
	end
	p89.BillboardFrame.SmallTalkBubble.Visible = false
end
function v_u_70.SetBillboardLODDistant(_, p94)
	-- upvalues: (copy) v_u_1
	local v95 = p94.Adornee
	local v96
	if v95 and v_u_1.LocalPlayer.Character then
		v96 = v95:IsDescendantOf(v_u_1.LocalPlayer.Character)
	else
		v96 = nil
	end
	p94.Size = UDim2.new(4, 0, 3, 0)
	p94.StudsOffset = Vector3.new(0, 3, v96 and 2 or 0.1)
	p94.Enabled = true
	local v97 = p94.BillboardFrame:GetChildren()
	for v98 = 1, #v97 do
		v97[v98].Visible = false
	end
	p94.BillboardFrame.SmallTalkBubble.Visible = true
end
function v_u_70.SetBillboardLODVeryFar(_, p99)
	p99.Enabled = false
end
function v_u_70.SetBillboardGuiLOD(_, p100, p101)
	-- upvalues: (copy) v_u_70
	if p101 then
		if p101:IsA("Model") then
			p101 = p101:FindFirstChild("Head") or p101.PrimaryPart
		end
		local v102 = not p101 and 100000 or (p101.Position - game.Workspace.CurrentCamera.CoordinateFrame.p).magnitude
		if v102 < 65 then
			v_u_70:SetBillboardLODNear(p100)
			return
		elseif v102 >= 65 and v102 < 100 then
			v_u_70:SetBillboardLODDistant(p100)
		else
			v_u_70:SetBillboardLODVeryFar(p100)
		end
	else
		return
	end
end
function v_u_70.CameraCFrameChanged(_)
	-- upvalues: (copy) v_u_70
	for v103, v104 in pairs(v_u_70.CharacterSortedMsg:GetData()) do
		local v105 = v104.BillboardGui
		if v105 then
			v_u_70:SetBillboardGuiLOD(v105, v103)
		end
	end
end
function v_u_70.CreateBubbleText(_, p106, p107)
	-- upvalues: (copy) v_u_19, (copy) v_u_20
	local v108 = Instance.new("TextLabel")
	v108.Name = "BubbleText"
	v108.BackgroundTransparency = 1
	v108.Position = UDim2.new(0, 15, 0, 0)
	v108.Size = UDim2.new(1, -30, 1, 0)
	v108.Font = v_u_19
	v108.ClipsDescendants = true
	v108.TextWrapped = true
	v108.FontSize = v_u_20
	v108.Text = p106
	v108.Visible = false
	v108.AutoLocalize = p107
	v108.TextStrokeTransparency = 0
	return v108
end
function v_u_70.CreateSmallTalkBubble(_, p109)
	-- upvalues: (copy) v_u_70
	local v110 = v_u_70.ScalingChatBubbleWithTail[p109]:Clone()
	v110.Name = "SmallTalkBubble"
	v110.AnchorPoint = Vector2.new(0, 0.5)
	v110.Position = UDim2.new(0, 0, 0.5, 0)
	v110.Visible = false
	local v111 = v_u_70:CreateBubbleText("...")
	v111.TextScaled = true
	v111.TextWrapped = false
	v111.Visible = true
	v111.Parent = v110
	return v110
end
function v_u_70.UpdateChatLinesForOrigin(_, p112, p113)
	-- upvalues: (copy) v_u_70
	local v114 = v_u_70.CharacterSortedMsg:Get(p112).Fifo
	local v115 = v114:Size()
	local v116 = v114:GetData()
	if #v116 > 1 then
		for v117 = #v116 - 1, 1, -1 do
			local v118 = v116[v117].RenderBubble
			if not v118 then
				return
			end
			if v115 - v117 + 1 > 1 then
				local v119 = v118:FindFirstChild("ChatBubbleTail")
				if v119 then
					v119:Destroy()
				end
				local v120 = v118:FindFirstChild("BubbleText")
				if v120 then
					v120.TextTransparency = 0.5
				end
			end
			v118:TweenPosition(UDim2.new(v118.Position.X.Scale, v118.Position.X.Offset, 1, p113 - v118.Size.Y.Offset - 14), Enum.EasingDirection.Out, Enum.EasingStyle.Bounce, 0.1, true)
			p113 = p113 - v118.Size.Y.Offset - 14
		end
	end
end
function v_u_70.DestroyBubble(_, p_u_121, p_u_122)
	if p_u_121 then
		if p_u_121:Empty() then
			return
		else
			local v_u_123 = p_u_121:Front().RenderBubble
			if v_u_123 then
				spawn(function()
					-- upvalues: (copy) p_u_121, (copy) p_u_122, (ref) v_u_123
					while p_u_121:Front().RenderBubble ~= p_u_122 do
						wait()
					end
					v_u_123 = p_u_121:Front().RenderBubble
					local v124 = v_u_123:FindFirstChild("BubbleText")
					local v125 = v_u_123:FindFirstChild("ChatBubbleTail")
					while v_u_123 and v_u_123.ImageTransparency < 1 do
						local v126 = wait()
						if v_u_123 then
							local v127 = v126 * 1.5
							v_u_123.ImageTransparency = v_u_123.ImageTransparency + v127
							if v124 then
								v124.TextTransparency = v124.TextTransparency + v127
							end
							if v125 then
								v125.ImageTransparency = v125.ImageTransparency + v127
							end
						end
					end
					if v_u_123 then
						v_u_123:Destroy()
						p_u_121:PopFront()
					end
				end)
			else
				p_u_121:PopFront()
			end
		end
	else
		return
	end
end
function v_u_70.CreateChatLineRender(_, p128, p129, p130, p_u_131, p132, p133, p134)
	-- upvalues: (copy) v_u_70, (copy) v_u_11, (copy) v_u_19
	if p128 then
		if not v_u_70.CharacterSortedMsg:Get(p128).BillboardGui then
			v_u_70:CreateBillboardGuiHelper(p128, p130)
		end
		local v135 = v_u_70.CharacterSortedMsg:Get(p128).BillboardGui
		if v135 then
			local v_u_136 = v_u_70.ChatBubbleWithTail[p129.BubbleColor]:Clone()
			if p133 then
				v_u_136.ImageColor3 = p133
				v_u_136.ChatBubbleTail.ImageColor3 = p133
			end
			v_u_136.Visible = false
			local v_u_137 = v_u_70:CreateBubbleText(p129.Message, p132)
			if p134 then
				v_u_137.TextColor3 = p134
			end
			v_u_137.Parent = v_u_136
			v_u_136.Parent = v135.BillboardFrame
			p129.RenderBubble = v_u_136
			local v138 = v_u_11:GetTextSize(v_u_137.Text, 24, v_u_19, Vector2.new(400, 250))
			local v139 = (v138.X + 30) / 400
			local v140 = math.max(v139, 0.1)
			local v141 = v138.Y / 24
			v_u_136.Size = UDim2.new(0, 0, 0, 0)
			v_u_136.Position = UDim2.new(0.5, 0, 1, 0)
			local v142 = v141 * 34
			v_u_136:TweenSizeAndPosition(UDim2.new(v140, 0, 0, v142), UDim2.new((1 - v140) / 2, 0, 1, -v142), Enum.EasingDirection.Out, Enum.EasingStyle.Elastic, 0.1, true, function()
				-- upvalues: (copy) v_u_137
				v_u_137.Visible = true
			end)
			v_u_70:SetBillboardGuiLOD(v135, p129.Origin)
			v_u_70:UpdateChatLinesForOrigin(p129.Origin, -v142)
			delay(p129.BubbleDieDelay, function()
				-- upvalues: (ref) v_u_70, (copy) p_u_131, (copy) v_u_136
				v_u_70:DestroyBubble(p_u_131, v_u_136)
			end)
		end
	end
end
function v_u_70.OnPlayerChatMessage(_, p143, p144, _)
	-- upvalues: (copy) v_u_70, (copy) v_u_1, (copy) v_u_40, (copy) v_u_22, (copy) v_u_4, (copy) v_u_5
	if v_u_70:BubbleChatEnabled() then
		local v145 = v_u_1.LocalPlayer
		local v146
		if v145 == nil then
			v146 = false
		else
			v146 = p143 ~= v145
		end
		local v147 = v_u_40(v_u_70:SanitizeChatLine(p144), v_u_22.WHITE, not v146)
		if p143 then
			v147.User = p143.Name
			v147.Origin = p143.Character
		end
		if p143 and v147.Origin then
			local v148 = v_u_70.CharacterSortedMsg:Get(v147.Origin).Fifo
			v148:PushBack(v147)
			v_u_70:CreateChatLineRender(p143.Character, v147, true, v148, false, v_u_4[p143.UserId], v_u_5[p143.UserId])
		end
	end
end
function v_u_70.OnGameChatMessage(_, p149, p150, p151)
	-- upvalues: (copy) v_u_1, (copy) v_u_22, (copy) v_u_70, (copy) v_u_40, (copy) v_u_15
	local v152 = v_u_1.LocalPlayer
	local v153
	if v152 == nil then
		v153 = false
	else
		v153 = v152.Character ~= p149
	end
	local v154 = v_u_22.WHITE
	if p151 == Enum.ChatColor.Blue then
		v154 = v_u_22.BLUE
	elseif p151 == Enum.ChatColor.Green then
		v154 = v_u_22.GREEN
	elseif p151 == Enum.ChatColor.Red then
		v154 = v_u_22.RED
	end
	local v155 = v_u_40(v_u_70:SanitizeChatLine(p150), v154, not v153)
	v155.Origin = p149
	v_u_70.CharacterSortedMsg:Get(v155.Origin).Fifo:PushBack(v155)
	if v_u_15 then
		v_u_70:CreateChatLineRender(p149, v155, false, v_u_70.CharacterSortedMsg:Get(v155.Origin).Fifo, true)
	else
		v_u_70:CreateChatLineRender(p149, v155, false, v_u_70.CharacterSortedMsg:Get(v155.Origin).Fifo, false)
	end
end
function v_u_70.BubbleChatEnabled(_)
	-- upvalues: (copy) v_u_3, (copy) v_u_1
	local v156 = v_u_3:FindFirstChild("ClientChatModules")
	local v157 = v156 and v156:FindFirstChild("ChatSettings")
	if v157 then
		local v158 = require(v157)
		if v158.BubbleChatEnabled ~= nil then
			return v158.BubbleChatEnabled
		end
	end
	return v_u_1.BubbleChat
end
function v_u_70.ShowOwnFilteredMessage(_)
	-- upvalues: (copy) v_u_3
	local v159 = v_u_3:FindFirstChild("ClientChatModules")
	local v160 = v159 and v159:FindFirstChild("ChatSettings")
	if v160 then
		return require(v160).ShowUserOwnFilteredMessage
	else
		return false
	end
end
function findPlayer(p161)
	-- upvalues: (copy) v_u_1
	for _, v162 in pairs(v_u_1:GetPlayers()) do
		if v162.Name == p161 then
			return v162
		end
	end
end
v_u_3.Chatted:connect(function(p163, p164, p165)
	-- upvalues: (copy) v_u_70
	v_u_70:OnGameChatMessage(p163, p164, p165)
end)
local v_u_166
if game.Workspace.CurrentCamera then
	v_u_166 = game.Workspace.CurrentCamera:GetPropertyChangedSignal("CFrame"):connect(function(_)
		-- upvalues: (copy) v_u_70
		v_u_70:CameraCFrameChanged()
	end)
else
	v_u_166 = nil
end
game.Workspace.Changed:connect(function(p167)
	-- upvalues: (ref) v_u_166, (copy) v_u_70
	if p167 == "CurrentCamera" then
		if v_u_166 then
			v_u_166:disconnect()
		end
		if game.Workspace.CurrentCamera then
			v_u_166 = game.Workspace.CurrentCamera:GetPropertyChangedSignal("CFrame"):connect(function(_)
				-- upvalues: (ref) v_u_70
				v_u_70:CameraCFrameChanged()
			end)
		end
	end
end)
local v_u_168 = nil
function getAllowedMessageTypes()
	-- upvalues: (ref) v_u_168, (copy) v_u_3
	if v_u_168 then
		return v_u_168
	end
	local v169 = v_u_3:FindFirstChild("ClientChatModules")
	if not v169 then
		return { "Message", "Whisper" }
	end
	local v170 = v169:FindFirstChild("ChatSettings")
	if v170 then
		local v171 = require(v170)
		if v171.BubbleChatMessageTypes then
			v_u_168 = v171.BubbleChatMessageTypes
			return v_u_168
		end
	end
	local v172 = v169:FindFirstChild("ChatConstants")
	if v172 then
		local v173 = require(v172)
		v_u_168 = { v173.MessageTypeDefault, v173.MessageTypeWhisper }
	end
	return v_u_168
end
function checkAllowedMessageType(p174)
	local v175 = getAllowedMessageTypes()
	for v176 = 1, #v175 do
		if v175[v176] == p174.MessageType then
			return true
		end
	end
	return false
end
local v177 = v10:WaitForChild("DefaultChatSystemChatEvents")
local v178 = v177:WaitForChild("OnMessageDoneFiltering")
v177:WaitForChild("OnNewMessage").OnClientEvent:connect(function(p179, _)
	-- upvalues: (ref) v_u_2, (copy) v_u_70
	if checkAllowedMessageType(p179) then
		local v180 = findPlayer(p179.FromSpeaker)
		if v180 then
			if p179.IsFiltered and p179.FromSpeaker ~= v_u_2.Name or p179.FromSpeaker == v_u_2.Name and not v_u_70:ShowOwnFilteredMessage() then
				v_u_70:OnPlayerChatMessage(v180, p179.Message, nil)
			end
		else
			return
		end
	else
		return
	end
end)
v178.OnClientEvent:connect(function(p181, _)
	-- upvalues: (ref) v_u_2, (copy) v_u_70
	if checkAllowedMessageType(p181) then
		local v182 = findPlayer(p181.FromSpeaker)
		if v182 then
			if p181.FromSpeaker ~= v_u_2.Name or v_u_70:ShowOwnFilteredMessage() then
				v_u_70:OnPlayerChatMessage(v182, p181.Message, nil)
			end
		else
			return
		end
	else
		return
	end
end)