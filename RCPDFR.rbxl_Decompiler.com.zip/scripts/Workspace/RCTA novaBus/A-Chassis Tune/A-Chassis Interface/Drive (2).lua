-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

script.Parent:WaitForChild("Car")
script.Parent:WaitForChild("IsOn")
script.Parent:WaitForChild("ControlsOpen")
script.Parent:WaitForChild("Values")
local v_u_1 = game.Players.LocalPlayer:GetMouse()
local v_u_2 = game:GetService("UserInputService")
local v_u_3 = script.Parent.Car.Value
local v_u_4 = require(v_u_3["A-Chassis Tune"])
local v_u_5 = v_u_4.WeightScaling * 10
local v_u_6 = v_u_4.BrakeForce * v_u_4.BrakeBias
local v_u_7 = v_u_4.BrakeForce * (1 - v_u_4.BrakeBias)
local v_u_8 = v_u_4.PBrakeForce * v_u_4.PBrakeBias
local v_u_9 = v_u_4.PBrakeForce * (1 - v_u_4.PBrakeBias)
local v_u_10 = v_u_4.EBrakeForce
local v_u_11 = v_u_4.SteerOuter
local v_u_12 = v_u_4.SteerInner
local v_u_13 = v_u_4.RSteerOuter
local v_u_14 = v_u_4.RSteerInner
if not workspace:PGSIsEnabled() then
	error("PGS is not enabled: A-Chassis will not work.")
end
local v_u_15 = v_u_4.AutoStart
if v_u_4.AutoStart and (v_u_4.Engine or v_u_4.Electric) then
	script.Parent.IsOn.Value = true
end
local v_u_16 = v_u_4.IdleThrottle / 100
local v_u_17 = v_u_4.TransModes[1]
local v_u_18 = v_u_4.TCSEnabled
local v_u_19 = v_u_4.ABSEnabled
local v_u_20 = tick()
v_u_3.DriveSeat.ChildRemoved:connect(function(p21)
	if p21.Name == "SeatWeld" and p21:IsA("Weld") then
		script.Parent:Destroy()
	end
end)
local v_u_22 = v_u_4.Controls
local v23 = Instance.new("Folder", script.Parent)
v23.Name = "Controls"
local v_u_24 = false
local v_u_25 = 0
local v_u_26 = 0
local v_u_27 = 0
local v_u_28 = false
local v_u_29 = false
local v_u_30 = false
local v_u_31 = false
local v_u_32 = false
local v_u_33 = false
local v_u_34 = false
local v_u_35 = false
local v_u_36 = 0
local v_u_37 = 0
local v_u_38 = 0
local v_u_39 = 0
local v_u_40 = 0
local v_u_41 = 0
local v_u_42 = false
local v_u_43 = 0
local v_u_44 = 0
local v_u_45 = 0
local v_u_46 = false
local v_u_47 = 0
local v_u_48 = 0
local v_u_49 = 0
local v_u_50 = 0
local v_u_51 = 0
local v_u_52 = 0
local v_u_53 = 0
local v_u_54 = 0
local v_u_55 = 0
local v_u_56 = 0
local v_u_57 = 0
local v_u_58 = 0
local v_u_59 = 0
local v_u_60 = 0
local v_u_61 = false
local v_u_62 = false
local v_u_63 = 0
local v_u_64 = 0
for v_u_65, v66 in pairs(v_u_22) do
	local v_u_67 = Instance.new("StringValue", v23)
	v_u_67.Name = v_u_65
	v_u_67.Value = v66.Name
	v_u_67.Changed:connect(function()
		-- upvalues: (copy) v_u_65, (copy) v_u_67, (copy) v_u_22
		if v_u_65 == "MouseThrottle" or v_u_65 == "MouseBrake" then
			if v_u_67.Value == "MouseButton1" or v_u_67.Value == "MouseButton2" then
				v_u_22[v_u_65] = Enum.UserInputType[v_u_67.Value]
			else
				v_u_22[v_u_65] = Enum.KeyCode[v_u_67.Value]
			end
		else
			v_u_22[v_u_65] = Enum.KeyCode[v_u_67.Value]
			return
		end
	end)
end
local v_u_68 = v_u_4.Peripherals
for v_u_69, v70 in pairs(v_u_68) do
	local v_u_71 = Instance.new("IntValue", v23)
	v_u_71.Name = v_u_69
	v_u_71.Value = v70
	v_u_71.Changed:connect(function()
		-- upvalues: (copy) v_u_71, (copy) v_u_68, (copy) v_u_69
		local v72 = v_u_71
		local v73 = v_u_71.Value
		local v74 = math.max(0, v73)
		v72.Value = math.min(100, v74)
		v_u_68[v_u_69] = v_u_71.Value
	end)
end
function DealWithInput(p75, _)
	-- upvalues: (copy) v_u_2, (ref) v_u_35, (copy) v_u_22, (ref) v_u_24, (ref) v_u_15, (ref) v_u_17, (ref) v_u_25, (copy) v_u_4, (ref) v_u_30, (ref) v_u_31, (ref) v_u_32, (ref) v_u_33, (ref) v_u_34, (copy) v_u_3, (ref) v_u_16, (ref) v_u_26, (ref) v_u_27, (ref) v_u_28, (ref) v_u_29, (ref) v_u_18, (ref) v_u_19
	if v_u_2:GetFocusedTextBox() == nil and not v_u_35 then
		if (p75.KeyCode == v_u_22.ContlrShiftDown or v_u_24 and p75.KeyCode == v_u_22.MouseShiftDown or not v_u_24 and p75.KeyCode == v_u_22.ShiftDown) and ((v_u_15 and (v_u_17 == "Auto" and (v_u_25 <= 1 and v_u_4.AutoShiftVers == "New")) or (v_u_17 == "Semi" or v_u_17 == "Manual")) and p75.UserInputState == Enum.UserInputState.Begin) then
			if not v_u_30 then
				v_u_30 = true
			end
		elseif (p75.KeyCode == v_u_22.ContlrShiftUp or v_u_24 and p75.KeyCode == v_u_22.MouseShiftUp or not v_u_24 and p75.KeyCode == v_u_22.ShiftUp) and ((v_u_15 and (v_u_17 == "Auto" and (v_u_25 < 1 and v_u_4.AutoShiftVers == "New")) or (v_u_17 == "Semi" or v_u_17 == "Manual")) and p75.UserInputState == Enum.UserInputState.Begin) then
			if not v_u_31 then
				v_u_31 = true
			end
		elseif (p75.KeyCode == v_u_22.ContlrClutch or v_u_24 and p75.KeyCode == v_u_22.MouseClutch or not v_u_24 and p75.KeyCode == v_u_22.Clutch) and v_u_17 == "Manual" then
			if p75.UserInputState == Enum.UserInputState.Begin then
				v_u_32 = true
				v_u_33 = true
			elseif p75.UserInputState == Enum.UserInputState.End then
				v_u_32 = false
				v_u_33 = false
			end
		elseif p75.KeyCode == v_u_22.ContlrPBrake or v_u_24 and p75.KeyCode == v_u_22.MousePBrake or not v_u_24 and p75.KeyCode == v_u_22.PBrake then
			if p75.UserInputState == Enum.UserInputState.Begin then
				v_u_34 = not v_u_34
			elseif p75.UserInputState == Enum.UserInputState.End and v_u_3.DriveSeat.Velocity.Magnitude > 5 then
				v_u_34 = false
			end
		elseif (p75.KeyCode == v_u_22.ContlrToggleTMode or p75.KeyCode == v_u_22.ToggleTransMode) and p75.UserInputState == Enum.UserInputState.Begin then
			local v76 = 1
			for v77, v78 in pairs(v_u_4.TransModes) do
				if v78 == v_u_17 then
					v76 = v77
					break
				end
			end
			local v79 = v76 + 1
			local v80 = #v_u_4.TransModes < v79 and 1 or v79
			v_u_17 = v_u_4.TransModes[v80]
		elseif (v_u_24 or p75.KeyCode ~= v_u_22.Throttle and p75.KeyCode ~= v_u_22.Throttle2) and ((v_u_22.MouseThrottle ~= Enum.UserInputType.MouseButton1 and v_u_22.MouseThrottle ~= Enum.UserInputType.MouseButton2 or p75.UserInputType ~= v_u_22.MouseThrottle) and p75.KeyCode ~= v_u_22.MouseThrottle or not v_u_24) then
			if (v_u_24 or p75.KeyCode ~= v_u_22.Brake and p75.KeyCode ~= v_u_22.Brake2) and ((v_u_22.MouseBrake ~= Enum.UserInputType.MouseButton1 and v_u_22.MouseBrake ~= Enum.UserInputType.MouseButton2 or p75.UserInputType ~= v_u_22.MouseBrake) and p75.KeyCode ~= v_u_22.MouseBrake or not v_u_24) then
				if v_u_24 or p75.KeyCode ~= v_u_22.SteerLeft and p75.KeyCode ~= v_u_22.SteerLeft2 then
					if v_u_24 or p75.KeyCode ~= v_u_22.SteerRight and p75.KeyCode ~= v_u_22.SteerRight2 then
						if p75.KeyCode == v_u_22.ToggleMouseDrive then
							if p75.UserInputState == Enum.UserInputState.End then
								v_u_24 = not v_u_24
								v_u_16 = v_u_4.IdleThrottle / 100
								v_u_26 = 0
								v_u_27 = 0
							end
						elseif v_u_4.TCSEnabled and (v_u_15 and p75.KeyCode == v_u_22.ToggleTCS) or p75.KeyCode == v_u_22.ContlrToggleTCS then
							if p75.UserInputState == Enum.UserInputState.End then
								v_u_18 = not v_u_18
							end
						elseif (v_u_4.ABSEnabled and (v_u_15 and p75.KeyCode == v_u_22.ToggleABS) or p75.KeyCode == v_u_22.ContlrToggleABS) and p75.UserInputState == Enum.UserInputState.End then
							v_u_19 = not v_u_19
						end
					elseif p75.UserInputState == Enum.UserInputState.Begin then
						v_u_27 = 1
						v_u_29 = true
					else
						if v_u_28 then
							v_u_27 = -1
						else
							v_u_27 = 0
						end
						v_u_29 = false
					end
				elseif p75.UserInputState == Enum.UserInputState.Begin then
					v_u_27 = -1
					v_u_28 = true
				else
					if v_u_29 then
						v_u_27 = 1
					else
						v_u_27 = 0
					end
					v_u_28 = false
				end
			elseif p75.UserInputState == Enum.UserInputState.Begin then
				v_u_26 = 1
			else
				v_u_26 = 0
			end
		elseif p75.UserInputState == Enum.UserInputState.Begin and v_u_15 then
			v_u_16 = 1
		else
			v_u_16 = v_u_4.IdleThrottle / 100
		end
		if p75.UserInputType.Name:find("Gamepad") then
			if p75.KeyCode == v_u_22.ContlrSteer then
				if p75.Position.X >= 0 then
					local v81 = v_u_4.Peripherals.ControlRDZone / 100
					local v82 = math.min(0.99, v81)
					local v83 = p75.Position.X
					if v82 < math.abs(v83) then
						v_u_27 = (p75.Position.X - v82) / (1 - v82)
					else
						v_u_27 = 0
					end
				else
					local v84 = v_u_4.Peripherals.ControlLDZone / 100
					local v85 = math.min(0.99, v84)
					local v86 = p75.Position.X
					if v85 < math.abs(v86) then
						v_u_27 = (p75.Position.X + v85) / (1 - v85)
					else
						v_u_27 = 0
					end
				end
			end
			if p75.KeyCode == v_u_22.ContlrThrottle then
				if v_u_15 then
					local v87 = v_u_4.IdleThrottle / 100
					local v88 = p75.Position.Z
					v_u_16 = math.max(v87, v88)
				else
					v_u_16 = v_u_4.IdleThrottle / 100
				end
			end
			if p75.KeyCode == v_u_22.ContlrBrake then
				v_u_26 = p75.Position.Z
				return
			end
		end
	else
		v_u_16 = v_u_4.IdleThrottle / 100
		v_u_27 = 0
		v_u_26 = 0
	end
end
v_u_2.InputBegan:connect(DealWithInput)
v_u_2.InputChanged:connect(DealWithInput)
v_u_2.InputEnded:connect(DealWithInput)
local v_u_89 = {}
if v_u_4.Config == "FWD" or v_u_4.Config == "AWD" then
	for _, v90 in pairs(v_u_3.Wheels:GetChildren()) do
		if v90.Name == "FL" or (v90.Name == "FR" or v90.Name == "F") then
			table.insert(v_u_89, v90)
		end
	end
end
if v_u_4.Config == "RWD" or v_u_4.Config == "AWD" then
	for _, v91 in pairs(v_u_3.Wheels:GetChildren()) do
		if v91.Name == "RL" or (v91.Name == "RR" or v91.Name == "R") then
			table.insert(v_u_89, v91)
		end
	end
end
local v92 = 0
for _, v93 in pairs(v_u_89) do
	if v92 < v93.Size.x then
		v92 = v93.Size.x
	end
end
for _, v94 in pairs(v_u_3.Wheels:GetChildren()) do
	local v95 = v94["#BV"].MotorMaxTorque - v_u_8
	if math.abs(v95) < 1 then
		::l38::
		local v96 = true
		v_u_34 = v96
	else
		local v97 = v94["#BV"].MotorMaxTorque - v_u_9
		if math.abs(v97) < 1 then
			goto l38
		end
	end
end
function Inputs(p98)
	-- upvalues: (ref) v_u_51, (ref) v_u_16, (copy) v_u_4, (ref) v_u_40, (ref) v_u_26
	local v99 = 60 / (1 / p98)
	if v_u_51 <= v_u_16 then
		local v100 = v_u_16
		local v101 = v_u_51 + v_u_4.ThrotAccel * v99
		v_u_51 = math.min(v100, v101)
	else
		local v102 = v_u_16
		local v103 = v_u_51 - v_u_4.ThrotDecel * v99
		v_u_51 = math.max(v102, v103)
	end
	if v_u_40 <= v_u_26 then
		local v104 = v_u_26
		local v105 = v_u_40 + v_u_4.BrakeAccel * v99
		v_u_40 = math.min(v104, v105)
	else
		local v106 = v_u_26
		local v107 = v_u_40 - v_u_4.BrakeDecel * v99
		v_u_40 = math.max(v106, v107)
	end
end
if v_u_4.SteeringType == "New" then
	v_u_11 = v_u_4.LockToLock * 180 / v_u_4.SteerRatio
	local v108 = v_u_11 - v_u_11 * (1 - v_u_4.Ackerman)
	local v109 = v_u_11 * 1.2
	v_u_12 = math.min(v108, v109)
end
function Steering(p110)
	-- upvalues: (ref) v_u_24, (copy) v_u_1, (copy) v_u_4, (ref) v_u_27, (ref) v_u_41, (copy) v_u_3, (ref) v_u_11, (ref) v_u_12, (copy) v_u_14, (copy) v_u_13
	local v111 = 60 / (1 / p110)
	if v_u_24 then
		local v112 = v_u_1.ViewSizeX * v_u_4.Peripherals.MSteerWidth / 200
		local v113 = math.max(1, v112)
		local v114 = v_u_4.Peripherals.MSteerDZone / 100
		local v115 = (v_u_1.X - v_u_1.ViewSizeX / 2) / v113
		if math.abs(v115) <= v114 then
			v_u_27 = 0
		else
			local v116 = math.abs(v115) - v114
			local v117 = 1 - v114
			local v118 = math.min(v116, v117)
			v_u_27 = (math.max(v118, 0) / (1 - v114)) ^ v_u_4.MSteerExp * (v115 / math.abs(v115))
		end
	end
	if v_u_41 < v_u_27 then
		if v_u_41 < 0 then
			local v119 = v_u_27
			local v120 = v_u_41 + v_u_4.ReturnSpeed * v111
			v_u_41 = math.min(v119, v120)
		else
			local v121 = v_u_27
			local v122 = v_u_41 + v_u_4.SteerSpeed * v111
			v_u_41 = math.min(v121, v122)
		end
	elseif v_u_41 > 0 then
		local v123 = v_u_27
		local v124 = v_u_41 - v_u_4.ReturnSpeed * v111
		v_u_41 = math.max(v123, v124)
	else
		local v125 = v_u_27
		local v126 = v_u_41 - v_u_4.SteerSpeed * v111
		v_u_41 = math.max(v125, v126)
	end
	local v127 = v_u_3.DriveSeat.Velocity.Magnitude / v_u_4.SteerDecay
	local v128 = 1 - v_u_4.MinSteer / 100
	local v129 = 1 - math.min(v127, v128)
	local v130 = v_u_3.DriveSeat.Velocity.Magnitude / v_u_4.RSteerDecay
	local v131 = 1 - v_u_4.MinSteer / 100
	local v132 = 1 - math.min(v130, v131)
	for _, v133 in pairs(v_u_3.Wheels:GetChildren()) do
		if v133.Name == "F" then
			local v134 = v133.Arm.Steer
			local v135 = v_u_3.Wheels.F.Base.CFrame
			local v136 = CFrame.Angles
			local v137 = v_u_41 * v_u_4.SteerInner * v129
			v134.CFrame = v135 * v136(0, -math.rad(v137), 0)
		elseif v133.Name == "FL" then
			if v_u_41 >= 0 then
				local v138 = v133.Arm.Steer
				local v139 = v_u_3.Wheels.FL.Base.CFrame
				local v140 = CFrame.Angles
				local v141 = v_u_41 * v_u_11 * v129
				v138.CFrame = v139 * v140(0, -math.rad(v141), 0)
			else
				local v142 = v133.Arm.Steer
				local v143 = v_u_3.Wheels.FL.Base.CFrame
				local v144 = CFrame.Angles
				local v145 = v_u_41 * v_u_12 * v129
				v142.CFrame = v143 * v144(0, -math.rad(v145), 0)
			end
		elseif v133.Name == "FR" then
			if v_u_41 >= 0 then
				local v146 = v133.Arm.Steer
				local v147 = v_u_3.Wheels.FR.Base.CFrame
				local v148 = CFrame.Angles
				local v149 = v_u_41 * v_u_12 * v129
				v146.CFrame = v147 * v148(0, -math.rad(v149), 0)
			else
				local v150 = v133.Arm.Steer
				local v151 = v_u_3.Wheels.FR.Base.CFrame
				local v152 = CFrame.Angles
				local v153 = v_u_41 * v_u_11 * v129
				v150.CFrame = v151 * v152(0, -math.rad(v153), 0)
			end
		elseif v133.Name == "R" then
			if v_u_4.FWSteer ~= "None" then
				if v_u_4.FWSteer == "Static" then
					local v154 = v133.Arm.Steer
					local v155 = v_u_3.Wheels.R.Base.CFrame
					local v156 = CFrame.Angles
					local v157 = v_u_41 * v_u_14 * v132
					local v158 = 1 - v_u_3.DriveSeat.Velocity.Magnitude / v_u_4.RSteerSpeed
					local v159 = v157 * math.max(0, v158)
					v154.CFrame = v155 * v156(0, math.rad(v159), 0)
				elseif v_u_4.FWSteer == "Speed" then
					local v160 = v133.Arm.Steer
					local v161 = v_u_3.Wheels.R.Base.CFrame
					local v162 = CFrame.Angles
					local v163 = v_u_41 * v_u_14 * v132
					local v164 = v_u_3.DriveSeat.Velocity.Magnitude / v_u_4.RSteerSpeed
					local v165 = v163 * math.min(1, v164)
					v160.CFrame = v161 * v162(0, -math.rad(v165), 0)
				elseif v_u_4.FWSteer == "Both" then
					local v166 = v133.Arm.Steer
					local v167 = v_u_3.Wheels.R.Base.CFrame
					local v168 = CFrame.Angles
					local v169 = v_u_41 * v_u_14 * v132
					local v170 = 1 - v_u_3.DriveSeat.Velocity.Magnitude / v_u_4.RSteerSpeed
					local v171 = v169 * math.max(-1, v170)
					v166.CFrame = v167 * v168(0, math.rad(v171), 0)
				end
			end
		elseif v133.Name == "RL" then
			if v_u_4.FWSteer ~= "None" then
				if v_u_4.FWSteer == "Static" then
					if v_u_41 >= 0 then
						local v172 = v133.Arm.Steer
						local v173 = v_u_3.Wheels.RL.Base.CFrame
						local v174 = CFrame.Angles
						local v175 = v_u_41 * v_u_13 * v132
						local v176 = 1 - v_u_3.DriveSeat.Velocity.Magnitude / v_u_4.RSteerSpeed
						local v177 = v175 * math.max(0, v176)
						v172.CFrame = v173 * v174(0, math.rad(v177), 0)
					else
						local v178 = v133.Arm.Steer
						local v179 = v_u_3.Wheels.RL.Base.CFrame
						local v180 = CFrame.Angles
						local v181 = v_u_41 * v_u_14 * v132
						local v182 = 1 - v_u_3.DriveSeat.Velocity.Magnitude / v_u_4.RSteerSpeed
						local v183 = v181 * math.max(0, v182)
						v178.CFrame = v179 * v180(0, math.rad(v183), 0)
					end
				elseif v_u_4.FWSteer == "Speed" then
					if v_u_41 >= 0 then
						local v184 = v133.Arm.Steer
						local v185 = v_u_3.Wheels.RL.Base.CFrame
						local v186 = CFrame.Angles
						local v187 = v_u_41 * v_u_13 * v132
						local v188 = v_u_3.DriveSeat.Velocity.Magnitude / v_u_4.RSteerSpeed
						local v189 = v187 * math.min(1, v188)
						v184.CFrame = v185 * v186(0, -math.rad(v189), 0)
					else
						local v190 = v133.Arm.Steer
						local v191 = v_u_3.Wheels.RL.Base.CFrame
						local v192 = CFrame.Angles
						local v193 = v_u_41 * v_u_14 * v132
						local v194 = v_u_3.DriveSeat.Velocity.Magnitude / v_u_4.RSteerSpeed
						local v195 = v193 * math.min(1, v194)
						v190.CFrame = v191 * v192(0, -math.rad(v195), 0)
					end
				elseif v_u_4.FWSteer == "Both" then
					if v_u_41 >= 0 then
						local v196 = v133.Arm.Steer
						local v197 = v_u_3.Wheels.RL.Base.CFrame
						local v198 = CFrame.Angles
						local v199 = v_u_41 * v_u_13 * v132
						local v200 = 1 - v_u_3.DriveSeat.Velocity.Magnitude / v_u_4.RSteerSpeed
						local v201 = v199 * math.max(-1, v200)
						v196.CFrame = v197 * v198(0, math.rad(v201), 0)
					else
						local v202 = v133.Arm.Steer
						local v203 = v_u_3.Wheels.RL.Base.CFrame
						local v204 = CFrame.Angles
						local v205 = v_u_41 * v_u_14 * v132
						local v206 = 1 - v_u_3.DriveSeat.Velocity.Magnitude / v_u_4.RSteerSpeed
						local v207 = v205 * math.max(-1, v206)
						v202.CFrame = v203 * v204(0, math.rad(v207), 0)
					end
				end
			end
		elseif v133.Name == "RR" then
			if v_u_4.FWSteer ~= "None" then
				if v_u_4.FWSteer == "Static" then
					if v_u_41 >= 0 then
						local v208 = v133.Arm.Steer
						local v209 = v_u_3.Wheels.RR.Base.CFrame
						local v210 = CFrame.Angles
						local v211 = v_u_41 * v_u_14 * v132
						local v212 = 1 - v_u_3.DriveSeat.Velocity.Magnitude / v_u_4.RSteerSpeed
						local v213 = v211 * math.max(0, v212)
						v208.CFrame = v209 * v210(0, math.rad(v213), 0)
					else
						local v214 = v133.Arm.Steer
						local v215 = v_u_3.Wheels.RR.Base.CFrame
						local v216 = CFrame.Angles
						local v217 = v_u_41 * v_u_13 * v132
						local v218 = 1 - v_u_3.DriveSeat.Velocity.Magnitude / v_u_4.RSteerSpeed
						local v219 = v217 * math.max(0, v218)
						v214.CFrame = v215 * v216(0, math.rad(v219), 0)
					end
				elseif v_u_4.FWSteer == "Speed" then
					if v_u_41 >= 0 then
						local v220 = v133.Arm.Steer
						local v221 = v_u_3.Wheels.RR.Base.CFrame
						local v222 = CFrame.Angles
						local v223 = v_u_41 * v_u_14 * v132
						local v224 = v_u_3.DriveSeat.Velocity.Magnitude / v_u_4.RSteerSpeed
						local v225 = v223 * math.min(1, v224)
						v220.CFrame = v221 * v222(0, -math.rad(v225), 0)
					else
						local v226 = v133.Arm.Steer
						local v227 = v_u_3.Wheels.RR.Base.CFrame
						local v228 = CFrame.Angles
						local v229 = v_u_41 * v_u_13 * v132
						local v230 = v_u_3.DriveSeat.Velocity.Magnitude / v_u_4.RSteerSpeed
						local v231 = v229 * math.min(1, v230)
						v226.CFrame = v227 * v228(0, -math.rad(v231), 0)
					end
				elseif v_u_4.FWSteer == "Both" then
					if v_u_41 >= 0 then
						local v232 = v133.Arm.Steer
						local v233 = v_u_3.Wheels.RR.Base.CFrame
						local v234 = CFrame.Angles
						local v235 = v_u_41 * v_u_14 * v132
						local v236 = 1 - v_u_3.DriveSeat.Velocity.Magnitude / v_u_4.RSteerSpeed
						local v237 = v235 * math.max(-1, v236)
						v232.CFrame = v233 * v234(0, math.rad(v237), 0)
					else
						local v238 = v133.Arm.Steer
						local v239 = v_u_3.Wheels.RR.Base.CFrame
						local v240 = CFrame.Angles
						local v241 = v_u_41 * v_u_13 * v132
						local v242 = 1 - v_u_3.DriveSeat.Velocity.Magnitude / v_u_4.RSteerSpeed
						local v243 = v241 * math.max(-1, v242)
						v238.CFrame = v239 * v240(0, math.rad(v243), 0)
					end
				end
			end
		end
	end
end
local v_u_244 = v_u_4.FinalDrive * v_u_4.FDMult
local v_u_245 = v_u_244 * 30 / 3.141592653589793
local v_u_246 = workspace.Gravity * v_u_4.InclineComp / 32.2
local v_u_247 = v92 * 3.141592653589793 / 60
local v_u_248 = CFrame.Angles(1.5707963267948966, -1.5707963267948966, 0)
local v_u_249 = CFrame.Angles(0, 3.141592653589793, 0)
if not v_u_4.Engine and v_u_4.Electric then
	v_u_4.Redline = v_u_4.E_Redline
	v_u_4.PeakRPM = v_u_4.E_Trans2
	v_u_4.Turbochargers = 0
	v_u_4.Superchargers = 0
	v_u_4.Clutch = false
	v_u_4.IdleRPM = 0
	v_u_4.ClutchType = "Clutch"
	v_u_4.AutoShiftType = "DCT"
	v_u_4.ShiftUpTime = 0.1
	v_u_4.ShiftDnTime = 0.1
end
local v_u_250 = v_u_4.Turbochargers
local v_u_251 = v_u_4.T_Boost * v_u_4.Turbochargers
local v_u_252 = v_u_4.Superchargers
local v_u_253 = v_u_4.S_Boost * v_u_4.Superchargers
local v_u_254 = v_u_4.Horsepower / 100
local v_u_255 = v_u_4.Horsepower * (v_u_251 * (v_u_4.T_Efficiency / 10)) / 7.5 / 2 / 100
local v_u_256 = v_u_4.Horsepower * (v_u_253 * (v_u_4.S_Efficiency / 10)) / 7.5 / 2 / 100
local v_u_257 = v_u_4.PeakRPM / 1000
local v_u_258 = v_u_4.PeakSharpness
local v_u_259 = v_u_4.CurveMult
local v_u_260 = v_u_4.EqPoint / 1000
function CurveN(p261)
	-- upvalues: (copy) v_u_257, (copy) v_u_254, (copy) v_u_259, (copy) v_u_258
	local v262 = p261 / 1000
	local v263 = -(v262 - v_u_257) ^ 2
	local v264 = v_u_254 / v_u_257 ^ 2
	local v265 = v_u_259 ^ (v_u_257 / v_u_254)
	return (v263 * math.min(v264, v265) + v_u_254) * (v262 - v262 ^ v_u_258 / (v_u_258 * v_u_257 ^ (v_u_258 - 1)))
end
local v_u_266 = CurveN(v_u_4.PeakRPM)
function CurveT(p267)
	-- upvalues: (copy) v_u_257, (copy) v_u_255, (copy) v_u_259, (copy) v_u_258
	local v268 = p267 / 1000
	local v269 = -(v268 - v_u_257) ^ 2
	local v270 = v_u_255 / v_u_257 ^ 2
	local v271 = v_u_259 ^ (v_u_257 / v_u_255)
	return (v269 * math.min(v270, v271) + v_u_255) * (v268 - v268 ^ v_u_258 / (v_u_258 * v_u_257 ^ (v_u_258 - 1)))
end
local v_u_272 = CurveT(v_u_4.PeakRPM)
function CurveS(p273)
	-- upvalues: (copy) v_u_257, (copy) v_u_256, (copy) v_u_259, (copy) v_u_258
	local v274 = p273 / 1000
	local v275 = -(v274 - v_u_257) ^ 2
	local v276 = v_u_256 / v_u_257 ^ 2
	local v277 = v_u_259 ^ (v_u_257 / v_u_256)
	return (v275 * math.min(v276, v277) + v_u_256) * (v274 - v274 ^ v_u_258 / (v_u_258 * v_u_257 ^ (v_u_258 - 1)))
end
local v_u_278 = CurveS(v_u_4.PeakRPM)
local v_u_279 = v_u_4.E_Horsepower / 100
local v_u_280 = v_u_4.E_Torque / 100
local v_u_281 = v_u_4.E_Trans1 / 1000
local v_u_282 = v_u_4.E_Trans2 / 1000
local v_u_283 = v_u_4.E_Redline / 1000
function elecHP(p284)
	-- upvalues: (copy) v_u_281, (copy) v_u_4, (copy) v_u_279, (copy) v_u_282, (copy) v_u_283
	local v285 = p284 / 1000
	local v286 = 1e-9
	if v285 <= v_u_281 then
		return (v285 / v_u_281) ^ v_u_4.EH_FrontMult / (1 / v_u_279) * (v285 / v_u_281) + (v285 / v_u_281) ^ (1 / v_u_4.EH_FrontMult) / (1 / v_u_279) * (1 - v285 / v_u_281)
	end
	if v_u_281 < v285 and v285 < v_u_282 then
		return v_u_279
	end
	if v_u_282 <= v285 then
		return v_u_279 - ((v285 - v_u_282) / (v_u_283 - v_u_282)) ^ v_u_4.EH_EndMult / (1 / (v_u_279 * (v_u_4.EH_EndPercent / 100)))
	end
	error("\n\t [AC6C]: Drive initialization failed!" .. "\n\t    An unknown error occured when initializing electric horsepower." .. "\n\t    Please send a screenshot of this message to Avxnturador." .. "\n\t    R: " .. v285 .. ", T1: " .. v_u_281(", T2: ") .. v_u_282(", L: ") .. v_u_283("."))
	return v286
end
function elecTQ(p287)
	-- upvalues: (copy) v_u_281, (copy) v_u_280, (copy) v_u_283, (copy) v_u_4, (copy) v_u_282
	local v288 = p287 / 1000
	local v289 = 1e-9
	if v288 < v_u_281 then
		return v_u_280
	end
	if v_u_281 <= v288 then
		return v_u_280 - ((v288 - v_u_281) / (v_u_283 - v_u_281)) ^ v_u_4.ET_EndMult / (1 / (v_u_280 * (v_u_4.ET_EndPercent / 100)))
	end
	error("\n\t [AC6C]: Drive initialization failed!" .. "\n\t    An unknown error occured when initializing electric torque." .. "\n\t    Please send a screenshot of this message to Avxnturador." .. "\n\t    R: " .. v288 .. ", T1: " .. v_u_281(", T2: ") .. v_u_282(", L: ") .. v_u_283("."))
	return v289
end
function GetNCurve(p290, p291)
	-- upvalues: (copy) v_u_266, (copy) v_u_254, (copy) v_u_260, (copy) v_u_4, (copy) v_u_244, (copy) v_u_5
	local v292 = CurveN(p290) / (v_u_266 / v_u_254)
	local v293 = math.max(v292, 0) * 100
	return v293, v293 * (v_u_260 / p290) * v_u_4.Ratios[p291 + 2] * v_u_244 * v_u_5 * 1000
end
function GetECurve(p294, p295)
	-- upvalues: (copy) v_u_4, (copy) v_u_244, (copy) v_u_5
	local v296 = elecHP(p294)
	local v297 = math.max(v296, 0) * 100
	local v298 = elecTQ(p294)
	local v299 = math.max(v298, 0) * 100
	if p295 == 0 then
		return 0, 0
	end
	local v300 = v299 * v_u_4.Ratios[p295 + 2] * v_u_244 * v_u_5
	return v297, math.max(v300, 0)
end
function GetTCurve(p301, p302)
	-- upvalues: (copy) v_u_272, (copy) v_u_255, (copy) v_u_260, (copy) v_u_4, (copy) v_u_244, (copy) v_u_5
	local v303 = CurveT(p301) / (v_u_272 / v_u_255)
	local v304 = math.max(v303, 0) * 100
	return v304, v304 * (v_u_260 / p301) * v_u_4.Ratios[p302 + 2] * v_u_244 * v_u_5 * 1000
end
function GetSCurve(p305, p306)
	-- upvalues: (copy) v_u_278, (copy) v_u_256, (copy) v_u_260, (copy) v_u_4, (copy) v_u_244, (copy) v_u_5
	local v307 = CurveS(p305) / (v_u_278 / v_u_256)
	local v308 = math.max(v307, 0) * 100
	return v308, v308 * (v_u_260 / p305) * v_u_4.Ratios[p306 + 2] * v_u_244 * v_u_5 * 1000
end
local v_u_309 = {}
local v_u_310 = {}
local v_u_311 = {}
local v_u_312 = {}
for v313, _ in pairs(v_u_4.Ratios) do
	local v314 = (v_u_4.Redline + 100) / 100
	local v315 = {}
	local v316 = {}
	local v317 = {}
	local v318 = {}
	for v319 = 0, math.ceil(v314) do
		local v320 = {}
		local v321 = {}
		local v322 = {}
		local v323 = {}
		if v319 == 0 then
			v320.Horsepower = 0
			v320.Torque = 0
			v321.Horsepower = 0
			v321.Torque = 0
			v322.Horsepower = 0
			v322.Torque = 0
			v323.Horsepower = 0
			v323.Torque = 0
		else
			if v_u_4.Engine then
				local v324, v325 = GetNCurve(v319 * 100, v313 - 2)
				v320.Horsepower = v324
				v320.Torque = v325
				if v_u_250 == 0 then
					v322.Horsepower = 0
					v322.Torque = 0
				else
					local v326, v327 = GetTCurve(v319 * 100, v313 - 2)
					v322.Horsepower = v326
					v322.Torque = v327
				end
				if v_u_252 == 0 then
					v323.Horsepower = 0
					v323.Torque = 0
				else
					local v328, v329 = GetSCurve(v319 * 100, v313 - 2)
					v323.Horsepower = v328
					v323.Torque = v329
				end
			else
				v320.Horsepower = 0
				v320.Torque = 0
				v322.Horsepower = 0
				v322.Torque = 0
				v323.Horsepower = 0
				v323.Torque = 0
			end
			if v_u_4.Electric then
				local v330, v331 = GetECurve(v319 * 100, v313 - 2)
				v321.Horsepower = v330
				v321.Torque = v331
			else
				v321.Horsepower = 0
				v321.Torque = 0
			end
		end
		if v_u_4.Engine then
			local v332, v333 = GetNCurve((v319 + 1) * 100, v313 - 2)
			nhp = v332
			ntq = v333
			if v_u_250 == 0 then
				thp = 0
				ttq = 0
			else
				local v334, v335 = GetTCurve((v319 + 1) * 100, v313 - 2)
				thp = v334
				ttq = v335
			end
			if v_u_252 == 0 then
				shp = 0
				stq = 0
			else
				local v336, v337 = GetSCurve((v319 + 1) * 100, v313 - 2)
				shp = v336
				stq = v337
			end
		else
			nhp = 0
			ntq = 0
			thp = 0
			ttq = 0
			shp = 0
			stq = 0
		end
		if v_u_4.Electric then
			local v338, v339 = GetECurve((v319 + 1) * 100, v313 - 2)
			ehp = v338
			etq = v339
		else
			ehp = 0
			etq = 0
		end
		local v340 = nhp - v320.Horsepower
		local v341 = ntq - v320.Torque
		v320.HpSlope = v340
		v320.TqSlope = v341
		local v342 = ehp - v321.Horsepower
		local v343 = etq - v321.Torque
		v321.HpSlope = v342
		v321.TqSlope = v343
		local v344 = thp - v322.Horsepower
		local v345 = ttq - v322.Torque
		v322.HpSlope = v344
		v322.TqSlope = v345
		local v346 = shp - v323.Horsepower
		local v347 = stq - v323.Torque
		v323.HpSlope = v346
		v323.TqSlope = v347
		v315[v319] = v320
		v316[v319] = v321
		v317[v319] = v322
		v318[v319] = v323
	end
	table.insert(v_u_309, v315)
	table.insert(v_u_310, v316)
	table.insert(v_u_311, v317)
	table.insert(v_u_312, v318)
end
wait()
function Auto()
	-- upvalues: (copy) v_u_89, (ref) v_u_15, (copy) v_u_4, (ref) v_u_25, (ref) v_u_32, (ref) v_u_40, (copy) v_u_3, (ref) v_u_64, (ref) v_u_31, (ref) v_u_46, (copy) v_u_245, (ref) v_u_30, (copy) v_u_247, (copy) v_u_244, (ref) v_u_51
	local v348 = 0
	for _, v349 in pairs(v_u_89) do
		if v348 < v349.RotVelocity.Magnitude then
			v348 = v349.RotVelocity.Magnitude
		end
	end
	if v_u_15 then
		if v_u_4.AutoShiftVers == "Old" and v_u_25 == 0 then
			v_u_25 = 1
			v_u_32 = false
		end
		if v_u_25 >= 1 then
			if v_u_25 == 1 and (v_u_40 > 0 and (v_u_3.DriveSeat.Velocity.Magnitude < 5 and v_u_4.AutoShiftVers == "Old")) then
				v_u_25 = -1
				v_u_32 = false
				return
			end
			if v_u_3.DriveSeat.Velocity.Magnitude > 5 then
				if v_u_4.AutoShiftMode == "RPM" then
					if v_u_64 > v_u_4.PeakRPM + v_u_4.AutoUpThresh then
						if not (v_u_31 or v_u_46) then
							v_u_31 = true
							return
						end
					else
						local v350 = v348 * v_u_4.Ratios[v_u_25 + 1] * v_u_245
						local v351 = v_u_4.Redline + 100
						local v352 = math.min(v350, v351)
						local v353 = v_u_4.IdleRPM
						if math.max(v352, v353) < v_u_4.PeakRPM - v_u_4.AutoDownThresh and (v_u_25 > 1 and not (v_u_30 or v_u_46)) then
							v_u_30 = true
							return
						end
					end
				else
					local v354 = v_u_3.DriveSeat.Velocity.Magnitude
					local v355 = v_u_247 * (v_u_4.PeakRPM + v_u_4.AutoUpThresh) / v_u_4.Ratios[v_u_25 + 2] / v_u_244
					if math.ceil(v355) < v354 then
						if not (v_u_31 or v_u_46) then
							v_u_31 = true
							return
						end
					else
						local v356 = v_u_3.DriveSeat.Velocity.Magnitude
						local v357 = v_u_247 * (v_u_4.PeakRPM - v_u_4.AutoDownThresh) / v_u_4.Ratios[v_u_25 + 1] / v_u_244
						if v356 < math.ceil(v357) and (v_u_25 > 1 and not (v_u_30 or v_u_46)) then
							v_u_30 = true
							return
						end
					end
				end
			end
		elseif v_u_51 - v_u_4.IdleThrottle / 100 > 0 and (v_u_3.DriveSeat.Velocity.Magnitude < 5 and v_u_4.AutoShiftVers == "Old") then
			v_u_25 = 1
			v_u_32 = false
		end
	end
end
function Gear()
	-- upvalues: (copy) v_u_89, (ref) v_u_31, (ref) v_u_46, (ref) v_u_17, (ref) v_u_32, (copy) v_u_4, (ref) v_u_51, (ref) v_u_25, (ref) v_u_15, (ref) v_u_64, (copy) v_u_245, (ref) v_u_30
	local v358 = 0
	for _, v359 in pairs(v_u_89) do
		if v358 < v359.RotVelocity.Magnitude then
			v358 = v359.RotVelocity.Magnitude
		end
	end
	if v_u_31 and not v_u_46 then
		if v_u_17 == "Manual" and not v_u_32 or (v_u_17 == "Manual" and (v_u_4.ClutchRel and v_u_51 - v_u_4.IdleThrottle / 100 > 0) or (v_u_25 == #v_u_4.Ratios - 2 or v_u_17 ~= "Manual" and not v_u_15)) then
			v_u_31 = false
			return
		end
		local v360 = v_u_25 + 3
		local v361 = #v_u_4.Ratios
		local v362 = math.min(v360, v361)
		if v_u_17 ~= "Manual" then
			v_u_46 = true
			if v_u_25 > 0 then
				if v_u_4.AutoShiftType == "DCT" then
					wait(v_u_4.ShiftUpTime)
				elseif v_u_4.AutoShiftType == "Rev" then
					repeat
						wait()
						local v363 = v_u_64
						local v364 = v358 * v_u_4.Ratios[v362] * v_u_245
						local v365 = v_u_4.Redline - v_u_4.RevBounce
						local v366 = math.min(v364, v365)
						local v367 = v_u_4.IdleRPM
					until v363 <= math.max(v366, v367) or (not v_u_15 or v_u_30)
				end
			end
		end
		v_u_31 = false
		v_u_46 = false
		if v_u_17 ~= "Manual" and not v_u_15 then
			return
		end
		local v368 = v_u_25 + 1
		local v369 = #v_u_4.Ratios - 2
		v_u_25 = math.min(v368, v369)
		if v_u_17 ~= "Manual" or v_u_17 == "Manual" and (v_u_25 == 1 and v_u_15) then
			v_u_32 = false
		end
	end
	if v_u_30 and not v_u_46 then
		if v_u_17 == "Manual" and not v_u_32 or (v_u_25 == -1 or v_u_17 ~= "Manual" and not v_u_15) then
			v_u_30 = false
			return
		end
		local v370 = v_u_25 + 1
		local v371 = #v_u_4.Ratios
		local v372 = math.min(v370, v371)
		if v_u_17 ~= "Manual" then
			v_u_46 = true
			if v_u_25 > 1 then
				if v_u_4.AutoShiftType == "DCT" then
					wait(v_u_4.ShiftDnTime)
				elseif v_u_4.AutoShiftType == "Rev" then
					repeat
						wait()
						local v373 = v_u_64
						local v374 = v358 * v_u_4.Ratios[v372] * v_u_245
						local v375 = v_u_4.Redline - v_u_4.RevBounce
						local v376 = math.min(v374, v375)
						local v377 = v_u_4.IdleRPM
					until math.max(v376, v377) <= v373 or (not v_u_15 or v_u_31)
				end
			end
		end
		v_u_30 = false
		v_u_46 = false
		if v_u_17 ~= "Manual" and not v_u_15 then
			return
		end
		local v378 = v_u_25 - 1
		v_u_25 = math.max(v378, -1)
		if v_u_17 ~= "Manual" or v_u_17 == "Manual" and (v_u_25 == -1 and v_u_15) then
			v_u_32 = false
		end
	end
end
local v_u_379 = 0
local v_u_380 = 1
local v_u_381 = 0
local v_u_382 = false
local v_u_383 = tick()
function Engine(p384)
	-- upvalues: (ref) v_u_25, (ref) v_u_46, (ref) v_u_15, (ref) v_u_32, (ref) v_u_60, (ref) v_u_382, (copy) v_u_4, (ref) v_u_31, (ref) v_u_38, (ref) v_u_30, (ref) v_u_17, (ref) v_u_40, (ref) v_u_51, (ref) v_u_50, (ref) v_u_383, (ref) v_u_33, (copy) v_u_89, (ref) v_u_379, (ref) v_u_64, (copy) v_u_245, (ref) v_u_49, (ref) v_u_63, (ref) v_u_45, (ref) v_u_251, (ref) v_u_250, (ref) v_u_56, (ref) v_u_57, (ref) v_u_252, (ref) v_u_381, (ref) v_u_39, (copy) v_u_309, (ref) v_u_52, (ref) v_u_53, (copy) v_u_311, (ref) v_u_36, (ref) v_u_58, (copy) v_u_312, (ref) v_u_59, (ref) v_u_37, (ref) v_u_47, (ref) v_u_48, (copy) v_u_310, (ref) v_u_54, (ref) v_u_43, (ref) v_u_55, (copy) v_u_3, (copy) v_u_246, (copy) v_u_248, (copy) v_u_249, (ref) v_u_61, (ref) v_u_62, (ref) v_u_19, (ref) v_u_34, (ref) v_u_380, (ref) v_u_18, (ref) v_u_44, (copy) v_u_6, (copy) v_u_10, (copy) v_u_8, (copy) v_u_7, (copy) v_u_9
	local v385 = 60 / (1 / p384)
	if (v_u_25 == 0 or v_u_46) and v_u_15 then
		v_u_32 = true
		v_u_60 = 1
		v_u_382 = false
	end
	local v386 = v_u_4.IdleRPM
	local v387 = v_u_4.IdleRPM
	local v388 = v_u_4.Redline
	local v389 = v_u_4.Stall and v_u_4.Clutch and 0 or v386
	if v_u_46 and v_u_31 then
		v_u_38 = 0
	elseif v_u_46 and v_u_30 then
		v_u_38 = v_u_4.ShiftThrot / 100
	elseif v_u_4.AutoShiftVers == "Old" and (v_u_25 == -1 and v_u_17 == "Auto") then
		v_u_38 = v_u_40
	else
		v_u_38 = v_u_51
	end
	if v_u_4.AutoShiftVers == "Old" and (v_u_25 == -1 and v_u_17 == "Auto") then
		v_u_50 = v_u_51 - v_u_4.IdleThrottle / 100
	else
		v_u_50 = v_u_40
	end
	if not v_u_15 then
		v_u_383 = tick()
		v389 = 0
		v387 = 0
		v_u_38 = v_u_4.IdleThrottle / 100
		if v_u_17 ~= "Manual" then
			v_u_25 = 0
			v_u_32 = true
			v_u_60 = 1
		end
	end
	if (v_u_32 and v_u_25 == 0 or v_u_33 and v_u_25 ~= 0) and (v_u_4.NeutralLimit and (v_u_25 == 0 and not v_u_4.LimitClutch or v_u_4.LimitClutch)) then
		v388 = v_u_4.NeutralRevRPM
	end
	local v390 = v_u_38
	local v391 = 0
	local v392 = 0
	for _, v393 in pairs(v_u_89) do
		v391 = v391 + v393.RotVelocity.Magnitude
		v392 = v392 + 1
	end
	local v394 = v391 / v392
	if v_u_379 > v388 + 100 then
		v390 = v_u_4.IdleThrottle / 100
	end
	if v_u_4.Engine or v_u_4.Electric then
		local v395 = v_u_64 - v_u_4.RevDecay * v385 + (v_u_4.RevDecay + v_u_4.RevAccel) * v390 * v385
		local v396 = v_u_4.Redline + 100
		v_u_379 = math.clamp(v395, v387, v396)
	end
	if v_u_379 > v_u_4.Redline then
		if v_u_25 < #v_u_4.Ratios - 2 then
			v_u_379 = v_u_379 - v_u_4.RevBounce
		else
			v_u_379 = v_u_379 - v_u_4.RevBounce * 0.5
		end
	end
	local v397 = v394 * v_u_4.Ratios[v_u_25 + 2] * v_u_245
	if v_u_4.Clutch then
		if script.Parent.Values.AutoClutch.Value and v_u_15 then
			if v_u_4.ClutchType == "Clutch" then
				if v_u_32 then
					v_u_49 = 1
				end
				v_u_49 = v_u_49 * (v_u_4.ClutchEngage / 100)
				local v398 = (v_u_64 - v_u_4.IdleRPM) * v_u_4.ClutchRPMMult / (v_u_4.Redline - v_u_4.IdleRPM)
				local v399 = math.max(v398, 0)
				local v400 = v_u_4.ClutchMode == "New" and 0 or v399
				local v401 = v_u_25
				local v402 = script.Parent.Values.Velocity.Value.Magnitude / v_u_4.SpeedEngage / math.abs(v401) + v400 - v_u_49
				v_u_63 = math.min(v402, 1)
			elseif v_u_4.ClutchType == "CVT" or v_u_4.ClutchType == "TorqueConverter" and v_u_4.TQLock then
				if v_u_38 - v_u_4.IdleThrottle / 100 == 0 and script.Parent.Values.Velocity.Value.Magnitude < v_u_4.SpeedEngage or v_u_38 - v_u_4.IdleThrottle / 100 ~= 0 and (v_u_64 < v_u_4.RPMEngage and v397 < v_u_4.RPMEngage) then
					local v403 = v_u_63 * (v_u_4.ClutchEngage / 100)
					v_u_63 = math.min(v403, 1)
				else
					local v404 = v_u_63 * (v_u_4.ClutchEngage / 100) + (1 - v_u_4.ClutchEngage / 100)
					v_u_63 = math.min(v404, 1)
				end
			elseif v_u_4.ClutchType == "TorqueConverter" and not v_u_4.TQLock then
				local v405 = v_u_64 / v_u_4.Redline * 0.7
				v_u_63 = math.min(v405, 1)
			end
			if v_u_32 then
				v_u_60 = 1
			else
				local v406 = 1 - v_u_63
				v_u_60 = math.min(v406, 1)
			end
			v_u_382 = v_u_60 <= 0.01 and true or v_u_382
		else
			v_u_382 = v_u_4.Stall
			v_u_60 = script.Parent.Values.Clutch.Value
		end
	else
		v_u_382 = false
		if v_u_32 or v_u_46 then
			v_u_60 = 1
		else
			v_u_60 = 0
		end
	end
	local v407 = v_u_379 * v_u_60 + v397 * (1 - v_u_60)
	local v408 = v_u_4.Redline + 100
	local v409 = math.min(v407, v408)
	local v410 = math.max(v409, v389)
	local v411 = v410 - v_u_64
	local v412 = math.abs(v411) / (v_u_4.Flywheel * v385)
	local v413 = v_u_32 and 0 or math.min(v412, 0.9)
	v_u_64 = v_u_64 * v413 + v410 * (1 - v413)
	if v_u_64 <= v_u_4.IdleRPM / 4 and (v_u_382 and tick() - v_u_383 >= 0.2) then
		script.Parent.IsOn.Value = not v_u_4.Stall
	end
	v_u_45 = (v_u_4.Redline + 100) / (v_u_245 * v_u_4.Ratios[v_u_25 + 2])
	if v_u_64 > v_u_4.Redline then
		if v_u_25 < #v_u_4.Ratios - 2 then
			v_u_64 = v_u_64 - v_u_4.RevBounce
		else
			v_u_64 = v_u_64 - v_u_4.RevBounce * 0.5
		end
	end
	local v414 = v_u_251 / v_u_250
	local v415 = v_u_38
	if v_u_4.Engine then
		if v_u_250 == 0 then
			v_u_56 = 0
		else
			v_u_56 = v_u_56 + (v_u_57 * (v415 * 1.2) / v_u_4.Horsepower / 8 - v_u_56 / v414 * (v414 / 15)) * (8 / (v_u_4.T_Size / v385) * 2) / v414 * 15
			if v_u_56 < 0.05 then
				v_u_56 = 0.05
			elseif v_u_56 > 2 then
				v_u_56 = 2
			end
		end
		if v_u_252 == 0 then
			v_u_39 = 0
		else
			if v_u_381 < v415 then
				local v416 = v_u_381 + v_u_4.S_Sensitivity * v385
				v_u_381 = math.min(v415, v416)
			elseif v415 < v_u_381 then
				local v417 = v_u_381 - v_u_4.S_Sensitivity * v385
				v_u_381 = math.max(v415, v417)
			end
			v_u_39 = v_u_64 / v_u_4.Redline * (v_u_381 * 1.5 + 0.5)
		end
	else
		v_u_56 = 0
		v_u_39 = 0
	end
	if v_u_4.Engine then
		local v418 = v_u_309[v_u_25 + 2]
		local v419 = v_u_4.Redline
		local v420 = v_u_64
		local v421 = math.max(0, v420)
		local v422 = math.min(v419, v421) / 100
		local v423 = v418[math.floor(v422)]
		local v424 = v423.Horsepower
		local v425 = v423.HpSlope
		local v426 = v_u_64
		local v427 = v_u_64 / 100
		v_u_52 = v424 + v425 * ((v426 - math.floor(v427)) / 100 % 1)
		local v428 = v423.Torque
		local v429 = v423.TqSlope
		local v430 = v_u_64
		local v431 = v_u_64 / 100
		v_u_53 = v428 + v429 * ((v430 - math.floor(v431)) / 100 % 1)
		if v_u_250 == 0 then
			v_u_36 = 0
			v_u_58 = 0
		else
			local v432 = v_u_311[v_u_25 + 2]
			local v433 = v_u_4.Redline
			local v434 = v_u_64
			local v435 = math.max(0, v434)
			local v436 = math.min(v433, v435) / 100
			local v437 = v432[math.floor(v436)]
			local v438 = v437.Horsepower
			local v439 = v437.HpSlope
			local v440 = v_u_64
			local v441 = v_u_64 / 100
			v_u_36 = (v438 + v439 * ((v440 - math.floor(v441)) / 100 % 1)) * (v_u_56 / 2)
			local v442 = v437.Torque
			local v443 = v437.TqSlope
			local v444 = v_u_64
			local v445 = v_u_64 / 100
			v_u_58 = (v442 + v443 * ((v444 - math.floor(v445)) / 100 % 1)) * (v_u_56 / 2)
		end
		if v_u_252 == 0 then
			v_u_59 = 0
			v_u_37 = 0
		else
			local v446 = v_u_312[v_u_25 + 2]
			local v447 = v_u_4.Redline
			local v448 = v_u_64
			local v449 = math.max(0, v448)
			local v450 = math.min(v447, v449) / 100
			local v451 = v446[math.floor(v450)]
			local v452 = v451.Horsepower
			local v453 = v451.HpSlope
			local v454 = v_u_64
			local v455 = v_u_64 / 100
			v_u_59 = (v452 + v453 * ((v454 - math.floor(v455)) / 100 % 1)) * (v_u_39 / 2)
			local v456 = v451.Torque
			local v457 = v451.TqSlope
			local v458 = v_u_64
			local v459 = v_u_64 / 100
			v_u_37 = (v456 + v457 * ((v458 - math.floor(v459)) / 100 % 1)) * (v_u_39 / 2)
		end
		v_u_47 = v_u_36 + v_u_59
		v_u_48 = v_u_58 + v_u_37
	else
		v_u_52 = 0
		v_u_53 = 0
		v_u_36 = 0
		v_u_58 = 0
		v_u_59 = 0
		v_u_37 = 0
		v_u_47 = 0
		v_u_48 = 0
	end
	if v_u_4.Electric and v_u_25 ~= 0 then
		local v460 = v_u_310[v_u_25 + 2]
		local v461 = v_u_4.Redline
		local v462 = v_u_64
		local v463 = math.max(100, v462)
		local v464 = math.min(v461, v463) / 100
		local v465 = v460[math.floor(v464)]
		local v466 = v465.Horsepower
		local v467 = v465.HpSlope
		local v468 = v_u_64
		local v469 = v_u_64 / 100
		v_u_54 = v466 + v467 * ((v468 - math.floor(v469)) / 100 % 1)
		local v470 = v465.Torque
		local v471 = v465.TqSlope
		local v472 = v_u_64
		local v473 = v_u_64 / 100
		v_u_43 = v470 + v471 * ((v472 - math.floor(v473)) / 100 % 1)
	else
		v_u_54 = 0
		v_u_43 = 0
	end
	v_u_57 = v_u_52 + v_u_47 + v_u_54
	v_u_55 = v_u_53 + v_u_48 + v_u_43
	local v474 = v_u_3.DriveSeat.CFrame.lookVector.y * v_u_246
	if v_u_25 == -1 then
		v474 = -v474
	end
	local v475 = v_u_55
	local v476 = 1 + v474
	v_u_55 = v475 * math.max(1, v476)
	local v477 = 0
	local v478 = 0
	local v479 = 0
	local v480 = 0
	for _, v481 in pairs(v_u_3.Wheels:GetChildren()) do
		if v481.Name == "FL" or (v481.Name == "FR" or v481.Name == "F") then
			v477 = v477 + v481.RotVelocity.Magnitude
			v478 = v478 + 1
		elseif v481.Name == "RL" or (v481.Name == "RR" or v481.Name == "R") then
			v479 = v479 + v481.RotVelocity.Magnitude
			v480 = v480 + 1
		end
	end
	local v482 = v477 / v478
	local v483 = v479 / v480
	local v484 = (v482 + v483) / 2
	for _, v485 in pairs(v_u_3.Wheels:GetChildren()) do
		local _ = (CFrame.new(v485.Position - (v485.Arm.CFrame * v_u_248).lookVector, v485.Position) * v_u_249).lookVector
		local _ = v485.Name == "FL" or v485.Name == "RL"
		local v486 = 1
		local v487 = 1
		local v488 = 1
		local v489 = 1
		local v490 = 1
		if v_u_4.DifferentialType == "Old" then
			if v485.Name == "FL" or v485.Name == "FR" then
				local v491 = (v485.RotVelocity.Magnitude - v482) / v482
				local v492 = v_u_4.FDiffSlipThres
				local v493 = 1 + v491 / (math.max(v492, 1) / 100) * ((v_u_4.FDiffLockThres - 50) / 50)
				local v494 = math.min(1, v493)
				v489 = math.max(0, v494)
				if v_u_4.Config == "AWD" then
					local v495 = (v482 - v484) / v484
					local v496 = v_u_4.CDiffSlipThres
					local v497 = v489 * (1 + v495 / (math.max(v496, 1) / 100) * ((v_u_4.CDiffLockThres - 50) / 50))
					local v498 = math.min(1, v497)
					v489 = math.max(0, v498)
				end
			elseif v485.Name == "RL" or v485.Name == "RR" then
				local v499 = (v485.RotVelocity.Magnitude - v483) / v483
				local v500 = v_u_4.RDiffSlipThres
				local v501 = 1 + v499 / (math.max(v500, 1) / 100) * ((v_u_4.RDiffLockThres - 50) / 50)
				local v502 = math.min(1, v501)
				v489 = math.max(0, v502)
				if v_u_4.Config == "AWD" then
					local v503 = (v483 - v484) / v484
					local v504 = v_u_4.CDiffSlipThres
					local v505 = v489 * (1 + v503 / (math.max(v504, 1) / 100) * ((v_u_4.CDiffLockThres - 50) / 50))
					local v506 = math.min(1, v505)
					v489 = math.max(0, v506)
				end
			end
		elseif v485.Name == "FR" then
			local v507 = (v485.RotVelocity.Magnitude / v_u_3.Wheels.FL.RotVelocity.Magnitude - 1) * (v_u_4.FDiffPreload / 10)
			local v508 = 1 - (v_u_4.FDiffPower / 100 * v507 * v_u_38 + v_u_4.FDiffCoast / 100 * v507 * (1 - v_u_38))
			local v509 = math.min(2, v508)
			local v510 = math.max(0, v509) * 100
			v486 = math.ceil(v510) / 100
			v488 = 2 - v486
		elseif v485.Name == "FL" then
			local v511 = (v485.RotVelocity.Magnitude / v_u_3.Wheels.FR.RotVelocity.Magnitude - 1) * (v_u_4.FDiffPreload / 10)
			local v512 = 1 - (v_u_4.FDiffPower / 100 * v511 * v_u_38 + v_u_4.FDiffCoast / 100 * v511 * (1 - v_u_38))
			local v513 = math.min(2, v512)
			local v514 = math.max(0, v513) * 100
			v488 = math.ceil(v514) / 100
			v486 = 2 - v488
		elseif v485.Name == "RR" then
			local v515 = (v485.RotVelocity.Magnitude / v_u_3.Wheels.RL.RotVelocity.Magnitude - 1) * (v_u_4.RDiffPreload / 10)
			local v516 = 1 - (v_u_4.RDiffPower / 100 * v515 * v_u_38 + v_u_4.RDiffCoast / 100 * v515 * (1 - v_u_38))
			local v517 = math.min(2, v516)
			local v518 = math.max(0, v517) * 100
			v490 = math.ceil(v518) / 100
			v487 = 2 - v490
		elseif v485.Name == "RL" then
			local v519 = (v485.RotVelocity.Magnitude / v_u_3.Wheels.RR.RotVelocity.Magnitude - 1) * (v_u_4.RDiffPreload / 10)
			local v520 = 1 - (v_u_4.RDiffPower / 100 * v519 * v_u_38 + v_u_4.RDiffCoast / 100 * v519 * (1 - v_u_38))
			local v521 = math.min(2, v520)
			local v522 = math.max(0, v521) * 100
			v487 = math.ceil(v522) / 100
			v490 = 2 - v487
		end
		v_u_61 = false
		v_u_62 = false
		local v523 = script.Parent.IsOn.Value and 1 or 0
		local v524 = v_u_38
		local v525 = v_u_50
		local v526 = v_u_32 and 0 or 1
		local v527 = v_u_55
		local v528 = 1
		if v_u_19 and v525 > 0 then
			local v529 = v485.RotVelocity.Magnitude * (v485.Size.x / 2) - v485.Velocity.Magnitude
			v528 = math.abs(v529) - v_u_4.ABSThreshold > 0 and 0 or v528
		end
		v_u_62 = v528 < 1
		local v530 = v_u_34 == true and 1 or 0
		local v531 = false
		for _, v532 in pairs(v_u_89) do
			if v532 == v485 then
				v531 = true
			end
		end
		if v531 then
			if v_u_4.Config == "AWD" then
				local v533 = (v_u_4.TorqueVector + 1) / 2
				if string.find(v485.Name, "F") then
					v527 = v527 * (1 - v533)
				elseif string.find(v485.Name, "R") then
					v527 = v527 * v533
				end
			end
			v_u_380 = 1
			if v_u_18 and v524 > 0 then
				local v534 = v485.RotVelocity.Magnitude * (v485.Size.x / 2) - v485.Velocity.Magnitude
				local v535 = math.abs(v534) - v_u_4.TCSThreshold
				local v536 = math.max(0, v535) / v_u_4.TCSGradient
				v_u_380 = 1 - math.min(v536, 1) * (1 - v_u_4.TCSLimit / 100)
			end
			if v_u_380 < 1 then
				v_u_44 = v_u_380
				v_u_61 = true
			end
			local v537 = v_u_25 == -1 and -1 or 1
			if v_u_4.ClutchKick and (v_u_3.DriveSeat.Velocity.Magnitude < v_u_4.KickSpeedThreshold and (v_u_64 > v_u_4.Redline - v_u_4.KickRPMThreshold and v485["#BV"].MotorMaxTorque < 1)) then
				v527 = v527 * v_u_4.KickMult
			end
			local v538 = v527 * (60 / workspace:GetRealPhysicsFPS()) * (1 + (v485.RotVelocity.Magnitude / (120 - workspace:GetRealPhysicsFPS())) ^ (1.15 + 0.07 * (1 - 60 / workspace:GetRealPhysicsFPS()))) * v524 * v_u_380 * v523 * v526
			if v485.Name == "RR" then
				v485["#AV"].MotorMaxTorque = v538 * v490 * v489
			elseif v485.Name == "RL" then
				v485["#AV"].MotorMaxTorque = v538 * v487 * v489
			elseif v485.Name == "FR" then
				v485["#AV"].MotorMaxTorque = v538 * v486 * v489
			elseif v485.Name == "FL" then
				v485["#AV"].MotorMaxTorque = v538 * v488 * v489
			else
				v485["#AV"].MotorMaxTorque = v538 * v489
			end
			v485["#AV"].AngularVelocity = v_u_45 * v537
			if string.find(v485.Name, "F") then
				v485["#BV"].MotorMaxTorque = v_u_6 * (60 / workspace:GetRealPhysicsFPS()) * v525 * v528 + v_u_10 * ((1 - v524) * (v_u_64 / v_u_4.Redline)) + v_u_8 * v530
			else
				v485["#BV"].MotorMaxTorque = v_u_7 * (60 / workspace:GetRealPhysicsFPS()) * v525 * v528 + v_u_10 * ((1 - v524) * (v_u_64 / v_u_4.Redline)) + v_u_9 * v530
			end
		else
			v485["#AV"].MotorMaxTorque = 0
			v485["#AV"].AngularVelocity = 0
			if string.find(v485.Name, "F") then
				v485["#BV"].MotorMaxTorque = v_u_6 * (60 / workspace:GetRealPhysicsFPS()) * v525 * v528 + v_u_8 * v530
			else
				v485["#BV"].MotorMaxTorque = v_u_7 * (60 / workspace:GetRealPhysicsFPS()) * v525 * v528 + v_u_9 * v530
			end
		end
	end
end
function Flip()
	-- upvalues: (copy) v_u_3, (ref) v_u_42, (ref) v_u_20
	if (v_u_3.DriveSeat.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)).lookVector.y > 0.1 or v_u_42 then
		v_u_20 = tick()
	elseif tick() - v_u_20 >= 3 then
		v_u_42 = true
		local v539 = v_u_3.DriveSeat.Flip
		v539.maxTorque = Vector3.new(10000, 0, 10000)
		v539.P = 3000
		v539.D = 500
		wait(1)
		v539.maxTorque = Vector3.new(0, 0, 0)
		v539.P = 0
		v539.D = 0
		v_u_42 = false
	end
end
local v540 = require(v_u_3["A-Chassis Tune"].README)
print("Novena: AC6C Loaded - Version " .. v540 .. ", Update " .. script.Parent.Version.Value)
game["Run Service"].Heartbeat:connect(function(p541)
	-- upvalues: (ref) v_u_15, (ref) v_u_35, (ref) v_u_25, (ref) v_u_64, (ref) v_u_56, (ref) v_u_251, (ref) v_u_39, (ref) v_u_253, (ref) v_u_52, (ref) v_u_54, (ref) v_u_36, (ref) v_u_59, (ref) v_u_47, (ref) v_u_57, (ref) v_u_53, (copy) v_u_4, (copy) v_u_244, (copy) v_u_5, (ref) v_u_43, (ref) v_u_58, (ref) v_u_37, (ref) v_u_17, (ref) v_u_38, (ref) v_u_50, (ref) v_u_60, (ref) v_u_41, (ref) v_u_27, (ref) v_u_34, (ref) v_u_18, (ref) v_u_61, (ref) v_u_44, (ref) v_u_19, (ref) v_u_62, (ref) v_u_24, (copy) v_u_3
	v_u_15 = script.Parent.IsOn.Value
	v_u_35 = script.Parent.ControlsOpen.Value
	Inputs(p541)
	Steering(p541)
	Gear()
	Engine(p541)
	script.Parent.Values.Gear.Value = v_u_25
	script.Parent.Values.RPM.Value = v_u_64
	script.Parent.Values.Boost.Value = v_u_56 / 2 * v_u_251 + v_u_39 / 2 * v_u_253
	script.Parent.Values.BoostTurbo.Value = v_u_56 / 2 * v_u_251
	script.Parent.Values.BoostSuper.Value = v_u_39 / 2 * v_u_253
	script.Parent.Values.HpNatural.Value = v_u_52
	script.Parent.Values.HpElectric.Value = v_u_54
	script.Parent.Values.HpTurbo.Value = v_u_36
	script.Parent.Values.HpSuper.Value = v_u_59
	script.Parent.Values.HpBoosted.Value = v_u_47
	script.Parent.Values.Horsepower.Value = v_u_57
	script.Parent.Values.TqNatural.Value = v_u_53 / v_u_4.Ratios[v_u_25 + 2] / v_u_244 / v_u_5
	script.Parent.Values.TqElectric.Value = v_u_43 / v_u_4.Ratios[v_u_25 + 2] / v_u_244 / v_u_5
	script.Parent.Values.TqTurbo.Value = v_u_58 / v_u_4.Ratios[v_u_25 + 2] / v_u_244 / v_u_5
	script.Parent.Values.TqSuper.Value = v_u_37 / v_u_4.Ratios[v_u_25 + 2] / v_u_244 / v_u_5
	script.Parent.Values.TqBoosted.Value = script.Parent.Values.TqTurbo.Value + script.Parent.Values.TqSuper.Value
	script.Parent.Values.Torque.Value = script.Parent.Values.TqNatural.Value + script.Parent.Values.TqElectric.Value + script.Parent.Values.TqBoosted.Value
	script.Parent.Values.TransmissionMode.Value = v_u_17
	script.Parent.Values.Throttle.Value = v_u_38
	script.Parent.Values.Brake.Value = v_u_50
	if script.Parent.Values.AutoClutch.Value then
		script.Parent.Values.Clutch.Value = v_u_60
	end
	script.Parent.Values.SteerC.Value = v_u_41
	script.Parent.Values.SteerT.Value = v_u_27
	script.Parent.Values.PBrake.Value = v_u_34
	script.Parent.Values.TCS.Value = v_u_18
	script.Parent.Values.TCSActive.Value = v_u_61
	script.Parent.Values.TCSAmt.Value = 1 - v_u_44
	script.Parent.Values.ABS.Value = v_u_19
	script.Parent.Values.ABSActive.Value = v_u_62
	script.Parent.Values.MouseSteerOn.Value = v_u_24
	script.Parent.Values.Velocity.Value = v_u_3.DriveSeat.Velocity
end)
while wait(0.0667) do
	if v_u_17 == "Auto" then
		Auto()
	end
	if v_u_4.AutoFlip then
		Flip()
	end
end