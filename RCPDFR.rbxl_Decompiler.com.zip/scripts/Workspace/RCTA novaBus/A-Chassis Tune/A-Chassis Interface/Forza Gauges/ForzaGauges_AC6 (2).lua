-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

SpeedType = "MPH"
local v1 = {
	{
		["units"] = "MPH",
		["scaling"] = 0.5681818181818181,
		["maxSpeed"] = 230,
		["spInc"] = 20
	},
	{
		["units"] = "KM/H",
		["scaling"] = 0.9144000000000001,
		["maxSpeed"] = 370,
		["spInc"] = 40
	},
	{
		["units"] = "SPS",
		["scaling"] = 1,
		["maxSpeed"] = 400,
		["spInc"] = 40
	}
}
game.Players.LocalPlayer:GetMouse()
local v2 = script.Parent.Parent.Car.Value
local v_u_3 = require(v2["A-Chassis Tune"])
local v_u_4 = script.Parent
local v_u_5 = script.Parent.Parent.Values
local v_u_6 = script.Parent.Parent.IsOn
v_u_4:WaitForChild("Tach")
v_u_4:WaitForChild("ln")
v_u_4:WaitForChild("bln")
v_u_4:WaitForChild("Gear")
v2.DriveSeat.HeadsUpDisplay = false
local v7 = v_u_3.PeakRPM
local v8 = v_u_3.Redline
local v9 = v8 / 1000
local v_u_10 = math.ceil(v9)
local v_u_11 = v_u_3.Aspiration ~= "Single" and 0 or v_u_3.Boost
if v_u_3.Aspiration == "Double" then
	v_u_11 = v_u_3.Boost * 2
end
if v_u_3.Aspiration == "Super" then
	v_u_11 = v_u_3.Boost
end
local v12 = {}
if v_u_3.Config == "FWD" or v_u_3.Config == "AWD" then
	if v2.Wheels:FindFirstChild("FL") ~= nil then
		local v13 = v2.Wheels.FL
		table.insert(v12, v13)
	end
	if v2.Wheels:FindFirstChild("FR") ~= nil then
		local v14 = v2.Wheels.FR
		table.insert(v12, v14)
	end
	if v2.Wheels:FindFirstChild("F") ~= nil then
		local v15 = v2.Wheels.F
		table.insert(v12, v15)
	end
end
if v_u_3.Config == "RWD" or v_u_3.Config == "AWD" then
	if v2.Wheels:FindFirstChild("RL") ~= nil then
		local v16 = v2.Wheels.RL
		table.insert(v12, v16)
	end
	if v2.Wheels:FindFirstChild("RR") ~= nil then
		local v17 = v2.Wheels.RR
		table.insert(v12, v17)
	end
	if v2.Wheels:FindFirstChild("R") ~= nil then
		local v18 = v2.Wheels.R
		table.insert(v12, v18)
	end
end
local v19 = 0
for _, v20 in pairs(v12) do
	if v19 < v20.Size.x then
		v19 = v20.Size.x
	end
end
for _, v21 in pairs(v1) do
	local v22 = v21.scaling * v19 * 3.141592653589793 * v8 / 60 / v_u_3.Ratios[#v_u_3.Ratios] / v_u_3.FinalDrive / v_u_3.FDMult
	v21.maxSpeed = math.ceil(v22)
	local v23 = v21.maxSpeed / 150
	local v24 = math.ceil(v23) * 10
	v21.spInc = math.max(v24, 10)
end
for v25 = 0, v_u_10 * 2 do
	local v26 = v_u_4.ln:clone()
	v26.Parent = v_u_4.Tach
	v26.Rotation = v25 * 270 / (v_u_10 * 2) + 45
	v26.Num.Text = v25 / 2
	v26.Num.Rotation = -v26.Rotation
	v26.Frame.Position = UDim2.new(0, -1, 0, 85)
	local v27 = v25 * 500
	local v28 = v7 / 500
	if math.floor(v28) * 500 <= v27 then
		v26.Frame.BackgroundColor3 = Color3.new(1, 0, 0.2980392156862745)
		if v25 < v_u_10 * 2 then
			ln2 = v26:clone()
			ln2.Parent = v_u_4.Tach
			ln2.Rotation = (v25 + 0.5) * 270 / (v_u_10 * 2) + 45
			ln2.Num:Destroy()
			ln2.Visible = true
		end
	end
	if v25 % 2 == 0 then
		v26.Frame.Size = UDim2.new(0, 3, 0, 10)
		v26.Frame.Position = UDim2.new(0, -1, 0, 80)
		v26.Num.Visible = true
	else
		v26.Num:Destroy()
	end
	v26.Visible = true
end
local v29 = Instance.new("Frame", v_u_4.Boost)
v29.Name = "blns"
v29.BackgroundTransparency = 1
v29.BorderSizePixel = 0
v29.Size = UDim2.new(0, 0, 0, 0)
for v30 = 0, 6 do
	local v31 = v_u_4.bln:clone()
	v31.Parent = v29
	v31.Rotation = 25 - v30 / 6 * 50
	if v30 % 2 == 0 then
		v31.Frame.Size = UDim2.new(0, 2, 0, 7)
		v31.Frame.Position = UDim2.new(0, -1, 0, 62)
	else
		v31.Frame.Size = UDim2.new(0, 3, 0, 5)
		v31.Frame.Position = UDim2.new(0, -1, 0, 62)
	end
	v31.Num:Destroy()
	v31.Visible = true
end
if v_u_6.Value then
	v_u_4:TweenPosition(UDim2.new(0, 0, 0, 0), Enum.EasingDirection.InOut, Enum.EasingStyle.Quad, 1, true)
end
v_u_6.Changed:connect(function()
	-- upvalues: (copy) v_u_6, (copy) v_u_4
	if v_u_6.Value then
		v_u_4:TweenPosition(UDim2.new(0, 0, 0, 0), Enum.EasingDirection.InOut, Enum.EasingStyle.Quad, 1, true)
	end
end)
game["Run Service"].RenderStepped:connect(function()
	-- upvalues: (copy) v_u_4, (copy) v_u_5, (copy) v_u_10, (copy) v_u_3, (ref) v_u_11
	local v32 = v_u_4.Tach.Needle
	local v33 = v_u_4.Tach.Needle.Rotation * 0.89
	local v34 = v_u_5.RPM.Value / (v_u_10 * 1000)
	v32.Rotation = v33 + (math.min(1, v34) * 270 + 45) * 0.10999999999999999
	local v35 = v_u_4.Tach.Needle2
	local v36 = v_u_4.Tach.Needle2.Rotation * 0.893
	local v37 = v_u_5.RPM.Value / (v_u_10 * 1000)
	v35.Rotation = v36 + (math.min(1, v37) * 270 + 45) * 0.10699999999999998
	local v38 = v_u_4.Tach.Needle3
	local v39 = v_u_4.Tach.Needle3.Rotation * 0.896
	local v40 = v_u_5.RPM.Value / (v_u_10 * 1000)
	v38.Rotation = v39 + (math.min(1, v40) * 270 + 45) * 0.10399999999999998
	local v41 = v_u_4.Tach.Needle4
	local v42 = v_u_4.Tach.Needle4.Rotation * 0.899
	local v43 = v_u_5.RPM.Value / (v_u_10 * 1000)
	v41.Rotation = v42 + (math.min(1, v43) * 270 + 45) * 0.10099999999999998
	local v44 = v_u_4.Tach.Needle5
	local v45 = v_u_4.Tach.Needle5.Rotation * 0.902
	local v46 = v_u_5.RPM.Value / (v_u_10 * 1000)
	v44.Rotation = v45 + (math.min(1, v46) * 270 + 45) * 0.09799999999999998
	local v47 = v_u_4.Tach.Needle6
	local v48 = v_u_4.Tach.Needle6.Rotation * 0.905
	local v49 = v_u_5.RPM.Value / (v_u_10 * 1000)
	v47.Rotation = v48 + (math.min(1, v49) * 270 + 45) * 0.09499999999999997
	local v50 = v_u_4.Tach.Needle7
	local v51 = v_u_4.Tach.Needle7.Rotation * 0.908
	local v52 = v_u_5.RPM.Value / (v_u_10 * 1000)
	v50.Rotation = v51 + (math.min(1, v52) * 270 + 45) * 0.09199999999999997
	local v53 = v_u_4.Tach.Needle8
	local v54 = v_u_4.Tach.Needle8.Rotation * 0.911
	local v55 = v_u_5.RPM.Value / (v_u_10 * 1000)
	v53.Rotation = v54 + (math.min(1, v55) * 270 + 45) * 0.08899999999999997
	local v56 = v_u_4.Tach.Needle9
	local v57 = v_u_4.Tach.Needle9.Rotation * 0.914
	local v58 = v_u_5.RPM.Value / (v_u_10 * 1000)
	v56.Rotation = v57 + (math.min(1, v58) * 270 + 45) * 0.08599999999999997
	local v59 = v_u_4.Tach.Needle10
	local v60 = v_u_4.Tach.Needle10.Rotation * 0.917
	local v61 = v_u_5.RPM.Value / (v_u_10 * 1000)
	v59.Rotation = v60 + (math.min(1, v61) * 270 + 45) * 0.08299999999999996
	if v_u_3.Aspiration then
		v_u_4.Boost.Needle.Rotation = v_u_4.Boost.Needle.Rotation * 0.87 + (25 - 50 * (v_u_5.Boost.Value / v_u_11)) * 0.13
		v_u_4.Boost.Needle2.Rotation = v_u_4.Boost.Needle2.Rotation * 0.875 + (25 - 50 * (v_u_5.Boost.Value / v_u_11)) * 0.125
		v_u_4.Boost.Needle3.Rotation = v_u_4.Boost.Needle3.Rotation * 0.88 + (25 - 50 * (v_u_5.Boost.Value / v_u_11)) * 0.12
		v_u_4.Boost.Needle4.Rotation = v_u_4.Boost.Needle4.Rotation * 0.885 + (25 - 50 * (v_u_5.Boost.Value / v_u_11)) * 0.11499999999999999
		v_u_4.Boost.Needle5.Rotation = v_u_4.Boost.Needle5.Rotation * 0.89 + (25 - 50 * (v_u_5.Boost.Value / v_u_11)) * 0.10999999999999999
		v_u_4.Boost.Needle6.Rotation = v_u_4.Boost.Needle6.Rotation * 0.895 + (25 - 50 * (v_u_5.Boost.Value / v_u_11)) * 0.10499999999999998
		v_u_4.Boost.Needle7.Rotation = v_u_4.Boost.Needle7.Rotation * 0.9 + (25 - 50 * (v_u_5.Boost.Value / v_u_11)) * 0.09999999999999998
		v_u_4.Boost.Needle8.Rotation = v_u_4.Boost.Needle8.Rotation * 0.905 + (25 - 50 * (v_u_5.Boost.Value / v_u_11)) * 0.09499999999999997
		v_u_4.Boost.Needle9.Rotation = v_u_4.Boost.Needle9.Rotation * 0.91 + (25 - 50 * (v_u_5.Boost.Value / v_u_11)) * 0.08999999999999997
		v_u_4.Boost.Needle10.Rotation = v_u_4.Boost.Needle10.Rotation * 0.915 + (25 - 50 * (v_u_5.Boost.Value / v_u_11)) * 0.08499999999999996
	end
end)
if v_u_3.Aspiration then
	if v_u_3.Aspiration == "Natural" then
		v_u_4.Boost.Visible = false
		v_u_4.BoostImage.Visible = false
	elseif v_u_3.Aspiration ~= "Single" and v_u_3.Aspiration ~= "Super" then
		local _ = v_u_3.Aspiration == "Double"
	end
else
	v_u_4.Boost.Visible = false
	v_u_4.BoostImage.Visible = false
end
v_u_5.Gear.Changed:connect(function()
	-- upvalues: (copy) v_u_5, (copy) v_u_4
	local v62 = v_u_5.Gear.Value
	local v63 = v62 == 0 and "N" or (v62 == -1 and "R" or v62)
	v_u_4.Gear.Text = v63
end)
v_u_5.TCS.Changed:connect(function()
	-- upvalues: (copy) v_u_3, (copy) v_u_5, (copy) v_u_4
	if v_u_3.TCSEnabled then
		if v_u_5.TCS.Value then
			v_u_4.TCS.TextColor3 = Color3.new(1, 0.8862745098039215, 0)
			v_u_4.TCS.TextStrokeColor3 = Color3.new(1, 0.8862745098039215, 0)
			if v_u_5.TCSActive.Value then
				wait()
				v_u_4.TCS.TextColor3 = Color3.new(1, 0.8862745098039215, 0)
				v_u_4.TCS.TextStrokeColor3 = Color3.new(1, 0.8862745098039215, 0)
			else
				wait()
				v_u_4.TCS.TextColor3 = Color3.new(0.2, 0.2, 0.2)
				v_u_4.TCS.TextStrokeColor3 = Color3.new(0.2, 0.2, 0.2)
			end
		else
			v_u_4.TCS.TextColor3 = Color3.new(0.2, 0.2, 0.2)
			v_u_4.TCS.TextStrokeColor3 = Color3.new(0.2, 0.2, 0.2)
			return
		end
	else
		v_u_4.TCS.TextColor3 = Color3.new(0.2, 0.2, 0.2)
		v_u_4.TCS.TextStrokeColor3 = Color3.new(0.2, 0.2, 0.2)
		return
	end
end)
v_u_5.TCSActive.Changed:connect(function()
	-- upvalues: (copy) v_u_3, (copy) v_u_5, (copy) v_u_4
	if v_u_3.TCSEnabled then
		if v_u_5.TCSActive.Value and v_u_5.TCS.Value then
			wait()
			v_u_4.TCS.TextColor3 = Color3.new(1, 0.8862745098039215, 0)
			v_u_4.TCS.TextStrokeColor3 = Color3.new(1, 0.8862745098039215, 0)
			return
		elseif v_u_5.TCS.Value then
			wait()
			v_u_4.TCS.TextColor3 = Color3.new(0.2, 0.2, 0.2)
			v_u_4.TCS.TextStrokeColor3 = Color3.new(0.2, 0.2, 0.2)
		else
			wait()
			v_u_4.TCS.TextColor3 = Color3.new(1, 0.8862745098039215, 0)
			v_u_4.TCS.TextStrokeColor3 = Color3.new(1, 0.8862745098039215, 0)
		end
	else
		v_u_4.TCS.TextColor3 = Color3.new(0.2, 0.2, 0.2)
		v_u_4.TCS.TextStrokeColor3 = Color3.new(0.2, 0.2, 0.2)
		return
	end
end)
v_u_4.TCS.Changed:connect(function()
	-- upvalues: (copy) v_u_3, (copy) v_u_5, (copy) v_u_4
	if v_u_3.TCSEnabled then
		if v_u_5.TCSActive.Value and v_u_5.TCS.Value then
			wait()
			v_u_4.TCS.TextColor3 = Color3.new(1, 0.8862745098039215, 0)
			v_u_4.TCS.TextStrokeColor3 = Color3.new(1, 0.8862745098039215, 0)
			return
		end
		if not v_u_5.TCS.Value then
			wait()
			v_u_4.TCS.TextColor3 = Color3.new(1, 0.8862745098039215, 0)
			v_u_4.TCS.TextStrokeColor3 = Color3.new(1, 0.8862745098039215, 0)
			return
		end
	elseif v_u_4.TCS.Visible then
		v_u_4.TCS.TextColor3 = Color3.new(0.2, 0.2, 0.2)
		v_u_4.TCS.TextStrokeColor3 = Color3.new(0.2, 0.2, 0.2)
	end
end)
v_u_5.ABS.Changed:connect(function()
	-- upvalues: (copy) v_u_3, (copy) v_u_5, (copy) v_u_4
	if v_u_3.ABSEnabled then
		if v_u_5.ABS.Value then
			v_u_4.ABS.TextColor3 = Color3.new(1, 0.8862745098039215, 0)
			v_u_4.ABS.TextStrokeColor3 = Color3.new(1, 0.8862745098039215, 0)
			if v_u_5.ABSActive.Value then
				wait()
				v_u_4.ABS.TextColor3 = Color3.new(1, 0.8862745098039215, 0)
				v_u_4.ABS.TextStrokeColor3 = Color3.new(1, 0.8862745098039215, 0)
			else
				wait()
				v_u_4.ABS.TextColor3 = Color3.new(0.2, 0.2, 0.2)
				v_u_4.ABS.TextStrokeColor3 = Color3.new(0.2, 0.2, 0.2)
			end
		else
			v_u_4.ABS.Visible = true
			v_u_4.ABS.TextColor3 = Color3.new(0.2, 0.2, 0.2)
			v_u_4.ABS.TextStrokeColor3 = Color3.new(0.2, 0.2, 0.2)
			return
		end
	else
		v_u_4.ABS.TextColor3 = Color3.new(0.2, 0.2, 0.2)
		v_u_4.ABS.TextStrokeColor3 = Color3.new(0.2, 0.2, 0.2)
		return
	end
end)
v_u_5.ABSActive.Changed:connect(function()
	-- upvalues: (copy) v_u_3, (copy) v_u_5, (copy) v_u_4
	if v_u_3.ABSEnabled then
		if v_u_5.ABSActive.Value and v_u_5.ABS.Value then
			wait()
			v_u_4.ABS.TextColor3 = Color3.new(1, 0.8862745098039215, 0)
			v_u_4.ABS.TextStrokeColor3 = Color3.new(1, 0.8862745098039215, 0)
			return
		elseif v_u_5.ABS.Value then
			wait()
			v_u_4.ABS.TextColor3 = Color3.new(0.2, 0.2, 0.2)
			v_u_4.ABS.TextStrokeColor3 = Color3.new(0.2, 0.2, 0.2)
		else
			wait()
			v_u_4.ABS.TextColor3 = Color3.new(1, 0.8862745098039215, 0)
			v_u_4.ABS.TextStrokeColor3 = Color3.new(1, 0.8862745098039215, 0)
		end
	else
		v_u_4.ABS.TextColor3 = Color3.new(0.2, 0.2, 0.2)
		v_u_4.ABS.TextStrokeColor3 = Color3.new(0.2, 0.2, 0.2)
		return
	end
end)
v_u_4.ABS.Changed:connect(function()
	-- upvalues: (copy) v_u_3, (copy) v_u_5, (copy) v_u_4
	if v_u_3.ABSEnabled then
		if v_u_5.ABSActive.Value and v_u_5.ABS.Value then
			wait()
			v_u_4.ABS.TextColor3 = Color3.new(1, 0.8862745098039215, 0)
			v_u_4.ABS.TextStrokeColor3 = Color3.new(1, 0.8862745098039215, 0)
			return
		end
		if not v_u_5.ABS.Value then
			wait()
			v_u_4.ABS.TextColor3 = Color3.new(1, 0.8862745098039215, 0)
			v_u_4.ABS.TextStrokeColor3 = Color3.new(1, 0.8862745098039215, 0)
			return
		end
	elseif v_u_4.ABS.Visible then
		v_u_4.ABS.TextColor3 = Color3.new(0.2, 0.2, 0.2)
		v_u_4.ABS.TextStrokeColor3 = Color3.new(0.2, 0.2, 0.2)
	end
end)
function Speed()
	-- upvalues: (copy) v_u_4, (copy) v_u_5
	v_u_4.SpeedThing.Text = SpeedType
	local v64 = v_u_5.Velocity.Value.Magnitude
	if SpeedType == "MPH" then
		if v64 * 0.5681818181818181 < 100 then
			if v64 * 0.5681818181818181 < 10 then
				local v65 = v_u_4.Speed
				local v66 = v64 * 0.5681818181818181
				v65.Text = "00" .. math.floor(v66)
			else
				local v67 = v_u_4.Speed
				local v68 = v64 * 0.5681818181818181
				v67.Text = "0" .. math.floor(v68)
			end
		else
			local v69 = v_u_4.Speed
			local v70 = v64 * 0.5681818181818181
			v69.Text = math.floor(v70)
		end
	end
	if SpeedType == "KPH" then
		if v64 * 0.9144000000000001 < 100 then
			if v64 * 0.9144000000000001 < 10 then
				local v71 = v_u_4.Speed
				local v72 = v64 * 0.9144000000000001
				v71.Text = "00" .. math.floor(v72)
			else
				local v73 = v_u_4.Speed
				local v74 = v64 * 0.9144000000000001
				v73.Text = "0" .. math.floor(v74)
			end
		end
		local v75 = v_u_4.Speed
		local v76 = v64 * 0.9144000000000001
		v75.Text = math.floor(v76)
	end
end
v_u_5.Velocity.Changed:connect(function()
	Speed()
end)
wait(0.1)
Speed()