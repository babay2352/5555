-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game.Players.LocalPlayer:GetMouse()
car = script.Parent.Car.Value
local v_u_2 = car.Horn
if workspace.FilteringEnabled then
	v1.KeyDown:connect(function(p3)
		-- upvalues: (copy) v_u_2
		if string.lower(p3) == "h" then
			v_u_2:FireServer("Horn", true)
		end
	end)
	v1.KeyUp:connect(function(p4)
		-- upvalues: (copy) v_u_2
		if string.lower(p4) == "h" then
			v_u_2:FireServer("Horn", false)
		end
	end)
else
	v1.KeyDown:connect(function(p5)
		if string.lower(p5) == "h" then
			car.DriveSeat.Horn:Play()
		end
	end)
	v1.KeyUp:connect(function(p6)
		if string.lower(p6) == "h" then
			car.DriveSeat.Horn:Stop()
		end
	end)
end