-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v_u_1 = { -25, 0, 5 }
local v_u_2 = { -25, 0, 5 }
local v_u_3 = script.Parent.Car.Value
local v4 = script.Parent.Values
local v_u_5 = require(v_u_3["A-Chassis Tune"])
local v_u_6 = v_u_3:WaitForChild("Sounds")
local v_u_7 = {}
local v8 = v4.RPM
local v_u_9 = v4.Throttle
local v_u_10 = v_u_5.Redline
local v_u_11 = v_u_5.RevBounce + 100
local function v19(p12)
	-- upvalues: (copy) v_u_9, (copy) v_u_10, (copy) v_u_7, (copy) v_u_5, (copy) v_u_11, (copy) v_u_1, (copy) v_u_2, (copy) v_u_6, (copy) v_u_3
	local v13 = v_u_9.Value
	local v14 = p12 / v_u_10
	v_u_7[1] = p12 ^ 1 / v_u_10 * (v13 * 0.5 + 0.5) * 0.7
	local v15 = v_u_7
	local v16 = 0 + 1.655 * v14 * (v13 * 0.1 + 0.9)
	v15[2] = math.max(v16, 0)
	v_u_7[3] = p12 ^ 1 / v_u_10 * (v13 * 0.5 + 0.5) * 0.5
	local v17 = v_u_7
	local v18 = 0 + 1.815 * v14 * (v13 * 0.1 + 0.9)
	v17[4] = math.max(v18, 0)
	v_u_7[5] = 1.4 + p12 / (-v_u_5.IdleRPM - 0)
	v_u_7[6] = (p12 + v_u_11 - v_u_10) / v_u_10 * v13 * 1 * 100
	v_u_7[7] = v13 * (0 + 0.4 * v14)
	v_u_7[8] = v13 * (0 + 0 * v14)
	v_u_7[9] = { v_u_1[1] * (1 - v13), v_u_1[2] * (1 - v13), v_u_1[3] * (1 - v13) }
	v_u_7[10] = { v_u_2[1] * (1 - v13), v_u_2[2] * (1 - v13), v_u_2[3] * (1 - v13) }
	v_u_6:FireServer(v_u_3, "update", nil, v_u_7)
end
createinfo = {
	123639887894256,
	1000,
	10,
	107432588154873,
	500,
	15,
	138426523255134,
	500,
	5,
	0,
	1000,
	5,
	{ 0, 4, 6 },
	{ 0, 4, 6 }
}
v_u_6:FireServer(v_u_3, "create", createinfo)
if v4.Parent.IsOn.Value == true then
	v_u_6:FireServer(v_u_3, "play")
else
	v_u_6:FireServer(v_u_3, "stop")
end
v4.Parent.IsOn.Changed:Connect(function(p20)
	-- upvalues: (copy) v_u_6, (copy) v_u_3
	if p20 == false then
		v_u_6:FireServer(v_u_3, "stop")
	else
		v_u_6:FireServer(v_u_3, "play")
	end
end)
v8.Changed:Connect(v19)