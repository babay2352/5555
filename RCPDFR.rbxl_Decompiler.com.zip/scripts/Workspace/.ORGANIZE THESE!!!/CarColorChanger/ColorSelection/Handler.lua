-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

local v1 = game:GetService("Players")
local v2 = game:GetService("TweenService")
local v3 = v1.LocalPlayer
local v4 = v3.Character or v3.CharacterAdded:Wait()
local v_u_5 = workspace.CurrentCamera
local v_u_6 = script.Parent
local v7 = v_u_6:WaitForChild("Frame")
local v8 = v7.Frame:WaitForChild("ScrollingFrame")
local v9 = v7:WaitForChild("Confirm")
local v10 = v7:WaitForChild("Close")
local v_u_11 = v_u_6.OriginalColor.Value
local v_u_12 = v_u_6.OriginalParent.Value
local v_u_13 = nil
task.wait(0.1)
local v14 = v_u_12:FindFirstChild("CameraPosition")
if v14 then
	v_u_5.CameraType = Enum.CameraType.Scriptable
	v2:Create(v_u_5, TweenInfo.new(1, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
		["CFrame"] = v14.CFrame
	}):Play()
end
for _, v_u_15 in ipairs(v8:GetChildren()) do
	if v_u_15:IsA("ImageButton") then
		v_u_15.MouseButton1Click:Connect(function()
			-- upvalues: (ref) v_u_13, (copy) v_u_15, (copy) v_u_12
			v_u_13 = v_u_15.BackgroundColor3
			v_u_12:FindFirstChild("ColorEvent"):FireServer(v_u_13, false)
		end)
	end
end
v9.MouseButton1Click:Connect(function()
	-- upvalues: (copy) v_u_12, (ref) v_u_13, (copy) v_u_11, (copy) v_u_5, (copy) v_u_6
	v_u_12:FindFirstChild("ColorEvent"):FireServer(v_u_13 or v_u_11, true)
	v_u_5.CameraType = Enum.CameraType.Custom
	v_u_6:Destroy()
end)
v10.MouseButton1Click:Connect(function()
	-- upvalues: (copy) v_u_12, (copy) v_u_11, (copy) v_u_5, (copy) v_u_6
	v_u_12:FindFirstChild("ColorEvent"):FireServer(v_u_11, true)
	v_u_5.CameraType = Enum.CameraType.Custom
	v_u_6:Destroy()
end)
local v16 = v4:FindFirstChildOfClass("Humanoid")
if v16 then
	v16.Died:Connect(function()
		-- upvalues: (copy) v_u_12, (copy) v_u_11, (copy) v_u_5, (copy) v_u_6
		v_u_12:FindFirstChild("ColorEvent"):FireServer(v_u_11, true)
		v_u_5.CameraType = Enum.CameraType.Custom
		v_u_6:Destroy()
	end)
end
v_u_12:FindFirstChild("ColorEvent").OnClientEvent:Connect(function(p17)
	-- upvalues: (copy) v_u_5, (copy) v_u_6
	if p17 == "end" then
		v_u_5.CameraType = Enum.CameraType.Custom
		v_u_6:Destroy()
	end
end)
v_u_6.AncestryChanged:Connect(function(_, p18)
	-- upvalues: (copy) v_u_5
	if not p18 then
		v_u_5.CameraType = Enum.CameraType.Custom
	end
end)