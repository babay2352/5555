-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local t = {}
local t2 = {
	Low = {
		Resolution = 128,
		Compression = 80,
		Format = "PNG",
		Mipmaps = false
	},
	Medium = {
		Resolution = 512,
		Compression = 60,
		Format = "PNG",
		Mipmaps = true
	},
	High = {
		Resolution = 1024,
		Compression = 40,
		Format = "PNG",
		Mipmaps = true
	},
	Ultra = {
		Resolution = 2048,
		Compression = 20,
		Format = "PNG",
		Mipmaps = true
	}
}
local t3 = {
	Decal = {
		Class = "Decal",
		DefaultProperties = {
			Face = "Top",
			Texture = "",
			Transparency = 0
		}
	},
	Texture = {
		Class = "Texture",
		DefaultProperties = {
			OffsetStudsU = 0,
			OffsetStudsV = 0,
			StudsPerTileU = 2,
			StudsPerTileV = 2
		}
	},
	SurfaceAppearance = {
		Class = "SurfaceAppearance",
		DefaultProperties = {
			AlphaMode = "Overlay",
			ColorMap = "",
			MetalnessMap = "",
			NormalMap = "",
			RoughnessMap = ""
		}
	}
}
local t4 = {}

setmetatable(t4, {
	__mode = "k"
})

local function ApplyProperties(p1, p2) --[[ ApplyProperties | Line: 72 ]]
	assert(if type(p2) == "table" then true else false, "Properties must be a table")

	for k, v in pairs(p2) do
		if type(k) == "number" then
			if typeof(v) == "Instance" then
				v.Parent = p1
			end

			continue
		end

		if pcall(function() --[[ Line: 84 | Upvalues: p1 (copy), k (copy) ]]
			return p1[k]
		end) then
			p1[k] = v
		end
	end

	return p1
end

local function CreateTextureAsset(p1, p2) --[[ CreateTextureAsset | Line: 93 | Upvalues: t3 (copy), ApplyProperties (copy) ]]
	local v1 = t3[p1]

	if not v1 then
		error("Unsupported texture type: " .. tostring(p1), 2)
	end

	return ApplyProperties(Instance.new(v1.Class), if p2 then p2 else v1.DefaultProperties)
end

function t.AnalyzeTextureUsage(p1) --[[ AnalyzeTextureUsage | Line: 105 | Upvalues: t3 (copy) ]]
	local t = {
		totalTextures = 0,
		memoryUsage = 0,
		missingTextures = 0,
		byType = {}
	}

	local function v1(p1) --[[ scanHierarchy | Line: 114 | Upvalues: t3 (ref), t (copy), v1 (copy) ]]
		if t3[p1.ClassName] then
			t.totalTextures = t.totalTextures + 1
			t.byType[p1.ClassName] = (t.byType[p1.ClassName] or 0) + 1

			if p1:IsA("Decal") and p1.Texture == "" then
				t.missingTextures = t.missingTextures + 1
			end
		end

		for i, v in ipairs(p1:GetChildren()) do
			v1(v)
		end
	end

	v1(p1)

	return t
end
function t.GenerateMissingTextures(p1, p2) --[[ GenerateMissingTextures | Line: 134 | Upvalues: t3 (copy), ApplyProperties (copy) ]]
	local count = 0

	for k, v in pairs(p2) do
		local v1 = p1:FindFirstChild(k)

		if v1 then
			if v1.ClassName ~= v.Type then
				warn("[TextureConfiguration] - Texture type mismatch for \'" .. k .. "\'. Expected: " .. v.Type .. ", Found: " .. v1.ClassName)
			end

			continue
		end

		local Type = v.Type
		local Properties = v.Properties
		local v2 = t3[Type]

		if not v2 then
			error("Unsupported texture type: " .. tostring(Type), 2)
		end

		local v6 = ApplyProperties(Instance.new(v2.Class), if Properties then Properties else v2.DefaultProperties)

		v6.Name = k
		v6.Parent = p1
		count = count + 1
	end

	print("[TextureConfiguration] - Generated " .. count .. " missing textures")

	return count
end
function t.CreateTextureLayer(p1, p2) --[[ CreateTextureLayer | Line: 155 ]]
	local v1 = p2:FindFirstChild(p1)

	if not v1 then
		local v2 = Instance.new("Folder")

		v2.Name = p1
		v2.Archivable = false
		v2.Parent = p2
		v1 = v2
	end

	return v1
end
function t.GetTextureManager(p1) --[[ GetTextureManager | Line: 170 | Upvalues: t4 (copy), t3 (copy), ApplyProperties (copy) ]]
	if t4[p1] then
		return t4[p1]
	end

	local t = {}

	local function FindTexture(p12) --[[ FindTexture | Line: 178 | Upvalues: p1 (copy) ]]
		return p1:FindFirstChild(p12)
	end

	local t2 = {
		__index = function(p12, p2) --[[ __index | Line: 183 | Upvalues: p1 (copy), t3 (ref), ApplyProperties (ref), FindTexture (copy) ]]
			local v1 = p2:lower()

			if v1 == "addtexture" or v1 == "create" then
				return function(p12, p2) --[[ Line: 187 | Upvalues: p1 (ref), t3 (ref), ApplyProperties (ref) ]]
					local v1 = if p2 then p2.Name else p2

					if not v1 or type(v1) ~= "string" then
						error("[TextureConfiguration] - Texture configuration must include a valid Name property", 2)
					end

					local v2 = p1:FindFirstChild(v1)

					if v2 and v2.ClassName ~= p12 then
						warn("[TextureConfiguration] - Replacing existing texture \'" .. v1 .. "\' of type " .. v2.ClassName .. " with new type " .. p12)
						v2:Destroy()
						v2 = nil
					end

					if v2 then
						return
					end

					local v3 = t3[p12]

					if not v3 then
						error("Unsupported texture type: " .. tostring(p12), 2)
					end

					ApplyProperties(Instance.new(v3.Class), if p2 then p2 else v3.DefaultProperties).Parent = p1
				end
			end

			if v1 == "gettexture" or v1 == "find" then
				return function(p1) --[[ Line: 208 | Upvalues: FindTexture (ref) ]]
					return FindTexture(p1)
				end
			end

			if v1 == "getlayer" then
				return function(p12) --[[ Line: 213 | Upvalues: p1 (ref) ]]
					return p1:FindFirstChild(p12)
				end
			end

			local v2 = p1:FindFirstChild(p2)

			if v2 and t3[v2.ClassName] then
				return v2
			end

			error("[TextureConfiguration] - Texture \'" .. p2 .. "\' not found or unsupported type", 2)
		end,
		__newindex = function(p12, p2, p3) --[[ __newindex | Line: 228 | Upvalues: p1 (copy), t3 (ref), ApplyProperties (ref) ]]
			local v1 = p1:FindFirstChild(p2)

			if v1 and t3[v1.ClassName] then
				ApplyProperties(v1, p3)
			else
				error("[TextureConfiguration] - Cannot configure non-existent texture: " .. p2, 2)
			end
		end
	}

	setmetatable(t, t2)
	t4[p1] = t

	return t
end
function t.OptimizeTextures(p1, p2) --[[ OptimizeTextures | Line: 243 | Upvalues: t2 (copy), t3 (copy) ]]
	local v1 = t2[p2] or t2.Medium
	local v2 = 0

	local function processTexture(p1) --[[ processTexture | Line: 248 | Upvalues: v1 (copy), v2 (ref) ]]
		if p1:IsA("Decal") then
			p1.ZIndex = v1.Resolution / 256
		elseif p1:IsA("Texture") then
			p1.StudsPerTileU = math.max(1, v1.Resolution / 512)
			p1.StudsPerTileV = math.max(1, v1.Resolution / 512)
		end

		v2 = v2 + 1
	end

	local function v3(p1) --[[ scanTextures | Line: 261 | Upvalues: t3 (ref), v1 (copy), v2 (ref), v3 (copy) ]]
		if t3[p1.ClassName] then
			if p1:IsA("Decal") then
				p1.ZIndex = v1.Resolution / 256
			elseif p1:IsA("Texture") then
				p1.StudsPerTileU = math.max(1, v1.Resolution / 512)
				p1.StudsPerTileV = math.max(1, v1.Resolution / 512)
			end

			v2 = v2 + 1
		end

		for i, v in ipairs(p1:GetChildren()) do
			v3(v)
		end
	end

	v3(p1)
	print("[TextureConfiguration] - Optimized " .. v2 .. " textures with " .. p2 .. " preset")

	return v2
end
function t.UpgradeTextureQuality(p1, p2) --[[ UpgradeTextureQuality | Line: 276 | Upvalues: t3 (copy) ]]
	local v1 = 0

	local function upgradeTexture(p1) --[[ upgradeTexture | Line: 280 | Upvalues: v1 (ref) ]]
		if not p1:IsA("Decal") or p1.Texture == "" then
			return
		end

		v1 = v1 + 1
	end

	local function v2(p1) --[[ scanTextures | Line: 288 | Upvalues: t3 (ref), v1 (ref), v2 (copy) ]]
		if t3[p1.ClassName] and (p1:IsA("Decal") and p1.Texture ~= "") then
			v1 = v1 + 1
		end

		for i, v in ipairs(p1:GetChildren()) do
			v2(v)
		end
	end

	v2(p1)
	print("[TextureConfiguration] - Upgraded " .. v1 .. " textures to " .. p2 .. " resolution")

	return v1
end
t.CreateLayer = t.CreateTextureLayer
t.GetManager = t.GetTextureManager
t.Analyze = t.AnalyzeTextureUsage
t.GenerateMissing = t.GenerateMissingTextures
t.Optimize = t.OptimizeTextures
t.Upgrade = t.UpgradeTextureQuality

return t