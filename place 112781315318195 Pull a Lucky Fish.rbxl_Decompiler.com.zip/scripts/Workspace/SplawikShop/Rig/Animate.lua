-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local v1 = script.Parent
local Humanoid = v1:WaitForChild("Humanoid")
local v2 = "Standing"

local function getRigScale() --[[ getRigScale | Line: 5 | Upvalues: v1 (copy) ]]
	return v1:GetScale()
end

local ScaleDampeningPercent = script:FindFirstChild("ScaleDampeningPercent")
local ok, result = pcall(function() --[[ Line: 14 ]]
	return UserSettings():IsUserFeatureEnabled("UserAnimateRemoveEmoteChatHook")
end)
local v4 = ""
local v5 = nil
local v6 = nil
local v7 = nil
local v8 = 1
local v9 = nil
local v10 = nil
local t = {}
local t2 = {}
local tbl = {
	idle = {
		{
			id = "http://www.roblox.com/asset/?id=507766666",
			weight = 1
		},
		{
			id = "http://www.roblox.com/asset/?id=507766951",
			weight = 1
		},
		{
			id = "http://www.roblox.com/asset/?id=507766388",
			weight = 9
		}
	},
	walk = {
		{
			id = "http://www.roblox.com/asset/?id=507777826",
			weight = 10
		}
	},
	run = {
		{
			id = "http://www.roblox.com/asset/?id=507767714",
			weight = 10
		}
	},
	swim = {
		{
			id = "http://www.roblox.com/asset/?id=507784897",
			weight = 10
		}
	},
	swimidle = {
		{
			id = "http://www.roblox.com/asset/?id=507785072",
			weight = 10
		}
	},
	jump = {
		{
			id = "http://www.roblox.com/asset/?id=507765000",
			weight = 10
		}
	},
	fall = {
		{
			id = "http://www.roblox.com/asset/?id=507767968",
			weight = 10
		}
	},
	climb = {
		{
			id = "http://www.roblox.com/asset/?id=507765644",
			weight = 10
		}
	},
	sit = {
		{
			id = "http://www.roblox.com/asset/?id=2506281703",
			weight = 10
		}
	},
	toolnone = {
		{
			id = "http://www.roblox.com/asset/?id=507768375",
			weight = 10
		}
	},
	toolslash = {
		{
			id = "http://www.roblox.com/asset/?id=522635514",
			weight = 10
		}
	},
	toollunge = {
		{
			id = "http://www.roblox.com/asset/?id=522638767",
			weight = 10
		}
	},
	wave = {
		{
			id = "http://www.roblox.com/asset/?id=507770239",
			weight = 10
		}
	},
	point = {
		{
			id = "http://www.roblox.com/asset/?id=507770453",
			weight = 10
		}
	},
	dance = {
		{
			id = "http://www.roblox.com/asset/?id=507771019",
			weight = 10
		},
		{
			id = "http://www.roblox.com/asset/?id=507771955",
			weight = 10
		},
		{
			id = "http://www.roblox.com/asset/?id=507772104",
			weight = 10
		}
	},
	dance2 = {
		{
			id = "http://www.roblox.com/asset/?id=507776043",
			weight = 10
		},
		{
			id = "http://www.roblox.com/asset/?id=507776720",
			weight = 10
		},
		{
			id = "http://www.roblox.com/asset/?id=507776879",
			weight = 10
		}
	},
	dance3 = {
		{
			id = "http://www.roblox.com/asset/?id=507777268",
			weight = 10
		},
		{
			id = "http://www.roblox.com/asset/?id=507777451",
			weight = 10
		},
		{
			id = "http://www.roblox.com/asset/?id=507777623",
			weight = 10
		}
	},
	laugh = {
		{
			id = "http://www.roblox.com/asset/?id=507770818",
			weight = 10
		}
	},
	cheer = {
		{
			id = "http://www.roblox.com/asset/?id=507770677",
			weight = 10
		}
	}
}
local t3 = {
	wave = false,
	point = false,
	dance = true,
	dance2 = true,
	dance3 = true,
	laugh = false,
	cheer = false
}
local v11 = nil
local v12 = nil
local v13 = nil
local v14 = nil
local v15 = nil
local ok2, result2 = pcall(function() --[[ Line: 122 ]]
	return UserSettings():IsUserFeatureEnabled("UserAnimationAbilityManagerFixed")
end)
local v16 = ok2 and result2

function resetManagerListeners() --[[ resetManagerListeners | Line: 129 | Upvalues: v11 (ref), v12 (ref), v13 (ref) ]]
	if v11 then
		v11:Disconnect()
		v11 = nil
	end

	if v12 then
		v12:Disconnect()
		v12 = nil
	end

	if not v13 then
		return
	end

	v13:Disconnect()
	v13 = nil
end
function teardownManager() --[[ teardownManager | Line: 145 | Upvalues: v14 (ref), v15 (ref) ]]
	resetManagerListeners()
	v14 = nil
	v15 = nil
end
function processIfManagerBelongsToCharacter(p1) --[[ processIfManagerBelongsToCharacter | Line: 154 | Upvalues: v1 (copy), v15 (ref), v14 (ref), v11 (ref), v12 (ref), v13 (ref) ]]
	if p1.RootPart ~= v1.PrimaryPart then
		return false
	end

	if v15 == p1 then
		return true
	end

	resetManagerListeners()
	v14 = p1.GroundSensor
	v11 = p1:GetPropertyChangedSignal("GroundSensor"):Connect(function() --[[ Line: 159 | Upvalues: p1 (copy), v11 (ref) ]]
		if not processIfManagerBelongsToCharacter(p1) then
			return
		end

		v11:Disconnect()
		v11 = nil
	end)
	v12 = p1:GetPropertyChangedSignal("RootPart"):Connect(function() --[[ Line: 165 | Upvalues: p1 (copy), v12 (ref) ]]
		if not processIfManagerBelongsToCharacter(p1) then
			return
		end

		v12:Disconnect()
		v12 = nil
	end)
	v13 = p1.AncestryChanged:Connect(function(p1, p2) --[[ Line: 171 ]]
		if p2 ~= nil then
			return
		end

		resetManagerListeners()
		lookForControllerManager()
	end)
	v15 = p1

	return true
end
function setupManager(p1) --[[ setupManager | Line: 186 | Upvalues: v15 (ref), v14 (ref), v11 (ref), v12 (ref), v1 (copy), v13 (ref) ]]
	v15 = p1
	v14 = p1.GroundSensor
	v11 = p1:GetPropertyChangedSignal("GroundSensor"):Connect(function() --[[ Line: 190 | Upvalues: v14 (ref), v15 (ref) ]]
		v14 = v15.GroundSensor
	end)
	v12 = p1:GetPropertyChangedSignal("RootPart"):Connect(function() --[[ Line: 194 | Upvalues: p1 (copy), v1 (ref) ]]
		if p1.RootPart == v1.PrimaryPart then
			return
		end

		teardownManager()
		lookForControllerManager()
	end)
	v13 = p1.AncestryChanged:Connect(function(p1, p2) --[[ Line: 201 ]]
		if p2 ~= nil then
			return
		end

		teardownManager()
		lookForControllerManager()
	end)
end
function lookForControllerManager() --[[ lookForControllerManager | Line: 212 | Upvalues: v16 (ref), v1 (copy), v14 (ref), v15 (ref) ]]
	if v16 then
		local ControllerManager = v1:FindFirstChildOfClass("ControllerManager")

		if not ControllerManager then
			local v12 = nil

			v12 = v1.ChildAdded:Connect(function(p1) --[[ Line: 230 | Upvalues: v12 (ref) ]]
				if not p1:IsA("ControllerManager") then
					return
				end

				v12:Disconnect()
				lookForControllerManager()
			end)

			return
		end

		if ControllerManager.RootPart == v1.PrimaryPart then
			setupManager(ControllerManager)
		else
			local v2 = nil

			v2 = ControllerManager:GetPropertyChangedSignal("RootPart"):Connect(function() --[[ Line: 221 | Upvalues: ControllerManager (copy), v1 (ref), v2 (ref) ]]
				if ControllerManager.RootPart ~= v1.PrimaryPart then
					return
				end

				v2:Disconnect()
				setupManager(ControllerManager)
			end)
		end
	else
		v14 = nil
		v15 = nil

		local ControllerManager = v1:FindFirstChildOfClass("ControllerManager")

		if ControllerManager then
			processIfManagerBelongsToCharacter(ControllerManager)
		end

		if v15 ~= nil then
			return
		end

		local v3 = nil

		v3 = v1.ChildAdded:Connect(function(p1) --[[ Line: 249 | Upvalues: v3 (ref) ]]
			if not (p1:IsA("ControllerManager") and processIfManagerBelongsToCharacter(p1)) then
				return
			end

			v3:Disconnect()
			v3 = nil
		end)
	end
end
lookForControllerManager()
math.randomseed(tick())
function findExistingAnimationInSet(p1, p2) --[[ findExistingAnimationInSet | Line: 264 ]]
	if p1 == nil or p2 == nil then
		return 0
	end

	for i = 1, p1.count do
		if p1[i].anim.AnimationId == p2.AnimationId then
			return i
		end
	end

	return 0
end
function configureAnimationSet(p1, p2) --[[ configureAnimationSet | Line: 278 | Upvalues: t2 (copy), t (copy), Humanoid (copy) ]]
	if t2[p1] ~= nil then
		for k, v in pairs(t2[p1].connections) do
			v:disconnect()
		end
	end

	t2[p1] = {}
	t2[p1].count = 0
	t2[p1].totalWeight = 0
	t2[p1].connections = {}

	local v1 = true
	local ok, _ = pcall(function() --[[ Line: 291 | Upvalues: v1 (ref) ]]
		v1 = game:GetService("StarterPlayer").AllowCustomAnimations
	end)

	if not ok then
		v1 = true
	end

	local v2 = script:FindFirstChild(p1)

	if v1 and v2 ~= nil then
		table.insert(t2[p1].connections, v2.ChildAdded:connect(function(p12) --[[ Line: 299 | Upvalues: p1 (copy), p2 (copy) ]]
			configureAnimationSet(p1, p2)
		end))
		table.insert(t2[p1].connections, v2.ChildRemoved:connect(function(p12) --[[ Line: 300 | Upvalues: p1 (copy), p2 (copy) ]]
			configureAnimationSet(p1, p2)
		end))

		for k, v in pairs(v2:GetChildren()) do
			if v:IsA("Animation") then
				local Weight = v:FindFirstChild("Weight")
				local v3 = if Weight == nil then 1 else Weight.Value

				t2[p1].count = t2[p1].count + 1

				local count = t2[p1].count

				t2[p1][count] = {}
				t2[p1][count].anim = v
				t2[p1][count].weight = v3
				t2[p1].totalWeight = t2[p1].totalWeight + t2[p1][count].weight
				table.insert(t2[p1].connections, v.Changed:connect(function(p12) --[[ Line: 316 | Upvalues: p1 (copy), p2 (copy) ]]
					configureAnimationSet(p1, p2)
				end))
				table.insert(t2[p1].connections, v.ChildAdded:connect(function(p12) --[[ Line: 317 | Upvalues: p1 (copy), p2 (copy) ]]
					configureAnimationSet(p1, p2)
				end))
				table.insert(t2[p1].connections, v.ChildRemoved:connect(function(p12) --[[ Line: 318 | Upvalues: p1 (copy), p2 (copy) ]]
					configureAnimationSet(p1, p2)
				end))
			end
		end
	end

	if t2[p1].count <= 0 then
		for k, v in pairs(p2) do
			t2[p1][k] = {}
			t2[p1][k].anim = Instance.new("Animation")
			t2[p1][k].anim.Name = p1
			t2[p1][k].anim.AnimationId = v.id
			t2[p1][k].weight = v.weight
			t2[p1].count = t2[p1].count + 1
			t2[p1].totalWeight = t2[p1].totalWeight + v.weight
		end
	end

	for k, v in pairs(t2) do
		for i = 1, v.count do
			if t[v[i].anim.AnimationId] == nil then
				Humanoid:LoadAnimation(v[i].anim)
				t[v[i].anim.AnimationId] = true
			end
		end
	end
end
function configureAnimationSetOld(p1, p2) --[[ configureAnimationSetOld | Line: 349 | Upvalues: t2 (copy), Humanoid (copy) ]]
	if t2[p1] ~= nil then
		for k, v in pairs(t2[p1].connections) do
			v:disconnect()
		end
	end

	t2[p1] = {}
	t2[p1].count = 0
	t2[p1].totalWeight = 0
	t2[p1].connections = {}

	local v1 = true
	local ok, _ = pcall(function() --[[ Line: 362 | Upvalues: v1 (ref) ]]
		v1 = game:GetService("StarterPlayer").AllowCustomAnimations
	end)

	if not ok then
		v1 = true
	end

	local v2 = script:FindFirstChild(p1)

	if v1 and v2 ~= nil then
		table.insert(t2[p1].connections, v2.ChildAdded:connect(function(p12) --[[ Line: 370 | Upvalues: p1 (copy), p2 (copy) ]]
			configureAnimationSet(p1, p2)
		end))
		table.insert(t2[p1].connections, v2.ChildRemoved:connect(function(p12) --[[ Line: 371 | Upvalues: p1 (copy), p2 (copy) ]]
			configureAnimationSet(p1, p2)
		end))

		local count = 1

		for k, v in pairs(v2:GetChildren()) do
			if v:IsA("Animation") then
				table.insert(t2[p1].connections, v.Changed:connect(function(p12) --[[ Line: 375 | Upvalues: p1 (copy), p2 (copy) ]]
					configureAnimationSet(p1, p2)
				end))
				t2[p1][count] = {}
				t2[p1][count].anim = v

				local Weight = v:FindFirstChild("Weight")

				if Weight == nil then
					t2[p1][count].weight = 1
				else
					t2[p1][count].weight = Weight.Value
				end

				t2[p1].count = t2[p1].count + 1
				t2[p1].totalWeight = t2[p1].totalWeight + t2[p1][count].weight
				count = count + 1
			end
		end
	end

	if t2[p1].count <= 0 then
		for k, v in pairs(p2) do
			t2[p1][k] = {}
			t2[p1][k].anim = Instance.new("Animation")
			t2[p1][k].anim.Name = p1
			t2[p1][k].anim.AnimationId = v.id
			t2[p1][k].weight = v.weight
			t2[p1].count = t2[p1].count + 1
			t2[p1].totalWeight = t2[p1].totalWeight + v.weight
		end
	end

	for k, v in pairs(t2) do
		for i = 1, v.count do
			Humanoid:LoadAnimation(v[i].anim)
		end
	end
end
function scriptChildModified(p1) --[[ scriptChildModified | Line: 414 | Upvalues: tbl (copy) ]]
	local v1 = tbl[p1.Name]

	if v1 == nil then
		return
	end

	configureAnimationSet(p1.Name, v1)
end
script.ChildAdded:connect(scriptChildModified)
script.ChildRemoved:connect(scriptChildModified)

local v17 = if Humanoid then Humanoid:FindFirstChildOfClass("Animator") else nil

if v17 then
	for i, v in ipairs((v17:GetPlayingAnimationTracks())) do
		v:Stop(0)
		v:Destroy()
	end
end

for k, v in pairs(tbl) do
	configureAnimationSet(k, v)
end

local v19 = "None"
local v20 = 0
local v21 = 0
local v22 = false

function stopAllAnimations() --[[ stopAllAnimations | Line: 455 | Upvalues: v4 (ref), t3 (copy), v22 (ref), v5 (ref), v7 (ref), v6 (ref), v10 (ref), v9 (ref) ]]
	local v1 = v4

	if t3[v1] ~= nil and t3[v1] == false then
		v1 = "idle"
	end

	if v22 then
		v1 = "idle"
		v22 = false
	end

	v4 = ""
	v5 = nil

	if v7 ~= nil then
		v7:disconnect()
	end

	if v6 ~= nil then
		v6:Stop()
		v6:Destroy()
		v6 = nil
	end

	if v10 ~= nil then
		v10:disconnect()
	end

	if v9 == nil then
		return v1
	end

	v9:Stop()
	v9:Destroy()
	v9 = nil

	return v1
end
function getHeightScale() --[[ getHeightScale | Line: 494 | Upvalues: Humanoid (copy), getRigScale (copy), ScaleDampeningPercent (ref) ]]
	if not Humanoid then
		return getRigScale()
	end

	if not Humanoid.AutomaticScalingEnabled then
		return getRigScale()
	end

	local v1 = Humanoid.HipHeight / 2

	if ScaleDampeningPercent == nil then
		ScaleDampeningPercent = script:FindFirstChild("ScaleDampeningPercent")
	end

	if ScaleDampeningPercent ~= nil then
		v1 = 1 + (Humanoid.HipHeight - 2) * ScaleDampeningPercent.Value / 2
	end

	return v1
end

local function rootMotionCompensation(p1) --[[ rootMotionCompensation | Line: 514 ]]
	return p1 * 1.25 / getHeightScale()
end

local function setRunSpeed(p1) --[[ setRunSpeed | Line: 522 | Upvalues: v6 (ref), v9 (ref) ]]
	local v1 = p1 * 1.25 / getHeightScale()
	local v2 = 0.0001
	local v3 = 1
	local v4

	if v1 <= 0.5 then
		v2 = 1
		v4 = 0.0001
		v3 = v1 / 0.5
	elseif v1 < 1 then
		local v5 = (v1 - 0.5) / 0.5

		v2 = 1 - v5
		v4 = v5
	else
		v4 = 1
		v3 = v1 / 1
	end

	v6:AdjustWeight(v2)
	v9:AdjustWeight(v4)
	v6:AdjustSpeed(v3)
	v9:AdjustSpeed(v3)
end

function setAnimationSpeed(p1) --[[ setAnimationSpeed | Line: 548 | Upvalues: v4 (ref), setRunSpeed (copy), v8 (ref), v6 (ref) ]]
	if v4 == "walk" then
		setRunSpeed(p1)

		return
	end

	if p1 == v8 then
		return
	end

	v8 = p1
	v6:AdjustSpeed(p1)
end
function keyFrameReachedFunc(p1) --[[ keyFrameReachedFunc | Line: 559 | Upvalues: v4 (ref), v9 (ref), v6 (ref), t3 (copy), v22 (ref), v8 (ref), Humanoid (copy) ]]
	if p1 ~= "End" then
		return
	end

	if v4 == "walk" then
		if v9.Looped ~= true then
			v9.TimePosition = 0
		end

		if v6.Looped ~= true then
			v6.TimePosition = 0
		end
	else
		local v1 = v4

		if t3[v1] ~= nil and t3[v1] == false then
			v1 = "idle"
		end

		if v22 then
			if v6.Looped then
				return
			end

			v1 = "idle"
			v22 = false
		end

		playAnimation(v1, 0.15, Humanoid)
		setAnimationSpeed(v8)
	end
end
function rollAnimation(p1) --[[ rollAnimation | Line: 592 | Upvalues: t2 (copy) ]]
	local sum = math.random(1, t2[p1].totalWeight)
	local count = 1

	while t2[p1][count].weight < sum do
		sum = sum - t2[p1][count].weight
		count = count + 1
	end

	return count
end

local function switchToAnim(p1, p2, p3, p4) --[[ switchToAnim | Line: 603 | Upvalues: v5 (ref), v6 (ref), v9 (ref), v8 (ref), v4 (ref), v7 (ref), t2 (copy), v10 (ref) ]]
	if p1 == v5 then
		return
	end

	if v6 ~= nil then
		v6:Stop(p3)
		v6:Destroy()
	end

	if v9 ~= nil then
		v9:Stop(p3)
		v9:Destroy()
		v9 = nil
	end

	v8 = 1
	v6 = p4:LoadAnimation(p1)
	v6.Priority = Enum.AnimationPriority.Core
	v6:Play(p3)
	v4 = p2
	v5 = p1

	if v7 ~= nil then
		v7:disconnect()
	end

	v7 = v6.KeyframeReached:connect(keyFrameReachedFunc)

	if p2 ~= "walk" then
		return
	end

	v9 = p4:LoadAnimation(t2.run[rollAnimation("run")].anim)
	v9.Priority = Enum.AnimationPriority.Core
	v9:Play(p3)

	if v10 ~= nil then
		v10:disconnect()
	end

	v10 = v9.KeyframeReached:connect(keyFrameReachedFunc)
end

function playAnimation(p1, p2, p3) --[[ playAnimation | Line: 652 | Upvalues: t2 (copy), switchToAnim (copy), v22 (ref) ]]
	switchToAnim(t2[p1][rollAnimation(p1)].anim, p1, p2, p3)
	v22 = false
end
function playEmote(p1, p2, p3) --[[ playEmote | Line: 660 | Upvalues: switchToAnim (copy), v22 (ref) ]]
	switchToAnim(p1, p1.Name, p2, p3)
	v22 = true
end

local v23 = ""
local v24 = nil
local v25 = nil
local v26 = nil

function toolKeyFrameReachedFunc(p1) --[[ toolKeyFrameReachedFunc | Line: 673 | Upvalues: v23 (ref), Humanoid (copy) ]]
	if p1 ~= "End" then
		return
	end

	playToolAnimation(v23, 0, Humanoid)
end
function playToolAnimation(p1, p2, p3, p4) --[[ playToolAnimation | Line: 680 | Upvalues: t2 (copy), v25 (ref), v24 (ref), v23 (ref), v26 (ref) ]]
	local anim = t2[p1][rollAnimation(p1)].anim

	if v25 == anim then
		return
	end

	if v24 ~= nil then
		v24:Stop()
		v24:Destroy()
		p2 = 0
	end

	v24 = p3:LoadAnimation(anim)

	if p4 then
		v24.Priority = p4
	end

	v24:Play(p2)
	v23 = p1
	v25 = anim
	v26 = v24.KeyframeReached:connect(toolKeyFrameReachedFunc)
end
function stopToolAnimations() --[[ stopToolAnimations | Line: 707 | Upvalues: v23 (ref), v26 (ref), v25 (ref), v24 (ref) ]]
	local v1 = v23

	if v26 ~= nil then
		v26:disconnect()
	end

	v23 = ""
	v25 = nil

	if v24 == nil then
		return v1
	end

	v24:Stop()
	v24:Destroy()
	v24 = nil

	return v1
end
function onRunning(p1) --[[ onRunning | Line: 729 | Upvalues: v14 (ref), Humanoid (copy), v15 (ref), v22 (ref), v2 (ref), t3 (copy), v4 (ref) ]]
	local v1 = getHeightScale()

	if v14 ~= nil and Humanoid.EvaluateStateMachine == false then
		local RootPart = Humanoid.RootPart
		local SensedPart = v14.SensedPart

		if SensedPart then
			local v23 = SensedPart:GetVelocityAtPosition(v14.HitFrame.Position)
			local AssemblyLinearVelocity = RootPart.AssemblyLinearVelocity
			local Magnitude = Vector3.new(AssemblyLinearVelocity.X - v23.X, 0, AssemblyLinearVelocity.Z - v23.Z).Magnitude
			local Magnitude2 = v15.MovingDirection.Magnitude

			if Magnitude2 < 0.1 then
				Magnitude = 0
				Magnitude2 = 0
			elseif Magnitude2 > 1 then
				Magnitude2 = 1
			end

			p1 = Magnitude * Magnitude2
		end
	end

	if (v22 and Humanoid.MoveDirection == Vector3.new(0, 0, 0) and Humanoid.WalkSpeed / v1 or 0.75) * v1 < p1 then
		playAnimation("walk", 0.2, Humanoid)
		setAnimationSpeed(p1 / 16)
		v2 = "Running"

		return
	end

	if t3[v4] ~= nil or v22 then
		return
	end

	playAnimation("idle", 0.2, Humanoid)
	v2 = "Standing"
end
function onDied() --[[ onDied | Line: 772 | Upvalues: v2 (ref) ]]
	v2 = "Dead"
end
function onJumping() --[[ onJumping | Line: 776 | Upvalues: Humanoid (copy), v21 (ref), v2 (ref) ]]
	playAnimation("jump", 0.1, Humanoid)
	v21 = 0.31
	v2 = "Jumping"
end
function onClimbing(p1) --[[ onClimbing | Line: 782 | Upvalues: Humanoid (copy), v2 (ref) ]]
	local v1 = p1 / getHeightScale()

	playAnimation("climb", 0.1, Humanoid)
	setAnimationSpeed(v1 / 5)
	v2 = "Climbing"
end
function onGettingUp() --[[ onGettingUp | Line: 790 | Upvalues: v2 (ref) ]]
	v2 = "GettingUp"
end
function onFreeFall() --[[ onFreeFall | Line: 794 | Upvalues: v21 (ref), Humanoid (copy), v2 (ref) ]]
	if v21 <= 0 then
		playAnimation("fall", 0.2, Humanoid)
	end

	v2 = "FreeFall"
end
function onFallingDown() --[[ onFallingDown | Line: 801 | Upvalues: v2 (ref) ]]
	v2 = "FallingDown"
end
function onSeated() --[[ onSeated | Line: 805 | Upvalues: v2 (ref) ]]
	v2 = "Seated"
end
function onPlatformStanding() --[[ onPlatformStanding | Line: 809 | Upvalues: v2 (ref) ]]
	v2 = "PlatformStanding"
end
function onSwimming(p1) --[[ onSwimming | Line: 816 | Upvalues: Humanoid (copy), v2 (ref) ]]
	local v1 = p1 / getHeightScale()

	if v1 > 1 then
		playAnimation("swim", 0.4, Humanoid)
		setAnimationSpeed(v1 / 10)
		v2 = "Swimming"
	else
		playAnimation("swimidle", 0.4, Humanoid)
		v2 = "Standing"
	end
end
function animateTool() --[[ animateTool | Line: 829 | Upvalues: v19 (ref), Humanoid (copy) ]]
	if v19 == "None" then
		playToolAnimation("toolnone", 0.1, Humanoid, Enum.AnimationPriority.Idle)

		return
	end

	if v19 == "Slash" then
		playToolAnimation("toolslash", 0, Humanoid, Enum.AnimationPriority.Action)

		return
	end

	if v19 == "Lunge" then
		playToolAnimation("toollunge", 0, Humanoid, Enum.AnimationPriority.Action)
	end
end
function getToolAnim(p1) --[[ getToolAnim | Line: 846 ]]
	for i, v in ipairs(p1:GetChildren()) do
		if v.Name == "toolanim" and v.className == "StringValue" then
			return v
		end
	end

	return nil
end

local v27 = 0

function stepAnimate(p1) --[[ stepAnimate | Line: 857 | Upvalues: v27 (ref), v21 (ref), v2 (ref), Humanoid (copy), v1 (copy), v19 (ref), v20 (ref), v25 (ref) ]]
	local v12 = p1 - v27

	v27 = p1

	if v21 > 0 then
		v21 = v21 - v12
	end

	if v2 == "FreeFall" and v21 <= 0 then
		playAnimation("fall", 0.2, Humanoid)
	else
		if v2 == "Seated" then
			playAnimation("sit", 0.5, Humanoid)

			return
		end

		if v2 == "Running" then
			playAnimation("walk", 0.2, Humanoid)
		elseif v2 == "Dead" or (v2 == "GettingUp" or (v2 == "FallingDown" or (v2 == "Seated" or v2 == "PlatformStanding"))) then
			stopAllAnimations()
		end
	end

	local Tool = v1:FindFirstChildOfClass("Tool")

	if not (Tool and Tool:FindFirstChild("Handle")) then
		stopToolAnimations()
		v19 = "None"
		v25 = nil
		v20 = 0

		return
	end

	local v22 = getToolAnim(Tool)

	if v22 then
		v19 = v22.Value
		v22.Parent = nil
		v20 = p1 + 0.3
	end

	if v20 < p1 then
		v20 = 0
		v19 = "None"
	end

	animateTool()
end
Humanoid.Died:connect(onDied)
Humanoid.Running:connect(onRunning)
Humanoid.Jumping:connect(onJumping)
Humanoid.Climbing:connect(onClimbing)
Humanoid.GettingUp:connect(onGettingUp)
Humanoid.FreeFalling:connect(onFreeFall)
Humanoid.FallingDown:connect(onFallingDown)
Humanoid.Seated:connect(onSeated)
Humanoid.PlatformStanding:connect(onPlatformStanding)
Humanoid.Swimming:connect(onSwimming)

if not (ok and result) then
	game:GetService("Players").LocalPlayer.Chatted:connect(function(p1) --[[ Line: 924 | Upvalues: v2 (ref), t3 (copy), Humanoid (copy) ]]
		local v1 = ""

		if string.sub(p1, 1, 3) == "/e " then
			v1 = string.sub(p1, 4)
		elseif string.sub(p1, 1, 7) == "/emote " then
			v1 = string.sub(p1, 8)
		end

		if v2 ~= "Standing" or t3[v1] == nil then
			return
		end

		playAnimation(v1, 0.1, Humanoid)
	end)
end

script:WaitForChild("PlayEmote").OnInvoke = function(p1) --[[ Line: 939 | Upvalues: v2 (ref), t3 (copy), Humanoid (copy), v6 (ref) ]]
	if v2 ~= "Standing" then
		return
	end

	if t3[p1] ~= nil then
		playAnimation(p1, 0.1, Humanoid)

		return true, v6
	end

	if typeof(p1) == "Instance" and p1:IsA("Animation") then
		playEmote(p1, 0.1, Humanoid)

		return true, v6
	end

	return false
end

if v1.Parent ~= nil then
	playAnimation("idle", 0.1, Humanoid)
	v2 = "Standing"
end

while v1.Parent ~= nil do
	local _, v28 = wait(0.1)

	stepAnimate(v28)
end