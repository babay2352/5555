-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local StarterGui = game:GetService("StarterGui")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local UECS = require(game.ReplicatedStorage.shared.UECS.UECS)

task.spawn(function() --[[ Line: 15 | Upvalues: StarterGui (copy) ]]
	local v1 = os.clock() + 15

	repeat
		if pcall(StarterGui.SetCore, StarterGui, "ResetButtonCallback", false) then
			return
		end

		task.wait()
	until v1 < os.clock()

	warn("[ECS.client] ResetButtonCallback never registered \226\128\148 reset button left enabled")
end)

if not ClientPlayerData.isPlayerDataLoaded then
	ClientPlayerData.playerDataLoadedSignal:Wait()
end

UECS.new():InitSystems(ReplicatedStorage.shared.UECS.Systems.Client)
Remotes.ClientUECSReady:Fire()
print(ClientPlayerData.serverProfile:getState())