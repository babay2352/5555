-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local RunService = game:GetService("RunService")
local Terrain = workspace:FindFirstChildOfClass("Terrain")
local t = {}
local t2 = {
	UpdateConnection = nil,
	UpdateQueue = table.create(10)
}

function t2.Init(p1, p2) --[[ Init | Line: 12 | Upvalues: t2 (copy), RunService (copy) ]]
	t2.Lifetime = p2.Lifetime or 3
	t2.Direction = p2.Direction or Vector3.new(1, 0, 0)
	t2.Speed = p2.Speed or 6

	if t2.UpdateConnection then
		t2.UpdateConnection:Disconnect()
		t2.UpdateConnection = nil
	end

	for v1, v2 in t2.UpdateQueue do
		v2.Attachment0:Destroy()
		v2.Attachment1:Destroy()
		v2.Trail:Destroy()
	end

	table.clear(t2.UpdateQueue)
	t2.LastSpawned = os.clock()

	local v3 = 1 / (p2.SpawnRate or 25)

	t2.UpdateConnection = RunService.Heartbeat:Connect(function() --[[ Line: 35 | Upvalues: t2 (ref), v3 (copy) ]]
		local v1 = os.clock()

		if v3 < v1 - t2.LastSpawned then
			t2:Create()
			t2.LastSpawned = v1
		end

		debug.profilebegin("Wind Lines")

		for v2, v32 in t2.UpdateQueue do
			local v4 = v1 - v32.StartClock

			if v32.Lifetime <= v4 then
				v32.Attachment0:Destroy()
				v32.Attachment1:Destroy()
				v32.Trail:Destroy()

				local v5 = #t2.UpdateQueue

				t2.UpdateQueue[v2] = t2.UpdateQueue[v5]
				t2.UpdateQueue[v5] = nil

				continue
			end

			v32.Trail.MaxLength = 20 - 20 * (v4 / v32.Lifetime)

			local v6 = (v1 + v32.Seed) * (v32.Speed * 0.2)
			local Position = v32.Position
			local Position2 = (CFrame.new(Position, Position + v32.Direction) * CFrame.new(0, 0, v32.Speed * -v4)).Position

			v32.Attachment0.WorldPosition = Position2 + Vector3.new(math.sin(v6) * 0.5, math.sin(v6) * 0.8, math.sin(v6) * 0.5)
			v32.Attachment1.WorldPosition = v32.Attachment0.WorldPosition + Vector3.new(0, 0.1, 0)
		end

		debug.profileend()
	end)
end
function t2.Cleanup(p1) --[[ Cleanup | Line: 82 | Upvalues: t2 (copy) ]]
	if t2.UpdateConnection then
		t2.UpdateConnection:Disconnect()
		t2.UpdateConnection = nil
	end

	for v1, v2 in t2.UpdateQueue do
		v2.Attachment0:Destroy()
		v2.Attachment1:Destroy()
		v2.Trail:Destroy()
	end

	table.clear(t2.UpdateQueue)
end
function t2.Create(p1, p2) --[[ Create | Line: 96 | Upvalues: t (copy), t2 (copy), Terrain (copy) ]]
	debug.profilebegin("Add Wind Line")

	local v1 = if p2 then p2 else t
	local v2 = v1.Lifetime or t2.Lifetime
	local Position = v1.Position

	if not Position then
		local v3 = workspace.CurrentCamera.CFrame
		local Angles = CFrame.Angles
		local v5 = math.rad((math.random(-30, 70)))
		local v6 = math.random(-80, 80)

		Position = v3 * Angles(v5, math.rad(v6), 0) * CFrame.new(0, 0, math.random(200, 600) * -0.1).Position
	end

	local v7 = v1.Direction or t2.Direction
	local v8 = v1.Speed or t2.Speed

	if not (v8 <= 0) then
		local Attachment = Instance.new("Attachment")
		local Attachment2 = Instance.new("Attachment")
		local Trail = Instance.new("Trail")

		Trail.Attachment0 = Attachment
		Trail.Attachment1 = Attachment2
		Trail.WidthScale = NumberSequence.new({
			NumberSequenceKeypoint.new(0, 0.3),
			NumberSequenceKeypoint.new(0.2, 1),
			NumberSequenceKeypoint.new(0.8, 1),
			NumberSequenceKeypoint.new(1, 0.3)
		})
		Trail.Transparency = NumberSequence.new(0.7)
		Trail.FaceCamera = true
		Trail.Parent = Attachment
		Attachment.WorldPosition = Position
		Attachment2.WorldPosition = Position + Vector3.new(0, 0.1, 0)
		t2.UpdateQueue[#t2.UpdateQueue + 1] = {
			Attachment0 = Attachment,
			Attachment1 = Attachment2,
			Trail = Trail,
			Lifetime = v2 + math.random(-10, 10) * 0.1,
			Position = Position,
			Direction = v7,
			Speed = v8 + math.random(-10, 10) * 0.1,
			StartClock = os.clock(),
			Seed = math.random(1, 1000) * 0.1
		}
		Attachment.Parent = Terrain
		Attachment2.Parent = Terrain
		debug.profileend()
	end
end

return t2