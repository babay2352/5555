-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local RunService = game:GetService("RunService")
local Settings = require(script.Settings)
local VectorMap = require(script.VectorMap)
local v1 = Instance.new("BindableEvent")
local v2 = Instance.new("BindableEvent")
local v3 = Instance.new("BindableEvent")
local v4 = Instance.new("BindableEvent")
local v5 = Instance.new("BindableEvent")
local t = {
	RenderDistance = 150,
	MaxRefreshRate = 1 / 60,
	Handled = 0,
	Active = 0,
	Initialized = nil,
	AddedConnection = nil,
	UpdateConnection = nil,
	RemovedConnection = nil,
	WorkspaceWindConnection = nil,
	SharedSettings = Settings.new(script),
	ObjectMetadata = {},
	VectorMap = VectorMap.new(),
	_partList = table.create(500),
	_cframeList = table.create(500),
	ObjectShakeAdded = v3.Event,
	ObjectShakeRemoved = v4.Event,
	ObjectShakeUpdated = v5.Event,
	Paused = v1.Event,
	Resumed = v2.Event
}

local function Connect(p1, p2, p3) --[[ Connect | Line: 83 ]]
	return p2:Connect(function(...) --[[ Line: 84 | Upvalues: p3 (copy), p1 (copy) ]]
		return p3(p1, ...)
	end)
end

function t.AddObjectShake(p1, p2, p3) --[[ AddObjectShake | Line: 89 | Upvalues: Settings (copy), v3 (copy) ]]
	if typeof(p2) ~= "Instance" then
		return
	end

	if not (p2:IsA("BasePart") or p2:IsA("Bone")) then
		return
	end

	local ObjectMetadata = p1.ObjectMetadata

	if ObjectMetadata[p2] then
		return
	end

	local t = {}

	t.ChunkKey = p1.VectorMap:AddObject(if p2:IsA("Bone") then p2.WorldPosition else p2.Position, p2)
	t.Settings = Settings.new(p2)
	t.Seed = math.random(5000) * 0.32
	t.Origin = if p2:IsA("Bone") then p2.WorldCFrame else p2.CFrame
	t.LastUpdate = os.clock()
	ObjectMetadata[p2] = t

	if p3 then
		p1:UpdateObjectSettings(p2, p3)
	end

	v3:Fire(p2)
	p1.Handled = p1.Handled + 1
end
function t.RemoveObjectShake(p1, p2) --[[ RemoveObjectShake | Line: 130 | Upvalues: v4 (copy) ]]
	if typeof(p2) ~= "Instance" then
		return
	end

	if not (p2:IsA("BasePart") or p2:IsA("Bone")) then
		return
	end

	local ObjectMetadata = p1.ObjectMetadata
	local v1 = ObjectMetadata[p2]

	if v1 then
		p1.Handled = p1.Handled - 1
		ObjectMetadata[p2] = nil
		v1.Settings:Destroy()
		p1.VectorMap:RemoveObject(v1.ChunkKey, p2)

		if p2:IsA("BasePart") then
			p2.CFrame = v1.Origin
		elseif p2:IsA("Bone") then
			p2.WorldCFrame = v1.Origin
		end
	end

	v4:Fire(p2)
end
function t.Update(p1, p2) --[[ Update | Line: 159 ]]
	debug.profilebegin("WindShake")

	local v1 = 0

	debug.profilebegin("Update")

	local v2 = os.clock()
	local v3 = p2 * 3
	local v4 = math.min(1, p2 * 5)
	local v5 = 0
	local _partList = p1._partList
	local _cframeList = p1._cframeList

	table.clear(_partList)
	table.clear(_cframeList)

	local ObjectMetadata = p1.ObjectMetadata
	local CurrentCamera = workspace.CurrentCamera
	local Position = CurrentCamera.CFrame.Position
	local RenderDistance = p1.RenderDistance
	local MaxRefreshRate = p1.MaxRefreshRate
	local SharedSettings = p1.SharedSettings
	local v6 = assert(SharedSettings.WindPower)
	local v7 = assert(SharedSettings.WindSpeed)
	local v8 = assert(SharedSettings.WindDirection)

	p1.VectorMap:ForEachObjectInView(CurrentCamera, RenderDistance, function(p1, p2) --[[ Line: 191 | Upvalues: ObjectMetadata (copy), Position (copy), RenderDistance (copy), v3 (copy), MaxRefreshRate (copy), v2 (copy), v1 (ref), v8 (copy), v6 (copy), v7 (copy), v4 (copy), v5 (ref), _partList (copy), _cframeList (copy) ]]
		local v12 = ObjectMetadata[p2]
		local v32 = p1 == "Bone"
		local v42 = if v32 then p2.WorldCFrame else p2.CFrame
		local v52 = (Position - v42.Position).Magnitude / RenderDistance
		local v62 = v52 * v52

		if v3 * v62 + MaxRefreshRate >= v2 - (v12.LastUpdate or 0) + 1 / math.random(60, 120) then
			return
		end

		v12.LastUpdate = v2
		v1 = v1 + 1

		local Settings = v12.Settings
		local v72 = Settings.WindDirection or v8

		if v72.Magnitude < 0.00001 then
			return
		end

		local v9 = (Settings.WindPower or v6) * 0.2

		if v9 < 0.00001 then
			return
		end

		local v122 = v2 * ((Settings.WindSpeed or v7) * 0.08)

		if v122 < 0.00001 then
			return
		end

		local Seed = v12.Seed
		local v13 = (math.noise(v122, 0, Seed) + 0.4) * v9
		local v15 = math.clamp(v4 + v62, 0.1, 0.5)
		local v16 = v9 / 3
		local v18 = v12.Origin * (Settings.PivotOffset or CFrame.identity)
		local v19 = v18:VectorToObjectSpace(v72)

		if v32 then
			p2.Transform = p2.Transform:Lerp(CFrame.fromAxisAngle(v19:Cross(Vector3.new(0, 1, 0)), -v13) * CFrame.Angles(math.noise(Seed, 0, v122) * v16, math.noise(Seed, v122, 0) * v16, math.noise(v122, Seed, 0) * v16) + v19 * v13 * v9, v15)

			return
		end

		v5 = v5 + 1
		_partList[v5] = p2
		_cframeList[v5] = v42:Lerp(v18 * CFrame.fromAxisAngle(v19:Cross(Vector3.new(0, 1, 0)), -v13) * CFrame.Angles(math.noise(Seed, 0, v122) * v16, math.noise(Seed, v122, 0) * v16, math.noise(v122, Seed, 0) * v16) * (Settings.PivotOffsetInverse or CFrame.identity) + v72 * v13 * (v9 * 2), v15)
	end)
	p1.Active = v1
	debug.profileend()
	workspace:BulkMoveTo(_partList, _cframeList, Enum.BulkMoveMode.FireCFrameChanged)
	debug.profileend()
end
function t.Pause(p1) --[[ Pause | Line: 279 | Upvalues: v1 (copy) ]]
	if p1.UpdateConnection then
		p1.UpdateConnection:Disconnect()
		p1.UpdateConnection = nil
	end

	p1.Active = 0
	p1.Running = false
	v1:Fire()
end
function t.Resume(p1) --[[ Resume | Line: 291 | Upvalues: RunService (copy), v2 (copy) ]]
	if not p1.Running then
		local Update = p1.Update

		p1.UpdateConnection = RunService.Heartbeat:Connect(function(...) --[[ Line: 84 | Upvalues: Update (copy), p1 (copy) ]]
			return Update(p1, ...)
		end)
		p1.Running = true
		v2:Fire()
	end
end
function t.Init(p1, p2) --[[ Init | Line: 303 | Upvalues: CollectionService (copy) ]]
	if p1.Initialized then
		return
	end

	local v1 = script:GetAttribute("WindPower")
	local v2 = script:GetAttribute("WindSpeed")
	local v3 = script:GetAttribute("WindDirection")

	if typeof(v1) ~= "number" then
		script:SetAttribute("WindPower", 0.5)
	end

	if typeof(v2) ~= "number" then
		script:SetAttribute("WindSpeed", 20)
	end

	if typeof(v3) ~= "Vector3" then
		script:SetAttribute("WindDirection", Vector3.new(0.5, 0, 0.5))
	end

	p1:Cleanup()
	p1.Initialized = true

	local v4 = CollectionService:GetInstanceAddedSignal("WindShake")
	local AddObjectShake = p1.AddObjectShake

	p1.AddedConnection = v4:Connect(function(...) --[[ Line: 84 | Upvalues: AddObjectShake (copy), p1 (copy) ]]
		return AddObjectShake(p1, ...)
	end)

	local v5 = CollectionService:GetInstanceRemovedSignal("WindShake")
	local RemoveObjectShake = p1.RemoveObjectShake

	p1.RemovedConnection = v5:Connect(function(...) --[[ Line: 84 | Upvalues: RemoveObjectShake (copy), p1 (copy) ]]
		return RemoveObjectShake(p1, ...)
	end)

	for v6, v7 in CollectionService:GetTagged("WindShake") do
		if v7:IsA("BasePart") or v7:IsA("Bone") then
			p1:AddObjectShake(v7)
		end
	end

	if p2 and p2.MatchWorkspaceWind then
		p1:MatchWorkspaceWind()
		p1.WorkspaceWindConnection = workspace:GetPropertyChangedSignal("GlobalWind"):Connect(function() --[[ Line: 346 | Upvalues: p1 (copy) ]]
			p1:MatchWorkspaceWind()
		end)
	end

	p1:Resume()
end
function t.Cleanup(p1) --[[ Cleanup | Line: 355 ]]
	if not p1.Initialized then
		return
	end

	p1:Pause()

	if p1.AddedConnection then
		p1.AddedConnection:Disconnect()
		p1.AddedConnection = nil
	end

	if p1.RemovedConnection then
		p1.RemovedConnection:Disconnect()
		p1.RemovedConnection = nil
	end

	if p1.WorkspaceWindConnection then
		p1.WorkspaceWindConnection:Disconnect()
		p1.WorkspaceWindConnection = nil
	end

	table.clear(p1.ObjectMetadata)
	p1.VectorMap:ClearAll()
	p1.Handled = 0
	p1.Active = 0
	p1.Initialized = false
end
function t.UpdateObjectSettings(p1, p2, p3) --[[ UpdateObjectSettings | Line: 385 | Upvalues: v5 (copy) ]]
	if typeof(p2) ~= "Instance" then
		return
	end

	if typeof(p3) ~= "table" then
		return
	end

	if not p1.ObjectMetadata[p2] and p2 ~= script then
		return
	end

	for k, v in pairs(p3) do
		p2:SetAttribute(k, v)
	end

	v5:Fire(p2)
end
function t.UpdateAllObjectSettings(p1, p2) --[[ UpdateAllObjectSettings | Line: 406 | Upvalues: v5 (copy) ]]
	if typeof(p2) ~= "table" then
		return
	end

	for v1, v2 in p1.ObjectMetadata do
		for k, v in pairs(p2) do
			v1:SetAttribute(k, v)
		end

		v5:Fire(v1)
	end
end
function t.SetDefaultSettings(p1, p2) --[[ SetDefaultSettings | Line: 420 ]]
	p1:UpdateObjectSettings(script, p2)
end
function t.MatchWorkspaceWind(p1) --[[ MatchWorkspaceWind | Line: 424 ]]
	local GlobalWind = workspace.GlobalWind
	local Magnitude = GlobalWind.Magnitude
	local v1, v2

	if Magnitude > 0 then
		v1 = if Magnitude > 1 then math.log10(Magnitude) + 0.2 else 0.3
		v2 = if Magnitude < 100 then Magnitude * 1.2 + 5 else 125
	else
		v2 = 0
		v1 = 0
	end

	p1:SetDefaultSettings({
		WindDirection = GlobalWind.Unit,
		WindSpeed = v2,
		WindPower = v1
	})
end

return t