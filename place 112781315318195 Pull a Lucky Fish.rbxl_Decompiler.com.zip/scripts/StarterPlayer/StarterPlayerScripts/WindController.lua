-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")

require(ReplicatedStorage.shared.util.isMobile)

if require(ReplicatedStorage.shared.util.isPlayerOnMobile)() then
	return
end

local WindLines = require(script.WindLines)
local WindShake = require(script.WindShake)

WindLines:Init({
	Direction = Vector3.new(1, 0, 0.3),
	Speed = 20,
	Lifetime = 1.5,
	SpawnRate = 11
})
WindShake:SetDefaultSettings({
	WindSpeed = 20,
	WindDirection = Vector3.new(1, 0, 0.3),
	WindPower = 0.5
})
WindShake:Init({
	MatchWorkspaceWind = true
})