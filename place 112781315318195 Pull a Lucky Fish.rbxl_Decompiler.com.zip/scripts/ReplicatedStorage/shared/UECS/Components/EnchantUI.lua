-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Component = require(ReplicatedStorage.shared.UECS.ECSElements.Component)

require(ReplicatedStorage.shared.UECS.ECSElements.PropertyValue)

local v1 = Component.new(script.Name, false, false)

v1.DefaultProperties = {
	Visible = false,
	Target = "Rod"
}

return v1