-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Component = require(ReplicatedStorage.shared.UECS.ECSElements.Component)

require(ReplicatedStorage.shared.types.GrowATailTypes)
require(ReplicatedStorage.shared.UECS.ECSElements.PropertyValue)
require(ReplicatedStorage.shared.config.rarityConfig)
require(ReplicatedStorage.shared.UECS.UECS)

local v1 = Component.new(script.Name, true, false)

v1.DefaultProperties = {
	Rarity = "Common",
	DisplayName = "a",
	Earnings = 0,
	Mutations = "",
	EarningsPercent = 0
}

return v1