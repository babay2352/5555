-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Component = require(ReplicatedStorage.shared.UECS.ECSElements.Component)

require(ReplicatedStorage.shared.UECS.ECSElements.ComponentRef)

local v1 = Component.new(script.Name, true, true)

v1.DefaultProperties = {
	OpenedUIComponent = Component.Ref
}

return v1