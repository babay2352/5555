-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Component = require(ReplicatedStorage.shared.UECS.ECSElements.Component)

require(ReplicatedStorage.shared.UECS.ECSElements.PropertyValue)
require(ReplicatedStorage.shared.UECS.UECS)

local v1 = Component.new(script.Name, true, true)

v1.DefaultProperties = {
	Visible = true,
	OfflineEarned = 0
}

return v1