-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Component = require(ReplicatedStorage.shared.UECS.ECSElements.Component)

require(ReplicatedStorage.shared.UECS.ECSElements.PropertyValue)

local UECS = require(ReplicatedStorage.shared.UECS.UECS)
local v1 = Component.new(script.Name, true, false)

v1.DefaultProperties = {
	ConfigName = UECS.Nil,
	Owner = UECS.Nil
}

return v1