-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local v1 = require(ReplicatedStorage.shared.UECS.ECSElements.Component).new(script.Name, true, true)

v1.DefaultProperties = {
	Visible = false
}

return v1