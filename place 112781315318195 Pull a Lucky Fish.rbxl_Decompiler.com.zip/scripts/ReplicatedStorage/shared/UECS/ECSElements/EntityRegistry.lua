-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Signal = require(ReplicatedStorage.package.Signal)
local t = {}

t.__index = t
function t.new() --[[ new | Line: 23 | Upvalues: t (copy), Signal (copy), CollectionService (copy) ]]
	local v2 = setmetatable({}, t)

	v2._byId = {}
	v2._idByInstance = {}
	v2._pendingAttrConns = {}
	v2.Attached = Signal.new()
	v2.Detached = Signal.new()

	for v3, v4 in CollectionService:GetTagged("Entity") do
		v2:_track(v4)
	end

	CollectionService:GetInstanceAddedSignal("Entity"):Connect(function(p1) --[[ Line: 39 | Upvalues: v2 (copy) ]]
		v2:_track(p1)
	end)
	CollectionService:GetInstanceRemovedSignal("Entity"):Connect(function(p1) --[[ Line: 42 | Upvalues: v2 (copy) ]]
		v2:_untrack(p1)
	end)

	return v2
end
function t._track(p1, p2) --[[ _track | Line: 49 ]]
	if p1._idByInstance[p2] then
		return
	end

	local v1 = p2:GetAttribute("_UECSEntityId")

	if type(v1) == "string" then
		p1._byId[v1] = p2
		p1._idByInstance[p2] = v1
		p1.Attached:Fire(v1, p2)
	else
		local v2 = nil

		v2 = p2:GetAttributeChangedSignal("_UECSEntityId"):Connect(function() --[[ Line: 62 | Upvalues: p2 (copy), v2 (ref), p1 (copy) ]]
			local v1 = p2:GetAttribute("_UECSEntityId")

			if type(v1) == "string" then
				v2:Disconnect()
				p1._pendingAttrConns[p2] = nil
				p1._byId[v1] = p2
				p1._idByInstance[p2] = v1
				p1.Attached:Fire(v1, p2)
			end
		end)
		p1._pendingAttrConns[p2] = v2
	end
end
function t._untrack(p1, p2) --[[ _untrack | Line: 76 ]]
	local v1 = p1._pendingAttrConns[p2]

	if v1 then
		v1:Disconnect()
		p1._pendingAttrConns[p2] = nil
	end

	local v2 = p1._idByInstance[p2]

	if not v2 then
		return
	end

	p1._idByInstance[p2] = nil

	if p1._byId[v2] == p2 then
		p1._byId[v2] = nil
	end

	p1.Detached:Fire(v2, p2)
end
function t.Get(p1, p2) --[[ Get | Line: 94 ]]
	return p1._byId[p2]
end

return t