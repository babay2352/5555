-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ComponentRegistry = require(ReplicatedStorage.shared.UECS.ECSElements.ComponentRegistry)
local Signal = require(ReplicatedStorage.package.Signal)
local t = {}

t.__index = t

local function Coerce(p1) --[[ Coerce | Line: 16 ]]
	if p1 == nil then
		return nil
	end

	if type(p1) == "string" then
		return p1
	end

	if type(p1) == "table" and p1.UID then
		return p1.UID
	end

	return nil
end

function t.new(p1, p2) --[[ new | Line: 27 | Upvalues: t (copy), Signal (copy) ]]
	local v2 = setmetatable({}, t)

	v2.ComponentUID = p1
	v2.OnChange = Signal.new()
	v2.Value = if p2 == nil then nil elseif type(p2) == "string" then p2 elseif type(p2) == "table" and p2.UID then p2.UID else nil

	return v2
end
function t.Get(p1) --[[ Get | Line: 35 | Upvalues: ComponentRegistry (copy) ]]
	if p1.Value == nil then
		return nil
	end

	return ComponentRegistry.Components[p1.Value]
end
function t.Set(p1, p2) --[[ Set | Line: 42 | Upvalues: ComponentRegistry (copy) ]]
	local v1 = if p2 == nil then nil elseif type(p2) == "string" then p2 elseif type(p2) == "table" and p2.UID then p2.UID else nil
	local v2 = p1.Value

	if v1 == v2 then
		return
	end

	p1.Value = v1

	local v3 = if v2 then ComponentRegistry.Components[v2] else nil

	p1.OnChange:Fire(p1:Get(), v3)
end

return t