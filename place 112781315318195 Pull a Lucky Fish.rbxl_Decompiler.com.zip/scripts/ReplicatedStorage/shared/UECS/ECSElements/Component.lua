-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local HttpService = game:GetService("HttpService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ComponentRef = require(ReplicatedStorage.shared.UECS.ECSElements.ComponentRef)
local PropertyValue = require(ReplicatedStorage.shared.UECS.ECSElements.PropertyValue)
local Signal = require(ReplicatedStorage.package.Signal)
local t = {}

t.__index = t

local Nil = PropertyValue.Nil

t.Nil = Nil

local v1 = newproxy(false)

t.Ref = v1

local function ensureEntityId(p1) --[[ ensureEntityId | Line: 25 | Upvalues: HttpService (copy) ]]
	local v1 = p1:GetAttribute("_UECSEntityId")

	if type(v1) == "string" then
		return v1
	end

	local v2 = HttpService:GenerateGUID(false)

	p1:SetAttribute("_UECSEntityId", v2)

	return v2
end

function t.new(p1, p2, p3) --[[ new | Line: 59 | Upvalues: t (copy), v1 (copy), ComponentRef (copy), Nil (copy), PropertyValue (copy), HttpService (copy), Signal (copy) ]]
	local v2 = setmetatable({}, t)

	v2.__index = v2
	v2.Name = p1
	v2.DefaultProperties = {}
	v2.ReplicateToClient = p2 or false
	v2.AcceptClientChanges = p3 or false

	local function initProperties(p1, p2) --[[ initProperties | Line: 67 | Upvalues: v2 (copy), v1 (ref), ComponentRef (ref), Nil (ref), PropertyValue (ref) ]]
		for k, v in pairs(v2.DefaultProperties) do
			local v12 = if p2 then p2[k] else nil

			if v == v1 then
				p1[k] = ComponentRef.new(p1.UID, v12)

				continue
			end

			if v == Nil then
				v = nil
			end

			if v12 == nil then
				v12 = v
			end

			p1[k] = PropertyValue.new(p1.UID, v12)
		end
	end

	function v2.Add(p1) --[[ Add | Line: 84 | Upvalues: v2 (copy), HttpService (ref), Signal (ref), initProperties (copy) ]]
		local v22 = setmetatable({}, v2)

		v22.UID = HttpService:GenerateGUID(false)
		v22.Entity = p1
		v22.Name = v2.Name
		v22.OnAttached = Signal.new()
		v22.OnDetached = Signal.new()

		local v3 = p1:GetAttribute("_UECSEntityId")
		local v4

		if type(v3) == "string" then
			v4 = v3
		else
			local v5 = HttpService:GenerateGUID(false)

			p1:SetAttribute("_UECSEntityId", v5)
			v4 = v5
		end

		v22.EntityId = v4
		p1:AddTag("Entity")
		initProperties(v22)
		v2._ComponentCreated(v22.UID, v22, false)

		return v22
	end
	function v2._AddFromReplication(p1, p2, p3) --[[ _AddFromReplication | Line: 100 | Upvalues: v2 (copy), Signal (ref), HttpService (ref), initProperties (copy) ]]
		local v22 = setmetatable({}, v2)

		v22.UID = p1
		v22.Entity = p2
		v22.Name = v2.Name
		v22.OnAttached = Signal.new()
		v22.OnDetached = Signal.new()

		local v3 = p2:GetAttribute("_UECSEntityId")
		local v4

		if type(v3) == "string" then
			v4 = v3
		else
			local v5 = HttpService:GenerateGUID(false)

			p2:SetAttribute("_UECSEntityId", v5)
			v4 = v5
		end

		v22.EntityId = v4
		p2:AddTag("Entity")
		initProperties(v22, p3)
		v2._ComponentCreated(v22.UID, v22, true)

		return v22
	end
	function v2._Attach(p1, p2) --[[ _Attach | Line: 119 ]]
		p1.Entity = p2
		p2:AddTag("Entity")
		p1.OnAttached:Fire(p2)
	end
	function v2._Detach(p1) --[[ _Detach | Line: 125 ]]
		local Entity = p1.Entity

		p1.Entity = nil

		if not Entity then
			return
		end

		p1.OnDetached:Fire(Entity)
	end
	function v2.WaitForEntity(p1) --[[ WaitForEntity | Line: 133 ]]
		if p1.Entity then
			return p1.Entity
		end

		return p1.OnAttached:Wait()
	end
	function v2.Destroy(p1) --[[ Destroy | Line: 140 | Upvalues: v2 (copy) ]]
		v2._ComponentDestroyed(p1.UID, false)

		if not p1.Entity then
			return
		end

		p1.Entity:RemoveTag("Entity")
	end
	function v2._DestroyFromReplication(p1) --[[ _DestroyFromReplication | Line: 147 | Upvalues: v2 (copy) ]]
		v2._ComponentDestroyed(p1.UID, true)

		if not p1.Entity then
			return
		end

		p1.Entity:RemoveTag("Entity")
	end

	return v2
end

return t