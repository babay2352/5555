-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Signal = require(ReplicatedStorage.package.Signal)
local v1 = newproxy(false)
local t = {}

t.__index = t
t.Nil = v1
function t.new(p1, p2) --[[ new | Line: 23 | Upvalues: t (copy), v1 (copy), Signal (copy) ]]
	local v2 = setmetatable({}, t)

	if p2 == v1 then
		p2 = nil
	end

	v2.Value = p2
	v2.ComponentUID = p1
	v2.OnChange = Signal.new()

	return v2
end
function t.Get(p1) --[[ Get | Line: 34 ]]
	return p1.Value
end
function t.Set(p1, p2) --[[ Set | Line: 38 | Upvalues: v1 (copy) ]]
	if p2 == v1 then
		p2 = nil
	end

	local v12 = p1.Value

	p1.Value = p2
	p1.OnChange:Fire(p2, v12)
end

return t