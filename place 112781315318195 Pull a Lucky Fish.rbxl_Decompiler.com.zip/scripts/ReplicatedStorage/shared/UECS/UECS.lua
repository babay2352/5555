-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")

game:GetService("HttpService")

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local Component = require(ReplicatedStorage.shared.UECS.ECSElements.Component)
local ComponentRegistry = require(ReplicatedStorage.shared.UECS.ECSElements.ComponentRegistry)
local EntityRegistry = require(ReplicatedStorage.shared.UECS.ECSElements.EntityRegistry)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local Signal = require(ReplicatedStorage.package.Signal)
local t = {}

t.__index = t
t.Nil = Component.Nil

local t2 = {}
local t3 = {}
local v1 = Signal.new()

function t.OnClientReady() --[[ OnClientReady | Line: 25 | Upvalues: v1 (copy) ]]
	return v1
end
function t.OnComponentCreated(p1) --[[ OnComponentCreated | Line: 29 | Upvalues: t2 (copy), Signal (copy) ]]
	if not t2[p1] then
		t2[p1] = Signal.new()
	end

	return t2[p1]
end
function t.OnComponentDestroyed(p1) --[[ OnComponentDestroyed | Line: 36 | Upvalues: t3 (copy), Signal (copy) ]]
	if not t3[p1] then
		t3[p1] = Signal.new()
	end

	return t3[p1]
end
function t.new() --[[ new | Line: 43 | Upvalues: t (copy), ComponentRegistry (copy), RunService (copy), EntityRegistry (copy), Remotes (copy), ReplicatedStorage (copy), t2 (copy), t3 (copy), Players (copy), v1 (copy) ]]
	local v2 = setmetatable({}, t)

	v2.Components = ComponentRegistry.Components
	v2.ComponentCategorizedByNames = {}
	v2._PlayerAddedCallbacks = {}
	v2._PlayerRemovingCallbacks = {}
	v2._SystemsInitialized = false

	local v3 = RunService:IsServer()
	local t4 = {}
	local t5 = {}
	local v4 = nil
	local v5 = EntityRegistry.new()

	v2._entityRegistry = v5

	local t6 = {}
	local t7 = {}

	local function queuePending(p1) --[[ queuePending | Line: 67 | Upvalues: t6 (copy), t7 (copy) ]]
		local v1 = t6[p1.EntityId]

		if not v1 then
			v1 = {}
			t6[p1.EntityId] = v1
		end

		table.insert(v1, p1)
		t7[p1.UID] = p1
	end

	local function dequeuePending(p1) --[[ dequeuePending | Line: 77 | Upvalues: t7 (copy), t6 (copy) ]]
		t7[p1.UID] = nil

		local v1 = t6[p1.EntityId]

		if not v1 then
			return
		end

		for v2, v3 in v1 do
			if v3 == p1 then
				table.remove(v1, v2)

				break
			end
		end

		if #v1 ~= 0 then
			return
		end

		t6[p1.EntityId] = nil
	end

	local function FireToReady(p1) --[[ FireToReady | Line: 94 | Upvalues: t5 (copy), v4 (ref), Remotes (ref) ]]
		for k in pairs(t5) do
			if k ~= v4 then
				Remotes.ReplicateToClient:Fire(k, p1)
			end
		end
	end

	for k, v in pairs(ReplicatedStorage.shared.UECS.Components:GetChildren()) do
		local v6 = require(v)

		t4[v6.Name] = v6
		function v6._ComponentCreated(p1, p2, p3) --[[ Line: 107 | Upvalues: v2 (copy), t2 (ref), v3 (copy), v6 (copy), FireToReady (copy), Remotes (ref) ]]
			v2.Components[p1] = p2

			if not v2.ComponentCategorizedByNames[p2.Name] then
				v2.ComponentCategorizedByNames[p2.Name] = {}
			end

			table.insert(v2.ComponentCategorizedByNames[p2.Name], p2)

			local v22 = t2[p2.Name]

			if v22 then
				v22:Fire(p2)
			end

			if v3 and v6.ReplicateToClient then
				local t = {}

				for k in pairs(v6.DefaultProperties) do
					local v32 = p2[k]

					t[k] = v32.Value
					v32.OnChange:Connect(function() --[[ Line: 124 | Upvalues: FireToReady (ref), p1 (copy), k (copy), v32 (copy) ]]
						FireToReady({
							Type = "PropertyChange",
							UID = p1,
							PropertyName = k,
							Value = v32.Value
						})
					end)
				end

				FireToReady({
					Type = "Create",
					Name = v6.Name,
					UID = p1,
					EntityId = p2.EntityId,
					Properties = t
				})
			end

			if v3 or not v6.AcceptClientChanges then
				return
			end

			for k in pairs(v6.DefaultProperties) do
				local v4 = p2[k]

				v4.OnChange:Connect(function() --[[ Line: 145 | Upvalues: p2 (copy), Remotes (ref), p1 (copy), k (copy), v4 (copy) ]]
					if not p2._SuppressClientFire then
						Remotes.AcceptClientChanges:Fire({
							Type = "PropertyChange",
							UID = p1,
							PropertyName = k,
							Value = v4.Value
						})
					end
				end)
			end

			if p3 then
				return
			end

			local t = {}

			for k in pairs(v6.DefaultProperties) do
				t[k] = p2[k].Value
			end

			Remotes.AcceptClientChanges:Fire({
				Type = "Create",
				Name = v6.Name,
				UID = p1,
				EntityId = p2.EntityId,
				Properties = t
			})
		end
		function v6._ComponentDestroyed(p1, p2) --[[ Line: 174 | Upvalues: v2 (copy), t3 (ref), v3 (copy), v6 (copy), FireToReady (copy), Remotes (ref) ]]
			local v1 = v2.Components[p1]

			v2.Components[p1] = nil

			if v1 then
				local v22 = v2.ComponentCategorizedByNames[v1.Name]

				if v22 then
					for i, v in ipairs(v22) do
						if v == v1 then
							table.remove(v22, i)

							break
						end
					end
				end

				local v32 = t3[v1.Name]

				if v32 then
					v32:Fire(v1)
				end
			end

			if v3 and v6.ReplicateToClient then
				FireToReady({
					Type = "Destroy",
					UID = p1
				})
			end

			if v3 or (not v6.AcceptClientChanges or p2) then
				return
			end

			Remotes.AcceptClientChanges:Fire({
				Type = "Destroy",
				UID = p1
			})
		end
	end

	v5.Attached:Connect(function(p1, p2) --[[ Line: 215 | Upvalues: t6 (copy), t7 (copy), v2 (copy), t4 (copy) ]]
		local v1 = t6[p1]

		if v1 then
			t6[p1] = nil

			for v22, v3 in v1 do
				t7[v3.UID] = nil

				if not v2.Components[v3.UID] then
					local v4 = t4[v3.Name]

					if v4 then
						v4._AddFromReplication(v3.UID, p2, v3.Properties)
					end
				end
			end
		end

		for k, v in pairs(v2.Components) do
			if v.EntityId == p1 and v.Entity == nil then
				v:_Attach(p2)
			end
		end
	end)
	v5.Detached:Connect(function(p1, p2) --[[ Line: 237 | Upvalues: v2 (copy) ]]
		for k, v in pairs(v2.Components) do
			if v.Entity == p2 then
				v:_Detach()
			end
		end
	end)

	if v3 then
		Players.PlayerRemoving:Connect(function(p1) --[[ Line: 246 | Upvalues: t5 (copy) ]]
			t5[p1] = nil
		end)
		Remotes.ClientUECSReady:On(function(p1) --[[ Line: 250 | Upvalues: v1 (ref), t5 (copy), v2 (copy), t4 (copy), Remotes (ref) ]]
			v1:Fire(p1)

			if t5[p1] then
				return
			end

			for k, v in pairs(v2.Components) do
				local v12 = t4[v.Name]

				if v12 and v12.ReplicateToClient then
					local t = {}

					for k2 in pairs(v12.DefaultProperties) do
						t[k2] = v[k2].Value
					end

					Remotes.ReplicateToClient:Fire(p1, {
						Type = "Create",
						Name = v12.Name,
						UID = k,
						EntityId = v.EntityId,
						Properties = t
					})
				end
			end

			t5[p1] = true
		end)
		Remotes.AcceptClientChanges:On(function(p1, p2) --[[ Line: 274 | Upvalues: v4 (ref), v2 (copy), t4 (copy), v5 (copy) ]]
			v4 = p1

			local ok, result = pcall(function() --[[ Line: 276 | Upvalues: p2 (copy), v2 (ref), t4 (ref), v5 (ref) ]]
				if p2.Type == "Create" then
					if v2.Components[p2.UID] then
						return
					end

					local v1 = t4[p2.Name]

					if not (v1 and v1.AcceptClientChanges) then
						return
					end

					local v22 = v5:Get(p2.EntityId)

					if v22 then
						v1._AddFromReplication(p2.UID, v22, p2.Properties)
					end
				elseif p2.Type == "PropertyChange" then
					local v3 = v2.Components[p2.UID]

					if not v3 then
						return
					end

					local v4 = t4[v3.Name]

					if v4 and (v4.AcceptClientChanges and v3[p2.PropertyName]) then
						v3[p2.PropertyName]:Set(p2.Value)
					end
				else
					if p2.Type ~= "Destroy" then
						return
					end

					local v52 = v2.Components[p2.UID]

					if not v52 then
						return
					end

					local v6 = t4[v52.Name]

					if not (v6 and v6.AcceptClientChanges) then
						return
					end

					v52:Destroy()
				end
			end)

			v4 = nil

			if ok then
				return
			end

			warn(result)
		end)
	else
		Remotes.ReplicateToClient:On(function(p1) --[[ Line: 316 | Upvalues: v2 (copy), t4 (copy), v5 (copy), t6 (copy), t7 (copy), dequeuePending (copy) ]]
			if p1.Type == "Create" then
				if v2.Components[p1.UID] then
					return
				end

				local v1 = t4[p1.Name]

				if not v1 then
					return
				end

				local v22 = v5:Get(p1.EntityId)

				if v22 then
					v1._AddFromReplication(p1.UID, v22, p1.Properties)

					return
				end

				local v3 = t6[p1.EntityId]

				if not v3 then
					v3 = {}
					t6[p1.EntityId] = v3
				end

				table.insert(v3, p1)
				t7[p1.UID] = p1
			elseif p1.Type == "PropertyChange" then
				local v4 = v2.Components[p1.UID]

				if v4 and v4[p1.PropertyName] then
					v4._SuppressClientFire = true
					v4[p1.PropertyName]:Set(p1.Value)
					v4._SuppressClientFire = nil

					return
				end

				local v52 = t7[p1.UID]

				if v52 then
					v52.Properties[p1.PropertyName] = p1.Value
				end
			else
				if p1.Type ~= "Destroy" then
					return
				end

				local v6 = v2.Components[p1.UID]

				if v6 then
					v6:_DestroyFromReplication()

					return
				end

				local v7 = t7[p1.UID]

				if not v7 then
					return
				end

				dequeuePending(v7)
			end
		end)
	end

	return v2
end
function t.TagToComponent(p1, p2) --[[ TagToComponent | Line: 365 | Upvalues: CollectionService (copy) ]]
	for v1, v2 in CollectionService:GetTagged(p2) do
		require(script.Parent.Components[p2]).Add(v2)
	end
end
function t.GetEntitiesOfComponent(p1, p2) --[[ GetEntitiesOfComponent | Line: 373 ]]
	local t = {}

	if not p1.ComponentCategorizedByNames[p2] then
		return {}
	end

	for v1, v2 in p1.ComponentCategorizedByNames[p2] do
		table.insert(t, v2.Entity)
	end

	return t
end
function t.OnPlayerAdded(p1, p2) --[[ OnPlayerAdded | Line: 384 | Upvalues: Players (copy) ]]
	table.insert(p1._PlayerAddedCallbacks, p2)

	if not p1._SystemsInitialized then
		return
	end

	for v1, v2 in Players:GetPlayers() do
		task.spawn(p2, v2)
	end
end
function t.OnPlayerRemoving(p1, p2) --[[ OnPlayerRemoving | Line: 393 ]]
	table.insert(p1._PlayerRemovingCallbacks, p2)
end
function t.InitSystems(p1, p2) --[[ InitSystems | Line: 397 | Upvalues: Players (copy) ]]
	local t = {}

	for v1, v2 in p2:GetChildren() do
		local v3 = require(v2)

		v3.UECS = p1
		table.insert(t, {
			Module = v2,
			System = v3,
			Priority = v3.Priority or 100
		})
	end

	table.sort(t, function(p1, p2) --[[ Line: 413 ]]
		if p1.Priority == p2.Priority then
			return p1.Module.Name < p2.Module.Name
		end

		return p1.Priority < p2.Priority
	end)

	for v4, v5 in t do
		local System = v5.System
		local _ = v5.Module.Name

		task.spawn(function() --[[ Line: 422 | Upvalues: System (copy) ]]
			System:Init()
		end)
	end

	Players.PlayerAdded:Connect(function(p12) --[[ Line: 427 | Upvalues: p1 (copy) ]]
		for v1, v2 in p1._PlayerAddedCallbacks do
			task.spawn(v2, p12)
		end
	end)
	Players.PlayerRemoving:Connect(function(p12) --[[ Line: 432 | Upvalues: p1 (copy) ]]
		for v1, v2 in p1._PlayerRemovingCallbacks do
			task.spawn(v2, p12)
		end
	end)

	for v6, v7 in Players:GetPlayers() do
		for v8, v9 in p1._PlayerAddedCallbacks do
			task.spawn(v9, v7)
		end
	end

	p1._SystemsInitialized = true
end
function t.GetComponent(p1, p2, p3) --[[ GetComponent | Line: 447 ]]
	for v2, v3 in p1.ComponentCategorizedByNames[p3] or {} do
		if v3.Entity == p2 then
			return v3
		end
	end

	return nil
end
function t.GetComponents(p1, p2) --[[ GetComponents | Line: 456 ]]
	return p1.ComponentCategorizedByNames[p2] or {}
end

local function WaitForMatch(p1, p2, p3, p4) --[[ WaitForMatch | Line: 460 | Upvalues: t (copy) ]]
	local v1 = p1.ComponentCategorizedByNames[p2]

	if v1 then
		for v2, v3 in v1 do
			if p3 == nil or p3(v3) then
				return v3
			end
		end
	end

	local v4 = coroutine.running()
	local v5 = false
	local v6 = nil

	v6 = t.OnComponentCreated(p2):Connect(function(p1) --[[ Line: 474 | Upvalues: v5 (ref), p3 (copy), v6 (ref), v4 (copy) ]]
		if v5 then
			return
		end

		if p3 and not p3(p1) then
			return
		end

		v5 = true
		v6:Disconnect()
		task.spawn(v4, p1)
	end)

	if not p4 then
		return coroutine.yield()
	end

	task.delay(p4, function() --[[ Line: 487 | Upvalues: v5 (ref), v6 (ref), v4 (copy) ]]
		if not v5 then
			v5 = true
			v6:Disconnect()
			task.spawn(v4, nil)
		end
	end)

	return coroutine.yield()
end

function t.WaitForComponent(p1, p2, p3, p4) --[[ WaitForComponent | Line: 500 | Upvalues: WaitForMatch (copy) ]]
	return WaitForMatch(p1, p3, function(p1) --[[ Line: 501 | Upvalues: p2 (copy) ]]
		return p1.Entity == p2
	end, p4)
end
function t.WaitForAnyComponent(p1, p2, p3) --[[ WaitForAnyComponent | Line: 506 | Upvalues: WaitForMatch (copy) ]]
	return WaitForMatch(p1, p2, nil, p3)
end

return t