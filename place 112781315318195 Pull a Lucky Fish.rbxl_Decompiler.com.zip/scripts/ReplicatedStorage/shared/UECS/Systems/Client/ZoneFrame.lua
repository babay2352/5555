-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local ConvertValue = require(ReplicatedStorage.shared.util.ConvertValue)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Worlds = require(ReplicatedStorage.shared.util.Worlds)
local ZoneFrame = require(ReplicatedStorage.shared.UECS.Components.ZoneFrame)
local isPlayerOnMobile = require(ReplicatedStorage.shared.util.isPlayerOnMobile)

return {
	UECS = nil,
	Priority = 30,
	Init = function(p1) --[[ Init | Line: 20 | Upvalues: Players (copy), isPlayerOnMobile (copy), ZoneFrame (copy), Worlds (copy), ConvertValue (copy), TweenService (copy) ]]
		local ZoneFrame2 = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI").Throwing.ZoneFrame
		local ClipFrame = ZoneFrame2:WaitForChild("ClipFrame")
		local Bar = ClipFrame:WaitForChild("Bar")

		if isPlayerOnMobile() then
			ZoneFrame2.Size = UDim2.new(0.25, 0, 0.08, 0)

			local UISizeConstraint = ZoneFrame2:FindFirstChildOfClass("UISizeConstraint")

			if UISizeConstraint then
				UISizeConstraint.MinSize = Vector2.new(0, 0)
			end
		else
			ZoneFrame2.Size = UDim2.new(0.4, 0, 0.06, 0)
		end

		local v1 = ZoneFrame.Add(ZoneFrame2)

		v1.Visible.OnChange:Connect(function(p1) --[[ Line: 39 | Upvalues: ZoneFrame2 (copy) ]]
			ZoneFrame2.Visible = p1
		end)
		ZoneFrame2.UserProgress.AnchorPoint = Vector2.new(0.5, 0.5)

		local Y = Bar.Size.Y
		local Y2 = Bar.Position.Y

		Bar.AnchorPoint = Vector2.new(0, 0)
		Bar.BackgroundTransparency = 1

		local t = {}
		local v2 = 1

		local function buildBar() --[[ buildBar | Line: 57 | Upvalues: Bar (copy), t (copy), Worlds (ref), v2 (ref), Y (copy), ConvertValue (ref) ]]
			for v1, v22 in Bar:GetChildren() do
				if v22.Name == "ZonePanel" then
					v22:Destroy()
				end
			end

			table.clear(t)

			local v3 = Worlds.GetLocalBiomes()
			local sum = 0

			for v4, v5 in v3 do
				sum = sum + v5.Length
			end

			v2 = sum / 600
			Bar.Size = UDim2.new(v2, 0, Y.Scale, Y.Offset)

			local v6 = #v3
			local sum2 = 0
			local sum3 = 0

			for i = 1, v6 do
				local v7 = v3[i]

				sum2 = sum2 + v7.Length
				sum3 = sum3 + v7.StrengthToReachEnd

				local ZonePanel = Bar.Template:Clone()

				ZonePanel.Name = "ZonePanel"
				ZonePanel.LayoutOrder = i
				ZonePanel.Parent = Bar
				ZonePanel.ZoneName.Text = v7.DisplayName
				ZonePanel.UIGradient.Color = v7.DisplayColor
				ZonePanel.AnchorPoint = Vector2.new(0, 0)
				ZonePanel.Position = UDim2.new(0, 0, 0, 0)
				ZonePanel.Size = UDim2.new(v7.Length / sum, 0, 1, 0)
				ZonePanel.Visible = true
				ZonePanel.ZoneName.Position = UDim2.new(0, 0, 0, 0)
				ZonePanel.ZoneName.Size = UDim2.new(1, 0, 1, 0)

				local MilestoneBadge = ZonePanel:FindFirstChild("MilestoneBadge")

				if MilestoneBadge then
					if i < v6 then
						MilestoneBadge.Visible = true

						local Label = MilestoneBadge:FindFirstChild("Label")

						if Label then
							Label.Text = ConvertValue.suffixformat(sum3)
						end

						table.insert(t, {
							HasBeenHit = false,
							Badge = MilestoneBadge,
							OriginalSize = MilestoneBadge.Size,
							EndProgress = sum2,
							BiomeLength = v7.Length
						})

						continue
					end

					MilestoneBadge:Destroy()
				end
			end
		end

		local Luck = ZoneFrame2.UserProgress:FindFirstChild("Luck")
		local v3, v4, _

		if Luck then
			Luck.Visible = false
		end

		v3 = function(p1) --[[ updateUI | Line: 131 | Upvalues: v2 (ref), Bar (copy), Y2 (copy), ZoneFrame2 (copy), ClipFrame (copy), t (copy), TweenService (ref) ]]
			local v22 = math.clamp(0.5 - p1 / 600, 1 - v2, 0)

			Bar.Position = UDim2.new(v22, 0, Y2.Scale, Y2.Offset)
			ZoneFrame2.UserProgress.Position = UDim2.new(p1 / 600 + v22, 0, 0.5, 0)

			local X = ClipFrame.AbsoluteSize.X

			for v3, v4 in t do
				if v4.EndProgress <= p1 then
					if not v4.HasBeenHit then
						v4.HasBeenHit = true
						TweenService:Create(v4.Badge, TweenInfo.new(0.2, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
							Size = UDim2.fromOffset(0, 0)
						}):Play()
						task.delay(0.2, function() --[[ Line: 150 | Upvalues: v4 (copy) ]]
							if not v4.HasBeenHit then
								return
							end

							v4.Badge.Visible = false
						end)
					end

					continue
				end

				if v4.HasBeenHit then
					v4.HasBeenHit = false
					v4.Badge.Size = v4.OriginalSize
				end

				local v5 = (v22 + v4.EndProgress / 600) * X
				local v7 = v4.OriginalSize.X.Scale * (v4.BiomeLength / 600 * X) + v4.OriginalSize.X.Offset

				if v5 - v7 / 2 >= 0 and v5 + v7 / 2 <= X then
					v4.Badge.Visible = true

					continue
				end

				v4.Badge.Visible = false
			end
		end
		buildBar()
		v1.UserProgress.OnChange:Connect(v3)
		v3(v1.UserProgress.Value)
		Worlds.OnLocalWorldChanged(function() --[[ Line: 189 | Upvalues: buildBar (copy), v3 (copy), v1 (copy) ]]
			buildBar()
			v3(v1.UserProgress.Value)
		end)
		v4, _ = Players:GetUserThumbnailAsync(Players.LocalPlayer.UserId, Enum.ThumbnailType.HeadShot, Enum.ThumbnailSize.Size420x420)
		ZoneFrame2.UserProgress.Image = v4
	end
}