-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ContextActionService = game:GetService("ContextActionService")
local Debris = game:GetService("Debris")

game:GetService("GuiService")

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")

game:GetService("UserInputService")

local CashFormat = require(ReplicatedStorage.shared.util.CashFormat)
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local DailyLoginConfig = require(ReplicatedStorage.shared.config.DailyLoginConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local topbarplus = require(ReplicatedStorage.client.Satchel.Package.topbarplus)
local Maid = require(ReplicatedStorage.shared.class.Maid)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local SFX = require(ReplicatedStorage.client.SFX)

require(ReplicatedStorage.shared.config.versionConfig)

local LocalPlayer = Players.LocalPlayer
local v1 = Color3.fromRGB(0, 0, 0)
local v2 = Color3.fromRGB(80, 220, 100)

Color3.fromRGB(255, 210, 60)

local v3 = Color3.fromRGB(80, 220, 100)
local v4 = Color3.fromRGB(100, 255, 130)

local function darkenColor(p1, p2) --[[ darkenColor | Line: 60 ]]
	return Color3.new(p1.R * p2, p1.G * p2, p1.B * p2)
end

local t = {}
local t2 = {}
local t3 = {
	UECS = nil,
	Priority = 45
}

for i = 1, 7 do
	local rarityColor = DailyLoginConfig.Rewards[i].Rarity.rarityColor

	t[i] = rarityColor
	t2[i] = Color3.new(rarityColor.R * 0.25, rarityColor.G * 0.25, rarityColor.B * 0.25)
end

local function addCorner(p1, p2) --[[ addCorner | Line: 77 ]]
	local UICorner = Instance.new("UICorner")

	UICorner.CornerRadius = UDim.new(0, p2)
	UICorner.Parent = p1
end

local function buildCards(p1) --[[ buildCards | Line: 87 | Upvalues: DailyLoginConfig (copy), t2 (copy), t (copy) ]]
	local v1 = p1:WaitForChild("Content")
	local Cards = v1:WaitForChild("Cards")
	local CardTemplate = Cards:WaitForChild("CardTemplate")
	local t3 = {}

	for i = 1, 6 do
		local v2 = DailyLoginConfig.Rewards[i]
		local v3 = CardTemplate:Clone()

		v3.Name = ("Day%*"):format(i)
		v3.LayoutOrder = i
		v3.Visible = true
		v3.BackgroundColor3 = t2[i]
		v3.BackgroundTransparency = 0
		v3.Parent = Cards

		local DayLabel = v3:FindFirstChild("DayLabel")

		if DayLabel then
			DayLabel.Text = ("Day %*"):format(i)
			DayLabel.TextColor3 = t[i]
		end

		local Icon = v3:FindFirstChild("Icon")

		if Icon then
			Icon.Image = v2.Icon
		end

		local RewardName = v3:FindFirstChild("RewardName")

		if RewardName then
			RewardName.Visible = false
		end

		local RewardAmount = v3:FindFirstChild("RewardAmount")

		if RewardAmount and (v2.GemAmount and v2.GemAmount > 1) then
			RewardAmount.Text = ("x%*"):format(v2.GemAmount)
			RewardAmount.Visible = true
		elseif RewardAmount then
			RewardAmount.Visible = false
		end

		local ClaimBtn = v3:FindFirstChild("ClaimBtn")

		if ClaimBtn then
			ClaimBtn.Visible = false
		end

		table.insert(t3, v3)
	end

	local v4 = DailyLoginConfig.Rewards[7]
	local Day7Icon = v1:FindFirstChild("Day7Icon")

	if Day7Icon then
		Day7Icon.Image = v4.Icon
	end

	local Day7 = v1:FindFirstChild("Day7")

	if Day7 then
		Day7.TextColor3 = t[7]
	end

	local Day7RewardName = v1:FindFirstChild("Day7RewardName")
	local v5

	if not Day7RewardName then
		v5 = {
			_IsDay7 = true,
			_Check = v1:FindFirstChild("Day7Check"),
			_Lock = v1:FindFirstChild("Day7Lock")
		}
		table.insert(t3, v5)

		return t3
	end

	Day7RewardName.Text = v4.DisplayName
	Day7RewardName.TextColor3 = t[7]
	v5 = {
		_IsDay7 = true,
		_Check = v1:FindFirstChild("Day7Check"),
		_Lock = v1:FindFirstChild("Day7Lock")
	}
	table.insert(t3, v5)

	return t3
end

local FishConfig = require(ReplicatedStorage.shared.config.FishConfig)
local luckyblockDropOdds = require(ReplicatedStorage.shared.util.luckyblockDropOdds)

local function buildDropPool(p1) --[[ buildDropPool | Line: 196 | Upvalues: luckyblockDropOdds (copy), FishConfig (copy) ]]
	local t = {}

	for v1, v2 in luckyblockDropOdds(p1) do
		local v3 = FishConfig[v2.name]
		local t2 = {
			name = v2.name,
			image = v2.image,
			chance = v2.chance
		}

		t2.earnings = if v3 then v3.Earnings else 0
		t2.displayName = v2.displayName
		table.insert(t, t2)
	end

	return t
end

local function startDay7Reel(p1) --[[ startDay7Reel | Line: 213 | Upvalues: DailyLoginConfig (copy), buildDropPool (copy), Maid (copy), TweenService (copy), CashFormat (copy) ]]
	local v1 = DailyLoginConfig.Rewards[7]

	if not v1.LuckyblockConfigName then
		return
	end

	local v2 = buildDropPool(v1.LuckyblockConfigName)

	if #v2 == 0 then
		return
	end

	local Day7Icon = p1:FindFirstChild("Day7Icon")

	if not Day7Icon then
		return
	end

	local t = {}
	local v3 = Maid.new()

	v3:GiveTask(function() --[[ Line: 234 | Upvalues: t (copy) ]]
		print("cancel", #t)

		for v1, v2 in t do
			v2:Cancel()
			v2:Destroy()
		end
	end)

	local v4 = TweenService:Create(Day7Icon, TweenInfo.new(1.08, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true), {
		Rotation = 4
	})

	Day7Icon.Rotation = -4
	v4:Play()
	table.insert(t, v4)

	local Day7Shine = p1:FindFirstChild("Day7Shine")

	if Day7Shine then
		v3:GiveTask(task.spawn(function() --[[ Line: 255 | Upvalues: Day7Shine (copy), TweenService (ref), t (copy) ]]
			while true do
				local v1

				repeat
					Day7Shine.Rotation = 0

					local v2 = TweenService:Create(Day7Shine, TweenInfo.new(12, Enum.EasingStyle.Linear), {
						Rotation = Day7Shine.Rotation + 360
					})

					table.insert(t, v2)
					v2:Play()
					v2.Completed:Wait()
					v1 = table.find(t, v2)
				until v1

				table.remove(t, v1)
			end
		end))
	end

	local Day7DropReel = Instance.new("Frame")

	Day7DropReel.Name = "Day7DropReel"
	Day7DropReel.BackgroundTransparency = 1
	Day7DropReel.Position = UDim2.new(Day7Icon.Position.X.Scale, 0, Day7Icon.Position.Y.Scale + 0.15, 0)
	Day7DropReel.Size = UDim2.fromScale(Day7Icon.Size.X.Scale * 0.51, Day7Icon.Size.Y.Scale)
	Day7DropReel.AnchorPoint = Day7Icon.AnchorPoint
	Day7DropReel.ClipsDescendants = false
	Day7DropReel.ZIndex = Day7Icon.ZIndex + 1
	Day7DropReel.Parent = p1

	local v5 = 0

	local function playTweens(p1) --[[ playTweens | Line: 289 | Upvalues: t (copy) ]]
		for v1, v2 in p1 do
			v2:Play()
			table.insert(t, v2)
		end
	end

	v3:GiveTask(task.spawn(function() --[[ Line: 296 | Upvalues: t (copy), v5 (ref), v2 (copy), Day7Icon (copy), Day7DropReel (copy), Day7Shine (copy), CashFormat (ref), TweenService (ref) ]]
		local ItemShine

		repeat
			for v1, v22 in t do
				if v22.PlaybackState == Enum.PlaybackState.Completed then
					v22:Destroy()
					table.remove(t, v1)
				end
			end

			v5 = v5 % #v2 + 1

			local v3 = v2[v5]
			local ReelItem = Instance.new("Frame")

			ReelItem.Name = "ReelItem"
			ReelItem.BackgroundTransparency = 1
			ReelItem.Size = UDim2.fromScale(0.3, 0.8)
			ReelItem.Position = UDim2.fromScale(-0.3, 0.1)
			ReelItem.ZIndex = Day7Icon.ZIndex + 2
			ReelItem.Parent = Day7DropReel

			if Day7Shine then
				ItemShine = Day7Shine:Clone()
				ItemShine.Name = "ItemShine"
				ItemShine.Position = UDim2.fromScale(0.5, 0.5)
				ItemShine.AnchorPoint = Vector2.new(0.5, 0.5)
				ItemShine.Size = UDim2.fromScale(1.2, 1.2)
				ItemShine.ImageTransparency = 1
				ItemShine.ZIndex = Day7Icon.ZIndex + 1
				ItemShine.Parent = ReelItem
			else
				ItemShine = nil
			end

			local Chance = Instance.new("TextLabel")

			Chance.Name = "Chance"
			Chance.BackgroundTransparency = 1
			Chance.Size = UDim2.fromScale(1, 0.14)
			Chance.Position = UDim2.fromScale(0.5, 0.3)
			Chance.AnchorPoint = Vector2.new(0.5, 0)
			Chance.Font = Enum.Font.GothamBold
			Chance.TextScaled = true
			Chance.Text = string.format("%.1f%%", v3.chance)
			Chance.TextColor3 = Color3.fromRGB(255, 255, 100)
			Chance.TextTransparency = 1
			Chance.ZIndex = Day7Icon.ZIndex + 4
			Chance.Parent = ReelItem

			local UIStroke = Instance.new("UIStroke")

			UIStroke.Thickness = 1.5
			UIStroke.Color = Color3.fromRGB(0, 0, 0)
			UIStroke.Transparency = 1
			UIStroke.Parent = Chance

			local FishIcon = Instance.new("ImageLabel")

			FishIcon.Name = "FishIcon"
			FishIcon.BackgroundTransparency = 1
			FishIcon.Image = v3.image
			FishIcon.Size = UDim2.fromScale(0.7, 0.55)
			FishIcon.Position = UDim2.fromScale(0.5, 0.48)
			FishIcon.AnchorPoint = Vector2.new(0.5, 0.5)
			FishIcon.ScaleType = Enum.ScaleType.Fit
			FishIcon.ImageTransparency = 1
			FishIcon.ZIndex = Day7Icon.ZIndex + 3
			FishIcon.Parent = ReelItem

			local Earnings = Instance.new("Frame")

			Earnings.Name = "Earnings"
			Earnings.BackgroundTransparency = 1
			Earnings.Size = UDim2.fromScale(1, 0.12)
			Earnings.Position = UDim2.fromScale(0.5, 0.68)
			Earnings.AnchorPoint = Vector2.new(0.5, 1)
			Earnings.ZIndex = Day7Icon.ZIndex + 4

			local UIListLayout = Instance.new("UIListLayout")

			UIListLayout.FillDirection = Enum.FillDirection.Horizontal
			UIListLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center
			UIListLayout.VerticalAlignment = Enum.VerticalAlignment.Center
			UIListLayout.Padding = UDim.new(0, 2)
			UIListLayout.Parent = Earnings
			Earnings.Parent = ReelItem

			local v4 = CashFormat.compact(v3.earnings)
			local ImageLabel = Instance.new("ImageLabel")

			ImageLabel.BackgroundTransparency = 1
			ImageLabel.Size = UDim2.fromScale(1, 1)
			ImageLabel.ScaleType = Enum.ScaleType.Fit
			ImageLabel.Image = v4.Icon
			ImageLabel.Visible = if v4.Icon == "" then false else true
			ImageLabel.ImageTransparency = 1
			ImageLabel.ZIndex = Day7Icon.ZIndex + 4

			local UIAspectRatioConstraint = Instance.new("UIAspectRatioConstraint")

			UIAspectRatioConstraint.AspectRatio = 1
			UIAspectRatioConstraint.AspectType = Enum.AspectType.FitWithinMaxSize
			UIAspectRatioConstraint.DominantAxis = Enum.DominantAxis.Height
			UIAspectRatioConstraint.Parent = ImageLabel
			ImageLabel.Parent = Earnings

			local TextLabel = Instance.new("TextLabel")

			TextLabel.BackgroundTransparency = 1
			TextLabel.Size = UDim2.fromScale(0, 1)
			TextLabel.AutomaticSize = Enum.AutomaticSize.X
			TextLabel.Font = Enum.Font.GothamBold
			TextLabel.TextScaled = true
			TextLabel.Text = ("%*/s"):format(v4.Text)
			TextLabel.TextColor3 = Color3.fromRGB(130, 255, 130)
			TextLabel.TextTransparency = 1
			TextLabel.ZIndex = Day7Icon.ZIndex + 4
			TextLabel.Parent = Earnings

			local UIStroke2 = Instance.new("UIStroke")

			UIStroke2.Thickness = 1.5
			UIStroke2.Color = Color3.fromRGB(0, 0, 0)
			UIStroke2.Transparency = 1
			UIStroke2.Parent = TextLabel

			local v6 = TweenService:Create(ReelItem, TweenInfo.new(10, Enum.EasingStyle.Linear), {
				Position = UDim2.fromScale(1, 0.1)
			})

			v6:Play()

			local v7 = t

			table.insert(v7, v6)

			local v8 = 0.9 + (math.random() - 0.5) * 0.4
			local v9 = (math.random() * 2 - 1) * 7

			ReelItem.Rotation = v9

			local v10 = TweenService:Create(ReelItem, TweenInfo.new(v8, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true), {
				Rotation = -v9
			})

			v10:Play()

			local v11 = t

			table.insert(v11, v10)

			for v12, v13 in {
				TweenService:Create(FishIcon, TweenInfo.new(1.5), {
					ImageTransparency = 0
				}),
				TweenService:Create(Chance, TweenInfo.new(1.5), {
					TextTransparency = 0
				}),
				TweenService:Create(UIStroke, TweenInfo.new(1.5), {
					Transparency = 0
				}),
				TweenService:Create(TextLabel, TweenInfo.new(1.5), {
					TextTransparency = 0
				}),
				TweenService:Create(ImageLabel, TweenInfo.new(1.5), {
					ImageTransparency = 0
				}),
				TweenService:Create(UIStroke2, TweenInfo.new(1.5), {
					Transparency = 0
				})
			} do
				v13:Play()
				table.insert(t, v13)
			end

			if ItemShine then
				for v15, v16 in { TweenService:Create(ItemShine, TweenInfo.new(1.5), {
						ImageTransparency = 0.3
					}), TweenService:Create(ItemShine, TweenInfo.new(10, Enum.EasingStyle.Linear), {
						Rotation = ItemShine.Rotation + 360
					}) } do
					v16:Play()
					table.insert(t, v16)
				end
			end

			task.delay(8.5, function() --[[ Line: 458 | Upvalues: TweenService (ref), FishIcon (copy), Chance (copy), UIStroke (copy), TextLabel (copy), ImageLabel (copy), UIStroke2 (copy), t (ref), ItemShine (ref) ]]
				for v1, v2 in {
					TweenService:Create(FishIcon, TweenInfo.new(1.5), {
						ImageTransparency = 1
					}),
					TweenService:Create(Chance, TweenInfo.new(1.5), {
						TextTransparency = 1
					}),
					TweenService:Create(UIStroke, TweenInfo.new(1.5), {
						Transparency = 1
					}),
					TweenService:Create(TextLabel, TweenInfo.new(1.5), {
						TextTransparency = 1
					}),
					TweenService:Create(ImageLabel, TweenInfo.new(1.5), {
						ImageTransparency = 1
					}),
					TweenService:Create(UIStroke2, TweenInfo.new(1.5), {
						Transparency = 1
					})
				} do
					v2:Play()
					table.insert(t, v2)
				end

				if not ItemShine then
					return
				end

				for v4, v5 in { TweenService:Create(ItemShine, TweenInfo.new(1.5), {
						ImageTransparency = 1
					}) } do
					v5:Play()
					table.insert(t, v5)
				end
			end)
			task.delay(10.1, function() --[[ Line: 473 | Upvalues: ReelItem (copy) ]]
				ReelItem:Destroy()
			end)
			task.wait(2.5)
		until not ItemShine
	end))

	return v3
end

local function playClaimVFX(p1, p2, p3) --[[ playClaimVFX | Line: 489 | Upvalues: SFX (copy), t (copy), TweenService (copy), Debris (copy) ]]
	local v1 = p2.AbsolutePosition + p2.AbsoluteSize / 2
	local AbsoluteSize = p2.AbsoluteSize

	SFX.PlaySoundWithRandomPitch(SFX.Sounds.Bell, 0.7, 0.95, 1.05)
	task.delay(0.1, function() --[[ Line: 495 | Upvalues: SFX (ref) ]]
		SFX.PlaySoundWithRandomPitch(SFX.Sounds.Luck, 1, 0.9, 1.1)
	end)
	task.delay(0.3, function() --[[ Line: 498 | Upvalues: SFX (ref) ]]
		SFX.PlaySoundWithRandomPitch(SFX.Sounds.Collect, 0.8, 0.95, 1.1)
	end)
	task.delay(0.5, function() --[[ Line: 501 | Upvalues: SFX (ref) ]]
		SFX.PlaySoundWithRandomPitch(SFX.Sounds.Fireworks, 0.5, 0.9, 1.1)
	end)

	local Frame = Instance.new("Frame")

	Frame.Size = UDim2.fromOffset(AbsoluteSize.X * 2.5, AbsoluteSize.Y * 2.5)
	Frame.Position = UDim2.fromOffset(v1.X, v1.Y)
	Frame.AnchorPoint = Vector2.new(0.5, 0.5)
	Frame.BackgroundColor3 = t[p3] or Color3.fromRGB(255, 200, 50)
	Frame.BackgroundTransparency = 0.5
	Frame.BorderSizePixel = 0
	Frame.ZIndex = 100080
	Frame.Parent = p1

	local UICorner = Instance.new("UICorner")

	UICorner.CornerRadius = UDim.new(0, 999)
	UICorner.Parent = Frame
	TweenService:Create(Frame, TweenInfo.new(0.6, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
		BackgroundTransparency = 1,
		Size = UDim2.fromOffset(AbsoluteSize.X * 4, AbsoluteSize.Y * 4)
	}):Play()
	Debris:AddItem(Frame, 0.7)

	local Icon = p2:FindFirstChild("Icon")

	if not Icon and p2:IsA("ImageLabel") then
		Icon = p2
	end

	if Icon then
		local Size = Icon.Size
		local v3 = UDim2.new(Size.X.Scale * 1.3, Size.X.Offset * 1.3, Size.Y.Scale * 1.3, Size.Y.Offset * 1.3)

		TweenService:Create(Icon, TweenInfo.new(0.15, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
			Size = v3
		}):Play()
		task.delay(0.15, function() --[[ Line: 541 | Upvalues: TweenService (ref), Icon (ref), Size (copy) ]]
			TweenService:Create(Icon, TweenInfo.new(0.4, Enum.EasingStyle.Elastic, Enum.EasingDirection.Out), {
				Size = Size
			}):Play()
		end)
	end

	local Frame2 = Instance.new("Frame")

	Frame2.Size = UDim2.fromScale(1, 1)
	Frame2.BackgroundColor3 = Color3.fromRGB(255, 230, 150)
	Frame2.BackgroundTransparency = 0.4
	Frame2.BorderSizePixel = 0
	Frame2.ZIndex = 100100
	Frame2.Parent = p1
	TweenService:Create(Frame2, TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
		BackgroundTransparency = 1
	}):Play()
	Debris:AddItem(Frame2, 0.4)

	for i = 1, 8 do
		local Frame3 = Instance.new("Frame")

		Frame3.Size = UDim2.fromOffset(3, 0)
		Frame3.Position = UDim2.fromOffset(v1.X, v1.Y)
		Frame3.AnchorPoint = Vector2.new(0.5, 1)
		Frame3.Rotation = i / 8 * 360
		Frame3.BackgroundColor3 = Color3.fromRGB(255, 230, 120)
		Frame3.BackgroundTransparency = 0.2
		Frame3.BorderSizePixel = 0
		Frame3.ZIndex = 100085
		Frame3.Parent = p1
		TweenService:Create(Frame3, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			BackgroundTransparency = 1,
			Size = UDim2.fromOffset(2, 120 + math.random() * 60)
		}):Play()
		Debris:AddItem(Frame3, 0.6)
	end

	for j = 1, 18 do
		local Frame3 = Instance.new("Frame")
		local v4 = 4 + math.random() * 6
		local v5 = v1.X + (math.random() * 2 - 1) * AbsoluteSize.X * 1.5
		local v6 = v1.Y - math.random() * 40 - 20

		Frame3.Size = UDim2.fromOffset(v4, v4 * (0.5 + math.random() * 0.5))
		Frame3.Position = UDim2.fromOffset(v5, v6)
		Frame3.AnchorPoint = Vector2.new(0.5, 0.5)
		Frame3.Rotation = math.random() * 360
		Frame3.BackgroundColor3 = Color3.fromHSV(math.random(), 0.7 + math.random() * 0.3, 0.9 + math.random() * 0.1)
		Frame3.BorderSizePixel = 0
		Frame3.ZIndex = 100092
		Frame3.Parent = p1

		local UICorner2 = Instance.new("UICorner")

		UICorner2.CornerRadius = UDim.new(0, 2)
		UICorner2.Parent = Frame3

		local v7 = (math.random() * 2 - 1) * 50
		local v8 = 0.8 + math.random() * 0.6

		task.delay(math.random() * 0.3, function() --[[ Line: 601 | Upvalues: TweenService (ref), Frame3 (copy), v8 (copy), v5 (copy), v7 (copy), v6 (copy) ]]
			TweenService:Create(Frame3, TweenInfo.new(v8, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
				BackgroundTransparency = 1,
				Position = UDim2.fromOffset(v5 + v7, v6 + 200 + math.random() * 100),
				Rotation = Frame3.Rotation + (math.random() * 2 - 1) * 180
			}):Play()
		end)
		Debris:AddItem(Frame3, 1.5)
	end

	for k = 1, 16 do
		local Frame3 = Instance.new("Frame")

		Frame3.Size = UDim2.fromOffset(6, 6)
		Frame3.Position = UDim2.fromOffset(v1.X, v1.Y)
		Frame3.AnchorPoint = Vector2.new(0.5, 0.5)
		Frame3.BackgroundColor3 = Color3.fromHSV(0.1 + math.random() * 0.1, 0.6 + math.random() * 0.4, 1)
		Frame3.BorderSizePixel = 0
		Frame3.ZIndex = 100091
		Frame3.Parent = p1

		local UICorner2 = Instance.new("UICorner")

		UICorner2.CornerRadius = UDim.new(0, 3)
		UICorner2.Parent = Frame3

		local v9 = k / 16 * math.pi * 2 + math.random() * 0.3
		local v10 = 60 + math.random() * 100
		local v11 = v1.X + math.cos(v9) * v10
		local v12 = v1.Y + math.sin(v9) * v10

		TweenService:Create(Frame3, TweenInfo.new(0.6, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			BackgroundTransparency = 1,
			Position = UDim2.fromOffset(v11, v12),
			Size = UDim2.fromOffset(2, 2)
		}):Play()
		Debris:AddItem(Frame3, 0.7)
	end

	local Frame3 = Instance.new("Frame")

	Frame3.Size = UDim2.fromOffset(AbsoluteSize.X * 0.3, AbsoluteSize.Y)
	Frame3.Position = UDim2.fromOffset(p2.AbsolutePosition.X - AbsoluteSize.X * 0.3, p2.AbsolutePosition.Y)
	Frame3.BackgroundColor3 = Color3.new(255/255, 255/255, 255/255)
	Frame3.BackgroundTransparency = 0.7
	Frame3.Rotation = 15
	Frame3.BorderSizePixel = 0
	Frame3.ZIndex = 100096
	Frame3.Parent = p1
	TweenService:Create(Frame3, TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
		BackgroundTransparency = 1,
		Position = UDim2.fromOffset(p2.AbsolutePosition.X + AbsoluteSize.X * 1.3, p2.AbsolutePosition.Y)
	}):Play()
	Debris:AddItem(Frame3, 0.5)

	local Icon2 = p2:FindFirstChild("Icon")

	if not Icon2 and p2:IsA("ImageLabel") then
		Icon2 = p2
	end

	if not Icon2 then
		return
	end

	local v13 = Icon2:Clone()

	v13.ZIndex = 100095
	v13.Parent = p1
	v13.Size = UDim2.fromOffset(Icon2.AbsoluteSize.X, Icon2.AbsoluteSize.Y)
	v13.Position = UDim2.fromOffset(Icon2.AbsolutePosition.X + Icon2.AbsoluteSize.X / 2, Icon2.AbsolutePosition.Y + Icon2.AbsoluteSize.Y / 2)
	v13.AnchorPoint = Vector2.new(0.5, 0.5)
	TweenService:Create(v13, TweenInfo.new(0.3, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
		Rotation = 15,
		Size = UDim2.fromOffset(Icon2.AbsoluteSize.X * 1.8, Icon2.AbsoluteSize.Y * 1.8)
	}):Play()
	task.delay(0.4, function() --[[ Line: 679 | Upvalues: TweenService (ref), v13 (copy) ]]
		TweenService:Create(v13, TweenInfo.new(0.6, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
			ImageTransparency = 0.9,
			Rotation = -30,
			Position = UDim2.new(0.5, 0, 0, -60),
			Size = UDim2.fromOffset(20, 20)
		}):Play()
	end)
	Debris:AddItem(v13, 1.1)
end

local function refreshCards(p1, p2, p3, p4, p5, p6, p7) --[[ refreshCards | Line: 734 | Upvalues: t2 (copy), v2 (copy), t (copy), v1 (copy), v3 (copy), TweenService (copy) ]]
	for i = 1, 7 do
		local v12, v22
		local v32 = p1[i]
		local v4 = if i == 7 then true else false
		local v5 = nil

		if v4 then
			v12 = v32._Check
			v22 = v32._Lock
		else
			local Check = v32:FindFirstChild("Check")
			local Lock = v32:FindFirstChild("Lock")
			local CardStroke = v32:FindFirstChild("CardStroke")

			v12 = Check
			v22 = Lock
			v5 = CardStroke
		end

		if i < p2 then
			if not v4 then
				v32.BackgroundColor3 = t2[i]
				v32.BackgroundTransparency = 0
			end

			if v12 then
				v12.Visible = true
			end

			if v22 then
				v22.Visible = false
			end

			if v5 then
				v5.Color = v2
			end

			continue
		end

		if i == p2 then
			if not v4 then
				local v6 = t[i]

				v32.BackgroundColor3 = Color3.new(v6.R * 0.4, v6.G * 0.4, v6.B * 0.4)
				v32.BackgroundTransparency = 0
			end

			if v12 then
				v12.Visible = false
			end

			if v22 then
				v22.Visible = not p3
			end

			if v5 then
				v5.Color = v1
			end

			continue
		end

		if not v4 then
			local v7 = t2[i]

			v32.BackgroundColor3 = Color3.new(v7.R * 0.5, v7.G * 0.5, v7.B * 0.5)
			v32.BackgroundTransparency = 0.3
		end

		if v12 then
			v12.Visible = false
		end

		if v22 then
			v22.Visible = true
		end

		if v5 then
			v5.Color = v1
		end
	end

	local v8

	if not p6 then
		v8 = math.max(0, p2 - 1) / 7
		TweenService:Create(p4, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			Size = UDim2.new(v8, 0, 1, 0)
		}):Play()

		return
	end

	if p3 then
		p6.Visible = true
		p6.BackgroundColor3 = v3
		p6.TextTransparency = 0
		p6.AutoButtonColor = true

		if not p7 then
			v8 = math.max(0, p2 - 1) / 7
			TweenService:Create(p4, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				Size = UDim2.new(v8, 0, 1, 0)
			}):Play()

			return
		end

		p7.Visible = false
	else
		p6.Visible = false
	end

	v8 = math.max(0, p2 - 1) / 7
	TweenService:Create(p4, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
		Size = UDim2.new(v8, 0, 1, 0)
	}):Play()
end

function t3.Init(p1) --[[ Init | Line: 837 | Upvalues: ClientPlayerData (copy), LocalPlayer (copy), buildCards (copy), v4 (copy), v3 (copy), DailyLoginConfig (copy), refreshCards (copy), topbarplus (copy), TweenService (copy), Remotes (copy), playClaimVFX (copy), ContextActionService (copy), Players (copy), startDay7Reel (copy) ]]
	repeat
		task.wait()
	until ClientPlayerData.isPlayerDataLoaded

	local PlayerGui = LocalPlayer:WaitForChild("PlayerGui")
	local MainUI = PlayerGui:WaitForChild("MainUI")
	local DailyLoginNew = MainUI:WaitForChild("DailyLoginNew")
	local DailyLoginVFX = Instance.new("ScreenGui")

	DailyLoginVFX.Name = "DailyLoginVFX"
	DailyLoginVFX.IgnoreGuiInset = true
	DailyLoginVFX.ResetOnSpawn = false
	DailyLoginVFX.DisplayOrder = 60
	DailyLoginVFX.Enabled = false
	DailyLoginVFX.Parent = PlayerGui

	local TopBar = DailyLoginNew:WaitForChild("TopBar")
	local CloseButton = TopBar:WaitForChild("CloseButton")
	local StreakLabel = TopBar:WaitForChild("StreakLabel")
	local v1 = DailyLoginNew:WaitForChild("Content")
	local Fill = v1:WaitForChild("ProgressBar"):WaitForChild("Fill")
	local v2 = buildCards(DailyLoginNew)
	local ClaimBtn = v1:WaitForChild("ClaimBtn")
	local NextrewardIn = v1:WaitForChild("NextrewardIn")

	NextrewardIn.Visible = false
	ClaimBtn.MouseEnter:Connect(function() --[[ Line: 871 | Upvalues: ClaimBtn (copy), v4 (ref) ]]
		if not ClaimBtn.AutoButtonColor then
			return
		end

		ClaimBtn.BackgroundColor3 = v4
	end)
	ClaimBtn.MouseLeave:Connect(function() --[[ Line: 876 | Upvalues: ClaimBtn (copy), v3 (ref) ]]
		if not ClaimBtn.AutoButtonColor then
			return
		end

		ClaimBtn.BackgroundColor3 = v3
	end)

	local function formatCountdown(p1) --[[ formatCountdown | Line: 883 ]]
		local v1 = math.floor(p1 / 3600)
		local v2 = math.floor(p1 % 3600 / 60)
		local v3 = p1 % 60
		local t = {}

		if v1 > 0 then
			table.insert(t, (("%*h"):format(v1)))
		end

		if v2 > 0 then
			table.insert(t, (("%*m"):format(v2)))
		end

		if v3 > 0 or #t == 0 then
			table.insert(t, (("%*s"):format(v3)))
		end

		return table.concat(t, " ")
	end

	local v32 = false

	local function updateNextRewardTimer() --[[ updateNextRewardTimer | Line: 902 | Upvalues: v32 (ref), ClientPlayerData (ref), StreakLabel (copy), DailyLoginConfig (ref), refreshCards (ref), v2 (copy), Fill (copy), ClaimBtn (copy), NextrewardIn (copy), formatCountdown (copy) ]]
		if v32 then
			return
		end

		local v1 = ClientPlayerData.serverProfile:getState()
		local dailyLoginLastClaim = v1.dailyLoginLastClaim

		if dailyLoginLastClaim == 0 then
			StreakLabel.Text = ""

			return
		end

		local v3 = DailyLoginConfig.MIN_CLAIM_INTERVAL - (os.time() - dailyLoginLastClaim)

		if not (v3 <= 0) then
			StreakLabel.Text = ("Next: %*"):format((formatCountdown(v3)))

			return
		end

		local v4 = DailyLoginConfig.getClaimInfo(v1)

		StreakLabel.Text = ""
		refreshCards(v2, v1.dailyLoginDay, v4 ~= nil, Fill, StreakLabel, ClaimBtn, NextrewardIn)
	end

	local v42 = nil

	local function startTimerLoop() --[[ startTimerLoop | Line: 934 | Upvalues: v42 (ref), DailyLoginNew (copy), updateNextRewardTimer (copy) ]]
		if not v42 then
			v42 = task.spawn(function() --[[ Line: 938 | Upvalues: DailyLoginNew (ref), updateNextRewardTimer (ref), v42 (ref) ]]
				while DailyLoginNew.Visible do
					updateNextRewardTimer()
					task.wait(1)
				end

				v42 = nil
			end)
		end
	end

	local function stopTimerLoop() --[[ stopTimerLoop | Line: 946 | Upvalues: v42 (ref) ]]
		if not v42 then
			return
		end

		task.cancel(v42)
		v42 = nil
	end

	local v5 = topbarplus.new()

	v5:setName("DailyLogin")
	v5:setRight()
	v5:setImage("rbxassetid://6031075938")
	v5:setCaption("Daily Rewards")

	local v6 = nil

	local function refreshNotice() --[[ refreshNotice | Line: 962 | Upvalues: ClientPlayerData (ref), DailyLoginConfig (ref), v6 (ref), v5 (copy) ]]
		if DailyLoginConfig.getClaimInfo((ClientPlayerData.serverProfile:getState())) then
			if v6 then
				return
			end

			local v2 = v5:getInstance("iconButton")

			if v2 then
				local NoticeBadge = Instance.new("Frame")

				NoticeBadge.Name = "NoticeBadge"
				NoticeBadge.Size = UDim2.fromOffset(12, 12)
				NoticeBadge.Position = UDim2.new(1, -4, 0, -2)
				NoticeBadge.AnchorPoint = Vector2.new(0.5, 0.5)
				NoticeBadge.BackgroundColor3 = Color3.fromRGB(255, 60, 60)
				NoticeBadge.BorderSizePixel = 0
				NoticeBadge.ZIndex = 10
				NoticeBadge.Parent = v2

				local UICorner = Instance.new("UICorner")

				UICorner.CornerRadius = UDim.new(0, 6)
				UICorner.Parent = NoticeBadge

				local TextLabel = Instance.new("TextLabel")

				TextLabel.Size = UDim2.fromScale(1, 1)
				TextLabel.BackgroundTransparency = 1
				TextLabel.Text = "!"
				TextLabel.TextColor3 = Color3.new(255/255, 255/255, 255/255)
				TextLabel.TextScaled = true
				TextLabel.Font = Enum.Font.GothamBold
				TextLabel.Parent = NoticeBadge
				v6 = NoticeBadge
			end
		else
			if not v6 then
				return
			end

			v6:Destroy()
			v6 = nil
		end
	end

	local Size = DailyLoginNew.Size
	local HUD = MainUI:WaitForChild("HUD")
	local Buttons = HUD:FindFirstChild("Buttons")
	local Counters = HUD:FindFirstChild("Counters")
	local v7 = Buttons and Buttons.Position
	local v8 = Counters and Counters.Position
	local v9 = TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	local v10 = TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	local v11 = nil

	local function hideHUD() --[[ hideHUD | Line: 1015 | Upvalues: Buttons (copy), v7 (copy), TweenService (ref), v9 (copy), Counters (copy), v8 (copy) ]]
		if Buttons and v7 then
			TweenService:Create(Buttons, v9, {
				Position = UDim2.new(-0.25, 0, v7.Y.Scale, v7.Y.Offset)
			}):Play()
		end

		if not (Counters and v8) then
			return
		end

		TweenService:Create(Counters, v9, {
			Position = UDim2.new(-0.25, 0, v8.Y.Scale, v8.Y.Offset)
		}):Play()
	end

	local function showHUD() --[[ showHUD | Line: 1029 | Upvalues: Buttons (copy), v7 (copy), TweenService (ref), v10 (copy), Counters (copy), v8 (copy) ]]
		if Buttons and v7 then
			TweenService:Create(Buttons, v10, {
				Position = v7
			}):Play()
		end

		if not (Counters and v8) then
			return
		end

		TweenService:Create(Counters, v10, {
			Position = v8
		}):Play()
	end

	local function claimButtonPress() --[[ claimButtonPress | Line: 1042 | Upvalues: v32 (ref), ClientPlayerData (ref), DailyLoginConfig (ref), Remotes (ref), DailyLoginVFX (copy), v2 (copy), v1 (copy), playClaimVFX (ref), refreshCards (ref), Fill (copy), StreakLabel (copy), ClaimBtn (copy), NextrewardIn (copy), v5 (copy) ]]
		if v32 then
			return
		end

		local v22 = DailyLoginConfig.getClaimInfo((ClientPlayerData.serverProfile:getState()))

		if not v22 then
			return
		end

		v32 = true
		Remotes.RequestClaimDailyLogin:Fire()
		DailyLoginVFX.Enabled = true

		local v3 = v2[v22]

		if v22 == 7 then
			local Day7Icon = v1:FindFirstChild("Day7Icon")

			if Day7Icon then
				v3 = Day7Icon
			end
		end

		playClaimVFX(DailyLoginVFX, v3, v22)
		task.wait(1)

		local v4 = ClientPlayerData.serverProfile:getState()

		refreshCards(v2, v4.dailyLoginDay, DailyLoginConfig.getClaimInfo(v4) ~= nil, Fill, StreakLabel, ClaimBtn, NextrewardIn)
		task.wait(1.5)
		v5:deselect()
		DailyLoginVFX.Enabled = false
		v32 = false
	end

	ClaimBtn.MouseButton1Down:Connect(claimButtonPress)

	local v12 = false

	local function closePanel() --[[ closePanel | Line: 1094 | Upvalues: v12 (ref), DailyLoginNew (copy), showHUD (copy), v42 (ref), ContextActionService (ref), TweenService (ref), Size (copy), v11 (ref), Players (ref) ]]
		if v12 or not DailyLoginNew.Visible then
			return
		end

		v12 = true
		showHUD()

		local v1

		if v42 then
			task.cancel(v42)
			v42 = nil
		end

		ContextActionService:UnbindAction("DailyLoginClaim")
		ContextActionService:UnbindAction("DailyLoginClose")
		v1 = TweenService:Create(DailyLoginNew, TweenInfo.new(0.3, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
			Size = UDim2.fromOffset(0, 0)
		})
		v1:Play()
		v1.Completed:Once(function() --[[ Line: 1110 | Upvalues: DailyLoginNew (ref), Size (ref), v12 (ref), v11 (ref), Players (ref) ]]
			DailyLoginNew.Visible = false
			DailyLoginNew.Size = Size
			v12 = false

			if not v11 then
				Players.LocalPlayer:SetAttribute("DailyLoginFinished", true)

				return
			end

			v11:Destroy()
			Players.LocalPlayer:SetAttribute("DailyLoginFinished", true)
		end)
	end

	local function openPanel() --[[ openPanel | Line: 1123 | Upvalues: ClientPlayerData (ref), DailyLoginConfig (ref), refreshCards (ref), v2 (copy), Fill (copy), StreakLabel (copy), ClaimBtn (copy), NextrewardIn (copy), updateNextRewardTimer (copy), DailyLoginNew (copy), TweenService (ref), Size (copy), hideHUD (copy), v42 (ref), ContextActionService (ref), closePanel (copy), claimButtonPress (copy), v11 (ref), startDay7Reel (ref), v1 (copy) ]]
		local v12 = ClientPlayerData.serverProfile:getState()

		refreshCards(v2, v12.dailyLoginDay, DailyLoginConfig.getClaimInfo(v12) ~= nil, Fill, StreakLabel, ClaimBtn, NextrewardIn)
		updateNextRewardTimer()
		DailyLoginNew.Size = UDim2.fromOffset(0, 0)
		DailyLoginNew.Visible = true
		TweenService:Create(DailyLoginNew, TweenInfo.new(0.4, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
			Size = Size
		}):Play()
		hideHUD()

		if not v42 then
			v42 = task.spawn(function() --[[ Line: 938 | Upvalues: DailyLoginNew (ref), updateNextRewardTimer (ref), v42 (ref) ]]
				while DailyLoginNew.Visible do
					updateNextRewardTimer()
					task.wait(1)
				end

				v42 = nil
			end)
		end

		ContextActionService:BindActionAtPriority("DailyLoginClose", function(p1, p2) --[[ Line: 1141 | Upvalues: closePanel (ref) ]]
			if p2 == Enum.UserInputState.Begin then
				closePanel()

				return Enum.ContextActionResult.Sink
			end

			return Enum.ContextActionResult.Pass
		end, false, 10000, Enum.KeyCode.ButtonB)
		ContextActionService:BindActionAtPriority("DailyLoginClaim", function(p1, p2) --[[ Line: 1156 | Upvalues: claimButtonPress (ref) ]]
			if p2 == Enum.UserInputState.Begin then
				claimButtonPress()

				return Enum.ContextActionResult.Sink
			end

			return Enum.ContextActionResult.Pass
		end, false, 10000, Enum.KeyCode.ButtonA)
		v11 = startDay7Reel(v1)
	end

	v5:bindEvent("selected", function() --[[ Line: 1173 | Upvalues: v6 (ref), openPanel (copy) ]]
		if not v6 then
			openPanel()

			return
		end

		v6:Destroy()
		v6 = nil
		openPanel()
	end)
	v5:bindEvent("deselected", function() --[[ Line: 1180 | Upvalues: closePanel (copy) ]]
		closePanel()
	end)
	CloseButton.MouseButton1Down:Connect(function() --[[ Line: 1185 | Upvalues: v5 (copy) ]]
		v5:deselect()
	end)
	refreshNotice()
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 1193 ]]
		return p1.dailyLoginLastClaim
	end, function() --[[ Line: 1195 | Upvalues: refreshNotice (copy) ]]
		refreshNotice()
	end)

	local v13 = false

	local function showDailyRewards() --[[ showDailyRewards | Line: 1201 | Upvalues: v13 (ref), ClientPlayerData (ref), DailyLoginConfig (ref), Players (ref), v5 (copy) ]]
		if v13 then
			return
		end

		if DailyLoginConfig.getClaimInfo((ClientPlayerData.serverProfile:getState())) then
			v13 = true
			task.delay(0.4, function() --[[ Line: 1217 | Upvalues: v5 (ref) ]]
				v5:select()
			end)
		else
			Players.LocalPlayer:SetAttribute("DailyLoginFinished", true)
		end
	end

	local v14 = ClientPlayerData.serverProfile:getState()
	local v15 = v14.tutorialInfo.tutorialStep > 9

	if if v14.tutorialInfo.tutorialStep == 1 then v14.stats.fishCaught == 0 else false then
		local v17 = nil

		v17 = ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 1231 ]]
			return p1.tutorialInfo.tutorialStep
		end, function(p1) --[[ Line: 1233 | Upvalues: v17 (ref), showDailyRewards (copy) ]]
			if not (p1 > 9) then
				return
			end

			if v17 then
				v17()
			end

			task.wait(4)
			showDailyRewards()
		end)
	elseif v15 then
		local function checkOfflineFinished() --[[ checkOfflineFinished | Line: 1245 | Upvalues: Players (ref), showDailyRewards (copy) ]]
			if Players.LocalPlayer:GetAttribute("OfflineEarningsFinished") == true then
				showDailyRewards()

				return true
			end

			return false
		end

		local v18

		if Players.LocalPlayer:GetAttribute("OfflineEarningsFinished") == true then
			showDailyRewards()
			v18 = true
		else
			v18 = false
		end

		if not v18 then
			local v19 = nil

			v19 = Players.LocalPlayer:GetAttributeChangedSignal("OfflineEarningsFinished"):Connect(function() --[[ Line: 1255 | Upvalues: Players (ref), showDailyRewards (copy), v19 (ref) ]]
				local v1

				if Players.LocalPlayer:GetAttribute("OfflineEarningsFinished") == true then
					showDailyRewards()
					v1 = true
				else
					v1 = false
				end

				if not v1 then
					return
				end

				v19:Disconnect()
			end)
		end
	end
end

return t3