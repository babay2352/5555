-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local MarketplaceService = game:GetService("MarketplaceService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Remotes = require(ReplicatedStorage.shared.Remotes)

require(ReplicatedStorage.shared.UECS.Components.TycoonStand)

local UECS = require(ReplicatedStorage.shared.UECS.UECS)

return {
	UECS = nil,
	Init = function(p1) --[[ Init | Line: 20 | Upvalues: Players (copy), UECS (copy), Remotes (copy), MarketplaceService (copy) ]]
		local LocalPlayer = Players.LocalPlayer

		local function refreshPromptText(p1) --[[ refreshPromptText | Line: 23 | Upvalues: LocalPlayer (copy) ]]
			if not p1.Entity then
				return
			end

			local root = p1.Entity:FindFirstChild("root")

			if not root then
				return
			end

			local FishPrompt = root:FindFirstChild("FishPrompt")

			if not FishPrompt then
				return
			end

			FishPrompt.ActionText = if p1.Owner:Get() == LocalPlayer then "Pull" else "Steal"
		end

		UECS.OnComponentCreated("TycoonStand"):Connect(function(p1) --[[ Line: 42 | Upvalues: LocalPlayer (copy) ]]
			p1.FishModel.OnChange:Connect(function() --[[ Line: 46 | Upvalues: p1 (copy), LocalPlayer (ref) ]]
				task.spawn(function() --[[ Line: 47 | Upvalues: p1 (ref), LocalPlayer (ref) ]]
					local v1 = p1.FishModel:Get()

					if typeof(v1) ~= "Instance" or not v1:IsA("Model") then
						return
					end

					local root = p1.Entity:FindFirstChild("root")

					if not root then
						return
					end

					root:WaitForChild("FishPrompt", 2)

					local v2 = p1

					if not v2.Entity then
						return
					end

					local root2 = v2.Entity:FindFirstChild("root")

					if not root2 then
						return
					end

					local FishPrompt = root2:FindFirstChild("FishPrompt")

					if not FishPrompt then
						return
					end

					FishPrompt.ActionText = if v2.Owner:Get() == LocalPlayer then "Pull" else "Steal"
				end)
			end)
			p1.Owner.OnChange:Connect(function() --[[ Line: 63 | Upvalues: p1 (copy), LocalPlayer (ref) ]]
				local v1 = p1

				if not v1.Entity then
					return
				end

				local root = v1.Entity:FindFirstChild("root")

				if not root then
					return
				end

				local FishPrompt = root:FindFirstChild("FishPrompt")

				if not FishPrompt then
					return
				end

				FishPrompt.ActionText = if v1.Owner:Get() == LocalPlayer then "Pull" else "Steal"
			end)

			if not p1.Entity then
				return
			end

			local root = p1.Entity:FindFirstChild("root")

			if not root then
				return
			end

			local FishPrompt = root:FindFirstChild("FishPrompt")

			if not FishPrompt then
				return
			end

			FishPrompt.ActionText = if p1.Owner:Get() == LocalPlayer then "Pull" else "Steal"
		end)
		Remotes.PromptStealPurchase:On(function(p1) --[[ Line: 70 | Upvalues: MarketplaceService (ref), LocalPlayer (copy) ]]
			if typeof(p1) == "number" then
				MarketplaceService:PromptProductPurchase(LocalPlayer, p1)
			end
		end)
	end
}