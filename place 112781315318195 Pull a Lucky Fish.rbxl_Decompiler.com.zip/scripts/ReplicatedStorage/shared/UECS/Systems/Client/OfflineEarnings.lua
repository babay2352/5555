-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ContextActionService = game:GetService("ContextActionService")
local Debris = game:GetService("Debris")
local MarketplaceService = game:GetService("MarketplaceService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local SoundService = game:GetService("SoundService")
local TweenService = game:GetService("TweenService")

game:GetService("UserInputService")

local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)

require(ReplicatedStorage.client.ControlHint)

local CashDisplay = require(ReplicatedStorage.shared.module.CashDisplay)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local MonetizationConfig = require(ReplicatedStorage.shared.config.MonetizationConfig)
local OfflineEarnings = require(ReplicatedStorage.shared.UECS.Components.OfflineEarnings)
local Remotes = require(ReplicatedStorage.shared.Remotes)

require(ReplicatedStorage.shared.UECS.UECS)

local fetchRobuxPriceInto = require(ReplicatedStorage.shared.util.fetchRobuxPriceInto)
local isGamepadActive = require(ReplicatedStorage.shared.util.isGamepadActive)
local ButtonA = Enum.KeyCode.ButtonA
local ButtonX = Enum.KeyCode.ButtonX
local Base = ReplicatedStorage.shared.model.Tycoon.Base
local v1 = NumberRange.new(0.11, 0.18)
local v2 = NumberRange.new(-15, 15)
local v3 = NumberRange.new(-0.05, 0.4)
local v4 = NumberRange.new(0.6, 1.05)
local v5 = NumberRange.new(0.6, 1.05)
local v6 = NumberRange.new(-0.05, 0.4)
local v7 = NumberRange.new(0.45, 0.8)
local v8 = NumberRange.new(0.65, 1.05)
local v9 = NumberRange.new(-0.05, 0.35)
local v10 = NumberRange.new(0.4, 0.7)

local function randomInRange(p1) --[[ randomInRange | Line: 70 ]]
	return p1.Min + math.random() * (p1.Max - p1.Min)
end

local function playClaimSound() --[[ playClaimSound | Line: 74 | Upvalues: SoundService (copy) ]]
	local SFX = SoundService:FindFirstChild("SFX")
	local v1 = if SFX then SFX:FindFirstChild("OfflineCash") else SFX

	if v1 and v1:IsA("Sound") then
		local v2 = v1:Clone()

		v2.PlayOnRemove = true
		v2.Parent = SoundService
		v2:Destroy()
	end
end

local function spawnWindIcon(p1, p2, p3, p4, p5, p6) --[[ spawnWindIcon | Line: 86 | Upvalues: v1 (copy), v2 (copy), TweenService (copy), RunService (copy), Debris (copy) ]]
	local v12 = v1
	local v22 = v12.Min + math.random() * (v12.Max - v12.Min)
	local v3 = v2
	local v4 = v3.Min + math.random() * (v3.Max - v3.Min)
	local v6 = Vector2.new(p2, p3)
	local v7 = Vector2.new(p4, p5)
	local v9 = v7 - v6
	local v10 = Vector2.new(-v9.Y, v9.X)
	local v11 = if v10.Magnitude > 0.001 then v10 / v10.Magnitude else Vector2.new(1, 0)
	local v122 = (v6 + v7) * 0.5 + v11 * ((math.random() * 2 - 1) * 0.32)
	local ImageLabel = Instance.new("ImageLabel")

	ImageLabel.BackgroundTransparency = 1
	ImageLabel.Image = "rbxassetid://135287528028888"
	ImageLabel.AnchorPoint = Vector2.new(0.5, 0.5)
	ImageLabel.Position = UDim2.fromScale(p2, p3)
	ImageLabel.Size = UDim2.fromScale(v22, v22)
	ImageLabel.SizeConstraint = Enum.SizeConstraint.RelativeYY
	ImageLabel.Rotation = v4
	ImageLabel.Parent = p1

	if if p3 > -0.05 and p2 > -0.02 then p2 < 1.02 else false then
		ImageLabel.ImageTransparency = 1
		TweenService:Create(ImageLabel, TweenInfo.new(0.18, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
			ImageTransparency = 0
		}):Play()
	end

	local v14 = Instance.new("NumberValue")

	v14.Value = 0
	v14.Parent = ImageLabel

	local v15 = nil

	v15 = RunService.Heartbeat:Connect(function() --[[ Line: 144 | Upvalues: ImageLabel (copy), v15 (ref), v14 (copy), v6 (copy), v122 (copy), v7 (copy) ]]
		debug.profilebegin("UECS/OfflineEarnings.ClaimIconArc")

		if ImageLabel.Parent then
			local v1 = v14.Value
			local v2 = 1 - v1

			ImageLabel.Position = UDim2.fromScale(v2 * v2 * v6.X + 2 * v2 * v1 * v122.X + v1 * v1 * v7.X, v2 * v2 * v6.Y + 2 * v2 * v1 * v122.Y + v1 * v1 * v7.Y)
		else
			v15:Disconnect()
		end

		debug.profileend()
	end)

	local v16 = TweenService:Create(v14, TweenInfo.new(1.9, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
		Value = 1
	})

	v16:Play()
	v16.Completed:Connect(function() --[[ Line: 165 | Upvalues: v15 (ref) ]]
		v15:Disconnect()
	end)
	TweenService:Create(ImageLabel, TweenInfo.new(1.9, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
		Rotation = v4 + p6 * 30
	}):Play()
	TweenService:Create(ImageLabel, TweenInfo.new(1.9, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
		Size = UDim2.fromScale(0.004, 0.004)
	}):Play()
	task.delay(1.2349999999999999, function() --[[ Line: 187 | Upvalues: ImageLabel (copy), TweenService (ref) ]]
		if ImageLabel.Parent then
			TweenService:Create(ImageLabel, TweenInfo.new(0.6649999999999999, Enum.EasingStyle.Linear), {
				ImageTransparency = 1
			}):Play()
		end
	end)
	Debris:AddItem(ImageLabel, 2.4)
end

local function playClaimVFX(p1) --[[ playClaimVFX | Line: 201 | Upvalues: v3 (copy), v5 (copy), v4 (copy), v6 (copy), spawnWindIcon (copy), v7 (copy), v8 (copy), v9 (copy), v10 (copy), Debris (copy) ]]
	local OfflineCashClaimVFX = Instance.new("ScreenGui")

	OfflineCashClaimVFX.Name = "OfflineCashClaimVFX"
	OfflineCashClaimVFX.IgnoreGuiInset = true
	OfflineCashClaimVFX.ResetOnSpawn = false
	OfflineCashClaimVFX.DisplayOrder = 1000
	OfflineCashClaimVFX.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
	OfflineCashClaimVFX.Parent = p1

	local function lerpSpawnY(p1) --[[ lerpSpawnY | Line: 214 ]]
		return (p1 - 1) / 11 * 0.6799999999999999 + -0.18 + (math.random() * 2 - 1) * 0.03
	end

	for i = 1, 8 do
		local v1 = if i % 2 == 1 then true else false
		local v2 = (i - 1) / 11 * 0.6799999999999999 + -0.18 + (math.random() * 2 - 1) * 0.03

		task.delay((i - 1) * 0.035, function() --[[ Line: 225 | Upvalues: OfflineCashClaimVFX (copy), v1 (copy), v3 (ref), v5 (ref), v4 (ref), v6 (ref), spawnWindIcon (ref), v2 (copy), v7 (ref) ]]
			if not OfflineCashClaimVFX.Parent then
				return
			end

			local v12 = if v1 then v3 else v5
			local v22 = if v1 then v4 else v6
			local v8 = v7

			spawnWindIcon(OfflineCashClaimVFX, v12.Min + math.random() * (v12.Max - v12.Min), v2, v22.Min + math.random() * (v22.Max - v22.Min), v8.Min + math.random() * (v8.Max - v8.Min), if v1 then 1 else -1)
		end)
	end

	for j = 1, 4 do
		local v32 = if j % 2 == 1 then true else false
		local v42 = (j + 8 - 1) / 11 * 0.6799999999999999 + -0.18 + (math.random() * 2 - 1) * 0.03

		task.delay((j - 1) * 0.035 + 0.395, function() --[[ Line: 249 | Upvalues: OfflineCashClaimVFX (copy), v32 (copy), v8 (ref), v9 (ref), spawnWindIcon (ref), v42 (copy), v10 (ref) ]]
			if not OfflineCashClaimVFX.Parent then
				return
			end

			local v2 = if v32 then v8 else v9
			local v7 = v10

			spawnWindIcon(OfflineCashClaimVFX, if v32 then -0.15 else 1.15, v42, v2.Min + math.random() * (v2.Max - v2.Min), v7.Min + math.random() * (v7.Max - v7.Min), if v32 then 1 else -1)
		end)
	end

	Debris:AddItem(OfflineCashClaimVFX, 2.9)
end

local t = {
	UECS = nil,
	Priority = 30
}

function t.Init(p1) --[[ Init | Line: 276 | Upvalues: Players (copy), OfflineEarnings (copy), MonetizationConfig (copy), Remotes (copy), playClaimSound (copy), playClaimVFX (copy), MarketplaceService (copy), CashDisplay (copy), fetchRobuxPriceInto (copy), t (copy), isGamepadActive (copy), ContextActionService (copy), ButtonA (copy), ButtonX (copy), ClientPlayerData (copy) ]]
	local PlayerGui = Players.LocalPlayer.PlayerGui
	local OfflineEarnings2 = PlayerGui:WaitForChild("MainUI").OfflineEarnings
	local v1 = OfflineEarnings.Add(OfflineEarnings2)
	local ProductId = MonetizationConfig.DevProducts.ClaimOfflineEarnings10x.ProductId
	local BuyDP = OfflineEarnings2:FindFirstChild("BuyDP", true)

	local function doClaim() --[[ doClaim | Line: 287 | Upvalues: Remotes (ref), p1 (copy), playClaimSound (ref), playClaimVFX (ref), PlayerGui (copy) ]]
		Remotes.ClaimOfflineMoney:Fire()
		p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
		playClaimSound()
		playClaimVFX(PlayerGui)
	end

	local function doBuyDP() --[[ doBuyDP | Line: 295 | Upvalues: MarketplaceService (ref), Players (ref), ProductId (copy) ]]
		MarketplaceService:PromptProductPurchase(Players.LocalPlayer, ProductId)
	end

	local Icon = OfflineEarnings2.Content.Cash:FindFirstChild("Icon")

	if Icon and Icon:IsA("GuiObject") then
		Icon.Visible = false
	end

	v1.OfflineEarned.OnChange:Connect(function(p1) --[[ Line: 306 | Upvalues: CashDisplay (ref), OfflineEarnings2 (copy) ]]
		CashDisplay.applyToLabel(OfflineEarnings2.Content.Cash.Counter, p1, {
			SuffixIcon = true
		})
	end)
	OfflineEarnings2.Content.Claim.MouseButton1Down:Connect(doClaim)

	if BuyDP then
		BuyDP.MouseButton1Down:Connect(doBuyDP)

		local v2 = BuyDP:FindFirstChild("Content") and BuyDP.Content:FindFirstChild("RobuxPrice")

		if v2 then
			fetchRobuxPriceInto(v2, ProductId, Enum.InfoType.Product)
		end
	end

	local t2 = {}

	local function bindGamepad() --[[ bindGamepad | Line: 350 | Upvalues: t (ref), isGamepadActive (ref), t2 (copy), ContextActionService (ref), Remotes (ref), p1 (copy), playClaimSound (ref), playClaimVFX (ref), PlayerGui (copy), ButtonA (ref), BuyDP (copy), MarketplaceService (ref), Players (ref), ProductId (copy), ButtonX (ref) ]]
		if t.GamepadBinded then
			return
		end

		if not isGamepadActive() then
			return
		end

		for v1, v2 in t2 do
			v2:Show()
		end

		t.GamepadBinded = true
		ContextActionService:BindActionAtPriority("OfflineEarnings_Claim", function(p12, p2) --[[ Line: 361 | Upvalues: Remotes (ref), p1 (ref), playClaimSound (ref), playClaimVFX (ref), PlayerGui (ref) ]]
			if p2 ~= Enum.UserInputState.Begin then
				return Enum.ContextActionResult.Sink
			end

			Remotes.ClaimOfflineMoney:Fire()
			p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
			playClaimSound()
			playClaimVFX(PlayerGui)

			return Enum.ContextActionResult.Sink
		end, false, 10000, ButtonA)

		if not BuyDP then
			return
		end

		ContextActionService:BindAction("OfflineEarnings_BuyDP", function(p1, p2) --[[ Line: 368 | Upvalues: MarketplaceService (ref), Players (ref), ProductId (ref) ]]
			if p2 ~= Enum.UserInputState.Begin then
				return Enum.ContextActionResult.Sink
			end

			MarketplaceService:PromptProductPurchase(Players.LocalPlayer, ProductId)

			return Enum.ContextActionResult.Sink
		end, false, ButtonX)
	end

	local function unbindGamepad() --[[ unbindGamepad | Line: 377 | Upvalues: t (ref), t2 (copy), ContextActionService (ref) ]]
		t.GamepadBinded = false

		for v1, v2 in t2 do
			v2:Hide()
		end

		ContextActionService:UnbindAction("OfflineEarnings_Claim")
		ContextActionService:UnbindAction("OfflineEarnings_BuyDP")
	end

	v1.Visible.OnChange:Connect(function(p1) --[[ Line: 386 | Upvalues: OfflineEarnings2 (copy), bindGamepad (copy), t (ref), t2 (copy), ContextActionService (ref), Players (ref) ]]
		OfflineEarnings2.Visible = p1

		if p1 then
			bindGamepad()

			return
		end

		t.GamepadBinded = false

		for v1, v2 in t2 do
			v2:Hide()
		end

		ContextActionService:UnbindAction("OfflineEarnings_Claim")
		ContextActionService:UnbindAction("OfflineEarnings_BuyDP")
		Players.LocalPlayer:SetAttribute("OfflineEarningsFinished", true)
	end)

	local function checkInitialOffline() --[[ checkInitialOffline | Line: 396 | Upvalues: ClientPlayerData (ref), Players (ref) ]]
		if not (ClientPlayerData.serverProfile:getState().offlineMoney <= 0) then
			return
		end

		Players.LocalPlayer:SetAttribute("OfflineEarningsFinished", true)
	end

	if ClientPlayerData.isPlayerDataLoaded then
		if not (ClientPlayerData.serverProfile:getState().offlineMoney <= 0) then
			MarketplaceService.PromptProductPurchaseFinished:Connect(function(p13, p23, p33) --[[ Line: 411 | Upvalues: Players (ref), ProductId (copy), p1 (copy) ]]
				if not p33 then
					return
				end

				if p13 ~= Players.LocalPlayer.UserId then
					return
				end

				if p23 == ProductId then
					p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
				end
			end)

			return
		end

		Players.LocalPlayer:SetAttribute("OfflineEarningsFinished", true)
	else
		task.spawn(function() --[[ Line: 405 | Upvalues: ClientPlayerData (ref), Players (ref) ]]
			repeat
				task.wait()
			until ClientPlayerData.isPlayerDataLoaded

			if not (ClientPlayerData.serverProfile:getState().offlineMoney <= 0) then
				return
			end

			Players.LocalPlayer:SetAttribute("OfflineEarningsFinished", true)
		end)
	end

	MarketplaceService.PromptProductPurchaseFinished:Connect(function(p13, p23, p33) --[[ Line: 411 | Upvalues: Players (ref), ProductId (copy), p1 (copy) ]]
		if not p33 then
			return
		end

		if p13 ~= Players.LocalPlayer.UserId then
			return
		end

		if p23 == ProductId then
			p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
		end
	end)
end

return t