-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
game:GetService("ContextActionService")
game:GetService("Players")

local ReplicatedStorage = game:GetService("ReplicatedStorage")

require(ReplicatedStorage.client.ClientPlayerData)
require(ReplicatedStorage.client.ControlHint)
require(ReplicatedStorage.shared.util.ConvertValue)
require(ReplicatedStorage.shared.UECS.GlobalTypes)
require(ReplicatedStorage.shared.Remotes)
require(ReplicatedStorage.client.SFX)
require(ReplicatedStorage.shared.UECS.Components.SpeedUpgrade)
require(ReplicatedStorage.shared.module.notifications)
require(ReplicatedStorage.shared.util.isGamepadActive)
require(ReplicatedStorage.shared.util.pullSpeedUpgradeCost)
require(ReplicatedStorage.shared.util.resolveFishRodForSpeed)

local ButtonX = Enum.KeyCode.ButtonX
local ButtonY = Enum.KeyCode.ButtonY

Color3.fromRGB(126, 255, 143)
Color3.fromRGB(110, 110, 110)
Color3.fromRGB(255, 255, 255)
Color3.fromRGB(180, 180, 180)
Color3.fromRGB(255, 90, 90)

return {
	UECS = nil,
	Priority = 30,
	Init = function(p1) --[[ Init | Line: 43 ]] end
}