-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local AlienEventConfig = require(ReplicatedStorage.shared.config.AlienEventConfig)
local AlienResearch = require(ReplicatedStorage.shared.util.AlienResearch)
local BeamTo = require(ReplicatedStorage.client.BeamTo)
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local FishConfig = require(ReplicatedStorage.shared.config.FishConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Remotes = require(ReplicatedStorage.shared.Remotes)
local SFX = require(ReplicatedStorage.client.SFX)
local TutorialGate = require(ReplicatedStorage.client.TutorialGate)
local buildFishModel = require(ReplicatedStorage.shared.util.buildFishModel)
local notifications = require(ReplicatedStorage.shared.module.notifications)
local t = {
	UECS = nil
}
local Laboratory = AlienEventConfig.Laboratory
local EventId = AlienEventConfig.EventId
local v1 = Vector2.new(0, -35)
local t2 = {}
local t3 = {}
local t4 = {}
local v2 = 0

local function getState() --[[ getState | Line: 87 | Upvalues: ClientPlayerData (copy) ]]
	return ClientPlayerData.serverProfile:getState()
end

local function getResearch(p1) --[[ getResearch | Line: 91 | Upvalues: EventId (copy) ]]
	local v1 = p1.events and p1.events[EventId]

	return (if type(v1) == "table" then v1.research else nil) or {}
end

local function isReady(p1) --[[ isReady | Line: 96 | Upvalues: Laboratory (copy) ]]
	return workspace:GetServerTimeNow() >= p1.startedAt + Laboratory.ScanDuration
end

local function heldFishState() --[[ heldFishState | Line: 106 | Upvalues: Players (copy), t (copy), AlienResearch (copy) ]]
	local Character = Players.LocalPlayer.Character

	if not Character then
		return "other"
	end

	local Tool = Character:FindFirstChildOfClass("Tool")

	if not Tool then
		return "other"
	end

	local UECS = t.UECS
	local v1 = if UECS then UECS:GetComponent(Tool, "PlaceableFish") else UECS

	if not v1 then
		return "other"
	end

	if not AlienResearch.isAlienFish((v1.FishConfigName:Get())) then
		return "other"
	end

	if AlienResearch.needsScan(AlienResearch.fromProperty(v1.ScanState and v1.ScanState:Get())) then
		return "researchable"
	end

	return "scanned"
end

local function clearFish(p1) --[[ clearFish | Line: 134 ]]
	if p1.fish then
		p1.fish:Destroy()
		p1.fish = nil
	end

	p1.fishSig = nil
end

local function showFish(p1, p2) --[[ showFish | Line: 145 | Upvalues: buildFishModel (copy), Laboratory (copy), CollectionService (copy), FishConfig (copy) ]]
	local v1 = buildFishModel.clone(p2.kind, p2.level, p2.mutation)

	if not v1 then
		warn((("[AlienResearchLab] no model for \'%*\'; capsule %* will scan without a fish"):format(p2.kind, p1.key)))

		return
	end

	for v2, v3 in v1:GetDescendants() do
		if v3:IsA("BasePart") then
			v3.Anchored = true
			v3.CanCollide = false
			v3.CanQuery = false
			v3.CanTouch = false
			v3.CastShadow = false
		end
	end

	local _, v4 = v1:GetBoundingBox()

	if v4.X > 0 and (v4.Y > 0 and v4.Z > 0) then
		local v8 = math.min(p1.part.Size.X / v4.X, p1.part.Size.Y / v4.Y, p1.part.Size.Z / v4.Z)

		v1:ScaleTo(v1:GetScale() * math.min(v8, 1) * Laboratory.FishFitRatio)
	end

	local PrimaryPart = v1.PrimaryPart

	if not PrimaryPart then
		warn((("[AlienResearchLab] \'%*\' has no PrimaryPart; not rendering it"):format(p2.kind)))
		v1:Destroy()

		return
	end

	PrimaryPart.CFrame = (p1.part.CFrame - p1.part.Position) * (PrimaryPart.CFrame - PrimaryPart.CFrame.Position)

	local v9, _2 = v1:GetBoundingBox()

	PrimaryPart.CFrame = PrimaryPart.CFrame + (p1.part.Position - v9.Position)
	v1.Parent = workspace
	v1:SetAttribute("IdleAnchor", PrimaryPart.CFrame)
	CollectionService:AddTag(v1, "IdleFishFloat")

	local v10 = FishConfig[p2.kind]

	if v10 and v10.Anim then
		v1:SetAttribute("Anim", v10.Anim)
		CollectionService:AddTag(v1, "AnimAnimationController")
	end

	p1.fish = v1
end

local function setLabel(p1, p2, p3) --[[ setLabel | Line: 204 ]]
	local label = p1.label

	if label and label:IsDescendantOf(game) then
		label.Text = p2
		label.TextColor3 = p3
	end
end

local function setCapsuleFx(p1, p2) --[[ setCapsuleFx | Line: 213 ]]
	for v1, v2 in p1.fx do
		if v2:IsDescendantOf(game) then
			if v2:IsA("ParticleEmitter") then
				v2.Enabled = p2

				continue
			end

			if v2:IsA("Beam") then
				v2.Enabled = p2
			end
		end
	end
end

local v3 = nil

local function getParkFolder() --[[ getParkFolder | Line: 236 | Upvalues: v3 (ref), Laboratory (copy), ReplicatedStorage (copy) ]]
	local v1 = v3

	if v1 and v1:IsDescendantOf(game) then
		return v1
	end

	local v2 = Instance.new("Folder")

	v2.Name = Laboratory.LockedParkFolderName
	v2.Parent = ReplicatedStorage
	v3 = v2

	return v2
end

local function setParked(p1, p2) --[[ setParked | Line: 248 | Upvalues: v3 (ref), Laboratory (copy), ReplicatedStorage (copy) ]]
	local model = p1.model

	if p2 then
		local v1 = v3
		local v2

		if v1 and v1:IsDescendantOf(game) then
			v2 = v1
		else
			local v32 = Instance.new("Folder")

			v32.Name = Laboratory.LockedParkFolderName
			v32.Parent = ReplicatedStorage
			v3 = v32
			v2 = v32
		end

		if model.Parent ~= v2 then
			p1.homeParent = model.Parent
			model.Parent = v2
		end
	else
		local homeParent = p1.homeParent

		if not homeParent or model.Parent == homeParent then
			return
		end

		model.Parent = homeParent
	end
end

local function findSoundPart() --[[ findSoundPart | Line: 273 | Upvalues: t3 (copy), Laboratory (copy) ]]
	for v1, v2 in t3 do
		if v2.model:IsDescendantOf(workspace) then
			local v3 = v2.model.Parent

			while v3 and v3 ~= workspace do
				local v4 = v3:FindFirstChild(Laboratory.SoundPartName)

				if v4 and v4:IsA("BasePart") then
					return v4
				end

				v3 = v3.Parent
			end
		end
	end

	return nil
end

local v4 = nil

local function setScanSound(p1) --[[ setScanSound | Line: 295 | Upvalues: v4 (ref), findSoundPart (copy), SFX (copy), Laboratory (copy) ]]
	local v1 = v4

	if v1 and not v1:IsDescendantOf(game) then
		v1 = nil
		v4 = nil
	end

	if p1 then
		if not v1 then
			local v2 = findSoundPart()

			if not v2 then
				return
			end

			local AlienLabScan = Instance.new("Sound")

			AlienLabScan.Name = "AlienLabScan"
			AlienLabScan.SoundId = SFX.Sounds.LabScan
			AlienLabScan.Looped = true
			AlienLabScan.Volume = Laboratory.ScanSoundVolume
			AlienLabScan.RollOffMaxDistance = Laboratory.ScanSoundRange
			AlienLabScan.Parent = v2
			v4 = AlienLabScan
			v1 = AlienLabScan
		end

		if not v1 or v1.IsPlaying then
			return
		end

		v1:Play()
	else
		if not (v1 and v1.IsPlaying) then
			return
		end

		v1:Stop()
	end
end

local function refreshCapsule(p1, p2, p3) --[[ refreshCapsule | Line: 331 | Upvalues: Laboratory (copy), v3 (ref), ReplicatedStorage (copy), setCapsuleFx (copy), showFish (copy), SFX (copy), TutorialGate (copy) ]]
	local v1 = p2[p1.key]
	local v2 = if v1 then if workspace:GetServerTimeNow() >= v1.startedAt + Laboratory.ScanDuration then "ready" else "scanning" elseif p3 < p1.id then "locked" else "empty"
	local model = p1.model

	if if v2 == "locked" then true else false then
		local v5 = v3
		local v6

		if v5 and v5:IsDescendantOf(game) then
			v6 = v5
		else
			local v7 = Instance.new("Folder")

			v7.Name = Laboratory.LockedParkFolderName
			v7.Parent = ReplicatedStorage
			v3 = v7
			v6 = v7
		end

		if model.Parent ~= v6 then
			p1.homeParent = model.Parent
			model.Parent = v6
		end
	else
		local homeParent = p1.homeParent

		if homeParent and model.Parent ~= homeParent then
			model.Parent = homeParent
		end
	end

	if v2 == "locked" then
		p1.prompt.Enabled = false
		setCapsuleFx(p1, false)

		if p1.fish then
			p1.fish:Destroy()
			p1.fish = nil
		end

		p1.fishSig = nil
	elseif v2 == "empty" then
		local EmptyText = Laboratory.EmptyText
		local labelColor = p1.labelColor
		local label = p1.label

		if label and label:IsDescendantOf(game) then
			label.Text = EmptyText
			label.TextColor3 = labelColor
		end

		p1.prompt.ActionText = Laboratory.PromptInsertActionText
		p1.prompt.Enabled = true
		setCapsuleFx(p1, false)

		if p1.fish then
			p1.fish:Destroy()
			p1.fish = nil
		end

		p1.fishSig = nil
	else
		local v8 = ("%*|%*|%*|%*"):format(v1.kind, v1.level, v1.mutation or "", v1.startedAt)

		if p1.fishSig ~= v8 then
			if p1.fish then
				p1.fish:Destroy()
				p1.fish = nil
			end

			p1.fishSig = nil
			p1.fishSig = v8
			showFish(p1, v1)
		end

		if v2 == "scanning" then
			local v9 = Laboratory.ProgressText(v1.startedAt + Laboratory.ScanDuration - workspace:GetServerTimeNow())
			local labelColor = p1.labelColor
			local label = p1.label

			if label and label:IsDescendantOf(game) then
				label.Text = v9
				label.TextColor3 = labelColor
			end

			p1.prompt.Enabled = false
			setCapsuleFx(p1, true)

			if p1.lastState == "empty" then
				SFX.PlaySoundWithRandomPitchAtPart(SFX.Sounds.LabScanStart, p1.part, Laboratory.InsertSoundVolume, 1, 1)
			end
		else
			local ReadyText = Laboratory.ReadyText
			local labelColor = p1.labelColor
			local label = p1.label

			if label and label:IsDescendantOf(game) then
				label.Text = ReadyText
				label.TextColor3 = labelColor
			end

			p1.prompt.ActionText = Laboratory.PromptCollectActionText
			p1.prompt.Enabled = true
			setCapsuleFx(p1, false)

			if p1.lastState == "scanning" then
				SFX.PlaySoundWithRandomPitchAtPart(SFX.Sounds.LabScanDone, p1.part, Laboratory.ReadySoundVolume, 1, 1)
			end
		end
	end

	if TutorialGate.active() then
		p1.prompt.Enabled = false
	end

	p1.lastState = v2

	return v2 == "scanning"
end

local function refreshAll() --[[ refreshAll | Line: 402 | Upvalues: ClientPlayerData (copy), EventId (copy), AlienEventConfig (copy), t2 (copy), t3 (copy), refreshCapsule (copy), setScanSound (copy) ]]
	local v1 = ClientPlayerData.serverProfile:getState()
	local v2 = v1.events and v1.events[EventId]
	local v3 = (if type(v2) == "table" then v2.research else nil) or {}
	local v4 = AlienEventConfig.GetUnlockedCapsuleCount(v1)
	local v5 = false

	for v6, v7 in t2 do
		if v6:IsDescendantOf(game) then
			if refreshCapsule(v7, v3, v4) then
				v5 = true
			end

			continue
		end

		if v7.fish then
			v7.fish:Destroy()
			v7.fish = nil
		end

		v7.fishSig = nil
		t2[v6] = nil

		if t3[v7.id] == v7 then
			t3[v7.id] = nil
		end
	end

	setScanSound(v5)
end

local function anchorPartOf(p1) --[[ anchorPartOf | Line: 428 | Upvalues: Laboratory (copy) ]]
	if p1:IsA("BasePart") then
		return p1
	end

	if not p1:IsA("Model") then
		return nil
	end

	local v1 = p1:FindFirstChild(Laboratory.MainPartName, true)

	return p1.PrimaryPart or (if v1 and v1:IsA("BasePart") then v1 else nil) or p1:FindFirstChildWhichIsA("BasePart", true)
end

local function register(p1, p2) --[[ register | Line: 441 | Upvalues: Laboratory (copy), t3 (copy), v1 (copy), Players (copy), ClientPlayerData (copy), EventId (copy), Remotes (copy), heldFishState (copy), notifications (copy), t2 (copy) ]]
	local v12 = p1:GetAttribute(Laboratory.CapsuleIdAttribute)
	local v2 = if typeof(v12) == "number" then math.floor(v12) else nil

	if not v2 or (v2 < 1 or Laboratory.CapsuleCount < v2) then
		warn((("[AlienResearchLab] \'%*\' has no usable %* (got %*); skipping it"):format(p1:GetFullName(), Laboratory.CapsuleIdAttribute, (tostring(v12)))))

		return nil
	end

	if t3[v2] then
		warn((("[AlienResearchLab] duplicate %* %* on \'%*\'"):format(Laboratory.CapsuleIdAttribute, v2, (p1:GetFullName()))))
	end

	local v3 = p1:FindFirstChild(Laboratory.ProgressLabelName, true)

	if not (v3 and v3:IsA("TextLabel")) then
		warn((("[AlienResearchLab] \'%*\' has no \'%*\' TextLabel"):format(p1:GetFullName(), Laboratory.ProgressLabelName)))
		v3 = nil
	end

	local t = {}

	for v4, v5 in p2:GetDescendants() do
		if v5:IsA("ParticleEmitter") then
			v5.Enabled = false
			table.insert(t, v5)

			continue
		end

		if v5:IsA("Beam") then
			v5.Enabled = false
			table.insert(t, v5)
		end
	end

	local ProximityPrompt = Instance.new("ProximityPrompt")

	ProximityPrompt.Style = Enum.ProximityPromptStyle.Custom
	ProximityPrompt.ActionText = Laboratory.PromptInsertActionText
	ProximityPrompt.ObjectText = Laboratory.PromptObjectText
	ProximityPrompt.HoldDuration = 0
	ProximityPrompt.MaxActivationDistance = Laboratory.PromptMaxDistance
	ProximityPrompt.RequiresLineOfSight = false
	ProximityPrompt.KeyboardKeyCode = Enum.KeyCode.E
	ProximityPrompt.UIOffset = v1
	ProximityPrompt.Enabled = false
	ProximityPrompt:AddTag("NoFade")
	ProximityPrompt.Parent = p2

	local t4 = {
		fish = nil,
		fishSig = nil,
		lastState = nil,
		model = p1,
		part = p2,
		id = v2,
		key = tostring(v2),
		prompt = ProximityPrompt,
		label = v3
	}

	t4.labelColor = if v3 and v3:IsA("TextLabel") then v3.TextColor3 else Color3.new(255/255, 255/255, 255/255)
	t4.fx = t
	t4.homeParent = p1.Parent
	ProximityPrompt.Triggered:Connect(function(p1) --[[ Line: 506 | Upvalues: Players (ref), ClientPlayerData (ref), EventId (ref), t4 (copy), Laboratory (ref), Remotes (ref), heldFishState (ref), notifications (ref) ]]
		if p1 ~= Players.LocalPlayer then
			return
		end

		local v1 = ClientPlayerData.serverProfile:getState()
		local v2 = v1.events and v1.events[EventId]
		local v4 = ((if type(v2) == "table" then v2.research else nil) or {})[t4.key]

		if v4 and workspace:GetServerTimeNow() >= v4.startedAt + Laboratory.ScanDuration then
			task.spawn(function() --[[ Line: 513 | Upvalues: Remotes (ref), t4 (ref) ]]
				Remotes.AlienResearchCollect:Call(t4.id):Await()
			end)

			return
		end

		local v6 = heldFishState()

		if v6 == "scanned" then
			notifications:Send(Laboratory.AlreadyScannedText)

			return
		end

		if v6 == "other" then
			notifications:Send(Laboratory.NeedAlienFishText)
		else
			task.spawn(function() --[[ Line: 533 | Upvalues: Remotes (ref), t4 (ref) ]]
				Remotes.AlienResearchInsert:Call(t4.id):Await()
			end)
		end
	end)
	t2[p1] = t4
	t3[v2] = t4

	return t4
end

local function ensureCapsule(p1) --[[ ensureCapsule | Line: 546 | Upvalues: t4 (copy), anchorPartOf (copy), register (copy), refreshAll (copy), t2 (copy), t3 (copy) ]]
	if not t4[p1] then
		t4[p1] = true
		task.spawn(function() --[[ Line: 551 | Upvalues: p1 (copy), anchorPartOf (ref), register (ref), refreshAll (ref), t2 (ref), t3 (ref), t4 (ref) ]]
			while p1:IsDescendantOf(game) do
				local v1 = anchorPartOf(p1)

				if v1 then
					local v22 = register(p1, v1)

					if not v22 then
						break
					end

					refreshAll()

					while p1:IsDescendantOf(game) and v1:IsDescendantOf(game) do
						task.wait(1)
					end

					if v22.fish then
						v22.fish:Destroy()
						v22.fish = nil
					end

					v22.fishSig = nil
					t2[p1] = nil

					if t3[v22.id] == v22 then
						t3[v22.id] = nil
					end

					continue
				end

				task.wait(0.5)
			end

			t4[p1] = nil
		end)
	end
end

local function firstCapsulePart() --[[ firstCapsulePart | Line: 583 | Upvalues: t3 (copy) ]]
	local v1 = nil

	for v2, v3 in t3 do
		if v3.part:IsDescendantOf(workspace) and (not v1 or v2 < v1) then
			v1 = v2
		end
	end

	if v1 then
		return t3[v1].part
	end

	return nil
end

local function showGuideBeam() --[[ showGuideBeam | Line: 593 | Upvalues: firstCapsulePart (copy), v2 (ref), BeamTo (copy), Laboratory (copy) ]]
	local v1 = firstCapsulePart()

	if v1 then
		v2 = v2 + 1

		local v22 = v2

		BeamTo(v1)
		task.delay(Laboratory.GuideBeamSeconds, function() --[[ Line: 601 | Upvalues: v2 (ref), v22 (copy), BeamTo (ref) ]]
			if v2 ~= v22 then
				return
			end

			BeamTo(nil)
		end)
	end
end

function t.Init(p1) --[[ Init | Line: 610 | Upvalues: AlienEventConfig (copy), CollectionService (copy), Laboratory (copy), t4 (copy), anchorPartOf (copy), register (copy), refreshAll (copy), t2 (copy), t3 (copy), ensureCapsule (copy), Remotes (copy), showGuideBeam (copy), ClientPlayerData (copy), EventId (copy), TutorialGate (copy), Players (copy), RunService (copy) ]]
	if not AlienEventConfig.Enabled then
		return
	end

	for v1, v2 in CollectionService:GetTagged(Laboratory.Tag) do
		if not t4[v2] then
			t4[v2] = true
			task.spawn(function() --[[ Line: 551 | Upvalues: v2 (copy), anchorPartOf (ref), register (ref), refreshAll (ref), t2 (ref), t3 (ref), t4 (ref) ]]
				while v2:IsDescendantOf(game) do
					local v1 = anchorPartOf(v2)

					if v1 then
						local v22 = register(v2, v1)

						if not v22 then
							break
						end

						refreshAll()

						while v2:IsDescendantOf(game) and v1:IsDescendantOf(game) do
							task.wait(1)
						end

						if v22.fish then
							v22.fish:Destroy()
							v22.fish = nil
						end

						v22.fishSig = nil
						t2[v2] = nil

						if t3[v22.id] == v22 then
							t3[v22.id] = nil
						end

						continue
					end

					task.wait(0.5)
				end

				t4[v2] = nil
			end)
		end
	end

	CollectionService:GetInstanceAddedSignal(Laboratory.Tag):Connect(ensureCapsule)
	Remotes.AlienResearchGuide:On(showGuideBeam)
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 626 | Upvalues: EventId (ref) ]]
		local v1 = p1.events and p1.events[EventId]

		if type(v1) == "table" then
			return v1.research
		end

		return nil
	end, refreshAll)
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 630 | Upvalues: AlienEventConfig (ref) ]]
		return AlienEventConfig.GetPlayerStage(p1, "ResearchStations")
	end, refreshAll)
	TutorialGate.onChanged(refreshAll)
	Players.LocalPlayer.CharacterAdded:Connect(function() --[[ Line: 642 | Upvalues: refreshAll (ref) ]]
		refreshAll()
	end)

	if not Players.LocalPlayer.Character then
		task.spawn(function() --[[ Line: 651 | Upvalues: ClientPlayerData (ref), EventId (ref), refreshAll (ref) ]]
			local v1 = os.clock() + 30

			while os.clock() < v1 do
				local v2 = ClientPlayerData.serverProfile:getState()

				if v2.events and v2.events[EventId] then
					break
				end

				task.wait(0.25)
			end

			refreshAll()
		end)
		task.spawn(function() --[[ Line: 666 | Upvalues: RunService (ref), ClientPlayerData (ref), EventId (ref), refreshAll (ref) ]]
			local v1 = 0

			RunService.Heartbeat:Connect(function(p13) --[[ Line: 668 | Upvalues: v1 (ref), ClientPlayerData (ref), EventId (ref), refreshAll (ref) ]]
				v1 = v1 + p13

				if v1 < 1 then
					return
				end

				v1 = 0
				debug.profilebegin("UECS/AlienResearchLab.Tick")

				local v12 = ClientPlayerData.serverProfile:getState()
				local v2 = v12.events and v12.events[EventId]

				if next((if type(v2) == "table" then v2.research else nil) or {}) ~= nil then
					refreshAll()
				end

				debug.profileend()
			end)
		end)

		return
	end

	refreshAll()
	task.spawn(function() --[[ Line: 651 | Upvalues: ClientPlayerData (ref), EventId (ref), refreshAll (ref) ]]
		local v1 = os.clock() + 30

		while os.clock() < v1 do
			local v2 = ClientPlayerData.serverProfile:getState()

			if v2.events and v2.events[EventId] then
				break
			end

			task.wait(0.25)
		end

		refreshAll()
	end)
	task.spawn(function() --[[ Line: 666 | Upvalues: RunService (ref), ClientPlayerData (ref), EventId (ref), refreshAll (ref) ]]
		local v1 = 0

		RunService.Heartbeat:Connect(function(p13) --[[ Line: 668 | Upvalues: v1 (ref), ClientPlayerData (ref), EventId (ref), refreshAll (ref) ]]
			v1 = v1 + p13

			if v1 < 1 then
				return
			end

			v1 = 0
			debug.profilebegin("UECS/AlienResearchLab.Tick")

			local v12 = ClientPlayerData.serverProfile:getState()
			local v2 = v12.events and v12.events[EventId]

			if next((if type(v2) == "table" then v2.research else nil) or {}) ~= nil then
				refreshAll()
			end

			debug.profileend()
		end)
	end)
end

return t