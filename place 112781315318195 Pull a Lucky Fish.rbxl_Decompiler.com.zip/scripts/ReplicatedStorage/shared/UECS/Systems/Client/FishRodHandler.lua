-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local ActiveFishRodRig = require(ReplicatedStorage.client.ActiveFishRodRig)
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local ThrowZoneState = require(ReplicatedStorage.client.ThrowZoneState)
local applyEnchantEffects = require(ReplicatedStorage.shared.util.applyEnchantEffects)
local buildFishRodRig = require(ReplicatedStorage.shared.util.buildFishRodRig)
local hideFishRodAccessory = require(ReplicatedStorage.shared.util.hideFishRodAccessory)
local t = {
	UECS = nil
}
local v1 = nil

local function setAccessoryHidden(p1, p2) --[[ setAccessoryHidden | Line: 23 | Upvalues: v1 (ref), hideFishRodAccessory (copy) ]]
	if v1 then
		v1()
		v1 = nil
	end

	if not p2 then
		return
	end

	v1 = hideFishRodAccessory(p1)
end

function t.Init(p1) --[[ Init | Line: 33 | Upvalues: ClientPlayerData (copy), Players (copy), CollectionService (copy), ActiveFishRodRig (copy), buildFishRodRig (copy), applyEnchantEffects (copy), RunService (copy), ThrowZoneState (copy), v1 (ref), hideFishRodAccessory (copy) ]]
	repeat
		task.wait()
	until ClientPlayerData.isPlayerDataLoaded

	local LocalPlayer = Players.LocalPlayer
	local v12 = RaycastParams.new()

	v12.FilterType = Enum.RaycastFilterType.Include

	local function refreshThrowZoneFilter() --[[ refreshThrowZoneFilter | Line: 45 | Upvalues: v12 (copy), CollectionService (ref) ]]
		v12.FilterDescendantsInstances = CollectionService:GetTagged("ThrowZone")
	end

	v12.FilterDescendantsInstances = CollectionService:GetTagged("ThrowZone")
	CollectionService:GetInstanceAddedSignal("ThrowZone"):Connect(refreshThrowZoneFilter)
	CollectionService:GetInstanceRemovedSignal("ThrowZone"):Connect(refreshThrowZoneFilter)

	local v2 = false
	local v3 = nil
	local v4 = nil
	local v5 = nil

	local function cleanupRig() --[[ cleanupRig | Line: 57 | Upvalues: v5 (ref), v4 (ref), ActiveFishRodRig (ref) ]]
		if v5 then
			v5:Disconnect()
			v5 = nil
		end

		if v4 then
			v4:Destroy()
			v4 = nil
		end

		ActiveFishRodRig.Set(nil)
	end

	local function spawnRig(p1) --[[ spawnRig | Line: 69 | Upvalues: v5 (ref), v4 (ref), ActiveFishRodRig (ref), ClientPlayerData (ref), buildFishRodRig (ref), applyEnchantEffects (ref), RunService (ref) ]]
		if v5 then
			v5:Disconnect()
			v5 = nil
		end

		if v4 then
			v4:Destroy()
			v4 = nil
		end

		ActiveFishRodRig.Set(nil)

		local RightHand = p1:FindFirstChild("RightHand")

		if not RightHand then
			return
		end

		local v1 = ClientPlayerData.serverProfile:getState()
		local fishRod = v1.fishRod
		local v2 = buildFishRodRig(fishRod)

		if v2 then
			applyEnchantEffects(v2, v1, fishRod)
			v4 = v2
			v5 = RunService.RenderStepped:Connect(function() --[[ Line: 84 | Upvalues: v4 (ref), RightHand (copy) ]]
				debug.profilebegin("UECS/FishRodHandler.RigFollow")

				if not (v4 and (v4.PrimaryPart and RightHand.Parent)) then
					debug.profileend()

					return
				end

				v4.PrimaryPart.CFrame = RightHand.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
				debug.profileend()
			end)
			ActiveFishRodRig.Set(v2)
		end
	end

	local function enterZone(p1) --[[ enterZone | Line: 94 | Upvalues: v2 (ref), v3 (ref), ThrowZoneState (ref), spawnRig (copy) ]]
		if not v2 then
			v2 = true
			v3 = p1
			ThrowZoneState.Set(true)
			task.delay(0.2, function() --[[ Line: 101 | Upvalues: v2 (ref), v3 (ref), p1 (copy), spawnRig (ref) ]]
				if not v2 or v3 ~= p1 then
					return
				end

				spawnRig(p1)
			end)
		end
	end

	local function leaveZone() --[[ leaveZone | Line: 108 | Upvalues: v2 (ref), v3 (ref), ThrowZoneState (ref), v5 (ref), v4 (ref), ActiveFishRodRig (ref) ]]
		if not v2 then
			return
		end

		v2 = false
		v3 = nil
		ThrowZoneState.Set(false)

		if v5 then
			v5:Disconnect()
			v5 = nil
		end

		if v4 then
			v4:Destroy()
			v4 = nil
		end

		ActiveFishRodRig.Set(nil)
	end

	local function bindCharacter(p1) --[[ bindCharacter | Line: 118 | Upvalues: RunService (ref), v2 (ref), v3 (ref), ThrowZoneState (ref), v5 (ref), v4 (ref), ActiveFishRodRig (ref), v12 (copy), spawnRig (copy) ]]
		local Humanoid = p1:WaitForChild("Humanoid")
		local HumanoidRootPart = p1:WaitForChild("HumanoidRootPart")
		local v1 = nil

		v1 = RunService.RenderStepped:Connect(function() --[[ Line: 123 | Upvalues: p1 (copy), HumanoidRootPart (copy), v2 (ref), v3 (ref), ThrowZoneState (ref), v5 (ref), v4 (ref), ActiveFishRodRig (ref), v1 (ref), v12 (ref), spawnRig (ref) ]]
			debug.profilebegin("UECS/FishRodHandler.ThrowZoneCheck")

			if p1.Parent and HumanoidRootPart.Parent then
				local v13 = workspace:Raycast(HumanoidRootPart.Position, Vector3.new(0, -15, 0), v12)

				if v13 and not v2 then
					local v22 = p1

					if not v2 then
						v2 = true
						v3 = v22
						ThrowZoneState.Set(true)
						task.delay(0.2, function() --[[ Line: 101 | Upvalues: v2 (ref), v3 (ref), v22 (copy), spawnRig (ref) ]]
							if not v2 or v3 ~= v22 then
								return
							end

							spawnRig(v22)
						end)
					end
				elseif not v13 and (v2 and v2) then
					v2 = false
					v3 = nil
					ThrowZoneState.Set(false)

					if v5 then
						v5:Disconnect()
						v5 = nil
					end

					if v4 then
						v4:Destroy()
						v4 = nil
					end

					ActiveFishRodRig.Set(nil)
				end
			else
				if v2 then
					v2 = false
					v3 = nil
					ThrowZoneState.Set(false)

					if v5 then
						v5:Disconnect()
						v5 = nil
					end

					if v4 then
						v4:Destroy()
						v4 = nil
					end

					ActiveFishRodRig.Set(nil)
				end

				v1:Disconnect()
			end

			debug.profileend()
		end)
		Humanoid.Died:Connect(function() --[[ Line: 142 | Upvalues: v2 (ref), v3 (ref), ThrowZoneState (ref), v5 (ref), v4 (ref), ActiveFishRodRig (ref), v1 (ref) ]]
			if not v2 then
				v1:Disconnect()

				return
			end

			v2 = false
			v3 = nil
			ThrowZoneState.Set(false)

			if v5 then
				v5:Disconnect()
				v5 = nil
			end

			if v4 then
				v4:Destroy()
				v4 = nil
			end

			ActiveFishRodRig.Set(nil)
			v1:Disconnect()
		end)
	end

	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 150 ]]
		return p1.fishRod
	end, function() --[[ Line: 152 | Upvalues: v2 (ref), v3 (ref), spawnRig (copy) ]]
		if not (v2 and v3) then
			return
		end

		spawnRig(v3)
	end)
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 160 ]]
		return p1.rodEnchants
	end, function() --[[ Line: 162 | Upvalues: v4 (ref), ClientPlayerData (ref), applyEnchantEffects (ref) ]]
		if not v4 then
			return
		end

		local v1 = ClientPlayerData.serverProfile:getState()

		applyEnchantEffects(v4, v1, v1.fishRod)
	end)

	local function syncAccessoryToRig() --[[ syncAccessoryToRig | Line: 172 | Upvalues: LocalPlayer (copy), ActiveFishRodRig (ref), v1 (ref), hideFishRodAccessory (ref) ]]
		local Character = LocalPlayer.Character

		if not Character then
			return
		end

		if v1 then
			v1()
			v1 = nil
		end

		if not (ActiveFishRodRig.Current ~= nil) then
			return
		end

		v1 = hideFishRodAccessory(Character)
	end

	ActiveFishRodRig.OnChanged:Connect(syncAccessoryToRig)

	local function onCharacter(p1) --[[ onCharacter | Line: 180 | Upvalues: bindCharacter (copy), LocalPlayer (copy), ActiveFishRodRig (ref), v1 (ref), hideFishRodAccessory (ref) ]]
		bindCharacter(p1)

		local Character = LocalPlayer.Character

		if not Character then
			return
		end

		if v1 then
			v1()
			v1 = nil
		end

		if not (ActiveFishRodRig.Current ~= nil) then
			return
		end

		v1 = hideFishRodAccessory(Character)
	end

	if LocalPlayer.Character then
		bindCharacter(LocalPlayer.Character)

		local Character = LocalPlayer.Character

		if Character then
			if v1 then
				v1()
				v1 = nil
			end

			if ActiveFishRodRig.Current ~= nil then
				v1 = hideFishRodAccessory(Character)
			end
		end
	end

	LocalPlayer.CharacterAdded:Connect(onCharacter)
end

return t