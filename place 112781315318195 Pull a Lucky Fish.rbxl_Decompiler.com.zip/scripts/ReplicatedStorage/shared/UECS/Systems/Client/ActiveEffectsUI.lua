-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local HttpService = game:GetService("HttpService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local ActiveEffects = require(ReplicatedStorage.shared.effects.ActiveEffects)
local EventsConfig = require(ReplicatedStorage.shared.config.EventsConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local PotionConfig = require(ReplicatedStorage.shared.config.PotionConfig)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local getPlayerPoolLuck = require(ReplicatedStorage.shared.util.getPlayerPoolLuck)
local t = {
	UECS = nil
}

local function formatRemaining(p1) --[[ formatRemaining | Line: 22 ]]
	local v3 = math.max(0, (math.ceil(p1 - workspace:GetServerTimeNow())))
	local v4 = math.floor(v3 / 3600)
	local v5 = math.floor(v3 % 3600 / 60)
	local v6 = v3 % 60

	if v4 > 0 then
		return string.format("%d:%02d:%02dh", v4, v5, v6)
	end

	return string.format("%02d:%02dm", v5, v6)
end

local function formatUpcoming(p1) --[[ formatUpcoming | Line: 33 ]]
	local v3 = math.max(0, (math.ceil(p1 - workspace:GetServerTimeNow())))
	local v4 = math.floor(v3 / 3600)
	local v5 = math.floor(v3 % 3600 / 60)
	local v6 = v3 % 60

	if v4 > 0 then
		return string.format("in %d:%02d:%02dh", v4, v5, v6)
	end

	return string.format("in %02d:%02dm", v5, v6)
end

function t.Init(p1) --[[ Init | Line: 44 | Upvalues: Players (copy), ReplicatedStorage (copy), CollectionService (copy), PotionConfig (copy), formatRemaining (copy), HttpService (copy), Remotes (copy), EventsConfig (copy), formatUpcoming (copy), ActiveEffects (copy), RunService (copy), getPlayerPoolLuck (copy) ]]
	local ActiveEffects2 = Players.LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("MainUI"):WaitForChild("HUD"):WaitForChild("ActiveEffects")
	local Template = ActiveEffects2:WaitForChild("UIGridLayout"):WaitForChild("Template")

	Template.Visible = false

	local t = {}
	local v1 = nil
	local v2 = nil
	local WeatherSchedule = ReplicatedStorage:FindFirstChild("WeatherSchedule")
	local LuckDisplay = Template:Clone()

	LuckDisplay.Name = "LuckDisplay"
	LuckDisplay.Visible = true
	LuckDisplay.LayoutOrder = -1
	LuckDisplay.Image = "rbxassetid://132785761242424"
	LuckDisplay.ImageTransparency = 0
	LuckDisplay:SetAttribute("InspectType", "Luck")
	CollectionService:AddTag(LuckDisplay, "Inspect")
	LuckDisplay.Parent = ActiveEffects2

	local v3 = 0
	local StockFishDisplay = Template:Clone()

	StockFishDisplay.Name = "StockFishDisplay"
	StockFishDisplay.Visible = false
	StockFishDisplay.LayoutOrder = -2
	StockFishDisplay.Image = "rbxassetid://127163014827377"
	StockFishDisplay.ImageTransparency = 0
	StockFishDisplay.TimeDuration.Text = "x0"
	StockFishDisplay:SetAttribute("InspectType", "Stock")
	StockFishDisplay:SetAttribute("stockAmount", 0)
	StockFishDisplay:AddTag("Inspect")
	StockFishDisplay.Parent = ActiveEffects2

	local t2 = {}
	local t3 = {}

	local function refreshPotionIcons() --[[ refreshPotionIcons | Line: 86 | Upvalues: t3 (ref), PotionConfig (ref), t2 (copy), Template (copy), CollectionService (ref), ActiveEffects2 (copy), formatRemaining (ref) ]]
		local t = {}

		for v1, v2 in t3 do
			t[v1] = true

			local v3 = PotionConfig.Potions[v2.ConfigName]

			if v3 then
				local v4 = t2[v1]

				if not v4 then
					local v5 = Template:Clone()

					v5.Name = "Potion_" .. v1
					v5.Visible = true
					v5.LayoutOrder = -2
					v5:SetAttribute("InspectType", "Potion")
					v5:SetAttribute("PotionConfigName", v2.ConfigName)
					CollectionService:AddTag(v5, "Inspect")
					v5.Parent = ActiveEffects2
					t2[v1] = v5
					v4 = v5
				end

				v4.Image = v3.Icon
				v4:SetAttribute("PotionConfigName", v2.ConfigName)

				local TimeDuration = v4:FindFirstChild("TimeDuration")

				if TimeDuration then
					TimeDuration.Text = formatRemaining(v2.ExpiresAt)
				end
			end
		end

		for v6, v7 in t2 do
			if not t[v6] then
				v7:Destroy()
				t2[v6] = nil
			end
		end
	end

	local function refreshFishStockDisplay() --[[ refreshFishStockDisplay | Line: 121 | Upvalues: ReplicatedStorage (ref), StockFishDisplay (copy), HttpService (ref) ]]
		local v1 = ReplicatedStorage:GetAttribute("fishStocks")

		if not v1 or typeof(v1) ~= "string" then
			StockFishDisplay.Visible = false

			return
		end

		local ok, result = pcall(function() --[[ Line: 128 | Upvalues: HttpService (ref), v1 (copy) ]]
			return HttpService:JSONDecode(v1)
		end)

		if not ok then
			StockFishDisplay.Visible = false

			return
		end

		local sum = 0

		for v2, v3 in result do
			if typeof(v3) == "number" then
				sum = sum + v3
			end
		end

		StockFishDisplay.Visible = sum > 0
		StockFishDisplay:SetAttribute("stockAmount", sum)
		StockFishDisplay.TimeDuration.Text = ("x%*"):format(sum)
	end

	refreshFishStockDisplay()
	ReplicatedStorage:GetAttributeChangedSignal("fishStocks"):Connect(refreshFishStockDisplay)
	Remotes.ReplicatePotionEffects:On(function(p1) --[[ Line: 152 | Upvalues: t3 (ref), refreshPotionIcons (copy), t2 (copy) ]]
		print("[ActiveEffectsUI] ReplicatePotionEffects received, type:", (type(p1)))

		if type(p1) ~= "table" then
			print("[ActiveEffectsUI] snapshot is NOT a table, ignoring")

			return
		end

		for v1, v2 in p1 do
			print("[ActiveEffectsUI]   effect:", v1, "config:", v2.ConfigName, "expiresAt:", v2.ExpiresAt)
		end

		if next(p1) == nil then
			print("[ActiveEffectsUI]   snapshot is EMPTY")
		end

		t3 = p1
		refreshPotionIcons()
		print("[ActiveEffectsUI] refreshPotionIcons done, clones count:", #t2)
	end)
	print("[ActiveEffectsUI] Firing RequestPotionSnapshot")
	Remotes.RequestPotionSnapshot:Fire()

	local function applyEvent(p1, p2) --[[ applyEvent | Line: 173 | Upvalues: EventsConfig (ref), formatRemaining (ref) ]]
		local v1 = EventsConfig[p2.Name]

		if v1 then
			p1.Image = v1.Icon
		end

		local TimeDuration = p1:FindFirstChild("TimeDuration")

		if not TimeDuration then
			return
		end

		TimeDuration.Text = formatRemaining(p2.ExpiresAt)
	end

	local function refreshUpcoming() --[[ refreshUpcoming | Line: 184 | Upvalues: WeatherSchedule (ref), ReplicatedStorage (ref), v1 (ref), EventsConfig (ref), Template (copy), CollectionService (ref), ActiveEffects2 (copy), formatUpcoming (ref) ]]
		local v12 = WeatherSchedule

		if not v12 then
			local WeatherSchedule2 = ReplicatedStorage:FindFirstChild("WeatherSchedule")

			WeatherSchedule = WeatherSchedule2
			v12 = WeatherSchedule2
		end

		if v12 then
			local v2 = v12:GetAttribute("NextWeatherName")
			local v3 = v12:GetAttribute("NextWeatherTime")

			if v2 and (v2 ~= "" and v3) then
				if v2 == "ExclusiveLuckyHour" then
					if not v1 then
						return
					end

					v1:Destroy()
					v1 = nil
				else
					local v4 = EventsConfig[v2]

					if v4 then
						if not v1 then
							local Upcoming = Template:Clone()

							Upcoming.Name = "Upcoming"
							Upcoming.Visible = true
							Upcoming.LayoutOrder = 999
							Upcoming:SetAttribute("InspectType", "Event")
							CollectionService:AddTag(Upcoming, "Inspect")
							Upcoming.Parent = ActiveEffects2
							v1 = Upcoming
						end

						local v5 = v1

						v5.Image = v4.Icon
						v5:SetAttribute("EventName", v2)

						local TimeDuration = v5:FindFirstChild("TimeDuration")

						if not TimeDuration then
							return
						end

						TimeDuration.Text = formatUpcoming(v3)
					else
						if not v1 then
							return
						end

						v1:Destroy()
						v1 = nil
					end
				end
			else
				if not v1 then
					return
				end

				v1:Destroy()
				v1 = nil
			end
		else
			if not v1 then
				return
			end

			v1:Destroy()
			v1 = nil
		end
	end

	local function refreshELH() --[[ refreshELH | Line: 246 | Upvalues: WeatherSchedule (ref), ReplicatedStorage (ref), v2 (ref), ActiveEffects (ref), EventsConfig (ref), Template (copy), CollectionService (ref), ActiveEffects2 (copy), formatUpcoming (ref) ]]
		local v1 = WeatherSchedule

		if not v1 then
			local WeatherSchedule2 = ReplicatedStorage:FindFirstChild("WeatherSchedule")

			WeatherSchedule = WeatherSchedule2
			v1 = WeatherSchedule2
		end

		if v1 then
			local v22 = v1:GetAttribute("ELHTime")
			local v3 = false

			for v4, v5 in ActiveEffects.GetActive() do
				if v5.Name == "ExclusiveLuckyHour" then
					v3 = true

					break
				end
			end

			if v22 and not v3 then
				local ExclusiveLuckyHour = EventsConfig.ExclusiveLuckyHour

				if not ExclusiveLuckyHour then
					return
				end

				if not v2 then
					local ELHCountdown = Template:Clone()

					ELHCountdown.Name = "ELHCountdown"
					ELHCountdown.Visible = true
					ELHCountdown.LayoutOrder = 1000
					ELHCountdown.ImageTransparency = 0.4
					ELHCountdown:SetAttribute("InspectType", "Event")
					ELHCountdown:SetAttribute("EventName", "ExclusiveLuckyHour")
					CollectionService:AddTag(ELHCountdown, "Inspect")
					ELHCountdown.Parent = ActiveEffects2
					v2 = ELHCountdown
				end

				local v6 = v2

				v6.Image = ExclusiveLuckyHour.Icon

				local TimeDuration = v6:FindFirstChild("TimeDuration")

				if not TimeDuration then
					return
				end

				TimeDuration.Text = formatUpcoming(v22)
			else
				if not v2 then
					return
				end

				v2:Destroy()
				v2 = nil
			end
		else
			if not v2 then
				return
			end

			v2:Destroy()
			v2 = nil
		end
	end

	local function refresh() --[[ refresh | Line: 305 | Upvalues: ActiveEffects (ref), t (copy), Template (copy), CollectionService (ref), ActiveEffects2 (copy), EventsConfig (ref), formatRemaining (ref), refreshUpcoming (copy), refreshELH (copy) ]]
		local v1 = ActiveEffects.GetActive()
		local t2 = {}
		local t3 = {}

		for v2, v3 in v1 do
			table.insert(t2, v3.Name)
		end

		print("[ActiveEffectsUI] refresh \226\128\148 active events:", table.concat(t2, ", "))

		for v5, v6 in v1 do
			if v6.Name ~= "ExclusiveLuckyHour" then
				t3[v6.Id] = true

				local v7 = t[v6.Id]

				if not v7 then
					local v8 = Template:Clone()

					v8.Name = v6.Id
					v8.Visible = true
					v8:SetAttribute("InspectType", "Event")
					v8:SetAttribute("EventName", v6.Name)
					CollectionService:AddTag(v8, "Inspect")
					v8.Parent = ActiveEffects2
					t[v6.Id] = v8
					v7 = v8
				end

				local v9 = EventsConfig[v6.Name]

				if v9 then
					v7.Image = v9.Icon
				end

				local TimeDuration = v7:FindFirstChild("TimeDuration")

				if TimeDuration then
					TimeDuration.Text = formatRemaining(v6.ExpiresAt)
				end
			end
		end

		for v11, v12 in t do
			if not t3[v11] then
				v12:Destroy()
				t[v11] = nil
			end
		end

		refreshUpcoming()
		refreshELH()
	end

	ActiveEffects.Changed:Connect(refresh)
	refresh()

	if WeatherSchedule then
		WeatherSchedule.AttributeChanged:Connect(function() --[[ Line: 345 | Upvalues: refreshUpcoming (copy), refreshELH (copy) ]]
			refreshUpcoming()
			refreshELH()
		end)
	else
		local v4 = nil

		v4 = ReplicatedStorage.ChildAdded:Connect(function(p1) --[[ Line: 351 | Upvalues: WeatherSchedule (ref), refreshUpcoming (copy), refreshELH (copy), v4 (ref) ]]
			if p1.Name ~= "WeatherSchedule" then
				return
			end

			WeatherSchedule = p1
			p1.AttributeChanged:Connect(function() --[[ Line: 354 | Upvalues: refreshUpcoming (ref), refreshELH (ref) ]]
				refreshUpcoming()
				refreshELH()
			end)
			refreshUpcoming()

			if not v4 then
				return
			end

			v4:Disconnect()
		end)
	end

	RunService.Heartbeat:Connect(function(p1) --[[ Line: 366 | Upvalues: ActiveEffects (ref), t (copy), formatRemaining (ref), WeatherSchedule (ref), v1 (ref), formatUpcoming (ref), v2 (ref), v3 (ref), getPlayerPoolLuck (ref), Players (ref), LuckDisplay (copy), t3 (ref), t2 (copy) ]]
		debug.profilebegin("UECS/ActiveEffectsUI.Heartbeat")

		for v12, v22 in ActiveEffects.GetActive() do
			local v32 = t[v22.Id]

			if v32 then
				local TimeDuration = v32:FindFirstChild("TimeDuration")

				if TimeDuration then
					TimeDuration.Text = formatRemaining(v22.ExpiresAt)
				end
			end
		end

		local v4 = WeatherSchedule
		local v5 = v1

		if v4 and v5 then
			local v6 = v4:GetAttribute("NextWeatherTime")

			if v6 then
				local TimeDuration = v5:FindFirstChild("TimeDuration")

				if TimeDuration then
					TimeDuration.Text = formatUpcoming(v6)
				end
			end
		end

		local v7 = WeatherSchedule
		local v8 = v2

		if v7 and v8 then
			local v9 = v7:GetAttribute("ELHTime")

			if v9 then
				local TimeDuration = v8:FindFirstChild("TimeDuration")

				if TimeDuration then
					TimeDuration.Text = formatUpcoming(v9)
				end
			end
		end

		v3 = v3 + p1

		if v3 >= 0.5 then
			v3 = 0

			local v10 = getPlayerPoolLuck(Players.LocalPlayer)
			local TimeDuration = LuckDisplay:FindFirstChild("TimeDuration")

			if TimeDuration and v10 >= 1000 then
				local format = string.format

				TimeDuration.Text = format("x%s", (tostring((math.floor(v10)))))
			elseif TimeDuration then
				TimeDuration.Text = string.format("x%.1f", v10)
			end
		end

		for v12, v13 in t3 do
			local v14 = t2[v12]

			if v14 then
				local TimeDuration = v14:FindFirstChild("TimeDuration")

				if TimeDuration then
					TimeDuration.Text = formatRemaining(v13.ExpiresAt)
				end
			end
		end

		debug.profileend()
	end)
end

return t