-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ContentProvider = game:GetService("ContentProvider")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local SoundService = game:GetService("SoundService")
local TweenService = game:GetService("TweenService")
local DecorationConfig = require(ReplicatedStorage.shared.config.DecorationConfig)
local FishingFloatsConfig = require(ReplicatedStorage.shared.config.FishingFloatsConfig)
local FloatCrateAnimation = require(ReplicatedStorage.shared.module.FloatCrateAnimation)
local FloatLootboxConfig = require(ReplicatedStorage.shared.config.FloatLootboxConfig)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local resolveDecorationModel = require(ReplicatedStorage.shared.util.resolveDecorationModel)
local tweenModelScale = require(ReplicatedStorage.shared.util.tweenModelScale)
local ok, result = pcall(function() --[[ Line: 31 | Upvalues: ReplicatedStorage (copy) ]]
	return require(ReplicatedStorage.client.SFX)
end)
local LocalPlayer = Players.LocalPlayer
local PlayerGui = LocalPlayer:WaitForChild("PlayerGui")

task.spawn(function() --[[ Line: 49 | Upvalues: ContentProvider (copy) ]]
	local Animation = Instance.new("Animation")

	Animation.AnimationId = "rbxassetid://95290247960196"
	ContentProvider:PreloadAsync({ Animation })
	Animation:Destroy()
end)

local function playSoundId(p1) --[[ playSoundId | Line: 66 | Upvalues: ok (copy), result (copy) ]]
	if not (ok and (result and result.new)) then
		return
	end

	result.new(p1, 0.5)
end

local function playSFX(p1) --[[ playSFX | Line: 72 | Upvalues: SoundService (copy) ]]
	local SFX = SoundService:FindFirstChild("SFX")
	local v1 = if SFX then SFX:FindFirstChild(p1) else SFX

	if not (v1 and v1:IsA("Sound")) then
		return
	end

	local v2 = v1:Clone()

	v2.PlayOnRemove = true
	v2.Parent = SoundService
	v2:Destroy()
end

local t = {
	Common = Color3.fromRGB(180, 180, 180),
	Rare = Color3.fromRGB(0, 120, 255),
	Epic = Color3.fromRGB(160, 40, 255),
	Legendary = Color3.fromRGB(255, 170, 0),
	Mythic = Color3.fromRGB(255, 50, 50),
	Godly = Color3.fromRGB(0, 255, 255)
}
local t2 = {
	Godly = "RarityBestFX",
	Mythic = "RarityBestFX",
	Legendary = "RarityMidFX",
	Epic = "RarityMidFX",
	Rare = "RarityWorstFX",
	Common = "RarityWorstFX"
}
local t3 = {
	CommonFloatCrate = "Common",
	RareFloatCrate = "Rare",
	EpicFloatCrate = "Epic",
	LegendaryFloatCrate = "Legendary",
	MythicFloatCrate = "Mythic",
	FunctionalObjectsCrate = "Mythic"
}

local function getTierColor(p1) --[[ getTierColor | Line: 118 | Upvalues: FishingFloatsConfig (copy), t (copy) ]]
	return FishingFloatsConfig.TierColors and FishingFloatsConfig.TierColors[p1] or (t[p1] or Color3.fromRGB(200, 200, 200))
end

local function normalizeModelScale(p1, p2) --[[ normalizeModelScale | Line: 143 ]]
	local _, v1 = p1:GetBoundingBox()
	local v2 = math.max(v1.X, v1.Y, v1.Z)

	if not (v2 <= 0) then
		p1:ScaleTo(p1:GetScale() * (p2 / v2))
	end
end

local function getRewardVisual(p1, p2, p3) --[[ getRewardVisual | Line: 152 | Upvalues: DecorationConfig (copy), FishingFloatsConfig (copy), t (copy), t2 (copy) ]]
	if p1 == "Decoration" then
		local v1 = DecorationConfig[p2]
		local v2 = if v1 then v1.Rarity else v1
		local v3 = v2 and v2.power or 1
		local t3 = {}

		t3.displayName = v1 and v1.DisplayName or p2
		t3.tierLabel = v2 and v2.displayName or "Common"
		t3.color = v2 and v2.rarityColor or Color3.fromRGB(200, 200, 200)
		t3.fxName = if v3 >= 6 then "RarityBestFX" elseif v3 >= 4 then "RarityMidFX" else "RarityWorstFX"
		t3.glow = v3 >= 5

		return t3
	end

	local v9 = p3 or "Common"
	local v10 = FishingFloatsConfig.Floats[p2]
	local t3 = {}

	t3.displayName = if v10 then v10.DisplayName or p2 else p2
	t3.tierLabel = v9
	t3.color = FishingFloatsConfig.TierColors and FishingFloatsConfig.TierColors[v9] or (t[v9] or Color3.fromRGB(200, 200, 200))
	t3.fxName = t2[v9] or "RarityWorstFX"
	t3.glow = if v9 == "Godly" or v9 == "Mythic" then true else v9 == "Legendary"

	return t3
end

local function buildCyclePool(p1, p2, p3, p4) --[[ buildCyclePool | Line: 187 | Upvalues: FishingFloatsConfig (copy) ]]
	local t = {}

	if p1 == "Decoration" then
		for v2, v3 in if p2 then p2 else {} do
			table.insert(t, {
				kind = p1,
				name = v3.ConfigName
			})
		end

		if #t == 0 then
			table.insert(t, {
				kind = p1,
				name = p3
			})
		end
	else
		for v4, v5 in FishingFloatsConfig.Floats do
			if p4 and (v5.Tiers and v5.Tiers[p4]) then
				table.insert(t, {
					kind = p1,
					name = v4,
					tier = p4
				})
			end
		end

		if #t == 0 then
			table.insert(t, {
				kind = p1,
				name = p3,
				tier = p4
			})
		end
	end

	return t
end

local function anchorModel(p1) --[[ anchorModel | Line: 226 ]]
	for v1, v2 in p1:GetDescendants() do
		if v2:IsA("BasePart") then
			v2.Anchored = true
			v2.CanCollide = false
			v2.CanTouch = false
			v2.CanQuery = false
		end
	end
end

local gui = ReplicatedStorage.shared.model:FindFirstChild("gui")

if not gui then
	gui = Instance.new("Folder")
	gui.Name = "gui"
	gui.Parent = ReplicatedStorage.shared.model
end

local FloatRevealBillboard = gui:FindFirstChild("FloatRevealBillboard")
local v1

if FloatRevealBillboard then
	v1 = FloatRevealBillboard
else
	local FloatRevealBillboard2 = Instance.new("BillboardGui")

	FloatRevealBillboard2.Name = "FloatRevealBillboard"
	FloatRevealBillboard2.Size = UDim2.new(6, 0, 2, 0)
	FloatRevealBillboard2.StudsOffset = Vector3.new(0, 4, 0)
	FloatRevealBillboard2.AlwaysOnTop = true

	local Background = Instance.new("Frame")

	Background.Name = "Background"
	Background.Size = UDim2.new(1, 0, 1, 0)
	Background.BackgroundColor3 = Color3.fromRGB(15, 15, 25)
	Background.BackgroundTransparency = 0.3
	Background.BorderSizePixel = 0
	Background.Parent = FloatRevealBillboard2
	Instance.new("UICorner", Background).CornerRadius = UDim.new(0.15, 0)

	local NameLabel = Instance.new("TextLabel")

	NameLabel.Name = "NameLabel"
	NameLabel.Size = UDim2.new(1, 0, 0.55, 0)
	NameLabel.BackgroundTransparency = 1
	NameLabel.Text = "FloatName"
	NameLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
	NameLabel.TextScaled = true
	NameLabel.Font = Enum.Font.GothamBold
	NameLabel.Parent = Background

	local TierLabel = Instance.new("TextLabel")

	TierLabel.Name = "TierLabel"
	TierLabel.Size = UDim2.new(1, 0, 0.35, 0)
	TierLabel.Position = UDim2.new(0, 0, 0.6, 0)
	TierLabel.BackgroundTransparency = 1
	TierLabel.Text = "Tier"
	TierLabel.TextColor3 = Color3.fromRGB(180, 180, 180)
	TierLabel.TextScaled = true
	TierLabel.Font = Enum.Font.GothamMedium
	TierLabel.Parent = Background
	FloatRevealBillboard2.Parent = gui
	warn("[FloatLootboxRoll] Created FloatRevealBillboard template in shared.gui")
	v1 = FloatRevealBillboard2
end

local floatsLootboxAnim = ReplicatedStorage.shared.model:FindFirstChild("floatsLootboxAnim")
local float = ReplicatedStorage.shared.model:FindFirstChild("float")

local function getFloatModel(p1, p2) --[[ getFloatModel | Line: 305 | Upvalues: FishingFloatsConfig (copy), floatsLootboxAnim (copy), float (copy) ]]
	local v1 = FishingFloatsConfig.Floats[p1]

	if v1 and (v1.ModelPrefix and (p2 and floatsLootboxAnim)) then
		local v2 = floatsLootboxAnim:FindFirstChild(v1.ModelPrefix .. "_" .. p2)

		if v2 then
			return v2:Clone()
		end

		local v3 = floatsLootboxAnim:FindFirstChild(v1.ModelPrefix .. "_" .. string.lower(p2))

		if v3 then
			return v3:Clone()
		end
	end

	if float then
		return float:Clone()
	end

	warn((("[FloatLootboxRoll] No model found for float \"%*\" tier \"%*\" and no default float model"):format(p1, p2 or "?")))

	return nil
end

local function getDecorationModel(p1) --[[ getDecorationModel | Line: 333 | Upvalues: resolveDecorationModel (copy) ]]
	local v1 = resolveDecorationModel(p1)

	if not v1 then
		warn((("[FloatLootboxRoll] No PlaceableDecorations model for \"%*\""):format(p1)))

		return nil
	end

	local v2 = v1:Clone()
	local _, v3 = v2:GetBoundingBox()
	local v4 = math.max(v3.X, v3.Y, v3.Z)

	if not (v4 <= 0) then
		v2:ScaleTo(v2:GetScale() * (3 / v4))
	end

	return v2
end

local function getRewardModel(p1) --[[ getRewardModel | Line: 344 | Upvalues: resolveDecorationModel (copy), getFloatModel (copy) ]]
	if p1.kind ~= "Decoration" then
		return getFloatModel(p1.name, p1.tier)
	end

	local name = p1.name
	local v1 = resolveDecorationModel(name)

	if not v1 then
		warn((("[FloatLootboxRoll] No PlaceableDecorations model for \"%*\""):format(name)))

		return nil
	end

	local v2 = v1:Clone()
	local _, v3 = v2:GetBoundingBox()
	local v4 = math.max(v3.X, v3.Y, v3.Z)

	if not (v4 <= 0) then
		v2:ScaleTo(v2:GetScale() * (3 / v4))
	end

	return v2
end

local function chargeUpModel(p1, p2) --[[ chargeUpModel | Line: 355 | Upvalues: RunService (copy) ]]
	local v1 = p1:GetPivot()
	local v2 = p1:GetScale()
	local Highlight = Instance.new("Highlight")

	Highlight.FillColor = Color3.fromRGB(255, 255, 255)
	Highlight.OutlineColor = Color3.fromRGB(255, 255, 255)
	Highlight.FillTransparency = 0.6
	Highlight.OutlineTransparency = 0
	Highlight.Parent = p1

	local sum = 0

	while sum < p2 do
		sum = sum + RunService.RenderStepped:Wait()

		local v3 = math.min(sum / p2, 1)

		p1:ScaleTo(v2 * (1 - (1 - v3) * (1 - v3) + 1))

		local v4 = v3 * 1.3 + 0.3
		local v5 = (math.random() - 0.5) * v4
		local v6 = (math.random() - 0.5) * v4

		p1:PivotTo(v1 + Vector3.new(v5, v6, (math.random() - 0.5) * v4))
		Highlight.FillTransparency = 0.6 - v3 * 0.5
	end

	Highlight:Destroy()
end

local function rollAndReveal(p1, p2, p3, p4, p5, p6) --[[ rollAndReveal | Line: 388 | Upvalues: playSFX (copy), ok (copy), result (copy), resolveDecorationModel (copy), getFloatModel (copy), anchorModel (copy), tweenModelScale (copy), v1 (ref), PlayerGui (copy), ReplicatedStorage (copy), TweenService (copy) ]]
	local sum = 0.05

	if p5 then
		playSFX("Reward Claim")
	end

	if p5 and (p6 and p6.Roll) then
		local Roll = p6.Roll

		if ok and (result and result.new) then
			result.new(Roll, 0.5)
		end
	end

	for i = 1, 15 do
		local v12

		if p5 and not (p6 and p6.Roll) and (ok and (result and (result.Sounds and result.Sounds.Roll))) then
			result.new(result.Sounds.Roll, 0.5)
		end

		local v2 = sum
		local v3 = p4[math.random(1, #p4)]

		if v3.kind == "Decoration" then
			local name = v3.name
			local v4 = resolveDecorationModel(name)

			if v4 then
				local v5 = v4:Clone()
				local _, v6 = v5:GetBoundingBox()
				local v7 = math.max(v6.X, v6.Y, v6.Z)

				if not (v7 <= 0) then
					v5:ScaleTo(v5:GetScale() * (3 / v7))
				end

				v12 = v5
			else
				warn((("[FloatLootboxRoll] No PlaceableDecorations model for \"%*\""):format(name)))
				v12 = nil
			end
		else
			v12 = getFloatModel(v3.name, v3.tier)
		end

		if v12 then
			v12:ScaleTo(v12:GetScale() / 3)
			anchorModel(v12)
			v12:PivotTo(p1 * (v12:GetPivot() - v12:GetPivot().Position))
			v12.Parent = workspace
			tweenModelScale(v12, TweenInfo.new(v2 * 0.66), v12:GetScale() * 2.5)
			task.spawn(function() --[[ Line: 432 | Upvalues: tweenModelScale (ref), v12 (copy), v2 (copy) ]]
				tweenModelScale(v12, TweenInfo.new(v2 * 0.33), v12:GetScale() / 3)
				v12:Destroy()
			end)
			task.wait(v2)
			sum = sum + 0.01
		end
	end

	task.wait(0.1)

	if p5 and (p6 and p6.Reward) then
		local Reward = p6.Reward

		if ok and (result and result.new) then
			result.new(Reward, 0.5)
		end
	elseif p5 then
		if ok and (result and (result.Sounds and result.Sounds.Luck)) then
			result.new(result.Sounds.Luck, 0.5)
		end

		playSFX("RewardApper")
	end

	local v8

	if p2.kind == "Decoration" then
		local name = p2.name
		local v9 = resolveDecorationModel(name)

		if v9 then
			local v10 = v9:Clone()
			local _, v11 = v10:GetBoundingBox()
			local v122 = math.max(v11.X, v11.Y, v11.Z)

			if not (v122 <= 0) then
				v10:ScaleTo(v10:GetScale() * (3 / v122))
			end

			v8 = v10
		else
			warn((("[FloatLootboxRoll] No PlaceableDecorations model for \"%*\""):format(name)))
			v8 = nil
		end
	else
		v8 = getFloatModel(p2.name, p2.tier)
	end

	if not v8 then
		return nil
	end

	local v13 = v8:GetScale()

	v8:ScaleTo(v13 / 3)
	anchorModel(v8)
	v8:PivotTo(p1 * (v8:GetPivot() - v8:GetPivot().Position))
	v8.Parent = workspace

	local v14 = v8.PrimaryPart or v8:FindFirstChildWhichIsA("BasePart")

	if v14 then
		local v15 = v1:Clone()

		v15.Adornee = v14
		v15.Parent = PlayerGui

		local v16 = v15:FindFirstChild("Background") or v15
		local NameLabel = v16:FindFirstChild("NameLabel")

		if NameLabel then
			NameLabel.Text = p3.displayName
			NameLabel.TextColor3 = p3.color
		end

		local TierLabel = v16:FindFirstChild("TierLabel")

		if TierLabel then
			TierLabel.Text = p3.tierLabel
			TierLabel.TextColor3 = p3.color
		end

		v8.Destroying:Connect(function() --[[ Line: 488 | Upvalues: v15 (copy) ]]
			v15:Destroy()
		end)
	end

	local color = p3.color
	local LuckyblockRollRewardRarity = ReplicatedStorage.shared.model:FindFirstChild("LuckyblockRollRewardRarity")

	if LuckyblockRollRewardRarity then
		local v17 = LuckyblockRollRewardRarity:FindFirstChild(p3.fxName)

		if v17 then
			local v18 = v17:Clone()

			for v19, v20 in v18:GetDescendants() do
				if v20:IsA("ParticleEmitter") then
					v20.Color = ColorSequence.new(color)
				end

				if v20:IsA("BasePart") then
					v20.Transparency = 1
				end
			end

			if v18:IsA("BasePart") then
				v18.Transparency = 1
			end

			local v21 = v8.PrimaryPart or v8:FindFirstChildWhichIsA("BasePart")

			if v21 and v18:IsA("BasePart") then
				v18.CFrame = v8:GetPivot()

				local WeldConstraint = Instance.new("WeldConstraint")

				WeldConstraint.Part0 = v18
				WeldConstraint.Part1 = v21
				WeldConstraint.Parent = v18
				v18.Anchored = false
			end

			v18.Parent = v8

			for v22, v23 in v18:GetDescendants() do
				if v23:IsA("ParticleEmitter") then
					v23.Enabled = false
					v23.Rate = 0
					v23:Emit(v23:GetAttribute("EmitCount") or 5)
				end
			end

			task.delay(2, function() --[[ Line: 538 | Upvalues: v18 (copy) ]]
				if not (v18 and v18.Parent) then
					return
				end

				for v1, v2 in v18:GetDescendants() do
					if v2:IsA("ParticleEmitter") then
						v2.Enabled = false
					end
				end
			end)
			task.delay(4, function() --[[ Line: 547 | Upvalues: v18 (copy) ]]
				if not (v18 and v18.Parent) then
					return
				end

				v18:Destroy()
			end)
		end
	end

	if p3.glow then
		local v24 = v8.PrimaryPart or v8:FindFirstChildWhichIsA("BasePart")

		if v24 then
			local PointLight = Instance.new("PointLight")

			PointLight.Color = color
			PointLight.Brightness = 1.5
			PointLight.Range = 10
			PointLight.Parent = v24
			TweenService:Create(PointLight, TweenInfo.new(3, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
				Brightness = 0
			}):Play()
			task.delay(3.5, function() --[[ Line: 567 | Upvalues: PointLight (copy) ]]
				if not (PointLight and PointLight.Parent) then
					return
				end

				PointLight:Destroy()
			end)
		end
	end

	tweenModelScale(v8, TweenInfo.new(1), v13 * 1.5)
	task.wait(1)

	return v8
end

local function spinModel(p1, p2) --[[ spinModel | Line: 586 | Upvalues: RunService (copy) ]]
	if not (p1.PrimaryPart or p1:FindFirstChildWhichIsA("BasePart")) then
		return
	end

	local v2 = p1:GetPivot()
	local Position = v2.Position
	local sum = 0
	local v3 = v2 - Position

	while sum < p2 do
		sum = sum + RunService.RenderStepped:Wait()

		local v4 = math.min(sum / p2, 1) * 6.283185307179586

		p1:PivotTo(CFrame.new(Position) * CFrame.Angles(0, v4, 0) * v3)
	end

	p1:PivotTo(v2)
end

local function playRollAnimation(p1) --[[ playRollAnimation | Line: 608 | Upvalues: LocalPlayer (copy), getRewardVisual (copy), buildCyclePool (copy), FloatLootboxConfig (copy), FloatCrateAnimation (copy), ok (copy), result (copy), playSFX (copy), t3 (copy), FishingFloatsConfig (copy), t (copy), ReplicatedStorage (copy), t2 (copy), tweenModelScale (copy), rollAndReveal (copy), spinModel (copy), Remotes (copy) ]]
	local isUserId = p1.OwnerUserId == LocalPlayer.UserId
	local v1 = p1.RewardKind or "Float"
	local v2 = if v1 == "Decoration" then p1.DecorationConfigName else p1.FloatName
	local v3 = getRewardVisual(v1, v2, p1.Tier)
	local v4 = buildCyclePool(v1, p1.AllDecorationDrops, v2, p1.Tier)
	local v5 = FloatLootboxConfig.Lootboxes[p1.LootboxConfigName or ""]
	local v6 = if v5 then v5.Sounds else v5
	local WorldPosition = p1.WorldPosition
	local v7 = WorldPosition and Vector3.new(WorldPosition[1], WorldPosition[2], WorldPosition[3]) or Vector3.new(0, 5, 0)
	local v11 = CFrame.new(v7 + Vector3.new(0, 3, 0))
	local v12 = nil

	if p1.PlacementId then
		local v13 = workspace:FindFirstChild("PlacedLootbox_" .. p1.PlacementId)

		if v13 and v13:IsA("Model") then
			v12 = v13
		end
	end

	if not v12 then
		for v14, v15 in workspace:GetDescendants() do
			if v15:IsA("Model") and (v15:FindFirstChildWhichIsA("AnimationController") and (v15:GetPivot().Position - v7).Magnitude < 5) then
				v12 = v15

				break
			end
		end
	end

	if v12 then
		local v16 = FloatCrateAnimation.resume(v12, p1.LootboxConfigName)
		local v17 = nil

		if not v16 then
			local v18 = v12:FindFirstChildWhichIsA("AnimationController")

			if v18 then
				v17 = Instance.new("Animation")
				v17.AnimationId = "rbxassetid://95290247960196"
				v16 = v18:LoadAnimation(v17)
				v16:Play()
			end
		end

		if v16 then
			local Length = v16.Length

			if Length == 0 then
				local sum = 0

				while v16.Length == 0 and sum < 2 do
					task.wait(0.05)
					sum = sum + 0.05
				end

				Length = v16.Length
			end

			if Length <= 0 then
				Length = 2
			end

			local v19 = Length - v16.TimePosition - 0.05 - 1

			task.wait((math.max(v19, 0)))

			if isUserId and (v6 and v6.Open) then
				local Open = v6.Open

				if ok and (result and result.new) then
					result.new(Open, 0.5)
				end
			elseif isUserId then
				playSFX("Chest opening")
			end

			task.wait(1)
			v16:AdjustSpeed(0)

			local v21 = t3[p1.LootboxConfigName or ""] or "Common"
			local v22 = FishingFloatsConfig.TierColors and FishingFloatsConfig.TierColors[v21] or (t[v21] or Color3.fromRGB(200, 200, 200))
			local LuckyblockRollRewardRarity = ReplicatedStorage.shared.model:FindFirstChild("LuckyblockRollRewardRarity")

			if LuckyblockRollRewardRarity then
				local v23 = LuckyblockRollRewardRarity:FindFirstChild(t2[v21] or "RarityWorstFX")

				if v23 then
					local v24 = v23:Clone()

					for v25, v26 in v24:GetDescendants() do
						if v26:IsA("ParticleEmitter") then
							v26.Color = ColorSequence.new(v22)
							v26.Enabled = false
							v26.Rate = 0
							v26:Emit(v26:GetAttribute("EmitCount") or 5)
						end

						if v26:IsA("BasePart") then
							v26.Transparency = 1
						end
					end

					if v24:IsA("BasePart") then
						v24.Transparency = 1
					end

					local v27 = v12.PrimaryPart or v12:FindFirstChildWhichIsA("BasePart")

					if v27 and v24:IsA("BasePart") then
						v24.CFrame = v12:GetPivot()

						local WeldConstraint = Instance.new("WeldConstraint")

						WeldConstraint.Part0 = v24
						WeldConstraint.Part1 = v27
						WeldConstraint.Parent = v24
						v24.Anchored = false
					end

					v24.Parent = v12
				end
			end

			task.delay(3, function() --[[ Line: 752 | Upvalues: tweenModelScale (ref), v12 (ref), v16 (ref), v17 (ref) ]]
				tweenModelScale(v12, TweenInfo.new(0.7, Enum.EasingStyle.Back, Enum.EasingDirection.In), 0.01)
				task.wait(0.7)
				v16:Stop()

				if v17 then
					v17:Destroy()
				end

				v12:Destroy()
			end)
		end
	end

	local v28 = rollAndReveal(v11, {
		kind = v1,
		name = v2,
		tier = p1.Tier
	}, v3, v4, isUserId, v6)

	if v28 then
		spinModel(v28, 0.6)
		task.wait(1.5)
		v28:Destroy()
	end

	if not isUserId then
		return
	end

	Remotes.ClaimFloatLootboxReward:Fire(p1.RewardUID)
end

return {
	Init = function(p1) --[[ Init | Line: 792 | Upvalues: Remotes (copy), playRollAnimation (copy) ]]
		Remotes.FloatLootboxRollResult:On(function(p1) --[[ Line: 793 | Upvalues: playRollAnimation (ref) ]]
			if type(p1) ~= "table" then
				return
			end

			if type(if p1.RewardKind == "Decoration" then p1.DecorationConfigName else p1.FloatName) == "string" then
				playRollAnimation(p1)
			end
		end)
	end
}