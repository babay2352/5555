-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ContextActionService = game:GetService("ContextActionService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local MountConfig = require(ReplicatedStorage.shared.config.MountConfig)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local ThrowZoneState = require(ReplicatedStorage.client.ThrowZoneState)
local bindToButtonPress = require(ReplicatedStorage.shared.util.bindToButtonPress)
local mountState = require(ReplicatedStorage.shared.util.mountState)
local notifications = require(ReplicatedStorage.shared.module.notifications)
local t = {
	UECS = nil
}
local Q = Enum.KeyCode.Q
local ButtonY = Enum.KeyCode.ButtonY

local function ownedMountConfigs() --[[ ownedMountConfigs | Line: 70 | Upvalues: ClientPlayerData (copy), MountConfig (copy) ]]
	local t = {}

	for v2, v3 in ClientPlayerData.serverProfile:getState().inventory or {} do
		if v3.Category == "Mount" and ((v3.Stack or 0) > 0 and MountConfig[v3.ConfigName]) then
			t[v3.ConfigName] = MountConfig[v3.ConfigName]
		end
	end

	return t
end

local function ownsAnyMount() --[[ ownsAnyMount | Line: 81 | Upvalues: ownedMountConfigs (copy) ]]
	return next((ownedMountConfigs())) ~= nil
end

local function equippedMountConfig() --[[ equippedMountConfig | Line: 88 | Upvalues: ownedMountConfigs (copy), ClientPlayerData (copy) ]]
	local v1 = ownedMountConfigs()
	local v2 = ClientPlayerData.serverProfile:getState().lastMountId or ""

	if v1[v2] then
		return v1[v2]
	end

	local v3 = (-1 / 0)
	local v4 = nil

	for v5, v6 in v1 do
		if v3 < v6.WalkSpeed then
			v3 = v6.WalkSpeed
			v4 = v6
		end
	end

	return v4
end

local function openMountsWindow() --[[ openMountsWindow | Line: 106 | Upvalues: t (copy) ]]
	local UECS = t.UECS

	if UECS then
		local v1 = UECS:WaitForAnyComponent("UIFrameOpener")

		v1.OpenedUIComponent:Set((UECS:WaitForAnyComponent("MountsUI")))
	end
end

local function toggleMount() --[[ toggleMount | Line: 116 | Upvalues: mountState (copy), Players (copy), ownedMountConfigs (copy), notifications (copy), openMountsWindow (copy), Remotes (copy) ]]
	if mountState.getRiddenConfig(Players.LocalPlayer) then
		Remotes.RequestToggleMount:Fire()

		return
	end

	if next((ownedMountConfigs())) ~= nil then
		Remotes.RequestToggleMount:Fire()
	else
		notifications:Send("You don\'t own any mounts!")
		task.spawn(openMountsWindow)
	end
end

local function updateGamepadBind() --[[ updateGamepadBind | Line: 127 | Upvalues: ThrowZoneState (copy), ContextActionService (copy), bindToButtonPress (copy), ButtonY (copy), toggleMount (copy) ]]
	if ThrowZoneState.InZone then
		ContextActionService:UnbindAction("ToggleMountGamepad")
	else
		bindToButtonPress("ToggleMountGamepad", ButtonY, toggleMount, 1000)
	end
end

local function setupButton() --[[ setupButton | Line: 137 | Upvalues: Players (copy), mountState (copy), ownedMountConfigs (copy), toggleMount (copy), t (copy), ThrowZoneState (copy), openMountsWindow (copy), equippedMountConfig (copy), ClientPlayerData (copy) ]]
	local MainUI = Players.LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("MainUI", 30)
	local v1 = if MainUI then MainUI:WaitForChild("HUD", 30) else MainUI
	local v2 = v1 and v1:WaitForChild("MountKeybind", 30)
	local v3 = if v2 then v2:WaitForChild("ToggleMount", 30) else v2

	if not (v3 and v3:IsA("GuiButton")) then
		warn("[MountInput] MainUI.HUD.MountKeybind.ToggleMount missing or not a button")

		return
	end

	v3.Activated:Connect(function() --[[ Line: 152 | Upvalues: mountState (ref), Players (ref), ownedMountConfigs (ref), toggleMount (ref), t (ref) ]]
		if mountState.getRiddenConfig(Players.LocalPlayer) then
			toggleMount()

			return
		end

		if next((ownedMountConfigs())) ~= nil then
			toggleMount()

			return
		end

		local UECS = t.UECS

		if UECS then
			local v2 = UECS:WaitForAnyComponent("UIFrameOpener")

			v2.OpenedUIComponent:Set((UECS:WaitForAnyComponent("MountsUI")))
		end
	end)

	local GamepadHint = Instance.new("Frame")

	GamepadHint.Name = "GamepadHint"
	GamepadHint.BackgroundTransparency = 1
	GamepadHint.AnchorPoint = Vector2.new(1, 0.5)
	GamepadHint.Position = UDim2.new(0, -4, 0.5, 0)
	GamepadHint.SizeConstraint = Enum.SizeConstraint.RelativeYY
	GamepadHint.Size = UDim2.fromScale(0.55, 0.55)

	local Icon = Instance.new("ImageLabel")

	Icon.Name = "Icon"
	Icon.BackgroundTransparency = 1
	Icon.Size = UDim2.fromScale(1, 1)
	Icon:SetAttribute("EnumString", "ButtonY")
	Icon:AddTag("GamepadControl")
	Icon.Parent = GamepadHint
	GamepadHint.Parent = v3

	local function refreshHint() --[[ refreshHint | Line: 183 | Upvalues: GamepadHint (copy), ThrowZoneState (ref) ]]
		GamepadHint.Visible = not ThrowZoneState.InZone
	end

	GamepadHint.Visible = not ThrowZoneState.InZone
	ThrowZoneState.OnChanged:Connect(refreshHint)

	local ChangeMount = v3:FindFirstChild("ChangeMount")

	if ChangeMount and ChangeMount:IsA("GuiButton") then
		ChangeMount.Activated:Connect(openMountsWindow)
	else
		warn("[MountInput] ToggleMount.ChangeMount missing or not a button")
	end

	local v4 = v3:FindFirstChildWhichIsA("TextLabel", true)

	if v4 then
		v4.Text = "Mounts"
	end

	local Frame = v3:FindFirstChild("Frame")
	local v5 = Frame and Frame:FindFirstChild("ImageLabel")
	local v6 = Frame and Frame:FindFirstChild("Price")

	if not (v5 and v5:IsA("ImageLabel")) then
		warn("[MountInput] ToggleMount.Frame.ImageLabel missing")
	end

	if not (v6 and v6:IsA("GuiObject")) then
		warn("[MountInput] ToggleMount.Frame.Price missing")
	end

	local function refreshTile() --[[ refreshTile | Line: 215 | Upvalues: equippedMountConfig (ref), v5 (copy), v6 (copy), ChangeMount (copy) ]]
		local v1 = equippedMountConfig()

		if v5 and v5:IsA("ImageLabel") then
			v5.Image = if v1 then v1.Icon else ""
			v5.Visible = v1 ~= nil
		end

		if v6 and v6:IsA("GuiObject") then
			v6.Visible = v1 == nil
		end

		if not (ChangeMount and ChangeMount:IsA("GuiObject")) then
			return
		end

		ChangeMount.Visible = v1 ~= nil
	end

	refreshTile()
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 229 ]]
		return p1.lastMountId
	end, refreshTile)
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 232 ]]
		return p1.inventory
	end, refreshTile)

	if not v2:IsA("GuiObject") then
		return
	end

	local function refreshVisibility() --[[ refreshVisibility | Line: 245 | Upvalues: ClientPlayerData (ref), v2 (copy) ]]
		v2.Visible = (ClientPlayerData.serverProfile:getState().rebirthLevel or 0) >= 2
	end

	v2.Visible = (ClientPlayerData.serverProfile:getState().rebirthLevel or 0) >= 2
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 250 ]]
		return p1.rebirthLevel
	end, refreshVisibility)
end

function t.Init(p1) --[[ Init | Line: 256 | Upvalues: bindToButtonPress (copy), Q (copy), toggleMount (copy), ThrowZoneState (copy), ContextActionService (copy), ButtonY (copy), updateGamepadBind (copy), setupButton (copy) ]]
	bindToButtonPress("ToggleMount", Q, toggleMount)

	if ThrowZoneState.InZone then
		ContextActionService:UnbindAction("ToggleMountGamepad")
	else
		bindToButtonPress("ToggleMountGamepad", ButtonY, toggleMount, 1000)
	end

	ThrowZoneState.OnChanged:Connect(updateGamepadBind)
	setupButton()
end

return t