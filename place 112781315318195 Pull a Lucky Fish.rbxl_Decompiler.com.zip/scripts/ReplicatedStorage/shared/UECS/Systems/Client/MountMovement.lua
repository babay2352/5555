-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local Workspace = game:GetService("Workspace")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local mountState = require(ReplicatedStorage.shared.util.mountState)
local t = {
	UECS = nil
}
local LocalPlayer = Players.LocalPlayer
local v1 = 0
local v2 = Vector3.new(0, 0, 0)
local v3 = nil

local function getControls() --[[ getControls | Line: 58 | Upvalues: v3 (ref), LocalPlayer (copy) ]]
	if v3 then
		return v3
	end

	local PlayerScripts = LocalPlayer:FindFirstChild("PlayerScripts")
	local v1 = PlayerScripts and PlayerScripts:FindFirstChild("PlayerModule")

	if not (v1 and v1:IsA("ModuleScript")) then
		return nil
	end

	local ok, result = pcall(function() --[[ Line: 67 | Upvalues: v1 (copy) ]]
		return require(v1):GetControls()
	end)

	if ok then
		v3 = result

		return result
	end

	warn("[MountMovement] PlayerModule controls failed:", result)

	return nil
end

local function getInputVector() --[[ getInputVector | Line: 81 | Upvalues: getControls (copy), Workspace (copy) ]]
	local v1 = getControls()
	local CurrentCamera = Workspace.CurrentCamera

	if not (v1 and CurrentCamera) then
		return Vector3.new(0, 0, 0)
	end

	local ok, result = pcall(function() --[[ Line: 87 | Upvalues: v1 (copy) ]]
		return v1:GetMoveVector()
	end)

	if not ok or (typeof(result) ~= "Vector3" or result.Magnitude < 0.05) then
		return Vector3.new(0, 0, 0)
	end

	local v2 = CurrentCamera.CFrame:VectorToWorldSpace(result)
	local v3 = Vector3.new(v2.X, 0, v2.Z)

	if v3.Magnitude < 0.05 then
		return Vector3.new(0, 0, 0)
	end

	return v3.Unit * math.min(result.Magnitude, 1)
end

local function step(p1) --[[ step | Line: 101 | Upvalues: mountState (copy), LocalPlayer (copy), v1 (ref), v2 (ref), getInputVector (copy) ]]
	local v12 = mountState.getRiddenConfig(LocalPlayer)
	local Character = LocalPlayer.Character
	local v22 = if Character then Character:FindFirstChildOfClass("Humanoid") else Character

	if not (v12 and v22) then
		v1 = 0
		v2 = Vector3.new(0, 0, 0)

		return
	end

	local v3 = getInputVector()
	local Magnitude = v3.Magnitude
	local v4 = if Magnitude > 0.05 then true else false

	if v4 then
		v2 = v3.Unit
	end

	local v5 = if v4 then v12.WalkSpeed * Magnitude else 0

	if v1 < v5 then
		v1 = math.min(v5, v1 + (v12.Acceleration or 60) * p1)
	else
		v1 = math.max(v5, v1 - (v12.Deceleration or 350) * p1)
	end

	if v1 <= 0 or v2.Magnitude < 0.05 then
		v1 = 0
	else
		v22:Move(v2 * math.min(v1 / v12.WalkSpeed, 1), false)
	end
end

function t.Init(p1) --[[ Init | Line: 135 | Upvalues: RunService (copy), step (copy) ]]
	RunService:BindToRenderStep("MountMovement", Enum.RenderPriority.Character.Value + 1, step)
end

return t