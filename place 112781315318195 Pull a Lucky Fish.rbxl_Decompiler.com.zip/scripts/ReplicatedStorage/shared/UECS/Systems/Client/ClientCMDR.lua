-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
game:GetService("MarketplaceService")
game:GetService("Players")

local ReplicatedStorage = game:GetService("ReplicatedStorage")

require(ReplicatedStorage.shared.module.CheckCMDRPerms)
require((ReplicatedStorage:WaitForChild("CmdrClient")))
require(ReplicatedStorage.shared.UECS.GlobalTypes)

return {
	UECS = nil,
	Init = function(p1) --[[ Init | Line: 13 ]] end
}