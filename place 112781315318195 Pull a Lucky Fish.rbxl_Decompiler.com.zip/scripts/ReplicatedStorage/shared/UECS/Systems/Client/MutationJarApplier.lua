-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local CashDisplay = require(ReplicatedStorage.shared.module.CashDisplay)
local FishConfig = require(ReplicatedStorage.shared.config.FishConfig)
local FishEarnings = require(ReplicatedStorage.shared.util.FishEarnings)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local MutateFishPopup = require(ReplicatedStorage.shared.UECS.Components.MutateFishPopup)
local MutationConfig = require(ReplicatedStorage.shared.config.MutationConfig)

require(ReplicatedStorage.shared.UECS.Components.MutationJar)

local MutationList = require(ReplicatedStorage.shared.util.MutationList)
local MutationMachineConfig = require(ReplicatedStorage.shared.config.MutationMachineConfig)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local SFX = require(ReplicatedStorage.client.SFX)
local SignalBag = require(ReplicatedStorage.client.SignalBag)

require(ReplicatedStorage.shared.UECS.Components.TycoonStand)

local UECS = require(ReplicatedStorage.shared.UECS.UECS)
local v1 = Color3.new(255/255, 255/255, 255/255)
local LocalPlayer = Players.LocalPlayer
local t = {
	UECS = nil
}

local function setupRarityLabel(p1, p2) --[[ setupRarityLabel | Line: 48 | Upvalues: ReplicatedStorage (copy) ]]
	if p1:QueryDescendants("BillboardGui#RarityLabel")[1] then
		return
	end

	local v1 = ReplicatedStorage.shared.model.RarityLabel:Clone()

	v1.Parent = p1
	p1.ChildAdded:Connect(function(p1) --[[ Line: 56 | Upvalues: v1 (copy) ]]
		if p1.Name ~= "Handle" or not p1:IsA("BasePart") then
			return
		end

		v1.Adornee = p1
	end)

	local Handle = p1:FindFirstChild("Handle")

	if Handle and Handle:IsA("BasePart") then
		v1.Adornee = Handle
	end

	v1.Frame.DisplayName.Text = p2.displayName
	v1.Frame.Rarity.Text = "Mutation"
	v1.Frame.Counter.Text = "Click on fish in your base to apply"

	local MutationList = v1.Frame:FindFirstChild("MutationList")

	if not MutationList then
		v1.Enabled = true

		return
	end

	MutationList.Visible = false
	v1.Enabled = true
end

function t.Init(p1) --[[ Init | Line: 81 | Upvalues: LocalPlayer (copy), MutateFishPopup (copy), FishConfig (copy), MutationList (copy), SignalBag (copy), MutationConfig (copy), v1 (copy), FishEarnings (copy), CashDisplay (copy), Remotes (copy), SFX (copy), UECS (copy), MutationMachineConfig (copy), setupRarityLabel (copy) ]]
	local MutateFishPopup2 = LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("MainUI"):WaitForChild("MutateFishPopup")
	local v12 = MutateFishPopup2:WaitForChild("Content")
	local GiftText = v12:WaitForChild("GiftText")
	local FishTemplateNotAcquired = v12:WaitForChild("FishTemplateNotAcquired")
	local Yes = v12:WaitForChild("Yes")
	local No = v12:WaitForChild("No")
	local CloseButton = MutateFishPopup2:WaitForChild("TopBar"):WaitForChild("CloseButton")
	local Frame = FishTemplateNotAcquired:WaitForChild("Frame")
	local UIGradient = Frame:FindFirstChild("UIGradient")
	local Icon = FishTemplateNotAcquired:WaitForChild("Icon")
	local DisplayName = FishTemplateNotAcquired:WaitForChild("DisplayName")
	local Earnings = FishTemplateNotAcquired:WaitForChild("Earnings")

	MutateFishPopup2.Visible = false

	local v2 = MutateFishPopup.Add(MutateFishPopup2)

	v2.Visible.OnChange:Connect(function(p1) --[[ Line: 102 | Upvalues: MutateFishPopup2 (copy) ]]
		MutateFishPopup2.Visible = p1
	end)

	local v3 = nil

	local function closePopup() --[[ closePopup | Line: 110 | Upvalues: v3 (ref), p1 (copy), v2 (copy) ]]
		v3 = nil

		local v1 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

		if v1.OpenedUIComponent:Get() ~= v2 then
			return
		end

		v1.OpenedUIComponent:Set(nil)
	end

	local function openConfirmPopup(p12, p2) --[[ openConfirmPopup | Line: 118 | Upvalues: FishConfig (ref), MutationList (ref), SignalBag (ref), v3 (ref), MutationConfig (ref), GiftText (copy), UIGradient (copy), Frame (copy), Icon (copy), v1 (ref), DisplayName (copy), FishEarnings (ref), LocalPlayer (ref), CashDisplay (ref), Earnings (copy), p1 (copy), v2 (copy) ]]
		local v12 = p12.FishStanding:Get()

		if typeof(v12) ~= "string" then
			return
		end

		local v22 = FishConfig[v12]

		if not v22 then
			return
		end

		local v32 = p12.BaseSlotIndexName:Get()

		if typeof(v32) ~= "string" then
			return
		end

		local v4 = p12.Mutation:Get()
		local v5 = if typeof(v4) == "string" and v4 ~= "" then v4 else nil

		if table.find(MutationList.parse(v5), p2) then
			SignalBag.Notification:Fire("This fish already has this mutation!")

			return
		end

		v3 = v32

		local v6 = MutationConfig.Mutations[p2]

		GiftText.Text = if v6 then ("Apply %* to this fish?"):format(v6.displayName) else "Apply this mutation to this fish?"

		local v9 = p12.Level:Get() or 1

		if UIGradient then
			UIGradient.Color = ColorSequence.new(v22.Rarity.rarityColor, Color3.fromRGB(255, 255, 255))
		end

		Frame.BackgroundColor3 = v22.Rarity.rarityColor
		Icon.Image = v22.Image
		Icon.ImageColor3 = v1

		local v10 = MutationList.displayLabel(MutationList.parse(v5))

		DisplayName.Text = ("%*%*"):format(if v10 == "" then "" else ("[%*] "):format(v10), v22.DisplayName)
		CashDisplay.applyToLabel(Earnings, FishEarnings.perFish(LocalPlayer, v12, false, v9, v5), {
			Suffix = "/s",
			Compact = true
		})
		p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(v2)
	end

	Yes.MouseButton1Click:Connect(function() --[[ Line: 167 | Upvalues: v3 (ref), Remotes (ref), SFX (ref), p1 (copy), v2 (copy) ]]
		local v1 = v3

		if not v1 then
			return
		end

		Remotes.ApplyMutationJar:Fire(v1)
		SFX.new("rbxassetid://127613720380706", 0.6)
		v3 = nil

		local v22 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

		if v22.OpenedUIComponent:Get() ~= v2 then
			return
		end

		v22.OpenedUIComponent:Set(nil)
	end)
	No.MouseButton1Click:Connect(closePopup)
	CloseButton.MouseButton1Click:Connect(closePopup)
	UECS.OnComponentCreated("MutationJar"):Connect(function(p12) --[[ Line: 179 | Upvalues: openConfirmPopup (copy), MutationMachineConfig (ref), p1 (copy), LocalPlayer (ref), setupRarityLabel (ref), MutationConfig (ref) ]]
		local Entity = p12.Entity
		local t = {}
		local t2 = {}

		local function CreateMutatePrompt(p1, p2, p3) --[[ CreateMutatePrompt | Line: 185 | Upvalues: t (copy), t2 (copy), openConfirmPopup (ref) ]]
			local MutatePrompt = Instance.new("ProximityPrompt")

			MutatePrompt.Name = "MutatePrompt"
			MutatePrompt.Style = Enum.ProximityPromptStyle.Custom
			MutatePrompt.ActionText = "Mutate"
			MutatePrompt.RequiresLineOfSight = false
			MutatePrompt.Parent = p1
			table.insert(t, MutatePrompt)

			local function refresh() --[[ refresh | Line: 201 | Upvalues: p2 (copy), MutatePrompt (copy), p1 (copy) ]]
				local v1 = p2.FishStanding:Get()
				local v2 = if type(v1) == "string" then v1 ~= "" else false

				MutatePrompt.Enabled = v2

				local FishPrompt = p1:FindFirstChild("FishPrompt")

				if not FishPrompt then
					return
				end

				FishPrompt.Enabled = not v2
			end

			local v2 = p2.FishStanding:Get()
			local v3 = if type(v2) == "string" then v2 ~= "" else false

			MutatePrompt.Enabled = v3

			local FishPrompt = p1:FindFirstChild("FishPrompt")
			local v5

			if FishPrompt then
				FishPrompt.Enabled = not v3
			end

			v5 = p2.FishStanding.OnChange
			table.insert(t2, v5:Connect(refresh))
			MutatePrompt.Triggered:Connect(function() --[[ Line: 214 | Upvalues: openConfirmPopup (ref), p2 (copy), p3 (copy) ]]
				openConfirmPopup(p2, p3)
			end)
		end

		local function teardown() --[[ teardown | Line: 219 | Upvalues: t (copy), t2 (copy) ]]
			for v1, v2 in t do
				local v3 = v2.Parent

				if v3 then
					local FishPrompt = v3:FindFirstChild("FishPrompt")

					if FishPrompt then
						FishPrompt.Enabled = true
					end
				end

				v2:Destroy()
			end

			table.clear(t)

			for v4, v5 in t2 do
				v5:Disconnect()
			end

			table.clear(t2)
		end

		Entity.Equipped:Connect(function() --[[ Line: 238 | Upvalues: p12 (copy), MutationMachineConfig (ref), p1 (ref), LocalPlayer (ref), CreateMutatePrompt (copy), setupRarityLabel (ref), Entity (copy), MutationConfig (ref) ]]
			local v1 = p12.ConfigName:Get()
			local v2 = if typeof(v1) == "string" then MutationMachineConfig.JarsByConfigName[v1] else nil

			if not v2 then
				return
			end

			for v3, v4 in p1.UECS:GetComponents("TycoonStand") do
				if v4.Owner:Get() == LocalPlayer then
					local root = v4.Entity:FindFirstChild("root")

					if root then
						CreateMutatePrompt(root, v4, v2.MutationId)
					end
				end
			end

			setupRarityLabel(Entity, MutationConfig.Mutations[MutationMachineConfig.JarsByConfigName[v1].MutationId])
		end)
		Entity.Unequipped:Connect(teardown)
		Entity.Destroying:Connect(teardown)
	end)
end

return t