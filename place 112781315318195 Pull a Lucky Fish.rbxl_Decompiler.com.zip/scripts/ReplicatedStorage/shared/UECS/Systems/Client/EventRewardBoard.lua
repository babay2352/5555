-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local EventConfig = require(ReplicatedStorage.shared.config.EventConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local t = {
	UECS = nil,
	Priority = 32
}
local RewardBoard = EventConfig.Tags.RewardBoard

function t.Init(p1) --[[ Init | Line: 23 | Upvalues: CollectionService (copy), RewardBoard (copy), Players (copy), ReplicatedStorage (copy), EventConfig (copy) ]]
	local v1 = CollectionService:GetTagged(RewardBoard)

	if #v1 == 0 then
		return
	end

	local PlayerGui = Players.LocalPlayer.PlayerGui
	local v2 = ReplicatedStorage.shared.model:FindFirstChild(EventConfig.Ui.RewardBoardTemplateName)

	if not v2 then
		warn("[EventRewardBoard] Could not find", EventConfig.Ui.RewardBoardTemplateName)

		return
	end

	local v3 = v2:FindFirstChild("Frame") and v2.Frame:FindFirstChild("ScrollingFrame")

	if not v3 then
		warn("[EventRewardBoard] Could not find Frame.ScrollingFrame")

		return
	end

	local Title = v3:FindFirstChild("Title")
	local RewardList = v3:FindFirstChild("RewardList")

	if not (Title and RewardList) then
		warn("[EventRewardBoard] Missing Title or RewardList template")

		return
	end

	local v4 = nil

	for v5, v6 in RewardList:GetChildren() do
		if v6:IsA("Frame") and v6.Name == "template" then
			v4 = v6

			break
		end
	end

	if not v4 then
		warn("[EventRewardBoard] Could not find tile template")

		return
	end

	for v7, v8 in v1 do
		if v8:IsA("BasePart") then
			local v9 = v2:Clone()

			v9.Adornee = v8
			v9.Parent = PlayerGui

			local ScrollingFrame = v9.Frame.ScrollingFrame

			for v10, v11 in ScrollingFrame:GetChildren() do
				if v11:IsA("TextLabel") or v11:IsA("Frame") then
					v11:Destroy()
				end
			end

			for v12, v13 in EventConfig.Tiers do
				local v14 = Title:Clone()

				v14.Text = v13.Label
				v14.LayoutOrder = v13.LayoutOrder * 2 - 1
				v14.Visible = true

				local v15 = v14:FindFirstChildWhichIsA("UIGradient")

				if v15 then
					v15.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, v13.GradientFrom), ColorSequenceKeypoint.new(1, v13.GradientTo) })
				end

				v14.Parent = ScrollingFrame

				local v17 = math.ceil(#v13.Items / 4)
				local v18 = RewardList:Clone()

				v18.Name = v13.Label
				v18.LayoutOrder = v13.LayoutOrder * 2
				v18.Size = UDim2.new(1, 0, 0, v17 * 120)
				v18.Visible = true

				for v19, v20 in v18:GetChildren() do
					if v20:IsA("Frame") then
						v20:Destroy()
					end
				end

				for i = 1, v17 do
					local v21 = (i - 1) * 4 + 1
					local v23 = math.min(i * 4, #v13.Items)
					local Frame = Instance.new("Frame")

					Frame.Name = "Row" .. i
					Frame.Size = UDim2.new(1, 0, 0, 120)
					Frame.Position = UDim2.new(0, 0, 0, (i - 1) * 120)
					Frame.BackgroundTransparency = 1
					Frame.BorderSizePixel = 0
					Frame.Parent = v18

					local UIListLayout = Instance.new("UIListLayout")

					UIListLayout.FillDirection = Enum.FillDirection.Horizontal
					UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder
					UIListLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center
					UIListLayout.Parent = Frame

					local v24 = v23 - v21 + 1

					for j = v21, v23 do
						local v25 = v13.Items[j]
						local v26 = v4:Clone()

						v26.Name = v25.DisplayName
						v26.LayoutOrder = j
						v26.Visible = true
						v26.Size = UDim2.new(1 / v24, 0, 1, 0)

						local ImageLabel = v26:FindFirstChild("ImageLabel")

						if ImageLabel then
							ImageLabel.Image = v25.Image
						end

						local Ammount = v26:FindFirstChild("Ammount")

						if Ammount then
							Ammount.Text = if v25.Amount > 1 then "x" .. v25.Amount else ""
						end

						local Description = v26:FindFirstChild("Description")

						if Description then
							Description.Text = v25.ShortLabel
						end

						v26.Parent = Frame
					end
				end

				v18.Parent = ScrollingFrame
			end
		end
	end
end

return t