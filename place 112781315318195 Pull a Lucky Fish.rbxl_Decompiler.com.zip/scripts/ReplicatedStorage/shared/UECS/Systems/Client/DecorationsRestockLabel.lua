-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local DecorationsStoreConfig = require(ReplicatedStorage.shared.config.DecorationsStoreConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local t = {
	UECS = nil
}
local RestockLabelTag = DecorationsStoreConfig.RestockLabelTag
local RestockLabelFormat = DecorationsStoreConfig.RestockLabelFormat
local RestockInterval = DecorationsStoreConfig.RestockInterval

local function secondsUntilRestock() --[[ secondsUntilRestock | Line: 38 | Upvalues: RestockInterval (copy) ]]
	return RestockInterval - os.time() % RestockInterval
end

local function restockText() --[[ restockText | Line: 42 | Upvalues: RestockInterval (copy), RestockLabelFormat (copy) ]]
	local v1 = RestockInterval - os.time() % RestockInterval

	return string.format(RestockLabelFormat, math.floor(v1 / 60), v1 % 60)
end

local function refresh() --[[ refresh | Line: 47 | Upvalues: RestockInterval (copy), RestockLabelFormat (copy), CollectionService (copy), RestockLabelTag (copy) ]]
	local v1 = RestockInterval - os.time() % RestockInterval
	local v3 = string.format(RestockLabelFormat, math.floor(v1 / 60), v1 % 60)

	for v4, v5 in CollectionService:GetTagged(RestockLabelTag) do
		if (v5:IsA("TextLabel") or v5:IsA("TextButton")) and v5.Text ~= v3 then
			v5.Text = v3
		end
	end
end

function t.Init(p1) --[[ Init | Line: 58 | Upvalues: refresh (copy), RunService (copy) ]]
	refresh()

	local v1 = 0

	RunService.Heartbeat:Connect(function(p1) --[[ Line: 62 | Upvalues: v1 (ref), refresh (ref) ]]
		v1 = v1 + p1

		if not (v1 < 1) then
			v1 = 0
			refresh()
		end
	end)
end

return t