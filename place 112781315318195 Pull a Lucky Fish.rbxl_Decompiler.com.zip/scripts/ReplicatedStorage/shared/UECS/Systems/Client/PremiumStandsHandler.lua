-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local MarketplaceService = game:GetService("MarketplaceService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")
local FishConfig = require(ReplicatedStorage.shared.config.FishConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local buildFishModel = require(ReplicatedStorage.shared.util.buildFishModel)
local fetchRobuxPriceInto = require(ReplicatedStorage.shared.util.fetchRobuxPriceInto)
local t = {
	StandBeeFish = {
		configName = "Bee Fish",
		devProductId = 3603081446,
		yawDeg = 180
	},
	StandMedusaKing = {
		configName = "Medusa King",
		devProductId = 3603081496,
		yawDeg = 180
	},
	StandLeviathan = {
		configName = "Leviathan",
		devProductId = 3603081526,
		yawDeg = -90
	},
	StandWhale = {
		configName = "Exclusive_1_Whale",
		devProductId = 3611308502,
		yawDeg = 180
	},
	StandPenguinKing = {
		configName = "Exclusive_2_Penguin_King",
		devProductId = 3611308573,
		yawDeg = 180
	},
	StandHydra = {
		configName = "Exclusive_3_hydra",
		devProductId = 3611308699,
		yawDeg = 180
	}
}
local t2 = {
	UECS = nil
}

local function setupStand(p1, p2, p3, p4, p5) --[[ setupStand | Line: 35 | Upvalues: FishConfig (copy), buildFishModel (copy), CollectionService (copy), ReplicatedStorage (copy), fetchRobuxPriceInto (copy), MarketplaceService (copy) ]]
	local v1 = FishConfig[p3]

	if not v1 then
		warn((("[PremiumStandsHandler] missing FishConfig entry \"%*\""):format(p3)))

		return
	end

	local v2 = buildFishModel.clone(p3, 1, nil)

	if not (v2 and v2.PrimaryPart) then
		warn((("[PremiumStandsHandler] buildFishModel returned nil for \"%*\" \226\128\148 model probably missing from FishModels"):format(p3)))

		return
	end

	local PrimaryPart = v2.PrimaryPart

	PrimaryPart.Anchored = true

	local _, v3 = v2:GetBoundingBox()
	local v6 = Vector3.new(p2.Position.X, p2.Position.Y + p2.Size.Y * 0.5 + 1.5 + v3.Y * 0.5, p2.Position.Z)
	local LookVector = p2.CFrame.LookVector
	local v7 = Vector3.new(LookVector.X, 0, LookVector.Z)

	if v7.Magnitude < 0.0001 then
		v7 = Vector3.new(0, 0, 1)
	end

	PrimaryPart.CFrame = CFrame.lookAt(v6, v6 + v7.Unit) * CFrame.Angles(0, math.rad(p5), 0)
	v2.Parent = p1
	v2:SetAttribute("IdleAnchor", PrimaryPart.CFrame)
	CollectionService:AddTag(v2, "IdleFishFloat")

	local v8 = ReplicatedStorage.shared.model.RarityLabel:Clone()

	v8.Parent = v2
	v8.Adornee = v2
	v8.Frame.Counter.Text = ("%*%%"):format((math.floor((v1.EarningsPercent or 1) * 100 + 0.5)))
	v8.Frame.Rarity.Text = v1.DisplayName
	v8.Frame.Rarity.UIGradient.Color = ColorSequence.new(v1.Rarity.rarityColor)
	v8.Frame.Rarity:SetAttribute("RarityId", v1.Rarity.id)
	CollectionService:AddTag(v8.Frame.Rarity, "AnimatedRarity")

	if p4 > 0 then
		v8.Frame.DisplayName.Text = "..."
		fetchRobuxPriceInto(v8.Frame.DisplayName, p4)
	else
		v8.Frame.DisplayName.Text = "Soon"
	end

	v8.Enabled = true

	local BuyPremiumFish = Instance.new("ProximityPrompt")

	BuyPremiumFish.Name = "BuyPremiumFish"
	BuyPremiumFish.Style = Enum.ProximityPromptStyle.Custom
	BuyPremiumFish.ActionText = "Buy"
	BuyPremiumFish.ObjectText = v1.DisplayName
	BuyPremiumFish.HoldDuration = 0.3
	BuyPremiumFish.MaxActivationDistance = 12
	BuyPremiumFish.RequiresLineOfSight = false
	BuyPremiumFish.Parent = p2
	BuyPremiumFish.Triggered:Connect(function(p1) --[[ Line: 116 | Upvalues: p4 (copy), MarketplaceService (ref) ]]
		if not (p4 <= 0) then
			MarketplaceService:PromptProductPurchase(p1, p4)
		end
	end)
end

function t2.Init(p1) --[[ Init | Line: 124 | Upvalues: Players (copy), Workspace (copy), t (copy), setupStand (copy) ]]
	local LocalPlayer = Players.LocalPlayer
	local PremiumStands = Workspace:WaitForChild("PremiumStands", 30)

	if not PremiumStands then
		return
	end

	for v1, v2 in t do
		task.spawn(function() --[[ Line: 134 | Upvalues: PremiumStands (copy), v1 (copy), setupStand (ref), v2 (copy) ]]
			local v12 = PremiumStands:WaitForChild(v1, 30)

			if not v12 then
				return
			end

			local Main = v12:WaitForChild("Main", 10)

			if Main and Main:IsA("BasePart") then
				setupStand(v12, Main, v2.configName, v2.devProductId, v2.yawDeg)
			else
				warn((("[PremiumStandsHandler] %*.Main missing or not a BasePart"):format(v1)))
			end
		end)
	end
end

return t2