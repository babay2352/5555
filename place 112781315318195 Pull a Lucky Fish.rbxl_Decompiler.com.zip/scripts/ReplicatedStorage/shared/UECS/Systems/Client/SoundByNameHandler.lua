-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local SoundService = game:GetService("SoundService")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Remotes = require(ReplicatedStorage.shared.Remotes)
local SignalBag = require(ReplicatedStorage.client.SignalBag)
local t = {
	UECS = nil,
	Priority = 100
}

local function playSoundByName(p1) --[[ playSoundByName | Line: 12 | Upvalues: SoundService (copy) ]]
	local v1 = SoundService:QueryDescendants((("SoundGroup#SFX > Sound#%*"):format(p1)))[1]

	if v1 then
		local v2 = v1:Clone()

		v2.PlayOnRemove = true
		v2.Parent = SoundService
		v2:Destroy()
	end
end

function t.Init(p1) --[[ Init | Line: 24 | Upvalues: Remotes (copy), playSoundByName (copy), SignalBag (copy) ]]
	Remotes.PlaySoundByName:On(playSoundByName)
	SignalBag.PlaySoundByName:Connect(playSoundByName)
end

return t