-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

return {
	UECS = nil,
	Init = function(p1) --[[ Init | Line: 16 ]] end
}