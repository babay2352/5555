-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local CashDisplay = require(ReplicatedStorage.shared.module.CashDisplay)
local CashFormat = require(ReplicatedStorage.shared.util.CashFormat)
local FishEarnings = require(ReplicatedStorage.shared.util.FishEarnings)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Remotes = require(ReplicatedStorage.shared.Remotes)

require(ReplicatedStorage.client.SFX)
require(ReplicatedStorage.shared.UECS.Components.TycoonStand)

local UECS = require(ReplicatedStorage.shared.UECS.UECS)
local notifications = require(ReplicatedStorage.shared.module.notifications)
local v1 = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(165, 246, 0)), ColorSequenceKeypoint.new(0.47, Color3.fromRGB(165, 246, 0)), ColorSequenceKeypoint.new(1, Color3.fromRGB(66, 233, 0)) })
local v2 = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(246, 80, 80)), ColorSequenceKeypoint.new(0.47, Color3.fromRGB(246, 80, 80)), ColorSequenceKeypoint.new(1, Color3.fromRGB(200, 30, 30)) })
local v3 = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 220, 80)), ColorSequenceKeypoint.new(0.47, Color3.fromRGB(255, 200, 50)), ColorSequenceKeypoint.new(1, Color3.fromRGB(220, 150, 0)) })
local v4 = Color3.fromRGB(255, 90, 90)

return {
	UECS = nil,
	Init = function(p1) --[[ Init | Line: 45 | Upvalues: Players (copy), UECS (copy), FishEarnings (copy), v3 (copy), CashDisplay (copy), ClientPlayerData (copy), v1 (copy), v2 (copy), notifications (copy), CashFormat (copy), v4 (copy), Remotes (copy) ]]
		local LocalPlayer = Players.LocalPlayer
		local PlayerGui = LocalPlayer:WaitForChild("PlayerGui")
		local t = {}

		UECS.OnComponentCreated("TycoonStand"):Connect(function(p12) --[[ Line: 53 | Upvalues: t (copy), LocalPlayer (copy), PlayerGui (copy), FishEarnings (ref), v3 (ref), CashDisplay (ref), ClientPlayerData (ref), v1 (ref), v2 (ref), notifications (ref), CashFormat (ref), v4 (ref), p1 (copy), Remotes (ref) ]]
			local function setupForLocalOwner() --[[ setupForLocalOwner | Line: 54 | Upvalues: t (ref), p12 (copy), LocalPlayer (ref), PlayerGui (ref), FishEarnings (ref), v3 (ref), CashDisplay (ref), ClientPlayerData (ref), v1 (ref), v2 (ref), notifications (ref), CashFormat (ref), v4 (ref), p1 (ref), Remotes (ref) ]]
				if t[p12] then
					return
				end

				if p12.Owner:Get() ~= LocalPlayer then
					return
				end

				local Entity = p12.Entity

				if typeof(Entity) ~= "Instance" then
					return
				end

				local UpgradeBoard = Entity:WaitForChild("UpgradeBoard", 10)

				if not UpgradeBoard then
					return
				end

				local UpgradeSurfaceUI = UpgradeBoard:WaitForChild("UpgradeSurfaceUI", 10)

				if not UpgradeSurfaceUI then
					warn("[UpgradeBoardHandler] No UpgradeSurfaceUI on", UpgradeBoard:GetFullName(), p12.UID)

					return
				end

				local Main = UpgradeSurfaceUI:WaitForChild("Main", 10)
				local v12 = if Main then Main:WaitForChild("UpgradeCostCash", 10) else Main
				local v22 = v12 and v12:WaitForChild("Counter", 10)
				local v32 = Main and Main:WaitForChild("LevelJump", 10)
				local v42 = Main and Main:FindFirstChild("UIGradient")

				if not (Main and (v22 and v32)) then
					print("No required children", p12.UID)

					return
				end

				if t[p12] or p12.Owner:Get() ~= LocalPlayer then
					print("Already wired [post check]", p12.UID)
				else
					t[p12] = true
					UpgradeSurfaceUI.Parent = PlayerGui
					UpgradeSurfaceUI.Adornee = UpgradeBoard

					local v5 = 0
					local v6 = false
					local v7 = false

					local function refresh() --[[ refresh | Line: 113 | Upvalues: p12 (ref), UpgradeSurfaceUI (copy), FishEarnings (ref), v7 (ref), v5 (ref), v6 (ref), v42 (copy), v3 (ref), CashDisplay (ref), v22 (copy), v32 (copy), ClientPlayerData (ref), v1 (ref), v2 (ref) ]]
						local v12 = p12.FishStanding:Get()

						if type(v12) ~= "string" then
							UpgradeSurfaceUI.Enabled = false

							return
						end

						UpgradeSurfaceUI.Enabled = true

						local v23 = p12.Level:Get() or 1

						if FishEarnings.FISH_MAX_LEVEL <= v23 then
							v7 = true
							v5 = 0
							v6 = false

							if v42 then
								v42.Color = v3
							end

							CashDisplay.setPlainText(v22, "MAXED")
							v32.Text = ("Lvl %* / %*"):format(v23, FishEarnings.FISH_MAX_LEVEL)
						else
							v7 = false

							local v33 = FishEarnings.upgradeCost(v12, v23)

							v5 = v33
							v6 = v33 <= (ClientPlayerData.serverProfile:getState().money or 0)

							if v42 then
								v42.Color = if v6 then v1 else v2
							end

							CashDisplay.applyToLabel(v22, v33, {
								Compact = true
							})
							v32.Text = ("Lvl %* -> Lvl %*"):format(v23, v23 + 1)
						end
					end

					p12.FishStanding.OnChange:Connect(refresh)
					p12.Level.OnChange:Connect(refresh)
					refresh()
					ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 157 ]]
						return p1.money
					end, refresh)
					Main.MouseButton1Down:Connect(function() --[[ Line: 161 | Upvalues: v7 (ref), v6 (ref), ClientPlayerData (ref), v5 (ref), notifications (ref), CashFormat (ref), v4 (ref), p1 (ref), Remotes (ref), p12 (ref) ]]
						if v7 then
							return
						end

						if v6 then
							Remotes.RequestUpgradeFish:Fire(p12.BaseSlotIndexName:Get())
						else
							notifications:Send((("You need %* more!"):format((CashFormat.token(math.max(0, v5 - (ClientPlayerData.serverProfile:getState().money or 0)), v4)))))
							p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set((p1.UECS:WaitForAnyComponent("Store")))
						end
					end)
					Entity.Destroying:Connect(function() --[[ Line: 181 | Upvalues: UpgradeSurfaceUI (copy), t (ref), p12 (ref) ]]
						if not UpgradeSurfaceUI.Parent then
							t[p12] = nil

							return
						end

						UpgradeSurfaceUI:Destroy()
						t[p12] = nil
					end)
				end
			end

			local t2 = {}
			local v12 = false

			local function hideForNonOwner() --[[ hideForNonOwner | Line: 197 | Upvalues: v12 (ref), p12 (copy), t2 (copy) ]]
				if v12 then
					return
				end

				local Entity = p12.Entity

				if typeof(Entity) ~= "Instance" then
					return
				end

				v12 = true

				local function disableSurface(p1) --[[ disableSurface | Line: 207 ]]
					local UpgradeSurfaceUI = p1:FindFirstChild("UpgradeSurfaceUI")

					if not (UpgradeSurfaceUI and UpgradeSurfaceUI:IsA("SurfaceGui")) then
						return
					end

					UpgradeSurfaceUI.Enabled = false
				end

				local function watchBoard(p1) --[[ watchBoard | Line: 213 | Upvalues: t2 (ref) ]]
					local UpgradeSurfaceUI = p1:FindFirstChild("UpgradeSurfaceUI")
					local v2

					if UpgradeSurfaceUI and UpgradeSurfaceUI:IsA("SurfaceGui") then
						UpgradeSurfaceUI.Enabled = false
					end

					v2 = p1.ChildAdded
					table.insert(t2, v2:Connect(function(p1) --[[ Line: 219 ]]
						if not p1:IsA("SurfaceGui") or p1.Name ~= "UpgradeSurfaceUI" then
							return
						end

						p1.Enabled = false
					end))
				end

				local UpgradeBoard = Entity:FindFirstChild("UpgradeBoard")

				if UpgradeBoard then
					local UpgradeSurfaceUI = UpgradeBoard:FindFirstChild("UpgradeSurfaceUI")

					if UpgradeSurfaceUI and UpgradeSurfaceUI:IsA("SurfaceGui") then
						UpgradeSurfaceUI.Enabled = false
					end

					table.insert(t2, UpgradeBoard.ChildAdded:Connect(function(p1) --[[ Line: 219 ]]
						if not p1:IsA("SurfaceGui") or p1.Name ~= "UpgradeSurfaceUI" then
							return
						end

						p1.Enabled = false
					end))
				end

				local v2 = t2

				local function f3(p1) --[[ Line: 234 | Upvalues: t2 (ref) ]]
					if p1.Name ~= "UpgradeBoard" then
						return
					end

					local UpgradeSurfaceUI = p1:FindFirstChild("UpgradeSurfaceUI")

					if UpgradeSurfaceUI and UpgradeSurfaceUI:IsA("SurfaceGui") then
						UpgradeSurfaceUI.Enabled = false
					end

					table.insert(t2, p1.ChildAdded:Connect(function(p1) --[[ Line: 219 ]]
						if not p1:IsA("SurfaceGui") or p1.Name ~= "UpgradeSurfaceUI" then
							return
						end

						p1.Enabled = false
					end))
				end

				table.insert(v2, Entity.ChildAdded:Connect(f3))
			end

			local function stopHiding() --[[ stopHiding | Line: 242 | Upvalues: v12 (ref), t2 (copy) ]]
				v12 = false

				for v1, v2 in t2 do
					v2:Disconnect()
				end

				table.clear(t2)
			end

			if p12.Owner:Get() == LocalPlayer then
				task.spawn(setupForLocalOwner)
			else
				hideForNonOwner()
			end

			p12.Owner.OnChange:Connect(function(p1) --[[ Line: 255 | Upvalues: LocalPlayer (ref), v12 (ref), t2 (copy), setupForLocalOwner (copy), hideForNonOwner (copy) ]]
				if p1 ~= LocalPlayer then
					hideForNonOwner()

					return
				end

				v12 = false

				for v1, v2 in t2 do
					v2:Disconnect()
				end

				table.clear(t2)
				task.spawn(setupForLocalOwner)
			end)
		end)
	end
}