-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local t = {
	UECS = nil
}

local function setupModel(p1) --[[ setupModel | Line: 16 ]]
	if not (p1:IsA("Model") or p1:IsA("BasePart")) then
		return
	end

	local v1 = p1:GetAttribute("Anim")

	if not v1 then
		p1:GetAttributeChangedSignal("Anim"):Wait()
		v1 = p1:GetAttribute("Anim")
	end

	if not v1 then
		return
	end

	local Animation = Instance.new("Animation")
	local v3 = tostring(v1)

	if not string.match(v3, "^%a+://") then
		v3 = "rbxassetid://" .. v3
	end

	Animation.AnimationId = v3

	local v4 = p1:FindFirstChildOfClass("AnimationController") or p1:WaitForChild("AnimationController", 30)

	if not v4 then
		local AnimationController = Instance.new("AnimationController")

		AnimationController.Parent = p1
		v4 = AnimationController
	end

	local v5 = v4:FindFirstChildOfClass("Animator") or v4:WaitForChild("Animator", 30)

	if not v5 then
		local Animator = Instance.new("Animator")

		Animator.Parent = v4
		v5 = Animator
	end

	local v6 = v5:LoadAnimation(Animation)

	v6.Looped = true
	v6:Play()

	local v7 = false

	p1.DescendantAdded:Connect(function(p12) --[[ Line: 68 | Upvalues: v7 (ref), p1 (copy), v6 (copy) ]]
		if not (p12:IsA("Motor6D") or p12:IsA("Bone")) then
			return
		end

		if not v7 then
			v7 = true
			task.delay(0.5, function() --[[ Line: 76 | Upvalues: v7 (ref), p1 (ref), v6 (ref) ]]
				v7 = false

				if p1.Parent then
					v6:Stop(0)
					v6:Play(0)
					v6.TimePosition = v6.TimePosition
				end
			end)
		end
	end)
end

function t.Init(p1) --[[ Init | Line: 89 | Upvalues: CollectionService (copy), setupModel (copy) ]]
	CollectionService:GetInstanceAddedSignal("AnimAnimationController"):Connect(function(p1) --[[ Line: 90 | Upvalues: setupModel (ref) ]]
		task.spawn(setupModel, p1)
	end)

	for v1, v2 in CollectionService:GetTagged("AnimAnimationController") do
		task.spawn(setupModel, v2)
	end
end

return t