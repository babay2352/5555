-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local Workspace = game:GetService("Workspace")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Maid = require(ReplicatedStorage.shared.class.Maid)
local isPlayerOnMobile = require(ReplicatedStorage.shared.util.isPlayerOnMobile)
local t = {
	UECS = nil
}

local function findTemplateFolder() --[[ findTemplateFolder | Line: 63 | Upvalues: ReplicatedStorage (copy) ]]
	local v1 = ReplicatedStorage:FindFirstChild("shared")
	local v2 = if v1 then v1:FindFirstChild("model") else v1

	if v2 then
		local clouds = v2:FindFirstChild("clouds")

		if clouds and clouds:IsA("Folder") then
			return clouds
		end
	end

	local asset = ReplicatedStorage:FindFirstChild("asset")

	if not asset then
		return nil
	end

	local clouds = asset:FindFirstChild("clouds")

	if clouds and clouds:IsA("Folder") then
		return clouds
	end

	return nil
end

local function collectTemplates(p1) --[[ collectTemplates | Line: 82 ]]
	local t = {}

	for v1, v2 in p1:GetChildren() do
		if v2:IsA("Model") then
			table.insert(t, v2)
		end
	end

	return t
end

local function lerp(p1, p2, p3) --[[ lerp | Line: 92 ]]
	return p1 + (p2 - p1) * p3
end

local function randomBetween(p1, p2) --[[ randomBetween | Line: 96 ]]
	return p1 + (p2 - p1) * math.random()
end

local function ensureContainer() --[[ ensureContainer | Line: 100 | Upvalues: Workspace (copy) ]]
	local ClientClouds = Workspace:FindFirstChild("ClientClouds")

	if ClientClouds and ClientClouds:IsA("Folder") then
		return ClientClouds
	end

	local ClientClouds2 = Instance.new("Folder")

	ClientClouds2.Name = "ClientClouds"
	ClientClouds2.Parent = Workspace

	return ClientClouds2
end

local function setupCloudParts(p1) --[[ setupCloudParts | Line: 111 ]]
	for v1, v2 in p1:GetDescendants() do
		if v2:IsA("BasePart") then
			v2.Anchored = true
			v2.CanCollide = false
			v2.CanQuery = false
			v2.CanTouch = false
			v2.Massless = true
			v2.CastShadow = false
		end
	end
end

local function spawnCloud(p1, p2) --[[ spawnCloud | Line: 124 | Upvalues: setupCloudParts (copy) ]]
	local v1 = p1:Clone()

	setupCloudParts(v1)

	local v2 = v1.PrimaryPart or v1:FindFirstChildWhichIsA("BasePart")

	if not v2 then
		v1:Destroy()

		return nil
	end

	v1.PrimaryPart = v2

	local v3 = math.random() * 0.8500000000000001 + 0.75

	v1:ScaleTo(v1:GetScale() * v3)

	local v4 = math.random() * 8192 + -4096 + -981.5
	local v5 = math.random() * 8192 + -4096 + -377.75
	local v6 = math.random() * 100 + 320
	local v8 = CFrame.Angles(0, math.random() * math.pi * 2, 0)

	v1:PivotTo(CFrame.new(v4, v6, v5) * v8)
	v1.Parent = p2

	local t = {}

	for v9, v10 in v1:GetDescendants() do
		if v10:IsA("BasePart") then
			table.insert(t, v10)
		end
	end

	return {
		model = v1,
		rotation = v8,
		baseY = v6,
		speedFactor = math.random() * 0.29999999999999993 + 0.85,
		bobPhase = math.random() * math.pi * 2,
		parts = t
	}
end

local function driftClouds(p1, p2, p3, p4, p5) --[[ driftClouds | Line: 171 | Upvalues: Workspace (copy) ]]
	local GlobalWind = Workspace.GlobalWind

	if GlobalWind.Magnitude < 0.01 then
		GlobalWind = Vector3.new(12, 0, 4)
	end

	for v1, v2 in p1 do
		local Position = v2.model.PrimaryPart.CFrame.Position
		local sum = Position.X + GlobalWind.X * v2.speedFactor * p2
		local sum2 = Position.Z + GlobalWind.Z * v2.speedFactor * p2

		if sum > 3114.5 then
			sum = sum - 8192
		elseif sum < -5077.5 then
			sum = sum + 8192
		end

		if sum2 > 3718.25 then
			sum2 = sum2 - 8192
		elseif sum2 < -4473.75 then
			sum2 = sum2 + 8192
		end

		local v6 = CFrame.new(sum, v2.baseY + math.sin((p3 + v2.bobPhase) * 0.15 * math.pi * 2) * 3, sum2) * v2.rotation
		local parts = v2.parts

		for i = 1, #parts do
			table.insert(p4, parts[i])
			table.insert(p5, v6)
		end
	end
end

function t.Init(p1) --[[ Init | Line: 235 | Upvalues: isPlayerOnMobile (copy), findTemplateFolder (copy), collectTemplates (copy), Maid (copy), Workspace (copy), spawnCloud (copy), RunService (copy), driftClouds (copy) ]]
	if isPlayerOnMobile() then
		return
	end

	local v1 = findTemplateFolder()

	if not v1 then
		warn("[ClientCloudRenderer] No cloud template folder found at ReplicatedStorage.shared.model.clouds or ReplicatedStorage.asset.clouds")

		return
	end

	local v2 = collectTemplates(v1)

	if #v2 == 0 then
		warn((("[ClientCloudRenderer] %* has no Model children"):format((v1:GetFullName()))))

		return
	end

	local v3 = Maid.new()
	local ClientClouds = Workspace:FindFirstChild("ClientClouds")
	local v4

	if ClientClouds and ClientClouds:IsA("Folder") then
		v4 = ClientClouds
	else
		local ClientClouds2 = Instance.new("Folder")

		ClientClouds2.Name = "ClientClouds"
		ClientClouds2.Parent = Workspace
		v4 = ClientClouds2
	end

	local t = {}

	for i = 1, 24 do
		local v5 = spawnCloud(v2[math.random(1, #v2)], v4)

		if v5 then
			table.insert(t, v5)
			v3:GiveTask(v5.model)
		end
	end

	if #t == 0 then
		warn("[ClientCloudRenderer] Failed to spawn any clouds (templates lack PrimaryPart?)")
		v3:DoCleaning()
	else
		local v6 = 0
		local t2 = {}
		local t3 = {}

		v3:GiveTask(RunService.Heartbeat:Connect(function(p1) --[[ Line: 280 | Upvalues: v6 (ref), t2 (copy), t3 (copy), driftClouds (ref), t (copy), Workspace (ref) ]]
			debug.profilebegin("UECS/ClientCloudRenderer.Heartbeat")
			v6 = v6 + p1
			table.clear(t2)
			table.clear(t3)
			driftClouds(t, p1, v6, t2, t3)
			Workspace:BulkMoveTo(t2, t3, Enum.BulkMoveMode.FireCFrameChanged)
			debug.profileend()
		end))
		print((("[ClientCloudRenderer] Spawned %* clouds drifting on Workspace.GlobalWind"):format(#t)))
	end
end

return t