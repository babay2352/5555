-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Debris = game:GetService("Debris")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Remotes = require(ReplicatedStorage.shared.Remotes)
local VFX = require(ReplicatedStorage.client.VFX)

return {
	UECS = nil,
	Init = function(p1) --[[ Init | Line: 13 | Upvalues: Remotes (copy), Debris (copy), VFX (copy) ]]
		Remotes.ShowGardenBuildFX:On(function(p1) --[[ Line: 14 | Upvalues: Debris (ref), VFX (ref) ]]
			if typeof(p1) == "CFrame" then
				local GardenBuildFXHost = Instance.new("Part")

				GardenBuildFXHost.Name = "GardenBuildFXHost"
				GardenBuildFXHost.Anchored = true
				GardenBuildFXHost.CanCollide = false
				GardenBuildFXHost.CanQuery = false
				GardenBuildFXHost.CanTouch = false
				GardenBuildFXHost.Transparency = 1
				GardenBuildFXHost.Size = Vector3.new(0.1, 0.1, 0.1)
				GardenBuildFXHost.CFrame = p1
				GardenBuildFXHost.Parent = workspace
				Debris:AddItem(GardenBuildFXHost, 5)
				VFX.new("BuildPlaceDestroy", GardenBuildFXHost)
			end
		end)
	end
}