-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local isObjectRenderable = require(ReplicatedStorage.shared.util.isObjectRenderable)
local t = {
	UECS = nil
}
local t2 = {}

local function spawnParticle(p1) --[[ spawnParticle | Line: 27 | Upvalues: isObjectRenderable (copy), TweenService (copy) ]]
	if isObjectRenderable(p1.container) then
		local v1 = p1.template:Clone()
		local v2 = math.random() * (p1.sizeMax - p1.sizeMin) + p1.sizeMin

		v1.Size = UDim2.fromScale(v2, v2)
		v1.Position = UDim2.fromScale(math.random(), 1.1)
		v1.ImageTransparency = math.random() * 0.5
		v1.ZIndex = math.random(2, 4)
		v1.Visible = true
		v1.Parent = p1.container
		table.insert(p1.active, v1)

		local v3 = 4 + math.random() * 3
		local v4 = v1.Position.X.Scale + (math.random() - 0.5) * 0.15
		local v5 = TweenService:Create(v1, TweenInfo.new(v3, Enum.EasingStyle.Linear), {
			Position = UDim2.fromScale(v4, -0.15)
		})

		v5.Completed:Once(function() --[[ Line: 50 | Upvalues: p1 (copy), v1 (copy) ]]
			local v12 = table.find(p1.active, v1)

			if v12 then
				table.remove(p1.active, v12)
			end

			v1:Destroy()
		end)
		v5:Play()
	end
end

local function setupEmitter(p1, p2, p3, p4) --[[ setupEmitter | Line: 61 | Upvalues: t2 (copy), spawnParticle (copy) ]]
	p2.Visible = false

	local t = {
		container = p1,
		template = p2,
		sizeMin = p3,
		sizeMax = p4,
		active = {}
	}

	table.insert(t2, t)

	for i = 1, 60 do
		task.delay(i * 11 / 2 / 60, function() --[[ Line: 74 | Upvalues: spawnParticle (ref), t (copy) ]]
			spawnParticle(t)
		end)
	end
end

function t.Init(p1) --[[ Init | Line: 80 | Upvalues: setupEmitter (copy), t2 (copy), spawnParticle (copy) ]]
	local MainUI = game:GetService("Players").LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("MainUI", 30)

	if not MainUI then
		return
	end

	local v1 = MainUI:FindFirstChild("Store") and (MainUI.Store:FindFirstChild("Content") and (MainUI.Store.Content:FindFirstChild("ScrollingFrame") and MainUI.Store.Content.ScrollingFrame:FindFirstChild("PremiumFish")))

	if not v1 then
		return
	end

	for v2, v3 in { "Hydra", "PenguinKing", "Whale" } do
		local v4 = v1:FindFirstChild(v3, true)
		local v5 = if v4 then v4:FindFirstChild("Content") else v4

		if v5 then
			local Bubble = v5:FindFirstChild("Bubble")

			if Bubble and Bubble:IsA("ImageLabel") then
				setupEmitter(v5, Bubble, 0.04, 0.1)
			end
		end
	end

	task.spawn(function() --[[ Line: 105 | Upvalues: t2 (ref), spawnParticle (ref) ]]
		while true do
			for v1, v2 in t2 do
				if #v2.active < 60 then
					spawnParticle(v2)
				end
			end

			task.wait(0.3)
		end
	end)
end

return t