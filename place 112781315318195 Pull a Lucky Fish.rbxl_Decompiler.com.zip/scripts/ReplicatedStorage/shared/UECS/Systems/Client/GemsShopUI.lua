-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ContextActionService = game:GetService("ContextActionService")
local GamepadService = game:GetService("GamepadService")
local GuiService = game:GetService("GuiService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local CurrencyCounterSlot = require(ReplicatedStorage.shared.module.CurrencyCounterSlot)
local DailyQuestConfig = require(ReplicatedStorage.shared.config.DailyQuestConfig)
local GemsShop = require(ReplicatedStorage.shared.UECS.Components.GemsShop)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local MonetizationConfig = require(ReplicatedStorage.shared.config.MonetizationConfig)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local SFX = require(ReplicatedStorage.client.SFX)
local TweenNumber = require(ReplicatedStorage.shared.util.TweenNumber)
local bindToButtonPress = require(ReplicatedStorage.shared.util.bindToButtonPress)
local luckyblockDropOdds = require(ReplicatedStorage.shared.util.luckyblockDropOdds)
local t = {
	UECS = nil,
	Priority = 30
}
local v1 = Color3.fromRGB(100, 100, 100)
local v2 = Color3.fromRGB(126, 255, 143)
local v3 = Color3.fromRGB(255, 80, 80)
local v4 = UDim2.fromOffset(64, 64)

function t.Init(p1) --[[ Init | Line: 46 | Upvalues: ClientPlayerData (copy), Players (copy), GemsShop (copy), bindToButtonPress (copy), GamepadService (copy), ContextActionService (copy), GuiService (copy), MonetizationConfig (copy), v1 (copy), v2 (copy), v3 (copy), DailyQuestConfig (copy), luckyblockDropOdds (copy), Remotes (copy), TweenService (copy), TweenNumber (copy), CurrencyCounterSlot (copy), SFX (copy), v4 (copy), RunService (copy) ]]
	repeat
		task.wait()
	until ClientPlayerData.isPlayerDataLoaded

	local LocalPlayer = Players.LocalPlayer
	local PlayerGui = LocalPlayer.PlayerGui
	local MainUI = PlayerGui:WaitForChild("MainUI")
	local GemsShop2 = MainUI:WaitForChild("GemsShop")

	GemsShop2.Visible = false

	local ScrollingFrame = GemsShop2:WaitForChild("Content"):WaitForChild("ScrollingFrame")

	GemsShop.Add(GemsShop2).Visible.OnChange:Connect(function(p12, p2) --[[ Line: 60 | Upvalues: GemsShop2 (copy), MainUI (copy), bindToButtonPress (ref), p1 (copy), GamepadService (ref), ScrollingFrame (copy), ContextActionService (ref), GuiService (ref) ]]
		GemsShop2.Visible = p12

		local HUD = MainUI:FindFirstChild("HUD")

		if HUD then
			HUD.Visible = not p12
		end

		if p12 == p2 then
			return
		end

		if p12 then
			bindToButtonPress("GemsShopCloseAction", Enum.KeyCode.ButtonB, function() --[[ Line: 72 | Upvalues: p1 (ref) ]]
				p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
			end)
			GamepadService:EnableGamepadCursor(ScrollingFrame)

			return
		end

		ContextActionService:UnbindAction("GemsShopCloseAction")
		GamepadService:DisableGamepadCursor()
		GuiService.SelectedObject = nil
	end)
	GamepadService:GetPropertyChangedSignal("GamepadCursorEnabled"):Connect(function() --[[ Line: 85 | Upvalues: GamepadService (ref), GemsShop2 (copy), ScrollingFrame (copy) ]]
		if GamepadService.GamepadCursorEnabled or not GemsShop2.Visible then
			return
		end

		GamepadService:EnableGamepadCursor(ScrollingFrame)
	end)
	GemsShop2:WaitForChild("TopBar"):WaitForChild("CloseButton").MouseButton1Down:Connect(function() --[[ Line: 93 | Upvalues: p1 (copy) ]]
		p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
	end)

	local UIListLayout = ScrollingFrame:WaitForChild("UIListLayout")
	local t = {
		Large = UIListLayout:WaitForChild("FrameTemplateLarge"),
		Medium = UIListLayout:WaitForChild("FrameTemplateMedium"),
		Small = UIListLayout:WaitForChild("FrameTemplateSmall"),
		Openable = UIListLayout:WaitForChild("FrameTemplateOpenable"),
		Category = UIListLayout:WaitForChild("CategoryDivider"),
		Subcategory = UIListLayout:WaitForChild("SubcategoryDivider")
	}

	local function getState() --[[ getState | Line: 118 | Upvalues: ClientPlayerData (ref) ]]
		return ClientPlayerData.serverProfile:getState()
	end

	local function isPassOwned(p1) --[[ isPassOwned | Line: 122 | Upvalues: LocalPlayer (copy) ]]
		local v1 = LocalPlayer:GetAttribute(p1.Attribute)

		return if typeof(v1) == "number" then v1 > 1 else false
	end

	local function updateButtonState(p1, p2) --[[ updateButtonState | Line: 127 | Upvalues: ClientPlayerData (ref), MonetizationConfig (ref), LocalPlayer (copy), v1 (ref), v2 (ref), v3 (ref) ]]
		local v12 = ClientPlayerData.serverProfile:getState()
		local Button = p1:FindFirstChild("Button")

		if not Button then
			return
		end

		local v22

		if p2.Type == "Permanent" then
			v22 = v12.claimedDailyRewards[p2.Id]

			if not v22 then
				v22 = false

				for v32, v4 in MonetizationConfig.Gamepasses do
					if v4.ConflictsWith == p2.Id then
						local v5 = LocalPlayer:GetAttribute(v4.Attribute)

						if if typeof(v5) == "number" then v5 > 1 else false then
							v22 = true

							break
						end
					end
				end
			end
		else
			v22 = false
		end

		local v7 = if v12.gems >= p2.Cost then true else false

		if v22 then
			Button.BackgroundColor3 = v1

			local v8 = Button:FindFirstChild("Content")

			if not v8 then
				return
			end

			local Frame = v8:FindFirstChild("Frame")

			if not Frame then
				return
			end

			local Price = Frame:FindFirstChild("Price")

			if Price then
				Price.Text = "OWNED"
			end

			local GemIcon = Frame:FindFirstChild("GemIcon")

			if GemIcon then
				GemIcon.Visible = false
			end
		else
			Button.BackgroundColor3 = if v7 then v2 else v3
		end
	end

	local t2 = {}
	local t3 = {
		Openable = "Luckyblock",
		Gamepass = "Permament Upgrades",
		Potion = "Potions",
		ServerUpgrade = "Server Events"
	}
	local t4 = {}

	for v22, v32 in DailyQuestConfig.Rewards do
		local v12

		v12 = if v32.RewardCategory == "Openable" then t.Openable:Clone() elseif v32.RewardCategory == "ServerUpgrade" then t.Medium:Clone() elseif v32.RewardCategory == "Potion" or v32.RewardCategory == "Gamepass" then t.Small:Clone() else t.Large:Clone()
		v12.Name = v32.Id
		v12:AddTag(v32.RewardCategory)

		if v32.RewardSubcategory then
			v12:AddTag(v32.RewardSubcategory)
		end

		v12.Visible = true
		v12.Parent = ScrollingFrame

		if not ScrollingFrame:FindFirstChild(v32.RewardCategory) and t3[v32.RewardCategory] then
			local v42 = t.Category:Clone()

			v42.Name = v32.RewardCategory
			v42.Text = t3[v32.RewardCategory]
			v42.Visible = true
			v42.Parent = ScrollingFrame
			table.insert(t4, v42)
		end

		if v32.RewardSubcategory and not ScrollingFrame:FindFirstChild(v32.RewardSubcategory) then
			local v5 = t.Subcategory:Clone()

			v5.Name = v32.RewardSubcategory
			v5.Text = v32.RewardSubcategory
			v5.Visible = true
			v5.Parent = ScrollingFrame
			table.insert(t4, v5)
		end

		local Title = v12:FindFirstChild("Title")

		if Title then
			Title.Text = v32.DisplayName
		end

		local Description = v12:FindFirstChild("Description")

		if Description then
			Description.Text = v32.Description
		end

		local ImageLabel = v12:FindFirstChild("ImageLabel")

		if ImageLabel then
			ImageLabel.Image = v32.Icon
		end

		if v32.RewardCategory == "Openable" then
			local Drops = v12:FindFirstChild("Drops")
			local v6 = v12:QueryDescendants("UIListLayout > Frame#DropIcon")[1]
			local v7 = luckyblockDropOdds(v32.GrantData.LuckyblockConfigName)

			if Drops and (v6 and #v7 > 0) then
				for v8, v9 in v7 do
					if v9.image ~= "" then
						local v10 = v6:Clone()

						v10.ImageLabel.Image = v9.image
						v10.Title.Text = string.format("%.1f%%", v9.chance)
						v10.LayoutOrder = -math.floor(v9.chance)
						v10.Visible = true
						v10.Parent = Drops
					end
				end
			end
		end

		local Button = v12:FindFirstChild("Button")

		if Button then
			local v11 = Button:FindFirstChild("Content")

			if v11 then
				local Frame = v11:FindFirstChild("Frame")

				if Frame then
					local Price = Frame:FindFirstChild("Price")

					if Price then
						Price.Text = tostring(v32.Cost)
					end
				end
			end

			Button.MouseButton1Down:Connect(function() --[[ Line: 266 | Upvalues: ClientPlayerData (ref), v32 (copy), MonetizationConfig (ref), LocalPlayer (copy), Remotes (ref) ]]
				local v1 = ClientPlayerData.serverProfile:getState()

				if v32.Type == "Permanent" then
					if v1.claimedDailyRewards[v32.Id] then
						return
					end

					for v2, v3 in MonetizationConfig.Gamepasses do
						if v3.ConflictsWith == v32.Id then
							local v4 = LocalPlayer:GetAttribute(v3.Attribute)

							if if typeof(v4) == "number" then v4 > 1 else false then
								return
							end
						end
					end
				end

				if not (v1.gems < v32.Cost) then
					Remotes.RequestPurchaseDailyReward:Fire(v32.Id)
				end
			end)
		end

		table.insert(t2, v12)
	end

	local count = 0

	for v122, v13 in t4 do
		v13.LayoutOrder = count
		count = count + 1

		for v14, v15 in t2 do
			if v15:HasTag(v13.Name) then
				v15.LayoutOrder = count
				count = count + 1
			end
		end
	end

	local function updateCardHeights() --[[ updateCardHeights | Line: 304 | Upvalues: ScrollingFrame (copy), t2 (copy) ]]
		local X = ScrollingFrame.AbsoluteSize.X

		if X <= 0 then
			return
		end

		local v1 = math.round(X * 0.2)

		for v2, v3 in t2 do
			local X2 = v3.Size.X

			v3.Size = UDim2.new(X2.Scale, X2.Offset, 0, v1)
		end
	end

	updateCardHeights()
	ScrollingFrame:GetPropertyChangedSignal("AbsoluteSize"):Connect(updateCardHeights)

	local function updateCardPity(p1, p2) --[[ updateCardPity | Line: 319 ]]
		local v1 = p1:FindFirstChild("PityLabel", true) or (p1:FindFirstChild("PityText", true) or p1:FindFirstChild("Pity", true))

		if v1 then
			v1.Text = ("%*/20"):format(p2)
		end

		local v2 = p1:FindFirstChild("PityBar", true) or (p1:FindFirstChild("PityProgress", true) or p1:FindFirstChild("ProgressBar", true))

		if not v2 then
			return
		end

		local v3 = v2:FindFirstChild("Fill", true) or (v2:FindFirstChild("Progress", true) or v2:FindFirstChild("Bar", true))

		if v3 then
			v3.Size = UDim2.fromScale(math.clamp(p2 / 20, 0, 1), 1)

			return
		end

		v2.Size = UDim2.new(math.clamp(p2 / 20, 0, 1), 0, v2.Size.Y.Scale, v2.Size.Y.Offset)
	end

	local function refreshAll() --[[ refreshAll | Line: 342 | Upvalues: t2 (copy), DailyQuestConfig (ref), updateButtonState (copy), ClientPlayerData (ref), updateCardPity (copy) ]]
		for v1, v2 in t2 do
			local v4 = DailyQuestConfig.RewardById[v2.Name]

			if v4 then
				updateButtonState(v2, v4)

				if v4.RewardCategory == "Openable" and (v4.GrantData and v4.GrantData.LuckyblockConfigName) then
					updateCardPity(v2, if ClientPlayerData.serverProfile:getState().luckyblockPity then ClientPlayerData.serverProfile:getState().luckyblockPity[v4.GrantData.LuckyblockConfigName] or 0 else 0)
				end
			end
		end
	end

	refreshAll()
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 364 ]]
		return {
			gems = p1.gems,
			claimedDailyRewards = p1.claimedDailyRewards,
			luckyblockPity = p1.luckyblockPity
		}
	end, function() --[[ Line: 370 | Upvalues: refreshAll (copy) ]]
		refreshAll()
	end)

	local Gems = MainUI:WaitForChild("HUD"):WaitForChild("Counters"):WaitForChild("Gems")
	local Counter = Gems:WaitForChild("Counter")
	local Size = Gems.Size
	local v16 = UDim2.new(Size.X.Scale, Size.X.Offset, 0, 0)

	Gems.Size = v16
	Gems.Visible = false

	local v17 = TweenInfo.new(0.35, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
	local v18 = TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
	local v19 = false
	local v20 = nil

	local function showCounter() --[[ showCounter | Line: 396 | Upvalues: v19 (ref), Gems (copy), v20 (ref), TweenService (ref), v17 (copy), Size (copy) ]]
		if v19 then
			return
		end

		v19 = true
		Gems.Visible = true

		if not v20 then
			v20 = TweenService:Create(Gems, v17, {
				Size = Size
			})
			v20:Play()

			return
		end

		v20:Cancel()
		v20 = TweenService:Create(Gems, v17, {
			Size = Size
		})
		v20:Play()
	end

	local function hideCounter() --[[ hideCounter | Line: 409 | Upvalues: v19 (ref), v20 (ref), TweenService (ref), Gems (copy), v18 (copy), v16 (copy) ]]
		if not v19 then
			return
		end

		v19 = false

		if v20 then
			v20:Cancel()
		end

		v20 = TweenService:Create(Gems, v18, {
			Size = v16
		})
		v20:Play()
		v20.Completed:Connect(function() --[[ Line: 419 | Upvalues: v19 (ref), Gems (ref) ]]
			if v19 then
				return
			end

			Gems.Visible = false
		end)
	end

	local v21 = TweenNumber.new(0.35, ClientPlayerData.serverProfile:getState().gems)

	v21:OnChange(function(p1) --[[ Line: 429 | Upvalues: Counter (copy) ]]
		Counter.Text = tostring((math.floor(p1)))
	end)

	local gems = ClientPlayerData.serverProfile:getState().gems

	Counter.Text = tostring(gems)

	local v22 = 0

	CurrencyCounterSlot.register("Gems", function() --[[ Line: 439 | Upvalues: v22 (ref), hideCounter (copy) ]]
		v22 = 0
		hideCounter()
	end)

	local function isNearShop() --[[ isNearShop | Line: 446 | Upvalues: LocalPlayer (copy) ]]
		local OpenGemsShop = workspace:FindFirstChild("OpenGemsShop")

		if not (OpenGemsShop and OpenGemsShop:IsA("BasePart")) then
			return false
		end

		local Character = LocalPlayer.Character

		if not Character then
			return false
		end

		local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")

		if not HumanoidRootPart then
			return false
		end

		return (HumanoidRootPart.Position - OpenGemsShop.Position).Magnitude <= 30
	end

	local GemFlyoutLayer = Instance.new("ScreenGui")

	GemFlyoutLayer.Name = "GemFlyoutLayer"
	GemFlyoutLayer.DisplayOrder = 100
	GemFlyoutLayer.IgnoreGuiInset = true
	GemFlyoutLayer.ResetOnSpawn = false
	GemFlyoutLayer.Parent = PlayerGui

	local function playGemFlyout() --[[ playGemFlyout | Line: 469 | Upvalues: Gems (copy), GemFlyoutLayer (copy), SFX (ref), TweenService (ref), v4 (ref) ]]
		local v1 = Gems.AbsolutePosition + Gems.AbsoluteSize / 2
		local v2 = GemFlyoutLayer.AbsoluteSize / 2

		for i = 1, 8 do
			task.delay((i - 1) * 0.07, function() --[[ Line: 474 | Upvalues: GemFlyoutLayer (ref), v2 (copy), SFX (ref), TweenService (ref), v4 (ref), v1 (copy) ]]
				local ImageLabel = Instance.new("ImageLabel")

				ImageLabel.Image = "rbxassetid://86270302884166"
				ImageLabel.BackgroundTransparency = 1
				ImageLabel.AnchorPoint = Vector2.new(0.5, 0.5)
				ImageLabel.Size = UDim2.fromOffset(0, 0)

				local AbsoluteSize = GemFlyoutLayer.AbsoluteSize
				local v12 = (math.random() - 0.5) * 2 * 0.4 * AbsoluteSize.X

				ImageLabel.Position = UDim2.fromOffset(v2.X + v12, v2.Y + (math.random() - 0.5) * 2 * 0.4 * AbsoluteSize.Y)
				ImageLabel.Parent = GemFlyoutLayer
				SFX.PlaySoundWithRandomPitch(SFX.Sounds.Pop, 0.7, 0.9, 1.3)

				local v3 = TweenService:Create(ImageLabel, TweenInfo.new(0.2, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
					Size = v4
				})

				v3:Play()
				v3.Completed:Wait()

				local v42 = TweenService:Create(ImageLabel, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
					Position = UDim2.fromOffset(v1.X, v1.Y),
					Size = UDim2.fromOffset(0, 0)
				})

				v42:Play()
				v42.Completed:Wait()
				ImageLabel:Destroy()
			end)
		end
	end

	local gems2 = ClientPlayerData.serverProfile:getState().gems

	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 515 ]]
		return p1.gems
	end, function(p1) --[[ Line: 517 | Upvalues: gems2 (ref), v22 (ref), CurrencyCounterSlot (ref), showCounter (copy), playGemFlyout (copy), v21 (copy) ]]
		local v1 = p1 - gems2

		gems2 = p1
		v22 = (1 / 0)
		CurrencyCounterSlot.claim("Gems")
		showCounter()

		if v1 > 0 then
			playGemFlyout()
		end

		v21:Set(p1, function() --[[ Line: 532 | Upvalues: v22 (ref) ]]
			v22 = os.clock() + 4
		end)
	end)
	RunService.Heartbeat:Connect(function() --[[ Line: 540 | Upvalues: isNearShop (copy), CurrencyCounterSlot (ref), showCounter (copy), v22 (ref), hideCounter (copy) ]]
		debug.profilebegin("UECS/GemsShopUI.Heartbeat")

		if isNearShop() then
			if CurrencyCounterSlot.tryClaim("Gems") then
				showCounter()
			end
		elseif v22 <= os.clock() then
			hideCounter()
			CurrencyCounterSlot.release("Gems")
		end

		debug.profileend()
	end)
end

return t