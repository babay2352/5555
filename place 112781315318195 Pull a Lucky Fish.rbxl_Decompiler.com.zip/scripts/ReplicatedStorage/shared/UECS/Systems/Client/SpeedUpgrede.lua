-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ContextActionService = game:GetService("ContextActionService")
local GuiService = game:GetService("GuiService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local UserInputService = game:GetService("UserInputService")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local SpeedUpgrade = require(ReplicatedStorage.shared.UECS.Components.SpeedUpgrade)
local SpeedUpgradeConfig = require(ReplicatedStorage.shared.config.SpeedUpgradeConfig)
local UpgradeTile = require(ReplicatedStorage.client.UpgradeTile)
local bindToButtonPress = require(ReplicatedStorage.shared.util.bindToButtonPress)

return {
	UECS = nil,
	Priority = 30,
	Init = function(p1) --[[ Init | Line: 21 | Upvalues: Players (copy), SpeedUpgrade (copy), SpeedUpgradeConfig (copy), UpgradeTile (copy), UserInputService (copy), GuiService (copy), bindToButtonPress (copy), ContextActionService (copy) ]]
		local MainUI = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI")
		local SpeedUpgrede = MainUI:WaitForChild("SpeedUpgrede")
		local v1 = SpeedUpgrede:WaitForChild("Content")
		local TopBar = SpeedUpgrede:WaitForChild("TopBar")
		local Template = v1:WaitForChild("Template")

		Template.Visible = false
		SpeedUpgrede.Visible = false

		local v2 = SpeedUpgrade.Add(SpeedUpgrede)

		TopBar:WaitForChild("CloseButton").MouseButton1Down:Connect(function() --[[ Line: 37 | Upvalues: p1 (copy) ]]
			p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
		end)

		local t = {}
		local t2 = {}

		for v3, v4 in SpeedUpgradeConfig do
			local v5 = UpgradeTile.new(Template, v4)

			table.insert(t, v5)

			local v6 = v5:GetFrame()

			v6.SelectionOrder = v3
			v6.Parent = v1
			table.insert(t2, v6)
		end

		local function onSelectionChange() --[[ onSelectionChange | Line: 51 | Upvalues: UserInputService (ref), GuiService (ref), t2 (copy), v2 (copy), SpeedUpgrede (copy) ]]
			if UserInputService.PreferredInput ~= Enum.PreferredInput.Gamepad then
				return
			end

			local SelectedObject = GuiService.SelectedObject

			for v1, v22 in t2 do
				local v3 = SelectedObject == v22

				for v4, v5 in v22:QueryDescendants("ImageLabel.GamepadControl") do
					v5.BackgroundTransparency = if v3 then 0 else 1
					v5.ImageTransparency = v5.BackgroundTransparency
				end
			end

			if not v2.Visible:Get() or SelectedObject and SelectedObject:IsDescendantOf(SpeedUpgrede) then
				return
			end

			GuiService:Select(SpeedUpgrede)
		end

		GuiService:GetPropertyChangedSignal("SelectedObject"):Connect(onSelectionChange)
		v2.Visible.OnChange:Connect(function(p12, p2) --[[ Line: 72 | Upvalues: SpeedUpgrede (copy), MainUI (copy), bindToButtonPress (ref), p1 (copy), t (copy), GuiService (ref), UserInputService (ref), v1 (copy), ContextActionService (ref) ]]
			SpeedUpgrede.Visible = p12

			local HUD = MainUI:FindFirstChild("HUD")

			if HUD then
				HUD.Visible = not p12
			end

			if p12 == p2 then
				return
			end

			if p12 then
				bindToButtonPress("UpgradesCloseAction", Enum.KeyCode.ButtonB, function() --[[ Line: 84 | Upvalues: p1 (ref) ]]
					p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
				end)
				bindToButtonPress("UpgradesU1Action", Enum.KeyCode.ButtonX, function() --[[ Line: 89 | Upvalues: t (ref), GuiService (ref) ]]
					for v1, v2 in t do
						if v2:GetFrame() == GuiService.SelectedObject then
							v2:_purchase(v2._config.Buy1Amount)

							return
						end
					end
				end)
				bindToButtonPress("UpgradesU2Action", Enum.KeyCode.ButtonY, function() --[[ Line: 98 | Upvalues: t (ref), GuiService (ref) ]]
					for v1, v2 in t do
						if v2:GetFrame() == GuiService.SelectedObject then
							v2:_purchase(v2._config.Buy2Amount)

							return
						end
					end
				end)

				if UserInputService.PreferredInput == Enum.PreferredInput.Gamepad then
					GuiService:Select(v1)
				end
			else
				ContextActionService:UnbindAction("UpgradesCloseAction")
				ContextActionService:UnbindAction("UpgradesU1Action")
				ContextActionService:UnbindAction("UpgradesU2Action")
				GuiService.SelectedObject = nil
			end
		end)
	end
}