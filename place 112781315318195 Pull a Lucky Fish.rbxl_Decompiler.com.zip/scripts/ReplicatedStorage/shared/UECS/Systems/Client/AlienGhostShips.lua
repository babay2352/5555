-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local Workspace = game:GetService("Workspace")
local AlienEventConfig = require(ReplicatedStorage.shared.config.AlienEventConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Remotes = require(ReplicatedStorage.shared.Remotes)
local t = {
	UECS = nil
}
local Ride = AlienEventConfig.Ship.Ride
local t2 = {}

local function getFolder() --[[ getFolder | Line: 87 | Upvalues: Workspace (copy) ]]
	local AlienGhostShips = Workspace:FindFirstChild("AlienGhostShips")

	if AlienGhostShips and AlienGhostShips:IsA("Folder") then
		return AlienGhostShips
	end

	local AlienGhostShips2 = Instance.new("Folder")

	AlienGhostShips2.Name = "AlienGhostShips"
	AlienGhostShips2.Parent = Workspace

	return AlienGhostShips2
end

local function getShipTemplate() --[[ getShipTemplate | Line: 99 | Upvalues: ReplicatedStorage (copy), Ride (copy) ]]
	local model = ReplicatedStorage.shared:FindFirstChild("model")
	local v1 = if model then model:FindFirstChild("AlienEvent") else model
	local v2 = if v1 then v1:FindFirstChild(Ride.TemplateName) else v1

	if v2 and v2:IsA("Model") then
		return v2
	end

	return nil
end

local function getGhost(p1) --[[ getGhost | Line: 106 | Upvalues: t2 (copy) ]]
	local v1 = t2[p1]

	if v1 then
		return v1
	end

	local t = {
		ship = nil,
		seatOffset = nil,
		current = nil,
		target = nil,
		lastPoseAt = 0,
		hiddenCharacter = nil,
		hiddenNameDisplay = nil,
		promptCharacter = nil,
		hiddenDecals = {},
		hiddenCollide = {},
		hiddenPrompts = {}
	}

	t2[p1] = t

	return t
end

local function hideCharacter(p1, p2) --[[ hideCharacter | Line: 134 ]]
	if p1.hiddenCharacter == p2 then
		return
	end

	p1.hiddenCharacter = p2
	table.clear(p1.hiddenDecals)

	for v1, v2 in p2:GetDescendants() do
		if v2:IsA("BasePart") then
			v2.LocalTransparencyModifier = 1

			continue
		end

		if v2:IsA("Decal") or v2:IsA("Texture") then
			p1.hiddenDecals[v2] = v2.Transparency
			v2.Transparency = 1

			continue
		end

		if v2:IsA("Humanoid") then
			p1.hiddenNameDisplay = v2.DisplayDistanceType
			v2.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
		end
	end

	if p1.promptCharacter == p2 then
		return
	end

	p1.promptCharacter = p2
	table.clear(p1.hiddenPrompts)
	table.clear(p1.hiddenCollide)

	for v3, v4 in p2:GetDescendants() do
		if v4:IsA("ProximityPrompt") or v4:IsA("BillboardGui") then
			p1.hiddenPrompts[v4] = v4.Enabled
			v4.Enabled = false

			continue
		end

		if v4:IsA("BasePart") and v4.CanCollide then
			p1.hiddenCollide[v4] = true
			v4.CanCollide = false
		end
	end
end

local function unhideCharacter(p1) --[[ unhideCharacter | Line: 169 ]]
	local hiddenCharacter = p1.hiddenCharacter

	p1.hiddenCharacter = nil

	if not hiddenCharacter then
		return
	end

	for v1, v2 in hiddenCharacter:GetDescendants() do
		if v2:IsA("BasePart") then
			v2.LocalTransparencyModifier = 0

			continue
		end

		if v2:IsA("Humanoid") and p1.hiddenNameDisplay then
			v2.DisplayDistanceType = p1.hiddenNameDisplay
		end
	end

	for v3, v4 in p1.hiddenDecals do
		if v3.Parent then
			v3.Transparency = v4
		end
	end

	table.clear(p1.hiddenDecals)
	p1.hiddenNameDisplay = nil
end

local function restoreInteraction(p1) --[[ restoreInteraction | Line: 192 ]]
	p1.promptCharacter = nil

	for v1, v2 in p1.hiddenPrompts do
		if v1.Parent then
			v1.Enabled = v2
		end
	end

	for v3, v4 in p1.hiddenCollide do
		if v3.Parent then
			v3.CanCollide = v4
		end
	end

	table.clear(p1.hiddenPrompts)
	table.clear(p1.hiddenCollide)
end

local function destroyShip(p1) --[[ destroyShip | Line: 210 ]]
	local ship = p1.ship

	p1.ship = nil
	p1.current = nil
	p1.target = nil

	if not ship then
		return
	end

	ship:Destroy()
end

local function dropGhost(p1) --[[ dropGhost | Line: 220 | Upvalues: t2 (copy), unhideCharacter (copy), restoreInteraction (copy) ]]
	local v1 = t2[p1]

	t2[p1] = nil

	if not v1 then
		return
	end

	unhideCharacter(v1)
	restoreInteraction(v1)

	local ship = v1.ship

	v1.ship = nil
	v1.current = nil
	v1.target = nil

	if not ship then
		return
	end

	ship:Destroy()
end

local function buildShip(p1, p2, p3) --[[ buildShip | Line: 230 | Upvalues: ReplicatedStorage (copy), Ride (copy), CollectionService (copy), Workspace (copy) ]]
	local model = ReplicatedStorage.shared:FindFirstChild("model")
	local v1 = if model then model:FindFirstChild("AlienEvent") else model
	local v2 = if v1 then v1:FindFirstChild(Ride.TemplateName) else v1
	local v3 = if v2 and v2:IsA("Model") then v2 else nil

	if not v3 then
		return
	end

	local v4 = v3:Clone()

	v4.Name = ("AlienGhostShip_%*"):format(p2.Name)
	CollectionService:RemoveTag(v4, Ride.Tag)

	local v5 = nil

	for v6, v7 in v4:GetDescendants() do
		if v7:IsA("BasePart") then
			v7.Anchored = true
			v7.CanCollide = false
			v7.CanTouch = false
			v7.CanQuery = false

			if v7.Name == Ride.SeatMarkerName or (v7.Name == Ride.PromptMarkerName or v7.Name == Ride.ExitMarkerName) then
				v7.Transparency = 1
			end

			if v7.Name == Ride.SeatMarkerName then
				v5 = v7
			end

			continue
		end

		if v7:IsA("ParticleEmitter") or v7:IsA("Beam") then
			v7.Enabled = false

			continue
		end

		if v7:IsA("ProximityPrompt") then
			v7:Destroy()
		end
	end

	if not v5 then
		v4:Destroy()
		warn((("[AlienGhostShips] template has no %* \226\128\148 cannot show a ghost ship"):format(Ride.SeatMarkerName)))

		return
	end

	p1.seatOffset = v4:GetPivot():ToObjectSpace(v5.CFrame)
	p1.current = p3
	p1.target = p3
	p1.ship = v4
	v4:PivotTo(p3)

	local AlienGhostShips = Workspace:FindFirstChild("AlienGhostShips")
	local v8

	if AlienGhostShips and AlienGhostShips:IsA("Folder") then
		v8 = AlienGhostShips
	else
		local AlienGhostShips2 = Instance.new("Folder")

		AlienGhostShips2.Name = "AlienGhostShips"
		AlienGhostShips2.Parent = Workspace
		v8 = AlienGhostShips2
	end

	v4.Parent = v8
end

local function onShipPose(p1) --[[ onShipPose | Line: 286 | Upvalues: Players (copy), getGhost (copy), buildShip (copy), unhideCharacter (copy) ]]
	if type(p1) ~= "table" then
		return
	end

	if typeof(p1.CFrame) ~= "CFrame" then
		return
	end

	local v3 = Players:GetPlayerByUserId(tonumber(p1.UserId) or 0)

	if not v3 or v3 == Players.LocalPlayer then
		return
	end

	local v4 = getGhost(v3)

	v4.lastPoseAt = os.clock()
	v4.target = p1.CFrame

	if v4.ship then
		return
	end

	buildShip(v4, v3, p1.CFrame)
	unhideCharacter(v4)
end

local function stepGhosts(p1) --[[ stepGhosts | Line: 303 | Upvalues: t2 (copy), unhideCharacter (copy), restoreInteraction (copy) ]]
	local v1 = os.clock()

	for v2, v3 in t2 do
		if v2.Parent then
			local ship = v3.ship

			if ship then
				if v1 - v3.lastPoseAt > 3 then
					local ship2 = v3.ship

					v3.ship = nil
					v3.current = nil
					v3.target = nil

					if ship2 then
						ship2:Destroy()
					end

					continue
				end

				local v4 = v3.current:Lerp(v3.target, 1 - math.exp(p1 * -10))

				v3.current = v4
				ship:PivotTo(v4)

				local Character = v2.Character
				local seatOffset = v3.seatOffset

				if Character and (Character.Parent and seatOffset) then
					Character:PivotTo(v4 * seatOffset)
				end
			end

			continue
		end

		local v5 = t2[v2]

		t2[v2] = nil

		if v5 then
			unhideCharacter(v5)
			restoreInteraction(v5)

			local ship = v5.ship

			v5.ship = nil
			v5.current = nil
			v5.target = nil

			if ship then
				ship:Destroy()
			end
		end
	end
end

function t.Init(p1) --[[ Init | Line: 337 | Upvalues: AlienEventConfig (copy), CollectionService (copy), Ride (copy), Players (copy), getGhost (copy), hideCharacter (copy), t2 (copy), unhideCharacter (copy), restoreInteraction (copy), Remotes (copy), onShipPose (copy), dropGhost (copy), RunService (copy), stepGhosts (copy) ]]
	if not AlienEventConfig.Enabled then
		return
	end

	CollectionService:GetInstanceAddedSignal(Ride.FlyingTag):Connect(function(p1) --[[ Line: 346 | Upvalues: Players (ref), getGhost (ref), hideCharacter (ref) ]]
		if not p1:IsA("Model") then
			return
		end

		local v1 = Players:GetPlayerFromCharacter(p1)

		if not v1 or v1 == Players.LocalPlayer then
			return
		end

		local v2 = getGhost(v1)

		if v2.ship then
			return
		end

		hideCharacter(v2, p1)
	end)
	CollectionService:GetInstanceRemovedSignal(Ride.FlyingTag):Connect(function(p1) --[[ Line: 362 | Upvalues: t2 (ref), unhideCharacter (ref), restoreInteraction (ref) ]]
		for v1, v2 in t2 do
			if v2.hiddenCharacter == p1 or (v2.promptCharacter == p1 or v1.Character == p1) then
				unhideCharacter(v2)
				restoreInteraction(v2)
			end
		end
	end)

	for v1, v2 in CollectionService:GetTagged(Ride.FlyingTag) do
		if v2:IsA("Model") then
			local v3 = Players:GetPlayerFromCharacter(v2)

			if v3 and v3 ~= Players.LocalPlayer then
				local v4 = getGhost(v3)

				if not v4.ship then
					hideCharacter(v4, v2)
				end
			end
		end
	end

	Remotes.AlienShipPose:On(onShipPose)
	Players.PlayerRemoving:Connect(dropGhost)
	RunService.Heartbeat:Connect(stepGhosts)
end

return t