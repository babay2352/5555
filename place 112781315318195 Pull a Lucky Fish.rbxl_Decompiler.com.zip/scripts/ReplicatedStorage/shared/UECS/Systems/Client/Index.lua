-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ContentProvider = game:GetService("ContentProvider")
local ContextActionService = game:GetService("ContextActionService")
local GamepadService = game:GetService("GamepadService")
local GuiService = game:GetService("GuiService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")
local CashDisplay = require(ReplicatedStorage.shared.module.CashDisplay)
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local ConvertValue = require(ReplicatedStorage.shared.util.ConvertValue)
local FishConfig = require(ReplicatedStorage.shared.config.FishConfig)
local FishEarnings = require(ReplicatedStorage.shared.util.FishEarnings)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local IndexCategoryConfig = require(ReplicatedStorage.shared.config.IndexCategoryConfig)
local Index = require(ReplicatedStorage.shared.UECS.Components.Index)
local IndexMilestoneConfig = require(ReplicatedStorage.shared.config.IndexMilestoneConfig)
local IndexRewardConfig = require(ReplicatedStorage.shared.config.IndexRewardConfig)
local Maid = require(ReplicatedStorage.shared.class.Maid)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local Signal = require(ReplicatedStorage.package.Signal)
local Worlds = require(ReplicatedStorage.shared.util.Worlds)
local WorldsConfig = require(ReplicatedStorage.shared.config.WorldsConfig)
local bindToButtonPress = require(ReplicatedStorage.shared.util.bindToButtonPress)
local isBeastLikeFish = require(ReplicatedStorage.shared.util.isBeastLikeFish)
local rarityConfig = require(ReplicatedStorage.shared.config.rarityConfig)
local v1 = Color3.new(255/255, 255/255, 255/255)
local v2 = GuiService:IsTenFootInterface()
local t = {
	"Common",
	"Uncommon",
	"Rare",
	"Epic",
	"Legendary",
	"Mythic",
	"Godly",
	"Secret",
	"Devine",
	"Hacked",
	"OG",
	"Celestial",
	"Doodle",
	"Backroom",
	"SCP",
	"Deeps",
	"Exclusive",
	"Beast",
	"Boss"
}

task.spawn(function() --[[ Line: 79 | Upvalues: FishConfig (copy), ContentProvider (copy) ]]
	local t = {}

	for v1, v2 in FishConfig do
		if v2.Image then
			table.insert(t, v2.Image)
		end
	end

	ContentProvider:PreloadAsync(t)
end)

local t2 = {
	UECS = nil,
	Priority = 30
}
local v3 = Signal.new()

local function spinForever(p1) --[[ spinForever | Line: 99 | Upvalues: TweenService (copy), v3 (copy) ]]
	return task.spawn(function() --[[ Line: 100 | Upvalues: TweenService (ref), p1 (copy), v3 (ref) ]]
		local v1 = TweenService:Create(p1, TweenInfo.new(12, Enum.EasingStyle.Linear), {
			Rotation = p1.Rotation + 360
		})
		local v2 = false

		v3:Once(function() --[[ Line: 105 | Upvalues: v2 (ref), v1 (copy) ]]
			print("closed signal")
			v2 = true
			v1:Cancel()
		end)

		while p1.Parent and not v2 do
			p1.Rotation = 0
			v1:Play()
			v1.Completed:Wait()
		end
	end)
end

local function swayForever(p1, p2) --[[ swayForever | Line: 119 | Upvalues: TweenService (copy) ]]
	p1.Rotation = -p2

	local v1 = TweenService:Create(p1, TweenInfo.new(1, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true), {
		Rotation = p2
	})

	v1:Play()

	return v1
end

local function lighten(p1, p2) --[[ lighten | Line: 132 ]]
	return Color3.new(p1.R + (1 - p1.R) * p2, p1.G + (1 - p1.G) * p2, p1.B + (1 - p1.B) * p2)
end

local function darken(p1, p2) --[[ darken | Line: 140 ]]
	return Color3.new(p1.R * (1 - p2), p1.G * (1 - p2), p1.B * (1 - p2))
end

local function getSortedFishNames() --[[ getSortedFishNames | Line: 149 | Upvalues: FishConfig (copy) ]]
	local t = {}

	for k in pairs(FishConfig) do
		table.insert(t, k)
	end

	table.sort(t, function(p1, p2) --[[ Line: 154 | Upvalues: FishConfig (ref) ]]
		local EarningsPercent = FishConfig[p1].EarningsPercent
		local EarningsPercent2 = FishConfig[p2].EarningsPercent

		if EarningsPercent ~= nil == (if EarningsPercent2 == nil then false else true) then
			if EarningsPercent == nil then
				return FishConfig[p1].Earnings < FishConfig[p2].Earnings
			end

			return EarningsPercent < EarningsPercent2
		end

		return EarningsPercent == nil
	end)

	return t
end

local function getButtonTextLabel(p1) --[[ getButtonTextLabel | Line: 171 ]]
	local v1 = p1:FindFirstChild("Content")

	if not v1 then
		return nil
	end

	for v2, v3 in v1:GetChildren() do
		if v3:IsA("TextLabel") then
			return v3
		end
	end

	return nil
end

local function getButtonIcon(p1) --[[ getButtonIcon | Line: 184 ]]
	local v1 = p1:FindFirstChild("Content")

	if not v1 then
		return nil
	end

	for v2, v3 in v1:GetChildren() do
		if v3:IsA("ImageLabel") and v3.Name ~= "Pattern" then
			return v3
		end
	end

	return nil
end

function t2.Init(p1) --[[ Init | Line: 197 | Upvalues: Players (copy), Index (copy), Maid (copy), bindToButtonPress (copy), GuiService (copy), ClientPlayerData (copy), Remotes (copy), GamepadService (copy), TweenService (copy), v3 (copy), swayForever (copy), ContextActionService (copy), v2 (copy), getSortedFishNames (copy), FishConfig (copy), v1 (copy), Worlds (copy), isBeastLikeFish (copy), WorldsConfig (copy), ConvertValue (copy), t (copy), rarityConfig (copy), CashDisplay (copy), FishEarnings (copy), IndexRewardConfig (copy), IndexCategoryConfig (copy), getButtonTextLabel (copy), getButtonIcon (copy), darken (copy), IndexMilestoneConfig (copy), RunService (copy), UserInputService (copy) ]]
	local MainUI = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI")
	local IndexNew = MainUI:WaitForChild("IndexNew")
	local ScrollingFrame = IndexNew.Content.ScrollingFrame
	local FishTemplateNotAcquired = ScrollingFrame.FishTemplateNotAcquired

	FishTemplateNotAcquired.Visible = false

	local TemplateFrame = ScrollingFrame.TemplateFrame

	TemplateFrame.Visible = false

	local Categories = IndexNew:WaitForChild("Categories")
	local CategoryButtonTemplate = Categories:WaitForChild("CategoryButtonTemplate")

	CategoryButtonTemplate.Visible = false

	local Footer = IndexNew.Content:WaitForChild("Footer")
	local CollectBar = Footer:WaitForChild("CollectBar")
	local Bar = CollectBar:WaitForChild("Bar")
	local ImageDecor = CollectBar:FindFirstChild("ImageDecor")
	local v12 = ImageDecor and ImageDecor:FindFirstChild("NumberProgress")
	local ClaimAllButton = Footer:FindFirstChild("ClaimAllButton")
	local ContentFrame = IndexNew.TopBar:FindFirstChild("ContentFrame")
	local v22 = ContentFrame and ContentFrame:FindFirstChild("TotalFishIndex")

	IndexNew.Visible = false

	local v32 = Index.Add(IndexNew)
	local v4 = Maid.new()

	v32.Visible.OnChange:Connect(function(p12, p2) --[[ Line: 225 | Upvalues: IndexNew (copy), MainUI (copy), bindToButtonPress (ref), p1 (copy), GuiService (ref), ClientPlayerData (ref), Remotes (ref), GamepadService (ref), CollectBar (copy), TweenService (ref), v3 (ref), swayForever (ref), v4 (copy), ContextActionService (ref) ]]
		IndexNew.Visible = p12

		local HUD = MainUI:FindFirstChild("HUD")

		if HUD then
			HUD.Visible = not p12
		end

		if p12 == p2 then
			return
		end

		if p12 then
			bindToButtonPress("IndexCloseAction", Enum.KeyCode.ButtonB, function() --[[ Line: 237 | Upvalues: p1 (ref) ]]
				p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
			end)
			bindToButtonPress("IndexClaimAction", Enum.KeyCode.ButtonX, function() --[[ Line: 241 | Upvalues: GuiService (ref), ClientPlayerData (ref), Remotes (ref) ]]
				local SelectedObject = GuiService.SelectedObject
				local v1 = ClientPlayerData.serverProfile:getState()

				if not v1.index[SelectedObject.Name] then
					return
				end

				if v1.claimedIndexRewards and v1.claimedIndexRewards[SelectedObject.Name] then
					return
				end

				Remotes.RequestClaimIndexReward:Fire(SelectedObject.Name)
			end)
			GamepadService:EnableGamepadCursor(nil)

			local v1 = nil

			for v2, v32 in CollectBar:GetChildren() do
				if v32.Name == "RewardFor75" and v32:IsA("Frame") then
					v1 = v32

					break
				end
			end

			if not v1 then
				return
			end

			for v42, v5 in v1:GetChildren() do
				if v5:IsA("ImageLabel") and v5.Name == "Shine" then
					task.spawn(function() --[[ Line: 100 | Upvalues: TweenService (ref), v5 (copy), v3 (ref) ]]
						local v1 = TweenService:Create(v5, TweenInfo.new(12, Enum.EasingStyle.Linear), {
							Rotation = v5.Rotation + 360
						})
						local v2 = false

						v3:Once(function() --[[ Line: 105 | Upvalues: v2 (ref), v1 (copy) ]]
							print("closed signal")
							v2 = true
							v1:Cancel()
						end)

						while v5.Parent and not v2 do
							v5.Rotation = 0
							v1:Play()
							v1.Completed:Wait()
						end
					end)
				end
			end

			local Icon = v1:FindFirstChild("Icon")

			if Icon and Icon:IsA("GuiObject") then
				local Rotation = Icon.Rotation
				local v6 = swayForever(Icon, 8)

				v4:GiveTask(function() --[[ Line: 273 | Upvalues: v6 (copy), Icon (copy), Rotation (copy) ]]
					v6:Cancel()
					v6:Destroy()
					Icon.Rotation = Rotation
				end)
			end
		else
			ContextActionService:UnbindAction("IndexCloseAction")
			ContextActionService:UnbindAction("IndexClaimAction")
			GuiService.SelectedObject = nil
			v3:Fire()
			v4:DoCleaning()
			GamepadService:DisableGamepadCursor()
		end
	end)

	local SelectedObject = GuiService.SelectedObject

	GuiService:GetPropertyChangedSignal("SelectedObject"):Connect(function() --[[ Line: 292 | Upvalues: GuiService (ref), SelectedObject (ref) ]]
		local SelectedObject2 = GuiService.SelectedObject

		if SelectedObject then
			local ClaimButton = SelectedObject:FindFirstChild("ClaimButton")

			if ClaimButton then
				ClaimButton.ClipsDescendants = true
			end

			SelectedObject = nil
		end

		if not (SelectedObject2 and SelectedObject2:HasTag("FishIndexItem")) then
			return
		end

		local ClaimButton = SelectedObject2:FindFirstChild("ClaimButton")

		if ClaimButton then
			ClaimButton.ClipsDescendants = false
		end

		SelectedObject = SelectedObject2
	end)
	GamepadService:GetPropertyChangedSignal("GamepadCursorEnabled"):Connect(function() --[[ Line: 312 | Upvalues: v2 (ref), IndexNew (copy), GamepadService (ref) ]]
		if not v2 or (not IndexNew.Visible or GamepadService.GamepadCursorEnabled) then
			return
		end

		GamepadService:EnableGamepadCursor(nil)
	end)
	IndexNew.TopBar.CloseButton.MouseButton1Down:Connect(function() --[[ Line: 319 | Upvalues: p1 (copy) ]]
		p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
	end)

	local Index2 = MainUI:WaitForChild("HUD").Buttons:FindFirstChild("Index")
	local v5 = Index2 and Index2:FindFirstChild("Alert")
	local v6 = v5 and v5:FindFirstChild("TextLabel")
	local v7 = getSortedFishNames()
	local t2 = {}
	local v8 = #v7

	for i, v in ipairs(v7) do
		local id = FishConfig[v].Rarity.id

		if not t2[id] then
			t2[id] = {}
		end

		table.insert(t2[id], v)
	end

	local t3 = {}
	local t4 = {}
	local t5 = {}
	local t6 = {}
	local t7 = {}
	local count = 0
	local v10 = nil

	local function updateSectionLabel(p1) --[[ updateSectionLabel | Line: 356 | Upvalues: t6 (copy) ]]
		local v1 = t6[p1]

		if v1 then
			v1.label.Text = ("%* (%*/%*)"):format(v1.title, v1.acquired, v1.total)
		end
	end

	local function updateClaimButton(p1) --[[ updateClaimButton | Line: 364 | Upvalues: t4 (copy), ClientPlayerData (ref) ]]
		local v1 = t4[p1]

		if not v1 then
			return
		end

		local ClaimButton = v1:FindFirstChild("ClaimButton")

		if not ClaimButton then
			return
		end

		local v2 = ClientPlayerData.serverProfile:getState()
		local v3 = v2.index and v2.index[p1]

		ClaimButton.Visible = if v3 then not (v2.claimedIndexRewards and v2.claimedIndexRewards[p1]) else v3
	end

	local function flipToAcquired(p1) --[[ flipToAcquired | Line: 379 | Upvalues: t4 (copy), FishConfig (ref), v1 (ref), ClientPlayerData (ref) ]]
		local v12 = t4[p1]

		if not v12 then
			return
		end

		v12.Icon.ImageColor3 = v1
		v12.DisplayName.Text = FishConfig[p1].DisplayName

		local v3 = t4[p1]

		if not v3 then
			return
		end

		local ClaimButton = v3:FindFirstChild("ClaimButton")

		if not ClaimButton then
			return
		end

		local v4 = ClientPlayerData.serverProfile:getState()
		local v5 = v4.index and v4.index[p1]

		ClaimButton.Visible = if v5 then not (v4.claimedIndexRewards and v4.claimedIndexRewards[p1]) else v5
	end

	local t8 = {}

	local function fishOfWorld(p1) --[[ fishOfWorld | Line: 396 | Upvalues: t8 (copy), Worlds (ref), FishConfig (ref) ]]
		local v1 = t8[p1]

		if v1 then
			return v1
		end

		local t = {}

		for v2, v3 in Worlds.GetBiomes(p1) do
			if v3.FishPool then
				for v4, v5 in v3.FishPool do
					local v6 = FishConfig[v5]

					if v6 and v3.RarityWeights[v6.Rarity.id] then
						t[v5] = true
					end
				end

				continue
			end

			for v7, v8 in FishConfig do
				if v3.RarityWeights[v8.Rarity.id] then
					t[v7] = true
				end
			end
		end

		t8[p1] = t

		return t
	end

	local function belongsToAnyWorld(p1) --[[ belongsToAnyWorld | Line: 425 | Upvalues: Worlds (ref), fishOfWorld (copy) ]]
		for v1, v2 in Worlds.AllWorldIds() do
			if fishOfWorld(v2)[p1] then
				return true
			end
		end

		return false
	end

	local function matchesCategory(p1, p2) --[[ matchesCategory | Line: 435 | Upvalues: FishConfig (ref), isBeastLikeFish (ref), fishOfWorld (copy), WorldsConfig (ref), Worlds (ref) ]]
		local v1 = FishConfig[p1]

		if not v1 then
			return false
		end

		local v2 = if v1.Event == true then true else false
		local v3 = if v1.Weather == nil then false else true
		local v4 = if v1.Rarity.id == "Deeps" then true elseif v1.Deeps == true then true else false

		if p2.kind == "deeps" then
			return v4
		end

		if p2.kind == "beast" then
			return isBeastLikeFish(v1) and (not v2 and (not v3 and not v4))
		end

		if p2.kind == "event" then
			return if v2 then not v3 else v2
		end

		if p2.kind == "weather" then
			return v3
		end

		if isBeastLikeFish(v1) or (v2 or (v3 or v4)) then
			return false
		end

		if not p2.worldId then
			return true
		end

		if fishOfWorld(p2.worldId)[p1] then
			return true
		end

		local v7

		if p2.worldId == WorldsConfig.DefaultWorldId then
			local v8 = false

			for v9, v10 in Worlds.AllWorldIds() do
				if fishOfWorld(v10)[p1] then
					v8 = true

					break
				end
			end

			v7 = not v8
		else
			v7 = false
		end

		return v7
	end

	local function formatExistText(p1) --[[ formatExistText | Line: 473 | Upvalues: t3 (ref), ConvertValue (ref) ]]
		return ("%* Exist"):format((ConvertValue.suffixformat(t3[p1] or 0)))
	end

	local function setupExistLabel(p1, p2) --[[ setupExistLabel | Line: 484 | Upvalues: FishConfig (ref), isBeastLikeFish (ref), t3 (ref), ConvertValue (ref) ]]
		local ExistCount = p1:FindFirstChild("ExistCount")

		if not ExistCount then
			return
		end

		local v1 = FishConfig[p2]
		local v2 = if v1 == nil then false else isBeastLikeFish(v1)

		ExistCount.Visible = v2

		if not v2 then
			return
		end

		ExistCount.Text = ("%* Exist"):format((ConvertValue.suffixformat(t3[p2] or 0)))
	end

	local function updateExistCountLabel(p1) --[[ updateExistCountLabel | Line: 498 | Upvalues: t4 (copy), t3 (ref), ConvertValue (ref) ]]
		local v1 = t4[p1]

		if not v1 then
			return
		end

		local ExistCount = v1:FindFirstChild("ExistCount")

		if ExistCount and ExistCount.Visible then
			ExistCount.Text = ("%* Exist"):format((ConvertValue.suffixformat(t3[p1] or 0)))
		end
	end

	local function updateBar() --[[ updateBar | Line: 510 | Upvalues: v8 (copy), count (ref), Bar (copy), v12 (copy), v22 (copy) ]]
		Bar.Size = UDim2.fromScale(math.clamp(if v8 == 0 then 0 else count / v8, 0, 1), 1)

		if v12 then
			v12.Text = ("%*/%*"):format(count, v8)
		end

		if not v22 then
			return
		end

		v22.Text = ("%*/%* Fishes"):format(count, v8)
	end

	local function updateAlert() --[[ updateAlert | Line: 521 | Upvalues: v5 (copy), v6 (copy), ClientPlayerData (ref), v10 (ref), TweenService (ref) ]]
		if not (v5 and v6) then
			return
		end

		local v1 = ClientPlayerData.serverProfile:getState()
		local v3 = v1.claimedIndexRewards or {}
		local v4 = false

		for k in pairs(v1.index or {}) do
			if not v3[k] then
				v4 = true

				break
			end
		end

		if v4 then
			v6.Text = "!"

			if not v5.Visible then
				v5.Visible = true
				v5.Rotation = -8
				v10 = TweenService:Create(v5, TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true), {
					Rotation = 8
				})
				v10:Play()
			end
		else
			if v10 then
				v10:Cancel()
				v10 = nil
			end

			v5.Rotation = 0
			v5.Visible = false
		end
	end

	local function updateGridCellSizes() --[[ updateGridCellSizes | Line: 561 | Upvalues: t7 (copy) ]]
		for v1, v2 in t7 do
			local v3 = v2:FindFirstChild("Content")
			local v4 = if v3 then v3:FindFirstChildOfClass("UIGridLayout") else v3

			if v4 then
				local X = v4.AbsoluteCellSize.X

				if not (X <= 0) then
					local X2 = v4.CellSize.X

					v4.CellSize = UDim2.new(X2.Scale, X2.Offset, 0, (math.round(X * 1.13)))

					local TitleFrame = v2:FindFirstChild("TitleFrame")

					if TitleFrame then
						local X3 = TitleFrame.Size.X

						TitleFrame.Size = UDim2.new(X3.Scale, X3.Offset, 0, (math.round(X * 0.51)))
					end
				end
			end
		end
	end

	local function buildSections(p1) --[[ buildSections | Line: 588 | Upvalues: v7 (copy), matchesCategory (copy), FishConfig (ref), t (ref), t2 (copy), rarityConfig (ref) ]]
		local t3 = {}

		if p1.kind == "event" or p1.kind == "weather" then
			local t4 = {}
			local list = {}

			for i, v in ipairs(v7) do
				if matchesCategory(v, p1) then
					local v1 = if p1.kind == "weather" then FishConfig[v].Weather or "Weather" else FishConfig[v].EventName or "Event"

					if not t4[v1] then
						t4[v1] = {}
						table.insert(list, v1)
					end

					table.insert(t4[v1], v)
				end
			end

			for i, v in ipairs(list) do
				local v3 = t4[v]

				table.insert(t3, {
					key = ("e:%*"):format(v),
					title = v,
					color = FishConfig[v3[1]].Rarity.rarityColor,
					fish = v3
				})
			end
		else
			for i, v in ipairs(t) do
				local v4 = t2[v]
				local v5 = rarityConfig[v]

				if v4 and v5 then
					local t4 = {}

					for i2, v2 in ipairs(v4) do
						if matchesCategory(v2, p1) then
							table.insert(t4, v2)
						end
					end

					if #t4 > 0 then
						table.insert(t3, {
							key = ("r:%*"):format(v),
							title = v5.displayName,
							color = v5.rarityColor,
							fish = t4
						})
					end
				end
			end
		end

		return t3
	end

	local function populateCategory(p1) --[[ populateCategory | Line: 640 | Upvalues: t7 (copy), t4 (copy), t5 (copy), t6 (copy), ClientPlayerData (ref), buildSections (copy), TemplateFrame (copy), FishConfig (ref), FishTemplateNotAcquired (copy), isBeastLikeFish (ref), CashDisplay (ref), FishEarnings (ref), Players (ref), IndexRewardConfig (ref), Remotes (ref), t3 (ref), ConvertValue (ref), ScrollingFrame (copy), v1 (ref), updateGridCellSizes (copy) ]]
		for v12, v2 in t7 do
			v2:Destroy()
		end

		table.clear(t7)
		table.clear(t4)
		table.clear(t5)
		table.clear(t6)

		local v3 = ClientPlayerData.serverProfile:getState().index or {}

		for i, v in ipairs((buildSections(p1))) do
			local v5 = TemplateFrame:Clone()

			v5.Name = v.key
			v5.LayoutOrder = i
			v5.Visible = true

			local TitleFrame = v5:FindFirstChild("TitleFrame")
			local v6 = if TitleFrame then TitleFrame:FindFirstChild("CategoryName") else TitleFrame

			if v6 then
				local UIGradient = v6:FindFirstChildOfClass("UIGradient")

				if UIGradient then
					UIGradient.Color = ColorSequence.new(v.color, Color3.new(255/255, 255/255, 255/255))
				end
			end

			local v7 = v5:FindFirstChild("Content")

			if v7 then
				local count = 0

				for i2, v2 in ipairs(v.fish) do
					local v8 = FishConfig[v2]
					local v9 = FishTemplateNotAcquired:Clone()

					v9:AddTag("FishIndexItem")

					if isBeastLikeFish(v8) or v8.Event then
						v9:AddTag("Inspect")
						v9:SetAttribute("InspectType", "IndexFish")
						v9:SetAttribute("FishName", v2)
					end

					v9.Name = v2
					v9.LayoutOrder = i2
					v9.Visible = true
					v9.Frame.UIGradient.Color = ColorSequence.new(v8.Rarity.rarityColor, Color3.fromRGB(255, 255, 255))
					v9.Icon.Image = v8.Image
					v9.Frame.BackgroundColor3 = v8.Rarity.rarityColor

					local Earnings = v9.Earnings

					if v8.EarningsPercent then
						CashDisplay.setPlainText(Earnings, (("(%*%%)"):format((math.floor(v8.EarningsPercent * 100 + 0.5)))))
					else
						CashDisplay.applyToLabel(Earnings, FishEarnings.perFish(Players.LocalPlayer, v2, false, 1, nil), {
							Suffix = "/s",
							Compact = true
						})
					end

					local ClaimButton = v9:FindFirstChild("ClaimButton")

					if ClaimButton then
						ClaimButton.Visible = false

						local v12 = IndexRewardConfig.getRewardForFish(v2)
						local v13 = ClaimButton:FindFirstChild("Content")

						if v13 and v12 > 0 then
							local TextLabel = v13:FindFirstChild("TextLabel")

							if TextLabel then
								TextLabel.Text = ("Claim %*"):format(v12)

								local ImageLabel = TextLabel:FindFirstChild("ImageLabel")

								if ImageLabel then
									ImageLabel.Image = "rbxassetid://86270302884166"
								end
							end
						end

						ClaimButton.MouseButton1Down:Connect(function() --[[ Line: 729 | Upvalues: ClientPlayerData (ref), v2 (copy), Remotes (ref) ]]
							local v1 = ClientPlayerData.serverProfile:getState()

							if not v1.index[v2] then
								return
							end

							if not (v1.claimedIndexRewards and v1.claimedIndexRewards[v2]) then
								Remotes.RequestClaimIndexReward:Fire(v2)
							end
						end)
					end

					local ExistCount = v9:FindFirstChild("ExistCount")

					if ExistCount then
						local v14 = FishConfig[v2]
						local v15 = if v14 == nil then false else isBeastLikeFish(v14)

						ExistCount.Visible = v15

						if v15 then
							ExistCount.Text = ("%* Exist"):format((ConvertValue.suffixformat(t3[v2] or 0)))
						end
					end

					v9.Parent = v7
					t4[v2] = v9
					t5[v2] = v.key

					if v3[v2] then
						count = count + 1
					end
				end

				v5.Parent = ScrollingFrame
				table.insert(t7, v5)

				if v6 then
					t6[v.key] = {
						label = v6,
						title = v.title,
						total = #v.fish,
						acquired = count
					}

					local v18 = t6[v.key]

					if v18 then
						v18.label.Text = ("%* (%*/%*)"):format(v18.title, v18.acquired, v18.total)
					end
				end
			end
		end

		local GhostSpacer = Instance.new("Frame")

		GhostSpacer.Name = "GhostSpacer"
		GhostSpacer.BackgroundTransparency = 1
		GhostSpacer.LayoutOrder = 9999
		GhostSpacer.Visible = true
		GhostSpacer.Size = UDim2.new(1, 0, 0, 120)
		GhostSpacer.Parent = ScrollingFrame
		table.insert(t7, GhostSpacer)

		for k in pairs(v3) do
			if t4[k] then
				local v20 = t4[k]

				if v20 then
					v20.Icon.ImageColor3 = v1
					v20.DisplayName.Text = FishConfig[k].DisplayName

					local v22 = t4[k]

					if v22 then
						local ClaimButton = v22:FindFirstChild("ClaimButton")

						if ClaimButton then
							local v23 = ClientPlayerData.serverProfile:getState()
							local v24 = v23.index and v23.index[k]

							ClaimButton.Visible = if v24 then not (v23.claimedIndexRewards and v23.claimedIndexRewards[k]) else v24
						end
					end
				end
			end
		end

		updateGridCellSizes()
	end

	local function selectCategory(p1) --[[ selectCategory | Line: 787 | Upvalues: populateCategory (copy) ]]
		populateCategory(p1)
	end

	local list = {}

	for v11, v122 in IndexCategoryConfig do
		table.insert(list, v122)
	end

	table.sort(list, function(p1, p2) --[[ Line: 797 ]]
		return (p1.order or 0) < (p2.order or 0)
	end)

	for i, v in ipairs(list) do
		local v13 = CategoryButtonTemplate:Clone()

		v13.Name = v.id
		v13.LayoutOrder = v.order or i
		v13.Visible = true

		local v14 = getButtonTextLabel(v13)

		if v14 then
			v14.Text = v.displayName
		end

		local v15 = getButtonIcon(v13)

		if v15 and v.icon then
			v15.Image = v.icon
			v15.Visible = true
		elseif v15 then
			v15.Visible = false
		end

		local v16 = v.color or Color3.fromRGB(120, 140, 170)
		local v17 = v13:FindFirstChild("Content")

		if v17 then
			local UIGradient = v17:FindFirstChildOfClass("UIGradient")

			if UIGradient then
				UIGradient.Color = ColorSequence.new(v16, darken(v16, 0.18))
			end

			local UIStroke = v17:FindFirstChildOfClass("UIStroke")

			if UIStroke then
				UIStroke.Color = Color3.new(v16.R + (1 - v16.R) * 0.2, v16.G + (1 - v16.G) * 0.2, v16.B + (1 - v16.B) * 0.2)
			end
		end

		local UIStroke = v13:FindFirstChildOfClass("UIStroke")

		if UIStroke then
			UIStroke.Color = Color3.new(v16.R * 0.38, v16.G * 0.38, v16.B * 0.38)
		end

		local Line = v13:FindFirstChild("Line")

		if Line and Line:IsA("GuiObject") then
			Line.BackgroundColor3 = Color3.new(v16.R * 0.62, v16.G * 0.62, v16.B * 0.62)
		end

		v13.MouseButton1Down:Connect(function() --[[ Line: 846 | Upvalues: v (copy), populateCategory (copy) ]]
			populateCategory(v)
		end)
		v13.Parent = Categories
	end

	if ClaimAllButton then
		ClaimAllButton.MouseButton1Down:Connect(function() --[[ Line: 856 | Upvalues: ClientPlayerData (ref), IndexRewardConfig (ref), Remotes (ref) ]]
			local v1 = ClientPlayerData.serverProfile:getState()
			local v3 = v1.claimedIndexRewards or {}

			for k in pairs(v1.index or {}) do
				if not v3[k] and IndexRewardConfig.getRewardForFish(k) > 0 then
					Remotes.RequestClaimIndexReward:Fire(k)
				end
			end
		end)
	end

	local v18 = pairs
	local v19 = ClientPlayerData.serverProfile:getState().index or {}

	for v20 in v18(v19) do
		if FishConfig[v20] then
			count = count + 1
		end
	end

	if #list > 0 then
		populateCategory(list[1])
	end

	local v21 = if v8 == 0 then 0 else count / v8

	Bar.Size = UDim2.fromScale(math.clamp(v21, 0, 1), 1)

	if v12 then
		v12.Text = ("%*/%*"):format(count, v8)
	end

	if v22 then
		v22.Text = ("%*/%* Fishes"):format(count, v8)
	end

	updateAlert()

	local t9 = {}
	local t10 = {}

	local function isMilestoneClaimed(p1, p2) --[[ isMilestoneClaimed | Line: 888 ]]
		if p1.claimedIndexMilestones and p1.claimedIndexMilestones[p2.id] then
			return true
		end

		return p2.reward.type == "baseSkin" and (p2.reward.skinName and (p1.unlockedBaseSkins and p1.unlockedBaseSkins[p2.reward.skinName])) and true or false
	end

	local function updateMilestones() --[[ updateMilestones | Line: 900 | Upvalues: ClientPlayerData (ref), IndexMilestoneConfig (ref), t9 (copy), t10 (copy), Remotes (ref) ]]
		local v1 = ClientPlayerData.serverProfile:getState()

		for v3, v4 in IndexMilestoneConfig.Milestones do
			local v2

			v2 = (v1.claimedIndexMilestones and v1.claimedIndexMilestones[v4.id] or v4.reward.type == "baseSkin" and (v4.reward.skinName and (v1.unlockedBaseSkins and v1.unlockedBaseSkins[v4.reward.skinName]))) and true or false

			local v5 = t9[v4.id]

			if v5 then
				v5.Visible = v2
			end

			if not v2 and (not t10[v4.id] and IndexMilestoneConfig.isReached(v1.index, v4)) then
				t10[v4.id] = true
				Remotes.RequestClaimIndexMilestone:Fire(v4.id)
			end
		end
	end

	for v222, v23 in IndexMilestoneConfig.Milestones do
		local v24 = nil

		for v25, v26 in CollectBar:GetChildren() do
			if v26.Name == ("RewardFor%*"):format(v23.id) and v26:IsA("GuiObject") then
				v24 = v26

				break
			end
		end

		if v24 then
			local MilestoneCheck = v24:FindFirstChild("MilestoneCheck")

			if not MilestoneCheck then
				local MilestoneCheck2 = Instance.new("ImageLabel")

				MilestoneCheck2.Name = "MilestoneCheck"
				MilestoneCheck2.BackgroundTransparency = 1
				MilestoneCheck2.AnchorPoint = Vector2.new(0.5, 0.5)
				MilestoneCheck2.Position = UDim2.fromScale(0.5, 0.5)
				MilestoneCheck2.Size = UDim2.fromScale(0.7, 0.7)
				MilestoneCheck2.Image = "rbxassetid://132276917473083"
				MilestoneCheck2.ZIndex = 50
				MilestoneCheck2.Visible = false
				MilestoneCheck2.Parent = v24
				MilestoneCheck = MilestoneCheck2
			end

			t9[v23.id] = MilestoneCheck
		end
	end

	updateMilestones()
	ScrollingFrame:GetPropertyChangedSignal("AbsoluteSize"):Connect(updateGridCellSizes)
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 953 ]]
		return p1.index
	end, function(p1, p2) --[[ Line: 955 | Upvalues: FishConfig (ref), count (ref), t4 (copy), v1 (ref), ClientPlayerData (ref), t5 (copy), t6 (copy), v8 (copy), Bar (copy), v12 (copy), v22 (copy), updateAlert (copy), updateMilestones (copy) ]]
		local v3 = if p2 then p2 else {}

		for k in pairs(if p1 then p1 else {}) do
			if not v3[k] and FishConfig[k] then
				count = count + 1

				if t4[k] then
					local v4 = t4[k]

					if v4 then
						v4.Icon.ImageColor3 = v1
						v4.DisplayName.Text = FishConfig[k].DisplayName

						local v6 = t4[k]

						if v6 then
							local ClaimButton = v6:FindFirstChild("ClaimButton")

							if ClaimButton then
								local v7 = ClientPlayerData.serverProfile:getState()
								local v82 = v7.index and v7.index[k]

								ClaimButton.Visible = if v82 then not (v7.claimedIndexRewards and v7.claimedIndexRewards[k]) else v82
							end
						end
					end

					local v11 = t5[k]
					local v122 = if v11 then t6[v11] else v11

					if v122 then
						v122.acquired = v122.acquired + 1

						local v132 = t6[v11]

						if v132 then
							v132.label.Text = ("%* (%*/%*)"):format(v132.title, v132.acquired, v132.total)
						end
					end
				end
			end
		end

		Bar.Size = UDim2.fromScale(math.clamp(if v8 == 0 then 0 else count / v8, 0, 1), 1)

		if v12 then
			v12.Text = ("%*/%*"):format(count, v8)
		end

		if v22 then
			v22.Text = ("%*/%* Fishes"):format(count, v8)
		end

		updateAlert()
		updateMilestones()
	end)
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 977 ]]
		return p1.claimedIndexRewards
	end, function(p1, p2) --[[ Line: 979 | Upvalues: t4 (copy), ClientPlayerData (ref), updateAlert (copy) ]]
		local v3 = if p2 then p2 else {}

		for k in pairs(if p1 then p1 else {}) do
			if not v3[k] then
				local v4 = t4[k]

				if v4 then
					local ClaimButton = v4:FindFirstChild("ClaimButton")

					if ClaimButton then
						local v5 = ClientPlayerData.serverProfile:getState()
						local v6 = v5.index and v5.index[k]

						ClaimButton.Visible = if v6 then not (v5.claimedIndexRewards and v5.claimedIndexRewards[k]) else v6
					end
				end
			end
		end

		updateAlert()
	end)
	Remotes.ReplicateGlobalExistCounts:On(function(p1) --[[ Line: 990 | Upvalues: t3 (ref), t4 (copy), ConvertValue (ref) ]]
		if typeof(p1) ~= "table" then
			return
		end

		t3 = p1

		for k in pairs(t4) do
			local v1 = t4[k]

			if v1 then
				local ExistCount = v1:FindFirstChild("ExistCount")

				if ExistCount and ExistCount.Visible then
					ExistCount.Text = ("%* Exist"):format((ConvertValue.suffixformat(p1[k] or 0)))
				end
			end
		end
	end)
	Remotes.ReplicateGlobalExistCounts:Fire()
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 1002 ]]
		return p1.claimedIndexMilestones
	end, function() --[[ Line: 1004 | Upvalues: updateMilestones (copy) ]]
		updateMilestones()
	end)
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 1008 ]]
		return p1.unlockedBaseSkins
	end, function() --[[ Line: 1010 | Upvalues: updateMilestones (copy) ]]
		updateMilestones()
	end)

	if RunService:IsStudio() then
		UserInputService.InputBegan:Connect(function(p1, p2) --[[ Line: 1018 | Upvalues: ClientPlayerData (ref), v7 (copy), Remotes (ref) ]]
			if p2 or p1.KeyCode ~= Enum.KeyCode.G then
				return
			end

			local v1 = ClientPlayerData.serverProfile:getState().index or {}
			local t = {}

			for i, v in ipairs(v7) do
				if #t >= 10 then
					break
				end

				if not v1[v] then
					table.insert(t, v)
				end
			end

			if not (#t > 0) then
				return
			end

			Remotes.DebugRevealIndexFish:Fire(t)
		end)
	end
end

return t2