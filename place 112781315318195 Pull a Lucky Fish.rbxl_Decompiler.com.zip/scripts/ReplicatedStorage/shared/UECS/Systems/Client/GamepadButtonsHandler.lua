-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")

game:GetService("Players")

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local UserInputService = game:GetService("UserInputService")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local t = {
	UECS = nil,
	Priority = 20,
	SetButtonImage = function(p1, p2) --[[ SetButtonImage | Line: 14 | Upvalues: UserInputService (copy) ]]
		local v1 = p2:GetAttribute("EnumString") or ""
		local ok, result = pcall(function() --[[ Line: 16 | Upvalues: v1 (copy) ]]
			return Enum.KeyCode[v1]
		end)

		if ok and result then
			p2.Image = UserInputService:GetImageForKeyCode(result)
			p2.ScaleType = Enum.ScaleType.Fit
		end
	end
}

function t.OnInputUpdate(p1) --[[ OnInputUpdate | Line: 28 | Upvalues: CollectionService (copy), t (copy) ]]
	for v1, v2 in CollectionService:GetTagged("GamepadControl") do
		if v2:IsA("ImageLabel") then
			t:UpdateVisibilityForImage(v2)
		end
	end
end
function t.UpdateVisibilityForImage(p1, p2) --[[ UpdateVisibilityForImage | Line: 36 | Upvalues: UserInputService (copy) ]]
	p2.Visible = if UserInputService.PreferredInput == Enum.PreferredInput.Gamepad then true else false
end
function t.Init(p1) --[[ Init | Line: 40 | Upvalues: CollectionService (copy), t (copy), UserInputService (copy) ]]
	CollectionService:GetInstanceAddedSignal("GamepadControl"):Connect(function(p1) --[[ Line: 41 | Upvalues: t (ref) ]]
		if not p1:IsA("ImageLabel") then
			return
		end

		t:SetButtonImage(p1)
		t:UpdateVisibilityForImage(p1)
	end)

	for v1, v2 in CollectionService:GetTagged("GamepadControl") do
		if v2:IsA("ImageLabel") then
			t:SetButtonImage(v2)
			t:UpdateVisibilityForImage(v2)
		end
	end

	UserInputService.GamepadConnected:Connect(function() --[[ Line: 55 | Upvalues: CollectionService (ref), t (ref) ]]
		for v1, v2 in CollectionService:GetTagged("GamepadControl") do
			if v2:IsA("ImageLabel") then
				t:SetButtonImage(v2)
			end
		end
	end)
	UserInputService:GetPropertyChangedSignal("PreferredInput"):Connect(function() --[[ Line: 63 | Upvalues: t (ref) ]]
		t:OnInputUpdate()
	end)
	t:OnInputUpdate()
end

return t