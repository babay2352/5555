-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local AlienEventConfig = require(ReplicatedStorage.shared.config.AlienEventConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Remotes = require(ReplicatedStorage.shared.Remotes)
local SFX = require(ReplicatedStorage.client.SFX)
local TutorialGate = require(ReplicatedStorage.client.TutorialGate)
local t = {
	UECS = nil
}
local FuelNpc = AlienEventConfig.FuelNpc
local AlienVoice = AlienEventConfig.AlienVoice
local v1 = Vector2.new(0, -35)
local t2 = {}

local function isHoldingTank() --[[ isHoldingTank | Line: 50 | Upvalues: Players (copy) ]]
	local Character = Players.LocalPlayer.Character

	if not Character then
		return false
	end

	local Tool = Character:FindFirstChildOfClass("Tool")

	return if Tool == nil then false else Tool:GetAttribute("IsFuelTank") == true
end

local function promptAllowed() --[[ promptAllowed | Line: 59 | Upvalues: TutorialGate (copy), Players (copy) ]]
	local v1 = not TutorialGate.active()

	if v1 then
		local Character = Players.LocalPlayer.Character
		local v2

		if Character then
			local Tool = Character:FindFirstChildOfClass("Tool")

			v2 = if Tool == nil then false else Tool:GetAttribute("IsFuelTank") == true
		else
			v2 = false
		end

		v1 = not v2
	end

	return v1
end

local function refreshPrompts() --[[ refreshPrompts | Line: 63 | Upvalues: TutorialGate (copy), Players (copy), t2 (copy) ]]
	local v1 = not TutorialGate.active()

	if v1 then
		local Character = Players.LocalPlayer.Character
		local v2

		if Character then
			local Tool = Character:FindFirstChildOfClass("Tool")

			v2 = if Tool == nil then false else Tool:GetAttribute("IsFuelTank") == true
		else
			v2 = false
		end

		v1 = not v2
	end

	for v3 in t2 do
		if v3:IsDescendantOf(game) then
			v3.Enabled = v1

			continue
		end

		t2[v3] = nil
	end
end

local function anchorPartOf(p1) --[[ anchorPartOf | Line: 76 ]]
	return p1:FindFirstChild("PromptPart") or (p1:FindFirstChild("Head") or (p1.PrimaryPart or p1:FindFirstChildWhichIsA("BasePart", true)))
end

local function attachPrompt(p1) --[[ attachPrompt | Line: 83 | Upvalues: FuelNpc (copy), v1 (copy), TutorialGate (copy), Players (copy), t2 (copy), SFX (copy), AlienVoice (copy), Remotes (copy) ]]
	local ProximityPrompt = Instance.new("ProximityPrompt")

	ProximityPrompt.Style = Enum.ProximityPromptStyle.Custom
	ProximityPrompt.ActionText = FuelNpc.PromptActionText
	ProximityPrompt.ObjectText = FuelNpc.PromptObjectText
	ProximityPrompt.HoldDuration = 0
	ProximityPrompt.MaxActivationDistance = FuelNpc.PromptMaxDistance
	ProximityPrompt.RequiresLineOfSight = false
	ProximityPrompt.KeyboardKeyCode = Enum.KeyCode.E
	ProximityPrompt.UIOffset = v1
	ProximityPrompt.Exclusivity = Enum.ProximityPromptExclusivity.AlwaysShow
	ProximityPrompt:AddTag("NoFade")

	local v12 = not TutorialGate.active()

	if v12 then
		local Character = Players.LocalPlayer.Character
		local v2

		if Character then
			local Tool = Character:FindFirstChildOfClass("Tool")

			v2 = if Tool == nil then false else Tool:GetAttribute("IsFuelTank") == true
		else
			v2 = false
		end

		v12 = not v2
	end

	ProximityPrompt.Enabled = v12
	ProximityPrompt.Parent = p1
	t2[ProximityPrompt] = true
	ProximityPrompt.Triggered:Connect(function() --[[ Line: 102 | Upvalues: SFX (ref), p1 (copy), AlienVoice (ref), Remotes (ref) ]]
		SFX.PlaySoundWithRandomPitchAtPart(SFX.Sounds.AlienNpcTalk, p1, AlienVoice.SoundVolume, AlienVoice.PitchMin, AlienVoice.PitchMax)
		task.spawn(function() --[[ Line: 115 | Upvalues: Remotes (ref) ]]
			Remotes.AlienGiveFuelFish:Call():Await()
		end)
	end)
end

local t3 = {}

local function ensureNpc(p1) --[[ ensureNpc | Line: 126 | Upvalues: t3 (copy), attachPrompt (copy) ]]
	if p1:IsA("Model") and not t3[p1] then
		t3[p1] = true
		task.spawn(function() --[[ Line: 131 | Upvalues: p1 (copy), attachPrompt (ref), t3 (ref) ]]
			while p1:IsDescendantOf(game) do
				local v1
				local v22 = p1
				local PromptPart = v22:FindFirstChild("PromptPart")

				if PromptPart then
					v1 = PromptPart
				else
					local Head = v22:FindFirstChild("Head")

					v1 = Head or (v22.PrimaryPart or v22:FindFirstChildWhichIsA("BasePart", true))
				end

				if v1 then
					attachPrompt(v1)

					while p1:IsDescendantOf(game) and v1:IsDescendantOf(game) do
						task.wait(1)
					end

					continue
				end

				task.wait(0.5)
			end

			t3[p1] = nil
		end)
	end
end

function t.Init(p1) --[[ Init | Line: 147 | Upvalues: AlienEventConfig (copy), CollectionService (copy), FuelNpc (copy), t3 (copy), attachPrompt (copy), ensureNpc (copy), refreshPrompts (copy), Players (copy), TutorialGate (copy) ]]
	if not AlienEventConfig.Enabled then
		return
	end

	for v1, v2 in CollectionService:GetTagged(FuelNpc.NpcTag) do
		if v2:IsA("Model") and not t3[v2] then
			t3[v2] = true
			task.spawn(function() --[[ Line: 131 | Upvalues: v2 (copy), attachPrompt (ref), t3 (ref) ]]
				while v2:IsDescendantOf(game) do
					local v1
					local v22 = v2
					local PromptPart = v22:FindFirstChild("PromptPart")

					if PromptPart then
						v1 = PromptPart
					else
						local Head = v22:FindFirstChild("Head")

						v1 = Head or (v22.PrimaryPart or v22:FindFirstChildWhichIsA("BasePart", true))
					end

					if v1 then
						attachPrompt(v1)

						while v2:IsDescendantOf(game) and v1:IsDescendantOf(game) do
							task.wait(1)
						end

						continue
					end

					task.wait(0.5)
				end

				t3[v2] = nil
			end)
		end
	end

	CollectionService:GetInstanceAddedSignal(FuelNpc.NpcTag):Connect(ensureNpc)

	local function watchCharacter(p1) --[[ watchCharacter | Line: 161 | Upvalues: refreshPrompts (ref) ]]
		p1.ChildAdded:Connect(refreshPrompts)
		p1.ChildRemoved:Connect(refreshPrompts)
		refreshPrompts()
	end

	if Players.LocalPlayer.Character then
		local Character = Players.LocalPlayer.Character

		Character.ChildAdded:Connect(refreshPrompts)
		Character.ChildRemoved:Connect(refreshPrompts)
		refreshPrompts()
	end

	Players.LocalPlayer.CharacterAdded:Connect(watchCharacter)
	TutorialGate.onChanged(refreshPrompts)
end

return t