-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local AlchemyTableConfig = require(ReplicatedStorage.shared.config.AlchemyTableConfig)
local AnimationConfig = require(ReplicatedStorage.shared.config.AnimationConfig)
local GardenConfig = require(ReplicatedStorage.shared.config.GardenConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local convertTimeMS = require(ReplicatedStorage.shared.util.convertTimeMS)
local createAnimationInstance = require(ReplicatedStorage.shared.util.createAnimationInstance)
local AlchemyTag = GardenConfig.AlchemyTag
local t = { "Progress", "ProgressFrame", "Fill" }
local t2 = { "MutationFrame", "MutationsFrame" }
local t3 = {
	UECS = nil
}

local function findNamed(p1, p2) --[[ findNamed | Line: 94 ]]
	for v1, v2 in p2 do
		local v3 = p1:FindFirstChild(v2)

		if v3 then
			return v3
		end
	end

	return nil
end

local function collectMutationIcons(p1) --[[ collectMutationIcons | Line: 104 ]]
	local t = {}

	if not p1 then
		return t
	end

	for v1, v2 in p1:GetChildren() do
		if v2:IsA("ImageLabel") then
			table.insert(t, v2)
		end
	end

	return t
end

local function collectEmitters(p1) --[[ collectEmitters | Line: 120 | Upvalues: GardenConfig (copy) ]]
	local t = {}
	local t2 = {}

	for v1, v2 in p1:GetDescendants() do
		if v2:IsA("ParticleEmitter") then
			if v2.Name == GardenConfig.AlchemyProducingEmitterName then
				table.insert(t, v2)

				continue
			end

			if v2.Name == GardenConfig.AlchemyReadyEmitterName then
				table.insert(t2, v2)
			end
		end
	end

	return t, t2
end

local function setEmittersEnabled(p1, p2) --[[ setEmittersEnabled | Line: 136 ]]
	for v1, v2 in p1 do
		v2.Enabled = p2
	end
end

local function createSound(p1, p2, p3, p4) --[[ createSound | Line: 146 ]]
	if typeof(p3) == "string" and p3 ~= "" then
		local Sound = Instance.new("Sound")

		Sound.Name = p2
		Sound.SoundId = p3
		Sound.Looped = p4
		Sound.Parent = p1

		return Sound
	end

	warn((("[GardenAlchemyTable] no sound id for %* \226\128\148 running without it"):format(p2)))

	return nil
end

local function setBrewSoundPlaying(p1, p2) --[[ setBrewSoundPlaying | Line: 159 ]]
	local brewSound = p1.brewSound

	if not brewSound then
		return
	end

	if p2 and not brewSound.IsPlaying then
		brewSound:Play()

		return
	end

	if p2 or not brewSound.IsPlaying then
		return
	end

	brewSound:Stop()
end

local function getAnimator(p1) --[[ getAnimator | Line: 171 ]]
	local v1 = p1:FindFirstChildWhichIsA("AnimationController", true)

	if not v1 then
		local AnimationController = Instance.new("AnimationController")

		AnimationController.Parent = p1
		v1 = AnimationController
	end

	local v2 = v1:FindFirstChildWhichIsA("Animator")

	if not v2 then
		local Animator = Instance.new("Animator")

		Animator.Parent = v1
		v2 = Animator
	end

	return v2
end

local function producingAnimationId() --[[ producingAnimationId | Line: 189 | Upvalues: AnimationConfig (copy) ]]
	local AlchemyTable = AnimationConfig.AlchemyTable
	local v1 = if AlchemyTable then AlchemyTable.Producing else AlchemyTable

	if typeof(v1) == "string" and v1 ~= "" then
		return v1
	end

	return nil
end

local function loadTrack(p1, p2) --[[ loadTrack | Line: 198 | Upvalues: createAnimationInstance (copy) ]]
	local ok, result = pcall(function() --[[ Line: 199 | Upvalues: p1 (copy), createAnimationInstance (ref), p2 (copy) ]]
		return p1:LoadAnimation(createAnimationInstance(p2))
	end)

	if ok and result then
		result.Looped = true
		result.Priority = Enum.AnimationPriority.Action

		return result
	end

	warn((("[GardenAlchemyTable] failed to load animation %*: %*"):format(p2, result)))

	return nil
end

local function pickDistinctRewards(p1) --[[ pickDistinctRewards | Line: 217 | Upvalues: AlchemyTableConfig (copy) ]]
	local v1 = table.clone(AlchemyTableConfig.Rewards)
	local v2 = math.min(p1, #v1)

	for i = 1, v2 do
		local v3 = math.random(i, #v1)
		local v5 = v1[i]

		v1[i] = v1[v3]
		v1[v3] = v5
	end

	local t = {}

	for j = 1, v2 do
		table.insert(t, v1[j])
	end

	return t
end

local function rollReel(p1) --[[ rollReel | Line: 231 | Upvalues: pickDistinctRewards (copy) ]]
	local mutationIcons = p1.mutationIcons

	if #mutationIcons == 0 then
		return
	end

	local v1 = pickDistinctRewards(#mutationIcons)

	for v2, v3 in mutationIcons do
		local v4 = v1[v2]

		v3.Image = if v4 then v4.Icon else ""
		v3.Visible = if v4 == nil then false else true
	end
end

function t3.Init(p1) --[[ Init | Line: 246 | Upvalues: Players (copy), t2 (copy), t (copy), GardenConfig (copy), collectEmitters (copy), collectMutationIcons (copy), AlchemyTableConfig (copy), getAnimator (copy), AnimationConfig (copy), loadTrack (copy), convertTimeMS (copy), rollReel (copy), CollectionService (copy), AlchemyTag (copy), RunService (copy) ]]
	local LocalPlayer = Players.LocalPlayer
	local t3 = {}

	local function teardown(p1) --[[ teardown | Line: 250 | Upvalues: t3 (copy) ]]
		local v1 = t3[p1]

		if not v1 then
			return
		end

		if v1.producingTrack then
			v1.producingTrack:Stop()
		end

		if v1.startSound then
			v1.startSound:Destroy()
		end

		if not v1.brewSound then
			t3[p1] = nil

			return
		end

		v1.brewSound:Destroy()
		t3[p1] = nil
	end

	local function setup(p1) --[[ setup | Line: 267 | Upvalues: t3 (copy), t2 (ref), t (ref), GardenConfig (ref), collectEmitters (ref), collectMutationIcons (ref), AlchemyTableConfig (ref), LocalPlayer (copy), getAnimator (ref), AnimationConfig (ref), loadTrack (ref) ]]
		if not p1:IsA("Model") or t3[p1] then
			return
		end

		local v1 = p1:FindFirstChildWhichIsA("BillboardGui", true)
		local v2 = if v1 then v1:FindFirstChild("Main") else v1

		if not v2 then
			warn((("[GardenAlchemyTable] %* has no BillboardGui.Main \226\128\148 no status display"):format(p1.Name)))
		end

		local v3

		if v2 then
			v3 = nil

			for v4, v5 in t2 do
				local v6 = v2:FindFirstChild(v5)

				if v6 then
					v3 = v6

					break
				end
			end
		else
			v3 = v2
		end

		local v7 = if v2 then v2:FindFirstChild("ProgressBar") else v2
		local v8 = if v2 then v2:FindFirstChild("ReadyLabel") else v2
		local v9 = if v2 then v2:FindFirstChild("InsertFish") else v2
		local v10

		if v7 then
			v10 = nil

			for v11, v12 in t do
				local v13 = v7:FindFirstChild(v12)

				if v13 then
					v10 = v13

					break
				end
			end
		else
			v10 = v7
		end

		local v14 = if v7 then v7:FindFirstChild("TimeLeft") else v7

		if v7 and not v10 then
			warn((("[GardenAlchemyTable] %* ProgressBar has no %* \226\128\148 bar stays empty"):format(p1.Name, (table.concat(t, "/")))))
		end

		local v15 = p1:FindFirstChild(GardenConfig.AlchemyRootName, true)
		local v16 = if v15 then v15:FindFirstChild(GardenConfig.AlchemyInsertPromptName) else v15
		local v17 = if v15 then v15:FindFirstChild(GardenConfig.AlchemyClaimPromptName) else v15
		local v18, v19 = collectEmitters(p1)
		local t4 = {
			state = nil,
			culled = false,
			reelElapsed = (1 / 0),
			model = p1
		}

		t4.mutationFrame = if v3 and v3:IsA("GuiObject") then v3 else nil
		t4.mutationIcons = collectMutationIcons(v3)
		t4.progressBar = if v7 and v7:IsA("GuiObject") then v7 else nil
		t4.fill = if v10 and v10:IsA("GuiObject") then v10 else nil
		t4.timeLeft = if v14 and v14:IsA("TextLabel") then v14 else nil
		t4.readyLabel = if v8 and v8:IsA("GuiObject") then v8 else nil
		t4.insertLabel = if v9 and v9:IsA("GuiObject") then v9 else nil
		t4.producingEmitters = v18
		t4.readyEmitters = v19
		t4.insertPrompt = if v16 and v16:IsA("ProximityPrompt") then v16 else nil
		t4.claimPrompt = if v17 and v17:IsA("ProximityPrompt") then v17 else nil

		local v28

		if v15 and v15:IsA("BasePart") then
			local StartSound = AlchemyTableConfig.StartSound

			if typeof(StartSound) == "string" and StartSound ~= "" then
				local AlchemyStart = Instance.new("Sound")

				AlchemyStart.Name = "AlchemyStart"
				AlchemyStart.SoundId = StartSound
				AlchemyStart.Looped = false
				AlchemyStart.Parent = v15
				v28 = AlchemyStart
			else
				warn("[GardenAlchemyTable] no sound id for AlchemyStart \226\128\148 running without it")
				v28 = nil
			end
		else
			v28 = nil
		end

		t4.startSound = v28

		local v29

		if v15 and v15:IsA("BasePart") then
			local BrewSound = AlchemyTableConfig.BrewSound

			if typeof(BrewSound) == "string" and BrewSound ~= "" then
				local AlchemyBrew = Instance.new("Sound")

				AlchemyBrew.Name = "AlchemyBrew"
				AlchemyBrew.SoundId = BrewSound
				AlchemyBrew.Looped = true
				AlchemyBrew.Parent = v15
				v29 = AlchemyBrew
			else
				warn("[GardenAlchemyTable] no sound id for AlchemyBrew \226\128\148 running without it")
				v29 = nil
			end
		else
			v29 = nil
		end

		t4.brewSound = v29
		t4.isOwner = p1:GetAttribute("OwnerUserId") == LocalPlayer.UserId

		local v30 = getAnimator(p1)
		local AlchemyTable = AnimationConfig.AlchemyTable
		local v31 = if AlchemyTable then AlchemyTable.Producing else AlchemyTable
		local v32 = if typeof(v31) == "string" and v31 ~= "" then v31 else nil

		if v30 and v32 then
			t4.producingTrack = loadTrack(v30, v32)
		elseif not v32 then
			warn("[GardenAlchemyTable] AnimationConfig.AlchemyTable.Producing missing \226\128\148 table will not animate")
		end

		t3[p1] = t4
	end

	local function applyState(p1, p2, p3) --[[ applyState | Line: 342 | Upvalues: AlchemyTableConfig (ref), convertTimeMS (ref) ]]
		local state = p1.state

		p1.state = p2

		if if state == p2 then false else true then
			local v2 = if p2 == "Producing" then true else false
			local v3 = if p2 == "Ready" then true else false
			local v4 = if p2 == "Idle" then true else false

			if p1.progressBar then
				p1.progressBar.Visible = v2
			end

			if p1.readyLabel then
				p1.readyLabel.Visible = v3
			end

			if p1.insertLabel then
				p1.insertLabel.Visible = v4
			end

			if p1.mutationFrame then
				p1.mutationFrame.Visible = v4
			end

			if p1.insertPrompt then
				p1.insertPrompt.Enabled = if v4 then p1.isOwner else v4
			end

			if p1.claimPrompt then
				p1.claimPrompt.Enabled = if v3 then p1.isOwner else v3
			end

			for v7, v8 in p1.producingEmitters do
				v8.Enabled = v2
			end

			for v9, v10 in p1.readyEmitters do
				v10.Enabled = v3
			end

			local brewSound = p1.brewSound

			if brewSound and (v2 and not brewSound.IsPlaying) then
				brewSound:Play()
			elseif brewSound and (not v2 and brewSound.IsPlaying) then
				brewSound:Stop()
			end

			if v2 and (state == "Idle" and p1.startSound) then
				p1.startSound:Play()
			end

			if p1.producingTrack then
				if v2 then
					if not p1.producingTrack.IsPlaying then
						p1.producingTrack:Play()
					end
				else
					p1.producingTrack:Stop()
				end
			end

			if v4 then
				p1.reelElapsed = (1 / 0)
			end
		end

		if p2 ~= "Producing" then
			return
		end

		if p1.fill then
			local ProcessingTime = AlchemyTableConfig.ProcessingTime

			p1.fill.Size = UDim2.fromScale(if ProcessingTime > 0 then math.clamp(1 - p3 / ProcessingTime, 0, 1) else 0, 1)
		end

		if not p1.timeLeft then
			return
		end

		p1.timeLeft.Text = convertTimeMS(p3)
	end

	local function update(p1) --[[ update | Line: 411 | Upvalues: LocalPlayer (copy), t3 (copy), GardenConfig (ref), applyState (copy), AlchemyTableConfig (ref), rollReel (ref) ]]
		local Character = LocalPlayer.Character
		local v1 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character
		local v2 = if v1 then v1.Position else v1
		local v3 = workspace:GetServerTimeNow()

		for v4, v5 in t3 do
			if v4.Parent then
				if v2 then
					local Position = v4:GetPivot().Position
					local v6 = Position.X - v2.X
					local v7 = Position.Z - v2.Z

					if v6 * v6 + v7 * v7 > 14400 then
						if not v5.culled then
							v5.culled = true

							if v5.producingTrack then
								v5.producingTrack:Stop()
							end

							local brewSound = v5.brewSound

							if brewSound and brewSound.IsPlaying then
								brewSound:Stop()
							end
						end

						continue
					end
				end

				if v5.culled then
					v5.culled = false
					v5.state = nil
				end

				local v8 = v4:GetAttribute(GardenConfig.AlchemyReadyAtAttribute)

				if typeof(v8) == "number" then
					local v9 = v8 - v3

					applyState(v5, if v9 > 0 then "Producing" else "Ready", (math.max(0, v9)))

					continue
				end

				applyState(v5, "Idle", 0)
				v5.reelElapsed = v5.reelElapsed + p1

				if v5.reelElapsed >= AlchemyTableConfig.IdleIconInterval then
					v5.reelElapsed = 0
					rollReel(v5)
				end

				continue
			end

			local v12 = t3[v4]

			if v12 then
				if v12.producingTrack then
					v12.producingTrack:Stop()
				end

				if v12.startSound then
					v12.startSound:Destroy()
				end

				if v12.brewSound then
					v12.brewSound:Destroy()
				end

				t3[v4] = nil
			end
		end
	end

	CollectionService:GetInstanceAddedSignal(AlchemyTag):Connect(setup)
	CollectionService:GetInstanceRemovedSignal(AlchemyTag):Connect(teardown)

	for v1, v2 in CollectionService:GetTagged(AlchemyTag) do
		task.spawn(setup, v2)
	end

	local v3 = 0

	RunService.Heartbeat:Connect(function(p1) --[[ Line: 468 | Upvalues: v3 (ref), update (copy) ]]
		debug.profilebegin("UECS/GardenAlchemyTable.Update")
		v3 = v3 + p1

		if not (v3 < 1) then
			local v1 = v3

			v3 = 0
			update(v1)
		end

		debug.profileend()
	end)
end

return t3