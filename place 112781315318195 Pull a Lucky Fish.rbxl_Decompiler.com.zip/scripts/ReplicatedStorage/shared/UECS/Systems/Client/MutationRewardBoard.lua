-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local AlienEventConfig = require(ReplicatedStorage.shared.config.AlienEventConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local MutationConfig = require(ReplicatedStorage.shared.config.MutationConfig)
local t = {
	UECS = nil
}
local FuelNpc = AlienEventConfig.FuelNpc

local function payingMutations() --[[ payingMutations | Line: 39 | Upvalues: FuelNpc (copy), MutationConfig (copy) ]]
	local t = {}

	for v1, v2 in FuelNpc.MutationFuel do
		local v3 = MutationConfig.Mutations[v1]

		if v3 and v2 > 0 then
			table.insert(t, {
				mutationId = v1,
				image = v3.image,
				fuel = v2
			})
		end
	end

	table.sort(t, function(p1, p2) --[[ Line: 47 ]]
		if p1.fuel == p2.fuel then
			return p1.mutationId < p2.mutationId
		end

		return p1.fuel < p2.fuel
	end)

	return t
end

local function buildBoard(p1) --[[ buildBoard | Line: 56 | Upvalues: payingMutations (copy) ]]
	local Frame = p1:FindFirstChild("Frame")
	local v1 = if Frame then Frame:FindFirstChild("Template") else Frame

	if not (Frame and (v1 and v1:IsA("GuiObject"))) then
		warn((("[MutationRewardBoard] %* is missing Frame.Template \226\128\148 nothing to clone"):format((p1:GetFullName()))))

		return
	end

	for v2, v3 in Frame:GetChildren() do
		if v3.Name == "MutationRewardRow" then
			v3:Destroy()
		end
	end

	v1.Visible = false

	for v4, v5 in payingMutations() do
		local MutationRewardRow = v1:Clone()

		MutationRewardRow.Name = "MutationRewardRow"
		MutationRewardRow.Visible = true
		MutationRewardRow.LayoutOrder = v4

		local Icon = MutationRewardRow:FindFirstChild("Icon")

		if Icon and Icon:IsA("ImageLabel") then
			Icon.Image = v5.image
		end

		local Text = MutationRewardRow:FindFirstChild("Text")

		if Text and Text:IsA("TextLabel") then
			Text.Text = ("+%* fuel"):format(v5.fuel)
		end

		MutationRewardRow.Parent = Frame
	end
end

local t2 = {}

local function ensureBoard(p1) --[[ ensureBoard | Line: 96 | Upvalues: t2 (copy), buildBoard (copy) ]]
	if p1:IsA("SurfaceGui") and not t2[p1] then
		t2[p1] = true
		task.spawn(function() --[[ Line: 102 | Upvalues: p1 (copy), buildBoard (ref), t2 (ref) ]]
			while p1:IsDescendantOf(game) do
				buildBoard(p1)

				while p1:IsDescendantOf(game) and p1:FindFirstChild("Frame") do
					task.wait(1)
				end

				task.wait(0.5)
			end

			t2[p1] = nil
		end)
	end
end

function t.Init(p1) --[[ Init | Line: 116 | Upvalues: AlienEventConfig (copy), CollectionService (copy), FuelNpc (copy), t2 (copy), buildBoard (copy), ensureBoard (copy) ]]
	if not AlienEventConfig.Enabled then
		return
	end

	for v1, v2 in CollectionService:GetTagged(FuelNpc.RewardBoardTag) do
		if v2:IsA("SurfaceGui") and not t2[v2] then
			t2[v2] = true
			task.spawn(function() --[[ Line: 102 | Upvalues: v2 (copy), buildBoard (ref), t2 (ref) ]]
				while v2:IsDescendantOf(game) do
					buildBoard(v2)

					while v2:IsDescendantOf(game) and v2:FindFirstChild("Frame") do
						task.wait(1)
					end

					task.wait(0.5)
				end

				t2[v2] = nil
			end)
		end
	end

	CollectionService:GetInstanceAddedSignal(FuelNpc.RewardBoardTag):Connect(ensureBoard)
end

return t