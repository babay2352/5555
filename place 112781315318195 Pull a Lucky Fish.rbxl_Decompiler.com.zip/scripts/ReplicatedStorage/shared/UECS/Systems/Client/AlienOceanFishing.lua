-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ContextActionService = game:GetService("ContextActionService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")
local Workspace = game:GetService("Workspace")
local AlienEventConfig = require(ReplicatedStorage.shared.config.AlienEventConfig)
local AlienFlightState = require(ReplicatedStorage.client.AlienFlightState)
local AlienOceanConfig = require(ReplicatedStorage.shared.config.AlienOceanConfig)
local BeamTo = require(ReplicatedStorage.client.BeamTo)
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local CollectFishUI = require(ReplicatedStorage.shared.module.CollectFishUI)
local ControlHint = require(ReplicatedStorage.client.ControlHint)
local FishConfig = require(ReplicatedStorage.shared.config.FishConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local NumberSpinner = require(ReplicatedStorage.shared.NumberSpinner.NumberSpinner)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local SFX = require(ReplicatedStorage.client.SFX)
local bindToButtonPress = require(ReplicatedStorage.shared.util.bindToButtonPress)
local buildFishModel = require(ReplicatedStorage.shared.util.buildFishModel)
local notifications = require(ReplicatedStorage.shared.module.notifications)
local popInGui = require(ReplicatedStorage.shared.util.popInGui)
local t = {
	UECS = nil
}
local EventId = AlienEventConfig.EventId
local Spawn = AlienOceanConfig.Spawn
local Catch = AlienOceanConfig.Catch
local DepotSign = AlienOceanConfig.DepotSign
local CatchAlert = AlienOceanConfig.CatchAlert
local Minigame = AlienOceanConfig.Minigame
local Swim = AlienOceanConfig.Swim
local Debug = AlienOceanConfig.Debug
local Ride = AlienEventConfig.Ship.Ride
local t2 = {
	Priority = 10000,
	Catch = Enum.KeyCode.ButtonX,
	Unload = Enum.KeyCode.ButtonY
}
local v1 = Color3.fromRGB(150, 255, 170)
local v2 = TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local v3 = Color3.new(0/255, 0/255, 0/255)

local function getAlienState() --[[ getAlienState | Line: 141 | Upvalues: ClientPlayerData (copy), EventId (copy) ]]
	local v1 = ClientPlayerData.serverProfile:getState()

	return v1.events and v1.events[EventId]
end

local function getUpgradeValue(p1) --[[ getUpgradeValue | Line: 148 | Upvalues: ClientPlayerData (copy), EventId (copy), AlienEventConfig (copy) ]]
	local v1 = ClientPlayerData.serverProfile:getState()
	local v2 = v1.events and v1.events[EventId]

	return AlienEventConfig.GetUpgradeValue(p1, v2 and v2.upgrades and v2.upgrades[p1] or 0) or 0
end

local function shipPosition() --[[ shipPosition | Line: 157 | Upvalues: AlienFlightState (copy) ]]
	local shipModel = AlienFlightState.shipModel

	if shipModel then
		return shipModel:GetPivot().Position
	end

	return nil
end

local v4 = nil
local v5 = nil

local function pullTargetPosition() --[[ pullTargetPosition | Line: 170 | Upvalues: AlienFlightState (copy), v5 (ref), v4 (ref), Ride (copy) ]]
	local shipModel = AlienFlightState.shipModel

	if not shipModel then
		return nil
	end

	if v5 ~= shipModel or not (v4 and v4.Parent) then
		v5 = shipModel
		v4 = nil

		local v1 = shipModel:FindFirstChild(Ride.FxPartName, true)
		local v2 = if v1 then v1:FindFirstChild(Ride.FxPullAttachmentName, true) else v1

		if v2 and v2:IsA("Attachment") then
			v4 = v2
		end
	end

	local v3 = v4

	if v3 then
		return v3.WorldPosition
	end

	return nil
end

local function getCargoCount() --[[ getCargoCount | Line: 188 | Upvalues: ClientPlayerData (copy), EventId (copy) ]]
	local v1 = ClientPlayerData.serverProfile:getState()
	local v2 = v1.events and v1.events[EventId]
	local v3 = if v2 then v2.cargo else v2

	if v3 then
		return #v3
	end

	return 0
end

local t3 = {}
local v6 = nil

local function getFishFolder() --[[ getFishFolder | Line: 224 | Upvalues: v6 (ref), Spawn (copy), Workspace (copy) ]]
	local v1 = v6

	if v1 and v1.Parent then
		return v1
	end

	local v2 = Instance.new("Folder")

	v2.Name = Spawn.ClientFishFolderName
	v2.Parent = Workspace
	v6 = v2

	return v2
end

local function buildPlaceholderModel() --[[ buildPlaceholderModel | Line: 239 ]]
	local Model = Instance.new("Model")
	local Part = Instance.new("Part")

	Part.Shape = Enum.PartType.Ball
	Part.Size = Vector3.new(4, 4, 4)
	Part.Material = Enum.Material.Neon
	Part.Color = Color3.fromRGB(120, 255, 160)
	Part.Parent = Model
	Model.PrimaryPart = Part

	return Model
end

local function makeFishPartInert(p1) --[[ makeFishPartInert | Line: 258 ]]
	p1.Anchored = true
	p1.CanCollide = false
	p1.CanTouch = false
	p1.CanQuery = false
end

local function forceFishInert(p1) --[[ forceFishInert | Line: 269 ]]
	for v1, v2 in p1:GetDescendants() do
		if v2:IsA("BasePart") then
			v2.Anchored = true
			v2.CanCollide = false
			v2.CanTouch = false
			v2.CanQuery = false
		end
	end
end

local function makeFishInert(p1) --[[ makeFishInert | Line: 277 | Upvalues: forceFishInert (copy) ]]
	forceFishInert(p1)
	p1.DescendantAdded:Connect(function(p1) --[[ Line: 279 ]]
		if not p1:IsA("BasePart") then
			return
		end

		p1.Anchored = true
		p1.CanCollide = false
		p1.CanTouch = false
		p1.CanQuery = false
	end)
end

local function buildModel(p1) --[[ buildModel | Line: 286 | Upvalues: buildFishModel (copy), buildPlaceholderModel (copy), Spawn (copy), forceFishInert (copy) ]]
	local v1 = buildFishModel.clone(p1) or buildPlaceholderModel()
	local _, v2 = v1:GetBoundingBox()
	local v3 = math.max(v2.X, v2.Y, v2.Z)

	if v3 > 0 then
		v1:ScaleTo(v1:GetScale() * (Spawn.FishScale / v3))
	end

	forceFishInert(v1)
	v1.DescendantAdded:Connect(function(p1) --[[ Line: 279 ]]
		if not p1:IsA("BasePart") then
			return
		end

		p1.Anchored = true
		p1.CanCollide = false
		p1.CanTouch = false
		p1.CanQuery = false
	end)

	return v1
end

local t4 = {
	{
		MaxRatio = 0.5,
		Suffix = "",
		Color = Color3.fromRGB(130, 255, 165)
	},
	{
		MaxRatio = 1,
		Suffix = "",
		Color = Color3.fromRGB(150, 225, 255)
	},
	{
		MaxRatio = (1 / 0),
		Suffix = " - hard",
		Color = Color3.fromRGB(255, 170, 60)
	}
}
local t5 = {
	Suffix = " - too strong",
	Color = Color3.fromRGB(255, 95, 95)
}

local function powerLineStyle(p1) --[[ powerLineStyle | Line: 315 | Upvalues: ClientPlayerData (copy), EventId (copy), AlienEventConfig (copy), AlienOceanConfig (copy), t5 (copy), t4 (copy) ]]
	local v1 = ClientPlayerData.serverProfile:getState()
	local v2 = v1.events and v1.events[EventId]
	local v4 = AlienEventConfig.GetUpgradeValue("ShipPower", v2 and v2.upgrades and v2.upgrades.ShipPower or 0) or 0

	if AlienOceanConfig.IsHopeless(p1, v4) then
		return ("Power %*%*"):format(p1, t5.Suffix), t5.Color
	end

	local v5 = AlienOceanConfig.GetPowerRatio(p1, v4)

	for v6, v7 in t4 do
		if v5 <= v7.MaxRatio then
			return ("Power %*%*"):format(p1, v7.Suffix), v7.Color
		end
	end

	return ("Power %*"):format(p1), t4[#t4].Color
end

local function buildBillboard(p1) --[[ buildBillboard | Line: 329 | Upvalues: FishConfig (copy), ReplicatedStorage (copy), powerLineStyle (copy) ]]
	local PrimaryPart = p1.model.PrimaryPart

	if not PrimaryPart then
		return
	end

	local v1 = FishConfig[p1.kind]
	local _, v2 = p1.model:GetBoundingBox()
	local v3 = ReplicatedStorage:FindFirstChild("shared")
	local v4 = if v3 then v3:FindFirstChild("model") else v3
	local v5 = if v4 then v4:FindFirstChild("AlienFishBillboard") else v4

	if v5 and v5:IsA("BillboardGui") then
		local v6 = v5:Clone()

		v6.StudsOffsetWorldSpace = Vector3.new(0, v2.Y * 0.5 + 2.5, 0)
		v6.AlwaysOnTop = false

		local v8 = if v1 then v1.Rarity else v1
		local Rarity = v6:FindFirstChild("Rarity")

		if Rarity and Rarity:IsA("TextLabel") then
			Rarity.Text = if v8 then v8.displayName else "???"

			if v8 then
				Rarity.TextColor3 = v8.rarityColor
			end
		end

		local FishName = v6:FindFirstChild("FishName")

		if FishName and FishName:IsA("TextLabel") then
			FishName.Text = if v1 then v1.DisplayName else p1.kind
		end

		local Power = v6:FindFirstChild("Power")

		if Power and Power:IsA("TextLabel") then
			local v11, v12 = powerLineStyle(p1.strength)

			Power.Text = v11
			Power.TextColor3 = v12
		end

		local Timer = v6:FindFirstChild("Timer")

		if not (Timer and Timer:IsA("TextLabel")) then
			v6.Parent = PrimaryPart

			return
		end

		Timer.Text = ""
		p1.timerLabel = Timer
		v6.Parent = PrimaryPart
	else
		local FishLabel = Instance.new("BillboardGui")

		FishLabel.Name = "FishLabel"
		FishLabel.Size = UDim2.fromOffset(140, 66)
		FishLabel.StudsOffsetWorldSpace = Vector3.new(0, v2.Y * 0.5 + 2.5, 0)
		FishLabel.MaxDistance = 300
		FishLabel.AlwaysOnTop = false
		FishLabel.Parent = PrimaryPart

		local function makeLine(p1, p2, p3, p4, p5) --[[ makeLine | Line: 388 | Upvalues: FishLabel (copy) ]]
			local TextLabel = Instance.new("TextLabel")

			TextLabel.Size = UDim2.new(1, 0, 0, p4)
			TextLabel.Position = UDim2.fromOffset(0, p1)
			TextLabel.BackgroundTransparency = 1
			TextLabel.Font = Enum.Font.GothamBlack
			TextLabel.TextSize = p5
			TextLabel.TextColor3 = p3
			TextLabel.Text = p2

			local UIStroke = Instance.new("UIStroke")

			UIStroke.Color = Color3.new(0/255, 0/255, 0/255)
			UIStroke.Thickness = 1.5
			UIStroke.Parent = TextLabel
			TextLabel.Parent = FishLabel

			return TextLabel
		end

		local v14 = if v1 then v1.Rarity else v1

		makeLine(0, if v14 then v14.displayName else "???", if v14 then v14.rarityColor else Color3.new(255/255, 255/255, 255/255), 16, 14)
		makeLine(16, if v1 then v1.DisplayName else p1.kind, Color3.new(255/255, 255/255, 255/255), 20, 17)

		local v21, v22 = powerLineStyle(p1.strength)

		makeLine(36, v21, v22, 14, 12)
		p1.timerLabel = makeLine(50, "", Color3.fromRGB(255, 210, 120), 14, 12)
	end
end

local function removeFish(p1, p2) --[[ removeFish | Line: 415 | Upvalues: t3 (copy), RunService (copy) ]]
	if t3[p1.id] ~= p1 then
		return
	end

	t3[p1.id] = nil

	local model = p1.model

	if p2 then
		model:Destroy()
	else
		task.spawn(function() --[[ Line: 425 | Upvalues: model (copy), RunService (ref) ]]
			local v1 = model:GetPivot()
			local sum2 = 0

			while sum2 < 0.35 and model.Parent do
				sum2 = sum2 + RunService.Heartbeat:Wait()

				local v2 = math.clamp(sum2 / 0.35, 0, 1)

				model:PivotTo(v1 * CFrame.new(0, v2 * -6 * v2, 0))
			end

			model:Destroy()
		end)
	end
end

local function addFish(p1) --[[ addFish | Line: 438 | Upvalues: AlienOceanConfig (copy), t3 (copy), buildModel (copy), v6 (ref), Spawn (copy), Workspace (copy), buildBillboard (copy) ]]
	if type(p1) ~= "table" then
		return
	end

	local v1 = tonumber(p1.Id)
	local Kind = p1.Kind
	local Position = p1.Position
	local v2 = tonumber(p1.ExpiresAt)
	local v3 = if type(Kind) == "string" then AlienOceanConfig.FishByKind[Kind] else nil

	if not v1 or (not v3 or (typeof(Position) ~= "Vector3" or not v2)) then
		return
	end

	if t3[v1] then
		return
	end

	local v4 = buildModel(Kind)

	v4.Name = Kind
	v4:SetAttribute("AlienOceanFishId", v1)
	v4:PivotTo(CFrame.new(Position) * CFrame.Angles(0, math.random() * 2 * math.pi, 0))

	local v5 = v6
	local v62

	if v5 and v5.Parent then
		v62 = v5
	else
		local v7 = Instance.new("Folder")

		v7.Name = Spawn.ClientFishFolderName
		v7.Parent = Workspace
		v6 = v7
		v62 = v7
	end

	v4.Parent = v62

	local t = {
		timerLabel = nil,
		lastSeconds = -1,
		beingCaught = false,
		id = v1,
		kind = Kind,
		config = v3,
		model = v4,
		basePosition = Position
	}

	t.strength = tonumber(p1.Strength) or v3.StrengthMin
	t.expiresAt = v2
	t.phase = math.random() * 2 * math.pi
	t.yaw = math.random() * 2 * math.pi
	t.yawSpeed = (math.random() - 0.5) * 0.8
	t.swimPosition = Position
	t3[v1] = t
	buildBillboard(t)
end

local function clearAllFish() --[[ clearAllFish | Line: 481 | Upvalues: t3 (copy) ]]
	for v1, v2 in t3 do
		v2.model:Destroy()
	end

	table.clear(t3)
end

local t6 = {}
local v7 = ""
local t7 = {}

local function buildMiniFish(p1, p2) --[[ buildMiniFish | Line: 516 | Upvalues: buildFishModel (copy), buildPlaceholderModel (copy), forceFishInert (copy) ]]
	local v1 = buildFishModel.clone(p1) or buildPlaceholderModel()
	local _, v2 = v1:GetBoundingBox()
	local v3 = math.max(v2.X, v2.Y, v2.Z)

	if v3 > 0 then
		v1:ScaleTo(v1:GetScale() * ((p2 or 3.4) / v3))
	end

	forceFishInert(v1)
	v1.DescendantAdded:Connect(function(p1) --[[ Line: 279 ]]
		if not p1:IsA("BasePart") then
			return
		end

		p1.Anchored = true
		p1.CanCollide = false
		p1.CanTouch = false
		p1.CanQuery = false
	end)

	return v1
end

local function clearCarriedDisplay() --[[ clearCarriedDisplay | Line: 527 | Upvalues: t6 (copy), v7 (ref) ]]
	for v1, v2 in t6 do
		v2:Destroy()
	end

	table.clear(t6)
	v7 = ""
end

local function clearDroppedFish() --[[ clearDroppedFish | Line: 535 | Upvalues: t7 (copy) ]]
	for v1, v2 in t7 do
		v2.model:Destroy()
	end

	table.clear(t7)
end

local function updateCarriedDisplay() --[[ updateCarriedDisplay | Line: 544 | Upvalues: ClientPlayerData (copy), EventId (copy), AlienFlightState (copy), v7 (ref), t6 (copy), buildMiniFish (copy), Workspace (copy) ]]
	local v1 = ClientPlayerData.serverProfile:getState()
	local v2 = v1.events and v1.events[EventId]
	local v3 = (if AlienFlightState.inFlight and v2 then v2.cargo else nil) or {}
	local v4 = table.concat(v3, "|")

	if v4 == v7 then
		return
	end

	for v5, v6 in t6 do
		v6:Destroy()
	end

	table.clear(t6)
	v7 = ""
	v7 = v4

	for v72, v8 in v3 do
		local v9 = buildMiniFish(v8)

		v9.Name = ("Carried_%*"):format(v8)
		v9.Parent = Workspace
		table.insert(t6, v9)
	end
end

local function stepCarried(p1) --[[ stepCarried | Line: 563 | Upvalues: t6 (copy), AlienFlightState (copy) ]]
	if #t6 == 0 then
		return
	end

	local shipModel = AlienFlightState.shipModel

	if not shipModel then
		return
	end

	local Position = shipModel:GetPivot().Position
	local v1 = #t6

	for v2, v3 in t6 do
		local v4 = v2 / v1 * 2 * math.pi + p1 * -0.6
		local v8 = Vector3.new(math.sin(v4) * 5, math.sin(p1 * 2 + v2) * 0.4 + 5, math.cos(v4) * 5)

		v3:PivotTo(CFrame.new(Position + v8) * CFrame.Angles(0, v4 + -1.5707963267948966, 0))
	end
end

local function stepDropped(p1) --[[ stepDropped | Line: 587 | Upvalues: t7 (copy), RunService (copy) ]]
	for i = #t7, 1, -1 do
		local v1 = t7[i]

		if not (p1 < v1.expiresAt) then
			table.remove(t7, i)

			local model = v1.model

			task.spawn(function() --[[ Line: 595 | Upvalues: model (copy), RunService (ref) ]]
				local v1 = model:GetPivot()
				local sum = 0

				while sum < 0.6 and model.Parent do
					sum = sum + RunService.Heartbeat:Wait()

					local v2 = math.clamp(sum / 0.6, 0, 1)

					model:PivotTo(v1 * CFrame.new(0, v2 * -3 * v2, 0))
				end

				model:Destroy()
			end)
		end
	end
end

local v8 = nil

local function updateFightFill(p1) --[[ updateFightFill | Line: 652 ]]
	local v1 = math.clamp(p1.progress, 0, 1)

	p1.ui.fill.Size = UDim2.fromScale(if p1.ui.template then v1 * 0.85 + 0.15 else v1, 1)
end

local function getUfoEventFrame() --[[ getUfoEventFrame | Line: 659 | Upvalues: Players (copy) ]]
	local PlayerGui = Players.LocalPlayer:FindFirstChildOfClass("PlayerGui")
	local v1 = if PlayerGui then PlayerGui:FindFirstChild("MainUI") else PlayerGui
	local v2 = if v1 then v1:FindFirstChild("UfoEvent") else v1

	if v2 and v2:IsA("Frame") then
		return v2
	end

	return nil
end

local v9 = TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local v10 = nil

local function findClickFastFrame(p1) --[[ findClickFastFrame | Line: 694 ]]
	for v1, v2 in p1:GetDescendants() do
		if v2.Name == "ClickFast" and (v2:IsA("GuiObject") and v2:FindFirstChild("Counter")) then
			return v2
		end
	end

	return nil
end

local function getClickFast() --[[ getClickFast | Line: 703 | Upvalues: v10 (ref), Players (copy), findClickFastFrame (copy), NumberSpinner (copy) ]]
	local v1 = v10

	if v1 and v1.frame.Parent then
		return v1
	end

	local PlayerGui = Players.LocalPlayer:FindFirstChildOfClass("PlayerGui")
	local v2 = if PlayerGui then PlayerGui:FindFirstChild("MainUI") else PlayerGui
	local v3 = if v2 then v2:FindFirstChild("UfoEvent") else v2
	local v4 = if v3 and v3:IsA("Frame") then v3 else nil
	local v5 = if v4 then findClickFastFrame(v4) else v4

	if not v5 then
		v10 = nil

		return nil
	end

	local Counter = v5:FindFirstChild("Counter")

	if not (Counter and Counter:IsA("GuiObject")) then
		v10 = nil

		return nil
	end

	local v6 = NumberSpinner.fromGuiObject(Counter)

	if v6 then
		v6.Visible = true
		v6.Decimals = 0
		v6.Prefix = ""
		v6.Suffix = ""
		v6.Duration = 0.15
		v6.TextSize = 24
		v6.AutomaticSize = Enum.AutomaticSize.X
		v6.Size = UDim2.fromScale(0, 1)

		local Size = v5.Size
		local t = {
			frame = v5,
			baseSize = Size,
			poppedSize = UDim2.new(Size.X.Scale * 1.2, Size.X.Offset * 1.2, Size.Y.Scale * 1.2, Size.Y.Offset * 1.2),
			spinner = v6
		}

		v10 = t

		return t
	end

	v10 = nil

	return nil
end

local function bumpClickFast(p1, p2) --[[ bumpClickFast | Line: 753 | Upvalues: TweenService (copy), v9 (copy) ]]
	p1.spinner.Value = p2
	p1.frame.Size = p1.poppedSize
	TweenService:Create(p1.frame, v9, {
		Size = p1.baseSize
	}):Play()
end

local function hideTemplateFightElements() --[[ hideTemplateFightElements | Line: 761 | Upvalues: Players (copy), getClickFast (copy) ]]
	local PlayerGui = Players.LocalPlayer:FindFirstChildOfClass("PlayerGui")
	local v1 = if PlayerGui then PlayerGui:FindFirstChild("MainUI") else PlayerGui
	local v2 = if v1 then v1:FindFirstChild("UfoEvent") else v1
	local v3 = if v2 and v2:IsA("Frame") then v2 else nil

	if not v3 then
		return
	end

	local CatchFishBar = v3:FindFirstChild("CatchFishBar")

	if CatchFishBar and CatchFishBar:IsA("GuiObject") then
		CatchFishBar.Visible = false
	end

	local v4 = getClickFast()

	if v4 then
		v4.frame.Visible = false
	end

	local TotalClicksCounter = v3:FindFirstChild("TotalClicksCounter")

	if not (TotalClicksCounter and TotalClicksCounter:IsA("GuiObject")) then
		return
	end

	TotalClicksCounter.Visible = false
end

local function buildTemplateFightUi(p1) --[[ buildTemplateFightUi | Line: 785 | Upvalues: Players (copy), FishConfig (copy), getClickFast (copy), popInGui (copy) ]]
	local PlayerGui = Players.LocalPlayer:FindFirstChildOfClass("PlayerGui")
	local v1 = if PlayerGui then PlayerGui:FindFirstChild("MainUI") else PlayerGui
	local v2 = if v1 then v1:FindFirstChild("UfoEvent") else v1
	local v3 = if v2 and v2:IsA("Frame") then v2 else nil
	local v4 = if v3 then v3:FindFirstChild("CatchFishBar") else v3
	local v5 = if v4 then v4:FindFirstChild("Filler") else v4

	if not (v3 and (v4 and (v4:IsA("GuiObject") and (v5 and v5:IsA("Frame"))))) then
		return nil
	end

	local v6 = FishConfig[p1.kind]
	local FishContainer = v4:FindFirstChild("FishContainer")
	local v7 = if FishContainer then FishContainer:FindFirstChild("FishImage") else FishContainer

	if v7 and v7:IsA("ImageLabel") then
		v7.Image = if v6 then v6.Image else ""
	end

	local v9 = if FishContainer then FishContainer:FindFirstChild("NameOfFish") else FishContainer

	if v9 and v9:IsA("TextLabel") then
		v9.Text = if v6 then v6.DisplayName else p1.kind

		if v6 then
			v9.TextColor3 = v6.Rarity.rarityColor
		end
	end

	local v11 = getClickFast()

	if v11 then
		v11.spinner.Value = 0
		v11.frame.Size = v11.baseSize
		popInGui(v11.frame, true)
	end

	popInGui(v4, true)

	return {
		template = true,
		root = v4,
		fill = v5,
		clickFast = v11
	}
end

local function buildFightUi(p1) --[[ buildFightUi | Line: 823 | Upvalues: FishConfig (copy), Players (copy), v3 (copy), Minigame (copy), v1 (copy) ]]
	local v12 = FishConfig[p1.kind]
	local AlienCatchUI = Instance.new("ScreenGui")

	AlienCatchUI.Name = "AlienCatchUI"
	AlienCatchUI.ResetOnSpawn = false
	AlienCatchUI.DisplayOrder = 60
	AlienCatchUI.Parent = Players.LocalPlayer:WaitForChild("PlayerGui")

	local Frame = Instance.new("Frame")

	Frame.AnchorPoint = Vector2.new(0.5, 1)
	Frame.Position = UDim2.new(0.5, 0, 1, -210)
	Frame.Size = UDim2.new(0.45, 0, 0, 88)
	Frame.BackgroundColor3 = v3
	Frame.BackgroundTransparency = 0.35
	Frame.BorderSizePixel = 0
	Frame.Parent = AlienCatchUI

	local UISizeConstraint = Instance.new("UISizeConstraint")

	UISizeConstraint.MinSize = Vector2.new(280, 88)
	UISizeConstraint.MaxSize = Vector2.new(420, 88)
	UISizeConstraint.Parent = Frame

	local UICorner = Instance.new("UICorner")

	UICorner.CornerRadius = UDim.new(0, 10)
	UICorner.Parent = Frame

	local ImageLabel = Instance.new("ImageLabel")

	ImageLabel.AnchorPoint = Vector2.new(0, 0.5)
	ImageLabel.Position = UDim2.new(0, 12, 0.5, 0)
	ImageLabel.Size = UDim2.fromOffset(64, 64)
	ImageLabel.BackgroundTransparency = 1
	ImageLabel.Image = if v12 then v12.Image else ""
	ImageLabel.Parent = Frame

	local TextLabel = Instance.new("TextLabel")

	TextLabel.Position = UDim2.fromOffset(88, 10)
	TextLabel.Size = UDim2.new(1, -100, 0, 22)
	TextLabel.BackgroundTransparency = 1
	TextLabel.Font = Enum.Font.GothamBlack
	TextLabel.TextSize = 18
	TextLabel.TextXAlignment = Enum.TextXAlignment.Left
	TextLabel.TextColor3 = if v12 then v12.Rarity.rarityColor else Color3.new(255/255, 255/255, 255/255)
	TextLabel.Text = if v12 then v12.DisplayName else p1.kind
	TextLabel.Parent = Frame

	local Frame2 = Instance.new("Frame")

	Frame2.Position = UDim2.fromOffset(88, 40)
	Frame2.Size = UDim2.new(1, -100, 0, 20)
	Frame2.BackgroundColor3 = Color3.fromRGB(35, 35, 35)
	Frame2.BorderSizePixel = 0
	Frame2.Parent = Frame

	local UICorner2 = Instance.new("UICorner")

	UICorner2.CornerRadius = UDim.new(0, 6)
	UICorner2.Parent = Frame2

	local Frame3 = Instance.new("Frame")

	Frame3.Size = UDim2.fromScale(Minigame.StartProgress, 1)
	Frame3.BackgroundColor3 = v1
	Frame3.BorderSizePixel = 0
	Frame3.Parent = Frame2

	local UICorner3 = Instance.new("UICorner")

	UICorner3.CornerRadius = UDim.new(0, 6)
	UICorner3.Parent = Frame3

	local TextLabel2 = Instance.new("TextLabel")

	TextLabel2.Position = UDim2.fromOffset(88, 62)
	TextLabel2.Size = UDim2.new(1, -100, 0, 18)
	TextLabel2.BackgroundTransparency = 1
	TextLabel2.Font = Enum.Font.GothamBlack
	TextLabel2.TextSize = 14
	TextLabel2.TextXAlignment = Enum.TextXAlignment.Left
	TextLabel2.TextColor3 = Color3.fromRGB(255, 230, 120)
	TextLabel2.Text = "Tap fast to pull it in!"
	TextLabel2.Parent = Frame

	return {
		template = false,
		clickFast = nil,
		root = AlienCatchUI,
		fill = Frame3
	}
end

local v11 = nil
local v12 = false

local function setShipFx(p1) --[[ setShipFx | Line: 927 | Upvalues: AlienFlightState (copy), v11 (ref), v12 (ref), Ride (copy) ]]
	local shipModel = AlienFlightState.shipModel
	local v1 = v11

	if p1 == v12 and (v1 and v1.model == shipModel) then
		return
	end

	local v2 = if shipModel then shipModel:FindFirstChild(Ride.FxPartName, true) else shipModel

	if v2 then
		if v1 and v1.model ~= shipModel then
			v11 = nil
		end

		if not v11 then
			local t = {
				model = shipModel,
				emitters = {},
				beams = {},
				meshes = {}
			}

			for v3, v4 in v2:GetDescendants() do
				if v4:IsA("ParticleEmitter") then
					table.insert(t.emitters, v4)

					continue
				end

				if v4:IsA("Beam") then
					table.insert(t.beams, v4)

					continue
				end

				if v4:IsA("BasePart") then
					t.meshes[v4] = v4.Transparency
					v4.CanQuery = false

					if v4.Transparency >= 1 then
						warn(("[AlienOceanFishing] %* is authored Transparency=1 (invisible), "):format((v4:GetFullName())) .. "so turning the tractor FX on cannot make it show")
					end
				end
			end

			v11 = t
		end

		local v5 = v11

		for v6, v7 in v5.emitters do
			if v7.Parent then
				v7.Enabled = p1
			end
		end

		for v8, v9 in v5.beams do
			if v9.Parent then
				v9.Enabled = p1
			end
		end

		for v10, v112 in v5.meshes do
			if v10.Parent then
				v10.Transparency = if p1 then v112 else 1
			end
		end

		v12 = p1
	else
		if not shipModel then
			return
		end

		warn((("[AlienOceanFishing] ship has no %* \226\128\148 no tractor FX to play"):format(Ride.FxPartName)))
	end
end

local function verifyShipFx() --[[ verifyShipFx | Line: 1005 | Upvalues: v11 (ref), v12 (ref) ]]
	local v1 = v11

	if not v1 then
		return
	end

	for v2, v3 in v1.beams do
		if v3.Parent and v3.Enabled ~= v12 then
			v3.Enabled = v12
		end
	end

	for v4, v5 in v1.emitters do
		if v5.Parent and v5.Enabled ~= v12 then
			v5.Enabled = v12
		end
	end

	for v6, v7 in v1.meshes do
		if v6.Parent then
			local v8 = if v12 then v7 else 1

			if math.abs(v6.Transparency - v8) > 0.001 then
				v6.Transparency = v8
			end
		end
	end
end

local v13 = nil

local function teardownFight(p1) --[[ teardownFight | Line: 1036 | Upvalues: AlienFlightState (copy), v13 (ref), setShipFx (copy), popInGui (copy) ]]
	AlienFlightState.fighting = false
	AlienFlightState.fightTarget = nil
	v13()
	setShipFx(false)

	local ui = p1.ui

	if ui.template then
		local root = ui.root

		if root:IsA("GuiObject") then
			popInGui(root, false)
		end

		if ui.clickFast then
			popInGui(ui.clickFast.frame, false)
		end
	else
		ui.root:Destroy()
	end
end

local function playSuckIn(p1) --[[ playSuckIn | Line: 1059 | Upvalues: RunService (copy), AlienFlightState (copy), pullTargetPosition (copy) ]]
	local model = p1.model

	task.spawn(function() --[[ Line: 1061 | Upvalues: model (copy), RunService (ref), AlienFlightState (ref), pullTargetPosition (ref) ]]
		local v1 = model:GetPivot()
		local v2 = model:GetScale()
		local sum2 = 0

		while sum2 < 0.4 and model.Parent do
			sum2 = sum2 + RunService.Heartbeat:Wait()

			local v3 = math.clamp(sum2 / 0.4, 0, 1)
			local shipModel = AlienFlightState.shipModel
			local v4 = if shipModel then shipModel:GetPivot().Position else v1.Position

			model:PivotTo(CFrame.new(v1.Position:Lerp(pullTargetPosition() or v4, v3 * v3)) * v1.Rotation)
			model:ScaleTo((math.max(v2 * (1 - v3 * 0.9), 0.05)))
		end

		model:Destroy()
	end)
end

local function finishFight(p1) --[[ finishFight | Line: 1081 | Upvalues: v8 (ref), Remotes (copy), teardownFight (copy), t3 (copy), RunService (copy), AlienFlightState (copy), pullTargetPosition (copy), CollectFishUI (copy), SFX (copy), AlienOceanConfig (copy), ClientPlayerData (copy), EventId (copy), AlienEventConfig (copy), notifications (copy) ]]
	local v1 = v8

	if v1 and not v1.finishing then
		v1.finishing = true
		task.spawn(function() --[[ Line: 1088 | Upvalues: v1 (copy), Remotes (ref), p1 (copy), teardownFight (ref), v8 (ref), t3 (ref), RunService (ref), AlienFlightState (ref), pullTargetPosition (ref), CollectFishUI (ref), SFX (ref), AlienOceanConfig (ref), ClientPlayerData (ref), EventId (ref), AlienEventConfig (ref), notifications (ref) ]]
			local fish = v1.fish
			local v12, v2 = Remotes.AlienCatchFinish:Call({
				Id = fish.id,
				Success = p1,
				Rejected = v1.rejectedPumps
			}):Await()

			teardownFight(v1)

			if v8 == v1 then
				v8 = nil
			end

			fish.beingCaught = false

			local v3 = if v12 and type(v2) == "table" then v2 else nil

			if p1 and (if v3 == nil or v3.Ok ~= true then false elseif v3.Caught == true then true else false) then
				t3[fish.id] = nil

				local model = fish.model

				task.spawn(function() --[[ Line: 1061 | Upvalues: model (copy), RunService (ref), AlienFlightState (ref), pullTargetPosition (ref) ]]
					local v1 = model:GetPivot()
					local v2 = model:GetScale()
					local sum2 = 0

					while sum2 < 0.4 and model.Parent do
						sum2 = sum2 + RunService.Heartbeat:Wait()

						local v3 = math.clamp(sum2 / 0.4, 0, 1)
						local shipModel = AlienFlightState.shipModel
						local v4 = if shipModel then shipModel:GetPivot().Position else v1.Position

						model:PivotTo(CFrame.new(v1.Position:Lerp(pullTargetPosition() or v4, v3 * v3)) * v1.Rotation)
						model:ScaleTo((math.max(v2 * (1 - v3 * 0.9), 0.05)))
					end

					model:Destroy()
				end)
				CollectFishUI.play(fish.kind)

				return
			end

			if t3[fish.id] == fish then
				t3[fish.id] = nil

				local model = fish.model

				task.spawn(function() --[[ Line: 425 | Upvalues: model (copy), RunService (ref) ]]
					local v1 = model:GetPivot()
					local sum2 = 0

					while sum2 < 0.35 and model.Parent do
						sum2 = sum2 + RunService.Heartbeat:Wait()

						local v2 = math.clamp(sum2 / 0.35, 0, 1)

						model:PivotTo(v1 * CFrame.new(0, v2 * -6 * v2, 0))
					end

					model:Destroy()
				end)
			end

			SFX.new(SFX.Sounds.Poof, 0.4)

			local v52 = if v3 then if type(v3.Message) == "string" then v3.Message else nil else nil

			if not v52 then
				local v62 = ClientPlayerData.serverProfile:getState()
				local v72 = v62.events and v62.events[EventId]

				if AlienOceanConfig.IsHopeless(fish.strength, AlienEventConfig.GetUpgradeValue("ShipPower", v72 and v72.upgrades and v72.upgrades.ShipPower or 0) or 0) then
					v52 = "Too strong! Upgrade your Ship Power."
				end
			end

			notifications:Send(v52 or "The fish got away!")
		end)
	end
end

local function punchFightPanel(p1) --[[ punchFightPanel | Line: 1135 | Upvalues: TweenService (copy), v2 (copy) ]]
	local root = p1.ui.root

	if root:IsA("GuiObject") then
		p1.punchSide = -p1.punchSide
		root.Rotation = p1.punchSide * 1.6
		TweenService:Create(root, v2, {
			Rotation = 0
		}):Play()
	end
end

local v14 = 1 / Catch.MaxClicksPerSecond * Catch.ClickTolerance

local function pumpFight() --[[ pumpFight | Line: 1159 | Upvalues: v8 (ref), v14 (copy), SFX (copy), punchFightPanel (copy), Minigame (copy), TweenService (copy), v9 (copy), Remotes (copy), teardownFight (copy), t3 (copy), RunService (copy), AlienFlightState (copy), pullTargetPosition (copy), CollectFishUI (copy), AlienOceanConfig (copy), ClientPlayerData (copy), EventId (copy), AlienEventConfig (copy), notifications (copy) ]]
	local v1 = v8

	if not v1 or v1.finishing then
		return
	end

	local v2 = os.clock()

	if v2 - v1.lastPumpAt < v14 then
		v1.rejectedPumps = v1.rejectedPumps + 1

		return
	end

	v1.lastPumpAt = v2
	SFX.PlaySoundWithRandomPitch(SFX.Sounds.Click, 0.2, 0.9, 1.15)
	punchFightPanel(v1)
	v1.progress = math.min(v1.progress + Minigame.ClickGain, 1)
	v1.clicks = v1.clicks + 1

	if v1.ui.clickFast then
		local clickFast = v1.ui.clickFast

		clickFast.spinner.Value = v1.clicks
		clickFast.frame.Size = clickFast.poppedSize
		TweenService:Create(clickFast.frame, v9, {
			Size = clickFast.baseSize
		}):Play()
	end

	local v4 = math.clamp(v1.progress, 0, 1)

	v1.ui.fill.Size = UDim2.fromScale(if v1.ui.template then v4 * 0.85 + 0.15 else v4, 1)

	if not (v1.progress >= 1) then
		return
	end

	local v6 = v8

	if not v6 then
		return
	end

	if v6.finishing then
		return
	end

	v6.finishing = true

	local v7 = true

	task.spawn(function() --[[ Line: 1088 | Upvalues: v6 (copy), Remotes (ref), v7 (copy), teardownFight (ref), v8 (ref), t3 (ref), RunService (ref), AlienFlightState (ref), pullTargetPosition (ref), CollectFishUI (ref), SFX (ref), AlienOceanConfig (ref), ClientPlayerData (ref), EventId (ref), AlienEventConfig (ref), notifications (ref) ]]
		local fish = v6.fish
		local v12, v2 = Remotes.AlienCatchFinish:Call({
			Id = fish.id,
			Success = v7,
			Rejected = v6.rejectedPumps
		}):Await()

		teardownFight(v6)

		if v8 == v6 then
			v8 = nil
		end

		fish.beingCaught = false

		local v3 = if v12 and type(v2) == "table" then v2 else nil

		if v7 and (if v3 == nil or v3.Ok ~= true then false elseif v3.Caught == true then true else false) then
			t3[fish.id] = nil

			local model = fish.model

			task.spawn(function() --[[ Line: 1061 | Upvalues: model (copy), RunService (ref), AlienFlightState (ref), pullTargetPosition (ref) ]]
				local v1 = model:GetPivot()
				local v2 = model:GetScale()
				local sum2 = 0

				while sum2 < 0.4 and model.Parent do
					sum2 = sum2 + RunService.Heartbeat:Wait()

					local v3 = math.clamp(sum2 / 0.4, 0, 1)
					local shipModel = AlienFlightState.shipModel
					local v4 = if shipModel then shipModel:GetPivot().Position else v1.Position

					model:PivotTo(CFrame.new(v1.Position:Lerp(pullTargetPosition() or v4, v3 * v3)) * v1.Rotation)
					model:ScaleTo((math.max(v2 * (1 - v3 * 0.9), 0.05)))
				end

				model:Destroy()
			end)
			CollectFishUI.play(fish.kind)

			return
		end

		if t3[fish.id] == fish then
			t3[fish.id] = nil

			local model = fish.model

			task.spawn(function() --[[ Line: 425 | Upvalues: model (copy), RunService (ref) ]]
				local v1 = model:GetPivot()
				local sum2 = 0

				while sum2 < 0.35 and model.Parent do
					sum2 = sum2 + RunService.Heartbeat:Wait()

					local v2 = math.clamp(sum2 / 0.35, 0, 1)

					model:PivotTo(v1 * CFrame.new(0, v2 * -6 * v2, 0))
				end

				model:Destroy()
			end)
		end

		SFX.new(SFX.Sounds.Poof, 0.4)

		local v52 = if v3 then if type(v3.Message) == "string" then v3.Message else nil else nil

		if not v52 then
			local v62 = ClientPlayerData.serverProfile:getState()
			local v72 = v62.events and v62.events[EventId]

			if AlienOceanConfig.IsHopeless(fish.strength, AlienEventConfig.GetUpgradeValue("ShipPower", v72 and v72.upgrades and v72.upgrades.ShipPower or 0) or 0) then
				v52 = "Too strong! Upgrade your Ship Power."
			end
		end

		notifications:Send(v52 or "The fish got away!")
	end)
end

local v15 = false
local v16 = nil

local function startFightCamera() --[[ startFightCamera | Line: 1205 | Upvalues: Workspace (copy), v15 (ref), v16 (ref) ]]
	local CurrentCamera = Workspace.CurrentCamera

	if CurrentCamera and not v15 then
		v15 = true
		v16 = nil
		CurrentCamera.CameraType = Enum.CameraType.Scriptable
	end
end

v13 = function() --[[ stopFightCamera | Line: 1215 | Upvalues: v15 (ref), Workspace (copy), Players (copy) ]]
	if not v15 then
		return
	end

	v15 = false

	local CurrentCamera = Workspace.CurrentCamera

	if not CurrentCamera then
		return
	end

	local Character = Players.LocalPlayer.Character
	local v1 = if Character then Character:FindFirstChildOfClass("Humanoid") else Character

	if v1 then
		CurrentCamera.CameraSubject = v1
	end

	CurrentCamera.CameraType = Enum.CameraType.Custom
end

local function updateFightCamera(p1, p2) --[[ updateFightCamera | Line: 1233 | Upvalues: Workspace (copy), AlienFlightState (copy), v15 (ref), v16 (ref) ]]
	local CurrentCamera = Workspace.CurrentCamera
	local shipModel = AlienFlightState.shipModel
	local v1 = if shipModel then shipModel:GetPivot().Position else nil

	if not (CurrentCamera and (v1 and v15)) then
		return
	end

	local v2 = AlienFlightState.fightTarget or p1.fish.model:GetPivot().Position
	local v3 = (v1 + v2) * 0.5
	local v4 = v2 - v1
	local v5 = Vector3.new(v4.X, 0, v4.Z)

	if v5.Magnitude > 6 or not v16 then
		local v6 = if v5.Magnitude > 0.01 then true else false
		local v7 = if v6 then v5.Unit:Cross(Vector3.new(0, 1, 0)) else CurrentCamera.CFrame.RightVector

		if v7:Dot(CurrentCamera.CFrame.Position - v3) < 0 then
			v7 = -v7
		end

		v16 = v7
	end

	local v10 = v3 + v16 * math.max(34, v4.Magnitude * 1.6)

	CurrentCamera.CFrame = CurrentCamera.CFrame:Lerp(CFrame.lookAt(v10 + Vector3.new(0, v1.Y - v3.Y + 4, 0), v3), 1 - math.exp(p2 * -3))
end

local v17 = nil

local function showCatchAlert() --[[ showCatchAlert | Line: 1287 | Upvalues: SFX (copy), CatchAlert (copy), v17 (ref), Players (copy), TweenService (copy) ]]
	SFX.new(SFX.Sounds.AlienCatchAlert, CatchAlert.SoundVolume)

	local v1 = v17

	v17 = nil

	if v1 then
		v1:Destroy()
	end

	local Character = Players.LocalPlayer.Character
	local v2 = if Character then Character:FindFirstChild("Head") else Character

	if v2 and v2:IsA("BasePart") then
		local AlienCatchAlert = Instance.new("BillboardGui")

		AlienCatchAlert.Name = "AlienCatchAlert"
		AlienCatchAlert.Adornee = v2
		AlienCatchAlert.StudsOffsetWorldSpace = Vector3.new(0, CatchAlert.HeightOffset, 0)
		AlienCatchAlert.Size = UDim2.fromScale(CatchAlert.Size.X, CatchAlert.Size.Y)
		AlienCatchAlert.AlwaysOnTop = true
		AlienCatchAlert.ResetOnSpawn = false

		local TextLabel = Instance.new("TextLabel")

		TextLabel.Size = UDim2.fromScale(1, 1)
		TextLabel.BackgroundTransparency = 1
		TextLabel.Font = Enum.Font.GothamBlack
		TextLabel.TextScaled = true
		TextLabel.TextColor3 = CatchAlert.Color
		TextLabel.Text = CatchAlert.Text
		TextLabel.Parent = AlienCatchAlert

		local UIStroke = Instance.new("UIStroke")

		UIStroke.Color = Color3.new(0/255, 0/255, 0/255)
		UIStroke.Thickness = 2
		UIStroke.Parent = TextLabel
		AlienCatchAlert.Parent = v2
		v17 = AlienCatchAlert

		local v3 = TweenInfo.new(CatchAlert.Duration, Enum.EasingStyle.Quad, Enum.EasingDirection.In)

		TweenService:Create(TextLabel, v3, {
			TextTransparency = 1
		}):Play()
		TweenService:Create(UIStroke, v3, {
			Transparency = 1
		}):Play()
		task.delay(CatchAlert.Duration + 0.1, function() --[[ Line: 1336 | Upvalues: v17 (ref), AlienCatchAlert (copy) ]]
			if v17 == AlienCatchAlert then
				v17 = nil
			end

			AlienCatchAlert:Destroy()
		end)
	end
end

local function startFight(p1) --[[ startFight | Line: 1344 | Upvalues: buildTemplateFightUi (copy), buildFightUi (copy), AlienFlightState (copy), popInGui (copy), forceFishInert (copy), Minigame (copy), AlienOceanConfig (copy), ClientPlayerData (copy), EventId (copy), AlienEventConfig (copy), v8 (ref), setShipFx (copy), Workspace (copy), v15 (ref), v16 (ref), showCatchAlert (copy) ]]
	local v1 = buildTemplateFightUi(p1) or buildFightUi(p1)

	if AlienFlightState.shipModel then
		p1.beingCaught = true
		forceFishInert(p1.model)

		if p1.timerLabel then
			p1.timerLabel.Text = ""
		end

		local t = {
			lastPumpAt = 0,
			rejectedPumps = 0,
			elapsed = 0,
			clicks = 0,
			punchSide = 1,
			finishing = false,
			fish = p1,
			progress = Minigame.StartProgress
		}
		local v2 = ClientPlayerData.serverProfile:getState()
		local v3 = v2.events and v2.events[EventId]

		t.drainPerSecond = AlienOceanConfig.GetDrainPerSecond(p1.strength, AlienEventConfig.GetUpgradeValue("ShipPower", v3 and v3.upgrades and v3.upgrades.ShipPower or 0) or 0)
		t.pullFrom = p1.model:GetPivot().Position
		t.ui = v1
		v8 = t
		AlienFlightState.fighting = true
		AlienFlightState.fightTarget = p1.model:GetPivot().Position
		setShipFx(true)

		local v5 = math.clamp(t.progress, 0, 1)

		t.ui.fill.Size = UDim2.fromScale(if t.ui.template then v5 * 0.85 + 0.15 else v5, 1)

		local CurrentCamera = Workspace.CurrentCamera

		if not CurrentCamera or v15 then
			showCatchAlert()

			return
		end

		v15 = true
		v16 = nil
		CurrentCamera.CameraType = Enum.CameraType.Scriptable
		showCatchAlert()
	else
		AlienFlightState.fighting = false

		if v1.template then
			local root = v1.root

			if root:IsA("GuiObject") then
				popInGui(root, false)
			end

			if v1.clickFast then
				popInGui(v1.clickFast.frame, false)
			end
		else
			v1.root:Destroy()
		end

		p1.beingCaught = false
	end
end

local v18 = false

local function beamReach(p1, p2) --[[ beamReach | Line: 1406 | Upvalues: Catch (copy) ]]
	if math.abs(p1.Y - p2.Y) > Catch.BeamHeight then
		return nil
	end

	local Magnitude = Vector2.new(p1.X - p2.X, p1.Z - p2.Z).Magnitude

	if Magnitude <= Catch.BeamRange then
		return Magnitude
	end

	return nil
end

local function tryCatch(p1) --[[ tryCatch | Line: 1416 | Upvalues: v8 (ref), v18 (ref), AlienFlightState (copy), Catch (copy), notifications (copy), ClientPlayerData (copy), EventId (copy), AlienEventConfig (copy), Remotes (copy), t3 (copy), RunService (copy), startFight (copy), Debug (copy) ]]
	if v8 or (v18 or (not AlienFlightState.inFlight or p1.beingCaught)) then
		return
	end

	local shipModel = AlienFlightState.shipModel
	local v1 = if shipModel then shipModel:GetPivot().Position else nil

	if not v1 then
		return
	end

	local Position = p1.model:GetPivot().Position
	local v3

	if math.abs(Position.Y - v1.Y) > Catch.BeamHeight then
		v3 = nil
	else
		local Magnitude = Vector2.new(Position.X - v1.X, Position.Z - v1.Z).Magnitude

		v3 = if Magnitude <= Catch.BeamRange then Magnitude else nil
	end

	if not v3 then
		notifications:Send("Fly closer to the fish!")

		return
	end

	local v4 = ClientPlayerData.serverProfile:getState()
	local v5 = v4.events and v4.events[EventId]
	local v6 = if v5 then v5.cargo else v5
	local v82 = ClientPlayerData.serverProfile:getState()
	local v9 = v82.events and v82.events[EventId]

	if (AlienEventConfig.GetUpgradeValue("CargoSlots", v9 and v9.upgrades and v9.upgrades.CargoSlots or 0) or 0) <= (if v6 then #v6 else 0) then
		notifications:Send("You can\'t carry more \226\128\148 drop them off at the depot!")
	else
		p1.beingCaught = true
		v18 = true
		task.spawn(function() --[[ Line: 1443 | Upvalues: Remotes (ref), p1 (copy), v18 (ref), notifications (ref), t3 (ref), RunService (ref), AlienFlightState (ref), startFight (ref), Debug (ref), v8 (ref) ]]
			local v1, v2 = Remotes.AlienCatchStart:Call(p1.id):Await()

			v18 = false

			local v3 = if v1 and type(v2) == "table" then v2 else nil

			if v3 and v3.Ok == true then
				if not AlienFlightState.inFlight or t3[p1.id] ~= p1 then
					p1.beingCaught = false

					return
				end

				startFight(p1)

				if not (RunService:IsStudio() and Debug.InstantCatch) then
					return
				end

				local v4 = v8

				if not v4 or v4.fish ~= p1 then
					return
				end

				v4.progress = 1
			else
				p1.beingCaught = false

				if v3 and type(v3.Message) == "string" then
					notifications:Send(v3.Message)
				else
					notifications:Send("Couldn\'t grab the fish. Try again!")
				end

				if not v3 or v3.Gone ~= true then
					return
				end

				local v5 = p1

				if t3[v5.id] ~= v5 then
					return
				end

				t3[v5.id] = nil

				local model = v5.model

				task.spawn(function() --[[ Line: 425 | Upvalues: model (copy), RunService (ref) ]]
					local v1 = model:GetPivot()
					local sum2 = 0

					while sum2 < 0.35 and model.Parent do
						sum2 = sum2 + RunService.Heartbeat:Wait()

						local v2 = math.clamp(sum2 / 0.35, 0, 1)

						model:PivotTo(v1 * CFrame.new(0, v2 * -6 * v2, 0))
					end

					model:Destroy()
				end)
			end
		end)
	end
end

local v19 = nil
local v20 = nil
local v21 = nil

local function getCrosshair() --[[ getCrosshair | Line: 1488 | Upvalues: v19 (ref), Players (copy), v1 (copy) ]]
	local v12 = v19

	if v12 and v12.Parent then
		return v12
	end

	local AlienCrosshair = Instance.new("ScreenGui")

	AlienCrosshair.Name = "AlienCrosshair"
	AlienCrosshair.ResetOnSpawn = false
	AlienCrosshair.DisplayOrder = 55
	AlienCrosshair.Enabled = false
	AlienCrosshair.Parent = Players.LocalPlayer:WaitForChild("PlayerGui")

	local TextLabel = Instance.new("TextLabel")

	TextLabel.AnchorPoint = Vector2.new(0.5, 0.5)
	TextLabel.Position = UDim2.fromScale(0.5, 0.5)
	TextLabel.Size = UDim2.fromOffset(40, 40)
	TextLabel.BackgroundTransparency = 1
	TextLabel.Font = Enum.Font.GothamBlack
	TextLabel.TextSize = 32
	TextLabel.TextColor3 = v1
	TextLabel.TextStrokeTransparency = 0.4
	TextLabel.Text = "+"
	TextLabel.Parent = AlienCrosshair
	v19 = AlienCrosshair

	return AlienCrosshair
end

local function getHighlight() --[[ getHighlight | Line: 1516 | Upvalues: v21 (ref), v1 (copy), v6 (ref), Spawn (copy), Workspace (copy) ]]
	local v12 = v21

	if v12 and v12.Parent then
		return v12
	end

	local AlienFishTarget = Instance.new("Highlight")

	AlienFishTarget.Name = "AlienFishTarget"
	AlienFishTarget.FillColor = v1
	AlienFishTarget.FillTransparency = 0.75
	AlienFishTarget.OutlineColor = v1
	AlienFishTarget.OutlineTransparency = 0
	AlienFishTarget.Enabled = false

	local v2 = v6
	local v3

	if v2 and v2.Parent then
		v3 = v2
	else
		local v4 = Instance.new("Folder")

		v4.Name = Spawn.ClientFishFolderName
		v4.Parent = Workspace
		v6 = v4
		v3 = v4
	end

	AlienFishTarget.Parent = v3
	v21 = AlienFishTarget

	return AlienFishTarget
end

local function isGamepadActive() --[[ isGamepadActive | Line: 1541 | Upvalues: UserInputService (copy) ]]
	local v1 = UserInputService:GetLastInputType()

	return if v1 == Enum.UserInputType.Gamepad1 or (v1 == Enum.UserInputType.Gamepad2 or v1 == Enum.UserInputType.Gamepad3) then true else v1 == Enum.UserInputType.Gamepad4
end

local function pickTarget() --[[ pickTarget | Line: 1559 | Upvalues: Workspace (copy), AlienFlightState (copy), t3 (copy), Catch (copy), v20 (ref) ]]
	local CurrentCamera = Workspace.CurrentCamera
	local shipModel = AlienFlightState.shipModel
	local v1 = if shipModel then shipModel:GetPivot().Position else nil

	if not (CurrentCamera and v1) then
		return nil
	end

	local Position = CurrentCamera.CFrame.Position
	local LookVector = CurrentCamera.CFrame.LookVector
	local v2 = (1 / 0)
	local v3 = 0.9
	local v4 = nil
	local v5 = nil

	for v7, v8 in t3 do
		local v6

		if not v8.beingCaught then
			local Position2 = v8.model:GetPivot().Position

			if math.abs(Position2.Y - v1.Y) > Catch.BeamHeight then
				v6 = nil
			else
				local Magnitude = Vector2.new(Position2.X - v1.X, Position2.Z - v1.Z).Magnitude

				v6 = if Magnitude <= Catch.BeamRange then Magnitude else nil
			end

			if v6 then
				if v6 < v2 then
					v2 = v6
					v5 = v8
				end

				local v10 = Position2 - Position

				if v10.Magnitude > 0.01 then
					local v11 = LookVector:Dot(v10.Unit)

					if v3 < v11 then
						v3 = v11
						v4 = v8
					end
				end
			end
		end
	end

	if v4 then
		return v4
	end

	local v12 = v20

	if v12 and (not v12.beingCaught and v12.model.Parent) then
		local Position2 = v12.model:GetPivot().Position
		local v14

		if math.abs(Position2.Y - v1.Y) > Catch.BeamHeight then
			v14 = nil
		else
			local Magnitude = Vector2.new(Position2.X - v1.X, Position2.Z - v1.Z).Magnitude

			v14 = if Magnitude <= Catch.BeamRange then Magnitude else nil
		end

		if v14 and v14 <= v2 * 1.25 then
			return v12
		end
	end

	return v5
end

local function requestCatch() --[[ requestCatch | Line: 1617 | Upvalues: v20 (ref), tryCatch (copy) ]]
	local v1 = v20

	if not v1 then
		return
	end

	tryCatch(v1)
end

local function updateTargeting() --[[ updateTargeting | Line: 1626 | Upvalues: AlienFlightState (copy), v8 (ref), getCrosshair (copy), UserInputService (copy), pickTarget (copy), v20 (ref), v21 (ref), v1 (copy), v6 (ref), Spawn (copy), Workspace (copy) ]]
	local v12 = AlienFlightState.inFlight and v8 == nil
	local v2 = getCrosshair()
	local v3

	if v12 then
		local v4 = UserInputService:GetLastInputType()

		v3 = if v4 == Enum.UserInputType.Gamepad1 or (v4 == Enum.UserInputType.Gamepad2 or v4 == Enum.UserInputType.Gamepad3) then true else v4 == Enum.UserInputType.Gamepad4
	else
		v3 = v12
	end

	if v2.Enabled ~= v3 then
		v2.Enabled = v3
	end

	local v5 = if v12 then pickTarget() else nil

	if v8 == nil then
		AlienFlightState.fightTarget = if v5 then v5.model:GetPivot().Position else nil
	end

	if v5 == v20 then
		return
	end

	v20 = v5

	local v82 = v21
	local v9

	if v82 and v82.Parent then
		v9 = v82
	else
		local AlienFishTarget = Instance.new("Highlight")

		AlienFishTarget.Name = "AlienFishTarget"
		AlienFishTarget.FillColor = v1
		AlienFishTarget.FillTransparency = 0.75
		AlienFishTarget.OutlineColor = v1
		AlienFishTarget.OutlineTransparency = 0
		AlienFishTarget.Enabled = false

		local v10 = v6
		local v11

		if v10 and v10.Parent then
			v11 = v10
		else
			local v122 = Instance.new("Folder")

			v122.Name = Spawn.ClientFishFolderName
			v122.Parent = Workspace
			v6 = v122
			v11 = v122
		end

		AlienFishTarget.Parent = v11
		v21 = AlienFishTarget
		v9 = AlienFishTarget
	end

	v9.Adornee = if v5 then v5.model else nil
	v9.Enabled = v5 ~= nil
end

local v22 = nil
local v23 = false
local v24 = false
local v25 = nil
local v26 = false

local function hideIslandBeam() --[[ hideIslandBeam | Line: 1694 | Upvalues: v26 (ref), BeamTo (copy) ]]
	if v26 then
		v26 = false
		BeamTo(nil)
	end
end

local function destroyIslandBeam() --[[ destroyIslandBeam | Line: 1703 | Upvalues: v26 (ref), BeamTo (copy), v25 (ref) ]]
	if v26 then
		v26 = false
		BeamTo(nil)
	end

	local v1 = v25

	v25 = nil

	if not v1 then
		return
	end

	v1:Destroy()
end

local function buildIslandBeam() --[[ buildIslandBeam | Line: 1712 | Upvalues: v26 (ref), v25 (ref), AlienFlightState (copy), Workspace (copy), BeamTo (copy) ]]
	if v26 then
		return
	end

	local v1 = v25

	if not v1 then
		local oceanCenter = AlienFlightState.oceanCenter

		if not oceanCenter then
			return
		end

		local AlienIslandBeamAnchor = Instance.new("Part")

		AlienIslandBeamAnchor.Name = "AlienIslandBeamAnchor"
		AlienIslandBeamAnchor.Anchored = true
		AlienIslandBeamAnchor.CanCollide = false
		AlienIslandBeamAnchor.CanQuery = false
		AlienIslandBeamAnchor.CanTouch = false
		AlienIslandBeamAnchor.Transparency = 1
		AlienIslandBeamAnchor.Size = Vector3.new(1, 1, 1)
		AlienIslandBeamAnchor.CFrame = CFrame.new(oceanCenter)
		AlienIslandBeamAnchor.Parent = Workspace
		v25 = AlienIslandBeamAnchor
		v1 = AlienIslandBeamAnchor
	end

	v26 = true
	BeamTo(v1)
end

local t8 = {}
local v27 = nil

local function addDepotSign(p1) --[[ addDepotSign | Line: 1765 | Upvalues: Workspace (copy), t8 (copy), v27 (ref) ]]
	if p1:IsA("Model") and (p1:IsDescendantOf(Workspace) and not t8[p1]) then
		local v1 = p1:GetPivot()

		t8[p1] = {
			authored = v1,
			authoredHeading = v27(v1.LookVector),
			current = v1,
			target = v1
		}
	end
end

local function restoreDepotSigns() --[[ restoreDepotSigns | Line: 1780 | Upvalues: t8 (copy) ]]
	for v1, v2 in t8 do
		if v1.Parent then
			v1:PivotTo(v2.authored)
			v2.current = v2.authored
			v2.target = v2.authored

			continue
		end

		t8[v1] = nil
	end
end

v27 = function(p1) --[[ flatHeading | Line: 1793 ]]
	local v1 = Vector3.new(p1.X, 0, p1.Z)

	if v1.Magnitude < 0.001 then
		return nil
	end

	return math.atan2(v1.X, v1.Z)
end

local function stepDepotSigns(p1) --[[ stepDepotSigns | Line: 1801 | Upvalues: AlienFlightState (copy), DepotSign (copy), t8 (copy) ]]
	local shipModel = AlienFlightState.shipModel
	local v1 = if shipModel then shipModel:GetPivot().Position else nil

	if not v1 then
		return
	end

	local v3 = 1 - math.exp(-DepotSign.TurnSmoothing * p1)
	local v4 = math.rad(DepotSign.YawOffset)

	for v5, v6 in t8 do
		if v5.Parent then
			local Position = v6.authored.Position
			local v9 = Vector3.new(v1.X - Position.X, 0, v1.Z - Position.Z)
			local authoredHeading = v6.authoredHeading

			if v9.Magnitude >= DepotSign.MinDistance and authoredHeading then
				local v10 = math.atan2(v9.X, v9.Z) - authoredHeading + v4

				v6.target = CFrame.new(Position) * CFrame.Angles(0, v10, 0) * v6.authored.Rotation
			end

			v6.current = v6.current:Lerp(v6.target, v3)
			v5:PivotTo(v6.current)

			continue
		end

		t8[v5] = nil
	end
end

local v28 = nil

local function destroyCarryBillboard() --[[ destroyCarryBillboard | Line: 1839 | Upvalues: v28 (ref) ]]
	local v1 = v28

	v28 = nil

	if not v1 then
		return
	end

	v1.gui:Destroy()
end

local function updateCarryBillboard(p1, p2) --[[ updateCarryBillboard | Line: 1847 | Upvalues: AlienFlightState (copy), v28 (ref) ]]
	local shipModel = AlienFlightState.shipModel
	local v1 = if shipModel then shipModel.PrimaryPart else shipModel

	if v1 and not (p1 <= 0) then
		local v2 = v28

		if not v2 or v2.gui.Adornee ~= v1 then
			local v3 = v28

			v28 = nil

			if v3 then
				v3.gui:Destroy()
			end

			local AlienCarryBillboard = Instance.new("BillboardGui")

			AlienCarryBillboard.Name = "AlienCarryBillboard"
			AlienCarryBillboard.Adornee = v1
			AlienCarryBillboard.StudsOffsetWorldSpace = Vector3.new(0, 10, 0)
			AlienCarryBillboard.Size = UDim2.fromScale(9, 2.2)
			AlienCarryBillboard.MaxDistance = 400
			AlienCarryBillboard.ResetOnSpawn = false

			local TextLabel = Instance.new("TextLabel")

			TextLabel.Size = UDim2.fromScale(1, 1)
			TextLabel.BackgroundTransparency = 1
			TextLabel.Font = Enum.Font.GothamBlack
			TextLabel.TextScaled = true
			TextLabel.TextColor3 = Color3.new(255/255, 255/255, 255/255)
			TextLabel.Parent = AlienCarryBillboard

			local UIStroke = Instance.new("UIStroke")

			UIStroke.Color = Color3.new(0/255, 0/255, 0/255)
			UIStroke.Thickness = 2
			UIStroke.Parent = TextLabel
			AlienCarryBillboard.Parent = v1

			local t = {
				gui = AlienCarryBillboard,
				label = TextLabel
			}

			v28 = t
			v2 = t
		end

		v2.label.Text = ("Fish %*/%*"):format(p1, p2)
		v2.label.TextColor3 = if p2 <= p1 then Color3.fromRGB(255, 210, 90) else Color3.new(255/255, 255/255, 255/255)
	else
		local v5 = v28

		v28 = nil

		if not v5 then
			return
		end

		v5.gui:Destroy()
	end
end

local function destroyCargoHud() --[[ destroyCargoHud | Line: 1894 | Upvalues: v22 (ref), ContextActionService (copy) ]]
	local v1 = v22

	v22 = nil

	if not v1 then
		return
	end

	v1.unloadConn:Disconnect()

	if v1.catchConn then
		v1.catchConn:Disconnect()
	end

	if v1.catchHint then
		v1.catchHint:Destroy()
	end

	if v1.unloadHint then
		v1.unloadHint:Destroy()
	end

	pcall(function() --[[ Line: 1912 | Upvalues: ContextActionService (ref) ]]
		ContextActionService:UnbindAction("AlienOcean_Catch")
		ContextActionService:UnbindAction("AlienOcean_Unload")
	end)

	if v1.template then
		v1.unloadButton.Visible = false

		if v1.catchButton then
			v1.catchButton.Visible = false
		end
	else
		v1.root:Destroy()
	end
end

local v29 = false

local function playCameraPunch() --[[ playCameraPunch | Line: 1937 | Upvalues: Workspace (copy), v29 (ref), TweenService (copy) ]]
	local CurrentCamera = Workspace.CurrentCamera

	if CurrentCamera and not v29 then
		v29 = true

		local FieldOfView = CurrentCamera.FieldOfView

		task.spawn(function() --[[ Line: 1944 | Upvalues: TweenService (ref), CurrentCamera (copy), FieldOfView (copy), v29 (ref) ]]
			local v1 = TweenService:Create(CurrentCamera, TweenInfo.new(0.12, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
				FieldOfView = FieldOfView + 9
			})

			v1:Play()
			v1.Completed:Wait()

			local v2 = TweenService:Create(CurrentCamera, TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				FieldOfView = FieldOfView
			})

			v2:Play()
			v2.Completed:Wait()
			v29 = false
		end)
	end
end

local function playUnloadDrop(p1) --[[ playUnloadDrop | Line: 1963 | Upvalues: AlienFlightState (copy), Workspace (copy), v29 (ref), TweenService (copy), SFX (copy), Catch (copy), v6 (ref), Spawn (copy), Players (copy), t6 (copy), buildMiniFish (copy), RunService (copy), t7 (copy) ]]
	local shipModel = AlienFlightState.shipModel

	if not shipModel then
		return
	end

	local Position = shipModel:GetPivot().Position
	local CurrentCamera = Workspace.CurrentCamera

	if CurrentCamera and not v29 then
		v29 = true

		local FieldOfView = CurrentCamera.FieldOfView

		task.spawn(function() --[[ Line: 1944 | Upvalues: TweenService (ref), CurrentCamera (copy), FieldOfView (copy), v29 (ref) ]]
			local v1 = TweenService:Create(CurrentCamera, TweenInfo.new(0.12, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
				FieldOfView = FieldOfView + 9
			})

			v1:Play()
			v1.Completed:Wait()

			local v2 = TweenService:Create(CurrentCamera, TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				FieldOfView = FieldOfView
			})

			v2:Play()
			v2.Completed:Wait()
			v29 = false
		end)
	end

	SFX.new(SFX.Sounds.AlienFishDrop, Catch.DropSoundVolume)

	local v1 = RaycastParams.new()

	v1.FilterType = Enum.RaycastFilterType.Exclude

	local t = {}
	local v2 = v6
	local v3

	if v2 and v2.Parent then
		v3 = v2
	else
		local v4 = Instance.new("Folder")

		v4.Name = Spawn.ClientFishFolderName
		v4.Parent = Workspace
		v6 = v4
		v3 = v4
	end

	t[1] = v3
	t[2] = shipModel

	local Character = Players.LocalPlayer.Character

	if Character then
		table.insert(t, Character)
	end

	for v5, v62 in t6 do
		table.insert(t, v62)
	end

	v1.FilterDescendantsInstances = t

	for v7, v8 in p1 do
		if v7 > 4 then
			break
		end

		task.spawn(function() --[[ Line: 1992 | Upvalues: Workspace (ref), Position (copy), v1 (copy), buildMiniFish (ref), v8 (copy), RunService (ref), t7 (ref) ]]
			local v3 = Vector3.new((math.random() - 0.5) * 22, 0, (math.random() - 0.5) * 22)
			local v4 = Workspace:Raycast(Position + v3 + Vector3.new(0, -4, 0), Vector3.new(0, -400, 0), v1)
			local v5 = if v4 then v4.Position + Vector3.new(0, 1, 0) else nil
			local v6 = buildMiniFish(v8, 7)

			v6.Name = ("Dropped_%*"):format(v8)
			v6:PivotTo(CFrame.new(Position))
			v6.Parent = Workspace

			local v7 = if v5 then v5.Y else Position.Y - 60
			local sum = 0

			while sum < 0.9 and v6.Parent do
				sum = sum + RunService.Heartbeat:Wait()

				local v82 = math.clamp(sum / 0.9, 0, 1)
				local v122 = Vector3.new(Position.X + v3.X * v82, Position.Y + (v7 - Position.Y) * v82 * v82, Position.Z + v3.Z * v82)

				v6:PivotTo(CFrame.new(v122) * CFrame.Angles(v82 * 5, v82 * 2.5, 0))
			end

			if v5 then
				v6:PivotTo(CFrame.new(v5.X, v7, v5.Z) * CFrame.Angles(0, math.random() * 2 * math.pi, 0))
				table.insert(t7, {
					model = v6,
					expiresAt = os.clock() + 30
				})
			else
				v6:Destroy()
			end
		end)
	end
end

local function requestUnload() --[[ requestUnload | Line: 2033 | Upvalues: v23 (ref), AlienFlightState (copy), ClientPlayerData (copy), EventId (copy), Remotes (copy), playUnloadDrop (copy), notifications (copy) ]]
	if v23 or not (AlienFlightState.inFlight and AlienFlightState.overIsland) then
		return
	end

	local v1 = ClientPlayerData.serverProfile:getState()
	local v2 = v1.events and v1.events[EventId]
	local v3 = if v2 then v2.cargo or {} else {}

	if #v3 ~= 0 then
		v23 = true

		local v4 = table.clone(v3)

		task.spawn(function() --[[ Line: 2044 | Upvalues: Remotes (ref), v23 (ref), playUnloadDrop (ref), v4 (copy), notifications (ref) ]]
			local v1, v2 = Remotes.AlienUnloadCargo:Call():Await()

			v23 = false

			if not v1 or (type(v2) ~= "table" or v2.Ok ~= true) then
				return
			end

			playUnloadDrop(v4)
			notifications:Send((("You got %* alien fish!"):format(v2.Count or #v4)))
		end)
	end
end

local function bindGamepadActions() --[[ bindGamepadActions | Line: 2060 | Upvalues: bindToButtonPress (copy), t2 (copy), v8 (ref), pumpFight (copy), v20 (ref), tryCatch (copy), requestUnload (copy) ]]
	bindToButtonPress("AlienOcean_Catch", t2.Catch, function() --[[ Line: 2061 | Upvalues: v8 (ref), pumpFight (ref), v20 (ref), tryCatch (ref) ]]
		if v8 then
			pumpFight()

			return
		end

		local v1 = v20

		if not v1 then
			return
		end

		tryCatch(v1)
	end)
	bindToButtonPress("AlienOcean_Unload", t2.Unload, requestUnload)
end

local function buildCargoHud() --[[ buildCargoHud | Line: 2074 | Upvalues: destroyCargoHud (copy), bindToButtonPress (copy), t2 (copy), v8 (ref), pumpFight (copy), v20 (ref), tryCatch (copy), requestUnload (copy), Players (copy), ControlHint (copy), v22 (ref) ]]
	destroyCargoHud()
	bindToButtonPress("AlienOcean_Catch", t2.Catch, function() --[[ Line: 2061 | Upvalues: v8 (ref), pumpFight (ref), v20 (ref), tryCatch (ref) ]]
		if v8 then
			pumpFight()

			return
		end

		local v1 = v20

		if not v1 then
			return
		end

		tryCatch(v1)
	end)
	bindToButtonPress("AlienOcean_Unload", t2.Unload, requestUnload)

	local PlayerGui = Players.LocalPlayer:FindFirstChildOfClass("PlayerGui")
	local v1 = if PlayerGui then PlayerGui:FindFirstChild("MainUI") else PlayerGui
	local v2 = if v1 then v1:FindFirstChild("UfoEvent") else v1
	local v3 = if v2 and v2:IsA("Frame") then v2 else nil
	local AlienCargoHud, Unload, v4, Catch, v5, v6, v7, v82

	if not v3 then
		AlienCargoHud = Instance.new("ScreenGui")
		AlienCargoHud.Name = "AlienCargoHud"
		AlienCargoHud.ResetOnSpawn = false
		AlienCargoHud.DisplayOrder = 50
		AlienCargoHud.Parent = Players.LocalPlayer:WaitForChild("PlayerGui")
		Unload = Instance.new("TextButton")
		Unload.Name = "Unload"
		Unload.AnchorPoint = Vector2.new(0.5, 1)
		Unload.Position = UDim2.new(0.5, 0, 1, -148)
		Unload.Size = UDim2.fromOffset(190, 48)
		Unload.BackgroundColor3 = Color3.fromRGB(70, 130, 220)
		Unload.Font = Enum.Font.GothamBlack
		Unload.TextSize = 20
		Unload.TextColor3 = Color3.new(255/255, 255/255, 255/255)
		Unload.Text = "Drop Off Fish"
		Unload.Visible = false
		Unload.Parent = AlienCargoHud
		v4 = Instance.new("UICorner")
		v4.CornerRadius = UDim.new(0, 10)
		v4.Parent = Unload
		Catch = Instance.new("TextButton")
		Catch.Name = "Catch"
		Catch.AnchorPoint = Vector2.new(0.5, 1)
		Catch.Position = UDim2.new(0.5, 0, 1, -204)
		Catch.Size = UDim2.fromOffset(210, 54)
		Catch.BackgroundColor3 = Color3.fromRGB(60, 190, 120)
		Catch.Font = Enum.Font.GothamBlack
		Catch.TextSize = 22
		Catch.TextColor3 = Color3.new(255/255, 255/255, 255/255)
		Catch.Text = "Catch Fish"
		Catch.Visible = false
		Catch.Parent = AlienCargoHud
		v5 = Instance.new("UICorner")
		v5.CornerRadius = UDim.new(0, 10)
		v5.Parent = Catch
		v6 = Instance.new("UIStroke")
		v6.Color = Color3.fromRGB(20, 90, 55)
		v6.Thickness = 2
		v6.Parent = Catch
		v7 = Instance.new("UIStroke")
		v7.Color = Color3.fromRGB(25, 60, 120)
		v7.Thickness = 2
		v7.Parent = Unload
		v82 = {
			template = false,
			root = AlienCargoHud,
			unloadButton = Unload,
			catchButton = Catch,
			catchHint = ControlHint.new({
				label = "Catch",
				anchorTo = Catch,
				keyCode = t2.Catch
			}),
			unloadHint = ControlHint.new({
				label = "Drop Off",
				anchorTo = Unload,
				keyCode = t2.Unload
			}),
			catchConn = Catch.Activated:Connect(function() --[[ Line: 2184 | Upvalues: v20 (ref), tryCatch (ref) ]]
				local v1 = v20

				if not v1 then
					return
				end

				tryCatch(v1)
			end),
			unloadConn = Unload.Activated:Connect(requestUnload)
		}
		v22 = v82

		return v82
	end

	local FishCapacity = v3:FindFirstChild("FishCapacity")

	if FishCapacity and FishCapacity:IsA("GuiObject") then
		FishCapacity.Visible = false
	end

	local DropFishButton = v3:FindFirstChild("DropFishButton")
	local CatchButton = v3:FindFirstChild("CatchButton")

	if DropFishButton and (DropFishButton:IsA("GuiButton") and (CatchButton and CatchButton:IsA("GuiButton"))) then
		DropFishButton.Visible = false
		DropFishButton.Active = true
		CatchButton.Visible = false
		CatchButton.Active = true

		local t = {
			template = true,
			root = v3,
			unloadButton = DropFishButton,
			catchButton = CatchButton,
			catchConn = CatchButton.Activated:Connect(function() --[[ Line: 2107 | Upvalues: v20 (ref), tryCatch (ref) ]]
				local v1 = v20

				if not v1 then
					return
				end

				tryCatch(v1)
			end),
			catchHint = ControlHint.new({
				label = "Catch",
				anchorTo = CatchButton,
				keyCode = t2.Catch
			}),
			unloadHint = ControlHint.new({
				label = "Drop Off",
				anchorTo = DropFishButton,
				keyCode = t2.Unload
			}),
			unloadConn = DropFishButton.Activated:Connect(requestUnload)
		}

		v22 = t

		return t
	end

	warn("[AlienOceanFishing] MainUI.UfoEvent is missing DropFishButton/CatchButton \226\128\148 using the code-built cargo HUD")
	AlienCargoHud = Instance.new("ScreenGui")
	AlienCargoHud.Name = "AlienCargoHud"
	AlienCargoHud.ResetOnSpawn = false
	AlienCargoHud.DisplayOrder = 50
	AlienCargoHud.Parent = Players.LocalPlayer:WaitForChild("PlayerGui")
	Unload = Instance.new("TextButton")
	Unload.Name = "Unload"
	Unload.AnchorPoint = Vector2.new(0.5, 1)
	Unload.Position = UDim2.new(0.5, 0, 1, -148)
	Unload.Size = UDim2.fromOffset(190, 48)
	Unload.BackgroundColor3 = Color3.fromRGB(70, 130, 220)
	Unload.Font = Enum.Font.GothamBlack
	Unload.TextSize = 20
	Unload.TextColor3 = Color3.new(255/255, 255/255, 255/255)
	Unload.Text = "Drop Off Fish"
	Unload.Visible = false
	Unload.Parent = AlienCargoHud
	v4 = Instance.new("UICorner")
	v4.CornerRadius = UDim.new(0, 10)
	v4.Parent = Unload
	Catch = Instance.new("TextButton")
	Catch.Name = "Catch"
	Catch.AnchorPoint = Vector2.new(0.5, 1)
	Catch.Position = UDim2.new(0.5, 0, 1, -204)
	Catch.Size = UDim2.fromOffset(210, 54)
	Catch.BackgroundColor3 = Color3.fromRGB(60, 190, 120)
	Catch.Font = Enum.Font.GothamBlack
	Catch.TextSize = 22
	Catch.TextColor3 = Color3.new(255/255, 255/255, 255/255)
	Catch.Text = "Catch Fish"
	Catch.Visible = false
	Catch.Parent = AlienCargoHud
	v5 = Instance.new("UICorner")
	v5.CornerRadius = UDim.new(0, 10)
	v5.Parent = Catch
	v6 = Instance.new("UIStroke")
	v6.Color = Color3.fromRGB(20, 90, 55)
	v6.Thickness = 2
	v6.Parent = Catch
	v7 = Instance.new("UIStroke")
	v7.Color = Color3.fromRGB(25, 60, 120)
	v7.Thickness = 2
	v7.Parent = Unload
	v82 = {
		template = false,
		root = AlienCargoHud,
		unloadButton = Unload,
		catchButton = Catch,
		catchHint = ControlHint.new({
			label = "Catch",
			anchorTo = Catch,
			keyCode = t2.Catch
		}),
		unloadHint = ControlHint.new({
			label = "Drop Off",
			anchorTo = Unload,
			keyCode = t2.Unload
		}),
		catchConn = Catch.Activated:Connect(function() --[[ Line: 2184 | Upvalues: v20 (ref), tryCatch (ref) ]]
			local v1 = v20

			if not v1 then
				return
			end

			tryCatch(v1)
		end),
		unloadConn = Unload.Activated:Connect(requestUnload)
	}
	v22 = v82

	return v82
end

local function updateCargoHud() --[[ updateCargoHud | Line: 2194 | Upvalues: v22 (ref), ClientPlayerData (copy), EventId (copy), AlienEventConfig (copy), updateCarryBillboard (copy), AlienFlightState (copy), v23 (ref), popInGui (copy), v20 (ref), v8 (ref), buildIslandBeam (copy), v26 (ref), BeamTo (copy), v24 (ref), notifications (copy) ]]
	local v1 = v22

	if not v1 then
		return
	end

	local v2 = ClientPlayerData.serverProfile:getState()
	local v3 = v2.events and v2.events[EventId]
	local v4 = if v3 then v3.cargo else v3
	local v5 = if v4 then #v4 else 0
	local v6 = ClientPlayerData.serverProfile:getState()
	local v7 = v6.events and v6.events[EventId]
	local v9 = AlienEventConfig.GetUpgradeValue("CargoSlots", v7 and v7.upgrades and v7.upgrades.CargoSlots or 0) or 0

	updateCarryBillboard(v5, v9)

	local v10 = AlienFlightState.overIsland and (if v5 > 0 then not v23 else false)

	popInGui(v1.unloadButton, v10)

	local v11 = if v20 == nil then false else v8 == nil

	AlienFlightState.catchAvailable = v11

	if v1.catchButton then
		popInGui(v1.catchButton, v11)
	end

	local catchHint = v1.catchHint

	if catchHint and v11 then
		catchHint:Show()
	elseif catchHint then
		catchHint:Hide()
	end

	local unloadHint = v1.unloadHint

	if unloadHint and v10 then
		unloadHint:Show()
	elseif unloadHint then
		unloadHint:Hide()
	end

	if v9 <= v5 and not AlienFlightState.overIsland then
		buildIslandBeam()
	elseif v26 then
		v26 = false
		BeamTo(nil)
	end

	if v9 <= v5 then
		if not v24 then
			v24 = true
			notifications:Send("You can\'t carry more \226\128\148 drop them off at the depot!")
		end
	else
		v24 = false
	end
end

local function stepFish(p1) --[[ stepFish | Line: 2256 | Upvalues: Workspace (copy), v8 (ref), t3 (copy), AlienFlightState (copy), Minigame (copy), pullTargetPosition (copy), RunService (copy), Swim (copy) ]]
	local v1 = Workspace:GetServerTimeNow()
	local v2 = v8

	for v3, v4 in t3 do
		if v4.beingCaught then
			if v2 and v2.fish == v4 then
				local shipModel = AlienFlightState.shipModel
				local v5 = if shipModel then shipModel:GetPivot().Position else nil

				if v5 then
					local v82 = math.clamp((v2.progress - Minigame.StartProgress) / (1 - Minigame.StartProgress), 0, 1)
					local v11 = math.clamp(v82 * 0.85 + math.min(v2.elapsed / 8, 1) * 0.2, 0, 1)
					local v13 = v2.pullFrom:Lerp(pullTargetPosition() or v5 - Vector3.new(0, 8, 0), v11)

					AlienFlightState.fightTarget = v13

					local v16 = Vector3.new(math.noise(v4.phase, os.clock() * 8) * 1.2, 0, math.noise(os.clock() * 8, v4.phase) * 1.2)

					v4.model:PivotTo(CFrame.new(v13 + v16) * CFrame.Angles(0, v4.yaw, 0))
				end
			end

			continue
		end

		if v4.expiresAt <= v1 then
			if t3[v4.id] == v4 then
				t3[v4.id] = nil

				local model = v4.model

				task.spawn(function() --[[ Line: 425 | Upvalues: model (copy), RunService (ref) ]]
					local v1 = model:GetPivot()
					local sum2 = 0

					while sum2 < 0.35 and model.Parent do
						sum2 = sum2 + RunService.Heartbeat:Wait()

						local v2 = math.clamp(sum2 / 0.35, 0, 1)

						model:PivotTo(v1 * CFrame.new(0, v2 * -6 * v2, 0))
					end

					model:Destroy()
				end)
			end

			continue
		end

		local v17 = os.clock() * Swim.Wander
		local v19 = Vector3.new(math.noise(v17, v4.phase), 0, math.noise(v4.phase, v17)) * (Swim.Radius * 2)

		if v19.Magnitude > Swim.Radius then
			v19 = v19.Unit * Swim.Radius
		end

		local v22 = v4.basePosition + v19 + Vector3.new(0, math.sin((os.clock() + v4.phase) * 6.283185307179586 / 2.6) * 0.7, 0)
		local v23 = v22 - v4.swimPosition
		local v24 = Vector3.new(v23.X, 0, v23.Z)

		if v24.Magnitude > 0.005 then
			local v27 = math.atan2(-v24.X, -v24.Z)
			local v28 = (v27 + math.rad(Swim.YawOffset) - v4.yaw + math.pi) % 6.283185307179586 - math.pi

			v4.yaw = v4.yaw + v28 * (1 - math.exp(-Swim.TurnSmoothing * p1))
		else
			v4.yaw = v4.yaw + v4.yawSpeed * p1
		end

		v4.swimPosition = v22
		v4.model:PivotTo(CFrame.new(v22) * CFrame.Angles(0, v4.yaw, 0))

		local v32 = math.max(math.floor(v4.expiresAt - v1), 0)

		if v32 ~= v4.lastSeconds then
			v4.lastSeconds = v32

			local timerLabel = v4.timerLabel

			if timerLabel then
				timerLabel.Text = ("%*s"):format(v32)
			end
		end
	end
end

local function stepFight(p1) --[[ stepFight | Line: 2335 | Upvalues: v8 (ref), updateFightCamera (copy), AlienFlightState (copy), verifyShipFx (copy), Remotes (copy), teardownFight (copy), t3 (copy), RunService (copy), pullTargetPosition (copy), CollectFishUI (copy), SFX (copy), AlienOceanConfig (copy), ClientPlayerData (copy), EventId (copy), AlienEventConfig (copy), notifications (copy), Minigame (copy) ]]
	local v1 = v8

	if not v1 then
		return
	end

	updateFightCamera(v1, p1)
	AlienFlightState.fightTarget = v1.fish.model:GetPivot().Position
	verifyShipFx()

	if v1.finishing then
		return
	end

	v1.elapsed = v1.elapsed + p1

	if v1.progress >= 1 then
		local v2 = math.clamp(v1.progress, 0, 1)

		v1.ui.fill.Size = UDim2.fromScale(if v1.ui.template then v2 * 0.85 + 0.15 else v2, 1)

		local v4 = v8

		if not v4 then
			return
		end

		if v4.finishing then
			return
		end

		v4.finishing = true

		local v5 = true

		task.spawn(function() --[[ Line: 1088 | Upvalues: v4 (copy), Remotes (ref), v5 (copy), teardownFight (ref), v8 (ref), t3 (ref), RunService (ref), AlienFlightState (ref), pullTargetPosition (ref), CollectFishUI (ref), SFX (ref), AlienOceanConfig (ref), ClientPlayerData (ref), EventId (ref), AlienEventConfig (ref), notifications (ref) ]]
			local fish = v4.fish
			local v12, v2 = Remotes.AlienCatchFinish:Call({
				Id = fish.id,
				Success = v5,
				Rejected = v4.rejectedPumps
			}):Await()

			teardownFight(v4)

			if v8 == v4 then
				v8 = nil
			end

			fish.beingCaught = false

			local v3 = if v12 and type(v2) == "table" then v2 else nil

			if v5 and (if v3 == nil or v3.Ok ~= true then false elseif v3.Caught == true then true else false) then
				t3[fish.id] = nil

				local model = fish.model

				task.spawn(function() --[[ Line: 1061 | Upvalues: model (copy), RunService (ref), AlienFlightState (ref), pullTargetPosition (ref) ]]
					local v1 = model:GetPivot()
					local v2 = model:GetScale()
					local sum2 = 0

					while sum2 < 0.4 and model.Parent do
						sum2 = sum2 + RunService.Heartbeat:Wait()

						local v3 = math.clamp(sum2 / 0.4, 0, 1)
						local shipModel = AlienFlightState.shipModel
						local v4 = if shipModel then shipModel:GetPivot().Position else v1.Position

						model:PivotTo(CFrame.new(v1.Position:Lerp(pullTargetPosition() or v4, v3 * v3)) * v1.Rotation)
						model:ScaleTo((math.max(v2 * (1 - v3 * 0.9), 0.05)))
					end

					model:Destroy()
				end)
				CollectFishUI.play(fish.kind)

				return
			end

			if t3[fish.id] == fish then
				t3[fish.id] = nil

				local model = fish.model

				task.spawn(function() --[[ Line: 425 | Upvalues: model (copy), RunService (ref) ]]
					local v1 = model:GetPivot()
					local sum2 = 0

					while sum2 < 0.35 and model.Parent do
						sum2 = sum2 + RunService.Heartbeat:Wait()

						local v2 = math.clamp(sum2 / 0.35, 0, 1)

						model:PivotTo(v1 * CFrame.new(0, v2 * -6 * v2, 0))
					end

					model:Destroy()
				end)
			end

			SFX.new(SFX.Sounds.Poof, 0.4)

			local v52 = if v3 then if type(v3.Message) == "string" then v3.Message else nil else nil

			if not v52 then
				local v62 = ClientPlayerData.serverProfile:getState()
				local v72 = v62.events and v62.events[EventId]

				if AlienOceanConfig.IsHopeless(fish.strength, AlienEventConfig.GetUpgradeValue("ShipPower", v72 and v72.upgrades and v72.upgrades.ShipPower or 0) or 0) then
					v52 = "Too strong! Upgrade your Ship Power."
				end
			end

			notifications:Send(v52 or "The fish got away!")
		end)
	else
		v1.progress = v1.progress - v1.drainPerSecond * p1

		local v6 = math.clamp(v1.progress, 0, 1)

		v1.ui.fill.Size = UDim2.fromScale(if v1.ui.template then v6 * 0.85 + 0.15 else v6, 1)

		if not (v1.progress <= 0 or v1.elapsed >= Minigame.FightTimeout) then
			return
		end

		local v82 = v8

		if not v82 then
			return
		end

		if v82.finishing then
			return
		end

		v82.finishing = true

		local v9 = false

		task.spawn(function() --[[ Line: 1088 | Upvalues: v82 (copy), Remotes (ref), v9 (copy), teardownFight (ref), v8 (ref), t3 (ref), RunService (ref), AlienFlightState (ref), pullTargetPosition (ref), CollectFishUI (ref), SFX (ref), AlienOceanConfig (ref), ClientPlayerData (ref), EventId (ref), AlienEventConfig (ref), notifications (ref) ]]
			local fish = v82.fish
			local v12, v2 = Remotes.AlienCatchFinish:Call({
				Id = fish.id,
				Success = v9,
				Rejected = v82.rejectedPumps
			}):Await()

			teardownFight(v82)

			if v8 == v82 then
				v8 = nil
			end

			fish.beingCaught = false

			local v3 = if v12 and type(v2) == "table" then v2 else nil

			if v9 and (if v3 == nil or v3.Ok ~= true then false elseif v3.Caught == true then true else false) then
				t3[fish.id] = nil

				local model = fish.model

				task.spawn(function() --[[ Line: 1061 | Upvalues: model (copy), RunService (ref), AlienFlightState (ref), pullTargetPosition (ref) ]]
					local v1 = model:GetPivot()
					local v2 = model:GetScale()
					local sum2 = 0

					while sum2 < 0.4 and model.Parent do
						sum2 = sum2 + RunService.Heartbeat:Wait()

						local v3 = math.clamp(sum2 / 0.4, 0, 1)
						local shipModel = AlienFlightState.shipModel
						local v4 = if shipModel then shipModel:GetPivot().Position else v1.Position

						model:PivotTo(CFrame.new(v1.Position:Lerp(pullTargetPosition() or v4, v3 * v3)) * v1.Rotation)
						model:ScaleTo((math.max(v2 * (1 - v3 * 0.9), 0.05)))
					end

					model:Destroy()
				end)
				CollectFishUI.play(fish.kind)

				return
			end

			if t3[fish.id] == fish then
				t3[fish.id] = nil

				local model = fish.model

				task.spawn(function() --[[ Line: 425 | Upvalues: model (copy), RunService (ref) ]]
					local v1 = model:GetPivot()
					local sum2 = 0

					while sum2 < 0.35 and model.Parent do
						sum2 = sum2 + RunService.Heartbeat:Wait()

						local v2 = math.clamp(sum2 / 0.35, 0, 1)

						model:PivotTo(v1 * CFrame.new(0, v2 * -6 * v2, 0))
					end

					model:Destroy()
				end)
			end

			SFX.new(SFX.Sounds.Poof, 0.4)

			local v52 = if v3 then if type(v3.Message) == "string" then v3.Message else nil else nil

			if not v52 then
				local v62 = ClientPlayerData.serverProfile:getState()
				local v72 = v62.events and v62.events[EventId]

				if AlienOceanConfig.IsHopeless(fish.strength, AlienEventConfig.GetUpgradeValue("ShipPower", v72 and v72.upgrades and v72.upgrades.ShipPower or 0) or 0) then
					v52 = "Too strong! Upgrade your Ship Power."
				end
			end

			notifications:Send(v52 or "The fish got away!")
		end)
	end
end

local function onFlightEnded() --[[ onFlightEnded | Line: 2373 | Upvalues: v8 (ref), teardownFight (copy), AlienFlightState (copy), v13 (ref), t3 (copy), t6 (copy), v7 (ref), t7 (copy), destroyCargoHud (copy), v26 (ref), BeamTo (copy), v25 (ref), v28 (ref), restoreDepotSigns (copy), v24 (ref), setShipFx (copy), v20 (ref), v19 (ref), v21 (ref) ]]
	local v1 = v8

	v8 = nil

	if v1 then
		teardownFight(v1)
	end

	AlienFlightState.fighting = false
	AlienFlightState.catchAvailable = false
	v13()

	for v2, v3 in t3 do
		v3.model:Destroy()
	end

	table.clear(t3)

	for v4, v5 in t6 do
		v5:Destroy()
	end

	table.clear(t6)
	v7 = ""

	for v6, v72 in t7 do
		v72.model:Destroy()
	end

	table.clear(t7)
	destroyCargoHud()

	if v26 then
		v26 = false
		BeamTo(nil)
	end

	local v82 = v25

	v25 = nil

	if v82 then
		v82:Destroy()
	end

	local v9 = v28

	v28 = nil

	if v9 then
		v9.gui:Destroy()
	end

	restoreDepotSigns()
	v24 = false
	setShipFx(false)
	v20 = nil

	local v10 = v19

	if v10 then
		v10.Enabled = false
	end

	local v11 = v21

	if not v11 then
		return
	end

	v11.Enabled = false
	v11.Adornee = nil
end

function t.Init(p1) --[[ Init | Line: 2413 | Upvalues: AlienEventConfig (copy), Remotes (copy), addFish (copy), AlienFlightState (copy), hideTemplateFightElements (copy), setShipFx (copy), buildCargoHud (copy), updateCargoHud (copy), updateCarriedDisplay (copy), onFlightEnded (copy), CollectionService (copy), DepotSign (copy), addDepotSign (copy), t8 (copy), ClientPlayerData (copy), EventId (copy), UserInputService (copy), v8 (ref), Players (copy), pumpFight (copy), RunService (copy), stepFight (copy), stepFish (copy), stepDropped (copy), stepCarried (copy), stepDepotSigns (copy), updateTargeting (copy), v20 (ref), verifyShipFx (copy) ]]
	if not AlienEventConfig.Enabled then
		return
	end

	Remotes.AlienFishSpawn:On(function(p1) --[[ Line: 2421 | Upvalues: addFish (ref) ]]
		if type(p1) ~= "table" then
			return
		end

		if type(p1.Fish) ~= "table" then
			return
		end

		for v1, v2 in p1.Fish do
			addFish(v2)
		end
	end)
	AlienFlightState.FlightStarted:Connect(function() --[[ Line: 2430 | Upvalues: hideTemplateFightElements (ref), setShipFx (ref), buildCargoHud (ref), updateCargoHud (ref), updateCarriedDisplay (ref) ]]
		hideTemplateFightElements()
		setShipFx(false)
		buildCargoHud()
		updateCargoHud()
		updateCarriedDisplay()
	end)
	AlienFlightState.FlightEnded:Connect(onFlightEnded)

	for v1, v2 in CollectionService:GetTagged(DepotSign.Tag) do
		addDepotSign(v2)
	end

	CollectionService:GetInstanceAddedSignal(DepotSign.Tag):Connect(addDepotSign)
	CollectionService:GetInstanceRemovedSignal(DepotSign.Tag):Connect(function(p1) --[[ Line: 2452 | Upvalues: t8 (ref) ]]
		if not p1:IsA("Model") then
			return
		end

		t8[p1] = nil
	end)
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 2462 | Upvalues: EventId (ref) ]]
		local v1 = p1.events and p1.events[EventId]

		return if v1 then v1.cargo else v1
	end, function() --[[ Line: 2465 | Upvalues: updateCargoHud (ref), updateCarriedDisplay (ref) ]]
		updateCargoHud()
		updateCarriedDisplay()
	end)
	UserInputService.InputBegan:Connect(function(p1, p2) --[[ Line: 2479 | Upvalues: v8 (ref), Players (ref), pumpFight (ref) ]]
		local v1 = v8

		if not v1 then
			return
		end

		local UserInputType = p1.UserInputType

		if UserInputType ~= Enum.UserInputType.MouseButton1 and UserInputType ~= Enum.UserInputType.Touch then
			return
		end

		if not p2 then
			pumpFight()

			return
		end

		local PlayerGui = Players.LocalPlayer:FindFirstChildOfClass("PlayerGui")
		local root = v1.ui.root

		if not (PlayerGui and root.Parent) then
			return
		end

		local v2 = false

		for v3, v4 in PlayerGui:GetGuiObjectsAtPosition(p1.Position.X, p1.Position.Y) do
			if v4 == root or v4:IsDescendantOf(root) then
				v2 = true

				break
			end
		end

		if v2 then
			pumpFight()
		end
	end)
	RunService.Heartbeat:Connect(function(p1) --[[ Line: 2510 | Upvalues: stepFight (ref), stepFish (ref), stepDropped (ref), AlienFlightState (ref), stepCarried (ref), stepDepotSigns (ref), updateTargeting (ref), updateCargoHud (ref), setShipFx (ref), v8 (ref), v20 (ref), verifyShipFx (ref) ]]
		debug.profilebegin("UECS/AlienOceanFishing.Step")

		local v1 = os.clock()

		stepFight(p1)
		stepFish(p1)
		stepDropped(v1)

		if AlienFlightState.inFlight then
			stepCarried(v1)
			stepDepotSigns(p1)
			updateTargeting()
			updateCargoHud()
			setShipFx(if v8 == nil then v20 ~= nil else true)
			verifyShipFx()
		end

		debug.profileend()
	end)
end

return t