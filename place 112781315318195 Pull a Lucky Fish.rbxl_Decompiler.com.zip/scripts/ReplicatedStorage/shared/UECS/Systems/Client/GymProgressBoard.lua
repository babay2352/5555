-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local ConvertValue = require(ReplicatedStorage.shared.util.ConvertValue)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local GymEventConfig = require(ReplicatedStorage.shared.config.GymEventConfig)
local GymEventState = require(ReplicatedStorage.client.GymEventState)
local convertTimeMS = require(ReplicatedStorage.shared.util.convertTimeMS)
local t = {
	UECS = nil,
	Priority = 60
}
local ProgressBoard = GymEventConfig.Tags.ProgressBoard
local Outcomes = GymEventConfig.Outcomes
local v1 = Color3.fromRGB(255, 213, 0)
local v2 = TweenInfo.new(0.45, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local t2 = {}

local function hideElement(p1) --[[ hideElement | Line: 133 ]]
	p1.BackgroundTransparency = 1

	if p1:IsA("TextLabel") then
		p1.TextTransparency = 1
		p1.TextStrokeTransparency = 1
	elseif p1:IsA("ImageLabel") then
		p1.ImageTransparency = 1
	end

	for v1, v2 in p1:GetDescendants() do
		if v2:IsA("UIStroke") then
			v2.Transparency = 1
		end
	end
end

local function render(p1) --[[ render | Line: 150 | Upvalues: GymEventState (copy), GymEventConfig (copy), ConvertValue (copy), convertTimeMS (copy), TweenService (copy), v1 (copy), v2 (copy) ]]
	local v12 = GymEventState.Get()

	if not v12 then
		return
	end

	if p1.subtitle then
		local v22, v3 = GymEventConfig.GetPoolProgress(v12.pool)

		p1.subtitle.Text = ("%* / %* pts"):format(ConvertValue.suffixformat(v22), (ConvertValue.suffixformat(v3)))
	end

	if p1.nextTime then
		p1.nextTime.Text = convertTimeMS((math.max(0, v12.cycleEnd - os.time())))
	end

	if p1.level then
		local v6, v7 = GymEventConfig.GetOutcomeLevel(v12.pool)

		p1.level.Text = GymEventConfig.Ui.ProgressLevelText(v6, v7)
	end

	local multiplierLabel = p1.multiplierLabel

	if multiplierLabel then
		local v8 = GymEventConfig.GetOutcomeForPool(v12.pool).Stages[1]
		local v9 = if v8 then v8.Multiplier else 0

		multiplierLabel.Text = ("x%*"):format(v9)

		local multiplierBaseColor = p1.multiplierBaseColor

		if p1.lastMultiplier ~= nil and (p1.lastMultiplier ~= v9 and multiplierBaseColor) then
			if p1.multiplierTween then
				p1.multiplierTween:Cancel()
			end

			local v10 = TweenService:Create(multiplierLabel, TweenInfo.new(GymEventConfig.Ui.ProgressMultiplierFlashInSeconds, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				TextColor3 = GymEventConfig.Ui.ProgressMultiplierFlashColor
			})

			p1.multiplierTween = v10
			v10.Completed:Once(function(p12) --[[ Line: 214 | Upvalues: p1 (copy), multiplierLabel (copy), TweenService (ref), GymEventConfig (ref), multiplierBaseColor (copy) ]]
				if p12 ~= Enum.PlaybackState.Completed then
					return
				end

				if p1.multiplierLabel == multiplierLabel then
					local v1 = TweenService:Create(multiplierLabel, TweenInfo.new(GymEventConfig.Ui.ProgressMultiplierFlashOutSeconds, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						TextColor3 = multiplierBaseColor
					})

					p1.multiplierTween = v1
					v1:Play()
				end
			end)
			v10:Play()
		end

		p1.lastMultiplier = v9
	end

	for v11, v122 in p1.rows do
		if v122.pointsLabel then
			v122.pointsLabel.TextColor3 = if v12.pool >= v122.outcome.PointsRequired then v1 else v122.baseColor
		end
	end

	if not p1.fill then
		return
	end

	local v15 = GymEventConfig.GetPoolFraction(v12.pool)

	if p1.fillTarget == nil then
		p1.fill.Size = UDim2.fromScale(1, v15)
	elseif math.abs(v15 - p1.fillTarget) > 0.0001 then
		if p1.fillTween then
			p1.fillTween:Cancel()
		end

		local v17 = TweenService:Create(p1.fill, v2, {
			Size = UDim2.fromScale(1, v15)
		})

		p1.fillTween = v17
		v17:Play()
	end

	p1.fillTarget = v15
end

local function buildRows(p1, p2) --[[ buildRows | Line: 268 | Upvalues: GymEventConfig (copy), Outcomes (copy), ConvertValue (copy), hideElement (copy), render (copy) ]]
	local v1 = p1:FindFirstChild(GymEventConfig.Ui.ProgressBackgroundName)

	if not v1 then
		p2.rows = {}
		p2.subtitle = nil
		p2.nextTime = nil
		p2.level = nil
		p2.multiplierLabel = nil
		p2.multiplierBaseColor = nil
		p2.lastMultiplier = nil
		p2.fill = nil
		p2.fillTarget = nil

		return
	end

	local v2 = v1:FindFirstChild(GymEventConfig.Ui.ProgressSubtitleLabelName, true)

	p2.subtitle = if v2 and v2:IsA("TextLabel") then v2 else nil

	local v4 = v1:FindFirstChild(GymEventConfig.Ui.ProgressNextTimeLabelName, true)

	p2.nextTime = if v4 and v4:IsA("TextLabel") then v4 else nil

	local v6 = v1:FindFirstChild(GymEventConfig.Ui.ProgressLevelLabelName, true)

	p2.level = if v6 and v6:IsA("TextLabel") then v6 else nil

	if p2.multiplierTween then
		p2.multiplierTween:Cancel()
		p2.multiplierTween = nil
	end

	local v8 = v1:FindFirstChild(GymEventConfig.Ui.ProgressMultiplierLabelName, true)

	if v8 and v8:IsA("TextLabel") then
		p2.multiplierLabel = v8
		p2.multiplierBaseColor = v8.TextColor3
	else
		p2.multiplierLabel = nil
		p2.multiplierBaseColor = nil
	end

	p2.lastMultiplier = nil

	local Thermometer = v1:FindFirstChild("Thermometer")

	p2.fill = if Thermometer then Thermometer:FindFirstChild("Fill") or nil else nil

	if p2.fillTween then
		p2.fillTween:Cancel()
		p2.fillTween = nil
	end

	p2.fillTarget = nil

	local Rows = v1:FindFirstChild("Rows")
	local v10 = if Rows then Rows:FindFirstChild("RowTemplate") else Rows

	if Rows and (v10 and v10:IsA("GuiObject")) then
		for v11, v12 in Rows:GetChildren() do
			if v12.Name == "GymOutcomeRow" then
				v12:Destroy()
			end
		end

		v10.Visible = false

		local t = {}
		local count = 0

		for i = #Outcomes, 1, -1 do
			local v13 = Outcomes[i]

			for v16, v17 in v13.Stages do
				local v14, v15
				local v18 = if v16 == 1 then true else false
				local GymOutcomeRow = v10:Clone()

				GymOutcomeRow.Name = "GymOutcomeRow"
				GymOutcomeRow.LayoutOrder = count
				GymOutcomeRow.Visible = true
				count = count + 1

				local Points = GymOutcomeRow:FindFirstChild("Points")

				v14 = if Points and Points:IsA("TextLabel") then Points else nil

				local v19 = if v14 then v14.TextColor3 else Color3.new(255/255, 255/255, 255/255)

				if v14 then
					v14.Text = if v18 then ConvertValue.suffixformat(v13.PointsRequired) else ""

					if not v18 then
						hideElement(v14)
					end
				end

				local Dish = GymOutcomeRow:FindFirstChild("Dish")

				v15 = if Dish and Dish:IsA("ImageLabel") then Dish else nil

				if v15 then
					if v18 then
						v15.Image = v13.Icon
					else
						v15.Image = GymEventConfig.Ui.ProgressContinuationIcon
					end

					local DoneGlow = v15:FindFirstChild("DoneGlow")

					if DoneGlow and DoneGlow:IsA("UIStroke") then
						DoneGlow.Transparency = 1
					end
				end

				local Info = GymOutcomeRow:FindFirstChild("Info")
				local v21 = if Info then Info:FindFirstChild("Reward") else Info

				if v21 then
					v21.Text = ConvertValue.suffixformat(v17.Ticks)
				end

				local v22 = if Info then Info:FindFirstChild("TrainMultiplier") else Info

				if v22 then
					v22.Text = ("x%*"):format(v17.Multiplier)
				end

				GymOutcomeRow.Parent = Rows

				if v18 then
					table.insert(t, {
						outcome = v13,
						pointsLabel = v14,
						baseColor = v19
					})
				end
			end
		end

		p2.rows = t
		render(p2)
	else
		p2.rows = {}
	end
end

local function startFor(p1) --[[ startFor | Line: 421 | Upvalues: t2 (copy), GymEventConfig (copy), buildRows (copy) ]]
	if p1:IsA("SurfaceGui") and not t2[p1] then
		local t = {
			subtitle = nil,
			nextTime = nil,
			level = nil,
			multiplierLabel = nil,
			multiplierBaseColor = nil,
			lastMultiplier = nil,
			multiplierTween = nil,
			fill = nil,
			fillTarget = nil,
			fillTween = nil,
			rows = {},
			connections = {}
		}

		t2[p1] = t

		local function f1(p12) --[[ Line: 447 | Upvalues: GymEventConfig (ref), buildRows (ref), p1 (copy), t (copy) ]]
			if p12.Name ~= GymEventConfig.Ui.ProgressBackgroundName then
				return
			end

			buildRows(p1, t)
		end

		table.insert(t.connections, p1.ChildAdded:Connect(f1))
		buildRows(p1, t)
	end
end

local function stopFor(p1) --[[ stopFor | Line: 457 | Upvalues: t2 (copy) ]]
	local v1 = t2[p1]

	if not v1 then
		return
	end

	for v2, v3 in v1.connections do
		v3:Disconnect()
	end

	if not v1.fillTween then
		t2[p1] = nil

		return
	end

	v1.fillTween:Cancel()
	v1.fillTween = nil
	t2[p1] = nil
end

function t.Init(p1) --[[ Init | Line: 472 | Upvalues: GymEventConfig (copy), GymEventState (copy), t2 (copy), render (copy), CollectionService (copy), ProgressBoard (copy), startFor (copy), stopFor (copy), RunService (copy) ]]
	if not GymEventConfig.Enabled then
		return
	end

	GymEventState.Start()
	GymEventState.Changed:Connect(function() --[[ Line: 480 | Upvalues: t2 (ref), render (ref) ]]
		for v1, v2 in t2 do
			render(v2)
		end
	end)

	for v1, v2 in CollectionService:GetTagged(ProgressBoard) do
		startFor(v2)
	end

	CollectionService:GetInstanceAddedSignal(ProgressBoard):Connect(startFor)
	CollectionService:GetInstanceRemovedSignal(ProgressBoard):Connect(stopFor)

	local v3 = 0

	RunService.Heartbeat:Connect(function(p1) --[[ Line: 496 | Upvalues: v3 (ref), t2 (ref), render (ref) ]]
		debug.profilebegin("UECS/GymProgressBoard.Heartbeat")
		v3 = v3 + p1

		if v3 >= 1 then
			v3 = 0

			for v1, v2 in t2 do
				render(v2)
			end
		end

		debug.profileend()
	end)
end

return t