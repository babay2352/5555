-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ContextActionService = game:GetService("ContextActionService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")
local Workspace = game:GetService("Workspace")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local ConvertValue = require(ReplicatedStorage.shared.util.ConvertValue)
local DeepsConfig = require(ReplicatedStorage.shared.config.DeepsConfig)
local DeepsGearConfig = require(ReplicatedStorage.shared.config.DeepsGearConfig)
local DeepsLootConfig = require(ReplicatedStorage.shared.config.DeepsLootConfig)
local DeepsState = require(ReplicatedStorage.client.DeepsState)
local FishConfig = require(ReplicatedStorage.shared.config.FishConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local NumberSpinner = require(ReplicatedStorage.shared.NumberSpinner.NumberSpinner)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local RodRig = require(ReplicatedStorage.client.remoteFishing.RodRig)
local SFX = require(ReplicatedStorage.client.SFX)
local bindToButtonPress = require(ReplicatedStorage.shared.util.bindToButtonPress)
local buildFishModel = require(ReplicatedStorage.shared.util.buildFishModel)
local buildFishRodRig = require(ReplicatedStorage.shared.util.buildFishRodRig)
local buildHookInstance = require(ReplicatedStorage.shared.util.buildHookInstance)
local hideFishRodAccessory = require(ReplicatedStorage.shared.util.hideFishRodAccessory)
local notifications = require(ReplicatedStorage.shared.module.notifications)
local popInGui = require(ReplicatedStorage.shared.util.popInGui)
local t = {
	UECS = nil
}
local Spawn = DeepsConfig.Spawn
local Minigame = DeepsConfig.Minigame
local v1 = Color3.fromRGB(150, 255, 170)
local v2 = Color3.new(0/255, 0/255, 0/255)
local v3 = TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local v4 = TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local t2 = {
	{
		MaxRatio = 0.7,
		Color = Color3.fromRGB(110, 255, 130)
	},
	{
		MaxRatio = 1.05,
		Color = Color3.fromRGB(255, 220, 80)
	},
	{
		MaxRatio = (1 / 0),
		Color = Color3.fromRGB(255, 80, 80)
	}
}
local LocalPlayer = Players.LocalPlayer
local t3 = {}
local t4 = {}
local v5 = nil

local function getFolder() --[[ getFolder | Line: 123 | Upvalues: v5 (ref), DeepsConfig (copy), Workspace (copy) ]]
	local v1 = v5

	if v1 and v1.Parent then
		return v1
	end

	local v2 = Instance.new("Folder")

	v2.Name = DeepsConfig.ClientFishFolderName
	v2.Parent = Workspace
	v5 = v2

	return v2
end

local function buildPlaceholderModel(p1) --[[ buildPlaceholderModel | Line: 135 ]]
	local Model = Instance.new("Model")
	local Part = Instance.new("Part")

	Part.Shape = Enum.PartType.Ball
	Part.Size = Vector3.new(3, 3, 3)
	Part.Material = Enum.Material.Neon
	Part.Color = p1
	Part.Parent = Model
	Model.PrimaryPart = Part

	return Model
end

local function makePartInert(p1) --[[ makePartInert | Line: 147 ]]
	p1.Anchored = true
	p1.CanCollide = false
	p1.CanTouch = false
	p1.CanQuery = false
end

local function makeInert(p1) --[[ makeInert | Line: 154 ]]
	for v1, v2 in p1:GetDescendants() do
		if v2:IsA("BasePart") then
			v2.Anchored = true
			v2.CanCollide = false
			v2.CanTouch = false
			v2.CanQuery = false
		end
	end

	p1.DescendantAdded:Connect(function(p1) --[[ Line: 160 ]]
		if not p1:IsA("BasePart") then
			return
		end

		p1.Anchored = true
		p1.CanCollide = false
		p1.CanTouch = false
		p1.CanQuery = false
	end)
end

local function buildModel(p1, p2) --[[ buildModel | Line: 169 | Upvalues: buildFishModel (copy), Spawn (copy), makeInert (copy) ]]
	local v1 = buildFishModel.clone(p1)

	if not v1 then
		local v2 = Color3.fromRGB(120, 220, 255)
		local Model = Instance.new("Model")
		local Part = Instance.new("Part")

		Part.Shape = Enum.PartType.Ball
		Part.Size = Vector3.new(3, 3, 3)
		Part.Material = Enum.Material.Neon
		Part.Color = v2
		Part.Parent = Model
		Model.PrimaryPart = Part
		v1 = Model
	end

	local _, v3 = v1:GetBoundingBox()
	local v4 = math.max(v3.X, v3.Y, v3.Z)

	if v4 > 0 then
		v1:ScaleTo(v1:GetScale() * (Spawn.FishScale * p2 / v4))
	end

	makeInert(v1)

	return v1
end

local function ratioFor(p1) --[[ ratioFor | Line: 181 | Upvalues: ClientPlayerData (copy), DeepsConfig (copy) ]]
	return DeepsConfig.GetStrengthRatio(p1, ClientPlayerData.serverProfile:getState().strength or 0)
end

local function powerLineStyle(p1) --[[ powerLineStyle | Line: 186 | Upvalues: ClientPlayerData (copy), DeepsConfig (copy), ConvertValue (copy), t2 (copy) ]]
	local v2 = DeepsConfig.GetStrengthRatio(p1, ClientPlayerData.serverProfile:getState().strength or 0)
	local v3 = ConvertValue.suffixformat(p1)
	local v4 = v2

	for v5, v6 in t2 do
		if v4 <= v6.MaxRatio then
			return v3, v6.Color
		end
	end

	return v3, t2[#t2].Color
end

local t5 = {}

local function makeBillboardWorldSized(p1, p2) --[[ makeBillboardWorldSized | Line: 205 | Upvalues: t5 (copy) ]]
	local v1 = Vector2.new(p1.Size.X.Offset, p1.Size.Y.Offset)

	if v1.X <= 0 or v1.Y <= 0 then
		return
	end

	local Scaled = Instance.new("Frame")

	Scaled.Name = "Scaled"
	Scaled.BackgroundTransparency = 1
	Scaled.Size = UDim2.fromOffset(v1.X, v1.Y)

	for v2, v3 in p1:GetChildren() do
		v3.Parent = Scaled
	end

	local UIScale = Instance.new("UIScale")

	UIScale.Parent = Scaled
	Scaled.Parent = p1
	p1.Size = UDim2.fromScale(p2, p2 * v1.Y / v1.X)
	t5[p1] = {
		scale = UIScale,
		base = v1
	}
end

local function stepBillboards() --[[ stepBillboards | Line: 227 | Upvalues: t5 (copy) ]]
	for v1, v2 in t5 do
		if v1.Parent then
			local AbsoluteSize = v1.AbsoluteSize

			if not (AbsoluteSize.X <= 0) then
				local v3 = AbsoluteSize.X / v2.base.X

				if math.abs(v2.scale.Scale - v3) >= 0.005 then
					v2.scale.Scale = v3
				end
			end

			continue
		end

		t5[v1] = nil
	end
end

local function buildFishBillboard(p1) --[[ buildFishBillboard | Line: 253 | Upvalues: FishConfig (copy), ClientPlayerData (copy), DeepsConfig (copy), ConvertValue (copy), t2 (copy), ReplicatedStorage (copy), makeBillboardWorldSized (copy) ]]
	local v1 = p1.model.PrimaryPart or p1.model:FindFirstChildWhichIsA("BasePart")

	if not v1 then
		return
	end

	local v2 = FishConfig[p1.kind]
	local v3 = if v2 then v2.Rarity else v2
	local _, v4 = p1.model:GetBoundingBox()
	local strength = p1.strength
	local v6 = DeepsConfig.GetStrengthRatio(strength, ClientPlayerData.serverProfile:getState().strength or 0)
	local v7 = ConvertValue.suffixformat(strength)
	local v8 = v6
	local v9, v10

	do
		local __inline_returned = false

		for v11, v12 in t2 do
			if v8 <= v12.MaxRatio then
				v9 = v12.Color
				v10 = v7
				__inline_returned = true

				break
			end
		end

		if not __inline_returned then
			v9 = t2[#t2].Color
			v10 = v7
		end
	end

	local v13 = ReplicatedStorage:FindFirstChild("shared")
	local v14 = if v13 then v13:FindFirstChild("model") else v13
	local v15 = if v14 then v14:FindFirstChild(DeepsConfig.FishBillboardName) else v14

	if v15 and v15:IsA("BillboardGui") then
		local v16 = v15:Clone()

		v16.StudsOffsetWorldSpace = Vector3.new(0, v4.Y * 0.5 + 2, 0)
		v16.AlwaysOnTop = false

		local Rarity = v16:FindFirstChild("Rarity")

		if Rarity and Rarity:IsA("TextLabel") then
			Rarity.Text = if v3 then v3.displayName else "???"

			if v3 then
				Rarity.TextColor3 = v3.rarityColor
			end
		end

		local FishName = v16:FindFirstChild("FishName")

		if FishName and FishName:IsA("TextLabel") then
			FishName.Text = if v2 then v2.DisplayName else p1.kind
		end

		local Power = v16:FindFirstChild("Power")
		local v20 = if Power and Power:IsA("TextLabel") then Power elseif Power then Power:FindFirstChild("Value") else Power

		if v20 and v20:IsA("TextLabel") then
			v20.Text = v10
			v20.TextColor3 = v9
			p1.powerLabel = v20
		end

		local Status = v16:FindFirstChild("Status")

		if not (Status and Status:IsA("TextLabel")) then
			v16.Parent = v1
			makeBillboardWorldSized(v16, DeepsConfig.Billboard.FishWidthStuds)

			return
		end

		Status.Text = ""
		p1.statusLabel = Status
		v16.Parent = v1
		makeBillboardWorldSized(v16, DeepsConfig.Billboard.FishWidthStuds)
	else
		local DeepsFishLabel = Instance.new("BillboardGui")

		DeepsFishLabel.Name = "DeepsFishLabel"
		DeepsFishLabel.Size = UDim2.fromOffset(150, 70)
		DeepsFishLabel.StudsOffsetWorldSpace = Vector3.new(0, v4.Y * 0.5 + 2, 0)
		DeepsFishLabel.MaxDistance = 120
		DeepsFishLabel.AlwaysOnTop = false
		DeepsFishLabel.Parent = v1

		local function makeLine(p1, p2, p3, p4, p5) --[[ makeLine | Line: 315 | Upvalues: DeepsFishLabel (copy) ]]
			local TextLabel = Instance.new("TextLabel")

			TextLabel.Size = UDim2.new(1, 0, 0, p4)
			TextLabel.Position = UDim2.fromOffset(0, p1)
			TextLabel.BackgroundTransparency = 1
			TextLabel.Font = Enum.Font.GothamBlack
			TextLabel.TextSize = p5
			TextLabel.TextColor3 = p3
			TextLabel.Text = p2

			local UIStroke = Instance.new("UIStroke")

			UIStroke.Color = Color3.new(0/255, 0/255, 0/255)
			UIStroke.Thickness = 1.5
			UIStroke.Parent = TextLabel
			TextLabel.Parent = DeepsFishLabel

			return TextLabel
		end

		local Power = Instance.new("Frame")

		Power.Name = "Power"
		Power.Size = UDim2.new(1, 0, 0, 14)
		Power.Position = UDim2.fromOffset(0, 0)
		Power.BackgroundTransparency = 1

		local UIListLayout = Instance.new("UIListLayout")

		UIListLayout.FillDirection = Enum.FillDirection.Horizontal
		UIListLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center
		UIListLayout.VerticalAlignment = Enum.VerticalAlignment.Center
		UIListLayout.Padding = UDim.new(0, 3)
		UIListLayout.Parent = Power

		local Icon = Instance.new("ImageLabel")

		Icon.Name = "Icon"
		Icon.Size = UDim2.fromOffset(14, 14)
		Icon.BackgroundTransparency = 1
		Icon.Image = "rbxassetid://136868578369874"
		Icon.LayoutOrder = 1
		Icon.Parent = Power

		local Value = Instance.new("TextLabel")

		Value.Name = "Value"
		Value.AutomaticSize = Enum.AutomaticSize.X
		Value.Size = UDim2.fromScale(0, 1)
		Value.BackgroundTransparency = 1
		Value.Font = Enum.Font.GothamBlack
		Value.TextSize = 12
		Value.TextColor3 = v9
		Value.Text = v10
		Value.LayoutOrder = 2

		local UIStroke = Instance.new("UIStroke")

		UIStroke.Color = Color3.new(0/255, 0/255, 0/255)
		UIStroke.Thickness = 1.5
		UIStroke.Parent = Value
		Value.Parent = Power
		Power.Parent = DeepsFishLabel
		p1.powerLabel = Value
		makeLine(14, if v3 then v3.displayName else "???", if v3 then v3.rarityColor else Color3.new(255/255, 255/255, 255/255), 16, 14)
		makeLine(30, if v2 then v2.DisplayName else p1.kind, Color3.new(255/255, 255/255, 255/255), 20, 17)
		p1.statusLabel = makeLine(50, "", Color3.fromRGB(255, 120, 90), 16, 13)
		makeBillboardWorldSized(DeepsFishLabel, DeepsConfig.Billboard.FishWidthStuds)
	end
end

local function updateFishStatus(p1) --[[ updateFishStatus | Line: 382 | Upvalues: Players (copy), LocalPlayer (copy) ]]
	local statusLabel = p1.statusLabel

	if statusLabel and p1.busyByUserId then
		local v1 = Players:GetPlayerByUserId(p1.busyByUserId)

		statusLabel.Text = if v1 and v1 ~= LocalPlayer then ("\226\154\148 %* is fighting!"):format(v1.DisplayName) else "\226\154\148 Fighting!"
	elseif statusLabel then
		statusLabel.Text = ""
	end

	local prompt = p1.prompt

	if not prompt then
		return
	end

	prompt.Enabled = if p1.busyByUserId == nil then not p1.beingCaught else false
end

local v6 = nil
local v7 = nil
local v8 = nil

local function buildFishPrompt(p1) --[[ buildFishPrompt | Line: 407 | Upvalues: FishConfig (copy), Minigame (copy), v6 (ref) ]]
	local v1 = p1.model.PrimaryPart or p1.model:FindFirstChildWhichIsA("BasePart")

	if not v1 then
		return
	end

	local v2 = FishConfig[p1.kind]
	local DeepsCatchPrompt = Instance.new("ProximityPrompt")

	DeepsCatchPrompt.Name = "DeepsCatchPrompt"
	DeepsCatchPrompt.Style = Enum.ProximityPromptStyle.Custom
	DeepsCatchPrompt.ActionText = "Catch"
	DeepsCatchPrompt.ObjectText = if v2 then v2.DisplayName else p1.kind
	DeepsCatchPrompt.HoldDuration = 0.15
	DeepsCatchPrompt.MaxActivationDistance = Minigame.PromptRange
	DeepsCatchPrompt.RequiresLineOfSight = false
	DeepsCatchPrompt.KeyboardKeyCode = Enum.KeyCode.E
	DeepsCatchPrompt.Parent = v1
	DeepsCatchPrompt.Triggered:Connect(function() --[[ Line: 423 | Upvalues: v6 (ref), p1 (copy) ]]
		v6(p1)
	end)
	p1.prompt = DeepsCatchPrompt
end

local function removeFishLocal(p1, p2) --[[ removeFishLocal | Line: 429 | Upvalues: t3 (copy), v7 (ref), RunService (copy) ]]
	if t3[p1.id] ~= p1 then
		return
	end

	t3[p1.id] = nil
	v7(p1.id)

	local model = p1.model

	if p2 then
		model:Destroy()
	else
		task.spawn(function() --[[ Line: 440 | Upvalues: model (copy), RunService (ref) ]]
			local v1 = model:GetPivot()
			local sum2 = 0

			while sum2 < 0.35 and model.Parent do
				sum2 = sum2 + RunService.Heartbeat:Wait()

				local v2 = math.clamp(sum2 / 0.35, 0, 1)

				model:PivotTo(v1 * CFrame.new(0, v2 * -4 * v2, 0))
			end

			model:Destroy()
		end)
	end
end

local function playCaughtByOther(p1, p2) --[[ playCaughtByOther | Line: 462 | Upvalues: t3 (copy), Players (copy), v7 (ref), RunService (copy), ReplicatedStorage (copy), v8 (ref) ]]
	if t3[p1.id] ~= p1 then
		return
	end

	t3[p1.id] = nil

	local model = p1.model
	local v1 = if p2 then Players:GetPlayerByUserId(p2) else nil
	local v2 = if v1 then v1.Character else v1
	local v3 = v2 and v2:FindFirstChild("HumanoidRootPart")

	if v3 and (v3:IsA("BasePart") and model.PrimaryPart) then
		pcall(function() --[[ Line: 490 | Upvalues: ReplicatedStorage (ref), model (copy) ]]
			local v1 = ReplicatedStorage:FindFirstChild("shared")
			local v2 = if v1 then v1:FindFirstChild("model") else v1
			local v3 = if v2 then v2:FindFirstChild("PullEffect") else v2

			if not v3 then
				return
			end

			local v4 = v3:Clone()

			for v5, v6 in { "A1", "A2", "T" } do
				local v7 = v4:FindFirstChild(v6)

				if v7 then
					v7.Parent = model
				end
			end

			v4:Destroy()
		end)
		task.spawn(function() --[[ Line: 506 | Upvalues: model (copy), RunService (ref), v3 (copy), v8 (ref), p1 (copy), v7 (ref) ]]
			local Position = model:GetPivot().Position
			local sum = 0
			local v1 = true

			while sum < 0.7 and model.Parent do
				sum = sum + RunService.RenderStepped:Wait()

				local v2 = math.min(sum / 0.7, 1)
				local Position2 = v3.Position
				local v5 = (Position + Position2) / 2 + Vector3.new(0, math.max(25, (Position2 - Position).Magnitude * 0.35), 0)
				local v6 = 1 - v2
				local v72 = v6 * v6 * Position + v6 * 2 * v2 * v5 + v2 * v2 * Position2
				local v82 = v6 * 2 * (v5 - Position) + v2 * 2 * (Position2 - v5)

				if v82.Magnitude > 0.001 then
					model:PivotTo(CFrame.lookAt(v72, v72 + v82.Unit))
				else
					model:PivotTo(CFrame.new(v72))
				end

				if v1 then
					v1 = v8(p1)
				end
			end

			model:Destroy()
			v7(p1.id)
		end)

		return
	end

	v7(p1.id)
	task.spawn(function() --[[ Line: 474 | Upvalues: model (copy), RunService (ref) ]]
		local v1 = model:GetPivot()
		local sum = 0

		while sum < 0.35 and model.Parent do
			sum = sum + RunService.Heartbeat:Wait()

			local v2 = math.clamp(sum / 0.35, 0, 1)

			model:PivotTo(v1 * CFrame.new(0, v2 * -4 * v2, 0))
		end

		model:Destroy()
	end)
end

local function addFish(p1) --[[ addFish | Line: 538 | Upvalues: t3 (copy), buildModel (copy), v5 (ref), DeepsConfig (copy), Workspace (copy), buildFishBillboard (copy), buildFishPrompt (copy), updateFishStatus (copy) ]]
	if type(p1) ~= "table" then
		return
	end

	if type(p1.Id) ~= "number" then
		return
	end

	if type(p1.Kind) ~= "string" then
		return
	end

	if t3[p1.Id] then
		return
	end

	local Position = p1.Position

	if typeof(Position) ~= "Vector3" then
		return
	end

	local v2 = buildModel(p1.Kind, if type(p1.Scale) == "number" and p1.Scale > 0 then p1.Scale else 1)

	v2.Name = ("DeepsFish_%*"):format(p1.Kind)
	v2:SetAttribute("DeepsFishId", p1.Id)
	v2:PivotTo(CFrame.new(Position) * CFrame.Angles(0, math.random() * math.pi * 2, 0))

	local v3 = v5
	local v4

	if v3 and v3.Parent then
		v4 = v3
	else
		local v52 = Instance.new("Folder")

		v52.Name = DeepsConfig.ClientFishFolderName
		v52.Parent = Workspace
		v5 = v52
		v4 = v52
	end

	v2.Parent = v4

	local t = {
		beingCaught = false,
		prompt = nil,
		statusLabel = nil,
		id = p1.Id,
		kind = p1.Kind,
		model = v2,
		basePosition = Position
	}

	t.strength = if type(p1.Strength) == "number" then p1.Strength else 1
	t.expiresAt = if type(p1.ExpiresAt) == "number" then p1.ExpiresAt else (1 / 0)
	t.busyByUserId = if type(p1.BusyByUserId) == "number" then p1.BusyByUserId else nil
	t.phase = math.random() * 100
	t.yaw = math.random() * math.pi * 2
	t.lastPosition = Position
	t3[t.id] = t
	buildFishBillboard(t)
	buildFishPrompt(t)
	updateFishStatus(t)
end

local function getItemTemplate(p1) --[[ getItemTemplate | Line: 580 | Upvalues: ReplicatedStorage (copy) ]]
	local v1 = ReplicatedStorage:FindFirstChild("shared")
	local v2 = if v1 then v1:FindFirstChild("model") else v1
	local v3 = if v2 then v2:FindFirstChild("DeepsLoot") else v2
	local v4 = if v3 then v3:FindFirstChild(p1) else v3

	if v4 and v4:IsA("Model") then
		return v4:Clone()
	end

	return nil
end

local function tryPickup(p1) --[[ tryPickup | Line: 588 | Upvalues: DeepsState (copy), Remotes (copy), notifications (copy), t4 (copy), SFX (copy) ]]
	if not p1.taking and DeepsState.underwater then
		p1.taking = true
		task.spawn(function() --[[ Line: 593 | Upvalues: Remotes (ref), p1 (copy), notifications (ref), t4 (ref), SFX (ref) ]]
			local v12, v2 = Remotes.DeepsPickupItem:Call(p1.id):Await()

			p1.taking = false

			local v3 = if v12 and type(v2) == "table" then v2 else nil

			if v3 and v3.Ok == true then
				SFX.new(SFX.Sounds.Collect, 0.5)

				return
			end

			if v3 and type(v3.Message) == "string" then
				notifications:Send(v3.Message)
			end

			if not v3 or v3.Gone ~= true then
				return
			end

			local v4 = t4[p1.id]

			if not v4 then
				return
			end

			t4[p1.id] = nil
			v4.model:Destroy()
		end)
	end
end

local function addItem(p1) --[[ addItem | Line: 615 | Upvalues: t4 (copy), DeepsLootConfig (copy), getItemTemplate (copy), makeInert (copy), v5 (ref), DeepsConfig (copy), Workspace (copy), makeBillboardWorldSized (copy), Minigame (copy), DeepsState (copy), Remotes (copy), notifications (copy), SFX (copy) ]]
	if type(p1) ~= "table" then
		return
	end

	if type(p1.Id) ~= "number" then
		return
	end

	if type(p1.Kind) ~= "string" then
		return
	end

	if t4[p1.Id] then
		return
	end

	local Position = p1.Position

	if typeof(Position) ~= "Vector3" then
		return
	end

	local v1 = DeepsLootConfig.Items[p1.Kind]
	local v2 = getItemTemplate(p1.Kind)

	if not v2 then
		local v3 = v1 and v1.Rarity.rarityColor or Color3.fromRGB(200, 200, 200)
		local Model = Instance.new("Model")
		local Part = Instance.new("Part")

		Part.Shape = Enum.PartType.Ball
		Part.Size = Vector3.new(3, 3, 3)
		Part.Material = Enum.Material.Neon
		Part.Color = v3
		Part.Parent = Model
		Model.PrimaryPart = Part
		v2 = Model
	end

	v2.Name = ("DeepsItem_%*"):format(p1.Kind)
	makeInert(v2)
	v2:PivotTo(CFrame.new(Position) * CFrame.Angles(0, math.random() * math.pi * 2, 0))

	local v4 = v5
	local v52

	if v4 and v4.Parent then
		v52 = v4
	else
		local v6 = Instance.new("Folder")

		v6.Name = DeepsConfig.ClientFishFolderName
		v6.Parent = Workspace
		v5 = v6
		v52 = v6
	end

	v2.Parent = v52

	local t = {
		prompt = nil,
		taking = false,
		id = p1.Id,
		kind = p1.Kind,
		model = v2,
		position = Position
	}

	t.expiresAt = if type(p1.ExpiresAt) == "number" then p1.ExpiresAt else (1 / 0)

	local v8 = v2.PrimaryPart or v2:FindFirstChildWhichIsA("BasePart")

	if v8 then
		local DeepsItemLabel = Instance.new("BillboardGui")

		DeepsItemLabel.Name = "DeepsItemLabel"
		DeepsItemLabel.Size = UDim2.fromOffset(150, 54)
		DeepsItemLabel.StudsOffsetWorldSpace = Vector3.new(0, 2.6, 0)
		DeepsItemLabel.MaxDistance = 80
		DeepsItemLabel.AlwaysOnTop = false
		DeepsItemLabel.Parent = v8

		local function makeLine(p1, p2, p3, p4, p5) --[[ makeLine | Line: 657 | Upvalues: DeepsItemLabel (copy) ]]
			local TextLabel = Instance.new("TextLabel")

			TextLabel.Size = UDim2.new(1, 0, 0, p4)
			TextLabel.Position = UDim2.fromOffset(0, p1)
			TextLabel.BackgroundTransparency = 1
			TextLabel.Font = Enum.Font.GothamBlack
			TextLabel.TextSize = p5
			TextLabel.TextColor3 = p3
			TextLabel.Text = p2

			local UIStroke = Instance.new("UIStroke")

			UIStroke.Color = Color3.new(0/255, 0/255, 0/255)
			UIStroke.Thickness = 1.5
			UIStroke.Parent = TextLabel
			TextLabel.Parent = DeepsItemLabel
		end

		makeLine(0, v1 and v1.DisplayName or p1.Kind, v1 and v1.Rarity.rarityColor or Color3.new(255/255, 255/255, 255/255), 18, 15)

		local v15, v16

		if v1 then
			v15 = v1.StonesYield

			if v15 then
				v16 = makeLine
			else
				v15 = 0
				v16 = makeLine
			end
		else
			v15 = 0
			v16 = makeLine
		end

		v16(18, ("+%* Enchant Stones"):format(v15), Color3.fromRGB(140, 255, 170), 16, 13)
		makeBillboardWorldSized(DeepsItemLabel, DeepsConfig.Billboard.ItemWidthStuds)

		local DeepsTakePrompt = Instance.new("ProximityPrompt")

		DeepsTakePrompt.Name = "DeepsTakePrompt"
		DeepsTakePrompt.Style = Enum.ProximityPromptStyle.Custom
		DeepsTakePrompt.ActionText = "Take"
		DeepsTakePrompt.ObjectText = v1 and v1.DisplayName or p1.Kind
		DeepsTakePrompt.HoldDuration = 0.15
		DeepsTakePrompt.MaxActivationDistance = Minigame.PromptRange
		DeepsTakePrompt.RequiresLineOfSight = false
		DeepsTakePrompt.KeyboardKeyCode = Enum.KeyCode.E
		DeepsTakePrompt.Parent = v8
		DeepsTakePrompt.Triggered:Connect(function() --[[ Line: 692 | Upvalues: t (copy), DeepsState (ref), Remotes (ref), notifications (ref), t4 (ref), SFX (ref) ]]
			local v1 = t

			if v1.taking then
				return
			end

			if not DeepsState.underwater then
				return
			end

			v1.taking = true
			task.spawn(function() --[[ Line: 593 | Upvalues: Remotes (ref), v1 (copy), notifications (ref), t4 (ref), SFX (ref) ]]
				local v12, v2 = Remotes.DeepsPickupItem:Call(v1.id):Await()

				v1.taking = false

				local v3 = if v12 and type(v2) == "table" then v2 else nil

				if v3 and v3.Ok == true then
					SFX.new(SFX.Sounds.Collect, 0.5)

					return
				end

				if v3 and type(v3.Message) == "string" then
					notifications:Send(v3.Message)
				end

				if not v3 or v3.Gone ~= true then
					return
				end

				local v4 = t4[v1.id]

				if not v4 then
					return
				end

				t4[v1.id] = nil
				v4.model:Destroy()
			end)
		end)
		t.prompt = DeepsTakePrompt
	end

	t4[t.id] = t
end

local function removeItemLocal(p1, p2) --[[ removeItemLocal | Line: 701 | Upvalues: t4 (copy), RunService (copy) ]]
	if t4[p1.id] ~= p1 then
		return
	end

	t4[p1.id] = nil

	if p2 then
		p1.model:Destroy()
	else
		local model = p1.model

		task.spawn(function() --[[ Line: 711 | Upvalues: model (copy), RunService (ref) ]]
			local v1 = model:GetPivot()
			local sum2 = 0

			while sum2 < 0.35 and model.Parent do
				sum2 = sum2 + RunService.Heartbeat:Wait()

				local v2 = math.clamp(sum2 / 0.35, 0, 1)

				model:PivotTo(v1 * CFrame.new(0, v2 * -3 * v2, 0))
			end

			model:Destroy()
		end)
	end
end

local v9 = nil
local v10 = nil

local function getHighlight() --[[ getHighlight | Line: 731 | Upvalues: v10 (ref), v5 (ref), DeepsConfig (copy), Workspace (copy) ]]
	local v1 = v10

	if v1 and v1.Parent then
		return v1
	end

	local DeepsFishTarget = Instance.new("Highlight")

	DeepsFishTarget.Name = "DeepsFishTarget"
	DeepsFishTarget.FillTransparency = 1
	DeepsFishTarget.OutlineColor = Color3.fromRGB(170, 255, 255)
	DeepsFishTarget.OutlineTransparency = 0
	DeepsFishTarget.Enabled = false

	local v2 = v5
	local v3

	if v2 and v2.Parent then
		v3 = v2
	else
		local v4 = Instance.new("Folder")

		v4.Name = DeepsConfig.ClientFishFolderName
		v4.Parent = Workspace
		v5 = v4
		v3 = v4
	end

	DeepsFishTarget.Parent = v3
	v10 = DeepsFishTarget

	return DeepsFishTarget
end

local function pickTarget() --[[ pickTarget | Line: 750 | Upvalues: DeepsState (copy), LocalPlayer (copy), Minigame (copy), t3 (copy) ]]
	if not DeepsState.underwater then
		return nil
	end

	local Character = LocalPlayer.Character
	local v1 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character

	if not (v1 and v1:IsA("BasePart")) then
		return nil
	end

	local PromptRange = Minigame.PromptRange
	local v2 = nil

	for v3, v4 in t3 do
		if not (v4.beingCaught or v4.busyByUserId) then
			local Magnitude = (v4.model:GetPivot().Position - v1.Position).Magnitude

			if Magnitude <= PromptRange then
				PromptRange = Magnitude
				v2 = v4
			end
		end
	end

	return v2
end

local function updateTargeting() --[[ updateTargeting | Line: 774 | Upvalues: pickTarget (copy), v9 (ref), v10 (ref), v5 (ref), DeepsConfig (copy), Workspace (copy) ]]
	local v1 = pickTarget()

	if v1 == v9 then
		return
	end

	v9 = v1

	local v2 = v10
	local v3

	if v2 and v2.Parent then
		v3 = v2
	else
		local DeepsFishTarget = Instance.new("Highlight")

		DeepsFishTarget.Name = "DeepsFishTarget"
		DeepsFishTarget.FillTransparency = 1
		DeepsFishTarget.OutlineColor = Color3.fromRGB(170, 255, 255)
		DeepsFishTarget.OutlineTransparency = 0
		DeepsFishTarget.Enabled = false

		local v4 = v5
		local v52

		if v4 and v4.Parent then
			v52 = v4
		else
			local v6 = Instance.new("Folder")

			v6.Name = DeepsConfig.ClientFishFolderName
			v6.Parent = Workspace
			v5 = v6
			v52 = v6
		end

		DeepsFishTarget.Parent = v52
		v10 = DeepsFishTarget
		v3 = DeepsFishTarget
	end

	v3.Adornee = if v1 then v1.model else nil
	v3.Enabled = v1 ~= nil
end

local t6 = {}
local t7 = {}

local function extentAlong(p1, p2, p3) --[[ extentAlong | Line: 816 ]]
	local v2 = math.abs((p3:Dot(p1.RightVector))) * p2.X
	local v4 = v2 + math.abs((p3:Dot(p1.UpVector))) * p2.Y

	return v4 + math.abs((p3:Dot(p1.LookVector))) * p2.Z
end

local function moveCastHook(p1, p2) --[[ moveCastHook | Line: 826 ]]
	local v2 = CFrame.new(p2) * (p1.hook.CFrame - p1.hook.CFrame.Position)
	local hookContainer = p1.hookContainer

	if hookContainer:IsA("Model") then
		hookContainer:SetPrimaryPartCFrame(v2)
	else
		p1.hook.CFrame = v2
	end
end

local function seatCastHook(p1, p2) --[[ seatCastHook | Line: 841 | Upvalues: extentAlong (copy), Minigame (copy), moveCastHook (copy) ]]
	local v1 = p2.model:GetPivot()
	local _, v2 = p2.model:GetBoundingBox()
	local LookVector = v1.LookVector
	local v4 = v1.Position + LookVector * (extentAlong(v1 - v1.Position, v2, LookVector) / 2 + p1.hookHalfLength)
	local v5 = os.clock() - p1.castStartedAt
	local v7 = math.clamp(v5 / math.max(Minigame.CastHoldDelay, 0.05), 0, 1)

	if v7 >= 1 then
		moveCastHook(p1, v4)
	else
		local v8 = math.sin(v7 * math.pi) * 2

		moveCastHook(p1, p1.castFrom:Lerp(v4, 1 - (1 - v7) * (1 - v7)) + Vector3.new(0, v8, 0))
	end
end

local function stopCastRig(p1) --[[ stopCastRig | Line: 859 | Upvalues: t6 (copy), t7 (copy) ]]
	if t6[p1.userId] == p1 then
		t6[p1.userId] = nil
	end

	if t7[p1.fishId] == p1 then
		t7[p1.fishId] = nil
	end

	if p1.followConn then
		p1.followConn:Disconnect()
	end

	if p1.restoreAccessory then
		p1.restoreAccessory()
	end

	if p1.ownsRig and p1.rig then
		p1.rig:Destroy()
	end

	p1.hookContainer:Destroy()
end

local function stopCastRigForUser(p1) --[[ stopCastRigForUser | Line: 878 | Upvalues: t6 (copy), stopCastRig (copy) ]]
	local v1 = t6[p1]

	if not v1 then
		return
	end

	stopCastRig(v1)
end

v7 = function(p1) --[[ Line: 885 | Upvalues: t7 (copy), stopCastRig (copy) ]]
	local v1 = t7[p1]

	if not v1 then
		return
	end

	stopCastRig(v1)
end
v8 = function(p1) --[[ Line: 892 | Upvalues: t7 (copy), seatCastHook (copy) ]]
	local v1 = t7[p1.id]

	if v1 then
		seatCastHook(v1, p1)

		return true
	end

	return false
end

local function startCastRig(p1, p2, p3) --[[ startCastRig | Line: 901 | Upvalues: t6 (copy), stopCastRig (copy), v7 (ref), Players (copy), Minigame (copy), RodRig (copy), buildFishRodRig (copy), hideFishRodAccessory (copy), buildHookInstance (copy), v5 (ref), DeepsConfig (copy), Workspace (copy), extentAlong (copy), RunService (copy), t7 (copy), seatCastHook (copy) ]]
	local v1 = t6[p1]

	if v1 then
		stopCastRig(v1)
	end

	v7(p2.id)

	local v2 = Players:GetPlayerByUserId(p1)
	local v3 = if v2 then v2.Character else v2
	local v4 = v3 and (v3:FindFirstChild("RightHand") or v3:FindFirstChild("HumanoidRootPart"))

	if not (v2 and (v3 and (v4 and v4:IsA("BasePart")))) then
		return
	end

	if not p3 and Minigame.CastSoundId ~= "" then
		local DeepsCastSound = Instance.new("Sound")

		DeepsCastSound.Name = "DeepsCastSound"
		DeepsCastSound.SoundId = Minigame.CastSoundId
		DeepsCastSound.Volume = Minigame.CastSoundVolume
		DeepsCastSound.Parent = v4
		DeepsCastSound:Play()
		task.delay(6, function() --[[ Line: 928 | Upvalues: DeepsCastSound (copy) ]]
			DeepsCastSound:Destroy()
		end)
	end

	local v52 = v2:GetAttribute("FishRodConfig")

	if typeof(v52) ~= "string" then
		v52 = ""
	end

	local v6 = RodRig.rigFor(v2)
	local v72 = if v6 == nil then true else false
	local v8 = v6 or buildFishRodRig(v52)
	local v9 = if v72 and v8 then hideFishRodAccessory(v3) else nil
	local v11, v12 = buildHookInstance(v52)

	if v12 then
		v12:ScaleTo(v12:GetScale() * Minigame.HookScale)
	else
		v11.Size = v11.Size * Minigame.HookScale
	end

	local v13 = v12 or v11
	local v14 = v5
	local v15

	if v14 and v14.Parent then
		v15 = v14
	else
		local v16 = Instance.new("Folder")

		v16.Name = DeepsConfig.ClientFishFolderName
		v16.Parent = Workspace
		v5 = v16
		v15 = v16
	end

	v13.Parent = v15

	local RopeConstraint = v11:FindFirstChild("RopeConstraint")
	local v17 = if v8 then v8:FindFirstChild("RopeAttachment", true) else v8

	if RopeConstraint and (v17 and v17:IsA("Attachment")) then
		RopeConstraint.Attachment1 = v17
	elseif RopeConstraint then
		local DeepsLineHand = Instance.new("Attachment")

		DeepsLineHand.Name = "DeepsLineHand"
		DeepsLineHand.Parent = v4
		RopeConstraint.Attachment1 = DeepsLineHand
	end

	local v18, v19

	if v12 then
		local v20, v21 = v12:GetBoundingBox()

		v18 = v20
		v19 = v21
	else
		v18 = v11.CFrame
		v19 = v11.Size
	end

	local t = {
		followConn = nil,
		userId = p1,
		fishId = p2.id,
		rig = v8,
		ownsRig = v72,
		restoreAccessory = v9,
		hook = v11,
		hookContainer = v13,
		hookHalfLength = extentAlong(v18 - v18.Position, v19, Vector3.new(0, 0, 1)) / 2,
		castStartedAt = os.clock(),
		castFrom = v4.Position
	}

	if v72 and (v8 and v8.PrimaryPart) then
		t.followConn = RunService.RenderStepped:Connect(function() --[[ Line: 997 | Upvalues: v8 (copy), v4 (copy) ]]
			debug.profilebegin("UECS/DeepsFishing.RigFollow")

			if v8.PrimaryPart and v4.Parent then
				v8.PrimaryPart.CFrame = v4.CFrame * CFrame.Angles(1.5707963267948966, 0, 0)
			end

			debug.profileend()
		end)
	end

	t6[p1] = t
	t7[p2.id] = t
	seatCastHook(t, p2)
end

local function syncCastRig(p1, p2) --[[ syncCastRig | Line: 1013 | Upvalues: t7 (copy), startCastRig (copy), stopCastRig (copy) ]]
	local busyByUserId = p1.busyByUserId
	local v1 = t7[p1.id]

	if busyByUserId then
		if v1 and v1.userId == busyByUserId then
			return
		end

		startCastRig(busyByUserId, p1, p2)

		return
	end

	if not v1 then
		return
	end

	stopCastRig(v1)
end

local v11 = nil
local v12 = false
local v13 = nil

local function getDeepsFrame() --[[ getDeepsFrame | Line: 1069 | Upvalues: LocalPlayer (copy), DeepsConfig (copy) ]]
	local PlayerGui = LocalPlayer:FindFirstChildOfClass("PlayerGui")
	local v1 = if PlayerGui then PlayerGui:FindFirstChild("MainUI") else PlayerGui
	local v2 = if v1 then v1:FindFirstChild(DeepsConfig.UiFrameName) else v1

	if v2 and v2:IsA("Frame") then
		return v2
	end

	return nil
end

local function findClickFastFrame(p1) --[[ findClickFastFrame | Line: 1079 ]]
	for v1, v2 in p1:GetDescendants() do
		if v2.Name == "ClickFast" and (v2:IsA("GuiObject") and v2:FindFirstChild("Counter")) then
			return v2
		end
	end

	return nil
end

local function getClickFast() --[[ getClickFast | Line: 1088 | Upvalues: v13 (ref), LocalPlayer (copy), DeepsConfig (copy), findClickFastFrame (copy), NumberSpinner (copy) ]]
	local v1 = v13

	if v1 and v1.frame.Parent then
		return v1
	end

	local PlayerGui = LocalPlayer:FindFirstChildOfClass("PlayerGui")
	local v2 = if PlayerGui then PlayerGui:FindFirstChild("MainUI") else PlayerGui
	local v3 = if v2 then v2:FindFirstChild(DeepsConfig.UiFrameName) else v2
	local v4 = if v3 and v3:IsA("Frame") then v3 else nil
	local v5 = if v4 then findClickFastFrame(v4) else v4

	if not v5 then
		v13 = nil

		return nil
	end

	local Counter = v5:FindFirstChild("Counter")

	if not (Counter and Counter:IsA("GuiObject")) then
		v13 = nil

		return nil
	end

	local v6 = NumberSpinner.fromGuiObject(Counter)

	if v6 then
		v6.Visible = true
		v6.Decimals = 0
		v6.Prefix = ""
		v6.Suffix = ""
		v6.Duration = 0.15
		v6.TextSize = 24
		v6.AutomaticSize = Enum.AutomaticSize.X
		v6.Size = UDim2.fromScale(0, 1)

		local Size = v5.Size
		local t = {
			frame = v5,
			baseSize = Size,
			poppedSize = UDim2.new(Size.X.Scale * 1.2, Size.X.Offset * 1.2, Size.Y.Scale * 1.2, Size.Y.Offset * 1.2),
			spinner = v6
		}

		v13 = t

		return t
	end

	v13 = nil

	return nil
end

local function bumpClickFast(p1, p2) --[[ bumpClickFast | Line: 1134 | Upvalues: TweenService (copy), v4 (copy) ]]
	p1.spinner.Value = p2
	p1.frame.Size = p1.poppedSize
	TweenService:Create(p1.frame, v4, {
		Size = p1.baseSize
	}):Play()
end

local function hideTemplateFightElements() --[[ hideTemplateFightElements | Line: 1142 | Upvalues: LocalPlayer (copy), DeepsConfig (copy), getClickFast (copy) ]]
	local PlayerGui = LocalPlayer:FindFirstChildOfClass("PlayerGui")
	local v1 = if PlayerGui then PlayerGui:FindFirstChild("MainUI") else PlayerGui
	local v2 = if v1 then v1:FindFirstChild(DeepsConfig.UiFrameName) else v1
	local v3 = if v2 and v2:IsA("Frame") then v2 else nil

	if not v3 then
		return
	end

	local CatchFishBar = v3:FindFirstChild("CatchFishBar")

	if CatchFishBar and CatchFishBar:IsA("GuiObject") then
		CatchFishBar.Visible = false
	end

	local v4 = getClickFast()

	if not v4 then
		return
	end

	v4.frame.Visible = false
end

local function buildTemplateFightUi(p1) --[[ buildTemplateFightUi | Line: 1157 | Upvalues: LocalPlayer (copy), DeepsConfig (copy), FishConfig (copy), getClickFast (copy), popInGui (copy) ]]
	local PlayerGui = LocalPlayer:FindFirstChildOfClass("PlayerGui")
	local v1 = if PlayerGui then PlayerGui:FindFirstChild("MainUI") else PlayerGui
	local v2 = if v1 then v1:FindFirstChild(DeepsConfig.UiFrameName) else v1
	local v3 = if v2 and v2:IsA("Frame") then v2 else nil
	local v4 = if v3 then v3:FindFirstChild("CatchFishBar") else v3
	local v5 = if v4 then v4:FindFirstChild("Filler") else v4

	if not (v3 and (v4 and (v4:IsA("GuiObject") and (v5 and v5:IsA("Frame"))))) then
		return nil
	end

	local v6 = FishConfig[p1.kind]
	local FishContainer = v4:FindFirstChild("FishContainer")
	local v7 = if FishContainer then FishContainer:FindFirstChild("FishImage") else FishContainer

	if v7 and v7:IsA("ImageLabel") then
		v7.Image = if v6 then v6.Image else ""
	end

	local v9 = if FishContainer then FishContainer:FindFirstChild("NameOfFish") else FishContainer

	if v9 and v9:IsA("TextLabel") then
		v9.Text = if v6 then v6.DisplayName else p1.kind

		if v6 then
			v9.TextColor3 = v6.Rarity.rarityColor
		end
	end

	local v11 = getClickFast()

	if v11 then
		v11.spinner.Value = 0
		v11.frame.Size = v11.baseSize
		popInGui(v11.frame, true)
	end

	popInGui(v4, true)

	return {
		template = true,
		root = v4,
		fill = v5,
		clickFast = v11
	}
end

local function buildFightUi(p1) --[[ buildFightUi | Line: 1190 | Upvalues: FishConfig (copy), LocalPlayer (copy), v2 (copy), v1 (copy) ]]
	local v12 = FishConfig[p1.kind]
	local DeepsCatchUI = Instance.new("ScreenGui")

	DeepsCatchUI.Name = "DeepsCatchUI"
	DeepsCatchUI.ResetOnSpawn = false
	DeepsCatchUI.DisplayOrder = 60
	DeepsCatchUI.Parent = LocalPlayer:WaitForChild("PlayerGui")

	local Frame = Instance.new("Frame")

	Frame.AnchorPoint = Vector2.new(0.5, 1)
	Frame.Position = UDim2.new(0.5, 0, 1, -120)
	Frame.Size = UDim2.new(0.45, 0, 0, 88)
	Frame.BackgroundColor3 = v2
	Frame.BackgroundTransparency = 0.35
	Frame.BorderSizePixel = 0
	Frame.Parent = DeepsCatchUI

	local UISizeConstraint = Instance.new("UISizeConstraint")

	UISizeConstraint.MinSize = Vector2.new(280, 88)
	UISizeConstraint.MaxSize = Vector2.new(420, 88)
	UISizeConstraint.Parent = Frame

	local UICorner = Instance.new("UICorner")

	UICorner.CornerRadius = UDim.new(0, 10)
	UICorner.Parent = Frame

	local ImageLabel = Instance.new("ImageLabel")

	ImageLabel.AnchorPoint = Vector2.new(0, 0.5)
	ImageLabel.Position = UDim2.new(0, 12, 0.5, 0)
	ImageLabel.Size = UDim2.fromOffset(64, 64)
	ImageLabel.BackgroundTransparency = 1
	ImageLabel.Image = if v12 then v12.Image else ""
	ImageLabel.Parent = Frame

	local TextLabel = Instance.new("TextLabel")

	TextLabel.Position = UDim2.fromOffset(88, 10)
	TextLabel.Size = UDim2.new(1, -100, 0, 22)
	TextLabel.BackgroundTransparency = 1
	TextLabel.Font = Enum.Font.GothamBlack
	TextLabel.TextSize = 18
	TextLabel.TextXAlignment = Enum.TextXAlignment.Left
	TextLabel.TextColor3 = if v12 then v12.Rarity.rarityColor else Color3.new(255/255, 255/255, 255/255)
	TextLabel.Text = if v12 then v12.DisplayName else p1.kind
	TextLabel.Parent = Frame

	local Frame2 = Instance.new("Frame")

	Frame2.Position = UDim2.fromOffset(88, 40)
	Frame2.Size = UDim2.new(1, -100, 0, 20)
	Frame2.BackgroundColor3 = Color3.fromRGB(35, 35, 35)
	Frame2.BorderSizePixel = 0
	Frame2.Parent = Frame

	local UICorner2 = Instance.new("UICorner")

	UICorner2.CornerRadius = UDim.new(0, 6)
	UICorner2.Parent = Frame2

	local Filler = Instance.new("Frame")

	Filler.Name = "Filler"
	Filler.Size = UDim2.fromScale(0.35, 1)
	Filler.BackgroundColor3 = v1
	Filler.BorderSizePixel = 0
	Filler.Parent = Frame2

	local UICorner3 = Instance.new("UICorner")

	UICorner3.CornerRadius = UDim.new(0, 6)
	UICorner3.Parent = Filler

	local TextLabel2 = Instance.new("TextLabel")

	TextLabel2.Position = UDim2.fromOffset(88, 62)
	TextLabel2.Size = UDim2.new(1, -100, 0, 18)
	TextLabel2.BackgroundTransparency = 1
	TextLabel2.Font = Enum.Font.GothamBold
	TextLabel2.TextSize = 13
	TextLabel2.TextXAlignment = Enum.TextXAlignment.Left
	TextLabel2.TextColor3 = Color3.fromRGB(220, 220, 220)
	TextLabel2.Text = "CLICK FAST to reel it in!"
	TextLabel2.Parent = Frame

	return {
		template = false,
		clickFast = nil,
		root = DeepsCatchUI,
		fill = Filler
	}
end

local function updateFightFill(p1) --[[ updateFightFill | Line: 1269 ]]
	local fromScale = UDim2.fromScale

	p1.ui.fill.Size = fromScale(math.clamp(p1.progress, 0, 1), 1)
end

local FightCamera = DeepsConfig.FightCamera
local v14 = false
local v15 = nil
local v16 = nil
local v17 = 0

local function startFightCamera() --[[ startFightCamera | Line: 1293 | Upvalues: Workspace (copy), v14 (ref), FightCamera (copy), v15 (ref), v16 (ref), v17 (ref) ]]
	local CurrentCamera = Workspace.CurrentCamera

	if CurrentCamera and (not v14 and FightCamera.Enabled) then
		v14 = true
		v15 = nil
		v16 = CurrentCamera.CFrame
		v17 = 0
		CurrentCamera.CameraType = Enum.CameraType.Scriptable
	end
end

local function stopFightCamera() --[[ stopFightCamera | Line: 1305 | Upvalues: v14 (ref), v16 (ref), v17 (ref), Workspace (copy), LocalPlayer (copy) ]]
	if not v14 then
		return
	end

	v14 = false
	v16 = nil
	v17 = 0

	local CurrentCamera = Workspace.CurrentCamera

	if not CurrentCamera then
		return
	end

	local Character = LocalPlayer.Character
	local v1 = if Character then Character:FindFirstChildOfClass("Humanoid") else Character

	if v1 then
		CurrentCamera.CameraSubject = v1
	end

	CurrentCamera.CameraType = Enum.CameraType.Custom
end

local function updateFightCamera(p1) --[[ updateFightCamera | Line: 1326 | Upvalues: v11 (ref), Workspace (copy), v14 (ref), LocalPlayer (copy), DeepsState (copy), FightCamera (copy), v15 (ref), v16 (ref), v17 (ref) ]]
	local v1 = v11
	local CurrentCamera = Workspace.CurrentCamera

	if not (v1 and (CurrentCamera and v14)) then
		return
	end

	local Character = LocalPlayer.Character
	local v2 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character

	if not (v2 and v2:IsA("BasePart")) then
		return
	end

	local Position = v2.Position
	local v3 = DeepsState.fightTarget or v1.fish.model:GetPivot().Position
	local v4 = (Position + v3) * 0.5
	local v5 = v3 - Position
	local v6 = Vector3.new(v5.X, 0, v5.Z)

	if v6.Magnitude > FightCamera.MinAxis or not v15 then
		local v7 = if v6.Magnitude > 0.01 then true else false
		local v8 = if v7 then v6.Unit:Cross(Vector3.new(0, 1, 0)) else CurrentCamera.CFrame.RightVector

		if v8:Dot(CurrentCamera.CFrame.Position - v4) < 0 then
			v8 = -v8
		end

		v15 = v8
	end

	local v112 = v4 + v15 * math.max(FightCamera.MinDistance, v5.Magnitude * FightCamera.Spread)
	local v172 = (v16 or CurrentCamera.CFrame):Lerp(CFrame.lookAt(v112 + Vector3.new(0, Position.Y - v4.Y + FightCamera.Lift, 0), v4), 1 - math.exp(-FightCamera.Smoothing * p1))

	v16 = v172
	v17 = v17 * math.exp(-FightCamera.ShakeDecay * p1)

	local v20 = v17

	if v20 > 0.005 then
		local v21 = os.clock() * 23
		local v24 = Vector3.new(math.noise(v21, 1.7), math.noise(3.1, v21), math.noise(v21, -4.3)) * v20
		local v25 = math.rad(FightCamera.ShakeRollDegrees) * math.noise(-v21, 2.9)
		local v26 = v25 * (v20 / math.max(FightCamera.ShakeMax, 0.001))

		CurrentCamera.CFrame = v172 * CFrame.new(v24) * CFrame.Angles(0, 0, v26)
	else
		CurrentCamera.CFrame = v172
	end
end

local function teardownFight(p1) --[[ teardownFight | Line: 1382 | Upvalues: ContextActionService (copy), v14 (ref), v16 (ref), v17 (ref), Workspace (copy), LocalPlayer (copy), DeepsState (copy), popInGui (copy) ]]
	ContextActionService:UnbindAction("DeepsFishing_Pump")

	if v14 then
		v14 = false
		v16 = nil
		v17 = 0

		local CurrentCamera = Workspace.CurrentCamera

		if CurrentCamera then
			local Character = LocalPlayer.Character
			local v1 = if Character then Character:FindFirstChildOfClass("Humanoid") else Character

			if v1 then
				CurrentCamera.CameraSubject = v1
			end

			CurrentCamera.CameraType = Enum.CameraType.Custom
		end
	end

	DeepsState.fighting = false
	DeepsState.fightTarget = nil

	local ui = p1.ui

	if ui.template then
		local root = ui.root

		if root:IsA("GuiObject") then
			popInGui(root, false)
		end

		if ui.clickFast then
			popInGui(ui.clickFast.frame, false)
		end
	else
		ui.root:Destroy()
	end
end

local function finishFight(p1) --[[ finishFight | Line: 1403 | Upvalues: v11 (ref), Remotes (copy), teardownFight (copy), updateFishStatus (copy), SFX (copy), FishConfig (copy), notifications (copy) ]]
	local v1 = v11

	if v1 and not v1.finishing then
		v1.finishing = true
		task.spawn(function() --[[ Line: 1410 | Upvalues: v1 (copy), Remotes (ref), p1 (copy), teardownFight (ref), v11 (ref), updateFishStatus (ref), SFX (ref), FishConfig (ref), notifications (ref) ]]
			local fish = v1.fish
			local v12, v22 = Remotes.DeepsCatchFinish:Call({
				Id = fish.id,
				Success = p1,
				Rejected = v1.rejectedPumps
			}):Await()

			teardownFight(v1)

			if v11 == v1 then
				v11 = nil
			end

			fish.beingCaught = false
			updateFishStatus(fish)

			local v32 = if v12 and type(v22) == "table" then v22 else nil

			if p1 and (if v32 == nil or v32.Ok ~= true then false elseif v32.Caught == true then true else false) then
				SFX.new(SFX.Sounds.Collect, 0.5)

				local v52 = FishConfig[fish.kind]

				notifications:Send((("You caught %*!%*"):format(v52 and v52.DisplayName or fish.kind, if v32.Bag and v32.Slots then (" (%*/%*)"):format(v32.Bag, v32.Slots) else "")))
			else
				if not p1 then
					SFX.new(SFX.Sounds.Poof, 0.4)
					notifications:Send("It broke free!")

					return
				end

				SFX.new(SFX.Sounds.Poof, 0.4)
				notifications:Send(if v32 then if type(v32.Message) == "string" then v32.Message else "The fish got away!" else "The fish got away!")
			end
		end)
	end
end

local v18 = 1 / Minigame.MaxClicksPerSecond * Minigame.ClickTolerance

local function punchFightPanel(p1) --[[ punchFightPanel | Line: 1452 | Upvalues: TweenService (copy), v3 (copy) ]]
	local root = p1.ui.root

	if root:IsA("GuiObject") then
		p1.punchSide = -p1.punchSide
		root.Rotation = p1.punchSide * 1.6
		TweenService:Create(root, v3, {
			Rotation = 0
		}):Play()
	end
end

local function pumpFight() --[[ pumpFight | Line: 1462 | Upvalues: v11 (ref), v18 (copy), SFX (copy), punchFightPanel (copy), v17 (ref), FightCamera (copy), Minigame (copy), TweenService (copy), v4 (copy), Remotes (copy), teardownFight (copy), updateFishStatus (copy), FishConfig (copy), notifications (copy) ]]
	local v1 = v11

	if not v1 or v1.finishing then
		return
	end

	local v2 = os.clock()

	if v2 < v1.castingUntil then
		return
	end

	if v2 - v1.lastPumpAt < v18 then
		v1.rejectedPumps = v1.rejectedPumps + 1

		return
	end

	v1.lastPumpAt = v2
	SFX.PlaySoundWithRandomPitch(SFX.Sounds.Click, 0.2, 0.9, 1.15)
	punchFightPanel(v1)
	v17 = math.min(v17 + FightCamera.ShakePerClick, FightCamera.ShakeMax)
	v1.progress = math.min(v1.progress + Minigame.ClickGain, 1)
	v1.clicks = v1.clicks + 1

	if v1.ui.clickFast then
		local clickFast = v1.ui.clickFast

		clickFast.spinner.Value = v1.clicks
		clickFast.frame.Size = clickFast.poppedSize
		TweenService:Create(clickFast.frame, v4, {
			Size = clickFast.baseSize
		}):Play()
	end

	v1.ui.fill.Size = UDim2.fromScale(math.clamp(v1.progress, 0, 1), 1)

	if not (v1.progress >= 1) then
		return
	end

	local v5 = v11

	if not v5 then
		return
	end

	if v5.finishing then
		return
	end

	v5.finishing = true

	local v6 = true

	task.spawn(function() --[[ Line: 1410 | Upvalues: v5 (copy), Remotes (ref), v6 (copy), teardownFight (ref), v11 (ref), updateFishStatus (ref), SFX (ref), FishConfig (ref), notifications (ref) ]]
		local fish = v5.fish
		local v12, v22 = Remotes.DeepsCatchFinish:Call({
			Id = fish.id,
			Success = v6,
			Rejected = v5.rejectedPumps
		}):Await()

		teardownFight(v5)

		if v11 == v5 then
			v11 = nil
		end

		fish.beingCaught = false
		updateFishStatus(fish)

		local v32 = if v12 and type(v22) == "table" then v22 else nil

		if v6 and (if v32 == nil or v32.Ok ~= true then false elseif v32.Caught == true then true else false) then
			SFX.new(SFX.Sounds.Collect, 0.5)

			local v52 = FishConfig[fish.kind]

			notifications:Send((("You caught %*!%*"):format(v52 and v52.DisplayName or fish.kind, if v32.Bag and v32.Slots then (" (%*/%*)"):format(v32.Bag, v32.Slots) else "")))
		else
			if not v6 then
				SFX.new(SFX.Sounds.Poof, 0.4)
				notifications:Send("It broke free!")

				return
			end

			SFX.new(SFX.Sounds.Poof, 0.4)
			notifications:Send(if v32 then if type(v32.Message) == "string" then v32.Message else "The fish got away!" else "The fish got away!")
		end
	end)
end

local function startFight(p1) --[[ startFight | Line: 1494 | Upvalues: buildTemplateFightUi (copy), buildFightUi (copy), updateFishStatus (copy), LocalPlayer (copy), Minigame (copy), DeepsConfig (copy), ratioFor (copy), v11 (ref), bindToButtonPress (copy), pumpFight (copy), DeepsState (copy), Workspace (copy), v14 (ref), FightCamera (copy), v15 (ref), v16 (ref), v17 (ref) ]]
	local v1 = buildTemplateFightUi(p1) or buildFightUi(p1)

	p1.beingCaught = true
	updateFishStatus(p1)

	local Character = LocalPlayer.Character
	local v2 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character
	local v3 = if v2 and v2:IsA("BasePart") then v2.Position else p1.basePosition
	local t = {
		lastPumpAt = 0,
		rejectedPumps = 0,
		elapsed = 0,
		clicks = 0,
		punchSide = 1,
		finishing = false,
		fish = p1,
		progress = Minigame.StartProgress,
		drainPerSecond = DeepsConfig.GetDrainPerSecond(ratioFor(p1.strength)),
		ui = v1,
		castingUntil = os.clock() + Minigame.CastHoldDelay,
		pullTo = v3
	}

	v11 = t
	bindToButtonPress("DeepsFishing_Pump", Enum.KeyCode.ButtonX, function() --[[ Line: 1522 | Upvalues: v11 (ref), pumpFight (ref) ]]
		if not v11 then
			return
		end

		pumpFight()
	end)
	DeepsState.fighting = true
	DeepsState.fightTarget = p1.model:GetPivot().Position

	local CurrentCamera = Workspace.CurrentCamera
	local v4, v5, v6

	if CurrentCamera and (not v14 and FightCamera.Enabled) then
		v14 = true
		v15 = nil
		v16 = CurrentCamera.CFrame
		v17 = 0
		CurrentCamera.CameraType = Enum.CameraType.Scriptable
	end

	v4 = t.ui.fill
	v5 = UDim2.fromScale
	v6 = t.progress
	v4.Size = v5(math.clamp(v6, 0, 1), 1)
end

v6 = function(p1) --[[ Line: 1534 | Upvalues: v11 (ref), v12 (ref), DeepsState (copy), LocalPlayer (copy), Players (copy), notifications (copy), ClientPlayerData (copy), DeepsGearConfig (copy), updateFishStatus (copy), Remotes (copy), t3 (copy), v7 (ref), RunService (copy), startFight (copy) ]]
	if v11 or (v12 or (p1.beingCaught or not DeepsState.underwater)) then
		return
	end

	if p1.busyByUserId and p1.busyByUserId ~= LocalPlayer.UserId then
		local v1 = Players:GetPlayerByUserId(p1.busyByUserId)

		notifications:Send((("%* is fighting this fish!"):format(if v1 then v1.DisplayName else "Someone")))
	else
		local v5 = ClientPlayerData.serverProfile:getState()

		if #(v5.deeps and v5.deeps.bag or {}) >= DeepsGearConfig.GetBagSlots(v5.deepsGear) then
			notifications:Send("Your loot bag is full! Swim up to unload.")
		else
			p1.beingCaught = true
			updateFishStatus(p1)
			v12 = true
			task.spawn(function() --[[ Line: 1553 | Upvalues: Remotes (ref), p1 (copy), v12 (ref), updateFishStatus (ref), notifications (ref), t3 (ref), v7 (ref), RunService (ref), DeepsState (ref), startFight (ref) ]]
				local v1, v2 = Remotes.DeepsCatchStart:Call(p1.id):Await()

				v12 = false

				local v3 = if v1 and type(v2) == "table" then v2 else nil

				if v3 and v3.Ok == true then
					if DeepsState.underwater and t3[p1.id] == p1 then
						startFight(p1)
					else
						p1.beingCaught = false
						updateFishStatus(p1)
					end
				else
					p1.beingCaught = false
					updateFishStatus(p1)

					if v3 and type(v3.Message) == "string" then
						notifications:Send(v3.Message)
					else
						notifications:Send("Couldn\'t hook the fish. Try again!")
					end

					if not v3 or v3.Gone ~= true then
						return
					end

					local v4 = p1

					if t3[v4.id] ~= v4 then
						return
					end

					t3[v4.id] = nil
					v7(v4.id)

					local model = v4.model

					task.spawn(function() --[[ Line: 440 | Upvalues: model (copy), RunService (ref) ]]
						local v1 = model:GetPivot()
						local sum2 = 0

						while sum2 < 0.35 and model.Parent do
							sum2 = sum2 + RunService.Heartbeat:Wait()

							local v2 = math.clamp(sum2 / 0.35, 0, 1)

							model:PivotTo(v1 * CFrame.new(0, v2 * -4 * v2, 0))
						end

						model:Destroy()
					end)
				end
			end)
		end
	end
end

local function stepFight(p1) --[[ stepFight | Line: 1583 | Upvalues: v11 (ref), Remotes (copy), teardownFight (copy), updateFishStatus (copy), SFX (copy), FishConfig (copy), notifications (copy), Minigame (copy) ]]
	local v1 = v11

	if not v1 then
		return
	end

	if v1.finishing then
		return
	end

	if os.clock() < v1.castingUntil then
		return
	end

	v1.elapsed = v1.elapsed + p1

	if v1.progress >= 1 then
		local fromScale = UDim2.fromScale

		v1.ui.fill.Size = fromScale(math.clamp(v1.progress, 0, 1), 1)

		local v2 = v11

		if not v2 then
			return
		end

		if v2.finishing then
			return
		end

		v2.finishing = true

		local v3 = true

		task.spawn(function() --[[ Line: 1410 | Upvalues: v2 (copy), Remotes (ref), v3 (copy), teardownFight (ref), v11 (ref), updateFishStatus (ref), SFX (ref), FishConfig (ref), notifications (ref) ]]
			local fish = v2.fish
			local v12, v22 = Remotes.DeepsCatchFinish:Call({
				Id = fish.id,
				Success = v3,
				Rejected = v2.rejectedPumps
			}):Await()

			teardownFight(v2)

			if v11 == v2 then
				v11 = nil
			end

			fish.beingCaught = false
			updateFishStatus(fish)

			local v32 = if v12 and type(v22) == "table" then v22 else nil

			if v3 and (if v32 == nil or v32.Ok ~= true then false elseif v32.Caught == true then true else false) then
				SFX.new(SFX.Sounds.Collect, 0.5)

				local v52 = FishConfig[fish.kind]

				notifications:Send((("You caught %*!%*"):format(v52 and v52.DisplayName or fish.kind, if v32.Bag and v32.Slots then (" (%*/%*)"):format(v32.Bag, v32.Slots) else "")))
			else
				if not v3 then
					SFX.new(SFX.Sounds.Poof, 0.4)
					notifications:Send("It broke free!")

					return
				end

				SFX.new(SFX.Sounds.Poof, 0.4)
				notifications:Send(if v32 then if type(v32.Message) == "string" then v32.Message else "The fish got away!" else "The fish got away!")
			end
		end)
	else
		v1.progress = v1.progress - v1.drainPerSecond * p1

		local fromScale = UDim2.fromScale

		v1.ui.fill.Size = fromScale(math.clamp(v1.progress, 0, 1), 1)

		if not (v1.progress <= 0 or v1.elapsed >= Minigame.FightTimeout) then
			return
		end

		local v4 = v11

		if not v4 then
			return
		end

		if v4.finishing then
			return
		end

		v4.finishing = true

		local v5 = false

		task.spawn(function() --[[ Line: 1410 | Upvalues: v4 (copy), Remotes (ref), v5 (copy), teardownFight (ref), v11 (ref), updateFishStatus (ref), SFX (ref), FishConfig (ref), notifications (ref) ]]
			local fish = v4.fish
			local v12, v22 = Remotes.DeepsCatchFinish:Call({
				Id = fish.id,
				Success = v5,
				Rejected = v4.rejectedPumps
			}):Await()

			teardownFight(v4)

			if v11 == v4 then
				v11 = nil
			end

			fish.beingCaught = false
			updateFishStatus(fish)

			local v32 = if v12 and type(v22) == "table" then v22 else nil

			if v5 and (if v32 == nil or v32.Ok ~= true then false elseif v32.Caught == true then true else false) then
				SFX.new(SFX.Sounds.Collect, 0.5)

				local v52 = FishConfig[fish.kind]

				notifications:Send((("You caught %*!%*"):format(v52 and v52.DisplayName or fish.kind, if v32.Bag and v32.Slots then (" (%*/%*)"):format(v32.Bag, v32.Slots) else "")))
			else
				if not v5 then
					SFX.new(SFX.Sounds.Poof, 0.4)
					notifications:Send("It broke free!")

					return
				end

				SFX.new(SFX.Sounds.Poof, 0.4)
				notifications:Send(if v32 then if type(v32.Message) == "string" then v32.Message else "The fish got away!" else "The fish got away!")
			end
		end)
	end
end

local function stepFish(p1) --[[ stepFish | Line: 1612 | Upvalues: Workspace (copy), v11 (ref), t3 (copy), v7 (ref), RunService (copy), Minigame (copy), DeepsState (copy), t7 (copy), seatCastHook (copy), t4 (copy) ]]
	local v1 = Workspace:GetServerTimeNow()
	local v2 = os.clock()
	local v3 = v11

	for v5, v6 in t3 do
		local v4

		if v6.expiresAt <= v1 and not (v6.beingCaught or v6.busyByUserId) then
			if t3[v6.id] == v6 then
				t3[v6.id] = nil
				v7(v6.id)

				local model = v6.model

				task.spawn(function() --[[ Line: 440 | Upvalues: model (copy), RunService (ref) ]]
					local v1 = model:GetPivot()
					local sum2 = 0

					while sum2 < 0.35 and model.Parent do
						sum2 = sum2 + RunService.Heartbeat:Wait()

						local v2 = math.clamp(sum2 / 0.35, 0, 1)

						model:PivotTo(v1 * CFrame.new(0, v2 * -4 * v2, 0))
					end

					model:Destroy()
				end)
			end

			continue
		end

		local model = v6.model

		if model.Parent then
			if v3 and v3.fish == v6 then
				local v8 = math.clamp((v3.progress - Minigame.StartProgress) / (1 - Minigame.StartProgress), 0, 1)
				local v12 = Vector3.new(math.noise(v2 * 6, v6.phase) * 1.2, math.noise(v6.phase, v2 * 6) * 0.8, math.noise(v2 * 6, -v6.phase) * 1.2)

				v4 = v6.basePosition:Lerp(v3.pullTo, v8 * 0.6) + v12
				DeepsState.fightTarget = v4
			else
				local v15 = Vector3.new(math.noise(v2 * 0.12, v6.phase) * 4, 0, math.noise(v6.phase, v2 * 0.12) * 4)

				v4 = v6.basePosition + v15 + Vector3.new(0, math.sin((v2 + v6.phase) * 6.283185307179586 / 2.6) * 0.5, 0)
			end

			local v18 = v4 - v6.lastPosition
			local v19 = Vector3.new(v18.X, 0, v18.Z)

			if v19.Magnitude > 0.01 then
				local v22 = math.atan2(-v19.X, -v19.Z)
				local v27 = math.atan2(math.sin(v22 - v6.yaw), (math.cos(v22 - v6.yaw)))

				v6.yaw = v6.yaw + v27 * math.min(p1 * 4, 1)
			end

			v6.lastPosition = v4
			model:PivotTo(CFrame.new(v4) * CFrame.Angles(0, v6.yaw, 0))

			local v28 = t7[v6.id]

			if v28 then
				seatCastHook(v28, v6)
			end
		end
	end

	for v29, v30 in t4 do
		if v30.expiresAt <= v1 and t4[v30.id] == v30 then
			t4[v30.id] = nil

			local model = v30.model

			task.spawn(function() --[[ Line: 711 | Upvalues: model (copy), RunService (ref) ]]
				local v1 = model:GetPivot()
				local sum2 = 0

				while sum2 < 0.35 and model.Parent do
					sum2 = sum2 + RunService.Heartbeat:Wait()

					local v2 = math.clamp(sum2 / 0.35, 0, 1)

					model:PivotTo(v1 * CFrame.new(0, v2 * -3 * v2, 0))
				end

				model:Destroy()
			end)
		end
	end
end

function t.Init(p1) --[[ Init | Line: 1684 | Upvalues: DeepsConfig (copy), Remotes (copy), addFish (copy), t3 (copy), v11 (ref), playCaughtByOther (copy), v7 (ref), RunService (copy), updateFishStatus (copy), t7 (copy), startCastRig (copy), stopCastRig (copy), addItem (copy), t4 (copy), removeItemLocal (copy), Players (copy), t6 (copy), ClientPlayerData (copy), ConvertValue (copy), t2 (copy), DeepsState (copy), LocalPlayer (copy), getClickFast (copy), teardownFight (copy), v9 (ref), v10 (ref), UserInputService (copy), pumpFight (copy), stepFight (copy), stepFish (copy), stepBillboards (copy), updateFightCamera (copy), pickTarget (copy), v5 (ref), Workspace (copy) ]]
	if DeepsConfig.Enabled then
		Remotes.DeepsFishSpawn:On(function(p1) --[[ Line: 1689 | Upvalues: addFish (ref) ]]
			if type(p1) ~= "table" then
				return
			end

			if type(p1.Fish) ~= "table" then
				return
			end

			for v1, v2 in p1.Fish do
				addFish(v2)
			end
		end)
		Remotes.DeepsFishRemoved:On(function(p1) --[[ Line: 1698 | Upvalues: t3 (ref), v11 (ref), playCaughtByOther (ref), v7 (ref), RunService (ref) ]]
			if type(p1) ~= "table" then
				return
			end

			if type(p1.Id) ~= "number" then
				return
			end

			local v1 = t3[p1.Id]

			if not v1 then
				return
			end

			local v2 = v11

			if v2 and v2.fish == v1 then
				playCaughtByOther(v1, p1.ByUserId)

				return
			end

			if p1.Caught == true then
				playCaughtByOther(v1, p1.ByUserId)

				return
			end

			if t3[v1.id] == v1 then
				t3[v1.id] = nil
				v7(v1.id)

				local model = v1.model

				task.spawn(function() --[[ Line: 440 | Upvalues: model (copy), RunService (ref) ]]
					local v1 = model:GetPivot()
					local sum2 = 0

					while sum2 < 0.35 and model.Parent do
						sum2 = sum2 + RunService.Heartbeat:Wait()

						local v2 = math.clamp(sum2 / 0.35, 0, 1)

						model:PivotTo(v1 * CFrame.new(0, v2 * -4 * v2, 0))
					end

					model:Destroy()
				end)
			end
		end)
		Remotes.DeepsFishBusy:On(function(p1) --[[ Line: 1722 | Upvalues: t3 (ref), updateFishStatus (ref), t7 (ref), startCastRig (ref), stopCastRig (ref) ]]
			if type(p1) ~= "table" then
				return
			end

			if type(p1.Id) ~= "number" then
				return
			end

			local v1 = t3[p1.Id]

			if not v1 then
				return
			end

			v1.busyByUserId = if type(p1.ByUserId) == "number" then p1.ByUserId else nil
			updateFishStatus(v1)

			local busyByUserId = v1.busyByUserId
			local v3 = t7[v1.id]

			if busyByUserId then
				if v3 and v3.userId == busyByUserId then
					return
				end

				startCastRig(busyByUserId, v1, nil)

				return
			end

			if not v3 then
				return
			end

			stopCastRig(v3)
		end)
		Remotes.DeepsItemSpawn:On(function(p1) --[[ Line: 1736 | Upvalues: addItem (ref) ]]
			if type(p1) ~= "table" then
				return
			end

			if type(p1.Items) ~= "table" then
				return
			end

			for v1, v2 in p1.Items do
				addItem(v2)
			end
		end)
		Remotes.DeepsItemRemoved:On(function(p1) --[[ Line: 1745 | Upvalues: t4 (ref), removeItemLocal (ref) ]]
			if type(p1) ~= "table" then
				return
			end

			if type(p1.Id) ~= "number" then
				return
			end

			local v1 = t4[p1.Id]

			if not v1 then
				return
			end

			removeItemLocal(v1, p1.Taken == true)
		end)
		task.spawn(function() --[[ Line: 1757 | Upvalues: Remotes (ref), addFish (ref), t3 (ref), t7 (ref), startCastRig (ref), stopCastRig (ref), addItem (ref) ]]
			local v1, v2 = Remotes.DeepsSync:Call():Await()

			if not v1 or type(v2) ~= "table" then
				return
			end

			if type(v2.Fish) == "table" then
				for v3, v4 in v2.Fish do
					addFish(v4)

					local v5 = if type(v4) == "table" then t3[v4.Id] else false

					if v5 then
						local busyByUserId = v5.busyByUserId
						local v6 = t7[v5.id]

						if busyByUserId then
							if not v6 or v6.userId ~= busyByUserId then
								startCastRig(busyByUserId, v5, true)
							end

							continue
						end

						if v6 then
							stopCastRig(v6)
						end
					end
				end
			end

			if type(v2.Items) ~= "table" then
				return
			end

			for v7, v8 in v2.Items do
				addItem(v8)
			end
		end)
		Players.PlayerRemoving:Connect(function(p1) --[[ Line: 1783 | Upvalues: t6 (ref), stopCastRig (ref) ]]
			local v1 = t6[p1.UserId]

			if not v1 then
				return
			end

			stopCastRig(v1)
		end)
		ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 1789 ]]
			return p1.strength
		end, function() --[[ Line: 1791 | Upvalues: t3 (ref), ClientPlayerData (ref), DeepsConfig (ref), ConvertValue (ref), t2 (ref) ]]
			for v3, v4 in t3 do
				local v1, v2
				local powerLabel = v4.powerLabel

				if powerLabel then
					local strength = v4.strength
					local v6 = DeepsConfig.GetStrengthRatio(strength, ClientPlayerData.serverProfile:getState().strength or 0)
					local v7 = ConvertValue.suffixformat(strength)
					local v8 = v6

					do
						local __inline_returned = false

						for v9, v10 in t2 do
							if v8 <= v10.MaxRatio then
								v1 = v10.Color
								v2 = v7
								__inline_returned = true

								break
							end
						end

						if not __inline_returned then
							v1 = t2[#t2].Color
							v2 = v7
						end
					end

					powerLabel.Text = v2
					powerLabel.TextColor3 = v1
				end
			end
		end)
		DeepsState.DiveStarted:Connect(function() --[[ Line: 1800 | Upvalues: LocalPlayer (ref), DeepsConfig (ref), getClickFast (ref) ]]
			local PlayerGui = LocalPlayer:FindFirstChildOfClass("PlayerGui")
			local v1 = if PlayerGui then PlayerGui:FindFirstChild("MainUI") else PlayerGui
			local v2 = if v1 then v1:FindFirstChild(DeepsConfig.UiFrameName) else v1
			local v3 = if v2 and v2:IsA("Frame") then v2 else nil

			if not v3 then
				return
			end

			local CatchFishBar = v3:FindFirstChild("CatchFishBar")

			if CatchFishBar and CatchFishBar:IsA("GuiObject") then
				CatchFishBar.Visible = false
			end

			local v4 = getClickFast()

			if not v4 then
				return
			end

			v4.frame.Visible = false
		end)
		DeepsState.DiveEnded:Connect(function() --[[ Line: 1803 | Upvalues: v11 (ref), teardownFight (ref), updateFishStatus (ref), v9 (ref), v10 (ref) ]]
			local v1 = v11

			v11 = nil

			if v1 then
				teardownFight(v1)
				v1.fish.beingCaught = false
				updateFishStatus(v1.fish)
			end

			v9 = nil

			local v2 = v10

			if not v2 then
				return
			end

			v2.Enabled = false
			v2.Adornee = nil
		end)
		UserInputService.InputBegan:Connect(function(p1, p2) --[[ Line: 1822 | Upvalues: v11 (ref), LocalPlayer (ref), pumpFight (ref) ]]
			local v1 = v11

			if not v1 then
				return
			end

			local UserInputType = p1.UserInputType

			if UserInputType ~= Enum.UserInputType.MouseButton1 and UserInputType ~= Enum.UserInputType.Touch then
				return
			end

			if not p2 then
				pumpFight()

				return
			end

			local PlayerGui = LocalPlayer:FindFirstChildOfClass("PlayerGui")
			local root = v1.ui.root

			if not (PlayerGui and root.Parent) then
				return
			end

			local v2 = false

			for v3, v4 in PlayerGui:GetGuiObjectsAtPosition(p1.Position.X, p1.Position.Y) do
				if v4 == root or v4:IsDescendantOf(root) then
					v2 = true

					break
				end
			end

			if v2 then
				pumpFight()
			end
		end)
		RunService.Heartbeat:Connect(function(p1) --[[ Line: 1854 | Upvalues: stepFight (ref), stepFish (ref), stepBillboards (ref), updateFightCamera (ref), pickTarget (ref), v9 (ref), v10 (ref), v5 (ref), DeepsConfig (ref), Workspace (ref) ]]
			debug.profilebegin("UECS/DeepsFishing.Step")
			stepFight(p1)
			stepFish(p1)
			stepBillboards()
			updateFightCamera(p1)

			local v1 = pickTarget()

			if v1 ~= v9 then
				v9 = v1

				local v2 = v10
				local v3

				if v2 and v2.Parent then
					v3 = v2
				else
					local DeepsFishTarget = Instance.new("Highlight")

					DeepsFishTarget.Name = "DeepsFishTarget"
					DeepsFishTarget.FillTransparency = 1
					DeepsFishTarget.OutlineColor = Color3.fromRGB(170, 255, 255)
					DeepsFishTarget.OutlineTransparency = 0
					DeepsFishTarget.Enabled = false

					local v4 = v5
					local v52

					if v4 and v4.Parent then
						v52 = v4
					else
						local v6 = Instance.new("Folder")

						v6.Name = DeepsConfig.ClientFishFolderName
						v6.Parent = Workspace
						v5 = v6
						v52 = v6
					end

					DeepsFishTarget.Parent = v52
					v10 = DeepsFishTarget
					v3 = DeepsFishTarget
				end

				v3.Adornee = if v1 then v1.model else nil
				v3.Enabled = v1 ~= nil
			end

			debug.profileend()
		end)
	end
end

return t