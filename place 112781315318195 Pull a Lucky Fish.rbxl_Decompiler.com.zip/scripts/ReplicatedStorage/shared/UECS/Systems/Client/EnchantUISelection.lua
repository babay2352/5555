-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ContextActionService = game:GetService("ContextActionService")
local GamepadService = game:GetService("GamepadService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local ControlHint = require(ReplicatedStorage.client.ControlHint)

require(ReplicatedStorage.shared.UECS.Components.EnchantUI)

local EnchantUISelection = require(ReplicatedStorage.shared.UECS.Components.EnchantUISelection)
local FishRodConfig = require(ReplicatedStorage.shared.config.FishRodConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local TrainToolConfig = require(ReplicatedStorage.shared.config.TrainToolConfig)
local bindToButtonPress = require(ReplicatedStorage.shared.util.bindToButtonPress)
local t = {
	UECS = nil,
	Priority = 30
}

local function findChildOfClass(p1, p2, p3) --[[ findChildOfClass | Line: 31 ]]
	for v1, v2 in p1:GetChildren() do
		if v2.ClassName == p2 and (p3 == nil or v2.Name == p3) then
			return v2
		end
	end

	return nil
end

function t.Init(p1) --[[ Init | Line: 40 | Upvalues: Players (copy), EnchantUISelection (copy), ClientPlayerData (copy), FishRodConfig (copy), TrainToolConfig (copy), ControlHint (copy), GamepadService (copy), bindToButtonPress (copy), ContextActionService (copy) ]]
	local MainUI = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI")
	local EnchantUISelection2 = MainUI:WaitForChild("EnchantUISelection")
	local TopBar = EnchantUISelection2:WaitForChild("TopBar")
	local v1 = EnchantUISelection2:WaitForChild("Content")
	local Rod = v1:WaitForChild("Rod")
	local Barbells = v1:WaitForChild("Barbells")

	EnchantUISelection2.Visible = false

	local v2 = EnchantUISelection.Add(EnchantUISelection2)

	local function getState() --[[ getState | Line: 51 | Upvalues: ClientPlayerData (ref) ]]
		return ClientPlayerData.serverProfile:getState()
	end

	local function fillCard(p1, p2, p3) --[[ fillCard | Line: 56 ]]
		local v1 = nil

		for v2, v3 in p1:GetChildren() do
			if v3.ClassName == "TextLabel" and v3.Name == "ItemName" then
				v1 = v3

				break
			end
		end

		if v1 then
			v1.Text = if p2 then p2.DisplayName else "Nothing equipped"
		end

		local v5 = nil

		for v6, v7 in p1:GetChildren() do
			if v7.ClassName == "TextLabel" and v7.Name == "Rarity" then
				v5 = v7

				break
			end
		end

		if v5 and p2 then
			v5.Text = p2.Rarity.displayName
			v5.TextColor3 = p2.Rarity.rarityColor
		elseif v5 then
			v5.Text = ""
		end

		for v8, v9 in p1:GetChildren() do
			if v9.Name == "ToolIcon" and (v9:IsA("ImageLabel") or v9:IsA("ImageButton")) then
				v9.Image = if p2 then p2.Icon or "" else ""
			end
		end

		local AddTrainValue = p1:FindFirstChild("AddTrainValue")
		local v11 = if AddTrainValue then AddTrainValue:FindFirstChild("Value") else AddTrainValue

		if not v11 then
			return
		end

		v11.Text = p3 or ""
	end

	local function refreshCards() --[[ refreshCards | Line: 85 | Upvalues: ClientPlayerData (ref), FishRodConfig (ref), fillCard (copy), Rod (copy), TrainToolConfig (ref), Barbells (copy) ]]
		local v1 = ClientPlayerData.serverProfile:getState()
		local v2 = FishRodConfig[v1.fishRod]
		local v5, v6

		if v2 then
			v5 = ("x%* Luck"):format(v2.LuckMultiplier)

			if v5 then
				v6 = v2
			else
				v6 = v2
				v5 = nil
			end
		else
			v6 = v2
			v5 = nil
		end

		fillCard(Rod, v6, v5)

		local v7 = TrainToolConfig[v1.trainingTool]
		local v10, v11

		if v7 then
			v10 = ("+%* Strength"):format(v7.AddStrength)

			if v10 then
				v11 = v7
			else
				v11 = v7
				v10 = nil
			end
		else
			v11 = v7
			v10 = nil
		end

		fillCard(Barbells, v11, v10)
	end

	local function openEnchantUI(p12) --[[ openEnchantUI | Line: 96 | Upvalues: p1 (copy) ]]
		local v1 = p1.UECS:WaitForAnyComponent("EnchantUI")

		v1.Target:Set(p12)
		p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(v1)
	end

	local v3 = nil

	for v4, v5 in Rod:GetChildren() do
		if v5.ClassName == "ImageButton" and v5.Name == "ToolIcon" then
			v3 = v5

			break
		end
	end

	if v3 then
		v3.Selectable = true
		v3.Activated:Connect(function() --[[ Line: 107 | Upvalues: p1 (copy) ]]
			local v1 = p1.UECS:WaitForAnyComponent("EnchantUI")

			v1.Target:Set("Rod")
			p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(v1)
		end)
	else
		warn("[EnchantUISelection] Rod card has no ToolIcon ImageButton \226\128\148 rod page unreachable")
	end

	local v6 = nil

	for v7, v8 in Barbells:GetChildren() do
		if v8.ClassName == "ImageButton" and v8.Name == "ToolIcon" then
			v6 = v8

			break
		end
	end

	if v6 then
		v6.Selectable = true
		v6.Activated:Connect(function() --[[ Line: 116 | Upvalues: p1 (copy) ]]
			local v1 = p1.UECS:WaitForAnyComponent("EnchantUI")

			v1.Target:Set("Barbell")
			p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(v1)
		end)
	else
		warn("[EnchantUISelection] Barbells card has no ToolIcon ImageButton \226\128\148 barbell page unreachable")
	end

	local CloseButton = TopBar:WaitForChild("CloseButton")

	CloseButton.Active = true
	CloseButton.Selectable = true

	local function closePanel() --[[ closePanel | Line: 129 | Upvalues: p1 (copy) ]]
		p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
	end

	CloseButton.Activated:Connect(closePanel)

	local v9 = ControlHint.new({
		label = "",
		anchorTo = CloseButton,
		keyCode = Enum.KeyCode.ButtonB
	})

	v9:Hide()
	v2.Visible.OnChange:Connect(function(p12) --[[ Line: 140 | Upvalues: EnchantUISelection2 (copy), MainUI (copy), p1 (copy), GamepadService (ref), bindToButtonPress (ref), closePanel (copy), v9 (copy), ContextActionService (ref), refreshCards (copy) ]]
		EnchantUISelection2.Visible = p12

		local HUD = MainUI:FindFirstChild("HUD")

		if HUD and p12 then
			HUD.Visible = false
		elseif HUD then
			HUD.Visible = not p1.UECS:WaitForAnyComponent("EnchantUI").Visible:Get()
		end

		if p12 then
			GamepadService:EnableGamepadCursor(EnchantUISelection2)
			bindToButtonPress("EnchantUISelectionClose", Enum.KeyCode.ButtonB, closePanel)
			v9:Show()
		else
			ContextActionService:UnbindAction("EnchantUISelectionClose")
			v9:Hide()

			if not p1.UECS:WaitForAnyComponent("EnchantUI").Visible:Get() then
				GamepadService:DisableGamepadCursor()
			end
		end

		if not p12 then
			return
		end

		refreshCards()
	end)
	GamepadService:GetPropertyChangedSignal("GamepadCursorEnabled"):Connect(function() --[[ Line: 174 | Upvalues: GamepadService (ref), EnchantUISelection2 (copy) ]]
		if GamepadService.GamepadCursorEnabled or not EnchantUISelection2.Visible then
			return
		end

		GamepadService:EnableGamepadCursor(EnchantUISelection2)
	end)
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 180 ]]
		return p1.fishRod
	end, refreshCards)
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 183 ]]
		return p1.trainingTool
	end, refreshCards)
	refreshCards()
end

return t