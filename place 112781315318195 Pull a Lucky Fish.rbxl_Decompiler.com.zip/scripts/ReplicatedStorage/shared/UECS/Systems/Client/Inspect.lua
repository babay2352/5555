-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")

game:GetService("GamepadService")

local GuiService = game:GetService("GuiService")
local HttpService = game:GetService("HttpService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TextService = game:GetService("TextService")
local UserInputService = game:GetService("UserInputService")
local ActiveEffects = require(ReplicatedStorage.shared.effects.ActiveEffects)

require(ReplicatedStorage.shared.config.BiomesConfig)

local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local DecorationConfig = require(ReplicatedStorage.shared.config.DecorationConfig)
local EnchantConfig = require(ReplicatedStorage.shared.config.EnchantConfig)
local DecorationsStoreConfig = require(ReplicatedStorage.shared.config.DecorationsStoreConfig)
local EventsConfig = require(ReplicatedStorage.shared.config.EventsConfig)
local FishConfig = require(ReplicatedStorage.shared.config.FishConfig)
local FishRodConfig = require(ReplicatedStorage.shared.config.FishRodConfig)
local FishingFloatsConfig = require(ReplicatedStorage.shared.config.FishingFloatsConfig)
local FootballEventConfig = require(ReplicatedStorage.shared.config.FootballEventConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local InspectFocus = require(ReplicatedStorage.shared.module.InspectFocus)
local PotionConfig = require(ReplicatedStorage.shared.config.PotionConfig)
local RollClass = require(ReplicatedStorage.shared.util.RollClass)
local TrainToolConfig = require(ReplicatedStorage.shared.config.TrainToolConfig)
local Worlds = require(ReplicatedStorage.shared.util.Worlds)
local WorldsConfig = require(ReplicatedStorage.shared.config.WorldsConfig)
local abbreviateNumber = require(ReplicatedStorage.shared.util.abbreviateNumber)
local createInstance = require(ReplicatedStorage.shared.util.createInstance)
local getBossPool = require(ReplicatedStorage.shared.util.getBossPool)
local getPlayerPoolLuck = require(ReplicatedStorage.shared.util.getPlayerPoolLuck)
local getRodEnchantBonus = require(ReplicatedStorage.shared.util.getRodEnchantBonus)
local rarityConfig = require(ReplicatedStorage.shared.config.rarityConfig)

local function catchZonesLine(p1) --[[ catchZonesLine | Line: 54 | Upvalues: WorldsConfig (copy), Worlds (copy) ]]
	local v1 = table.clone(WorldsConfig.Ordered())
	local v2 = Worlds.GetLocalWorldId()

	table.sort(v1, function(p1, p2) --[[ Line: 57 | Upvalues: v2 (copy) ]]
		if (if p1.Id == v2 then true else false) == (if p2.Id == v2 then true else false) then
			return p1.LayoutOrder < p2.LayoutOrder
		end

		return p1.Id == v2
	end)

	local count = 0
	local sum = 0
	local t = {}

	for v3, v4 in v1 do
		local v5 = Worlds.GetBiomes(v4.Id)

		if #v5 ~= 0 and Worlds.GetWorldIdOfBiome(v5[1].id) == v4.Id then
			local t2 = {}

			for v6, v7 in v5 do
				count = count + 1

				if p1(v7) then
					table.insert(t2, v7.DisplayName)
				end
			end

			sum = sum + #t2

			if #t2 ~= 0 then
				local v8 = if #t2 == #v5 then "Any zone" else table.concat(t2, ", ")

				table.insert(t, if #v1 > 1 then ("Catch in %*: %*"):format(v4.Title, v8) else ("Catch in: %*"):format(v8))
			end
		end
	end

	if sum == 0 then
		return "Special fish"
	end

	if sum == count then
		return "Catch in: Any zone"
	end

	return table.concat(t, "\n")
end

local t = {
	Cats = "Only from the Cat Luckyblock",
	Aliens = "Only from the Alien Event ocean"
}

local function describeCatch(p1, p2) --[[ describeCatch | Line: 111 | Upvalues: t (copy), FootballEventConfig (copy), catchZonesLine (copy), RollClass (copy) ]]
	if p2.Event then
		local EventName = p2.EventName

		return (if typeof(EventName) == "string" then t[EventName] else nil) or "Only from a limited-time event"
	end

	if p2.Football and not FootballEventConfig.Enabled then
		return "Only during the Football event"
	end

	if p2.Boss then
		return catchZonesLine(function(p12) --[[ Line: 126 | Upvalues: RollClass (ref), p1 (copy) ]]
			return RollClass.canBossDropInBiome(p1, p12)
		end)
	end

	if p2.Beast then
		local v2 = catchZonesLine(function(p12) --[[ Line: 131 | Upvalues: RollClass (ref), p1 (copy) ]]
			return RollClass.canBeastDropInBiome(p1, p12)
		end)
		local Weather = p2.Weather

		if typeof(Weather) == "string" and v2 ~= "Special fish" then
			v2 = v2 .. ("\nOnly during %* weather"):format(Weather)
		end

		return v2
	end

	if p2.EarningsPercent == nil then
		return catchZonesLine(function(p1) --[[ Line: 144 | Upvalues: p2 (copy) ]]
			return p1.RarityWeights[p2.Rarity.id] ~= nil
		end)
	end

	return "Exclusive fish"
end

return {
	UECS = nil,
	Init = function(p1) --[[ Init | Line: 152 | Upvalues: Players (copy), TextService (copy), createInstance (copy), WorldsConfig (copy), ReplicatedStorage (copy), HttpService (copy), rarityConfig (copy), abbreviateNumber (copy), getBossPool (copy), getPlayerPoolLuck (copy), getRodEnchantBonus (copy), EventsConfig (copy), ActiveEffects (copy), CollectionService (copy), PotionConfig (copy), FishingFloatsConfig (copy), ClientPlayerData (copy), EnchantConfig (copy), FishRodConfig (copy), TrainToolConfig (copy), DecorationConfig (copy), DecorationsStoreConfig (copy), FishConfig (copy), describeCatch (copy), InspectFocus (copy), GuiService (copy), RunService (copy), UserInputService (copy) ]]
		local LocalPlayer = Players.LocalPlayer
		local v1 = LocalPlayer:GetMouse()
		local PlayerGui = LocalPlayer:WaitForChild("PlayerGui")
		local Inspect = PlayerGui:WaitForChild("MainUI"):WaitForChild("Inspect")

		Inspect.ZIndex = Inspect.ZIndex + 1

		for v2, v3 in Inspect:GetDescendants() do
			if v3:IsA("GuiObject") then
				v3.ZIndex = v3.ZIndex + 1
			end
		end

		local ContentFrame = Inspect.TopBar.ContentFrame
		local Icon = ContentFrame.Icon
		local Title = ContentFrame.Title
		local Rarity = Inspect.Content.Rarity
		local Desc = Inspect.Content.Desc

		Inspect.Visible = false

		local Size = Inspect.Size
		local Offset = Desc.Size.Y.Offset

		Desc.TextWrapped = true

		local v4 = 0

		local function fitToDesc() --[[ fitToDesc | Line: 190 | Upvalues: Desc (copy), TextService (ref), Offset (copy), Inspect (copy), Size (copy), v4 (ref) ]]
			local X = Desc.AbsoluteSize.X
			local Offset2 = Desc.Size.Y.Offset

			if X > 0 then
				local Y = TextService:GetTextSize(Desc.Text, Desc.TextSize, Desc.Font, Vector2.new(math.max(X - 8, 1), (1 / 0))).Y
				local v3 = math.max(Offset, math.ceil(Y) + 24)

				Desc.Size = UDim2.new(Desc.Size.X.Scale, Desc.Size.X.Offset, 0, v3)
				Offset2 = v3
			end

			Inspect.Size = UDim2.new(Size.X.Scale, Size.X.Offset, Size.Y.Scale, Size.Y.Offset + (Offset2 - Offset) + v4)
		end

		local v5 = Color3.fromRGB(33, 203, 255)
		local v6 = Color3.fromRGB(255, 110, 110)
		local v7 = Color3.fromRGB(200, 200, 200)
		local v8 = Color3.fromRGB(255, 215, 0)
		local v9 = Color3.fromRGB(90, 90, 90)

		Desc.ClipsDescendants = false

		local v10 = createInstance("Frame", Desc, "BossPool", {
			BackgroundTransparency = 1,
			Visible = false,
			AnchorPoint = Vector2.new(0.5, 0),
			Position = UDim2.new(0.5, 0, 1, 10),
			Size = UDim2.new(1, 0, 0, 0),
			ZIndex = Desc.ZIndex + 1
		})

		createInstance("UIListLayout", v10, {
			Padding = UDim.new(0, 4),
			SortOrder = Enum.SortOrder.LayoutOrder
		})

		local function bossWorldsText(p1) --[[ bossWorldsText | Line: 259 | Upvalues: WorldsConfig (ref) ]]
			if not p1 or #p1 == 0 then
				return "Every world"
			end

			local t = {}

			for v1, v2 in p1 do
				local v3 = WorldsConfig.Get(v2)

				table.insert(t, if v3 then v3.Title else ("World %*"):format(v2))
			end

			return table.concat(t, ", ")
		end

		local function bossStocks() --[[ bossStocks | Line: 273 | Upvalues: ReplicatedStorage (ref), HttpService (ref) ]]
			local v1 = ReplicatedStorage:GetAttribute("fishStocks")

			if typeof(v1) ~= "string" then
				return {}
			end

			local ok, result = pcall(function() --[[ Line: 278 | Upvalues: HttpService (ref), v1 (copy) ]]
				return HttpService:JSONDecode(v1)
			end)

			if ok and typeof(result) == "table" then
				return result
			end

			return {}
		end

		local function bossRowLabel(p1, p2, p3) --[[ bossRowLabel | Line: 287 | Upvalues: Desc (copy), createInstance (ref) ]]
			local t = {
				BackgroundTransparency = 1,
				TextSize = 14,
				FontFace = Desc.FontFace,
				TextTruncate = Enum.TextTruncate.AtEnd,
				ZIndex = p1.ZIndex + 1
			}

			for v1, v2 in p3 do
				t[v1] = v2
			end

			return createInstance("TextLabel", p1, p2, t)
		end

		local function addBossRow(p1, p2, p3) --[[ addBossRow | Line: 301 | Upvalues: createInstance (ref), v10 (copy), v9 (copy), bossRowLabel (copy), rarityConfig (ref), v6 (copy), v5 (copy), bossWorldsText (copy), v7 (copy), abbreviateNumber (ref), v8 (copy) ]]
			local v1 = if p2 <= 0 then true else false
			local v2 = createInstance("Frame", v10, p1.Name, {
				BackgroundTransparency = 1,
				LayoutOrder = p3,
				Size = UDim2.new(1, 0, 0, 42),
				ZIndex = v10.ZIndex
			})
			local t = {
				BackgroundTransparency = 1,
				Image = p1.Image
			}

			t.ImageColor3 = if v1 then v9 else Color3.new(255/255, 255/255, 255/255)
			t.ImageTransparency = if v1 then 0.3 else 0
			t.Position = UDim2.fromOffset(0, 1)
			t.Size = UDim2.fromOffset(40, 40)
			t.ScaleType = Enum.ScaleType.Fit
			t.ZIndex = v2.ZIndex + 1
			createInstance("ImageLabel", v2, "Icon", t)
			bossRowLabel(v2, "BossName", {
				TextSize = 15,
				Position = UDim2.fromOffset(48, 0),
				Size = UDim2.new(1, -144, 0, 21),
				Text = p1.DisplayName,
				TextColor3 = rarityConfig.Boss.rarityColor,
				TextXAlignment = Enum.TextXAlignment.Left
			})

			local t2 = {
				Position = UDim2.new(1, -96, 0, 0),
				Size = UDim2.new(0, 96, 0, 21)
			}

			t2.Text = if v1 then "SOLD OUT" else ("x%* left"):format(p2)
			t2.TextColor3 = if v1 then v6 else v5
			t2.TextXAlignment = Enum.TextXAlignment.Right
			bossRowLabel(v2, "Stock", t2)
			bossRowLabel(v2, "World", {
				TextSize = 13,
				Position = UDim2.fromOffset(48, 21),
				Size = UDim2.new(1, -144, 0, 21),
				Text = bossWorldsText(p1.Worlds),
				TextColor3 = v7,
				TextXAlignment = Enum.TextXAlignment.Left
			})
			bossRowLabel(v2, "Odds", {
				TextSize = 13,
				Position = UDim2.new(1, -96, 0, 21),
				Size = UDim2.new(0, 96, 0, 21),
				Text = ("1 in %*"):format((abbreviateNumber(p1.OneIn))),
				TextColor3 = v8,
				TextXAlignment = Enum.TextXAlignment.Right
			})
		end

		local function refreshBossList() --[[ refreshBossList | Line: 357 | Upvalues: v10 (copy), getBossPool (ref), getPlayerPoolLuck (ref), LocalPlayer (copy), getRodEnchantBonus (ref), bossStocks (copy), addBossRow (copy) ]]
			for v1, v2 in v10:GetChildren() do
				if v2:IsA("GuiObject") then
					v2:Destroy()
				end
			end

			local v3 = getBossPool(getPlayerPoolLuck(LocalPlayer), getRodEnchantBonus(LocalPlayer, "BossHunter"))

			if #v3 == 0 then
				return 0
			end

			local v4 = bossStocks()

			for v5, v6 in v3 do
				addBossRow(v6, tonumber(v4[v6.Name]) or 0, v5)
			end

			local v9 = #v3 * 42 + (#v3 - 1) * 4

			v10.Size = UDim2.new(1, 0, 0, v9)

			return v9 + 20
		end

		local v11 = 0
		local t = {
			Event = function(p1) --[[ Line: 394 | Upvalues: EventsConfig (ref), Icon (copy), ActiveEffects (ref), Title (copy), Rarity (copy), CollectionService (ref), Desc (copy) ]]
				local v1 = p1:GetAttribute("EventName")
				local v2 = if typeof(v1) == "string" then EventsConfig[v1] else nil

				if not v2 then
					return false
				end

				Icon.Image = v2.Icon

				local DisplayName = v2.DisplayName

				for v3, v4 in ActiveEffects.GetActive() do
					if v4.Name == v1 and v4.DisplayNameOverride then
						DisplayName = v4.DisplayNameOverride

						break
					end
				end

				Title.Text = DisplayName
				Rarity.Text = v2.Rarity.displayName
				Rarity.TextColor3 = v2.Rarity.rarityColor

				if v1 == "ExclusiveLuckyHour" then
					Rarity:SetAttribute("RarityId", v2.Rarity.id)
					CollectionService:AddTag(Rarity, "AnimatedRarity")
				else
					CollectionService:RemoveTag(Rarity, "AnimatedRarity")
				end

				Desc.Text = v2.Desc

				return true
			end,
			Potion = function(p1) --[[ Line: 421 | Upvalues: PotionConfig (ref), Icon (copy), Title (copy), Rarity (copy), CollectionService (ref), Desc (copy) ]]
				local v1 = p1:GetAttribute("PotionConfigName")
				local v2 = if typeof(v1) == "string" then PotionConfig.Potions[v1] else nil

				if v2 then
					Icon.Image = v2.Icon
					Title.Text = v2.DisplayName
					Rarity.Text = v2.Rarity.displayName
					Rarity.TextColor3 = v2.Rarity.rarityColor
					CollectionService:RemoveTag(Rarity, "AnimatedRarity")
					Desc.Text = ("%* for %* min"):format(v2.EffectDescription, v2.Duration / 60)

					return true
				end

				return false
			end,
			Stock = function(p1) --[[ Line: 436 | Upvalues: Icon (copy), Title (copy), Desc (copy), Rarity (copy), v5 (copy), CollectionService (ref), v4 (ref), refreshBossList (copy), v10 (copy) ]]
				local v1 = p1:GetAttribute("stockAmount")

				Icon.Image = "rbxassetid://127163014827377"
				Title.Text = "BOSS fishes in stock!"
				Desc.Text = "You can now catch BOSS fishes while the stock is there.\nOdds are per cast, at your current luck."
				Rarity.Text = ("Stock: %*"):format(v1)
				Rarity.TextColor3 = v5
				CollectionService:RemoveTag(Rarity, "AnimatedRarity")
				v4 = refreshBossList()
				v10.Visible = false

				return true
			end,
			Luck = function(p1) --[[ Line: 452 | Upvalues: Icon (copy), Title (copy), getPlayerPoolLuck (ref), LocalPlayer (copy), Rarity (copy), CollectionService (ref), Desc (copy) ]]
				Icon.Image = "rbxassetid://132785761242424"
				Title.Text = "Your Luck"

				local v1 = getPlayerPoolLuck(LocalPlayer)

				Rarity.Text = if v1 >= 1000 then string.format("x%s", (tostring((math.floor(v1))))) else string.format("x%.1f", v1)
				Rarity.TextColor3 = Color3.fromRGB(255, 215, 0)
				CollectionService:RemoveTag(Rarity, "AnimatedRarity")
				Desc.Text = "Total luck from rod, events and bonuses"

				return true
			end,
			FishingFloat = function(p1) --[[ Line: 469 | Upvalues: FishingFloatsConfig (ref), Icon (copy), Title (copy), Rarity (copy), CollectionService (ref), Desc (copy) ]]
				local v1 = p1:GetAttribute("FloatName")
				local v2 = p1:GetAttribute("FloatTier")
				local v3 = if typeof(v1) == "string" then FishingFloatsConfig.Floats[v1] else nil

				if not v3 then
					return false
				end

				Icon.Image = v3.Image or ""
				Title.Text = v3.DisplayName

				if typeof(v2) == "string" and FishingFloatsConfig.TierColors[v2] then
					Rarity.Text = v2
					Rarity.TextColor3 = FishingFloatsConfig.TierColors[v2]
				else
					Rarity.Text = ""
				end

				CollectionService:RemoveTag(Rarity, "AnimatedRarity")

				local Description = v3.Description

				if typeof(v2) == "string" and v3.Tiers[v2] then
					local v4 = v3.Tiers[v2]
					local Effect = v3.Effect

					Description = ("%*\n%*"):format(Description, if Effect == "BeastBonus" then ("+%* Beast Chance"):format(v4) elseif Effect == "LuckyblockLuck" then ("+%* Luckyblock Luck"):format(v4) elseif Effect == "ExtraSlot" then ("+%* Extra Slot"):format(v4) elseif Effect == "GoldenGuarantee" then "Guaranteed Golden Mutation" else ("+%*%%"):format(math.floor(v4 * 1000) / 10))
				end

				Desc.Text = Description

				return true
			end
		}

		local function enchantLinesFor(p1, p2) --[[ enchantLinesFor | Line: 514 | Upvalues: ClientPlayerData (ref), EnchantConfig (ref) ]]
			local v1 = ClientPlayerData.serverProfile:getState()
			local v2 = v1.rodEnchants and v1.rodEnchants[p1]
			local t = {}

			if not v2 then
				return t
			end

			for v3, v4 in EnchantConfig.List do
				if v4.Target == p2 and v2[v4.Stat] == v4.Tier then
					table.insert(t, (("\226\128\162 %*"):format(v4.DisplayName)))
				end
			end

			return t
		end

		local function skipUnenchanted(p1, p2) --[[ skipUnenchanted | Line: 533 ]]
			return if #p2 == 0 then p1:GetAttribute("InspectRequiresEnchants") == true else false
		end

		function t.FishingRod(p1) --[[ Line: 537 | Upvalues: FishRodConfig (ref), enchantLinesFor (copy), Icon (copy), Title (copy), Rarity (copy), CollectionService (ref), Desc (copy) ]]
			local v1 = p1:GetAttribute("FishRod")
			local v2 = if typeof(v1) == "string" then FishRodConfig[v1] else nil

			if not v2 then
				return false
			end

			local v3 = enchantLinesFor(v1, "Rod")

			if if #v3 == 0 then p1:GetAttribute("InspectRequiresEnchants") == true else false then
				return false
			end

			Icon.Image = v2.Icon or ""
			Title.Text = v2.DisplayName
			Rarity.Text = v2.Rarity.id
			Rarity.TextColor3 = v2.Rarity.rarityColor
			CollectionService:RemoveTag(Rarity, "AnimatedRarity")

			local v5 = ("Luck: x%*"):format(v2.LuckMultiplier)

			if #v3 > 0 then
				v5 = v5 .. ("\nEnchants:\n%*"):format((table.concat(v3, "\n")))
			end

			Desc.Text = v5

			return true
		end
		function t.TrainingTool(p1) --[[ Line: 563 | Upvalues: TrainToolConfig (ref), enchantLinesFor (copy), Icon (copy), Title (copy), Rarity (copy), CollectionService (ref), Desc (copy) ]]
			local v1 = p1:GetAttribute("TrainingTool")
			local v2 = if typeof(v1) == "string" then TrainToolConfig[v1] else nil

			if not v2 then
				return false
			end

			local v3 = enchantLinesFor(v1, "Barbell")

			if if #v3 == 0 then p1:GetAttribute("InspectRequiresEnchants") == true else false then
				return false
			end

			Icon.Image = v2.Icon or ""
			Title.Text = v2.DisplayName
			Rarity.Text = v2.Rarity.displayName
			Rarity.TextColor3 = v2.Rarity.rarityColor
			CollectionService:RemoveTag(Rarity, "AnimatedRarity")

			local v5 = ("Strength: +%*"):format(v2.AddStrength)

			if #v3 > 0 then
				v5 = v5 .. ("\nEnchants:\n%*"):format((table.concat(v3, "\n")))
			end

			Desc.Text = v5

			return true
		end
		function t.Enchant(p1) --[[ Line: 590 | Upvalues: EnchantConfig (ref), Icon (copy), Title (copy), Rarity (copy), CollectionService (ref), Desc (copy) ]]
			local v1 = p1:GetAttribute("EnchantId")
			local v2 = if typeof(v1) == "string" then EnchantConfig.Enchants[v1] else nil

			if not v2 then
				return false
			end

			Icon.Image = v2.Icon
			Title.Text = v2.DisplayName

			local v3 = EnchantConfig.TierColors[v2.Tier]

			Rarity.Text = ("Tier %*"):format(v2.Tier)
			Rarity.TextColor3 = v3 and v3.Stroke or Color3.fromRGB(255, 215, 0)
			CollectionService:RemoveTag(Rarity, "AnimatedRarity")

			local Description = v2.Description

			if v2.Value2 then
				Description = Description:gsub("Y%%", (("%*%%%%"):format(v2.Value2))):gsub("%+Y", (("+%*"):format(v2.Value2))):gsub("xY", (("x%*"):format(v2.Value2)))
			end

			Desc.Text = Description:gsub("X%%", (("%*%%%%"):format(v2.Value))):gsub("%+X", (("+%*"):format(v2.Value))):gsub("xX", (("x%*"):format(v2.Value))):gsub("X studs", (("%* studs"):format(v2.Value))):gsub("X reps", (("%* reps"):format(v2.Value)))

			return true
		end
		function t.Decoration(p1) --[[ Line: 619 | Upvalues: DecorationConfig (ref), Icon (copy), Title (copy), Rarity (copy), CollectionService (ref), Desc (copy) ]]
			local v1 = p1:GetAttribute("DecorationConfigName")
			local v2 = if typeof(v1) == "string" then DecorationConfig[v1] else nil

			if v2 then
				Icon.Image = v2.Icon or ""
				Title.Text = v2.DisplayName
				Rarity.Text = v2.Rarity.displayName
				Rarity.TextColor3 = v2.Rarity.rarityColor
				CollectionService:RemoveTag(Rarity, "AnimatedRarity")
				Desc.Text = v2.Description or "A decoration for your garden."

				return true
			end

			return false
		end
		function t.StoreCrate(p1) --[[ Line: 638 | Upvalues: DecorationsStoreConfig (ref), Icon (copy), Title (copy), Rarity (copy), CollectionService (ref), Desc (copy) ]]
			local v1 = p1:GetAttribute("StoreItemId")
			local v2 = if typeof(v1) == "string" then DecorationsStoreConfig.Items[v1] else nil

			if v2 then
				Icon.Image = v2.Icon or ""
				Title.Text = v2.DisplayName
				Rarity.Text = v2.Rarity.displayName
				Rarity.TextColor3 = v2.Rarity.rarityColor
				CollectionService:RemoveTag(Rarity, "AnimatedRarity")
				Desc.Text = v2.Description

				return true
			end

			return false
		end
		function t.IndexFish(p1) --[[ Line: 654 | Upvalues: FishConfig (ref), ClientPlayerData (ref), Icon (copy), Title (copy), Rarity (copy), CollectionService (ref), Desc (copy), describeCatch (ref) ]]
			local v1 = p1:GetAttribute("FishName")
			local v2 = if typeof(v1) == "string" then FishConfig[v1] else nil

			if not v2 then
				return false
			end

			local v4 = if (ClientPlayerData.serverProfile:getState().index or {})[v1] == true then true else false

			Icon.Image = v2.Image
			Icon.ImageColor3 = if v4 then Color3.new(255/255, 255/255, 255/255) else Color3.new(0/255, 0/255, 0/255)
			Title.Text = if v4 then v2.DisplayName else "???"
			Rarity.Text = v2.Rarity.displayName
			Rarity.TextColor3 = v2.Rarity.rarityColor
			CollectionService:RemoveTag(Rarity, "AnimatedRarity")
			Desc.Text = describeCatch(v1, v2)

			return true
		end

		local v12 = nil

		local function isOnScreen(p1) --[[ isOnScreen | Line: 679 ]]
			if p1.AbsoluteSize.X <= 0 or p1.AbsoluteSize.Y <= 0 then
				return false
			end

			local v1 = p1

			while v1 and not v1:IsA("LayerCollector") do
				if v1:IsA("GuiObject") and not v1.Visible then
					return false
				end

				v1 = v1.Parent
			end

			return true
		end

		local function taggedAncestor(p1) --[[ taggedAncestor | Line: 697 | Upvalues: isOnScreen (copy) ]]
			local v1 = p1

			while v1 do
				if v1:IsA("GuiObject") and v1:HasTag("Inspect") then
					if isOnScreen(v1) then
						return v1
					end

					break
				end

				v1 = v1.Parent
			end

			return nil
		end

		local function focusedObject() --[[ focusedObject | Line: 710 | Upvalues: InspectFocus (ref), isOnScreen (copy), taggedAncestor (copy), GuiService (ref) ]]
			local v1 = InspectFocus.Get()

			if v1 and isOnScreen(v1) then
				return v1
			end

			return taggedAncestor(GuiService.SelectedObject)
		end

		local function updatePosition() --[[ updatePosition | Line: 718 | Upvalues: InspectFocus (ref), isOnScreen (copy), taggedAncestor (copy), GuiService (ref), Inspect (copy), v1 (copy) ]]
			local v12 = InspectFocus.Get()
			local v2 = if v12 and isOnScreen(v12) then v12 else taggedAncestor(GuiService.SelectedObject)
			local AbsoluteSize = Inspect.AbsoluteSize
			local ViewportSize = workspace.CurrentCamera.ViewportSize

			if v2 then
				local AbsolutePosition = v2.AbsolutePosition
				local AbsoluteSize2 = v2.AbsoluteSize
				local v4 = Vector2.new(AbsolutePosition.X + AbsoluteSize2.X, AbsolutePosition.Y + AbsoluteSize2.Y / 2)

				Inspect.AnchorPoint = Vector2.new(0, 0)

				local fromOffset = UDim2.fromOffset
				local v8 = math.clamp(v4.X, 0, (math.max(0, ViewportSize.X - AbsoluteSize.X)))
				local v10 = math.max(0, ViewportSize.Y - AbsoluteSize.Y)

				Inspect.Position = fromOffset(v8, math.clamp(v4.Y, 0, v10) + GuiService:GetGuiInset().Y)

				return
			end

			local v11 = Vector2.new(v1.X, v1.Y)

			Inspect.AnchorPoint = Vector2.new(if v11.X + AbsoluteSize.X > ViewportSize.X then 1 else 0, if v11.Y + AbsoluteSize.Y > ViewportSize.Y then 1 else 0)
			Inspect.Position = UDim2.fromOffset(v11.X + 2, v11.Y + GuiService:GetGuiInset().Y)
		end

		local function updatePositionTouch(p1, p2) --[[ updatePositionTouch | Line: 745 | Upvalues: Inspect (copy), GuiService (ref) ]]
			local AbsoluteSize = Inspect.AbsoluteSize
			local ViewportSize = workspace.CurrentCamera.ViewportSize
			local v1 = if p2 + AbsoluteSize.Y > ViewportSize.Y then 1 else 0

			Inspect.AnchorPoint = Vector2.new(if p1 + AbsoluteSize.X > ViewportSize.X then 1 else 0, v1)
			Inspect.Position = UDim2.fromOffset(p1 + 2, p2 + GuiService:GetGuiInset().Y)
		end

		local v13 = updatePosition

		local function settleBossList() --[[ settleBossList | Line: 765 | Upvalues: v11 (ref), Inspect (copy), v4 (ref), v10 (copy), fitToDesc (copy), v13 (ref) ]]
			if v11 <= 0 then
				return
			end

			v11 = v11 - 1

			if not Inspect.Visible then
				v11 = 0

				return
			end

			if v4 > 0 and v11 > 0 then
				local v2 = math.ceil(v10.AbsolutePosition.Y + v10.AbsoluteSize.Y + 10 - (Inspect.AbsolutePosition.Y + Inspect.AbsoluteSize.Y))

				if v2 > 0 then
					v4 = v4 + v2
					fitToDesc()
					v13()

					return
				end
			end

			v11 = 0
			v10.Visible = v4 > 0
		end

		RunService.Heartbeat:Connect(settleBossList)

		local function prepareInspect(p1) --[[ prepareInspect | Line: 795 | Upvalues: updatePosition (copy), v12 (ref), Icon (copy), v4 (ref), v10 (copy), t (copy), Inspect (copy), fitToDesc (copy), v13 (ref), v11 (ref) ]]
			updatePosition()

			if v12 == p1 then
				return
			end

			v12 = p1
			Icon.ImageColor3 = Color3.new(255/255, 255/255, 255/255)
			v4 = 0
			v10.Visible = false

			local v1 = t[p1:GetAttribute("InspectType")]

			if not (v1 and v1(p1)) then
				Inspect.Visible = false

				return
			end

			fitToDesc()
			Inspect.Visible = true
			updatePosition()
			v13 = updatePosition
			v11 = if v4 > 0 then 5 else 0
		end

		local function prepareInspectTouch(p1, p2, p3) --[[ prepareInspectTouch | Line: 822 | Upvalues: updatePositionTouch (copy), v12 (ref), Icon (copy), v4 (ref), v10 (copy), t (copy), Inspect (copy), fitToDesc (copy), v13 (ref), v11 (ref) ]]
			updatePositionTouch(p2, p3)
			v12 = p1
			Icon.ImageColor3 = Color3.new(255/255, 255/255, 255/255)
			v4 = 0
			v10.Visible = false

			local v1 = t[p1:GetAttribute("InspectType")]

			if not (v1 and v1(p1)) then
				Inspect.Visible = false

				return
			end

			fitToDesc()
			Inspect.Visible = true
			updatePositionTouch(p2, p3)
			v13 = function() --[[ Line: 837 | Upvalues: updatePositionTouch (ref), p2 (copy), p3 (copy) ]]
				updatePositionTouch(p2, p3)
			end
			v11 = if v4 > 0 then 5 else 0
		end

		local function inspectableAt(p1, p2) --[[ inspectableAt | Line: 843 | Upvalues: InspectFocus (ref), isOnScreen (copy), taggedAncestor (copy), GuiService (ref), PlayerGui (copy) ]]
			local v1 = InspectFocus.Get()
			local v2 = if v1 and isOnScreen(v1) then v1 else taggedAncestor(GuiService.SelectedObject)

			if v2 and v2:HasTag("Inspect") then
				return v2
			end

			for v4, v5 in PlayerGui:GetGuiObjectsAtPosition(p1, p2) do
				if v5:HasTag("Inspect") and isOnScreen(v5) then
					return v5
				end
			end

			return nil
		end

		local function onMove() --[[ onMove | Line: 856 | Upvalues: inspectableAt (copy), v1 (copy), prepareInspect (copy), v12 (ref), Inspect (copy) ]]
			local v13 = inspectableAt(v1.X, v1.Y)

			if v13 then
				prepareInspect(v13)
			else
				v12 = nil
				Inspect.Visible = false
			end
		end

		if UserInputService.TouchEnabled and not UserInputService.MouseEnabled then
			local function handleTouch(p1) --[[ handleTouch | Line: 874 | Upvalues: inspectableAt (copy), prepareInspectTouch (copy), v12 (ref), Inspect (copy) ]]
				local v1 = inspectableAt(p1.X, p1.Y)

				if v1 then
					prepareInspectTouch(v1, p1.X, p1.Y)
				else
					v12 = nil
					Inspect.Visible = false
				end
			end

			UserInputService.TouchStarted:Connect(function(p1) --[[ Line: 884 | Upvalues: inspectableAt (copy), prepareInspectTouch (copy), v12 (ref), Inspect (copy) ]]
				local Position = p1.Position
				local v1 = inspectableAt(Position.X, Position.Y)

				if v1 then
					prepareInspectTouch(v1, Position.X, Position.Y)
				else
					v12 = nil
					Inspect.Visible = false
				end
			end)
			UserInputService.TouchMoved:Connect(function(p1) --[[ Line: 888 | Upvalues: inspectableAt (copy), prepareInspectTouch (copy), v12 (ref), Inspect (copy) ]]
				local Position = p1.Position
				local v1 = inspectableAt(Position.X, Position.Y)

				if v1 then
					prepareInspectTouch(v1, Position.X, Position.Y)
				else
					v12 = nil
					Inspect.Visible = false
				end
			end)
			UserInputService.TouchEnded:Connect(function() --[[ Line: 892 | Upvalues: v12 (ref), Inspect (copy) ]]
				v12 = nil
				Inspect.Visible = false
			end)
		else
			UserInputService.InputChanged:Connect(function(p1) --[[ Line: 897 | Upvalues: inspectableAt (copy), v1 (copy), prepareInspect (copy), v12 (ref), Inspect (copy) ]]
				if p1.UserInputType == Enum.UserInputType.MouseMovement then
					local v13 = inspectableAt(v1.X, v1.Y)

					if v13 then
						prepareInspect(v13)
					else
						v12 = nil
						Inspect.Visible = false
					end
				else
					if p1.UserInputType ~= Enum.UserInputType.MouseWheel then
						return
					end

					for i = 1, 10 do
						local v2 = inspectableAt(v1.X, v1.Y)

						if v2 then
							prepareInspect(v2)
						else
							v12 = nil
							Inspect.Visible = false
						end

						task.wait(0.1)
					end
				end
			end)
		end

		GuiService:GetPropertyChangedSignal("SelectedObject"):Connect(function() --[[ Line: 909 | Upvalues: inspectableAt (copy), v1 (copy), prepareInspect (copy), v12 (ref), Inspect (copy) ]]
			local v13 = inspectableAt(v1.X, v1.Y)

			if v13 then
				prepareInspect(v13)
			else
				v12 = nil
				Inspect.Visible = false
			end
		end)
		InspectFocus.Changed:Connect(function() --[[ Line: 914 | Upvalues: inspectableAt (copy), v1 (copy), prepareInspect (copy), v12 (ref), Inspect (copy) ]]
			local v13 = inspectableAt(v1.X, v1.Y)

			if v13 then
				prepareInspect(v13)
			else
				v12 = nil
				Inspect.Visible = false
			end
		end)
		ReplicatedStorage:GetAttributeChangedSignal("fishStocks"):Connect(function() --[[ Line: 921 | Upvalues: Inspect (copy), v10 (copy), v4 (ref), refreshBossList (copy), fitToDesc (copy), v11 (ref) ]]
			if not (Inspect.Visible and v10.Visible) then
				return
			end

			v4 = refreshBossList()
			v10.Visible = v4 > 0
			fitToDesc()
			v11 = if v4 > 0 then 5 else 0
		end)
	end
}