-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ContextActionService = game:GetService("ContextActionService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local AuctionHouseConfig = require(ReplicatedStorage.shared.config.AuctionHouseConfig)
local ControlHint = require(ReplicatedStorage.client.ControlHint)
local ConvertValue = require(ReplicatedStorage.shared.util.ConvertValue)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local MutationList = require(ReplicatedStorage.shared.util.MutationList)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local SFX = require(ReplicatedStorage.client.SFX)
local t = {
	UECS = nil,
	Priority = 35
}
local t2 = { "OfflineEarnings", "UpdateLog", "DailyLoginNew", "AdminRewardPopUp" }

local function waitForPopupsClosed(p1) --[[ waitForPopupsClosed | Line: 48 | Upvalues: t2 (copy) ]]
	for v1, v2 in t2 do
		local v3 = p1:FindFirstChild(v2)

		if v3 and v3.Visible then
			repeat
				task.wait(0.2)
			until not v3.Visible

			task.wait(0.4)
		end
	end
end

local function animateCardAppear(p1, p2) --[[ animateCardAppear | Line: 60 | Upvalues: TweenService (copy) ]]
	local Container = p1:FindFirstChild("Container")

	if Container then
		Container.Size = UDim2.new(0.6, 0, 0.6, 0)
		Container.Rotation = math.random(-8, 8)
		task.delay(p2, function() --[[ Line: 69 | Upvalues: p1 (copy), TweenService (ref), Container (copy) ]]
			p1.Visible = true
			TweenService:Create(Container, TweenInfo.new(0.25, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
				Rotation = 0,
				Size = UDim2.new(1, 0, 1, 0)
			}):Play()
			task.delay(0.35, function() --[[ Line: 79 | Upvalues: Container (ref), TweenService (ref) ]]
				local v1 = math.random(-10, 10)

				Container.Rotation = v1

				local v3 = TweenService:Create(Container, TweenInfo.new(math.max(math.abs(10 - v1) / 20 * 1.2, 0.1), Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
					Rotation = 10
				})

				v3:Play()
				v3.Completed:Once(function() --[[ Line: 92 | Upvalues: TweenService (ref), Container (ref) ]]
					TweenService:Create(Container, TweenInfo.new(1.2, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true), {
						Rotation = -10
					}):Play()
				end)
			end)
		end)
	end
end

local function resolveCardInfo(p1) --[[ resolveCardInfo | Line: 107 | Upvalues: AuctionHouseConfig (copy), MutationList (copy) ]]
	if type(p1) ~= "table" then
		return nil
	end

	if type(p1.Category) ~= "string" then
		return nil
	end

	if type(p1.ConfigName) ~= "string" then
		return nil
	end

	local v1 = AuctionHouseConfig.resolveItem(p1.Category, p1.ConfigName)

	if not v1 then
		return nil
	end

	local v2 = v1.DisplayName or p1.ConfigName
	local v3 = MutationList.parse(p1.Mutation)

	if #v3 > 0 then
		v2 = ("%* %*"):format(MutationList.displayLabel(v3), v2)
	end

	local v5 = if type(p1.Level) == "number" and p1.Level > 1 then ("Lv. %*"):format(p1.Level) else ""
	local t = {}

	t.Image = v1.Image or v1.Icon or ""
	t.Label = v2
	t.Detail = v5
	t.Bid = tonumber(p1.Bid)

	return t
end

function t.Init(p1) --[[ Init | Line: 134 | Upvalues: Players (copy), ControlHint (copy), ContextActionService (copy), TweenService (copy), ConvertValue (copy), resolveCardInfo (copy), waitForPopupsClosed (copy), SFX (copy), animateCardAppear (copy), Remotes (copy) ]]
	local MainUI = Players.LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("MainUI")
	local AuctionRewardPopUp = MainUI:FindFirstChild("AuctionRewardPopUp")

	if AuctionRewardPopUp then
		local v1 = AuctionRewardPopUp:WaitForChild("Content")
		local TopBar = AuctionRewardPopUp:WaitForChild("TopBar")
		local TextLabel = v1:WaitForChild("TextLabel")
		local RewardsContainer = v1:WaitForChild("RewardsContainer")
		local CardTemplate = RewardsContainer:WaitForChild("CardTemplate")
		local ClaimBtn = v1:WaitForChild("ClaimBtn")
		local CloseButton = TopBar:WaitForChild("CloseButton")

		CloseButton.ZIndex = 10
		CloseButton.Active = true

		local Size = AuctionRewardPopUp.Size
		local v2 = false
		local v3 = ControlHint.new({
			label = "Claim",
			anchorTo = ClaimBtn,
			keyCode = Enum.KeyCode.ButtonA
		})
		local v4 = ControlHint.new({
			label = "Close",
			anchorTo = CloseButton,
			keyCode = Enum.KeyCode.ButtonB
		})

		v3:Hide()
		v4:Hide()

		local v5 = nil

		local function bindGamepad() --[[ bindGamepad | Line: 168 | Upvalues: ContextActionService (ref), v5 (ref), v3 (copy), v4 (copy) ]]
			ContextActionService:BindActionAtPriority("AuctionRewardPopupClaim", function(p1, p2) --[[ Line: 169 | Upvalues: v5 (ref) ]]
				if p2 == Enum.UserInputState.Begin then
					v5()

					return Enum.ContextActionResult.Sink
				end

				return Enum.ContextActionResult.Pass
			end, false, 10000, Enum.KeyCode.ButtonA)
			ContextActionService:BindActionAtPriority("AuctionRewardPopupClose", function(p1, p2) --[[ Line: 176 | Upvalues: v5 (ref) ]]
				if p2 == Enum.UserInputState.Begin then
					v5()

					return Enum.ContextActionResult.Sink
				end

				return Enum.ContextActionResult.Pass
			end, false, 10000, Enum.KeyCode.ButtonB)
			v3:Show()
			v4:Show()
		end

		local function unbindGamepad() --[[ unbindGamepad | Line: 187 | Upvalues: ContextActionService (ref), v3 (copy), v4 (copy) ]]
			ContextActionService:UnbindAction("AuctionRewardPopupClaim")
			ContextActionService:UnbindAction("AuctionRewardPopupClose")
			v3:Hide()
			v4:Hide()
		end

		local function showPopup() --[[ showPopup | Line: 194 | Upvalues: AuctionRewardPopUp (copy), TweenService (ref), Size (copy), bindGamepad (copy) ]]
			AuctionRewardPopUp.Size = UDim2.new(0, 0, 0, 0)
			AuctionRewardPopUp.Visible = true
			TweenService:Create(AuctionRewardPopUp, TweenInfo.new(0.35, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
				Size = Size
			}):Play()
			bindGamepad()
		end

		v5 = function() --[[ Line: 205 | Upvalues: v2 (ref), ContextActionService (ref), v3 (copy), v4 (copy), TweenService (ref), AuctionRewardPopUp (copy), Size (copy) ]]
			if not v2 then
				v2 = true
				ContextActionService:UnbindAction("AuctionRewardPopupClaim")
				ContextActionService:UnbindAction("AuctionRewardPopupClose")
				v3:Hide()
				v4:Hide()

				local v1 = TweenService:Create(AuctionRewardPopUp, TweenInfo.new(0.25, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
					Size = UDim2.new(0, 0, 0, 0)
				})

				v1:Play()
				v1.Completed:Once(function() --[[ Line: 219 | Upvalues: AuctionRewardPopUp (ref), Size (ref), v2 (ref) ]]
					AuctionRewardPopUp.Visible = false
					AuctionRewardPopUp.Size = Size
					v2 = false
				end)
			end
		end

		local Size2 = ClaimBtn.Size

		local function pressButton() --[[ pressButton | Line: 227 | Upvalues: TweenService (ref), ClaimBtn (copy), Size2 (copy) ]]
			local v1 = TweenService:Create(ClaimBtn, TweenInfo.new(0.08, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				Size = UDim2.new(Size2.X.Scale * 0.9, Size2.X.Offset, Size2.Y.Scale * 0.9, Size2.Y.Offset)
			})

			v1:Play()
			v1.Completed:Once(function() --[[ Line: 238 | Upvalues: TweenService (ref), ClaimBtn (ref), Size2 (ref) ]]
				TweenService:Create(ClaimBtn, TweenInfo.new(0.15, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
					Size = Size2
				}):Play()
			end)
		end

		ClaimBtn.Activated:Connect(function() --[[ Line: 245 | Upvalues: pressButton (copy), v5 (ref) ]]
			pressButton()
			task.delay(0.15, v5)
		end)
		CloseButton.Activated:Connect(v5)

		local function headlineFor(p1) --[[ headlineFor | Line: 253 | Upvalues: ConvertValue (ref) ]]
			if #p1 > 1 then
				return ("You won %* auctions!"):format(#p1)
			end

			local v1 = p1[1]

			if v1.Bid and v1.Bid > 0 then
				return ("You won %* for $%*!"):format(v1.Label, (ConvertValue.suffixformat(v1.Bid)))
			end

			return ("You won %*!"):format(v1.Label)
		end

		local function handleAuctionPopup(p1) --[[ handleAuctionPopup | Line: 264 | Upvalues: resolveCardInfo (ref), waitForPopupsClosed (ref), MainUI (copy), TextLabel (copy), ConvertValue (ref), RewardsContainer (copy), CardTemplate (copy), showPopup (copy), SFX (ref), animateCardAppear (ref) ]]
			if type(p1) ~= "table" then
				warn("[AuctionRewardPopup] Invalid data received")

				return
			end

			if type(p1.Items) ~= "table" then
				warn("[AuctionRewardPopup] Invalid data received")

				return
			end

			local t = {}

			for v1, v2 in p1.Items do
				local v3 = resolveCardInfo(v2)

				if v3 then
					table.insert(t, v3)
				end
			end

			if #t ~= 0 then
				task.spawn(function() --[[ Line: 281 | Upvalues: waitForPopupsClosed (ref), MainUI (ref), TextLabel (ref), t (copy), ConvertValue (ref), RewardsContainer (ref), CardTemplate (ref), showPopup (ref), SFX (ref), animateCardAppear (ref) ]]
					waitForPopupsClosed(MainUI)

					local v2 = t
					local v3

					if #v2 > 1 then
						v3 = ("You won %* auctions!"):format(#v2)
					else
						local v5 = v2[1]

						v3 = if v5.Bid and v5.Bid > 0 then ("You won %* for $%*!"):format(v5.Label, (ConvertValue.suffixformat(v5.Bid))) else ("You won %*!"):format(v5.Label)
					end

					TextLabel.Text = v3

					for v8, v9 in RewardsContainer:GetChildren() do
						if v9:IsA("Frame") and v9.Name ~= "CardTemplate" then
							v9:Destroy()
						end
					end

					local t2 = {}

					for v10, v11 in t do
						local v12 = CardTemplate:Clone()

						v12.Name = "Card" .. v10
						v12.LayoutOrder = v10
						v12.Visible = false

						local Container = v12:FindFirstChild("Container")

						if Container then
							local Icon = Container:FindFirstChild("Icon")

							if Icon then
								Icon.Image = v11.Image
							end

							local RewardName = Container:FindFirstChild("RewardName")

							if RewardName then
								RewardName.Text = v11.Label
							end

							local RewardAmount = Container:FindFirstChild("RewardAmount")

							if RewardAmount then
								RewardAmount.Text = v11.Detail
							end

							v12.Parent = RewardsContainer
							table.insert(t2, v12)

							continue
						end

						warn("[AuctionRewardPopup] CardTemplate missing Container")
					end

					showPopup()
					SFX.PlaySoundWithRandomPitch(SFX.Sounds.EggReward, 0.8, 0.95, 1.05)

					for v13, v14 in t2 do
						animateCardAppear(v14, (v13 - 1) * 0.12)
					end
				end)
			end
		end

		Remotes.AuctionRewardPopup:On(handleAuctionPopup)
		Remotes.AuctionRewardPopupReady:Fire()
	else
		warn("[AuctionRewardPopup] MainUI.AuctionRewardPopUp not found \226\128\148 auction wins will only notify")
	end
end

return t