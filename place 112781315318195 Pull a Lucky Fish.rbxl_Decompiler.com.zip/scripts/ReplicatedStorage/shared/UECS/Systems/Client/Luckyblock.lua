-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local CollectFishUI = require(ReplicatedStorage.shared.module.CollectFishUI)
local FishConfig = require(ReplicatedStorage.shared.config.FishConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)
require(ReplicatedStorage.shared.UECS.Components.Luckyblock)

local LuckyblockConfig = require(ReplicatedStorage.shared.config.LuckyblockConfig)
local MountConfig = require(ReplicatedStorage.shared.config.MountConfig)
local RarityLabel = require(ReplicatedStorage.shared.UECS.Components.RarityLabel)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local SFX = require(ReplicatedStorage.client.SFX)
local createAnimationInstance = require(ReplicatedStorage.shared.util.createAnimationInstance)
local tweenModelScale = require(ReplicatedStorage.shared.util.tweenModelScale)
local Luckyblocks = ReplicatedStorage.shared.model.Luckyblocks
local FishModels = ReplicatedStorage.shared.model.FishModels
local t = {
	UECS = nil
}

local function quadBezier(p1, p2, p3, p4) --[[ quadBezier | Line: 48 ]]
	local v1 = 1 - p4

	return v1 * v1 * p1 + v1 * 2 * p4 * p2 + p4 * p4 * p3
end

local function findLandingCFrame(p1, p2, p3) --[[ findLandingCFrame | Line: 56 ]]
	local Position = (p1.CFrame * CFrame.new(0, 0, -6)).Position
	local v1 = RaycastParams.new()

	v1.FilterType = Enum.RaycastFilterType.Exclude

	local t = {}

	t[1] = if p2 then p2 else p1.Parent

	if p3 then
		for v3, v4 in p3 do
			table.insert(t, v4)
		end
	end

	v1.FilterDescendantsInstances = t

	local v5 = workspace:Raycast(Position, Vector3.new(0, -200, 0), v1)

	if v5 then
		return CFrame.new(v5.Position)
	end

	return p1.CFrame * CFrame.new(Vector3.new(0, 3, -6))
end

local function curveTo(p1, p2, p3) --[[ curveTo | Line: 76 | Upvalues: RunService (copy) ]]
	local Position = p1.Position
	local Position2 = p2.Position
	local sum = 0
	local v1 = (Position + Position2) / 2 + Vector3.new(0, 8, 0)

	while sum < p3 do
		sum = sum + RunService.RenderStepped:Wait()

		local v2 = math.min(sum / p3, 1)
		local v3 = 1 - v2

		p1.CFrame = CFrame.new(v3 * v3 * Position + v3 * 2 * v2 * v1 + v2 * v2 * Position2) * (p2 - p2.Position)
	end

	p1.CFrame = p2
end

local function chargeUp(p1, p2) --[[ chargeUp | Line: 93 | Upvalues: TweenService (copy), RunService (copy) ]]
	local v1 = p1.CFrame
	local Highlight = Instance.new("Highlight")

	Highlight.FillColor = Color3.fromRGB(255, 255, 255)
	Highlight.OutlineColor = Color3.fromRGB(255, 255, 255)
	Highlight.FillTransparency = 0.6
	Highlight.OutlineTransparency = 0
	Highlight.Parent = p1

	local v2 = TweenService:Create(p1, TweenInfo.new(p2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
		Size = p1.Size * 2
	})

	v2:Play()

	local sum = 0

	while sum < p2 do
		sum = sum + RunService.RenderStepped:Wait()

		local v3 = sum / p2
		local v4 = v3 * 1.3 + 0.3
		local v5 = (math.random() - 0.5) * v4
		local v6 = (math.random() - 0.5) * v4

		p1.CFrame = v1 + Vector3.new(v5, v6, (math.random() - 0.5) * v4)
		Highlight.FillTransparency = 0.6 - v3 * 0.5
	end

	v2:Cancel()
	Highlight:Destroy()
end

local function anchorModel(p1, p2) --[[ anchorModel | Line: 138 ]]
	local v1 = p1.PrimaryPart or p1:FindFirstChildWhichIsA("BasePart", true)

	for v2, v3 in p1:GetDescendants() do
		if v3:IsA("BasePart") then
			v3.Anchored = not p2 or (if v3 == v1 then true else false)
			v3.CanCollide = false
		end
	end

	if not p2 then
		return
	end

	local Humanoid = p1:FindFirstChildOfClass("Humanoid")

	if not Humanoid then
		return
	end

	Humanoid.EvaluateStateMachine = false
	Humanoid.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
end

local function getModelAnimator(p1) --[[ getModelAnimator | Line: 157 ]]
	local v1 = p1:FindFirstChildOfClass("Humanoid") or p1:FindFirstChildOfClass("AnimationController")

	if not v1 then
		local AnimationController = Instance.new("AnimationController")

		AnimationController.Parent = p1
		v1 = AnimationController
	end

	local Animator = v1:FindFirstChildOfClass("Animator")

	if not Animator then
		local Animator2 = Instance.new("Animator")

		Animator2.Parent = v1
		Animator = Animator2
	end

	return Animator
end

local function playOpenAnimation(p1, p2) --[[ playOpenAnimation | Line: 182 | Upvalues: getModelAnimator (copy), createAnimationInstance (copy), RunService (copy) ]]
	local v1 = getModelAnimator(p1)
	local ok, result = pcall(function() --[[ Line: 184 | Upvalues: v1 (copy), createAnimationInstance (ref), p2 (copy) ]]
		return v1:LoadAnimation(createAnimationInstance(p2))
	end)

	if ok and result then
		result.Looped = false
		result.Priority = Enum.AnimationPriority.Action
		result:Play()

		local sum = 0
		local v2 = false

		while sum < 5 do
			sum = sum + RunService.RenderStepped:Wait()

			if result.Length > 0 then
				v2 = true

				if not result.IsPlaying then
					break
				end
			elseif sum >= 1 then
				break
			end
		end

		result:Stop()
		result:Destroy()

		if v2 then
			return v2
		end

		warn((("[Luckyblock] open animation %* never loaded"):format(p2)))

		return v2
	end

	warn((("[Luckyblock] failed to load open animation %*: %*"):format(p2, result)))

	return false
end

local function pivotHeightAboveBase(p1) --[[ pivotHeightAboveBase | Line: 222 ]]
	local v1, v2 = p1:GetBoundingBox()

	return p1:GetPivot().Position.Y - (v1.Position.Y - v2.Y / 2)
end

local function curveToModel(p1, p2, p3) --[[ curveToModel | Line: 229 | Upvalues: RunService (copy) ]]
	local Position = p1:GetPivot().Position
	local Position2 = p2.Position
	local sum = 0
	local v1 = (Position + Position2) / 2 + Vector3.new(0, 8, 0)

	while sum < p3 do
		sum = sum + RunService.RenderStepped:Wait()

		local v2 = math.min(sum / p3, 1)
		local v3 = 1 - v2

		p1:PivotTo(CFrame.new(v3 * v3 * Position + v3 * 2 * v2 * v1 + v2 * v2 * Position2) * (p2 - p2.Position))
	end

	p1:PivotTo(p2)
end

local function chargeUpModel(p1, p2) --[[ chargeUpModel | Line: 245 | Upvalues: RunService (copy) ]]
	local v1 = p1:GetPivot()
	local v2 = p1:GetScale()
	local Highlight = Instance.new("Highlight")

	Highlight.FillColor = Color3.fromRGB(255, 255, 255)
	Highlight.OutlineColor = Color3.fromRGB(255, 255, 255)
	Highlight.FillTransparency = 0.6
	Highlight.OutlineTransparency = 0
	Highlight.Parent = p1

	local sum = 0

	while sum < p2 do
		sum = sum + RunService.RenderStepped:Wait()

		local v3 = math.min(sum / p2, 1)

		p1:ScaleTo(v2 * (1 - (1 - v3) * (1 - v3) + 1))

		local v4 = v3 * 1.3 + 0.3
		local v5 = (math.random() - 0.5) * v4
		local v6 = (math.random() - 0.5) * v4

		p1:PivotTo(v1 + Vector3.new(v5, v6, (math.random() - 0.5) * v4))
		Highlight.FillTransparency = 0.6 - v3 * 0.5
	end

	Highlight:Destroy()
end

local function collectDropKeys(p1, p2) --[[ collectDropKeys | Line: 279 | Upvalues: LuckyblockConfig (copy) ]]
	local v1 = LuckyblockConfig[p1]
	local t = {}

	if v1 and v1.Drops then
		for v2 in v1.Drops do
			table.insert(t, v2)
		end
	end

	if #t == 0 then
		table.insert(t, p2)
	end

	return t
end

local function dropSource(p1) --[[ dropSource | Line: 296 | Upvalues: LuckyblockConfig (copy), ReplicatedStorage (copy), MountConfig (copy), FishModels (copy), FishConfig (copy) ]]
	local v1 = LuckyblockConfig[p1]

	if not v1 or v1.DropCategory ~= "Mount" then
		return FishModels, FishConfig
	end

	local MountModels = ReplicatedStorage.shared.model:FindFirstChild("MountModels")

	if MountModels then
		return MountModels, MountConfig
	end

	warn("[Luckyblock] shared.model.MountModels missing \226\128\148 falling back to fish models")

	return FishModels, FishConfig
end

local function rollAndReveal(p1, p2, p3, p4, p5) --[[ rollAndReveal | Line: 310 | Upvalues: SFX (copy), tweenModelScale (copy), RarityLabel (copy) ]]
	local sum = 0.05

	for i = 1, 15 do
		SFX.new(SFX.Sounds.Roll, 0.5)

		local v1 = sum
		local v2 = p4:FindFirstChild(p3[math.random(1, #p3)])

		if v2 then
			local v3 = v2:Clone()

			v3:ScaleTo(v3:GetScale() / 3)
			v3.PrimaryPart.Anchored = true
			v3.PrimaryPart.CFrame = p1
			v3.Parent = workspace
			tweenModelScale(v3, TweenInfo.new(v1 * 0.66), v3:GetScale() * 2.5)
			task.spawn(function() --[[ Line: 335 | Upvalues: tweenModelScale (ref), v3 (copy), v1 (copy) ]]
				tweenModelScale(v3, TweenInfo.new(v1 * 0.33), v3:GetScale() / 3)
				v3:Destroy()
			end)
			task.wait(v1)
			sum = sum + 0.01

			continue
		end

		task.wait(v1)
		sum = sum + 0.01
	end

	task.wait(0.1)
	SFX.new(SFX.Sounds.Luck, 0.5)

	local v4 = p4:FindFirstChild(p2):Clone()
	local v5 = v4:GetScale()

	v4:ScaleTo(v5 / 3)
	v4.PrimaryPart.Anchored = true
	v4.PrimaryPart.CFrame = p1
	v4.Parent = workspace

	local v6 = p5[p2]
	local v7 = RarityLabel.Add(v4)

	v7.DisplayName:Set(v6.DisplayName)
	v7.Rarity:Set(v6.Rarity.id)
	v7.Earnings:Set(v6.Earnings or 0)
	tweenModelScale(v4, TweenInfo.new(1), v5)
	task.wait(1)

	return v4
end

local function spinFish(p1, p2) --[[ spinFish | Line: 369 | Upvalues: RunService (copy) ]]
	if not p1.PrimaryPart then
		return
	end

	local v1 = p1.PrimaryPart.CFrame
	local Position = v1.Position
	local sum = 0
	local v2 = v1 - Position

	while sum < p2 do
		sum = sum + RunService.RenderStepped:Wait()

		local v3 = math.min(sum / p2, 1) * 6.283185307179586

		p1.PrimaryPart.CFrame = CFrame.new(Position) * CFrame.Angles(0, v3, 0) * v2
	end

	p1.PrimaryPart.CFrame = v1
end

local function flyFishToPlayer(p1, p2) --[[ flyFishToPlayer | Line: 388 | Upvalues: RunService (copy) ]]
	if not p1.PrimaryPart then
		p1:Destroy()

		return
	end

	p1.PrimaryPart.Anchored = true

	local Position = p1.PrimaryPart.Position
	local sum = 0

	while sum < 0.7 do
		sum = sum + RunService.RenderStepped:Wait()

		local v1 = math.min(sum / 0.7, 1)
		local Position2 = p2.Position
		local v4 = (Position + Position2) / 2 + Vector3.new(0, math.max(25, (Position2 - Position).Magnitude * 0.35), 0)
		local v5 = 1 - v1
		local v6 = v5 * v5 * Position + v5 * 2 * v1 * v4 + v1 * v1 * Position2
		local v7 = (1 - v1) * 2 * (v4 - Position) + v1 * 2 * (Position2 - v4)

		if v7.Magnitude > 0.001 then
			p1.PrimaryPart.CFrame = CFrame.lookAt(v6, v6 + v7.Unit)
		else
			p1.PrimaryPart.CFrame = CFrame.new(v6)
		end
	end

	p1:Destroy()
end

function t.Init(p1) --[[ Init | Line: 415 | Upvalues: ClientPlayerData (copy), Players (copy), Remotes (copy), Luckyblocks (copy), SFX (copy), LuckyblockConfig (copy), anchorModel (copy), findLandingCFrame (copy), curveToModel (copy), playOpenAnimation (copy), chargeUpModel (copy), curveTo (copy), chargeUp (copy), collectDropKeys (copy), ReplicatedStorage (copy), MountConfig (copy), FishModels (copy), FishConfig (copy), rollAndReveal (copy), spinFish (copy), CollectFishUI (copy), flyFishToPlayer (copy) ]]
	p1.UECS.OnComponentCreated("Luckyblock"):Connect(function(p1) --[[ Line: 416 | Upvalues: ClientPlayerData (ref), Players (ref), Remotes (ref), Luckyblocks (ref), SFX (ref), LuckyblockConfig (ref), anchorModel (ref), findLandingCFrame (ref), curveToModel (ref), playOpenAnimation (ref), chargeUpModel (ref), curveTo (ref), chargeUp (ref), collectDropKeys (ref), ReplicatedStorage (ref), MountConfig (ref), FishModels (ref), FishConfig (ref), rollAndReveal (ref), spinFish (ref), CollectFishUI (ref), flyFishToPlayer (ref) ]]
		if p1.Entity:IsA("Tool") then
			local Entity = p1.Entity
			local v1 = nil

			local function getPlayerPity(p1) --[[ getPlayerPity | Line: 424 | Upvalues: ClientPlayerData (ref) ]]
				local v1 = ClientPlayerData.serverProfile:getState()

				if v1.luckyblockPity and v1.luckyblockPity[p1] then
					return v1.luckyblockPity[p1]
				end

				return 0
			end

			local function updateHUD(p1, p2) --[[ updateHUD | Line: 432 | Upvalues: Players (ref), ClientPlayerData (ref) ]]
				local PlayerGui = Players.LocalPlayer:FindFirstChildOfClass("PlayerGui")
				local v1 = if PlayerGui then PlayerGui:FindFirstChild("MainUI") else PlayerGui
				local v2 = if v1 then v1:FindFirstChild("HUD") else v1

				if not v2 then
					return
				end

				local v3 = v2:FindFirstChild("LuckyblockPity") or (v2:FindFirstChild("PityHUD") or v2:FindFirstChild("PityFrame"))

				if not v3 then
					return
				end

				v3.Visible = p2

				if not p2 then
					return
				end

				local v4 = ClientPlayerData.serverProfile:getState()
				local v5 = if v4.luckyblockPity and v4.luckyblockPity[p1] then v4.luckyblockPity[p1] else 0
				local v6 = v3:FindFirstChild("PityLabel", true) or (v3:FindFirstChild("PityText", true) or v3:FindFirstChild("Pity", true))

				if v6 then
					v6.Text = ("%*/20"):format(v5)
				end

				local v7 = v3:FindFirstChild("PityBar", true) or (v3:FindFirstChild("PityProgress", true) or v3:FindFirstChild("ProgressBar", true))

				if not v7 then
					return
				end

				local v8 = v7:FindFirstChild("Fill", true) or (v7:FindFirstChild("Progress", true) or v7:FindFirstChild("Bar", true))

				if v8 then
					v8.Size = UDim2.fromScale(math.clamp(v5 / 20, 0, 1), 1)

					return
				end

				v7.Size = UDim2.new(math.clamp(v5 / 20, 0, 1), 0, v7.Size.Y.Scale, v7.Size.Y.Offset)
			end

			local function cleanup() --[[ cleanup | Line: 477 | Upvalues: p1 (copy), Players (ref), v1 (ref) ]]
				p1.ConfigName:Get()

				local PlayerGui = Players.LocalPlayer:FindFirstChildOfClass("PlayerGui")
				local v12 = if PlayerGui then PlayerGui:FindFirstChild("MainUI") else PlayerGui
				local v2 = if v12 then v12:FindFirstChild("HUD") else v12

				if v2 then
					local v3 = v2:FindFirstChild("LuckyblockPity") or (v2:FindFirstChild("PityHUD") or v2:FindFirstChild("PityFrame"))

					if v3 then
						v3.Visible = false
					end
				end

				if not v1 then
					return
				end

				v1()
				v1 = nil
			end

			Entity.Equipped:Connect(function() --[[ Line: 486 | Upvalues: p1 (copy), updateHUD (copy), v1 (ref), ClientPlayerData (ref) ]]
				local v12 = p1.ConfigName:Get()

				updateHUD(v12, true)

				if v1 then
					v1()
				end

				v1 = ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 493 | Upvalues: v12 (copy) ]]
					return if p1.luckyblockPity then p1.luckyblockPity[v12] or 0 else 0
				end, function() --[[ Line: 495 | Upvalues: updateHUD (ref), v12 (copy) ]]
					updateHUD(v12, true)
				end)
			end)
			Entity.Unequipped:Connect(cleanup)
			Entity.Destroying:Connect(cleanup)
			Entity.Activated:Connect(function() --[[ Line: 503 | Upvalues: Players (ref), p1 (copy), Remotes (ref), Luckyblocks (ref), SFX (ref), LuckyblockConfig (ref), anchorModel (ref), findLandingCFrame (ref), curveToModel (ref), playOpenAnimation (ref), chargeUpModel (ref), curveTo (ref), chargeUp (ref), collectDropKeys (ref), ReplicatedStorage (ref), MountConfig (ref), FishModels (ref), FishConfig (ref), rollAndReveal (ref), spinFish (ref), CollectFishUI (ref), flyFishToPlayer (ref) ]]
				local LocalPlayer = Players.LocalPlayer
				local Character = LocalPlayer.Character
				local v1 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character

				if not v1 then
					return
				end

				local v2 = p1.ConfigName:Get()
				local v3, v4 = Remotes.OpenLuckyblock:Call(v2):Await()
				local v5 = if v3 and v4 then v4 else nil

				if not v5 then
					return
				end

				local v6 = Luckyblocks:FindFirstChild(v2) or Luckyblocks:GetChildren()[1]

				if not v6 then
					return
				end

				SFX.new("rbxassetid://6352582283", 0.5)

				local v7 = LuckyblockConfig[v2]
				local v8 = if v7 then v7.OpenAnimation else v7
				local v9, v10

				if v6:IsA("Model") then
					local v11 = v6:Clone()
					local v13

					v9 = v5
					v13 = if v8 == nil then false else true
					anchorModel(v11, v13)
					v11.Parent = workspace
					v11:PivotTo(v1.CFrame * CFrame.new(0, 2, 0))

					local v14 = findLandingCFrame(v1, Character, { v11 })
					local v15, v16 = v11:GetBoundingBox()

					v10 = v14 + Vector3.new(0, v11:GetPivot().Position.Y - (v15.Position.Y - v16.Y / 2), 0)
					curveToModel(v11, v10, 0.6)

					if not (v8 and playOpenAnimation(v11, v8)) then
						chargeUpModel(v11, 0.8)
					end

					v11:Destroy()
				else
					if not v6:IsA("BasePart") then
						return
					end

					local v18 = v6:Clone()

					v18.Anchored = true
					v18.CanCollide = false
					v18.Parent = workspace
					v18.CFrame = v1.CFrame * CFrame.new(0, 2, 0)

					local v19 = findLandingCFrame(v1, Character, { v18 })

					curveTo(v18, v19, 0.6)
					chargeUp(v18, 0.8)
					v18:Destroy()
					v9 = v5
					v10 = v19
				end

				local v20 = collectDropKeys(v2, v9.FishConfigName)
				local v21 = LuckyblockConfig[v2]
				local v22, v23

				if v21 and v21.DropCategory == "Mount" then
					local MountModels = ReplicatedStorage.shared.model:FindFirstChild("MountModels")

					if MountModels then
						v22 = MountConfig
						v23 = MountModels
					else
						warn("[Luckyblock] shared.model.MountModels missing \226\128\148 falling back to fish models")
						v23 = FishModels
						v22 = FishConfig
					end
				else
					v23 = FishModels
					v22 = FishConfig
				end

				local v24 = rollAndReveal(v10 + Vector3.new(0, 3, 0), v9.FishConfigName, v20, v23, v22)

				spinFish(v24, 0.6)
				CollectFishUI.play(v9.FishConfigName)

				local v25 = LocalPlayer.Character and LocalPlayer.Character:FindFirstChild("HumanoidRootPart")

				if v25 then
					flyFishToPlayer(v24, v25)
				else
					v24:Destroy()
				end

				Remotes.ClaimLuckyblockFish:Fire(v9.DropUID)
			end)
		end
	end)
end

return t