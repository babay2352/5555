-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local AnimationConfig = require(ReplicatedStorage.shared.config.AnimationConfig)
local DecorationConfig = require(ReplicatedStorage.shared.config.DecorationConfig)
local GardenConfig = require(ReplicatedStorage.shared.config.GardenConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local convertTimeHMS = require(ReplicatedStorage.shared.util.convertTimeHMS)
local createAnimationInstance = require(ReplicatedStorage.shared.util.createAnimationInstance)
local DrillTag = GardenConfig.DrillTag
local t = { "Progress", "ProgressFrame", "Fill" }
local t2 = {
	UECS = nil
}

local function findFill(p1) --[[ findFill | Line: 78 | Upvalues: t (copy) ]]
	for v1, v2 in t do
		local v3 = p1:FindFirstChild(v2)

		if v3 and v3:IsA("GuiObject") then
			return v3
		end
	end

	return nil
end

local function collectGemParts(p1) --[[ collectGemParts | Line: 88 ]]
	local t = {}

	if not p1 then
		return t
	end

	if p1:IsA("BasePart") then
		table.insert(t, p1)
	end

	for v1, v2 in p1:GetDescendants() do
		if v2:IsA("BasePart") then
			table.insert(t, v2)
		end
	end

	return t
end

local function collectEmitters(p1, p2) --[[ collectEmitters | Line: 104 ]]
	local t = {}
	local t2 = {}

	for v1, v2 in p1:GetDescendants() do
		if v2:IsA("ParticleEmitter") then
			if p2 and v2:IsDescendantOf(p2) then
				table.insert(t, v2)

				continue
			end

			table.insert(t2, v2)
		end
	end

	return t2, t
end

local function setEmittersEnabled(p1, p2) --[[ setEmittersEnabled | Line: 119 ]]
	for v1, v2 in p1 do
		v2.Enabled = p2
	end
end

local function setLoopSoundPlaying(p1, p2) --[[ setLoopSoundPlaying | Line: 125 ]]
	local loopSound = p1.loopSound

	if not loopSound then
		return
	end

	if p2 and not loopSound.IsPlaying then
		loopSound:Play()

		return
	end

	if p2 or not loopSound.IsPlaying then
		return
	end

	loopSound:Stop()
end

local function createLoopSound(p1) --[[ createLoopSound | Line: 137 | Upvalues: GardenConfig (copy) ]]
	local v1 = p1:FindFirstChild(GardenConfig.DrillRootName, true)
	local DrillLoopSound = GardenConfig.DrillLoopSound

	if v1 and (v1:IsA("BasePart") and (typeof(DrillLoopSound) == "string" and DrillLoopSound ~= "")) then
		local DrillLoop = Instance.new("Sound")

		DrillLoop.Name = "DrillLoop"
		DrillLoop.SoundId = DrillLoopSound
		DrillLoop.Looped = true
		DrillLoop.Volume = GardenConfig.DrillLoopVolume or 0.15
		DrillLoop.RollOffMode = Enum.RollOffMode.Linear
		DrillLoop.RollOffMinDistance = GardenConfig.DrillLoopMinDistance or 6
		DrillLoop.RollOffMaxDistance = GardenConfig.DrillLoopMaxDistance or 45
		DrillLoop.Parent = v1

		return DrillLoop
	end

	return nil
end

local function getAnimator(p1) --[[ getAnimator | Line: 158 ]]
	local v1 = p1:FindFirstChildWhichIsA("AnimationController", true)

	if not v1 then
		local AnimationController = Instance.new("AnimationController")

		AnimationController.Parent = p1
		v1 = AnimationController
	end

	local v2 = v1:FindFirstChildWhichIsA("Animator")

	if not v2 then
		local Animator = Instance.new("Animator")

		Animator.Parent = v1
		v2 = Animator
	end

	return v2
end

local function loadTrack(p1, p2, p3) --[[ loadTrack | Line: 172 | Upvalues: createAnimationInstance (copy) ]]
	local ok, result = pcall(function() --[[ Line: 173 | Upvalues: p1 (copy), createAnimationInstance (ref), p2 (copy) ]]
		return p1:LoadAnimation(createAnimationInstance(p2))
	end)

	if ok and result then
		result.Looped = p3
		result.Priority = Enum.AnimationPriority.Action

		return result
	end

	warn((("[GardenDrill] failed to load animation %*: %*"):format(p2, result)))

	return nil
end

local function orderedTracks(p1) --[[ orderedTracks | Line: 187 ]]
	local t = {}

	if p1.goingDownTrack then
		table.insert(t, p1.goingDownTrack)
	end

	if p1.drillingTrack then
		table.insert(t, p1.drillingTrack)
	end

	if p1.goingUpTrack then
		table.insert(t, p1.goingUpTrack)
	end

	return t
end

local function stopAnimations(p1) --[[ stopAnimations | Line: 205 ]]
	p1.sequenceGeneration = (p1.sequenceGeneration or 0) + 1

	local t = {}

	if p1.goingDownTrack then
		table.insert(t, p1.goingDownTrack)
	end

	if p1.drillingTrack then
		table.insert(t, p1.drillingTrack)
	end

	if p1.goingUpTrack then
		table.insert(t, p1.goingUpTrack)
	end

	for v1, v2 in t do
		v2:Stop()
	end
end

local function startProducingAnimations(p1) --[[ startProducingAnimations | Line: 216 ]]
	p1.sequenceGeneration = (p1.sequenceGeneration or 0) + 1

	local t = {}

	if p1.goingDownTrack then
		table.insert(t, p1.goingDownTrack)
	end

	if p1.drillingTrack then
		table.insert(t, p1.drillingTrack)
	end

	if p1.goingUpTrack then
		table.insert(t, p1.goingUpTrack)
	end

	for v1, v2 in t do
		v2:Stop()
	end

	local goingDownTrack = p1.goingDownTrack
	local drillingTrack = p1.drillingTrack

	if drillingTrack then
		if goingDownTrack then
			local sequenceGeneration = p1.sequenceGeneration

			task.spawn(function() --[[ Line: 233 | Upvalues: goingDownTrack (copy), p1 (copy), sequenceGeneration (copy), drillingTrack (copy) ]]
				goingDownTrack:Play()
				goingDownTrack.Stopped:Wait()

				if p1.sequenceGeneration == sequenceGeneration and (p1.ready == false and p1.model.Parent) then
					drillingTrack:Play()
				end
			end)
		else
			drillingTrack:Play()
		end
	else
		if not goingDownTrack then
			return
		end

		goingDownTrack:Play()
	end
end

local function playReadyAnimation(p1) --[[ playReadyAnimation | Line: 243 ]]
	p1.sequenceGeneration = (p1.sequenceGeneration or 0) + 1

	local t = {}

	if p1.goingDownTrack then
		table.insert(t, p1.goingDownTrack)
	end

	if p1.drillingTrack then
		table.insert(t, p1.drillingTrack)
	end

	if p1.goingUpTrack then
		table.insert(t, p1.goingUpTrack)
	end

	for v1, v2 in t do
		v2:Stop()
	end

	if not p1.goingUpTrack then
		return
	end

	p1.goingUpTrack:Play()
end

local function setGemVisible(p1, p2) --[[ setGemVisible | Line: 250 ]]
	for v1, v2 in p1.gemParts do
		v2.LocalTransparencyModifier = if p2 then 0 else 1
	end
end

function t2.Init(p1) --[[ Init | Line: 256 | Upvalues: Players (copy), findFill (copy), t (copy), GardenConfig (copy), DecorationConfig (copy), collectEmitters (copy), collectGemParts (copy), createLoopSound (copy), getAnimator (copy), loadTrack (copy), AnimationConfig (copy), startProducingAnimations (copy), convertTimeHMS (copy), CollectionService (copy), DrillTag (copy), RunService (copy) ]]
	local LocalPlayer = Players.LocalPlayer
	local t2 = {}

	local function teardown(p1) --[[ teardown | Line: 260 | Upvalues: t2 (copy) ]]
		local v1 = t2[p1]

		if not v1 then
			return
		end

		v1.sequenceGeneration = (v1.sequenceGeneration or 0) + 1

		local t = {}

		if v1.goingDownTrack then
			table.insert(t, v1.goingDownTrack)
		end

		if v1.drillingTrack then
			table.insert(t, v1.drillingTrack)
		end

		if v1.goingUpTrack then
			table.insert(t, v1.goingUpTrack)
		end

		for v2, v3 in t do
			v3:Stop()
		end

		if v1.goingUpTrack then
			v1.goingUpTrack:Stop()
		end

		if not v1.loopSound then
			t2[p1] = nil

			return
		end

		v1.loopSound:Destroy()
		t2[p1] = nil
	end

	local function setup(p1) --[[ setup | Line: 275 | Upvalues: t2 (copy), findFill (ref), t (ref), GardenConfig (ref), DecorationConfig (ref), collectEmitters (ref), collectGemParts (ref), createLoopSound (ref), LocalPlayer (copy), getAnimator (ref), loadTrack (ref), AnimationConfig (ref) ]]
		if not p1:IsA("Model") or t2[p1] then
			return
		end

		local v1 = p1:FindFirstChildWhichIsA("BillboardGui", true)
		local v2 = if v1 then v1:FindFirstChild("Main") else v1

		if not v2 then
			warn((("[GardenDrill] %* has no BillboardGui.Main \226\128\148 no status display"):format(p1.Name)))
		end

		local v3 = if v2 then v2:FindFirstChild("ProgressBar") else v2
		local v4 = if v2 then v2:FindFirstChild("ReadyLabel") else v2
		local v5 = if v3 then findFill(v3) else v3
		local v6 = if v3 then v3:FindFirstChild("TimeLeft") else v3

		if v3 and not v5 then
			warn((("[GardenDrill] %* ProgressBar has no %* \226\128\148 bar stays empty"):format(p1.Name, (table.concat(t, "/")))))
		end

		local v7 = p1:FindFirstChild(GardenConfig.DrillRootName, true)
		local v8 = if v7 then v7:FindFirstChild(GardenConfig.DrillPromptName) else v7
		local v9 = p1:GetAttribute("ConfigName")
		local v10 = if typeof(v9) == "string" then DecorationConfig[v9] else nil
		local v11 = p1:FindFirstChild(GardenConfig.DrillGemPartName, true)
		local v12, v13 = collectEmitters(p1, v11)
		local t3 = {
			sequenceGeneration = 0,
			ready = nil,
			culled = false,
			model = p1
		}

		t3.progressBar = if v3 and v3:IsA("GuiObject") then v3 else nil
		t3.fill = v5
		t3.timeLeft = if v6 and v6:IsA("TextLabel") then v6 else nil
		t3.readyLabel = if v4 and v4:IsA("GuiObject") then v4 else nil
		t3.gemParts = collectGemParts(v11)
		t3.bodyEmitters = v12
		t3.gemEmitters = v13
		t3.prompt = if v8 and v8:IsA("ProximityPrompt") then v8 else nil
		t3.loopSound = createLoopSound(p1)
		t3.isOwner = if p1:GetAttribute("OwnerUserId") == LocalPlayer.UserId then true else false
		t3.produceSeconds = v10 and v10.ProduceSeconds or 0

		local v20 = getAnimator(p1)

		if v20 then
			t3.drillingTrack = loadTrack(v20, AnimationConfig.Drill.Drilling, true)
			t3.goingDownTrack = loadTrack(v20, AnimationConfig.Drill.GoingDown, false)
			t3.goingUpTrack = loadTrack(v20, AnimationConfig.Drill.GoingUp, false)
		end

		t2[p1] = t3
	end

	local function applyState(p1, p2, p3) --[[ applyState | Line: 334 | Upvalues: startProducingAnimations (ref), convertTimeHMS (ref) ]]
		local v1 = if p1.ready == p2 then false else true

		p1.ready = p2

		if p1.progressBar then
			p1.progressBar.Visible = not p2
		end

		if p1.readyLabel then
			p1.readyLabel.Visible = p2
		end

		if p1.prompt then
			p1.prompt.Enabled = if p2 then p1.isOwner else p2
		end

		if v1 then
			for v3, v4 in p1.gemParts do
				v4.LocalTransparencyModifier = if p2 then 0 else 1
			end

			local v6 = not p2

			for v7, v8 in p1.bodyEmitters do
				v8.Enabled = v6
			end

			for v9, v10 in p1.gemEmitters do
				v10.Enabled = p2
			end

			local v11 = not p2
			local loopSound = p1.loopSound

			if loopSound and (v11 and not loopSound.IsPlaying) then
				loopSound:Play()
			elseif loopSound and (not v11 and loopSound.IsPlaying) then
				loopSound:Stop()
			end

			if p2 then
				p1.sequenceGeneration = (p1.sequenceGeneration or 0) + 1

				local t = {}

				if p1.goingDownTrack then
					table.insert(t, p1.goingDownTrack)
				end

				if p1.drillingTrack then
					table.insert(t, p1.drillingTrack)
				end

				if p1.goingUpTrack then
					table.insert(t, p1.goingUpTrack)
				end

				for v12, v13 in t do
					v13:Stop()
				end

				if p1.goingUpTrack then
					p1.goingUpTrack:Play()
				end
			else
				startProducingAnimations(p1)
			end
		end

		if p2 then
			return
		end

		if p1.fill then
			local produceSeconds = p1.produceSeconds

			p1.fill.Size = UDim2.fromScale(if produceSeconds > 0 then math.clamp(1 - p3 / produceSeconds, 0, 1) else 0, 1)
		end

		if not p1.timeLeft then
			return
		end

		p1.timeLeft.Text = convertTimeHMS(p3)
	end

	local function update() --[[ update | Line: 375 | Upvalues: LocalPlayer (copy), t2 (copy), GardenConfig (ref), applyState (copy) ]]
		local Character = LocalPlayer.Character
		local v1 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character
		local v2 = if v1 then v1.Position else v1
		local v3 = workspace:GetServerTimeNow()

		for v4, v5 in t2 do
			if v4.Parent then
				if v2 then
					local Position = v4:GetPivot().Position
					local v6 = Position.X - v2.X
					local v7 = Position.Z - v2.Z

					if v6 * v6 + v7 * v7 > 14400 then
						if not v5.culled then
							v5.culled = true
							v5.sequenceGeneration = (v5.sequenceGeneration or 0) + 1

							local t = {}

							if v5.goingDownTrack then
								table.insert(t, v5.goingDownTrack)
							end

							if v5.drillingTrack then
								table.insert(t, v5.drillingTrack)
							end

							if v5.goingUpTrack then
								table.insert(t, v5.goingUpTrack)
							end

							for v8, v9 in t do
								v9:Stop()
							end

							local loopSound = v5.loopSound

							if loopSound and loopSound.IsPlaying then
								loopSound:Stop()
							end
						end

						continue
					end
				end

				if v5.culled then
					v5.culled = false
					v5.ready = nil
				end

				local v10 = v4:GetAttribute(GardenConfig.DrillReadyAtAttribute)

				if typeof(v10) == "number" then
					local v11 = v10 - v3

					applyState(v5, v11 <= 0, (math.max(0, v11)))
				end

				continue
			end

			local v14 = t2[v4]

			if v14 then
				v14.sequenceGeneration = (v14.sequenceGeneration or 0) + 1

				local t = {}

				if v14.goingDownTrack then
					table.insert(t, v14.goingDownTrack)
				end

				if v14.drillingTrack then
					table.insert(t, v14.drillingTrack)
				end

				if v14.goingUpTrack then
					table.insert(t, v14.goingUpTrack)
				end

				for v15, v16 in t do
					v16:Stop()
				end

				if v14.goingUpTrack then
					v14.goingUpTrack:Stop()
				end

				if v14.loopSound then
					v14.loopSound:Destroy()
				end

				t2[v4] = nil
			end
		end
	end

	CollectionService:GetInstanceAddedSignal(DrillTag):Connect(setup)
	CollectionService:GetInstanceRemovedSignal(DrillTag):Connect(teardown)

	for v1, v2 in CollectionService:GetTagged(DrillTag) do
		task.spawn(setup, v2)
	end

	local v3 = 0

	RunService.Heartbeat:Connect(function(p1) --[[ Line: 421 | Upvalues: v3 (ref), update (copy) ]]
		debug.profilebegin("UECS/GardenDrill.Update")
		v3 = v3 + p1

		if not (v3 < 1) then
			v3 = 0
			update()
		end

		debug.profileend()
	end)
end

return t2