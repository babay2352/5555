-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local SocialService = game:GetService("SocialService")
local StarterGui = game:GetService("StarterGui")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local TeaserConfig = require(ReplicatedStorage.shared.config.TeaserConfig)
local EventId = TeaserConfig.EventId
local AnimationId = TeaserConfig.AnimationId
local t = {
	UECS = nil
}
local t2 = {}

local function eventTimeToUnix(p1) --[[ eventTimeToUnix | Line: 46 ]]
	return DateTime.fromUniversalTime(p1.Year, p1.Month, p1.Day, p1.Hour, p1.Minute, p1.Second).UnixTimestamp
end

local function formatCountdown(p1) --[[ formatCountdown | Line: 53 ]]
	if p1 <= 0 then
		return "00:00"
	end

	local v1 = math.floor(p1 / 86400)
	local v2 = math.floor(p1 % 86400 / 3600)
	local v3 = math.floor(p1 % 3600 / 60)
	local v4 = math.floor(p1 % 60)

	if v1 > 0 then
		return string.format("%dd %02d:%02d:%02d", v1, v2, v3, v4)
	end

	if v2 > 0 then
		return string.format("%02d:%02d:%02d", v2, v3, v4)
	end

	return string.format("%02d:%02d", v3, v4)
end

local function setCountdownText(p1, p2) --[[ setCountdownText | Line: 70 | Upvalues: formatCountdown (copy) ]]
	p1.Text = "Event starts in: " .. formatCountdown(p2)
end

local function findRestockLabel(p1) --[[ findRestockLabel | Line: 74 ]]
	local Restock = p1:FindFirstChild("Restock", true)

	if Restock and Restock:IsA("TextLabel") then
		return Restock
	end

	local Timer = p1:FindFirstChild("Timer", true)

	if Timer and Timer:IsA("TextLabel") then
		return Timer
	end

	return nil
end

local function setupCountdown(p1, p2, p3) --[[ setupCountdown | Line: 88 | Upvalues: SocialService (copy), EventId (copy), t2 (copy), RunService (copy), formatCountdown (copy) ]]
	task.spawn(function() --[[ Line: 89 | Upvalues: SocialService (ref), EventId (ref), t2 (ref), p1 (copy), RunService (ref), p3 (copy), formatCountdown (ref), p2 (copy) ]]
		local v12 = nil
		local ok, result = pcall(function() --[[ Line: 91 | Upvalues: SocialService (ref), EventId (ref), v12 (ref) ]]
			local v122 = SocialService:GetExperienceEventAsync(EventId)

			if not v122 or (v122.HasEnded or v122.HasStarted) then
				return
			end

			local StartTime = v122.StartTime

			v12 = DateTime.fromUniversalTime(StartTime.Year, StartTime.Month, StartTime.Day, StartTime.Hour, StartTime.Minute, StartTime.Second).UnixTimestamp
		end)

		if not ok then
			warn("[EventBgui] Countdown event fetch failed:", result)
		end

		if t2[p1] then
			if v12 == nil and not RunService:IsStudio() then
				p3.Text = "Event starts in: 00:00"
			elseif v12 == nil then
				v12 = workspace:GetServerTimeNow() + 3600
			end

			local function v() --[[ tick | Line: 116 | Upvalues: p3 (ref), v12 (ref), formatCountdown (ref) ]]
				p3.Text = "Event starts in: " .. formatCountdown(v12 - workspace:GetServerTimeNow())
			end

			p3.Text = "Event starts in: " .. formatCountdown(v12 - workspace:GetServerTimeNow())

			local v22 = 0

			p2.countdown = RunService.Heartbeat:Connect(function(p13) --[[ Line: 122 | Upvalues: v22 (ref), p3 (ref), v12 (ref), formatCountdown (ref) ]]
				debug.profilebegin("UECS/EventBgui.Countdown")
				v22 = v22 + p13

				if not (v22 < 1) then
					v22 = 0
					p3.Text = "Event starts in: " .. formatCountdown(v12 - workspace:GetServerTimeNow())
				end

				debug.profileend()
			end)
		end
	end)
end

local function playAnimationOn(p1) --[[ playAnimationOn | Line: 142 | Upvalues: AnimationId (copy) ]]
	if not AnimationId or AnimationId == "" then
		return nil
	end

	local AnimationController = p1:FindFirstChild("AnimationController", true)

	if not (AnimationController and AnimationController:IsA("AnimationController")) then
		warn("[EventBgui] No AnimationController found under", p1:GetFullName())

		return nil
	end

	local Animator = AnimationController:FindFirstChildOfClass("Animator")

	if not Animator then
		Animator = Instance.new("Animator")
		Animator.Parent = AnimationController
	end

	local Animation = Instance.new("Animation")

	Animation.AnimationId = AnimationId

	local ok, result = pcall(function() --[[ Line: 162 | Upvalues: Animator (ref), Animation (copy) ]]
		return Animator:LoadAnimation(Animation)
	end)

	if ok and result then
		result.Looped = true
		result.Priority = Enum.AnimationPriority.Idle
		result:Play()

		return result
	end

	warn("[EventBgui] LoadAnimation failed for", p1:GetFullName(), "-", result)

	return nil
end

local function playAnimation(p1) --[[ playAnimation | Line: 178 | Upvalues: playAnimationOn (copy) ]]
	local v1 = p1.Parent and p1.Parent.Parent

	if v1 then
		return playAnimationOn(v1)
	end

	return nil
end

local function resolvePromptHost(p1) --[[ resolvePromptHost | Line: 190 ]]
	if p1:IsA("BasePart") or p1:IsA("Attachment") then
		return p1
	end

	if p1:IsA("BillboardGui") or p1:IsA("SurfaceGui") then
		local Adornee = p1.Adornee

		if Adornee and (Adornee:IsA("BasePart") or Adornee:IsA("Attachment")) then
			return Adornee
		end
	end

	local v1 = p1.Parent

	if not (v1 and (v1:IsA("BasePart") or v1:IsA("Attachment"))) then
		return nil
	end

	return v1
end

local function ensurePrompt(p1) --[[ ensurePrompt | Line: 208 ]]
	local v1 = p1:FindFirstChildWhichIsA("ProximityPrompt")

	if v1 then
		return v1
	end

	local EventRsvp = Instance.new("ProximityPrompt")

	EventRsvp.Name = "EventRsvp"
	EventRsvp.Style = Enum.ProximityPromptStyle.Custom
	EventRsvp.ActionText = "Join"
	EventRsvp.ObjectText = "Event"
	EventRsvp.HoldDuration = 0
	EventRsvp.MaxActivationDistance = 10
	EventRsvp.Parent = p1

	return EventRsvp
end

local function setupPrompt(p1, p2) --[[ setupPrompt | Line: 225 | Upvalues: resolvePromptHost (copy), SocialService (copy), EventId (copy), t2 (copy), RunService (copy) ]]
	local v1 = resolvePromptHost(p1)

	if not v1 then
		return
	end

	local v2 = v1:FindFirstChildWhichIsA("ProximityPrompt")
	local v3

	if v2 then
		v3 = v2
	else
		local EventRsvp = Instance.new("ProximityPrompt")

		EventRsvp.Name = "EventRsvp"
		EventRsvp.Style = Enum.ProximityPromptStyle.Custom
		EventRsvp.ActionText = "Join"
		EventRsvp.ObjectText = "Event"
		EventRsvp.HoldDuration = 0
		EventRsvp.MaxActivationDistance = 10
		EventRsvp.Parent = v1
		v3 = EventRsvp
	end

	p2.prompt = v3
	v3.Enabled = false
	p2.triggered = v3.Triggered:Connect(function(p1) --[[ Line: 240 | Upvalues: SocialService (ref), EventId (ref) ]]
		local ok, result = pcall(function() --[[ Line: 241 | Upvalues: SocialService (ref), EventId (ref) ]]
			SocialService:PromptRsvpToEventAsync(EventId)
		end)

		if ok then
			return
		end

		warn(("[EventBgui] RSVP prompt failed for event %*:"):format(EventId), result)
	end)
	task.spawn(function() --[[ Line: 249 | Upvalues: SocialService (ref), EventId (ref), t2 (ref), p1 (copy), v3 (copy), RunService (ref) ]]
		local v1 = nil
		local ok, result = pcall(function() --[[ Line: 251 | Upvalues: v1 (ref), SocialService (ref), EventId (ref) ]]
			v1 = SocialService:GetExperienceEventAsync(EventId)
		end)

		if t2[p1] then
			if not ok then
				warn("[EventBgui] Failed to fetch event:", result)
				v3.Enabled = RunService:IsStudio()
			elseif v1 and not v1.HasEnded then
				v3.Enabled = true
			else
				v3.Enabled = RunService:IsStudio()
			end
		end
	end)
end

local function stopFor(p1) --[[ stopFor | Line: 277 | Upvalues: t2 (copy) ]]
	local v1 = t2[p1]

	if not v1 then
		return
	end

	if v1.triggered then
		v1.triggered:Disconnect()
	end

	if v1.countdown then
		v1.countdown:Disconnect()
	end

	if v1.destroying then
		v1.destroying:Disconnect()
	end

	if v1.track then
		v1.track:Stop()
		v1.track:Destroy()
	end

	t2[p1] = nil
end

local function startFor(p1) --[[ startFor | Line: 298 | Upvalues: t2 (copy), StarterGui (copy), stopFor (copy), playAnimationOn (copy), SocialService (copy), EventId (copy), RunService (copy), formatCountdown (copy), setupPrompt (copy) ]]
	if t2[p1] then
		return
	end

	if (p1:IsA("LayerCollector") or p1:IsA("GuiObject")) and p1:IsDescendantOf(StarterGui) then
		return
	end

	local t = {}

	t2[p1] = t
	t.destroying = p1.Destroying:Connect(function() --[[ Line: 311 | Upvalues: stopFor (ref), p1 (copy) ]]
		stopFor(p1)
	end)

	local v1 = p1.Parent and p1.Parent.Parent

	t.track = if v1 then playAnimationOn(v1) else nil

	local Restock = p1:FindFirstChild("Restock", true)
	local v3

	if Restock and Restock:IsA("TextLabel") then
		v3 = Restock
	else
		local Timer = p1:FindFirstChild("Timer", true)

		v3 = if Timer and Timer:IsA("TextLabel") then Timer else nil
	end

	if v3 then
		task.spawn(function() --[[ Line: 89 | Upvalues: SocialService (ref), EventId (ref), t2 (ref), p1 (copy), RunService (ref), v3 (copy), formatCountdown (ref), t (copy) ]]
			local v12 = nil
			local ok, result = pcall(function() --[[ Line: 91 | Upvalues: SocialService (ref), EventId (ref), v12 (ref) ]]
				local v122 = SocialService:GetExperienceEventAsync(EventId)

				if not v122 or (v122.HasEnded or v122.HasStarted) then
					return
				end

				local StartTime = v122.StartTime

				v12 = DateTime.fromUniversalTime(StartTime.Year, StartTime.Month, StartTime.Day, StartTime.Hour, StartTime.Minute, StartTime.Second).UnixTimestamp
			end)

			if not ok then
				warn("[EventBgui] Countdown event fetch failed:", result)
			end

			if t2[p1] then
				if v12 == nil and not RunService:IsStudio() then
					v3.Text = "Event starts in: 00:00"
				elseif v12 == nil then
					v12 = workspace:GetServerTimeNow() + 3600
				end

				local function v() --[[ tick | Line: 116 | Upvalues: v3 (ref), v12 (ref), formatCountdown (ref) ]]
					p3.Text = "Event starts in: " .. formatCountdown(v12 - workspace:GetServerTimeNow())
				end

				v3.Text = "Event starts in: " .. formatCountdown(v12 - workspace:GetServerTimeNow())

				local v22 = 0

				t.countdown = RunService.Heartbeat:Connect(function(p13) --[[ Line: 122 | Upvalues: v22 (ref), v3 (ref), v12 (ref), formatCountdown (ref) ]]
					debug.profilebegin("UECS/EventBgui.Countdown")
					v22 = v22 + p13

					if not (v22 < 1) then
						v22 = 0
						p3.Text = "Event starts in: " .. formatCountdown(v12 - workspace:GetServerTimeNow())
					end

					debug.profileend()
				end)
			end
		end)
	end

	setupPrompt(p1, t)
end

local function beginEntry(p1) --[[ beginEntry | Line: 332 | Upvalues: t2 (copy), stopFor (copy) ]]
	local t = {}

	t2[p1] = t
	t.destroying = p1.Destroying:Connect(function() --[[ Line: 335 | Upvalues: stopFor (ref), p1 (copy) ]]
		stopFor(p1)
	end)

	return t
end

local function startCountdownFor(p1) --[[ startCountdownFor | Line: 341 | Upvalues: t2 (copy), stopFor (copy), SocialService (copy), EventId (copy), RunService (copy), formatCountdown (copy) ]]
	if t2[p1] then
		return
	end

	local t = {}

	t2[p1] = t
	t.destroying = p1.Destroying:Connect(function() --[[ Line: 335 | Upvalues: stopFor (ref), p1 (copy) ]]
		stopFor(p1)
	end)

	local v1 = t
	local Restock = p1:FindFirstChild("Restock", true)
	local v2

	if Restock and Restock:IsA("TextLabel") then
		v2 = Restock
	else
		local Timer = p1:FindFirstChild("Timer", true)

		v2 = if Timer and Timer:IsA("TextLabel") then Timer else nil
	end

	if v2 then
		task.spawn(function() --[[ Line: 89 | Upvalues: SocialService (ref), EventId (ref), t2 (ref), p1 (copy), RunService (ref), v2 (copy), formatCountdown (ref), v1 (copy) ]]
			local v12 = nil
			local ok, result = pcall(function() --[[ Line: 91 | Upvalues: SocialService (ref), EventId (ref), v12 (ref) ]]
				local v122 = SocialService:GetExperienceEventAsync(EventId)

				if not v122 or (v122.HasEnded or v122.HasStarted) then
					return
				end

				local StartTime = v122.StartTime

				v12 = DateTime.fromUniversalTime(StartTime.Year, StartTime.Month, StartTime.Day, StartTime.Hour, StartTime.Minute, StartTime.Second).UnixTimestamp
			end)

			if not ok then
				warn("[EventBgui] Countdown event fetch failed:", result)
			end

			if t2[p1] then
				if v12 == nil and not RunService:IsStudio() then
					v2.Text = "Event starts in: 00:00"
				elseif v12 == nil then
					v12 = workspace:GetServerTimeNow() + 3600
				end

				local function v() --[[ tick | Line: 116 | Upvalues: v2 (ref), v12 (ref), formatCountdown (ref) ]]
					p3.Text = "Event starts in: " .. formatCountdown(v12 - workspace:GetServerTimeNow())
				end

				v2.Text = "Event starts in: " .. formatCountdown(v12 - workspace:GetServerTimeNow())

				local v22 = 0

				v1.countdown = RunService.Heartbeat:Connect(function(p13) --[[ Line: 122 | Upvalues: v22 (ref), v2 (ref), v12 (ref), formatCountdown (ref) ]]
					debug.profilebegin("UECS/EventBgui.Countdown")
					v22 = v22 + p13

					if not (v22 < 1) then
						v22 = 0
						p3.Text = "Event starts in: " .. formatCountdown(v12 - workspace:GetServerTimeNow())
					end

					debug.profileend()
				end)
			end
		end)
	else
		warn("[EventBgui] teaser.Bgui has no \'Timer\'/\'Restock\' TextLabel:", p1:GetFullName())
	end
end

local function startPromptFor(p1) --[[ startPromptFor | Line: 354 | Upvalues: t2 (copy), stopFor (copy), setupPrompt (copy) ]]
	if not t2[p1] then
		local t = {}

		t2[p1] = t
		t.destroying = p1.Destroying:Connect(function() --[[ Line: 335 | Upvalues: stopFor (ref), p1 (copy) ]]
			stopFor(p1)
		end)
		setupPrompt(p1, t)
	end
end

local function startAnimationFor(p1) --[[ startAnimationFor | Line: 362 | Upvalues: t2 (copy), stopFor (copy), playAnimationOn (copy) ]]
	if not t2[p1] then
		local t = {}

		t2[p1] = t
		t.destroying = p1.Destroying:Connect(function() --[[ Line: 335 | Upvalues: stopFor (ref), p1 (copy) ]]
			stopFor(p1)
		end)
		t.track = playAnimationOn(p1)
	end
end

local function setupTeaserFolder(p1) --[[ setupTeaserFolder | Line: 372 | Upvalues: t2 (copy), stopFor (copy), SocialService (copy), EventId (copy), RunService (copy), formatCountdown (copy), setupPrompt (copy), playAnimationOn (copy) ]]
	task.spawn(function() --[[ Line: 373 | Upvalues: p1 (copy), t2 (ref), stopFor (ref), SocialService (ref), EventId (ref), RunService (ref), formatCountdown (ref) ]]
		local Bgui = p1:WaitForChild("Bgui", 10)

		if not Bgui then
			return
		end

		if t2[Bgui] then
			return
		end

		local t = {}

		t2[Bgui] = t
		t.destroying = Bgui.Destroying:Connect(function() --[[ Line: 335 | Upvalues: stopFor (ref), Bgui (copy) ]]
			stopFor(Bgui)
		end)

		local v1 = t
		local Restock = Bgui:FindFirstChild("Restock", true)
		local v2

		if Restock and Restock:IsA("TextLabel") then
			v2 = Restock
		else
			local Timer = Bgui:FindFirstChild("Timer", true)

			v2 = if Timer and Timer:IsA("TextLabel") then Timer else nil
		end

		if v2 then
			task.spawn(function() --[[ Line: 89 | Upvalues: SocialService (ref), EventId (ref), t2 (ref), Bgui (copy), RunService (ref), v2 (copy), formatCountdown (ref), v1 (copy) ]]
				local v12 = nil
				local ok, result = pcall(function() --[[ Line: 91 | Upvalues: SocialService (ref), EventId (ref), v12 (ref) ]]
					local v122 = SocialService:GetExperienceEventAsync(EventId)

					if not v122 or (v122.HasEnded or v122.HasStarted) then
						return
					end

					local StartTime = v122.StartTime

					v12 = DateTime.fromUniversalTime(StartTime.Year, StartTime.Month, StartTime.Day, StartTime.Hour, StartTime.Minute, StartTime.Second).UnixTimestamp
				end)

				if not ok then
					warn("[EventBgui] Countdown event fetch failed:", result)
				end

				if t2[Bgui] then
					if v12 == nil and not RunService:IsStudio() then
						v2.Text = "Event starts in: 00:00"
					elseif v12 == nil then
						v12 = workspace:GetServerTimeNow() + 3600
					end

					local function v() --[[ tick | Line: 116 | Upvalues: v2 (ref), v12 (ref), formatCountdown (ref) ]]
						p3.Text = "Event starts in: " .. formatCountdown(v12 - workspace:GetServerTimeNow())
					end

					v2.Text = "Event starts in: " .. formatCountdown(v12 - workspace:GetServerTimeNow())

					local v22 = 0

					v1.countdown = RunService.Heartbeat:Connect(function(p13) --[[ Line: 122 | Upvalues: v22 (ref), v2 (ref), v12 (ref), formatCountdown (ref) ]]
						debug.profilebegin("UECS/EventBgui.Countdown")
						v22 = v22 + p13

						if not (v22 < 1) then
							v22 = 0
							p3.Text = "Event starts in: " .. formatCountdown(v12 - workspace:GetServerTimeNow())
						end

						debug.profileend()
					end)
				end
			end)

			return
		end

		warn("[EventBgui] teaser.Bgui has no \'Timer\'/\'Restock\' TextLabel:", Bgui:GetFullName())
	end)
	task.spawn(function() --[[ Line: 379 | Upvalues: p1 (copy), t2 (ref), stopFor (ref), setupPrompt (ref) ]]
		local Prompt = p1:WaitForChild("Prompt", 10)

		if not Prompt then
			return
		end

		if t2[Prompt] then
			return
		end

		local t = {}

		t2[Prompt] = t
		t.destroying = Prompt.Destroying:Connect(function() --[[ Line: 335 | Upvalues: stopFor (ref), Prompt (copy) ]]
			stopFor(Prompt)
		end)
		setupPrompt(Prompt, t)
	end)
	task.spawn(function() --[[ Line: 385 | Upvalues: p1 (copy), t2 (ref), stopFor (ref), playAnimationOn (ref) ]]
		local Model = p1:WaitForChild("Model", 10)

		if not Model then
			return
		end

		if t2[Model] then
			return
		end

		local t = {}

		t2[Model] = t
		t.destroying = Model.Destroying:Connect(function() --[[ Line: 335 | Upvalues: stopFor (ref), Model (copy) ]]
			stopFor(Model)
		end)
		t.track = playAnimationOn(Model)
	end)
end

function t.Init(p1) --[[ Init | Line: 393 | Upvalues: CollectionService (copy), startFor (copy), stopFor (copy), setupTeaserFolder (copy) ]]
	for v1, v2 in CollectionService:GetTagged("EventBgui") do
		startFor(v2)
	end

	CollectionService:GetInstanceAddedSignal("EventBgui"):Connect(startFor)
	CollectionService:GetInstanceRemovedSignal("EventBgui"):Connect(stopFor)
	task.spawn(function() --[[ Line: 402 | Upvalues: setupTeaserFolder (ref) ]]
		local teaser = workspace:WaitForChild("teaser", 30)

		if not teaser then
			return
		end

		setupTeaserFolder(teaser)
	end)
end

return t