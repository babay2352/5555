-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Debris = game:GetService("Debris")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local SoundService = game:GetService("SoundService")
local TweenService = game:GetService("TweenService")
local AutoCollect = require(ReplicatedStorage.shared.UECS.Components.AutoCollect)
local AutoCollectState = require(ReplicatedStorage.client.AutoCollectState)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Remotes = require(ReplicatedStorage.shared.Remotes)
local SFX = require(ReplicatedStorage.client.SFX)

require(ReplicatedStorage.shared.UECS.Components.TycoonStand)
require(ReplicatedStorage.client.VFX)

local LocalPlayer = Players.LocalPlayer
local t = {
	UECS = nil,
	Priority = 26
}
local v1 = UDim2.fromScale(2, 2)
local v2 = NumberRange.new(3, 6)
local v3 = Color3.fromRGB(255, 220, 100)
local v4 = Color3.fromRGB(100, 200, 255)

local function randomInRange(p1) --[[ randomInRange | Line: 64 ]]
	return p1.Min + math.random() * (p1.Max - p1.Min)
end

local function getHRP() --[[ getHRP | Line: 68 | Upvalues: LocalPlayer (copy) ]]
	local Character = LocalPlayer.Character

	return if Character then Character:FindFirstChild("HumanoidRootPart") else Character
end

local function playSound(p1) --[[ playSound | Line: 73 | Upvalues: SoundService (copy) ]]
	local SFX = SoundService:FindFirstChild("SFX")
	local v1 = if SFX then SFX:FindFirstChild(p1) else SFX

	if v1 and v1:IsA("Sound") then
		local v2 = v1:Clone()

		v2.PlaybackSpeed = v2.PlaybackSpeed * (1.05 + math.random() * 0.1)
		v2.PlayOnRemove = true
		v2.Parent = SoundService
		v2:Destroy()
	end
end

local function createFollowHost(p1) --[[ createFollowHost | Line: 87 ]]
	local Part = Instance.new("Part")

	Part.Anchored = true
	Part.CanCollide = false
	Part.CanQuery = false
	Part.CanTouch = false
	Part.Transparency = 1
	Part.Size = Vector3.new(0.1, 0.1, 0.1)
	Part.CFrame = CFrame.new(p1)
	Part.Parent = workspace

	return Part
end

local function setupBillboard(p1) --[[ setupBillboard | Line: 106 ]]
	local AutoCollectLabel = Instance.new("BillboardGui")

	AutoCollectLabel.Name = "AutoCollectLabel"
	AutoCollectLabel.Size = UDim2.fromScale(6, 2)
	AutoCollectLabel.StudsOffset = Vector3.new(0, 3, 0)
	AutoCollectLabel.LightInfluence = 0
	AutoCollectLabel.AlwaysOnTop = false
	AutoCollectLabel.Parent = p1

	local Handle = p1:FindFirstChild("Handle")

	if Handle and Handle:IsA("BasePart") then
		AutoCollectLabel.Adornee = Handle
	end

	local Frame = Instance.new("Frame")

	Frame.BackgroundTransparency = 1
	Frame.Size = UDim2.fromScale(1, 1)
	Frame.Parent = AutoCollectLabel

	local DisplayName = Instance.new("TextLabel")

	DisplayName.Name = "DisplayName"
	DisplayName.BackgroundTransparency = 1
	DisplayName.Size = UDim2.fromScale(1, 0.6)
	DisplayName.Position = UDim2.fromScale(0, 0)
	DisplayName.Text = "Auto Collect"
	DisplayName.TextColor3 = Color3.fromRGB(100, 220, 255)
	DisplayName.TextScaled = true
	DisplayName.Font = Enum.Font.GothamBold
	DisplayName.Parent = Frame

	local UIStroke = Instance.new("UIStroke")

	UIStroke.Color = Color3.fromRGB(0, 0, 0)
	UIStroke.Thickness = 2
	UIStroke.Parent = DisplayName

	local Description = Instance.new("TextLabel")

	Description.Name = "Description"
	Description.BackgroundTransparency = 1
	Description.Size = UDim2.fromScale(1, 0.4)
	Description.Position = UDim2.fromScale(0, 0.6)
	Description.Text = "Click to collect all cash!"
	Description.TextColor3 = Color3.fromRGB(200, 200, 200)
	Description.TextScaled = true
	Description.Font = Enum.Font.Gotham
	Description.Parent = Frame

	local UIStroke2 = Instance.new("UIStroke")

	UIStroke2.Color = Color3.fromRGB(0, 0, 0)
	UIStroke2.Thickness = 1.5
	UIStroke2.Parent = Description
	AutoCollectLabel.Enabled = true
end

local function playMagneticPulse(p1) --[[ playMagneticPulse | Line: 164 | Upvalues: v4 (copy), TweenService (copy), Debris (copy) ]]
	local Part = Instance.new("Part")

	Part.Shape = Enum.PartType.Ball
	Part.Anchored = true
	Part.CanCollide = false
	Part.CanQuery = false
	Part.CanTouch = false
	Part.Material = Enum.Material.Neon
	Part.Color = v4
	Part.Size = Vector3.new(1, 1, 1)
	Part.Transparency = 0.5
	Part.CFrame = CFrame.new(p1)
	Part.Parent = workspace
	TweenService:Create(Part, TweenInfo.new(0.6, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
		Size = Vector3.new(30, 30, 30),
		Transparency = 1
	}):Play()
	Debris:AddItem(Part, 0.7)
end

local function spawnFlyingCash(p1) --[[ spawnFlyingCash | Line: 190 | Upvalues: LocalPlayer (copy), Debris (copy), v1 (copy), v3 (copy), v2 (copy), RunService (copy), TweenService (copy) ]]
	local Character = LocalPlayer.Character

	if Character and Character:FindFirstChild("HumanoidRootPart") then
		local Part = Instance.new("Part")

		Part.Anchored = true
		Part.CanCollide = false
		Part.CanQuery = false
		Part.CanTouch = false
		Part.Transparency = 1
		Part.Size = Vector3.new(0.1, 0.1, 0.1)
		Part.CFrame = CFrame.new(p1)
		Part.Parent = workspace

		local v22 = Part

		Debris:AddItem(v22, 1.35)

		local Attachment = Instance.new("Attachment")

		Attachment.Parent = v22

		local Attachment2 = Instance.new("Attachment")

		Attachment2.Position = Vector3.new(0, 0.5, 0)
		Attachment2.Parent = v22

		local BillboardGui = Instance.new("BillboardGui")

		BillboardGui.Size = v1
		BillboardGui.Adornee = Attachment
		BillboardGui.LightInfluence = 0
		BillboardGui.Parent = Attachment

		local ImageLabel = Instance.new("ImageLabel")

		ImageLabel.BackgroundTransparency = 1
		ImageLabel.Size = UDim2.fromScale(1, 1)
		ImageLabel.Image = "rbxassetid://93898068805552"
		ImageLabel.Parent = BillboardGui

		local Trail = Instance.new("Trail")

		Trail.Attachment0 = Attachment
		Trail.Attachment1 = Attachment2
		Trail.Lifetime = 0.25
		Trail.MinLength = 0
		Trail.Color = ColorSequence.new(v3)
		Trail.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.2), NumberSequenceKeypoint.new(1, 1) })
		Trail.LightEmission = 0.5
		Trail.Parent = v22

		local v32 = v2
		local v4 = v32.Min + math.random() * (v32.Max - v32.Min)
		local v5 = (math.random() * 2 - 1) * 3
		local v6 = (math.random() * 2 - 1) * 3

		task.spawn(function() --[[ Line: 237 | Upvalues: Attachment (copy), RunService (ref), LocalPlayer (ref), v22 (copy), v5 (copy), v4 (copy), v6 (copy), Attachment2 (copy), TweenService (ref), ImageLabel (copy), Trail (copy) ]]
			local v1 = Instance.new("NumberValue")

			v1.Parent = Attachment

			local v2 = nil

			v2 = RunService.Heartbeat:Connect(function() --[[ Line: 242 | Upvalues: Attachment (ref), v2 (ref), LocalPlayer (ref), v22 (ref), v5 (ref), v4 (ref), v6 (ref), v1 (copy), Attachment2 (ref) ]]
				debug.profilebegin("UECS/AutoCollectHandler.FlyArc")

				if not Attachment.Parent then
					v2:Disconnect()
					debug.profileend()

					return
				end

				local Character = LocalPlayer.Character
				local v12 = Character and Character:FindFirstChild("HumanoidRootPart")

				if v12 then
					local v23 = v12.Position - v22.Position
					local v62 = v23 * 0.5 + Vector3.new(v5, v4, v6)
					local v7 = v1.Value
					local v8 = 1 - v7
					local v9 = v8 * v8 * Vector3.new(0, 0, 0) + 2 * v8 * v7 * v62 + v7 * v7 * v23

					Attachment.Position = v9
					Attachment2.Position = v9 + Vector3.new(0, 0.5, 0)
				end

				debug.profileend()
			end)
			TweenService:Create(v1, TweenInfo.new(0.6, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
				Value = 1
			}):Play()
			task.delay(0.36, function() --[[ Line: 274 | Upvalues: TweenService (ref), ImageLabel (ref) ]]
				TweenService:Create(ImageLabel, TweenInfo.new(0.24), {
					ImageTransparency = 1
				}):Play()
			end)
			task.wait(0.6)
			v2:Disconnect()
			Trail.Enabled = false
			task.wait(0.25)
			v22:Destroy()
		end)
	end
end

local function playAutoCollectVFX(p1) --[[ playAutoCollectVFX | Line: 290 | Upvalues: LocalPlayer (copy), playMagneticPulse (copy), SFX (copy), spawnFlyingCash (copy), playSound (copy) ]]
	local Character = LocalPlayer.Character
	local v1 = Character and Character:FindFirstChild("HumanoidRootPart")

	if not v1 then
		return
	end

	local v2

	if #p1 > 12 then
		local v3 = table.clone(p1)
		local v4 = v3

		for i = #v3, 2, -1 do
			local v5 = math.random(1, i)
			local v7 = v4[i]

			v4[i] = v4[v5]
			v4[v5] = v7
		end

		local v8 = table.create(12)

		v8[1] = v4[1]
		v8[2] = v4[2]
		v8[3] = v4[3]
		v8[4] = v4[4]
		v8[5] = v4[5]
		v8[6] = v4[6]
		v8[7] = v4[7]
		v8[8] = v4[8]
		v8[9] = v4[9]
		v8[10] = v4[10]
		v8[11] = v4[11]
		v8[12] = v4[12]
		v2 = v8
	else
		v2 = p1
	end

	playMagneticPulse(v1.Position)
	SFX.PlaySoundWithRandomPitch(SFX.Sounds.BigMoney, 0.8, 0.9, 1.1)

	for v9, v10 in v2 do
		task.delay((v9 - 1) * 0.12, function() --[[ Line: 318 | Upvalues: v10 (copy), spawnFlyingCash (ref), playSound (ref) ]]
			local v1 = v10.Position + Vector3.new(0, 3, 0)

			for i = 1, 3 do
				task.delay(math.random() * 0.15, function() --[[ Line: 323 | Upvalues: spawnFlyingCash (ref), v1 (copy) ]]
					spawnFlyingCash(v1)
				end)
			end

			playSound("CashPickup")
		end)
	end

	task.delay(0.42, function() --[[ Line: 334 | Upvalues: playSound (ref) ]]
		playSound("CashCollect")
	end)
	task.delay((#v2 - 1) * 0.12 + 0.6, function() --[[ Line: 340 | Upvalues: playSound (ref), LocalPlayer (ref), playMagneticPulse (ref) ]]
		playSound("CashPickupEnd")

		local Character = LocalPlayer.Character
		local v1 = Character and Character:FindFirstChild("HumanoidRootPart")

		if not v1 then
			return
		end

		playMagneticPulse(v1.Position)
	end)
end

function t.Init(p1) --[[ Init | Line: 354 | Upvalues: Remotes (copy), AutoCollect (copy), LocalPlayer (copy), AutoCollectState (copy), playAutoCollectVFX (copy), ReplicatedStorage (copy) ]]
	local v1 = 0
	local t = {}

	local function wireToolActivation(p1) --[[ wireToolActivation | Line: 360 | Upvalues: t (copy), v1 (ref), Remotes (ref) ]]
		if not t[p1] then
			t[p1] = true
			p1.Activated:Connect(function() --[[ Line: 367 | Upvalues: v1 (ref), Remotes (ref) ]]
				local v12 = os.clock()

				if not (v12 - v1 < 1) then
					v1 = v12
					Remotes.RequestUseAutoCollect:Fire()
				end
			end)
		end
	end

	function AutoCollect._ComponentCreated(p1, p2) --[[ Line: 378 | Upvalues: t (copy), v1 (ref), Remotes (ref) ]]
		local Entity = p2.Entity

		if not Entity:IsA("Tool") then
			return
		end

		if not t[Entity] then
			t[Entity] = true
			Entity.Activated:Connect(function() --[[ Line: 367 | Upvalues: v1 (ref), Remotes (ref) ]]
				local v12 = os.clock()

				if not (v12 - v1 < 1) then
					v1 = v12
					Remotes.RequestUseAutoCollect:Fire()
				end
			end)
		end
	end

	local function scanForAutoCollectTools(p1) --[[ scanForAutoCollectTools | Line: 388 | Upvalues: t (copy), v1 (ref), Remotes (ref) ]]
		for v12, v2 in p1:GetChildren() do
			if v2:IsA("Tool") and v2.Name == "AutoCollect" and not t[v2] then
				t[v2] = true
				v2.Activated:Connect(function() --[[ Line: 367 | Upvalues: v1 (ref), Remotes (ref) ]]
					local v12 = os.clock()

					if not (v12 - v1 < 1) then
						v1 = v12
						Remotes.RequestUseAutoCollect:Fire()
					end
				end)
			end
		end
	end

	local function setupCharacterWatcher(p1) --[[ setupCharacterWatcher | Line: 396 | Upvalues: scanForAutoCollectTools (copy), t (copy), v1 (ref), Remotes (ref) ]]
		scanForAutoCollectTools(p1)
		p1.ChildAdded:Connect(function(p13) --[[ Line: 398 | Upvalues: t (ref), v1 (ref), Remotes (ref) ]]
			if not p13:IsA("Tool") or p13.Name ~= "AutoCollect" then
				return
			end

			if t[p13] then
				return
			end

			t[p13] = true
			p13.Activated:Connect(function() --[[ Line: 367 | Upvalues: v1 (ref), Remotes (ref) ]]
				local v12 = os.clock()

				if not (v12 - v1 < 1) then
					v1 = v12
					Remotes.RequestUseAutoCollect:Fire()
				end
			end)
		end)
	end

	local Backpack = LocalPlayer:WaitForChild("Backpack")

	scanForAutoCollectTools(Backpack)
	Backpack.ChildAdded:Connect(function(p1) --[[ Line: 408 | Upvalues: t (copy), v1 (ref), Remotes (ref) ]]
		if not p1:IsA("Tool") or p1.Name ~= "AutoCollect" then
			return
		end

		if t[p1] then
			return
		end

		t[p1] = true
		p1.Activated:Connect(function() --[[ Line: 367 | Upvalues: v1 (ref), Remotes (ref) ]]
			local v12 = os.clock()

			if not (v12 - v1 < 1) then
				v1 = v12
				Remotes.RequestUseAutoCollect:Fire()
			end
		end)
	end)

	if LocalPlayer.Character then
		local Character = LocalPlayer.Character

		scanForAutoCollectTools(Character)
		Character.ChildAdded:Connect(function(p13) --[[ Line: 398 | Upvalues: t (copy), v1 (ref), Remotes (ref) ]]
			if not p13:IsA("Tool") or p13.Name ~= "AutoCollect" then
				return
			end

			if t[p13] then
				return
			end

			t[p13] = true
			p13.Activated:Connect(function() --[[ Line: 367 | Upvalues: v1 (ref), Remotes (ref) ]]
				local v12 = os.clock()

				if not (v12 - v1 < 1) then
					v1 = v12
					Remotes.RequestUseAutoCollect:Fire()
				end
			end)
		end)
	end

	LocalPlayer.CharacterAdded:Connect(setupCharacterWatcher)
	Remotes.AutoCollectActivated:On(function(p12) --[[ Line: 421 | Upvalues: AutoCollectState (ref), p1 (copy), LocalPlayer (ref), playAutoCollectVFX (ref), ReplicatedStorage (ref) ]]
		if type(p12) ~= "table" then
			return
		end

		if type(p12.SlotNames) ~= "table" then
			return
		end

		AutoCollectState.MarkSlots(p12.SlotNames)

		local t = {}

		for k, v in pairs((p1.UECS:GetComponents("TycoonStand"))) do
			if v.Owner:Get() == LocalPlayer then
				local v2 = v.BaseSlotIndexName:Get()

				if type(v2) == "string" then
					local v3 = false

					for v4, v5 in p12.SlotNames do
						if v5 == v2 then
							v3 = true

							break
						end
					end

					if v3 then
						local v6 = v.CollectButton:Get()

						if typeof(v6) ~= "Instance" and v.Entity then
							v6 = v.Entity:FindFirstChild("CollectButton")
						end

						if typeof(v6) == "Instance" and v6:IsA("BasePart") then
							table.insert(t, v6)
						end
					end
				end
			end
		end

		if #t > 0 then
			playAutoCollectVFX(t)
		end

		if type(p12.TotalCash) ~= "number" or not (p12.TotalCash > 0) then
			return
		end

		local HUD = require(ReplicatedStorage.shared.UECS.Systems.Client.HUD)

		if not (HUD and HUD.PlayCashGain) then
			return
		end

		task.spawn(HUD.PlayCashGain, HUD, p12.TotalCash)
	end)
end

return t