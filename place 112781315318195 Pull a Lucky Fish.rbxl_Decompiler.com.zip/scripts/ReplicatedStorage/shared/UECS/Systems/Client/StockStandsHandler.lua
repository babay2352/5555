-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local FishConfig = require(ReplicatedStorage.shared.config.FishConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local buildFishModel = require(ReplicatedStorage.shared.util.buildFishModel)
local t = {
	UECS = nil
}

local function setupStand(p1, p2, p3) --[[ setupStand | Line: 16 | Upvalues: FishConfig (copy), buildFishModel (copy), CollectionService (copy), ReplicatedStorage (copy) ]]
	local v1 = FishConfig[p3]

	if not v1 then
		warn((("[StockStandsHandler] missing FishConfig entry \"%*\""):format(p3)))

		return
	end

	local v2 = buildFishModel.clone(p3, 1, nil)

	if not (v2 and v2.PrimaryPart) then
		warn((("[StockStandsHandler] buildFishModel returned nil for \"%*\" \226\128\148 model probably missing from FishModels"):format(p3)))

		return
	end

	local PrimaryPart = v2.PrimaryPart

	PrimaryPart.Anchored = true

	local _, v3 = v2:GetBoundingBox()
	local v6 = Vector3.new(p2.Position.X, p2.Position.Y + p2.Size.Y * 0.5 + 1.5 + v3.Y * 0.5, p2.Position.Z)
	local LookVector = p2.CFrame.LookVector
	local v7 = Vector3.new(LookVector.X, 0, LookVector.Z)

	if v7.Magnitude < 0.0001 then
		v7 = Vector3.new(0, 0, 1)
	end

	PrimaryPart.CFrame = CFrame.lookAt(v6, v6 + v7.Unit)
	v2.Parent = p1
	v2:SetAttribute("IdleAnchor", PrimaryPart.CFrame)
	CollectionService:AddTag(v2, "IdleFishFloat")

	local v8 = ReplicatedStorage.shared.model.RarityLabel:Clone()

	v8.Parent = v2
	v8.Adornee = v2
	v8.Frame.Counter.Text = ("%*%%"):format((math.floor((v1.EarningsPercent or 1) * 100 + 0.5)))
	v8.Frame.Rarity.Text = v1.DisplayName
	v8.Frame.Rarity.UIGradient.Color = ColorSequence.new(v1.Rarity.rarityColor)
	v8.Frame.Rarity:SetAttribute("RarityId", v1.Rarity.id)
	CollectionService:AddTag(v8.Frame.Rarity, "AnimatedRarity")
	v8.Enabled = true

	local v10 = p1:GetAttribute("stock")
	local v11 = if v10 and typeof(v10) == "number" then v10 > 0 else false

	v8.Frame.DisplayName.Text = v10 and ("%* in Stock"):format(v10) or ""
	v8.Enabled = v11
	v2.Parent = if v11 and p1 then p1 else nil

	for v14, v15 in p1:GetChildren() do
		if v15:IsA("BasePart") then
			v15.LocalTransparencyModifier = if v11 then 0 else 1
		end
	end

	p1:GetAttributeChangedSignal("stock"):Connect(function() --[[ Line: 76 | Upvalues: v10 (ref), p1 (copy), v11 (ref), v8 (copy), v2 (copy) ]]
		v10 = p1:GetAttribute("stock")

		local v1 = if v10 then if typeof(v10) == "number" then v10 > 0 else false else false

		v11 = v1
		v8.Frame.DisplayName.Text = if v10 then ("%* in Stock"):format(v10) or "" else ""
		v8.Enabled = v1
		v2.Parent = if v1 then p1 or nil else nil

		for v6, v7 in p1:GetChildren() do
			if v7:IsA("BasePart") then
				v7.LocalTransparencyModifier = if v1 then 0 else 1
			end
		end
	end)
end

function t.Init(p1) --[[ Init | Line: 91 | Upvalues: CollectionService (copy), setupStand (copy) ]]
	for v1, v2 in CollectionService:GetTagged("StockStand") do
		local Main = v2:WaitForChild("Main", 10)

		if not (Main and Main:IsA("BasePart")) then
			warn((("[StockStandsHandler] %*.Main missing or not a BasePart"):format((v2:GetFullName()))))

			return
		end

		setupStand(v2, Main, v2:GetAttribute("fishId"))
	end

	CollectionService:GetInstanceAddedSignal("StockStand"):Connect(function(p1) --[[ Line: 103 | Upvalues: setupStand (ref) ]]
		local Main = p1:WaitForChild("Main", 10)

		if Main and Main:IsA("BasePart") then
			setupStand(p1, Main, p1:GetAttribute("fishId"))
		else
			warn((("[StockStandsHandler] %*.Main missing or not a BasePart"):format((p1:GetFullName()))))
		end
	end)
end

return t