-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Debris = game:GetService("Debris")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local SoundService = game:GetService("SoundService")
local TweenService = game:GetService("TweenService")
local AutoCollectState = require(ReplicatedStorage.client.AutoCollectState)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Remotes = require(ReplicatedStorage.shared.Remotes)

require(ReplicatedStorage.shared.UECS.Components.TycoonStand)
require(ReplicatedStorage.shared.UECS.UECS)

local VFX = require(ReplicatedStorage.client.VFX)
local LocalPlayer = Players.LocalPlayer
local v1 = NumberRange.new(4, 7)
local v2 = UDim2.fromScale(2, 2)
local v3 = NumberRange.new(2, 5)
local v4 = Color3.fromRGB(255, 220, 100)
local v5 = NumberRange.new(4, 10)
local v6 = NumberRange.new(0.3, 1)
local v7 = Color3.fromRGB(255, 140, 0)
local t = {}
local t2 = {}

local function randomInRange(p1) --[[ randomInRange | Line: 61 ]]
	return p1.Min + math.random() * (p1.Max - p1.Min)
end

local function playSound(p1) --[[ playSound | Line: 65 | Upvalues: SoundService (copy) ]]
	local SFX = SoundService:FindFirstChild("SFX")
	local v1 = if SFX then SFX:FindFirstChild(p1) else SFX

	if v1 and v1:IsA("Sound") then
		local v2 = v1:Clone()

		v2.PlaybackSpeed = v2.PlaybackSpeed * (1.05 + math.random() * 0.1)
		v2.PlayOnRemove = true
		v2.Parent = SoundService
		v2:Destroy()
	end
end

local function getHRP() --[[ getHRP | Line: 78 | Upvalues: LocalPlayer (copy) ]]
	local Character = LocalPlayer.Character

	return if Character then Character:FindFirstChild("HumanoidRootPart") else Character
end

local function createFollowHost(p1) --[[ createFollowHost | Line: 83 ]]
	local Part = Instance.new("Part")

	Part.Anchored = true
	Part.CanCollide = false
	Part.CanQuery = false
	Part.CanTouch = false
	Part.Transparency = 1
	Part.Size = Vector3.new(0.1, 0.1, 0.1)
	Part.CFrame = CFrame.new(p1.Position)
	Part.Parent = workspace

	return Part
end

local function spawnFlyingImage(p1) --[[ spawnFlyingImage | Line: 96 | Upvalues: v2 (copy), v4 (copy), v3 (copy), RunService (copy), LocalPlayer (copy), TweenService (copy) ]]
	local Attachment = Instance.new("Attachment")

	Attachment.Parent = p1

	local Attachment2 = Instance.new("Attachment")

	Attachment2.Position = Vector3.new(0, 0.5, 0)
	Attachment2.Parent = p1

	local BillboardGui = Instance.new("BillboardGui")

	BillboardGui.Size = v2
	BillboardGui.Adornee = Attachment
	BillboardGui.LightInfluence = 0
	BillboardGui.Parent = Attachment

	local ImageLabel = Instance.new("ImageLabel")

	ImageLabel.BackgroundTransparency = 1
	ImageLabel.Size = UDim2.fromScale(1, 1)
	ImageLabel.Image = "rbxassetid://93898068805552"
	ImageLabel.Parent = BillboardGui

	local Trail = Instance.new("Trail")

	Trail.Attachment0 = Attachment
	Trail.Attachment1 = Attachment2
	Trail.Lifetime = 0.2
	Trail.MinLength = 0
	Trail.Color = ColorSequence.new(v4)
	Trail.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.2), NumberSequenceKeypoint.new(1, 1) })
	Trail.LightEmission = 0.5
	Trail.Parent = p1

	local v1 = v3
	local v22 = v1.Min + math.random() * (v1.Max - v1.Min)
	local v32 = (math.random() * 2 - 1) * 2
	local v42 = (math.random() * 2 - 1) * 2

	task.spawn(function() --[[ Line: 134 | Upvalues: Attachment (copy), RunService (ref), LocalPlayer (ref), p1 (copy), v32 (copy), v22 (copy), v42 (copy), Attachment2 (copy), TweenService (ref), ImageLabel (copy), Trail (copy) ]]
		local v1 = Instance.new("NumberValue")

		v1.Parent = Attachment

		local v2 = nil

		v2 = RunService.Heartbeat:Connect(function() --[[ Line: 139 | Upvalues: Attachment (ref), v2 (ref), LocalPlayer (ref), p1 (ref), v32 (ref), v22 (ref), v42 (ref), v1 (copy), Attachment2 (ref) ]]
			debug.profilebegin("UECS/CollectCashDetector.FlyArc")

			if not Attachment.Parent then
				v2:Disconnect()
			else
				local Character = LocalPlayer.Character
				local v12 = Character and Character:FindFirstChild("HumanoidRootPart")

				if v12 then
					local v23 = v12.Position - p1.Position
					local v6 = v23 * 0.5 + Vector3.new(v32, v22, v42)
					local v7 = v1.Value
					local v8 = 1 - v7
					local v9 = v8 * v8 * Vector3.new(0, 0, 0) + 2 * v8 * v7 * v6 + v7 * v7 * v23

					Attachment.Position = v9
					Attachment2.Position = v9 + Vector3.new(0, 0.5, 0)
				end
			end

			debug.profileend()
		end)
		TweenService:Create(v1, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
			Value = 1
		}):Play()
		task.delay(0.3, function() --[[ Line: 170 | Upvalues: TweenService (ref), ImageLabel (ref) ]]
			TweenService:Create(ImageLabel, TweenInfo.new(0.2), {
				ImageTransparency = 1
			}):Play()
		end)
		task.wait(0.5)
		v2:Disconnect()
		Trail.Enabled = false
		task.wait(0.2)
		Attachment:Destroy()
		Attachment2:Destroy()
		Trail:Destroy()
	end)
end

local function spawnFloatingImage(p1, p2) --[[ spawnFloatingImage | Line: 184 | Upvalues: v2 (copy), TweenService (copy), Debris (copy) ]]
	local v1 = math.random() * 2 * math.pi
	local v3 = math.sqrt((math.random()))
	local v7 = Vector3.new(math.cos(v1) * v3 * 3, (math.random() * 2 - 1) * -2, math.sin(v1) * v3 * 1)
	local Attachment = Instance.new("Attachment")

	Attachment.Position = v7
	Attachment.Parent = p1

	local BillboardGui = Instance.new("BillboardGui")

	BillboardGui.Size = UDim2.fromScale(v2.X.Scale * p2, v2.Y.Scale * p2)
	BillboardGui.Adornee = Attachment
	BillboardGui.LightInfluence = 0
	BillboardGui.Parent = Attachment

	local ImageLabel = Instance.new("ImageLabel")

	ImageLabel.BackgroundTransparency = 1
	ImageLabel.Size = UDim2.fromScale(1, 1)
	ImageLabel.Image = "rbxassetid://125914890223429"

	local v8 = (math.random() * 2 - 1) * 45

	ImageLabel.Rotation = v8
	ImageLabel.Parent = BillboardGui

	local v9 = TweenInfo.new(1.8, Enum.EasingStyle.Linear)

	TweenService:Create(Attachment, v9, {
		Position = v7 + Vector3.new(0, 3, 0)
	}):Play()
	TweenService:Create(ImageLabel, v9, {
		Rotation = v8 + (math.random() * 2 - 1) * 50
	}):Play()
	task.delay(1.2, function() --[[ Line: 221 | Upvalues: TweenService (ref), ImageLabel (copy) ]]
		TweenService:Create(ImageLabel, TweenInfo.new(0.6000000000000001, Enum.EasingStyle.Linear), {
			ImageTransparency = 1
		}):Play()
	end)
	Debris:AddItem(Attachment, 2.3)
end

local function blinkPart(p1) --[[ blinkPart | Line: 232 | Upvalues: t2 (copy), v7 (copy) ]]
	if not t2[p1] then
		t2[p1] = p1.Color
	end

	p1.Color = v7
	task.delay(0.25, function() --[[ Line: 237 | Upvalues: p1 (copy), t2 (ref) ]]
		p1.Color = t2[p1]
	end)
end

local function playCollectFX(p1) --[[ playCollectFX | Line: 242 | Upvalues: Debris (copy), VFX (copy), playSound (copy), v1 (copy), spawnFlyingImage (copy), v5 (copy), spawnFloatingImage (copy), v6 (copy), t2 (copy), v7 (copy) ]]
	local Part = Instance.new("Part")

	Part.Anchored = true
	Part.CanCollide = false
	Part.CanQuery = false
	Part.CanTouch = false
	Part.Transparency = 1
	Part.Size = Vector3.new(0.1, 0.1, 0.1)
	Part.CFrame = CFrame.new((p1.CFrame + Vector3.new(0, 3, 0)).Position)
	Part.Parent = workspace

	local v2 = Part

	Debris:AddItem(v2, 5)
	VFX.new("CashPickup_fx", v2)
	playSound("CashPickup")

	for i = 1, math.random(v1.Min, v1.Max) do
		spawnFlyingImage(v2)
	end

	task.delay(0.2, function() --[[ Line: 252 | Upvalues: v2 (copy), v5 (ref), spawnFloatingImage (ref), v6 (ref) ]]
		if not v2.Parent then
			return
		end

		for i = 1, math.random(v5.Min, v5.Max) do
			task.delay(math.random() * 0.5, function() --[[ Line: 257 | Upvalues: v2 (ref), spawnFloatingImage (ref), v6 (ref) ]]
				if not v2.Parent then
					return
				end

				local v1 = v6

				spawnFloatingImage(v2, v1.Min + math.random() * (v1.Max - v1.Min))
			end)
		end
	end)

	if not t2[p1] then
		t2[p1] = p1.Color
	end

	p1.Color = v7
	task.delay(0.25, function() --[[ Line: 237 | Upvalues: p1 (copy), t2 (ref) ]]
		p1.Color = t2[p1]
	end)
	task.delay(0.25, function() --[[ Line: 267 | Upvalues: playSound (ref) ]]
		playSound("CashCollect")
	end)
	task.delay(0.5, function() --[[ Line: 270 | Upvalues: playSound (ref) ]]
		playSound("CashPickupEnd")
	end)
end

local function displayedCashAmount(p1) --[[ displayedCashAmount | Line: 277 | Upvalues: ReplicatedStorage (copy) ]]
	if typeof(p1) == "number" then
		return p1
	end

	if typeof(p1) == "string" then
		return require(ReplicatedStorage.shared.util.ConvertValue).parseSuffix((p1:gsub("^%$", ""))) or 0
	end

	return 0
end

local function resolveCollectButton(p1) --[[ resolveCollectButton | Line: 293 ]]
	local Entity = p1.Entity

	if Entity then
		local CollectButton = Entity:FindFirstChild("CollectButton")

		if CollectButton and CollectButton:IsA("BasePart") then
			return CollectButton
		end
	end

	local v1 = p1.CollectButton:Get()

	if typeof(v1) == "Instance" and (v1:IsA("BasePart") and v1:IsDescendantOf(workspace)) then
		return v1
	end

	return nil
end

return {
	UECS = nil,
	Init = function(p1) --[[ Init | Line: 316 | Upvalues: ReplicatedStorage (copy), resolveCollectButton (copy), LocalPlayer (copy), RunService (copy), t (copy), AutoCollectState (copy), playCollectFX (copy), Remotes (copy) ]]
		local v1 = assert(p1.UECS, "UECS not initialized")
		local v2 = RaycastParams.new()

		v2.FilterType = Enum.RaycastFilterType.Include

		local CashDisplay = require(ReplicatedStorage.shared.module.CashDisplay)
		local v3 = setmetatable({}, {
			__mode = "k"
		})

		local function bindStand(p1) --[[ bindStand | Line: 326 | Upvalues: v3 (copy), resolveCollectButton (ref), CashDisplay (copy), ReplicatedStorage (ref) ]]
			if v3[p1] then
				return
			end

			v3[p1] = true

			local v1 = nil
			local v2 = false
			local v32 = 30

			local function v4() --[[ Line: 339 | Upvalues: v1 (ref), resolveCollectButton (ref), p1 (copy), v32 (ref), v2 (ref), v4 (ref), CashDisplay (ref), ReplicatedStorage (ref) ]]
				if not (v1 and v1.Parent) then
					v1 = nil

					local v12 = resolveCollectButton(p1)
					local v22 = if v12 then v12:FindFirstChild("SurfaceGui") else v12
					local v3 = if v22 then v22:FindFirstChild("Cash") else v22

					if v3 and v3:IsA("TextLabel") then
						v1 = v3
						v32 = 30
					else
						if not (v32 > 0) or v2 then
							return
						end

						v2 = true
						v32 = v32 - 1
						task.delay(1, function() --[[ Line: 353 | Upvalues: v2 (ref), v4 (ref) ]]
							v2 = false
							v4()
						end)

						return
					end
				end

				local v5 = p1.DisplayedCash:Get()

				CashDisplay.applyToLabel(v1, if typeof(v5) == "number" then v5 elseif typeof(v5) == "string" then require(ReplicatedStorage.shared.util.ConvertValue).parseSuffix((v5:gsub("^%$", ""))) or 0 else 0, {
					Compact = true
				})
			end

			p1.DisplayedCash.OnChange:Connect(v4)
			p1.CollectButton.OnChange:Connect(function() --[[ Line: 366 | Upvalues: v1 (ref), v32 (ref), v4 (ref) ]]
				v1 = nil
				v32 = 30
				v4()
			end)

			if p1.OnAttached then
				p1.OnAttached:Connect(function() --[[ Line: 376 | Upvalues: v1 (ref), v32 (ref), v4 (ref) ]]
					v1 = nil
					v32 = 30
					v4()
				end)
			end

			if not p1.OnDetached then
				v4()

				return
			end

			p1.OnDetached:Connect(function() --[[ Line: 383 | Upvalues: v1 (ref) ]]
				v1 = nil
			end)
			v4()
		end

		v1.OnComponentCreated("TycoonStand"):Connect(bindStand)

		for k, v in pairs(v1:GetComponents("TycoonStand")) do
			bindStand(v)
		end

		local function getHomeAnchor() --[[ getHomeAnchor | Line: 398 | Upvalues: v1 (copy), LocalPlayer (ref) ]]
			for v12, v2 in v1:GetComponents("TycoonComponent") do
				if v2.Owner:Get() == LocalPlayer then
					local Entity = v2.Entity

					if typeof(Entity) == "Instance" then
						local FloorSpawn = Entity:FindFirstChild("FloorSpawn")

						if FloorSpawn and FloorSpawn:IsA("BasePart") then
							return FloorSpawn
						end

						break
					end

					break
				end
			end

			return nil
		end

		RunService.Heartbeat:Connect(function() --[[ Line: 412 | Upvalues: LocalPlayer (ref), getHomeAnchor (copy), v1 (copy), ReplicatedStorage (ref), resolveCollectButton (ref), t (ref), v2 (copy), AutoCollectState (ref), playCollectFX (ref), Remotes (ref) ]]
			debug.profilebegin("UECS/CollectCashDetector.StandScan")

			local Character = LocalPlayer.Character
			local v12 = Character and Character:FindFirstChild("HumanoidRootPart")

			if v12 then
				local v22 = getHomeAnchor()

				if v22 then
					local v3 = Vector3.new(v12.Position.X, 0, v12.Position.Z)

					if not ((v3 - Vector3.new(v22.Position.X, 0, v22.Position.Z)).Magnitude > 50) then
						local v4 = os.clock()
						local t2 = {}
						local t3 = {}

						for k, v in pairs((v1:GetComponents("TycoonStand"))) do
							if v.Owner:Get() == LocalPlayer then
								local v6 = v.DisplayedCash:Get()
								local v7 = if typeof(v6) == "number" then v6 elseif typeof(v6) == "string" then require(ReplicatedStorage.shared.util.ConvertValue).parseSuffix((v6:gsub("^%$", ""))) or 0 else 0

								if not (v7 <= 0) then
									local v8 = resolveCollectButton(v)

									if v8 then
										local v9 = v.BaseSlotIndexName:Get()

										if type(v9) == "string" then
											local v10 = t[v9]

											if not (v10 and v4 - v10 < 0.15) then
												table.insert(t2, v8)
												t3[v8] = {
													slotName = v9,
													amount = v7
												}
											end
										end
									end
								end
							end
						end

						if #t2 ~= 0 then
							v2.FilterDescendantsInstances = t2

							local v11 = workspace:Raycast(v12.Position, Vector3.new(0, -5, 0), v2)

							if v11 then
								local v122 = t3[v11.Instance]

								if v122 then
									t[v122.slotName] = v4

									if not AutoCollectState.IsSuppressed(v122.slotName) then
										playCollectFX(v11.Instance)
										Remotes.RequestCollectCash:Fire(v122.slotName)

										if v122.amount > 0 then
											local HUD = require(ReplicatedStorage.shared.UECS.Systems.Client.HUD)

											if HUD and HUD.PlayCashGain then
												task.spawn(HUD.PlayCashGain, HUD, v122.amount)
											end
										end
									end
								end
							end
						end
					end
				end
			end

			debug.profileend()
		end)
	end
}