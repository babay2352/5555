-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ContextActionService = game:GetService("ContextActionService")
local GuiService = game:GetService("GuiService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local UserInputService = game:GetService("UserInputService")
local BuildModeState = require(ReplicatedStorage.client.BuildModeState)
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local DecorationConfig = require(ReplicatedStorage.shared.config.DecorationConfig)
local DecorationsInventory = require(ReplicatedStorage.shared.UECS.Components.DecorationsInventory)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local bindToButtonPress = require(ReplicatedStorage.shared.util.bindToButtonPress)
local resolveDecorationModel = require(ReplicatedStorage.shared.util.resolveDecorationModel)

return {
	UECS = nil,
	Init = function(p1) --[[ Init | Line: 29 | Upvalues: Players (copy), DecorationsInventory (copy), ClientPlayerData (copy), DecorationConfig (copy), resolveDecorationModel (copy), CollectionService (copy), BuildModeState (copy), bindToButtonPress (copy), UserInputService (copy), GuiService (copy), ContextActionService (copy) ]]
		local DecorationsInventory2 = Players.LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("MainUI"):FindFirstChild("DecorationsInventory", true)

		if not DecorationsInventory2 then
			warn("[DecorationsInventory] MainUI.DecorationsInventory not found \226\128\148 decoration selector disabled")

			return
		end

		local ScrollingFrame = DecorationsInventory2:FindFirstChild("ScrollingFrame", true)
		local v1 = ScrollingFrame and ScrollingFrame:FindFirstChild("DecorationTemplate")
		local SearchBox = DecorationsInventory2:FindFirstChild("SearchBox", true)
		local EmptyListTextLabel = DecorationsInventory2:FindFirstChild("EmptyListTextLabel", true)
		local CloseButton = DecorationsInventory2:FindFirstChild("CloseButton", true)

		if not (ScrollingFrame and v1) then
			warn("[DecorationsInventory] DecorationsInventory is missing ScrollingFrame.DecorationTemplate \226\128\148 selector disabled")

			return
		end

		v1.Visible = false
		DecorationsInventory2.Visible = false

		local v2 = DecorationsInventory.Add(DecorationsInventory2)
		local t = {}

		local function closeWindow() --[[ closeWindow | Line: 55 | Upvalues: p1 (copy), v2 (copy) ]]
			local v1 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

			if not v1 or v1.OpenedUIComponent:Get() ~= v2 then
				return
			end

			v1.OpenedUIComponent:Set(nil)
		end

		local function applyFilter() --[[ applyFilter | Line: 62 | Upvalues: SearchBox (copy), t (copy), EmptyListTextLabel (copy) ]]
			local v1 = if SearchBox then string.lower(SearchBox.Text) else ""
			local count = 0
			local count2 = 0

			for v2, v3 in t do
				count = count + 1

				local v4 = if v1 == "" then true elseif string.find(string.lower(v3.displayName), v1, 1, true) == nil then false else true

				v3.frame.Visible = v4

				if v4 then
					count2 = count2 + 1
				end
			end

			if not EmptyListTextLabel then
				return
			end

			EmptyListTextLabel.Visible = count2 == 0
			EmptyListTextLabel.Text = if count == 0 then "You don\'t own any decorations yet!" else "No decorations match your search."
		end

		local function rebuild() --[[ rebuild | Line: 80 | Upvalues: t (copy), ClientPlayerData (ref), DecorationConfig (ref), resolveDecorationModel (ref), v1 (copy), CollectionService (ref), BuildModeState (ref), p1 (copy), v2 (copy), ScrollingFrame (copy), applyFilter (copy) ]]
			for v12, v22 in t do
				v22.frame:Destroy()
				t[v12] = nil
			end

			local v3 = ClientPlayerData.serverProfile:getState().inventory or {}
			local t2 = {}

			for v4, v5 in v3 do
				if v5.Category == "Decoration" and (not ((v5.Stack or 0) <= 0) and (DecorationConfig[v5.ConfigName] and resolveDecorationModel(v5.ConfigName))) then
					table.insert(t2, v4)
				end
			end

			table.sort(t2, function(p1, p2) --[[ Line: 98 | Upvalues: DecorationConfig (ref), v3 (copy) ]]
				local v1 = DecorationConfig[v3[p1].ConfigName]
				local v2 = DecorationConfig[v3[p2].ConfigName]
				local power = v1.Rarity.power
				local power2 = v2.Rarity.power

				if power == power2 then
					if v1.Cost == v2.Cost then
						return p1 < p2
					end

					return v1.Cost < v2.Cost
				end

				return power2 < power
			end)

			for v7, v8 in t2 do
				local v6
				local v9 = v3[v8]
				local v10 = DecorationConfig[v9.ConfigName]
				local v11 = v1:Clone()

				v11.Name = v8
				v11.LayoutOrder = v7
				v11.Visible = true
				v11:SetAttribute("InspectType", "Decoration")
				v11:SetAttribute("DecorationConfigName", v9.ConfigName)
				CollectionService:AddTag(v11, "Inspect")

				local Icon = v11:FindFirstChild("Icon", true)

				if Icon and (Icon:IsA("ImageLabel") or Icon:IsA("ImageButton")) then
					Icon.Image = v10.Icon
				end

				local Amount = v11:FindFirstChild("Amount", true)

				if Amount and Amount:IsA("TextLabel") then
					Amount.Text = ("x%*"):format(v9.Stack)
				end

				local Rarity = v11:FindFirstChild("Rarity", true)

				if Rarity and Rarity:IsA("TextLabel") then
					Rarity.Text = v10.Rarity.displayName
					Rarity.TextColor3 = v10.Rarity.rarityColor
				end

				v6 = if Icon and Icon:IsA("GuiButton") then Icon elseif v11:IsA("GuiButton") then v11 else v11:FindFirstChildWhichIsA("GuiButton", true)

				if v6 then
					v6.Selectable = true
					v6.SelectionOrder = v7
					v6.MouseButton1Down:Connect(function() --[[ Line: 155 | Upvalues: BuildModeState (ref), v9 (copy), p1 (ref), v2 (ref) ]]
						BuildModeState.SetMode("Build")
						BuildModeState.SetSelected(v9.ConfigName)

						local v1 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

						if not v1 or v1.OpenedUIComponent:Get() ~= v2 then
							return
						end

						v1.OpenedUIComponent:Set(nil)
					end)
				else
					warn((("[DecorationsInventory] DecorationTemplate has no button \226\128\148 \"%*\" cannot be selected"):format(v8)))
				end

				v11.Parent = ScrollingFrame
				t[v8] = {
					frame = v11,
					displayName = v10.DisplayName
				}
			end

			applyFilter()
		end

		if SearchBox then
			SearchBox:GetPropertyChangedSignal("Text"):Connect(applyFilter)
		end

		if CloseButton then
			CloseButton.MouseButton1Down:Connect(closeWindow)
		end

		v2.Visible.OnChange:Connect(function(p1, p2) --[[ Line: 178 | Upvalues: DecorationsInventory2 (copy), SearchBox (copy), rebuild (copy), bindToButtonPress (ref), closeWindow (copy), UserInputService (ref), GuiService (ref), ScrollingFrame (copy), ContextActionService (ref) ]]
			DecorationsInventory2.Visible = p1

			if p1 == p2 then
				return
			end

			if p1 then
				if SearchBox then
					SearchBox.Text = ""
				end

				rebuild()
				bindToButtonPress("DecorationsInventoryClose", Enum.KeyCode.ButtonB, closeWindow)

				if UserInputService.PreferredInput == Enum.PreferredInput.Gamepad then
					GuiService:Select(ScrollingFrame)
				end
			else
				ContextActionService:UnbindAction("DecorationsInventoryClose")

				local SelectedObject = GuiService.SelectedObject

				if not (SelectedObject and SelectedObject:IsDescendantOf(DecorationsInventory2)) then
					return
				end

				GuiService.SelectedObject = nil
			end
		end)
		BuildModeState.Changed:Connect(function() --[[ Line: 201 | Upvalues: v2 (copy), BuildModeState (ref), p1 (copy) ]]
			if not v2.Visible:Get() or BuildModeState.InGarden and BuildModeState.Active then
				return
			end

			local v1 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

			if not v1 or v1.OpenedUIComponent:Get() ~= v2 then
				return
			end

			v1.OpenedUIComponent:Set(nil)
		end)
		ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 207 ]]
			return p1.inventory
		end, function() --[[ Line: 209 | Upvalues: v2 (copy), rebuild (copy) ]]
			if not v2.Visible:Get() then
				return
			end

			rebuild()
		end)
		rebuild()
	end
}