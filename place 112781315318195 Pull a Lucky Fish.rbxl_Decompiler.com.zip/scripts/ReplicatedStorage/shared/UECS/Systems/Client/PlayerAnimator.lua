-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local AnimationConfig = require(ReplicatedStorage.shared.config.AnimationConfig)
local Animator = require(ReplicatedStorage.shared.UECS.Components.Animator)

require(ReplicatedStorage.shared.UECS.GlobalTypes)
require(ReplicatedStorage.shared.Remotes)
require(ReplicatedStorage.shared.UECS.UECS)

local Base = ReplicatedStorage.shared.model.Tycoon.Base
local t = {
	UECS = nil
}

local function AddComponentToCharacter(p1) --[[ AddComponentToCharacter | Line: 14 | Upvalues: Animator (copy), AnimationConfig (copy) ]]
	local v1 = Animator.Add(p1)

	v1.AnimationId.OnChange:Connect(function(p13, p2) --[[ Line: 16 | Upvalues: v1 (copy), AnimationConfig (ref), p1 (copy) ]]
		if type(p13) == "string" then
			if v1.LoadedAnims[p13] then
				v1.LoadedAnims[p13]:Play()
			else
				local Animation = Instance.new("Animation")

				Animation.AnimationId = AnimationConfig.TrainAnimation

				local v12 = p1.Humanoid.Animator:LoadAnimation(Animation)
				local v3 = table.clone((v1.LoadedAnims:Get()))

				v3[p13] = v12
				v1.LoadedAnims:Set(v3)
				v12:Play()
			end
		else
			local v4 = v1.LoadedAnims:Get()

			if not v4[p2] then
				return
			end

			v4[p2]:Stop()
		end
	end)
end

function t.Init(p1) --[[ Init | Line: 41 | Upvalues: Players (copy), Animator (copy), AnimationConfig (copy) ]]
	repeat
		task.wait()
	until Players.LocalPlayer.Character

	local Character = Players.LocalPlayer.Character
	local v1 = Animator.Add(Character)

	v1.AnimationId.OnChange:Connect(function(p13, p2) --[[ Line: 16 | Upvalues: v1 (copy), AnimationConfig (ref), Character (copy) ]]
		if type(p13) == "string" then
			if v1.LoadedAnims[p13] then
				v1.LoadedAnims[p13]:Play()
			else
				local Animation = Instance.new("Animation")

				Animation.AnimationId = AnimationConfig.TrainAnimation

				local v12 = Character.Humanoid.Animator:LoadAnimation(Animation)
				local v3 = table.clone((v1.LoadedAnims:Get()))

				v3[p13] = v12
				v1.LoadedAnims:Set(v3)
				v12:Play()
			end
		else
			local v4 = v1.LoadedAnims:Get()

			if not v4[p2] then
				return
			end

			v4[p2]:Stop()
		end
	end)
	Players.LocalPlayer.CharacterAdded:Connect(function(p1) --[[ Line: 47 | Upvalues: Animator (ref), AnimationConfig (ref) ]]
		local v1 = Animator.Add(p1)

		v1.AnimationId.OnChange:Connect(function(p13, p2) --[[ Line: 16 | Upvalues: v1 (copy), AnimationConfig (ref), p1 (copy) ]]
			if type(p13) == "string" then
				if v1.LoadedAnims[p13] then
					v1.LoadedAnims[p13]:Play()
				else
					local Animation = Instance.new("Animation")

					Animation.AnimationId = AnimationConfig.TrainAnimation

					local v12 = p1.Humanoid.Animator:LoadAnimation(Animation)
					local v3 = table.clone((v1.LoadedAnims:Get()))

					v3[p13] = v12
					v1.LoadedAnims:Set(v3)
					v12:Play()
				end
			else
				local v4 = v1.LoadedAnims:Get()

				if not v4[p2] then
					return
				end

				v4[p2]:Stop()
			end
		end)
	end)
end

return t