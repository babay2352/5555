-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Maid = require(ReplicatedStorage.shared.class.Maid)
local ezVisualz = require(ReplicatedStorage.package.ezVisualz)
local getGuiObjectVisibilityDepedencies = require(ReplicatedStorage.shared.util.getGuiObjectVisibilityDepedencies)
local isObjectRenderable = require(ReplicatedStorage.shared.util.isObjectRenderable)
local t = {
	UECS = nil,
	Priority = 50
}
local t2 = {
	Mythic = {
		preset = "LavaStroke",
		speed = 0.5,
		size = 2
	},
	Godly = {
		preset = "GhostStroke",
		speed = 0.4,
		size = 2,
		customColor = Color3.fromRGB(153, 0, 255)
	},
	Secret = {
		preset = "Zebra",
		speed = 0.5,
		size = 2
	},
	Devine = {
		preset = "RainbowStroke",
		speed = 0.5,
		size = 2
	},
	Hacked = {
		preset = "Matrix",
		speed = 0.5,
		size = 2
	},
	OG = {
		preset = "ShineOutline",
		speed = 0.4,
		size = 2,
		customColor = Color3.fromRGB(0, 247, 255)
	},
	Celestial = {
		preset = "GoldStroke",
		speed = 0.4,
		size = 2,
		customColor = Color3.fromRGB(255, 187, 0)
	},
	Doodle = {
		preset = "ShineOutline",
		speed = 0.4,
		size = 2,
		customColor = Color3.fromRGB(175, 200, 255)
	},
	Backroom = {
		preset = "GhostStroke",
		speed = 0.4,
		size = 2,
		customColor = Color3.fromRGB(214, 190, 105)
	},
	SCP = {
		preset = "ShineOutline",
		speed = 0.4,
		size = 2,
		customColor = Color3.fromRGB(255, 89, 89)
	},
	Deeps = {
		preset = "ShineOutline",
		speed = 0.4,
		size = 2,
		customColor = Color3.fromRGB(0, 195, 220)
	},
	Exclusive = {
		preset = "ShineOutline",
		speed = 0.4,
		size = 2,
		customColor = Color3.fromRGB(255, 0, 149)
	},
	Beast = {
		preset = "DeathStroke",
		speed = 0.4,
		size = 2
	},
	Boss = {
		preset = "WaveStroke",
		speed = 0.5,
		size = 6,
		customColor = Color3.fromRGB(0, 255, 115)
	}
}
local t3 = {}
local t4 = {}

local function cleanupEffect(p1) --[[ cleanupEffect | Line: 52 | Upvalues: t3 (copy), t4 (copy) ]]
	local v1 = t3[p1]

	if v1 then
		if v1.Destroy then
			v1:Destroy()
		end

		t3[p1] = nil
	end

	local v2 = t4[p1]

	if not v2 then
		return
	end

	v2:Destroy()
	t4[p1] = nil
end

local function applyEffect(p1) --[[ applyEffect | Line: 68 | Upvalues: t3 (copy), t4 (copy), t2 (copy), ezVisualz (copy), isObjectRenderable (copy), Maid (copy), getGuiObjectVisibilityDepedencies (copy) ]]
	local v1 = p1:GetAttribute("RarityId")

	if not v1 then
		return
	end

	local v2 = t3[p1]

	if v2 then
		if v2.Destroy then
			v2:Destroy()
		end

		t3[p1] = nil
	end

	local v3 = t4[p1]

	if v3 then
		v3:Destroy()
		t4[p1] = nil
	end

	local v4 = t2[v1]

	if not v4 then
		return
	end

	if not v4.preset then
		return
	end

	local ok, result = pcall(ezVisualz.new, p1, v4.preset, v4.speed, v4.size, true, v4.customColor)

	if not (ok and result) then
		return
	end

	t3[p1] = result

	local function checkVisibility() --[[ checkVisibility | Line: 87 | Upvalues: isObjectRenderable (ref), p1 (copy), result (copy) ]]
		local v1 = isObjectRenderable(p1)

		if v1 and result.IsPaused then
			result:Resume()
			result.IsPaused = false

			return
		end

		if v1 or result.IsPaused then
			return
		end

		result:Pause()
		result.IsPaused = true
	end

	local v5 = Maid.new()

	for v6, v7 in getGuiObjectVisibilityDepedencies(p1) do
		if v7:IsA("GuiObject") then
			v5:GiveTask(v7:GetPropertyChangedSignal("Visible"):Connect(checkVisibility))

			continue
		end

		if v7:IsA("LayerCollector") then
			v5:GiveTask(v7:GetPropertyChangedSignal("Enabled"):Connect(checkVisibility))

			if v7:IsA("BillboardGui") then
				v7.DistanceStep = 1
				v5:GiveTask(v7:GetPropertyChangedSignal("CurrentDistance"):Connect(checkVisibility))
			end
		end
	end

	t4[p1] = v5

	local v8 = isObjectRenderable(p1)

	if v8 and result.IsPaused then
		result:Resume()
		result.IsPaused = false

		return
	end

	if v8 or result.IsPaused then
		return
	end

	result:Pause()
	result.IsPaused = true
end

function t.Init(p1) --[[ Init | Line: 119 | Upvalues: applyEffect (copy), t3 (copy), t4 (copy), CollectionService (copy) ]]
	local function onAdded(p1) --[[ onAdded | Line: 120 | Upvalues: applyEffect (ref) ]]
		if p1:IsA("TextLabel") then
			applyEffect(p1)
		end
	end

	local function onRemoved(p1) --[[ onRemoved | Line: 127 | Upvalues: t3 (ref), t4 (ref) ]]
		if not p1:IsA("TextLabel") then
			return
		end

		local v1 = t3[p1]

		if v1 then
			if v1.Destroy then
				v1:Destroy()
			end

			t3[p1] = nil
		end

		local v2 = t4[p1]

		if not v2 then
			return
		end

		v2:Destroy()
		t4[p1] = nil
	end

	for v1, v2 in CollectionService:GetTagged("AnimatedRarity") do
		if v2:IsA("TextLabel") then
			applyEffect(v2)
		end
	end

	CollectionService:GetInstanceAddedSignal("AnimatedRarity"):Connect(onAdded)
	CollectionService:GetInstanceRemovedSignal("AnimatedRarity"):Connect(onRemoved)
end

return t