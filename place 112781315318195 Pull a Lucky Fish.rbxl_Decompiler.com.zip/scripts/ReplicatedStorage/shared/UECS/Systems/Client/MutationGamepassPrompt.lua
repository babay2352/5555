-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local MarketplaceService = game:GetService("MarketplaceService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local t = {
	UECS = nil
}
local MutationLuck = require(ReplicatedStorage.shared.config.MonetizationConfig).Gamepasses.MutationLuck
local v1 = RunService:IsStudio()
local t2 = {}
local t3 = {}
local v2 = false
local v3 = false

local function shouldOffer() --[[ shouldOffer | Line: 60 | Upvalues: v1 (copy), v3 (ref) ]]
	return v1 or not v3
end

local function refreshAll() --[[ refreshAll | Line: 64 | Upvalues: v1 (copy), v3 (ref), t2 (copy) ]]
	local v12 = v1 or not v3

	for i = #t2, 1, -1 do
		local v2 = t2[i]

		if v2.Parent then
			v2.Enabled = v12

			continue
		end

		table.remove(t2, i)
	end
end

local function refreshOwnership() --[[ refreshOwnership | Line: 78 | Upvalues: MarketplaceService (copy), Players (copy), MutationLuck (copy), v3 (ref), refreshAll (copy) ]]
	task.spawn(function() --[[ Line: 79 | Upvalues: MarketplaceService (ref), Players (ref), MutationLuck (ref), v3 (ref), refreshAll (ref) ]]
		local ok, result = pcall(function() --[[ Line: 80 | Upvalues: MarketplaceService (ref), Players (ref), MutationLuck (ref) ]]
			return MarketplaceService:UserOwnsGamePassAsync(Players.LocalPlayer.UserId, MutationLuck.GamepassId)
		end)

		if not ok then
			return
		end

		v3 = result
		refreshAll()
	end)
end

local function onActivated() --[[ onActivated | Line: 92 | Upvalues: v2 (ref), v1 (copy), v3 (ref), MarketplaceService (copy), Players (copy), MutationLuck (copy) ]]
	if v2 then
		return
	end

	if v1 or not v3 then
		v2 = true
		task.delay(3, function() --[[ Line: 97 | Upvalues: v2 (ref) ]]
			v2 = false
		end)
		MarketplaceService:PromptGamePassPurchase(Players.LocalPlayer, MutationLuck.GamepassId)
	end
end

local function wireButton(p1) --[[ wireButton | Line: 103 | Upvalues: t3 (copy), onActivated (copy) ]]
	if not t3[p1] then
		t3[p1] = true
		p1.Activated:Connect(onActivated)
	end
end

local function wireGui(p1) --[[ wireGui | Line: 114 | Upvalues: t2 (copy), v1 (copy), v3 (ref), t3 (copy), onActivated (copy) ]]
	if table.find(t2, p1) then
		return
	end

	table.insert(t2, p1)
	p1.Enabled = v1 or not v3

	for v32, v4 in p1:GetDescendants() do
		if v4:IsA("GuiButton") and not t3[v4] then
			t3[v4] = true
			v4.Activated:Connect(onActivated)
		end
	end

	p1.DescendantAdded:Connect(function(p1) --[[ Line: 126 | Upvalues: t3 (ref), onActivated (ref) ]]
		if not p1:IsA("GuiButton") then
			return
		end

		if t3[p1] then
			return
		end

		t3[p1] = true
		p1.Activated:Connect(onActivated)
	end)
end

local function resolveHost(p1) --[[ resolveHost | Line: 134 ]]
	if p1:IsA("BasePart") then
		return p1
	end

	if not p1:IsA("Model") then
		return nil
	end

	return p1.PrimaryPart or p1:FindFirstChildWhichIsA("BasePart", true)
end

local function setupHost(p1) --[[ setupHost | Line: 143 | Upvalues: wireGui (copy) ]]
	local v1 = if p1:IsA("BasePart") then p1 elseif p1:IsA("Model") then p1.PrimaryPart or p1:FindFirstChildWhichIsA("BasePart", true) else nil

	if not v1 then
		warn((("[MutationGamepassPrompt] %* is tagged 2xMutationGamepass but has no BasePart to host the button"):format((p1:GetFullName()))))

		return
	end

	local v2 = v1:FindFirstChildWhichIsA("SurfaceGui")

	if v2 then
		wireGui(v2)
	else
		local v3 = nil

		v3 = v1.ChildAdded:Connect(function(p1) --[[ Line: 159 | Upvalues: v3 (ref), wireGui (ref) ]]
			if not p1:IsA("SurfaceGui") then
				return
			end

			v3:Disconnect()
			wireGui(p1)
		end)
	end
end

function t.Init(p1) --[[ Init | Line: 167 | Upvalues: Players (copy), CollectionService (copy), setupHost (copy), MarketplaceService (copy), MutationLuck (copy), v3 (ref), refreshAll (copy), v2 (ref) ]]
	local LocalPlayer = Players.LocalPlayer

	for v1, v22 in CollectionService:GetTagged("2xMutationGamepass") do
		setupHost(v22)
	end

	CollectionService:GetInstanceAddedSignal("2xMutationGamepass"):Connect(setupHost)
	task.spawn(function() --[[ Line: 79 | Upvalues: MarketplaceService (ref), Players (ref), MutationLuck (ref), v3 (ref), refreshAll (ref) ]]
		local ok, result = pcall(function() --[[ Line: 80 | Upvalues: MarketplaceService (ref), Players (ref), MutationLuck (ref) ]]
			return MarketplaceService:UserOwnsGamePassAsync(Players.LocalPlayer.UserId, MutationLuck.GamepassId)
		end)

		if not ok then
			return
		end

		v3 = result
		refreshAll()
	end)
	MarketplaceService.PromptGamePassPurchaseFinished:Connect(function(p1, p2, p3) --[[ Line: 181 | Upvalues: MutationLuck (ref), v2 (ref), v3 (ref), refreshAll (ref) ]]
		if p2 ~= MutationLuck.GamepassId then
			return
		end

		v2 = false

		if not p3 then
			return
		end

		v3 = true
		refreshAll()
	end)
end

return t