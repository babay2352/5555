-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ContextActionService = game:GetService("ContextActionService")
local GuiService = game:GetService("GuiService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local UserInputService = game:GetService("UserInputService")
local AlienEventConfig = require(ReplicatedStorage.shared.config.AlienEventConfig)
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local ConvertValue = require(ReplicatedStorage.shared.util.ConvertValue)
local EventUpgradeTile = require(ReplicatedStorage.client.EventUpgradeTile)
local EventUpgrades = require(ReplicatedStorage.shared.UECS.Components.EventUpgrades)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local SFX = require(ReplicatedStorage.client.SFX)
local TutorialGate = require(ReplicatedStorage.client.TutorialGate)
local bindToButtonPress = require(ReplicatedStorage.shared.util.bindToButtonPress)
local t = {
	UECS = nil,
	Priority = 30
}
local UpgradeStand = AlienEventConfig.UpgradeStand
local AlienVoice = AlienEventConfig.AlienVoice
local v1 = Vector2.new(0, -35)

function t.Init(p1) --[[ Init | Line: 43 | Upvalues: Players (copy), AlienEventConfig (copy), UpgradeStand (copy), EventUpgrades (copy), ClientPlayerData (copy), ConvertValue (copy), EventUpgradeTile (copy), UserInputService (copy), GuiService (copy), bindToButtonPress (copy), ContextActionService (copy), TutorialGate (copy), v1 (copy), SFX (copy), AlienVoice (copy), CollectionService (copy) ]]
	local MainUI = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI")

	if AlienEventConfig.Enabled then
		local v12 = MainUI:WaitForChild(UpgradeStand.UiFrameName)
		local v2 = v12:WaitForChild("Content")
		local TopBar = v12:WaitForChild("TopBar")
		local Template = v2:WaitForChild("Template")

		Template.Visible = false

		local t = {}
		local t2 = {}

		v12.Visible = false

		local v3 = EventUpgrades.Add(v12)

		local function closePanel() --[[ closePanel | Line: 71 | Upvalues: p1 (copy) ]]
			p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
		end

		TopBar:WaitForChild("CloseButton").MouseButton1Down:Connect(closePanel)

		local EventCoins = TopBar:WaitForChild("EventCoins", 5)

		if EventCoins then
			local TextLabel = EventCoins:FindFirstChild("TextLabel")
			local ImageLabel = EventCoins:FindFirstChild("ImageLabel")

			if ImageLabel then
				ImageLabel.Image = AlienEventConfig.Currency.Icon
			end

			if TextLabel then
				local function refreshCoins() --[[ refreshCoins | Line: 93 | Upvalues: ClientPlayerData (ref), TextLabel (copy), ConvertValue (ref), AlienEventConfig (ref) ]]
					TextLabel.Text = ConvertValue.suffixformat(AlienEventConfig.GetPlayerCoins((ClientPlayerData.serverProfile:getState())))
				end

				local v4 = ClientPlayerData.serverProfile:getState()

				TextLabel.Text = ConvertValue.suffixformat(AlienEventConfig.GetPlayerCoins(v4))
				ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 98 | Upvalues: AlienEventConfig (ref) ]]
					return AlienEventConfig.GetPlayerCoins(p1)
				end, refreshCoins)
			end
		end

		for v5, v6 in AlienEventConfig.OrderedUpgradeIds do
			local v7 = EventUpgradeTile.new(Template, v6, AlienEventConfig.Upgrades[v6])

			table.insert(t2, v7)

			local v8 = v7:GetFrame()

			v8.SelectionOrder = v5
			v8.Parent = v2
			table.insert(t, v8)
		end

		local function onSelectionChange() --[[ onSelectionChange | Line: 113 | Upvalues: UserInputService (ref), GuiService (ref), t (copy), v3 (copy), v12 (copy) ]]
			if UserInputService.PreferredInput ~= Enum.PreferredInput.Gamepad then
				return
			end

			local SelectedObject = GuiService.SelectedObject

			for v1, v2 in t do
				local v32 = SelectedObject == v2

				for v4, v5 in v2:QueryDescendants("ImageLabel.GamepadControl") do
					v5.BackgroundTransparency = if v32 then 0 else 1
					v5.ImageTransparency = v5.BackgroundTransparency
				end
			end

			if not v3.Visible:Get() or SelectedObject and SelectedObject:IsDescendantOf(v12) then
				return
			end

			GuiService:Select(v12)
		end

		GuiService:GetPropertyChangedSignal("SelectedObject"):Connect(onSelectionChange)
		v3.Visible.OnChange:Connect(function(p1, p2) --[[ Line: 134 | Upvalues: v12 (copy), MainUI (copy), bindToButtonPress (ref), closePanel (copy), t2 (copy), GuiService (ref), UserInputService (ref), v2 (copy), ContextActionService (ref) ]]
			v12.Visible = p1

			local HUD = MainUI:FindFirstChild("HUD")

			if HUD then
				HUD.Visible = not p1
			end

			if p1 == p2 then
				return
			end

			if p1 then
				bindToButtonPress("EventUpgradesCloseAction", Enum.KeyCode.ButtonB, closePanel)
				bindToButtonPress("EventUpgradesBuyAction", Enum.KeyCode.ButtonX, function() --[[ Line: 150 | Upvalues: t2 (ref), GuiService (ref) ]]
					for v1, v2 in t2 do
						if v2:GetFrame() == GuiService.SelectedObject then
							v2:_purchase()

							return
						end
					end
				end)

				if UserInputService.PreferredInput == Enum.PreferredInput.Gamepad then
					GuiService:Select(v2)
				end
			else
				ContextActionService:UnbindAction("EventUpgradesCloseAction")
				ContextActionService:UnbindAction("EventUpgradesBuyAction")
				GuiService.SelectedObject = nil
			end
		end)

		local t3 = {}

		local function promptsAllowed() --[[ promptsAllowed | Line: 179 | Upvalues: TutorialGate (ref), v3 (copy) ]]
			return not TutorialGate.active() and not v3.Visible:Get()
		end

		local function refreshPrompts() --[[ refreshPrompts | Line: 182 | Upvalues: TutorialGate (ref), v3 (copy), t3 (copy) ]]
			local v1 = not TutorialGate.active() and not v3.Visible:Get()

			for v2 in t3 do
				if v2:IsDescendantOf(game) then
					v2.Enabled = v1

					continue
				end

				t3[v2] = nil
			end
		end

		TutorialGate.onChanged(refreshPrompts)
		v3.Visible.OnChange:Connect(refreshPrompts)

		local function anchorPartOf(p1) --[[ anchorPartOf | Line: 197 ]]
			return p1:FindFirstChild("PromptPart") or (p1:FindFirstChild("Head") or (p1.PrimaryPart or p1:FindFirstChildWhichIsA("BasePart", true)))
		end

		local function attachPrompt(p12) --[[ attachPrompt | Line: 204 | Upvalues: UpgradeStand (ref), v1 (ref), TutorialGate (ref), v3 (copy), t3 (copy), SFX (ref), AlienVoice (ref), p1 (copy) ]]
			local ProximityPrompt = Instance.new("ProximityPrompt")

			ProximityPrompt.Style = Enum.ProximityPromptStyle.Custom
			ProximityPrompt.ActionText = UpgradeStand.PromptActionText
			ProximityPrompt.ObjectText = UpgradeStand.PromptObjectText
			ProximityPrompt.HoldDuration = 0
			ProximityPrompt.MaxActivationDistance = UpgradeStand.PromptMaxDistance
			ProximityPrompt.RequiresLineOfSight = false
			ProximityPrompt.KeyboardKeyCode = Enum.KeyCode.E
			ProximityPrompt.UIOffset = v1
			ProximityPrompt.Exclusivity = Enum.ProximityPromptExclusivity.AlwaysShow
			ProximityPrompt:AddTag("NoFade")
			ProximityPrompt.Enabled = not TutorialGate.active() and not v3.Visible:Get()
			ProximityPrompt.Parent = p12
			t3[ProximityPrompt] = true
			ProximityPrompt.Triggered:Connect(function() --[[ Line: 221 | Upvalues: SFX (ref), p12 (copy), AlienVoice (ref), p1 (ref), v3 (ref) ]]
				SFX.PlaySoundWithRandomPitchAtPart(SFX.Sounds.AlienNpcTalk, p12, AlienVoice.SoundVolume, AlienVoice.PitchMin, AlienVoice.PitchMax)
				p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(v3)
			end)
		end

		local t4 = {}

		local function ensureNpc(p1) --[[ ensureNpc | Line: 241 | Upvalues: t4 (copy), attachPrompt (copy) ]]
			if p1:IsA("Model") and not t4[p1] then
				t4[p1] = true
				task.spawn(function() --[[ Line: 246 | Upvalues: p1 (copy), attachPrompt (ref), t4 (ref) ]]
					while p1:IsDescendantOf(game) do
						local v1
						local v2 = p1
						local PromptPart = v2:FindFirstChild("PromptPart")

						if PromptPart then
							v1 = PromptPart
						else
							local Head = v2:FindFirstChild("Head")

							v1 = Head or (v2.PrimaryPart or v2:FindFirstChildWhichIsA("BasePart", true))
						end

						if v1 then
							attachPrompt(v1)

							while p1:IsDescendantOf(game) and v1:IsDescendantOf(game) do
								task.wait(1)
							end

							continue
						end

						task.wait(0.5)
					end

					t4[p1] = nil
				end)
			end
		end

		for v9, v10 in CollectionService:GetTagged(UpgradeStand.NpcTag) do
			if v10:IsA("Model") and not t4[v10] then
				t4[v10] = true
				task.spawn(function() --[[ Line: 246 | Upvalues: v10 (copy), attachPrompt (copy), t4 (copy) ]]
					while v10:IsDescendantOf(game) do
						local v1
						local v2 = v10
						local PromptPart = v2:FindFirstChild("PromptPart")

						if PromptPart then
							v1 = PromptPart
						else
							local Head = v2:FindFirstChild("Head")

							v1 = Head or (v2.PrimaryPart or v2:FindFirstChildWhichIsA("BasePart", true))
						end

						if v1 then
							attachPrompt(v1)

							while v10:IsDescendantOf(game) and v1:IsDescendantOf(game) do
								task.wait(1)
							end

							continue
						end

						task.wait(0.5)
					end

					t4[v10] = nil
				end)
			end
		end

		CollectionService:GetInstanceAddedSignal(UpgradeStand.NpcTag):Connect(ensureNpc)
	else
		local v11 = MainUI:FindFirstChild(UpgradeStand.UiFrameName)

		if not (v11 and v11:IsA("GuiObject")) then
			return
		end

		v11.Visible = false
	end
end

return t