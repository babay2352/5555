-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local AnimationConfig = require(ReplicatedStorage.shared.config.AnimationConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local t = {
	UECS = nil
}
local v1 = setmetatable({}, {
	__mode = "k"
})

local function getAnimator(p1) --[[ getAnimator | Line: 28 ]]
	local Humanoid = p1:FindFirstChildOfClass("Humanoid")

	if not Humanoid then
		return nil
	end

	return Humanoid:FindFirstChildOfClass("Animator") or Instance.new("Animator", Humanoid)
end

local function loadTrack(p1, p2) --[[ loadTrack | Line: 36 ]]
	local Humanoid = p1:FindFirstChildOfClass("Humanoid")
	local v1 = if Humanoid then Humanoid:FindFirstChildOfClass("Animator") or Instance.new("Animator", Humanoid) else nil

	if not v1 then
		return nil
	end

	local Animation = Instance.new("Animation")

	Animation.AnimationId = p2

	local ok, result = pcall(function() --[[ Line: 43 | Upvalues: v1 (copy), Animation (copy) ]]
		return v1:LoadAnimation(Animation)
	end)

	Animation:Destroy()

	if ok then
		result.Looped = true

		return result
	end

	return nil
end

local function walkAnimId(p1) --[[ walkAnimId | Line: 56 | Upvalues: AnimationConfig (copy) ]]
	local Humanoid = p1:FindFirstChildOfClass("Humanoid")

	if Humanoid and Humanoid.RigType == Enum.HumanoidRigType.R6 then
		return AnimationConfig.DefaultWalkR6
	end

	return AnimationConfig.DefaultWalk
end

local function idleAnimId(p1) --[[ idleAnimId | Line: 64 | Upvalues: AnimationConfig (copy) ]]
	local Humanoid = p1:FindFirstChildOfClass("Humanoid")

	if Humanoid and Humanoid.RigType == Enum.HumanoidRigType.R6 then
		return AnimationConfig.DefaultIdleR6
	end

	return AnimationConfig.DefaultIdle
end

local function entryFor(p1) --[[ entryFor | Line: 72 | Upvalues: v1 (copy) ]]
	local v12 = v1[p1]

	if v12 then
		return v12
	end

	local t = {}

	v1[p1] = t

	return t
end

local function play(p1, p2) --[[ play | Line: 82 | Upvalues: v1 (copy), loadTrack (copy), AnimationConfig (copy) ]]
	local v12 = v1[p1]
	local v2

	if v12 then
		v2 = v12
	else
		local t = {}

		v1[p1] = t
		v2 = t
	end

	if p2 then
		if v2.idle and v2.idle.IsPlaying then
			v2.idle:Stop()
		end

		if not v2.walk then
			local Humanoid = p1:FindFirstChildOfClass("Humanoid")

			v2.walk = loadTrack(p1, if Humanoid and Humanoid.RigType == Enum.HumanoidRigType.R6 then AnimationConfig.DefaultWalkR6 else AnimationConfig.DefaultWalk)
		end

		if v2.walk and not v2.walk.IsPlaying then
			v2.walk:Play()
		end
	else
		if v2.walk and v2.walk.IsPlaying then
			v2.walk:Stop()
		end

		if not v2.idle then
			local Humanoid = p1:FindFirstChildOfClass("Humanoid")

			v2.idle = loadTrack(p1, if Humanoid and Humanoid.RigType == Enum.HumanoidRigType.R6 then AnimationConfig.DefaultIdleR6 else AnimationConfig.DefaultIdle)
		end

		if not v2.idle or v2.idle.IsPlaying then
			return
		end

		v2.idle:Play()
	end
end

function t.Init(p1) --[[ Init | Line: 107 | Upvalues: CollectionService (copy), v1 (copy), loadTrack (copy), AnimationConfig (copy) ]]
	for v3, v4 in CollectionService:GetTagged("NPCmoving") do
		local v12, v2

		if v4:IsA("Model") then
			local v5 = v1[v4]

			if v5 then
				v12 = v5
			else
				local t = {}

				v1[v4] = t
				v12 = t
			end

			if v12.idle and v12.idle.IsPlaying then
				v12.idle:Stop()
			end

			if not v12.walk then
				local Humanoid = v4:FindFirstChildOfClass("Humanoid")

				v2 = if Humanoid and Humanoid.RigType == Enum.HumanoidRigType.R6 then AnimationConfig.DefaultWalkR6 else AnimationConfig.DefaultWalk
				v12.walk = loadTrack(v4, v2)
			end

			if v12.walk and not v12.walk.IsPlaying then
				v12.walk:Play()
			end
		end
	end

	for v10, v11 in CollectionService:GetTagged("npcIdle") do
		local v8, v9

		if v11:IsA("Model") then
			local v122 = v1[v11]

			if v122 then
				v8 = v122
			else
				local t = {}

				v1[v11] = t
				v8 = t
			end

			if v8.walk and v8.walk.IsPlaying then
				v8.walk:Stop()
			end

			if not v8.idle then
				local Humanoid = v11:FindFirstChildOfClass("Humanoid")

				v9 = if Humanoid and Humanoid.RigType == Enum.HumanoidRigType.R6 then AnimationConfig.DefaultIdleR6 else AnimationConfig.DefaultIdle
				v8.idle = loadTrack(v11, v9)
			end

			if v8.idle and not v8.idle.IsPlaying then
				v8.idle:Play()
			end
		end
	end

	CollectionService:GetInstanceAddedSignal("NPCmoving"):Connect(function(p1) --[[ Line: 119 | Upvalues: v1 (ref), loadTrack (ref), AnimationConfig (ref) ]]
		if not p1:IsA("Model") then
			return
		end

		local v12 = v1[p1]
		local v2

		if v12 then
			v2 = v12
		else
			local t = {}

			v1[p1] = t
			v2 = t
		end

		if v2.idle and v2.idle.IsPlaying then
			v2.idle:Stop()
		end

		if not v2.walk then
			local Humanoid = p1:FindFirstChildOfClass("Humanoid")

			v2.walk = loadTrack(p1, if Humanoid and Humanoid.RigType == Enum.HumanoidRigType.R6 then AnimationConfig.DefaultWalkR6 else AnimationConfig.DefaultWalk)
		end

		if not v2.walk or v2.walk.IsPlaying then
			return
		end

		v2.walk:Play()
	end)
	CollectionService:GetInstanceAddedSignal("npcIdle"):Connect(function(p1) --[[ Line: 124 | Upvalues: v1 (ref), loadTrack (ref), AnimationConfig (ref) ]]
		if not p1:IsA("Model") then
			return
		end

		local v12 = v1[p1]
		local v2

		if v12 then
			v2 = v12
		else
			local t = {}

			v1[p1] = t
			v2 = t
		end

		if v2.walk and v2.walk.IsPlaying then
			v2.walk:Stop()
		end

		if not v2.idle then
			local Humanoid = p1:FindFirstChildOfClass("Humanoid")

			v2.idle = loadTrack(p1, if Humanoid and Humanoid.RigType == Enum.HumanoidRigType.R6 then AnimationConfig.DefaultIdleR6 else AnimationConfig.DefaultIdle)
		end

		if not v2.idle or v2.idle.IsPlaying then
			return
		end

		v2.idle:Play()
	end)
end

return t