-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ActiveEffects = require(ReplicatedStorage.shared.effects.ActiveEffects)
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local getFloatEffects = require(ReplicatedStorage.shared.util.getFloatEffects)
local getGardenDecorationEffects = require(ReplicatedStorage.shared.util.getGardenDecorationEffects)
local getMutationChances = require(ReplicatedStorage.shared.util.getMutationChances)
local getMutationLuckMultiplier = require(ReplicatedStorage.shared.util.getMutationLuckMultiplier)
local t = {
	UECS = nil
}
local t2 = {
	{
		tag = "GoldMutationChance",
		name = "Gold",
		label = "Gold",
		color = Color3.fromRGB(255, 220, 50)
	},
	{
		tag = "DiamondMutationChance",
		name = "Diamond",
		label = "Diamond",
		color = Color3.fromRGB(120, 210, 255)
	},
	{
		tag = "MoltenMutationChance",
		name = "Molten",
		label = "Molten",
		color = Color3.fromRGB(255, 105, 135)
	},
	{
		tag = "BubblegumMutationChance",
		name = "Bubblegum",
		label = "Bubblegum",
		color = Color3.fromRGB(255, 152, 220)
	}
}

local function formatChance(p1) --[[ formatChance | Line: 65 ]]
	local v1 = p1 * 100

	if v1 == math.floor(v1) then
		return string.format("%d%%", v1)
	end

	return string.format("%.1f%%", v1)
end

local t3 = {}
local MutationBoardTemplate = ReplicatedStorage.shared.model:WaitForChild("MutationBoardTemplate")

local function refresh() --[[ refresh | Line: 79 | Upvalues: Players (copy), getFloatEffects (copy), getMutationChances (copy), getMutationLuckMultiplier (copy), getGardenDecorationEffects (copy), t3 (copy) ]]
	local LocalPlayer = Players.LocalPlayer
	local v1 = getFloatEffects(LocalPlayer)
	local v2 = getMutationChances(getMutationLuckMultiplier(LocalPlayer), v1.MutationChance, v1.WeatherMutation, getGardenDecorationEffects(LocalPlayer).WeatherMutationMult)

	for v4, v5 in t3 do
		local v3
		local v6 = (v2[v5.name] or 0) * 100

		v3 = if v6 == math.floor(v6) then string.format("%d%%", v6) else string.format("%.1f%%", v6)
		v5.chanceLabel.Text = v3
	end
end

local function createGui(p1, p2) --[[ createGui | Line: 93 | Upvalues: MutationBoardTemplate (copy), t3 (copy), refresh (copy) ]]
	if not p1:QueryDescendants("SurfaceGui#MutationBoardTemplate")[1] then
		local v1 = MutationBoardTemplate:Clone()
		local NameLabel = v1:FindFirstChild("NameLabel")

		NameLabel.Text = p2.label
		NameLabel.TextColor3 = p2.color

		local ChanceLabel = v1:FindFirstChild("ChanceLabel")

		ChanceLabel.TextColor3 = p2.color
		v1.Parent = p1
		table.insert(t3, {
			chanceLabel = ChanceLabel,
			name = p2.name
		})
		refresh()
	end
end

function t.Init(p1) --[[ Init | Line: 119 | Upvalues: t2 (copy), CollectionService (copy), createGui (copy), ActiveEffects (copy), refresh (copy), Players (copy), ClientPlayerData (copy) ]]
	for v1, v2 in t2 do
		CollectionService:GetInstanceAddedSignal(v2.tag):Connect(function(p1) --[[ Line: 121 | Upvalues: createGui (ref), v2 (copy) ]]
			if not p1:IsA("MeshPart") then
				return
			end

			createGui(p1, v2)
		end)

		for v3, v4 in CollectionService:GetTagged(v2.tag) do
			if v4:IsA("MeshPart") then
				createGui(v4, v2)
			end
		end
	end

	ActiveEffects.Changed:Connect(refresh)
	Players.LocalPlayer:GetAttributeChangedSignal("MutationLuckMultiplier"):Connect(refresh)
	refresh()
	task.spawn(function() --[[ Line: 146 | Upvalues: ClientPlayerData (ref), refresh (ref) ]]
		if not ClientPlayerData.isPlayerDataLoaded then
			ClientPlayerData.playerDataLoadedSignal:Wait()
		end

		refresh()
		ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 152 ]]
			return p1.claimedDailyRewards
		end, refresh)
		ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 156 ]]
			return p1.equippedFloats
		end, refresh)
		ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 160 ]]
			return p1.garden and p1.garden.items
		end, refresh)
	end)
end

return t