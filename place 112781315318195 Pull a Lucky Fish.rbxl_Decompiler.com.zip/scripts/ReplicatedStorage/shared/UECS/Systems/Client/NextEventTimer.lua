-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local t = {
	UECS = nil
}
local t2 = {}
local v1 = nil

local function getScheduleFolder() --[[ getScheduleFolder | Line: 15 | Upvalues: v1 (ref), ReplicatedStorage (copy) ]]
	if not v1 then
		v1 = ReplicatedStorage:FindFirstChild("WeatherSchedule")
	end

	return v1
end

local function formatCountdown(p1) --[[ formatCountdown | Line: 23 ]]
	local v3 = math.max(0, (math.ceil(p1 - workspace:GetServerTimeNow())))

	return string.format("%02d:%02d", math.floor(v3 / 60), v3 % 60)
end

local function setupPart(p1) --[[ setupPart | Line: 30 | Upvalues: t2 (copy) ]]
	local v1 = p1:FindFirstChildWhichIsA("SurfaceGui")

	if not v1 then
		warn("[NextEventTimer] No SurfaceGui on", p1:GetFullName())

		return
	end

	local Timer = v1:FindFirstChild("Timer")

	if not Timer then
		warn("[NextEventTimer] No Timer frame in SurfaceGui on", p1:GetFullName())

		return
	end

	local v2 = Timer:FindFirstChildWhichIsA("TextLabel")

	if v2 then
		table.insert(t2, v2)
	else
		warn("[NextEventTimer] No TextLabel in Timer frame on", p1:GetFullName())
	end
end

function t.Init(p1) --[[ Init | Line: 52 | Upvalues: CollectionService (copy), setupPart (copy), v1 (ref), ReplicatedStorage (copy), RunService (copy), t2 (copy) ]]
	for v12, v2 in CollectionService:GetTagged("NextEventTimerPart") do
		task.spawn(setupPart, v2)
	end

	CollectionService:GetInstanceAddedSignal("NextEventTimerPart"):Connect(function(p1) --[[ Line: 56 | Upvalues: setupPart (ref) ]]
		task.spawn(setupPart, p1)
	end)

	if not v1 then
		v1 = ReplicatedStorage:FindFirstChild("WeatherSchedule")
	end

	local v3 = v1
	local v4

	if v3 then
		v4 = 0
		RunService.Heartbeat:Connect(function(p13) --[[ Line: 73 | Upvalues: v4 (ref), v1 (ref), ReplicatedStorage (ref), t2 (ref) ]]
			debug.profilebegin("UECS/NextEventTimer.Heartbeat")
			v4 = v4 + p13

			if not (v4 < 1) then
				v4 = 0

				if not v1 then
					v1 = ReplicatedStorage:FindFirstChild("WeatherSchedule")
				end

				local v12 = v1

				if v12 then
					local v2 = v12:GetAttribute("NextWeatherTime")

					if v2 then
						local v5 = math.max(0, (math.ceil(v2 - workspace:GetServerTimeNow())))
						local v8 = string.format("%02d:%02d", math.floor(v5 / 60), v5 % 60)

						for v9, v10 in t2 do
							if v10.Parent then
								v10.Text = v8
							end
						end
					end
				end
			end

			debug.profileend()
		end)

		return
	end

	local v5 = nil

	v5 = ReplicatedStorage.ChildAdded:Connect(function(p1) --[[ Line: 62 | Upvalues: v1 (ref), v5 (ref) ]]
		if p1.Name ~= "WeatherSchedule" then
			return
		end

		v1 = p1

		if not v5 then
			return
		end

		v5:Disconnect()
	end)
	v4 = 0
	RunService.Heartbeat:Connect(function(p13) --[[ Line: 73 | Upvalues: v4 (ref), v1 (ref), ReplicatedStorage (ref), t2 (ref) ]]
		debug.profilebegin("UECS/NextEventTimer.Heartbeat")
		v4 = v4 + p13

		if not (v4 < 1) then
			v4 = 0

			if not v1 then
				v1 = ReplicatedStorage:FindFirstChild("WeatherSchedule")
			end

			local v12 = v1

			if v12 then
				local v2 = v12:GetAttribute("NextWeatherTime")

				if v2 then
					local v5 = math.max(0, (math.ceil(v2 - workspace:GetServerTimeNow())))
					local v8 = string.format("%02d:%02d", math.floor(v5 / 60), v5 % 60)

					for v9, v10 in t2 do
						if v10.Parent then
							v10.Text = v8
						end
					end
				end
			end
		end

		debug.profileend()
	end)
end

return t