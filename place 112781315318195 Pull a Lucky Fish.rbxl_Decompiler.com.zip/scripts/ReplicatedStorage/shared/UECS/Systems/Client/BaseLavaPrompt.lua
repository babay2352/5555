-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local MarketplaceService = game:GetService("MarketplaceService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local BaseSkinConfig = require(ReplicatedStorage.shared.config.BaseSkinConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local t = {
	UECS = nil
}
local v1 = utf8.char(57346)
local v2 = setmetatable({}, {
	__mode = "k"
})
local v3 = nil
local v4 = false

local function applyPrice(p1, p2) --[[ applyPrice | Line: 46 | Upvalues: v3 (ref), v1 (copy), v4 (ref), MarketplaceService (copy) ]]
	if v3 then
		p1.ActionText = v3

		return
	end

	p1.ActionText = v1 .. " ..."

	if v4 then
		task.spawn(function() --[[ Line: 57 | Upvalues: v4 (ref), v3 (ref), p1 (copy) ]]
			while v4 do
				task.wait(0.25)
			end

			if not (v3 and p1.Parent) then
				return
			end

			p1.ActionText = v3
		end)
	else
		v4 = true
		task.spawn(function() --[[ Line: 69 | Upvalues: MarketplaceService (ref), p2 (copy), v4 (ref), v3 (ref), v1 (ref), p1 (copy) ]]
			local ok, result = pcall(function() --[[ Line: 70 | Upvalues: MarketplaceService (ref), p2 (ref) ]]
				return MarketplaceService:GetProductInfo(p2, Enum.InfoType.Product)
			end)

			v4 = false

			if not (ok and (result and result.PriceInRobux)) then
				return
			end

			v3 = v1 .. " " .. tostring(result.PriceInRobux)

			if not p1.Parent then
				return
			end

			p1.ActionText = v3
		end)
	end
end

local function setupPrompt(p1) --[[ setupPrompt | Line: 83 | Upvalues: BaseSkinConfig (copy), applyPrice (copy), MarketplaceService (copy) ]]
	local BaseLava = BaseSkinConfig.Config.BaseLava

	if not (BaseLava and BaseLava.DevProduct) then
		warn("[BaseLavaPrompt] BaseSkinConfig has no BaseLava DevProduct \226\128\148 prompt skipped")

		return
	end

	local DevProduct = BaseLava.DevProduct
	local v1 = p1:FindFirstChildWhichIsA("ProximityPrompt")
	local BuyBaseLava = if v1 then v1 else Instance.new("ProximityPrompt")

	BuyBaseLava.Parent = p1
	BuyBaseLava.Name = "BuyBaseLava"
	BuyBaseLava.Style = Enum.ProximityPromptStyle.Custom
	BuyBaseLava.ObjectText = BaseLava.DisplayName
	BuyBaseLava.HoldDuration = 0.3
	BuyBaseLava.MaxActivationDistance = 12
	BuyBaseLava.RequiresLineOfSight = false
	applyPrice(BuyBaseLava, DevProduct)
	BuyBaseLava.Triggered:Connect(function(p1) --[[ Line: 106 | Upvalues: MarketplaceService (ref), DevProduct (copy) ]]
		MarketplaceService:PromptProductPurchase(p1, DevProduct)
	end)
end

local function onTagged(p1) --[[ onTagged | Line: 111 | Upvalues: v2 (copy), setupPrompt (copy) ]]
	if not p1:IsA("BasePart") then
		warn((("[BaseLavaPrompt] \"BaseLava\" tag is on a %* (%*) \226\128\148 needs a BasePart"):format(p1.ClassName, (p1:GetFullName()))))

		return
	end

	if not v2[p1] then
		v2[p1] = true
		setupPrompt(p1)
	end
end

function t.Init(p1) --[[ Init | Line: 123 | Upvalues: Players (copy), CollectionService (copy), v2 (copy), setupPrompt (copy), onTagged (copy) ]]
	local LocalPlayer = Players.LocalPlayer

	for v1, v22 in CollectionService:GetTagged("BaseLava") do
		if v22:IsA("BasePart") then
			if not v2[v22] then
				v2[v22] = true
				setupPrompt(v22)
			end

			continue
		end

		warn((("[BaseLavaPrompt] \"BaseLava\" tag is on a %* (%*) \226\128\148 needs a BasePart"):format(v22.ClassName, (v22:GetFullName()))))
	end

	CollectionService:GetInstanceAddedSignal("BaseLava"):Connect(onTagged)
	CollectionService:GetInstanceRemovedSignal("BaseLava"):Connect(function(p1) --[[ Line: 135 | Upvalues: v2 (ref) ]]
		if not p1:IsA("BasePart") then
			return
		end

		v2[p1] = nil
	end)
end

return t