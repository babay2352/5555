-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local t = {
	UECS = nil
}

local function setupAnimator(p1) --[[ setupAnimator | Line: 8 ]]
	local Animation = p1:FindFirstChildOfClass("Animation")

	if not Animation then
		return
	end

	local v1 = p1:LoadAnimation(Animation)

	v1.Looped = true
	v1:Play(0)
end

function t.Init(p1) --[[ Init | Line: 17 | Upvalues: CollectionService (copy) ]]
	for v1, v2 in CollectionService:GetTagged("LoopAnimator") do
		if v2:IsA("Animator") then
			local Animation = v2:FindFirstChildOfClass("Animation")

			if Animation then
				local v3 = v2:LoadAnimation(Animation)

				v3.Looped = true
				v3:Play(0)
			end
		end
	end

	CollectionService:GetInstanceAddedSignal("LoopAnimator"):Connect(function(p1) --[[ Line: 24 ]]
		if not p1:IsA("Animator") then
			return
		end

		local Animation = p1:FindFirstChildOfClass("Animation")

		if not Animation then
			return
		end

		local v1 = p1:LoadAnimation(Animation)

		v1.Looped = true
		v1:Play(0)
	end)
end

return t