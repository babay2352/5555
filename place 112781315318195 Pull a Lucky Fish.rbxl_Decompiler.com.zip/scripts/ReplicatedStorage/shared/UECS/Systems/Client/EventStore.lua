-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ContextActionService = game:GetService("ContextActionService")
local GamepadService = game:GetService("GamepadService")
local GuiService = game:GetService("GuiService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local AlienEventConfig = require(ReplicatedStorage.shared.config.AlienEventConfig)
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local ConvertValue = require(ReplicatedStorage.shared.util.ConvertValue)
local EventStore = require(ReplicatedStorage.shared.UECS.Components.EventStore)
local EventStoreConfig = require(ReplicatedStorage.shared.config.EventStoreConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local LuckyblockDropReel = require(ReplicatedStorage.shared.module.LuckyblockDropReel)

require(ReplicatedStorage.shared.class.Maid)

local Remotes = require(ReplicatedStorage.shared.Remotes)
local SFX = require(ReplicatedStorage.client.SFX)
local bindToButtonPress = require(ReplicatedStorage.shared.util.bindToButtonPress)
local t = {
	UECS = nil,
	Priority = 30
}
local t2 = {}
local v1 = 0

local function getEventData(p1) --[[ getEventData | Line: 63 | Upvalues: EventStoreConfig (copy) ]]
	return p1.events and p1.events[EventStoreConfig.EventId]
end

local function isEntryOwned(p1, p2) --[[ isEntryOwned | Line: 71 ]]
	return if p1.OneTimeBuy == true then p2[p1.Id] == true else false
end

local function v2(p1, p2) --[[ collectCards | Line: 87 | Upvalues: EventStoreConfig (copy), v2 (copy) ]]
	for v22, v3 in p1:GetChildren() do
		local v1
		local v4 = EventStoreConfig.AllItems[v3.Name]

		if v4 and v3:IsA("GuiObject") then
			local v5 = v3:FindFirstChild("Content")
			local v6 = if v5 then v5:FindFirstChild("Buy1") else v5

			if v6 then
				local v7 = v6:FindFirstChild("Content")

				v1 = if v7 then v7:FindFirstChild("TextLabel") else v7
			else
				v1 = nil
			end

			p2[v3.Name] = {
				entry = v4,
				card = v3,
				buyButton = v6,
				priceLabel = v1,
				stockLabel = if v5 then v5:FindFirstChild("stock") else v5
			}

			continue
		end

		v2(v3, p2)
	end
end

function t.Init(p1) --[[ Init | Line: 113 | Upvalues: Players (copy), AlienEventConfig (copy), EventStore (copy), Remotes (copy), LuckyblockDropReel (copy), EventStoreConfig (copy), SFX (copy), bindToButtonPress (copy), GamepadService (copy), ContextActionService (copy), GuiService (copy), ClientPlayerData (copy), ConvertValue (copy), RunService (copy), v1 (ref), v2 (copy), t2 (ref) ]]
	local MainUI = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI")

	if AlienEventConfig.Enabled then
		local EventStore2 = MainUI:WaitForChild("EventStore")

		EventStore2.Visible = false

		local ScrollingFrame = EventStore2:WaitForChild("Content"):WaitForChild("ScrollingFrame")
		local v12 = EventStore.Add(EventStore2)
		local v22 = nil

		v12.Visible.OnChange:Connect(function(p12, p2) --[[ Line: 153 | Upvalues: EventStore2 (copy), MainUI (copy), Remotes (ref), v22 (ref), LuckyblockDropReel (ref), ScrollingFrame (copy), EventStoreConfig (ref), SFX (ref), AlienEventConfig (ref), bindToButtonPress (ref), p1 (copy), GamepadService (ref), ContextActionService (ref), GuiService (ref) ]]
			EventStore2.Visible = p12

			local HUD = MainUI:FindFirstChild("HUD")

			if HUD then
				HUD.Visible = not p12
			end

			if p12 then
				Remotes.RequestEventStoreState:Fire()

				if not v22 then
					v22 = LuckyblockDropReel.start(ScrollingFrame, "LuckyBlock", EventStoreConfig.Featured.LuckyBlock.ConfigName)
				end
			elseif v22 then
				v22:Destroy()
				v22 = nil
			end

			if p12 == p2 then
				return
			end

			if p12 then
				SFX.PlaySoundWithRandomPitch(SFX.Sounds.AlienNpcTalk, AlienEventConfig.AlienVoice.SoundVolume, AlienEventConfig.AlienVoice.PitchMin, AlienEventConfig.AlienVoice.PitchMax)
				bindToButtonPress("EventStoreCloseAction", Enum.KeyCode.ButtonB, function() --[[ Line: 193 | Upvalues: p1 (ref) ]]
					p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
				end)
				GamepadService:EnableGamepadCursor(ScrollingFrame)

				return
			end

			ContextActionService:UnbindAction("EventStoreCloseAction")
			GamepadService:DisableGamepadCursor()
			GuiService.SelectedObject = nil
		end)
		GamepadService:GetPropertyChangedSignal("GamepadCursorEnabled"):Connect(function() --[[ Line: 207 | Upvalues: GamepadService (ref), EventStore2 (copy), ScrollingFrame (copy) ]]
			if GamepadService.GamepadCursorEnabled or not EventStore2.Visible then
				return
			end

			GamepadService:EnableGamepadCursor(ScrollingFrame)
		end)

		local TopBar = EventStore2:WaitForChild("TopBar")

		TopBar:WaitForChild("CloseButton").MouseButton1Down:Connect(function() --[[ Line: 215 | Upvalues: p1 (copy) ]]
			p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
		end)

		local EventCoins = TopBar:WaitForChild("EventCoins")
		local TextLabel = EventCoins:WaitForChild("TextLabel")
		local ImageLabel = EventCoins:FindFirstChild("ImageLabel")

		if ImageLabel then
			ImageLabel.Image = EventStoreConfig.Currency.Icon
		end

		local function refreshCoinsLabel() --[[ refreshCoinsLabel | Line: 228 | Upvalues: ClientPlayerData (ref), EventStoreConfig (ref), TextLabel (copy), ConvertValue (ref) ]]
			local v1 = ClientPlayerData.serverProfile:getState()
			local v2 = v1.events and v1.events[EventStoreConfig.EventId]

			TextLabel.Text = ConvertValue.suffixformat(if v2 then v2.coins or 0 else 0)
		end

		local v3 = ClientPlayerData.serverProfile:getState()
		local v4 = v3.events and v3.events[EventStoreConfig.EventId]
		local suffixformat = ConvertValue.suffixformat

		TextLabel.Text = suffixformat(v4 and v4.coins or 0)
		ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 233 | Upvalues: EventStoreConfig (ref) ]]
			local v1 = p1.events and p1.events[EventStoreConfig.EventId]

			return if v1 then v1.coins or 0 else 0
		end, refreshCoinsLabel)

		local Refreshcountdown = TopBar:WaitForChild("Refreshcountdown")

		RunService.Heartbeat:Connect(function() --[[ Line: 240 | Upvalues: v1 (ref), Refreshcountdown (copy) ]]
			debug.profilebegin("UECS/EventStore.RestockCountdown")

			local v12 = v1 - os.time()

			if v12 <= 0 then
				Refreshcountdown.Text = "Restocking..."
			else
				Refreshcountdown.Text = string.format("Restock: %d:%02d", math.floor(v12 / 60), v12 % 60)
			end

			debug.profileend()
		end)

		local t = {}

		v2(ScrollingFrame, t)

		for v6, v7 in t do
			if v7.buyButton then
				v7.buyButton.MouseButton1Down:Connect(function() --[[ Line: 257 | Upvalues: Remotes (ref), v6 (copy) ]]
					Remotes.BuyEventStoreItem:Fire(v6)
				end)
			end
		end

		local function updateCardPity(p1, p2) --[[ updateCardPity | Line: 262 ]]
			local v1 = p1:FindFirstChild("PityLabel", true) or (p1:FindFirstChild("PityText", true) or p1:FindFirstChild("Pity", true))

			if v1 then
				v1.Text = ("%*/20"):format(p2)
			end

			local v2 = p1:FindFirstChild("PityBar", true) or (p1:FindFirstChild("PityProgress", true) or p1:FindFirstChild("ProgressBar", true))

			if not v2 then
				return
			end

			local v3 = v2:FindFirstChild("Fill", true) or (v2:FindFirstChild("Progress", true) or v2:FindFirstChild("Bar", true))

			if v3 then
				v3.Size = UDim2.fromScale(math.clamp(p2 / 20, 0, 1), 1)

				return
			end

			v2.Size = UDim2.new(math.clamp(p2 / 20, 0, 1), 0, v2.Size.Y.Scale, v2.Size.Y.Offset)
		end

		local function refreshRow(p1) --[[ refreshRow | Line: 285 | Upvalues: t (copy), ClientPlayerData (ref), EventStoreConfig (ref), t2 (ref), ConvertValue (ref), updateCardPity (copy) ]]
			local v1 = t[p1]

			if not v1 then
				return
			end

			local entry = v1.entry
			local v2 = ClientPlayerData.serverProfile:getState()
			local v3 = v2.events and v2.events[EventStoreConfig.EventId]

			if if entry.OneTimeBuy == true then if (v3 and v3.storePurchases or {})[entry.Id] == true then true else false else false then
				v1.card.Visible = true

				if v1.priceLabel then
					v1.priceLabel.Text = "OWNED"
				end

				if not v1.buyButton then
					return
				end

				v1.buyButton.Active = false
				v1.buyButton.AutoButtonColor = false
			else
				v1.card.Visible = true

				local v6

				if entry.MaxStock then
					local v7 = t2[p1]
					local v8 = if v7 == nil then false elseif v7 <= 0 then true else false

					if v1.stockLabel then
						if v7 == nil then
							v1.stockLabel.Text = ""
						elseif v8 then
							v1.stockLabel.Text = "0/" .. entry.MaxStock
						else
							v1.stockLabel.Text = ("%*/%*"):format(v7, entry.MaxStock)
						end
					end

					v6 = v8
				else
					v6 = false
				end

				if v1.priceLabel then
					v1.priceLabel.Text = if v6 then "Out of Stock" else ConvertValue.suffixformat(entry.Price)
				end

				if v1.buyButton then
					v1.buyButton.Active = not v6
					v1.buyButton.AutoButtonColor = not v6
				end

				if entry.ItemType ~= "Luckyblock" or not entry.ConfigName then
					return
				end

				updateCardPity(v1.card, v2.luckyblockPity and v2.luckyblockPity[entry.ConfigName] or 0)
			end
		end

		local function refreshAllRows() --[[ refreshAllRows | Line: 342 | Upvalues: t (copy), refreshRow (copy) ]]
			for v1 in t do
				refreshRow(v1)
			end
		end

		for v8 in t do
			refreshRow(v8)
		end

		ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 349 | Upvalues: EventStoreConfig (ref) ]]
			local v1 = p1.events and p1.events[EventStoreConfig.EventId]
			local t = {}

			t.storePurchases = if v1 then v1.storePurchases else v1
			t.luckyblockPity = p1.luckyblockPity

			return t
		end, refreshAllRows)
		Remotes.ReplicateEventStore:On(function(p1) --[[ Line: 357 | Upvalues: t2 (ref), v1 (ref), t (copy), refreshRow (copy) ]]
			if typeof(p1) ~= "table" then
				return
			end

			t2 = p1.Stock or {}
			v1 = p1.WindowEnd or 0

			for v2 in t do
				refreshRow(v2)
			end
		end)
		Remotes.RequestEventStoreState:Fire()

		local HUD = MainUI:FindFirstChild("HUD")
		local v9 = if HUD then HUD:FindFirstChild("Buttons") else HUD
		local v10 = if v9 then v9:FindFirstChild("EventStore") else v9

		if v10 then
			v10.MouseButton1Down:Connect(function() --[[ Line: 374 | Upvalues: p1 (copy), v12 (copy) ]]
				local v1 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

				if v1.OpenedUIComponent:Get() == v12 then
					v1.OpenedUIComponent:Set(nil)
				else
					v1.OpenedUIComponent:Set(v12)
				end
			end)
		end
	else
		local EventStore2 = MainUI:FindFirstChild("EventStore")

		if EventStore2 and EventStore2:IsA("GuiObject") then
			EventStore2.Visible = false
		end

		local HUD = MainUI:FindFirstChild("HUD")
		local v11 = HUD and HUD:FindFirstChild("Buttons")
		local v12 = v11 and v11:FindFirstChild("EventStore")

		if not (v12 and v12:IsA("GuiObject")) then
			return
		end

		v12.Visible = false
	end
end

return t