-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

game:GetService("SoundService")

local TweenService = game:GetService("TweenService")
local FishingFloatsConfig = require(ReplicatedStorage.shared.config.FishingFloatsConfig)
local FloatLootboxConfig = require(ReplicatedStorage.shared.config.FloatLootboxConfig)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local CashDisplay = require(ReplicatedStorage.shared.module.CashDisplay)
local rarityConfig = require(ReplicatedStorage.shared.config.rarityConfig)
local LocalPlayer = Players.LocalPlayer
local t = {}
local v1 = 0
local t2 = {}
local t3 = {}
local t4 = {}
local t5 = {}
local t6 = {}

local function findShopModel() --[[ findShopModel | Line: 39 ]]
	for v1, v2 in workspace:GetChildren() do
		if string.find(v2.Name, "wikShop") then
			return v2
		end
	end

	return nil
end

local function isAlive(p1) --[[ isAlive | Line: 52 ]]
	return if p1 == nil then false else p1:IsDescendantOf(workspace)
end

local gui = ReplicatedStorage.shared.model:FindFirstChild("gui")

if not gui then
	gui = Instance.new("Folder")
	gui.Name = "gui"
	gui.Parent = ReplicatedStorage.shared.model
end

local LootboxShopBillboard = gui:FindFirstChild("LootboxShopBillboard")
local v2

if LootboxShopBillboard then
	v2 = LootboxShopBillboard
else
	local LootboxShopBillboard2 = Instance.new("BillboardGui")

	LootboxShopBillboard2.Name = "LootboxShopBillboard"
	LootboxShopBillboard2.Size = UDim2.new(4, 0, 2.5, 0)
	LootboxShopBillboard2.StudsOffset = Vector3.new(0, 6, 0)
	LootboxShopBillboard2.AlwaysOnTop = false

	local Frame = Instance.new("Frame")

	Frame.Name = "Frame"
	Frame.Size = UDim2.new(1, 0, 1, 0)
	Frame.BackgroundColor3 = Color3.fromRGB(20, 20, 30)
	Frame.BackgroundTransparency = 0.3
	Frame.BorderSizePixel = 0
	Frame.Parent = LootboxShopBillboard2
	Instance.new("UICorner", Frame).CornerRadius = UDim.new(0.1, 0)

	local NameLabel = Instance.new("TextLabel")

	NameLabel.Name = "NameLabel"
	NameLabel.Size = UDim2.new(1, 0, 0.5, 0)
	NameLabel.BackgroundTransparency = 1
	NameLabel.Text = "Crate"
	NameLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
	NameLabel.TextScaled = true
	NameLabel.Font = Enum.Font.GothamBold
	NameLabel.Parent = Frame

	local PriceLabel = Instance.new("TextLabel")

	PriceLabel.Name = "PriceLabel"
	PriceLabel.Size = UDim2.new(1, 0, 0.4, 0)
	PriceLabel.Position = UDim2.new(0, 0, 0.55, 0)
	PriceLabel.BackgroundTransparency = 1
	PriceLabel.Text = "0"
	PriceLabel.TextColor3 = Color3.fromRGB(255, 215, 0)
	PriceLabel.TextScaled = true
	PriceLabel.Font = Enum.Font.GothamMedium
	PriceLabel.Parent = Frame
	LootboxShopBillboard2.Parent = gui
	warn("[FloatLootboxShop] Created LootboxShopBillboard template \226\128\148 copy it to shared.gui")
	v2 = LootboxShopBillboard2
end

local function createBillboard(p1, p2, p3) --[[ createBillboard | Line: 112 | Upvalues: FloatLootboxConfig (copy), t3 (copy), v2 (ref), CashDisplay (copy) ]]
	local v1 = FloatLootboxConfig.Lootboxes[p2]

	if not v1 then
		return
	end

	if t3[p3] then
		t3[p3]:Destroy()
		t3[p3] = nil
	end

	local LootboxInfo = v2:Clone()

	LootboxInfo.Name = "LootboxInfo"
	LootboxInfo.Adornee = p1
	LootboxInfo.Parent = p1

	local Frame = LootboxInfo:FindFirstChild("Frame")

	if Frame then
		local NameLabel = Frame:FindFirstChild("NameLabel")
		local PriceLabel = Frame:FindFirstChild("PriceLabel")

		if NameLabel then
			NameLabel.Text = v1.DisplayName
		end

		if PriceLabel then
			CashDisplay.applyToLabel(PriceLabel, v1.Price, {
				Compact = true
			})
		end
	end

	t3[p3] = LootboxInfo
end

local t7 = {}

local function pickRandomFloatImage(p1) --[[ pickRandomFloatImage | Line: 150 | Upvalues: t7 (copy), FishingFloatsConfig (copy) ]]
	local v1 = t7[p1]

	if v1 then
		return v1
	end

	local t = {}

	for v2, v3 in FishingFloatsConfig.Floats do
		local v4 = v3.TierImages and v3.TierImages[p1]

		if v4 then
			table.insert(t, v4)
		end
	end

	if #t == 0 then
		return nil
	end

	local v5 = t[math.random(1, #t)]

	t7[p1] = v5

	return v5
end

local FloatChances = ReplicatedStorage.shared.model:FindFirstChild("FloatChances")
local v3, v4, v5, v6, v7, v8, v9, v10, v11, v12, v13, _, v14

if FloatChances then
	v3 = function(p13, p23, p33) --[[ createChancesBillboard | Line: 179 | Upvalues: t6 (copy), FloatChances (copy), FloatLootboxConfig (copy), rarityConfig (copy), pickRandomFloatImage (copy) ]]
		if t6[p33] then
			t6[p33]:Destroy()
			t6[p33] = nil
		end

		local v1 = FloatChances

		if not v1 then
			return
		end

		local v2 = FloatLootboxConfig.Lootboxes[p23]

		if not v2 then
			return
		end

		local ChancesInfo = v1:Clone()

		ChancesInfo.Name = "ChancesInfo"
		ChancesInfo.Adornee = p13
		ChancesInfo.Enabled = false
		ChancesInfo.Parent = p13
		t6[p33] = ChancesInfo

		local FloatChances2 = ChancesInfo:FindFirstChild("FloatChances")
		local v3 = if FloatChances2 then FloatChances2:FindFirstChild("Content") else FloatChances2
		local v4 = if v3 then v3:FindFirstChild("ContentFrame") else v3
		local v5 = if v4 then v4:FindFirstChild("Template") else v4

		if not (v4 and v5) then
			return
		end

		v5.Visible = false

		for v6, v7 in v2.Drops do
			local v8 = v5:Clone()

			v8.Name = "Entry_" .. v6
			v8.LayoutOrder = v6
			v8.Visible = true

			local v9 = rarityConfig[v7.Tier]
			local Rarity = v8:FindFirstChild("Rarity")

			if Rarity then
				Rarity.Text = v9 and v9.displayName or v7.Tier

				if v9 then
					Rarity.TextColor3 = v9.rarityColor
				end
			end

			local Chance = v8:FindFirstChild("Chance")

			if Chance then
				Chance.Text = v7.Weight .. "%"
			end

			local Icon = v8:FindFirstChild("Icon")

			if Icon then
				local v11 = pickRandomFloatImage(v7.Tier)

				if v11 then
					Icon.Image = v11
					Icon.ImageColor3 = Color3.new(255/255, 255/255, 255/255)
				end
			end

			v8.Parent = v4
		end
	end
	v4 = function(p13, p23) --[[ createPrompt | Line: 243 | Upvalues: t4 (copy), LocalPlayer (copy), Remotes (copy), t6 (copy) ]]
		if t4[p23] then
			t4[p23]:Destroy()
			t4[p23] = nil
		end

		local ProximityPrompt = Instance.new("ProximityPrompt")

		ProximityPrompt.Style = Enum.ProximityPromptStyle.Custom
		ProximityPrompt.ObjectText = "Float Crate"
		ProximityPrompt.ActionText = "Buy"
		ProximityPrompt.HoldDuration = 0
		ProximityPrompt.MaxActivationDistance = 8
		ProximityPrompt.RequiresLineOfSight = false
		ProximityPrompt.Parent = p13
		ProximityPrompt.Triggered:Connect(function(p13) --[[ Line: 259 | Upvalues: LocalPlayer (ref), Remotes (ref), p23 (copy) ]]
			if p13 == LocalPlayer then
				Remotes.BuyFloatLootbox:Fire(p23)
			end
		end)
		ProximityPrompt.PromptShown:Connect(function() --[[ Line: 267 | Upvalues: t6 (ref), p23 (copy) ]]
			local v1 = t6[p23]

			if not v1 then
				return
			end

			v1.Enabled = true
		end)
		ProximityPrompt.PromptHidden:Connect(function() --[[ Line: 273 | Upvalues: t6 (ref), p23 (copy) ]]
			local v1 = t6[p23]

			if not v1 then
				return
			end

			v1.Enabled = false
		end)
		t4[p23] = ProximityPrompt
	end
	v5 = function(p13, p23, p33) --[[ spawnSlotModel | Line: 283 | Upvalues: t5 (copy), ReplicatedStorage (copy), RunService (copy), Players (copy) ]]
		if t5[p33] then
			t5[p33]:Destroy()
			t5[p33] = nil
		end

		local v1 = ReplicatedStorage:FindFirstChild("shared") and (ReplicatedStorage.shared.model and ReplicatedStorage.shared.model:FindFirstChild("FloatLootboxes"))
		local v2 = if v1 then v1:FindFirstChild(p23) else v1

		if not v2 then
			return
		end

		if not (v2:IsA("Model") or v2:IsA("BasePart")) then
			return
		end

		local v3 = v2:Clone()
		local v4 = p13.CFrame * CFrame.new(0, 1, 0)

		if v3:IsA("Model") then
			v3:PivotTo(v4)
		else
			v3.CFrame = v4
		end

		if v3:IsA("BasePart") then
			v3.Anchored = true
			v3.CanCollide = false
		end

		for v5, v6 in v3:GetDescendants() do
			if v6:IsA("BasePart") then
				v6.Anchored = true
				v6.CanCollide = false
			end
		end

		v3.Parent = p13
		t5[p33] = v3

		local v7 = CFrame.new(0, 1, 0)
		local v8 = p33 * 1.3
		local v9 = nil

		v9 = RunService.Heartbeat:Connect(function() --[[ Line: 336 | Upvalues: v3 (copy), v9 (ref), Players (ref), v8 (copy), p13 (copy), v7 (copy) ]]
			debug.profilebegin("UECS/FloatLootboxShop.SlotBob")

			if not (v3 and v3.Parent) then
				v9:Disconnect()
				debug.profileend()

				return
			end

			local v1 = Players.LocalPlayer.Character and Players.LocalPlayer.Character:FindFirstChild("HumanoidRootPart")

			if not v1 then
				debug.profileend()

				return
			end

			if (v1.Position - (if v3:IsA("Model") then v3:GetPivot().Position else v3.Position)).Magnitude > 40 then
				debug.profileend()

				return
			end

			local v32 = workspace:GetServerTimeNow()
			local v5 = math.sin(v32 * math.pi + v8) * 0.35
			local v72 = math.sin(v32 * math.pi * 0.6 + v8 + 1) * 0.08726646259971647
			local v92 = math.sin(v32 * math.pi * 0.8 + v8 + 2) * 0.05235987755982989
			local v10 = CFrame.new(0, v5, 0) * CFrame.Angles(v92, v72, 0)
			local v11 = p13.CFrame * v7

			if v3:IsA("Model") then
				v3:PivotTo(v11 * v10)
			else
				v3.CFrame = v11 * v10
			end

			debug.profileend()
		end)
	end
	v6 = function(p13) --[[ playDisappearAnimation | Line: 373 | Upvalues: t5 (copy), TweenService (copy) ]]
		local v1 = t5[p13]

		if not v1 then
			return
		end

		local t2 = {}

		if v1:IsA("BasePart") then
			table.insert(t2, v1)
		elseif v1:IsA("Model") then
			for v2, v3 in v1:GetDescendants() do
				if v3:IsA("BasePart") then
					table.insert(t2, v3)
				end
			end
		end

		for v4, v5 in t2 do
			TweenService:Create(v5, TweenInfo.new(0.5, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
				Transparency = 1,
				Size = v5.Size * 0.01
			}):Play()
		end

		task.delay(0.6, function() --[[ Line: 399 | Upvalues: t5 (ref), p13 (copy), v1 (copy) ]]
			if t5[p13] ~= v1 then
				return
			end

			v1:Destroy()
			t5[p13] = nil
		end)
	end
	v7 = function() --[[ updateShopDisplay | Line: 411 | Upvalues: FloatLootboxConfig (copy), t2 (copy), t (ref), createBillboard (copy), v3 (copy), v4 (copy), v5 (copy), v6 (copy), t3 (copy), t6 (copy), t4 (copy) ]]
		for i = 1, FloatLootboxConfig.ShopSlotCount do
			local v1 = t2[i]

			if v1 then
				local v2 = t[i]

				if v2 then
					createBillboard(v1, v2, i)
					v3(v1, v2, i)
					v4(v1, i)
					v5(v1, v2, i)

					continue
				end

				v6(i)

				if t3[i] then
					t3[i]:Destroy()
					t3[i] = nil
				end

				if t6[i] then
					t6[i]:Destroy()
					t6[i] = nil
				end

				if t4[i] then
					t4[i]:Destroy()
					t4[i] = nil
				end
			end
		end
	end
	v8 = nil
	v9 = 0
	v10 = function(p13) --[[ findRestockLabel | Line: 460 ]]
		local Sign = p13:FindFirstChild("Sign")
		local v1 = if Sign then Sign:FindFirstChildWhichIsA("BillboardGui") else Sign

		if not v1 then
			return nil
		end

		local v2 = v1:FindFirstChild("Restock") or v1:FindFirstChild("Restock", true)

		if v2 and v2:IsA("TextLabel") then
			return v2
		end

		return nil
	end
	v11 = 0
	v12 = function() --[[ isShopWired | Line: 489 | Upvalues: v8 (ref), FloatLootboxConfig (copy), t2 (copy) ]]
		local v1 = v8

		if not (if v1 == nil then false else v1:IsDescendantOf(workspace)) then
			return false
		end

		for i = 1, FloatLootboxConfig.ShopSlotCount do
			local v4
			local v5 = t2[i]

			v4 = if v5 == nil then false else v5:IsDescendantOf(workspace)

			if not v4 then
				return false
			end
		end

		return true
	end
	v13 = function() --[[ resolveShopWiring | Line: 504 | Upvalues: findShopModel (copy), FloatLootboxConfig (copy), t2 (copy), t3 (copy), t6 (copy), t4 (copy), t5 (copy), v10 (copy), v8 (ref) ]]
		local v1 = findShopModel()

		if not v1 then
			return false
		end

		local v2 = false

		for i = 1, FloatLootboxConfig.ShopSlotCount do
			local v3 = v1:FindFirstChild("LootboxSlot" .. i)

			if v3 ~= t2[i] then
				t2[i] = v3
				t3[i] = nil
				t6[i] = nil
				t4[i] = nil
				t5[i] = nil
				v2 = true
			end
		end

		local v4 = v10(v1)

		if v4 ~= v8 then
			v8 = v4
			v2 = true
		end

		return v2
	end
	_ = function() --[[ tickShopWiring | Line: 535 | Upvalues: v12 (copy), v11 (ref), v13 (copy), v7 (copy), Remotes (copy) ]]
		if v12() then
			return
		end

		local v1 = os.clock()

		if v1 - v11 < 1 then
			return
		end

		v11 = v1

		if not v13() then
			return
		end

		v7()
		Remotes.BuyFloatLootbox:Fire(0)
	end
	v14 = function() --[[ updateTimer | Line: 553 | Upvalues: v8 (ref), v1 (ref), v9 (ref), Remotes (copy) ]]
		if not v8 then
			return
		end

		if v1 == 0 then
			v8.Text = "Loading..."

			return
		end

		local v12 = v1 - os.time()

		if v12 <= 0 then
			v8.Text = "Refreshing..."

			local v2 = os.clock()

			if v2 - v9 >= 5 then
				v9 = v2
				Remotes.BuyFloatLootbox:Fire(0)
			end
		else
			v8.Text = string.format("Next Restock: %d:%02d", math.floor(v12 / 60), v12 % 60)
		end
	end

	return {
		Init = function(p13) --[[ Init | Line: 587 | Upvalues: v13 (copy), Remotes (copy), t (ref), v1 (ref), FloatLootboxConfig (copy), t2 (copy), v6 (copy), t3 (copy), t6 (copy), t4 (copy), v7 (copy), RunService (copy), v12 (copy), v11 (ref), v14 (copy) ]]
			v13()
			Remotes.ReplicateFloatShop:On(function(p13) --[[ Line: 592 | Upvalues: t (ref), v1 (ref), FloatLootboxConfig (ref), t2 (ref), v6 (ref), t3 (ref), t6 (ref), t4 (ref), v7 (ref) ]]
				if type(p13) ~= "table" then
					return
				end

				local v12 = table.clone(t)

				t = p13.Items or {}
				v1 = p13.WindowEnd or 0

				for i = 1, FloatLootboxConfig.ShopSlotCount do
					if v12[i] and (not t[i] and t2[i]) then
						v6(i)

						if t3[i] then
							t3[i]:Destroy()
							t3[i] = nil
						end

						if t6[i] then
							t6[i]:Destroy()
							t6[i] = nil
						end

						if t4[i] then
							t4[i]:Destroy()
							t4[i] = nil
						end
					end
				end

				task.delay(0.1, function() --[[ Line: 624 | Upvalues: v7 (ref) ]]
					v7()
				end)
			end)
			RunService.Heartbeat:Connect(function() --[[ Line: 630 | Upvalues: v12 (ref), v11 (ref), v13 (ref), v7 (ref), Remotes (ref), v14 (ref) ]]
				debug.profilebegin("UECS/FloatLootboxShop.TimerUpdate")

				if v12() then
					v14()
					debug.profileend()

					return
				end

				local v1 = os.clock()

				if v1 - v11 < 1 then
					v14()
					debug.profileend()

					return
				end

				v11 = v1

				if not v13() then
					v14()
					debug.profileend()

					return
				end

				v7()
				Remotes.BuyFloatLootbox:Fire(0)
				v14()
				debug.profileend()
			end)
			Remotes.BuyFloatLootbox:Fire(0)
		end
	}
end

warn("[FloatLootboxShop] FloatChances billboard template not found in shared.model")
v3 = function(p13, p23, p33) --[[ createChancesBillboard | Line: 179 | Upvalues: t6 (copy), FloatChances (copy), FloatLootboxConfig (copy), rarityConfig (copy), pickRandomFloatImage (copy) ]]
	if t6[p33] then
		t6[p33]:Destroy()
		t6[p33] = nil
	end

	local v1 = FloatChances

	if not v1 then
		return
	end

	local v2 = FloatLootboxConfig.Lootboxes[p23]

	if not v2 then
		return
	end

	local ChancesInfo = v1:Clone()

	ChancesInfo.Name = "ChancesInfo"
	ChancesInfo.Adornee = p13
	ChancesInfo.Enabled = false
	ChancesInfo.Parent = p13
	t6[p33] = ChancesInfo

	local FloatChances2 = ChancesInfo:FindFirstChild("FloatChances")
	local v3 = if FloatChances2 then FloatChances2:FindFirstChild("Content") else FloatChances2
	local v4 = if v3 then v3:FindFirstChild("ContentFrame") else v3
	local v5 = if v4 then v4:FindFirstChild("Template") else v4

	if not (v4 and v5) then
		return
	end

	v5.Visible = false

	for v6, v7 in v2.Drops do
		local v8 = v5:Clone()

		v8.Name = "Entry_" .. v6
		v8.LayoutOrder = v6
		v8.Visible = true

		local v9 = rarityConfig[v7.Tier]
		local Rarity = v8:FindFirstChild("Rarity")

		if Rarity then
			Rarity.Text = v9 and v9.displayName or v7.Tier

			if v9 then
				Rarity.TextColor3 = v9.rarityColor
			end
		end

		local Chance = v8:FindFirstChild("Chance")

		if Chance then
			Chance.Text = v7.Weight .. "%"
		end

		local Icon = v8:FindFirstChild("Icon")

		if Icon then
			local v11 = pickRandomFloatImage(v7.Tier)

			if v11 then
				Icon.Image = v11
				Icon.ImageColor3 = Color3.new(255/255, 255/255, 255/255)
			end
		end

		v8.Parent = v4
	end
end
v4 = function(p13, p23) --[[ createPrompt | Line: 243 | Upvalues: t4 (copy), LocalPlayer (copy), Remotes (copy), t6 (copy) ]]
	if t4[p23] then
		t4[p23]:Destroy()
		t4[p23] = nil
	end

	local ProximityPrompt = Instance.new("ProximityPrompt")

	ProximityPrompt.Style = Enum.ProximityPromptStyle.Custom
	ProximityPrompt.ObjectText = "Float Crate"
	ProximityPrompt.ActionText = "Buy"
	ProximityPrompt.HoldDuration = 0
	ProximityPrompt.MaxActivationDistance = 8
	ProximityPrompt.RequiresLineOfSight = false
	ProximityPrompt.Parent = p13
	ProximityPrompt.Triggered:Connect(function(p13) --[[ Line: 259 | Upvalues: LocalPlayer (ref), Remotes (ref), p23 (copy) ]]
		if p13 == LocalPlayer then
			Remotes.BuyFloatLootbox:Fire(p23)
		end
	end)
	ProximityPrompt.PromptShown:Connect(function() --[[ Line: 267 | Upvalues: t6 (ref), p23 (copy) ]]
		local v1 = t6[p23]

		if not v1 then
			return
		end

		v1.Enabled = true
	end)
	ProximityPrompt.PromptHidden:Connect(function() --[[ Line: 273 | Upvalues: t6 (ref), p23 (copy) ]]
		local v1 = t6[p23]

		if not v1 then
			return
		end

		v1.Enabled = false
	end)
	t4[p23] = ProximityPrompt
end
v5 = function(p13, p23, p33) --[[ spawnSlotModel | Line: 283 | Upvalues: t5 (copy), ReplicatedStorage (copy), RunService (copy), Players (copy) ]]
	if t5[p33] then
		t5[p33]:Destroy()
		t5[p33] = nil
	end

	local v1 = ReplicatedStorage:FindFirstChild("shared") and (ReplicatedStorage.shared.model and ReplicatedStorage.shared.model:FindFirstChild("FloatLootboxes"))
	local v2 = if v1 then v1:FindFirstChild(p23) else v1

	if not v2 then
		return
	end

	if not (v2:IsA("Model") or v2:IsA("BasePart")) then
		return
	end

	local v3 = v2:Clone()
	local v4 = p13.CFrame * CFrame.new(0, 1, 0)

	if v3:IsA("Model") then
		v3:PivotTo(v4)
	else
		v3.CFrame = v4
	end

	if v3:IsA("BasePart") then
		v3.Anchored = true
		v3.CanCollide = false
	end

	for v5, v6 in v3:GetDescendants() do
		if v6:IsA("BasePart") then
			v6.Anchored = true
			v6.CanCollide = false
		end
	end

	v3.Parent = p13
	t5[p33] = v3

	local v7 = CFrame.new(0, 1, 0)
	local v8 = p33 * 1.3
	local v9 = nil

	v9 = RunService.Heartbeat:Connect(function() --[[ Line: 336 | Upvalues: v3 (copy), v9 (ref), Players (ref), v8 (copy), p13 (copy), v7 (copy) ]]
		debug.profilebegin("UECS/FloatLootboxShop.SlotBob")

		if not (v3 and v3.Parent) then
			v9:Disconnect()
			debug.profileend()

			return
		end

		local v1 = Players.LocalPlayer.Character and Players.LocalPlayer.Character:FindFirstChild("HumanoidRootPart")

		if not v1 then
			debug.profileend()

			return
		end

		if (v1.Position - (if v3:IsA("Model") then v3:GetPivot().Position else v3.Position)).Magnitude > 40 then
			debug.profileend()

			return
		end

		local v32 = workspace:GetServerTimeNow()
		local v5 = math.sin(v32 * math.pi + v8) * 0.35
		local v72 = math.sin(v32 * math.pi * 0.6 + v8 + 1) * 0.08726646259971647
		local v92 = math.sin(v32 * math.pi * 0.8 + v8 + 2) * 0.05235987755982989
		local v10 = CFrame.new(0, v5, 0) * CFrame.Angles(v92, v72, 0)
		local v11 = p13.CFrame * v7

		if v3:IsA("Model") then
			v3:PivotTo(v11 * v10)
		else
			v3.CFrame = v11 * v10
		end

		debug.profileend()
	end)
end
v6 = function(p13) --[[ playDisappearAnimation | Line: 373 | Upvalues: t5 (copy), TweenService (copy) ]]
	local v1 = t5[p13]

	if not v1 then
		return
	end

	local t2 = {}

	if v1:IsA("BasePart") then
		table.insert(t2, v1)
	elseif v1:IsA("Model") then
		for v2, v3 in v1:GetDescendants() do
			if v3:IsA("BasePart") then
				table.insert(t2, v3)
			end
		end
	end

	for v4, v5 in t2 do
		TweenService:Create(v5, TweenInfo.new(0.5, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
			Transparency = 1,
			Size = v5.Size * 0.01
		}):Play()
	end

	task.delay(0.6, function() --[[ Line: 399 | Upvalues: t5 (ref), p13 (copy), v1 (copy) ]]
		if t5[p13] ~= v1 then
			return
		end

		v1:Destroy()
		t5[p13] = nil
	end)
end
v7 = function() --[[ updateShopDisplay | Line: 411 | Upvalues: FloatLootboxConfig (copy), t2 (copy), t (ref), createBillboard (copy), v3 (copy), v4 (copy), v5 (copy), v6 (copy), t3 (copy), t6 (copy), t4 (copy) ]]
	for i = 1, FloatLootboxConfig.ShopSlotCount do
		local v1 = t2[i]

		if v1 then
			local v2 = t[i]

			if v2 then
				createBillboard(v1, v2, i)
				v3(v1, v2, i)
				v4(v1, i)
				v5(v1, v2, i)

				continue
			end

			v6(i)

			if t3[i] then
				t3[i]:Destroy()
				t3[i] = nil
			end

			if t6[i] then
				t6[i]:Destroy()
				t6[i] = nil
			end

			if t4[i] then
				t4[i]:Destroy()
				t4[i] = nil
			end
		end
	end
end
v8 = nil
v9 = 0
v10 = function(p13) --[[ findRestockLabel | Line: 460 ]]
	local Sign = p13:FindFirstChild("Sign")
	local v1 = if Sign then Sign:FindFirstChildWhichIsA("BillboardGui") else Sign

	if not v1 then
		return nil
	end

	local v2 = v1:FindFirstChild("Restock") or v1:FindFirstChild("Restock", true)

	if v2 and v2:IsA("TextLabel") then
		return v2
	end

	return nil
end
v11 = 0
v12 = function() --[[ isShopWired | Line: 489 | Upvalues: v8 (ref), FloatLootboxConfig (copy), t2 (copy) ]]
	local v1 = v8

	if not (if v1 == nil then false else v1:IsDescendantOf(workspace)) then
		return false
	end

	for i = 1, FloatLootboxConfig.ShopSlotCount do
		local v4
		local v5 = t2[i]

		v4 = if v5 == nil then false else v5:IsDescendantOf(workspace)

		if not v4 then
			return false
		end
	end

	return true
end
v13 = function() --[[ resolveShopWiring | Line: 504 | Upvalues: findShopModel (copy), FloatLootboxConfig (copy), t2 (copy), t3 (copy), t6 (copy), t4 (copy), t5 (copy), v10 (copy), v8 (ref) ]]
	local v1 = findShopModel()

	if not v1 then
		return false
	end

	local v2 = false

	for i = 1, FloatLootboxConfig.ShopSlotCount do
		local v3 = v1:FindFirstChild("LootboxSlot" .. i)

		if v3 ~= t2[i] then
			t2[i] = v3
			t3[i] = nil
			t6[i] = nil
			t4[i] = nil
			t5[i] = nil
			v2 = true
		end
	end

	local v4 = v10(v1)

	if v4 ~= v8 then
		v8 = v4
		v2 = true
	end

	return v2
end
_ = function() --[[ tickShopWiring | Line: 535 | Upvalues: v12 (copy), v11 (ref), v13 (copy), v7 (copy), Remotes (copy) ]]
	if v12() then
		return
	end

	local v1 = os.clock()

	if v1 - v11 < 1 then
		return
	end

	v11 = v1

	if not v13() then
		return
	end

	v7()
	Remotes.BuyFloatLootbox:Fire(0)
end
v14 = function() --[[ updateTimer | Line: 553 | Upvalues: v8 (ref), v1 (ref), v9 (ref), Remotes (copy) ]]
	if not v8 then
		return
	end

	if v1 == 0 then
		v8.Text = "Loading..."

		return
	end

	local v12 = v1 - os.time()

	if v12 <= 0 then
		v8.Text = "Refreshing..."

		local v2 = os.clock()

		if v2 - v9 >= 5 then
			v9 = v2
			Remotes.BuyFloatLootbox:Fire(0)
		end
	else
		v8.Text = string.format("Next Restock: %d:%02d", math.floor(v12 / 60), v12 % 60)
	end
end

return {
	Init = function(p13) --[[ Init | Line: 587 | Upvalues: v13 (copy), Remotes (copy), t (ref), v1 (ref), FloatLootboxConfig (copy), t2 (copy), v6 (copy), t3 (copy), t6 (copy), t4 (copy), v7 (copy), RunService (copy), v12 (copy), v11 (ref), v14 (copy) ]]
		v13()
		Remotes.ReplicateFloatShop:On(function(p13) --[[ Line: 592 | Upvalues: t (ref), v1 (ref), FloatLootboxConfig (ref), t2 (ref), v6 (ref), t3 (ref), t6 (ref), t4 (ref), v7 (ref) ]]
			if type(p13) ~= "table" then
				return
			end

			local v12 = table.clone(t)

			t = p13.Items or {}
			v1 = p13.WindowEnd or 0

			for i = 1, FloatLootboxConfig.ShopSlotCount do
				if v12[i] and (not t[i] and t2[i]) then
					v6(i)

					if t3[i] then
						t3[i]:Destroy()
						t3[i] = nil
					end

					if t6[i] then
						t6[i]:Destroy()
						t6[i] = nil
					end

					if t4[i] then
						t4[i]:Destroy()
						t4[i] = nil
					end
				end
			end

			task.delay(0.1, function() --[[ Line: 624 | Upvalues: v7 (ref) ]]
				v7()
			end)
		end)
		RunService.Heartbeat:Connect(function() --[[ Line: 630 | Upvalues: v12 (ref), v11 (ref), v13 (ref), v7 (ref), Remotes (ref), v14 (ref) ]]
			debug.profilebegin("UECS/FloatLootboxShop.TimerUpdate")

			if v12() then
				v14()
				debug.profileend()

				return
			end

			local v1 = os.clock()

			if v1 - v11 < 1 then
				v14()
				debug.profileend()

				return
			end

			v11 = v1

			if not v13() then
				v14()
				debug.profileend()

				return
			end

			v7()
			Remotes.BuyFloatLootbox:Fire(0)
			v14()
			debug.profileend()
		end)
		Remotes.BuyFloatLootbox:Fire(0)
	end
}