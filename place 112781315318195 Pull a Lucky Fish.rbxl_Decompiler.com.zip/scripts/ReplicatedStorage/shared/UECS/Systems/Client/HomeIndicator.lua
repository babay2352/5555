-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local v1 = UDim2.fromScale(16, 16)
local v2 = TweenInfo.new(0.35, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
local v3 = TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
local v4 = TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local t = {
	UECS = nil
}

function t.Init(p1) --[[ Init | Line: 25 | Upvalues: t (copy), Players (copy), v1 (copy), TweenService (copy), v2 (copy), v4 (copy), v3 (copy), RunService (copy) ]]
	local v12 = assert(t.UECS, "UECS not initialized")
	local LocalPlayer = Players.LocalPlayer
	local PlayerGui = LocalPlayer:WaitForChild("PlayerGui")
	local HomeIndicator = Instance.new("BillboardGui")

	HomeIndicator.Name = "HomeIndicator"
	HomeIndicator.Size = v1
	HomeIndicator.StudsOffset = Vector3.new(0, 12, 0)
	HomeIndicator.AlwaysOnTop = true
	HomeIndicator.LightInfluence = 0
	HomeIndicator.MaxDistance = (1 / 0)
	HomeIndicator.Enabled = false

	local ImageLabel = Instance.new("ImageLabel")

	ImageLabel.BackgroundTransparency = 1
	ImageLabel.Size = UDim2.fromScale(1, 1)
	ImageLabel.Image = "rbxassetid://73254077936066"
	ImageLabel.ImageTransparency = 1
	ImageLabel.Parent = HomeIndicator

	local UIScale = Instance.new("UIScale")

	UIScale.Scale = 0
	UIScale.Parent = ImageLabel
	HomeIndicator.Parent = PlayerGui

	local v22 = false
	local v32 = nil
	local v42 = nil

	local function setVisible(p1) --[[ setVisible | Line: 59 | Upvalues: v22 (ref), v32 (ref), v42 (ref), HomeIndicator (copy), TweenService (ref), UIScale (copy), v2 (ref), ImageLabel (copy), v4 (ref), v3 (ref) ]]
		if p1 == v22 then
			return
		end

		v22 = p1

		if v32 then
			v32:Cancel()
		end

		if v42 then
			v42:Cancel()
		end

		if p1 then
			HomeIndicator.Enabled = true
			v32 = TweenService:Create(UIScale, v2, {
				Scale = 1
			})
			v42 = TweenService:Create(ImageLabel, v4, {
				ImageTransparency = 0
			})
			v32:Play()
			v42:Play()
		else
			v32 = TweenService:Create(UIScale, v3, {
				Scale = 0
			})
			v42 = TweenService:Create(ImageLabel, v3, {
				ImageTransparency = 1
			})
			v32:Play()
			v42:Play()
			v32.Completed:Once(function(p1) --[[ Line: 83 | Upvalues: v22 (ref), HomeIndicator (ref) ]]
				if p1 ~= Enum.PlaybackState.Completed or v22 then
					return
				end

				HomeIndicator.Enabled = false
			end)
		end
	end

	local function getHomeAnchor() --[[ getHomeAnchor | Line: 93 | Upvalues: v12 (copy), LocalPlayer (copy) ]]
		for v1, v2 in v12:GetComponents("TycoonComponent") do
			if v2.Owner:Get() == LocalPlayer then
				local Entity = v2.Entity

				if typeof(Entity) == "Instance" then
					local FloorSpawn = Entity:FindFirstChild("FloorSpawn")

					if FloorSpawn and FloorSpawn:IsA("BasePart") then
						return FloorSpawn
					end

					break
				end

				break
			end
		end

		return nil
	end

	RunService.Heartbeat:Connect(function() --[[ Line: 107 | Upvalues: getHomeAnchor (copy), HomeIndicator (copy), setVisible (copy), LocalPlayer (copy) ]]
		debug.profilebegin("UECS/HomeIndicator.Heartbeat")

		local v1 = getHomeAnchor()

		if not v1 then
			HomeIndicator.Adornee = nil
			setVisible(false)
			debug.profileend()

			return
		end

		if HomeIndicator.Adornee ~= v1 then
			HomeIndicator.Adornee = v1
		end

		local Character = LocalPlayer.Character
		local v2 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character
		local v3 = if v2 and v2:IsA("BasePart") then v2 else nil

		if not v3 then
			setVisible(false)
			debug.profileend()

			return
		end

		setVisible((v3.Position - v1.Position).Magnitude > 50)
		debug.profileend()
	end)
end

return t