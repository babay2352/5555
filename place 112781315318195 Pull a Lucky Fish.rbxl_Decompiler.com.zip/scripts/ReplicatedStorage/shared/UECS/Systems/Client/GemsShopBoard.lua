-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local QuestConfig = require(ReplicatedStorage.shared.config.QuestConfig)
local QuestView = require(ReplicatedStorage.shared.util.QuestView)
local t = {
	UECS = nil,
	Priority = 31
}
local v1 = Color3.fromRGB(39, 188, 49)

function t.Init(p1) --[[ Init | Line: 18 | Upvalues: ClientPlayerData (copy), Players (copy), ReplicatedStorage (copy), v1 (copy), QuestView (copy), QuestConfig (copy) ]]
	local GemsShop = workspace:FindFirstChild("GemsShop")

	if not GemsShop then
		return
	end

	local Part = GemsShop:FindFirstChild("Part")

	if not Part then
		return
	end

	local SurfaceGui = Part:FindFirstChild("SurfaceGui")

	if not SurfaceGui then
		return
	end

	repeat
		task.wait()
	until ClientPlayerData.isPlayerDataLoaded

	local LocalPlayer = Players.LocalPlayer

	SurfaceGui.Enabled = false

	local GemsShopBoard = ReplicatedStorage.shared.model:WaitForChild("GemsShopBoardTemplate"):Clone()

	GemsShopBoard.Name = "GemsShopBoard"
	GemsShopBoard.Adornee = Part
	GemsShopBoard.Face = SurfaceGui.Face
	GemsShopBoard.PixelsPerStud = SurfaceGui.PixelsPerStud
	GemsShopBoard.LightInfluence = SurfaceGui.LightInfluence
	GemsShopBoard.Brightness = SurfaceGui.Brightness
	GemsShopBoard.Parent = LocalPlayer.PlayerGui

	local QuestList = GemsShopBoard:WaitForChild("QuestList")
	local CompletedLabel = QuestList:WaitForChild("CompletedLabel")
	local QuestTemplate = LocalPlayer.PlayerGui:WaitForChild("MainUI"):WaitForChild("Quests"):WaitForChild("Content"):WaitForChild("ScrollingFrame"):WaitForChild("QuestTemplate")
	local t = {}
	local Frame = QuestTemplate:FindFirstChild("Frame")
	local v12 = if Frame then Frame.BackgroundColor3 else Color3.new(255/255, 255/255, 255/255)

	local function getState() --[[ getState | Line: 70 | Upvalues: ClientPlayerData (ref) ]]
		return ClientPlayerData.serverProfile:getState()
	end

	local function refreshCard(p1, p2, p3, p4) --[[ refreshCard | Line: 81 | Upvalues: v1 (ref), QuestView (ref) ]]
		local Frame = p1:FindFirstChild("Frame")

		if Frame then
			Frame.BackgroundColor3 = if p2.Claimed then v1 else p4
		end

		local Bar = p1:FindFirstChild("Bar")

		if not Bar then
			return
		end

		local v2 = math.min(p3, p2.Def.Goal)
		local Filler = Bar:FindFirstChild("Filler")

		if Filler then
			Filler.Size = UDim2.fromScale(QuestView.ProgressFraction(p2.Def, v2), 1)
		end

		local NumberProgress = Bar:FindFirstChild("NumberProgress")

		if not NumberProgress then
			return
		end

		NumberProgress.Text = QuestView.FormatProgress(p2.Def, v2)
	end

	local function removeGradientTransparency(p1) --[[ removeGradientTransparency | Line: 102 ]]
		for v1, v2 in p1:GetDescendants() do
			if v2:IsA("UIGradient") then
				v2.Transparency = NumberSequence.new(0)
			end
		end
	end

	local function buildCards() --[[ buildCards | Line: 110 | Upvalues: t (copy), QuestView (ref), getState (copy), CompletedLabel (copy), QuestTemplate (copy), QuestList (copy), removeGradientTransparency (copy), refreshCard (copy), v12 (copy), QuestConfig (ref) ]]
		for v1, v2 in t do
			v2:Destroy()
		end

		table.clear(t)

		local v3 = QuestView.GetActive(getState())

		if #v3 == 0 then
			CompletedLabel.Visible = true

			return
		end

		CompletedLabel.Visible = false

		for v4, v5 in v3 do
			local v6 = QuestTemplate:Clone()

			v6.Name = v5.Def.Id
			v6.LayoutOrder = v4
			v6.Visible = true
			v6.Size = UDim2.new(0.95, 0, 0.28, 0)
			v6.Parent = QuestList
			removeGradientTransparency(v6)

			local Title = v6:FindFirstChild("Title")

			if Title then
				Title.Text = v5.Def.DisplayText
			end

			refreshCard(v6, v5, v5.Progress, v12)

			local RightSideFrame = v6:FindFirstChild("RightSideFrame")
			local v7 = if RightSideFrame then RightSideFrame:FindFirstChild("SkipOrClaimButton") else nil

			if v7 and v7:IsA("GuiObject") then
				v7.Visible = false
			end

			if RightSideFrame then
				local count = 0

				for v8, v9 in RightSideFrame:GetChildren() do
					if v9.Name == "RewardFrame" and v9:IsA("GuiObject") then
						count = count + 1

						local v10 = v5.Rewards[count]

						if v10 then
							v9.Visible = true

							local Icon = v9:FindFirstChild("Icon")

							if Icon then
								Icon.Image = QuestConfig.GetRewardIcon(v10)

								local Title2 = Icon:FindFirstChild("Title")

								if Title2 then
									Title2.Text = QuestView.FormatRewardAmount(v10)
								end
							end

							continue
						end

						v9.Visible = false
					end
				end
			end

			t[v5.Def.Id] = v6
		end
	end

	local function updateProgress() --[[ updateProgress | Line: 177 | Upvalues: QuestView (ref), getState (copy), t (copy), refreshCard (copy), v12 (copy) ]]
		for v1, v2 in QuestView.GetActive(getState()) do
			local v3 = t[v2.Def.Id]

			if v3 then
				refreshCard(v3, v2, v2.Progress, v12)
			end
		end
	end

	local t2 = {}

	local function snapshotQuestIds() --[[ snapshotQuestIds | Line: 188 | Upvalues: QuestView (ref), getState (copy) ]]
		local t = {}

		for v1, v2 in QuestView.GetActive(getState()) do
			t[v2.Def.Id] = true
		end

		return t
	end

	local function onStateChanged() --[[ onStateChanged | Line: 196 | Upvalues: snapshotQuestIds (copy), t2 (ref), t (copy), buildCards (copy), updateProgress (copy) ]]
		local v1 = snapshotQuestIds()
		local v2 = false

		for v3 in v1 do
			if not t2[v3] then
				v2 = true

				break
			end
		end

		for v4 in t2 do
			if not v1[v4] then
				local v5 = t[v4]

				if v5 then
					v5:Destroy()
					t[v4] = nil
				end
			end
		end

		if v2 then
			buildCards()
		else
			updateProgress()
		end

		t2 = v1
	end

	buildCards()
	t2 = snapshotQuestIds()

	local v2 = 0
	local v3 = os.clock()

	local function tickPlaytime() --[[ tickPlaytime | Line: 232 | Upvalues: v3 (ref), v2 (ref), QuestView (ref), getState (copy), QuestConfig (ref), t (copy), refreshCard (copy), v12 (copy) ]]
		local v1 = os.clock()
		local v22 = v1 - v3

		if v22 < 1 then
			return
		end

		v3 = v1
		v2 = v2 + math.floor(v22)

		for v32, v4 in QuestView.GetActive(getState()) do
			local v5 = QuestConfig.Trackers[v4.Def.TrackerType]

			if v5 and (v5.Kind == "Timer" and not v4.Done) then
				local v6 = t[v4.Def.Id]

				if v6 then
					refreshCard(v6, v4, v4.Progress + v2, v12)
				end
			end
		end
	end

	task.spawn(function() --[[ Line: 253 | Upvalues: tickPlaytime (copy) ]]
		while true do
			task.wait(1)
			tickPlaytime()
		end
	end)
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 260 ]]
		return p1.quests
	end, function() --[[ Line: 262 | Upvalues: v2 (ref), v3 (ref), onStateChanged (copy) ]]
		v2 = 0
		v3 = os.clock()
		onStateChanged()
	end)
end

return t