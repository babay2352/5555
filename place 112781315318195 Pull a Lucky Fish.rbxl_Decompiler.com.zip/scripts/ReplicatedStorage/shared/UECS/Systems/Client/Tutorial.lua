-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local CashDisplay = require(ReplicatedStorage.shared.module.CashDisplay)
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Remotes = require(ReplicatedStorage.shared.Remotes)
local TutorialConfig = require(ReplicatedStorage.shared.config.TutorialConfig)
local TutorialCutscene = require(ReplicatedStorage.client.TutorialCutscene)
local TutorialPointer = require(ReplicatedStorage.client.TutorialPointer)
local t = {
	TrainingToolShop = 5,
	SpeedUpgrede = 7,
	FishingFloats = #TutorialConfig + 1
}

return {
	UECS = nil,
	Priority = 60,
	Init = function(p1) --[[ Init | Line: 32 | Upvalues: Players (copy), TweenService (copy), t (copy), ClientPlayerData (copy), TutorialPointer (copy), TutorialConfig (copy), CashDisplay (copy), Remotes (copy), TutorialCutscene (copy) ]]
		local TutorialFrame = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI"):WaitForChild("TutorialFrame")
		local TutorialTitle = TutorialFrame:WaitForChild("TutorialTitle")
		local TutorialProgress = Instance.new("Frame")

		TutorialProgress.Name = "TutorialProgress"
		TutorialProgress.AnchorPoint = Vector2.new(0.5, 0)
		TutorialProgress.Position = UDim2.fromScale(0.5, 1.12)
		TutorialProgress.Size = UDim2.fromScale(0.55, 0.34)
		TutorialProgress.BackgroundColor3 = Color3.fromRGB(28, 30, 38)
		TutorialProgress.BorderSizePixel = 0
		TutorialProgress.ZIndex = 5100
		TutorialProgress.Visible = false
		TutorialProgress.Parent = TutorialFrame

		local UICorner = Instance.new("UICorner")

		UICorner.CornerRadius = UDim.new(1, 0)
		UICorner.Parent = TutorialProgress

		local UIStroke = Instance.new("UIStroke")

		UIStroke.Color = Color3.fromRGB(0, 0, 0)
		UIStroke.Thickness = 2
		UIStroke.Parent = TutorialProgress

		local Fill = Instance.new("Frame")

		Fill.Name = "Fill"
		Fill.AnchorPoint = Vector2.new(0, 0.5)
		Fill.Position = UDim2.fromScale(0, 0.5)
		Fill.Size = UDim2.fromScale(0, 1)
		Fill.BackgroundColor3 = Color3.fromRGB(29, 236, 22)
		Fill.BorderSizePixel = 0
		Fill.ZIndex = 5101
		Fill.Parent = TutorialProgress

		local UICorner2 = Instance.new("UICorner")

		UICorner2.CornerRadius = UDim.new(1, 0)
		UICorner2.Parent = Fill

		local function setProgress(p1) --[[ setProgress | Line: 73 | Upvalues: TutorialProgress (copy), TweenService (ref), Fill (copy) ]]
			if p1 then
				TutorialProgress.Visible = true

				local v1 = math.clamp(p1, 0, 1)

				TweenService:Create(Fill, TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					Size = UDim2.fromScale(v1, 1)
				}):Play()
			else
				TutorialProgress.Visible = false
			end
		end

		local v1 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

		v1.OpenedUIComponent.OnChange:Connect(function(p1) --[[ Line: 88 | Upvalues: t (ref), ClientPlayerData (ref), v1 (copy) ]]
			if not p1 then
				return
			end

			local Entity = p1.Entity

			if not Entity then
				return
			end

			local v12 = t[Entity.Name]

			if not v12 then
				return
			end

			if not (ClientPlayerData.serverProfile:getState().tutorialInfo.tutorialStep < v12) then
				return
			end

			task.defer(function() --[[ Line: 102 | Upvalues: v1 (ref), p1 (copy) ]]
				if v1.OpenedUIComponent:Get() ~= p1 then
					return
				end

				v1.OpenedUIComponent:Set(nil)
			end)
		end)

		local function focusElement(p1) --[[ focusElement | Line: 112 | Upvalues: TutorialPointer (ref) ]]
			TutorialPointer.focusUI(p1)
		end

		local v2 = nil

		local function runStep(p12) --[[ runStep | Line: 118 | Upvalues: v2 (ref), TutorialPointer (ref), TutorialProgress (copy), TutorialConfig (ref), TutorialFrame (copy), CashDisplay (ref), TutorialTitle (copy), ClientPlayerData (ref), Remotes (ref), focusElement (copy), p1 (copy), setProgress (copy) ]]
			if v2 then
				v2()
				v2 = nil
			end

			TutorialPointer.focusUI(nil)
			TutorialProgress.Visible = false

			local v1 = TutorialConfig[p12]

			if v1 then
				local function setTitle(p1) --[[ setTitle | Line: 133 | Upvalues: CashDisplay (ref), TutorialTitle (ref) ]]
					CashDisplay.applyTokens(TutorialTitle, p1, {
						Compact = true
					})
				end

				CashDisplay.applyTokens(TutorialTitle, v1.DisplayData.Title, {
					Compact = true
				})
				TutorialFrame.Visible = true

				local function progressNext() --[[ progressNext | Line: 143 | Upvalues: ClientPlayerData (ref), p12 (copy), Remotes (ref) ]]
					local tutorialStep = ClientPlayerData.serverProfile:getState().tutorialInfo.tutorialStep

					if tutorialStep == p12 then
						Remotes.MarkTutorialStepCompletion:Fire(tutorialStep)
						ClientPlayerData.serverProfile.setTutorialInfo({
							tutorialStep = tutorialStep + 1
						})
					end
				end

				v2 = v1.ClientInitFunction(progressNext, focusElement, setTitle, p1.UECS, setProgress)
			else
				TutorialFrame.Visible = false
			end
		end

		Remotes.PlayTutorialCutscene:On(function(p1) --[[ Line: 162 | Upvalues: TutorialCutscene (ref) ]]
			task.spawn(TutorialCutscene.play, if type(p1) == "table" then tonumber(p1.FromScene) else nil)
		end)

		local tutorialStep = ClientPlayerData.serverProfile:getState().tutorialInfo.tutorialStep

		if tutorialStep == 1 then
			TutorialFrame.Visible = false
			task.spawn(function() --[[ Line: 177 | Upvalues: TutorialCutscene (ref), runStep (copy), ClientPlayerData (ref) ]]
				TutorialCutscene.play()
				runStep(ClientPlayerData.serverProfile:getState().tutorialInfo.tutorialStep)
			end)
		else
			runStep(tutorialStep)
		end

		ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 186 ]]
			return p1.tutorialInfo.tutorialStep
		end, function(p1) --[[ Line: 188 | Upvalues: runStep (copy) ]]
			runStep(p1)
		end)
	end
}