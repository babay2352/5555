-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local SoundService = game:GetService("SoundService")
local TweenService = game:GetService("TweenService")
local Workspace = game:GetService("Workspace")
local ClientMusicController = require(ReplicatedStorage.shared.UECS.Systems.Client.ClientMusicController)
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local CashDisplay = require(ReplicatedStorage.shared.module.CashDisplay)
local CashFormat = require(ReplicatedStorage.shared.util.CashFormat)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local notifications = require(ReplicatedStorage.shared.module.notifications)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local TutorialPointer = require(ReplicatedStorage.client.TutorialPointer)
local t = {
	UECS = nil
}
local FishingVillage = require(ReplicatedStorage.shared.config.WorldsConfig).FishingVillage
local UnlockFx = FishingVillage.UnlockFx
local Tour = FishingVillage.Tour
local Fireworks = Tour.Fireworks
local t2 = {}
local v1 = false

local function getUnlock() --[[ getUnlock | Line: 97 | Upvalues: FishingVillage (copy) ]]
	return FishingVillage.Unlock
end

local function isUnlocked(p1) --[[ isUnlocked | Line: 101 ]]
	return (if p1 then p1.unlockedFishingVillage else p1) == true
end

local function refreshBoard(p1, p2) --[[ refreshBoard | Line: 106 | Upvalues: FishingVillage (copy), CashDisplay (copy), CashFormat (copy) ]]
	local Unlock = FishingVillage.Unlock
	local v1 = FishingVillage.Unlock and Unlock.RebirthLevel or 0
	local v2 = Unlock and Unlock.CashCost or 0
	local v4 = if (if p2 then p2.unlockedFishingVillage else p2) == true then true else false
	local v5 = p2 and p2.rebirthLevel or 0
	local v6 = p2 and p2.money or 0

	if v4 then
		v5 = v1
		v6 = v2
	end

	p1.title.Text = FishingVillage.Title
	p1.rebirthLabel.Text = FishingVillage.RebirthReqText:gsub("{rebirth}", (tostring(v1)))
	CashDisplay.applyTokens(p1.moneyLabel, FishingVillage.MoneyReqText:gsub("{cash}", CashFormat.token(v2)), {
		Compact = true
	})

	local v7 = math.min(v5, v1)

	p1.rebirthFiller.Size = UDim2.fromScale(if v1 > 0 then v7 / v1 else 1, 1)
	p1.rebirthCapacity.Text = ("%*/%*"):format(v7, v1)

	local v9 = math.min(v6, v2)

	p1.moneyFiller.Size = UDim2.fromScale(if v2 > 0 then v9 / v2 else 1, 1)
	CashDisplay.applyParts(p1.moneyCapacity, {
		{
			Compact = true,
			Value = v9
		},
		"/",
		{
			Compact = true,
			Value = v2
		}
	})
	p1.buttonLabel.Text = if v4 then "UNLOCKED!" else "BUY"
end

local v2 = false

local function updateArrow(p1) --[[ updateArrow | Line: 152 | Upvalues: FishingVillage (copy), t2 (copy), TutorialPointer (copy), v2 (ref) ]]
	local Unlock = FishingVillage.Unlock
	local v1 = false

	if Unlock and not (if (if p1 then p1.unlockedFishingVillage else p1) == true then true else false) then
		local v4 = not Unlock.RebirthLevel

		if not v4 then
			v4 = if Unlock.RebirthLevel <= (p1 and p1.rebirthLevel or 0) then true else false
		end

		local v6 = not Unlock.CashCost

		if not v6 then
			v6 = if Unlock.CashCost <= (if p1 then p1.money or 0 else 0) then true else false
		end

		v1 = v4 and v6
	end

	local v8 = if v1 then next(t2) else nil

	if v8 then
		TutorialPointer.guide(v8, false)
		v2 = true

		return
	end

	if not v2 then
		return
	end

	TutorialPointer.guide(nil)
	v2 = false
end

local function detachBoard(p1) --[[ detachBoard | Line: 173 | Upvalues: t2 (copy), updateArrow (copy), ClientPlayerData (copy) ]]
	local v1 = t2[p1]

	if not v1 then
		return
	end

	t2[p1] = nil
	v1.gui:Destroy()
	updateArrow(ClientPlayerData.serverProfile:getState())
end

local function detachAllBoards() --[[ detachAllBoards | Line: 183 | Upvalues: t2 (copy), updateArrow (copy), ClientPlayerData (copy) ]]
	for v1 in t2 do
		local v2 = t2[v1]

		if v2 then
			t2[v1] = nil
			v2.gui:Destroy()
			updateArrow(ClientPlayerData.serverProfile:getState())
		end
	end
end

local function destroyBoardParts() --[[ destroyBoardParts | Line: 192 | Upvalues: CollectionService (copy), FishingVillage (copy) ]]
	for v1, v2 in CollectionService:GetTagged(FishingVillage.BoardTag) do
		v2:Destroy()
	end
end

local function fadeOutBoards(p1) --[[ fadeOutBoards | Line: 202 | Upvalues: t2 (copy), TweenService (copy), CollectionService (copy), FishingVillage (copy) ]]
	local v1 = TweenInfo.new(p1, Enum.EasingStyle.Quad)

	for v2, v3 in t2 do
		for v4, v5 in v3.gui:GetDescendants() do
			if v5:IsA("GuiObject") then
				TweenService:Create(v5, v1, {
					BackgroundTransparency = 1
				}):Play()
			end

			if v5:IsA("TextLabel") or (v5:IsA("TextButton") or v5:IsA("TextBox")) then
				TweenService:Create(v5, v1, {
					TextTransparency = 1,
					TextStrokeTransparency = 1
				}):Play()
			end

			if v5:IsA("ImageLabel") or v5:IsA("ImageButton") then
				TweenService:Create(v5, v1, {
					ImageTransparency = 1
				}):Play()
			end

			if v5:IsA("UIStroke") then
				TweenService:Create(v5, v1, {
					Transparency = 1
				}):Play()
			end
		end

		TweenService:Create(v2, v1, {
			Transparency = 1
		}):Play()
	end

	for v6, v7 in CollectionService:GetTagged(FishingVillage.BoardTag) do
		if v7:IsA("BasePart") and not t2[v7] then
			TweenService:Create(v7, v1, {
				Transparency = 1
			}):Play()
		end
	end
end

local function findRopesModel() --[[ findRopesModel | Line: 237 | Upvalues: Workspace (copy), FishingVillage (copy) ]]
	local v1 = Workspace:FindFirstChild(FishingVillage.RopesModelName)

	if v1 and v1:IsA("Model") then
		return v1
	end

	return nil
end

local function removeBarrier() --[[ removeBarrier | Line: 244 | Upvalues: Workspace (copy), FishingVillage (copy), CollectionService (copy) ]]
	local v1 = Workspace:FindFirstChild(FishingVillage.RopesModelName)
	local v2 = if v1 and v1:IsA("Model") then v1 else nil

	if v2 then
		v2:Destroy()
	end

	for v3, v4 in CollectionService:GetTagged(FishingVillage.BarrierTag) do
		v4:Destroy()
	end
end

local function refreshAllBoards() --[[ refreshAllBoards | Line: 254 | Upvalues: ClientPlayerData (copy), v1 (ref), t2 (copy), updateArrow (copy), CollectionService (copy), FishingVillage (copy), removeBarrier (copy), refreshBoard (copy) ]]
	local v12 = ClientPlayerData.serverProfile:getState()

	if (if (if v12 then v12.unlockedFishingVillage else v12) == true then true else false) and not v1 then
		for v4 in t2 do
			local v5 = t2[v4]

			if v5 then
				t2[v4] = nil
				v5.gui:Destroy()
				updateArrow(ClientPlayerData.serverProfile:getState())
			end
		end

		for v6, v7 in CollectionService:GetTagged(FishingVillage.BoardTag) do
			v7:Destroy()
		end

		removeBarrier()
	end

	for v8, v9 in t2 do
		refreshBoard(v9, v12)
	end

	updateArrow(v12)
end

local function resolveTourStand() --[[ resolveTourStand | Line: 273 | Upvalues: Workspace (copy), Tour (copy) ]]
	local v1 = Workspace:FindFirstChild(Tour.FolderName)
	local v2 = if v1 then v1:FindFirstChild(Tour.CenterPartName) else v1

	if v2 and v2:IsA("BasePart") then
		return v2
	end

	return nil
end

local t3 = {}
local v3 = false
local v4 = nil

local function checkSkip() --[[ checkSkip | Line: 293 | Upvalues: v3 (ref), t3 (copy) ]]
	if not v3 then
		return
	end

	error(t3)
end

local function rideWait(p1) --[[ rideWait | Line: 301 | Upvalues: v3 (ref), t3 (copy), RunService (copy) ]]
	local v1 = os.clock()

	repeat
		if v3 then
			error(t3)
		end

		RunService.RenderStepped:Wait()
	until p1 <= os.clock() - v1
end

local function tweenCamera(p1, p2, p3, p4) --[[ tweenCamera | Line: 309 | Upvalues: TweenService (copy), v4 (ref), v3 (ref), t3 (copy), RunService (copy) ]]
	local v1 = TweenService:Create(p1, TweenInfo.new(p3, p4, Enum.EasingDirection.InOut), {
		CFrame = p2
	})

	v4 = v1
	v1:Play()

	while v1.PlaybackState == Enum.PlaybackState.Playing do
		if v3 then
			v1:Cancel()
			v4 = nil
			error(t3)
		end

		RunService.RenderStepped:Wait()
	end

	v4 = nil
end

local function playSound(p1, p2, p3) --[[ playSound | Line: 325 | Upvalues: SoundService (copy) ]]
	local Sound = Instance.new("Sound")

	Sound.SoundId = ("rbxassetid://%*"):format(p1)
	Sound.Looped = p2

	if p3 then
		Sound.Volume = p3
	end

	Sound.Parent = SoundService
	Sound:Play()

	return Sound
end

local v5 = nil

local function getFadeFrame() --[[ getFadeFrame | Line: 342 | Upvalues: v5 (ref), Players (copy) ]]
	if v5 and v5.Parent then
		return v5
	end

	local World2UnlockFade = Instance.new("ScreenGui")

	World2UnlockFade.Name = "World2UnlockFade"
	World2UnlockFade.IgnoreGuiInset = true
	World2UnlockFade.ResetOnSpawn = false
	World2UnlockFade.DisplayOrder = 1000

	local Black = Instance.new("Frame")

	Black.Name = "Black"
	Black.BackgroundColor3 = Color3.new(0/255, 0/255, 0/255)
	Black.BackgroundTransparency = 1
	Black.BorderSizePixel = 0
	Black.Size = UDim2.fromScale(1, 1)
	Black.Parent = World2UnlockFade
	World2UnlockFade.Parent = Players.LocalPlayer.PlayerGui
	v5 = Black

	return Black
end

local function fadeTo(p1, p2) --[[ fadeTo | Line: 364 | Upvalues: getFadeFrame (copy), TweenService (copy) ]]
	local v1 = TweenService:Create(getFadeFrame(), TweenInfo.new(p2, Enum.EasingStyle.Quad), {
		BackgroundTransparency = p1
	})

	v1:Play()
	v1.Completed:Wait()
end

local v6 = nil

local function getBanner() --[[ getBanner | Line: 380 | Upvalues: v6 (ref), getFadeFrame (copy) ]]
	if not (v6 and v6.title.Parent) then
		local v1 = getFadeFrame().Parent

		local function makeLabel(p1, p2, p3) --[[ makeLabel | Line: 386 | Upvalues: v1 (copy) ]]
			local TextLabel = Instance.new("TextLabel")

			TextLabel.Name = p1
			TextLabel.AnchorPoint = Vector2.new(0.5, 1)
			TextLabel.Position = p2
			TextLabel.Size = p3
			TextLabel.BackgroundTransparency = 1
			TextLabel.Font = Enum.Font.GothamBlack
			TextLabel.TextColor3 = Color3.new(255/255, 255/255, 255/255)
			TextLabel.TextScaled = true
			TextLabel.TextTransparency = 1

			local UIStroke = Instance.new("UIStroke")

			UIStroke.Color = Color3.new(0/255, 0/255, 0/255)
			UIStroke.Thickness = 3
			UIStroke.Transparency = 1
			UIStroke.Parent = TextLabel
			TextLabel.Parent = v1

			return TextLabel
		end

		v6 = {
			title = makeLabel("ShotTitle", UDim2.fromScale(0.5, 0.86), UDim2.fromScale(0.9, 0.07)),
			sub = makeLabel("ShotSubtitle", UDim2.fromScale(0.5, 0.92), UDim2.fromScale(0.9, 0.045))
		}
	end

	return v6
end

local function tweenCaptionLabel(p1, p2, p3) --[[ tweenCaptionLabel | Line: 414 | Upvalues: TweenService (copy) ]]
	local v1 = TweenInfo.new(p3, Enum.EasingStyle.Quad)

	TweenService:Create(p1, v1, {
		TextTransparency = p2
	}):Play()

	local UIStroke = p1:FindFirstChildOfClass("UIStroke")

	if not UIStroke then
		return
	end

	TweenService:Create(UIStroke, v1, {
		Transparency = p2
	}):Play()
end

local function showShotCaption(p1, p2) --[[ showShotCaption | Line: 423 | Upvalues: getBanner (copy), tweenCaptionLabel (copy), Tour (copy) ]]
	local v1 = getBanner()

	v1.title.Text = p1
	tweenCaptionLabel(v1.title, 0, Tour.LabelFadeTime)
	v1.sub.Text = p2 or ""

	if not p2 then
		return
	end

	tweenCaptionLabel(v1.sub, 0, Tour.LabelFadeTime)
end

local function hideShotCaption() --[[ hideShotCaption | Line: 433 | Upvalues: v6 (ref), tweenCaptionLabel (copy), Tour (copy) ]]
	if v6 then
		tweenCaptionLabel(v6.title, 1, Tour.LabelFadeTime)
		tweenCaptionLabel(v6.sub, 1, Tour.LabelFadeTime)
	end
end

local v7 = nil

local function destroySkipButton() --[[ destroySkipButton | Line: 448 | Upvalues: v7 (ref) ]]
	if not v7 then
		return
	end

	v7:Destroy()
	v7 = nil
end

local function showSkipButton() --[[ showSkipButton | Line: 455 | Upvalues: v7 (ref), ReplicatedStorage (copy), FishingVillage (copy), v3 (ref), getFadeFrame (copy) ]]
	if v7 then
		v7:Destroy()
		v7 = nil
	end

	local v1 = ReplicatedStorage.shared.model:FindFirstChild(FishingVillage.TemplateName)
	local v2 = if v1 then v1:FindFirstChild("UnlockButton", true) else v1

	if not (v2 and v2:IsA("ImageButton")) then
		return
	end

	local SkipButton = v2:Clone()

	SkipButton.Name = "SkipButton"
	SkipButton.AnchorPoint = Vector2.new(1, 1)
	SkipButton.Position = UDim2.new(1, -16, 1, -16)
	SkipButton.Size = UDim2.fromOffset(150, 52)

	local TextLabel = SkipButton:FindFirstChild("TextLabel", true)

	if TextLabel and TextLabel:IsA("TextLabel") then
		TextLabel.Text = "Skip"
	end

	SkipButton.Activated:Connect(function() --[[ Line: 471 | Upvalues: v3 (ref) ]]
		v3 = true
	end)
	SkipButton.Parent = getFadeFrame().Parent
	v7 = SkipButton
end

local function randomUnitVector() --[[ randomUnitVector | Line: 480 ]]
	local v1 = math.random() - 0.5
	local v2 = math.random() - 0.5
	local v4 = Vector3.new(v1, v2, math.random() - 0.5)

	if v4.Magnitude > 0.01 then
		return v4.Unit
	end

	return Vector3.new(0, 1, 0)
end

local function breakRopes() --[[ breakRopes | Line: 489 | Upvalues: Workspace (copy), FishingVillage (copy), UnlockFx (copy), TweenService (copy), removeBarrier (copy) ]]
	local v1 = Workspace:FindFirstChild(FishingVillage.RopesModelName)
	local v2 = if v1 and v1:IsA("Model") then v1 else nil

	if not v2 then
		return
	end

	for v3, v4 in v2:GetDescendants() do
		if v4:IsA("BasePart") then
			v4.CanCollide = false
			v4.CanTouch = false
			v4.CanQuery = false

			local ParticleEmitter = Instance.new("ParticleEmitter")

			ParticleEmitter.Enabled = false
			ParticleEmitter.Texture = "rbxasset://textures/particles/smoke_main.dds"
			ParticleEmitter.Color = ColorSequence.new(v4.Color)
			ParticleEmitter.Lifetime = NumberRange.new(0.5, 1)
			ParticleEmitter.Speed = NumberRange.new(6, 14)
			ParticleEmitter.SpreadAngle = Vector2.new(180, 180)
			ParticleEmitter.Acceleration = Vector3.new(0, -25, 0)
			ParticleEmitter.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.7), NumberSequenceKeypoint.new(1, 0.1) })
			ParticleEmitter.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.2), NumberSequenceKeypoint.new(1, 1) })
			ParticleEmitter.Parent = v4
			ParticleEmitter:Emit(UnlockFx.RopeDebrisPerPiece)

			local v5 = UnlockFx.RopeScatterDistance * (0.6 + math.random() * 0.8)
			local v10 = Vector3.new(math.random() - 0.5, math.random() - 0.5, math.random() - 0.5)
			local v12 = v4.CFrame + (if v10.Magnitude > 0.01 then v10.Unit else Vector3.new(0, 1, 0)) * v5
			local v18 = v12 * CFrame.Angles(math.rad((math.random(-180, 180))), math.rad((math.random(-180, 180))), (math.rad((math.random(-180, 180)))))

			TweenService:Create(v4, TweenInfo.new(UnlockFx.RopeBreakFadeTime, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				CFrame = v18
			}):Play()
			TweenService:Create(v4, TweenInfo.new(UnlockFx.RopeBreakFadeTime, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
				Transparency = 1
			}):Play()
		end
	end

	task.delay(UnlockFx.RopeBreakFadeTime + 0.2, removeBarrier)
end

local v8 = nil

local function getFireworksFolder() --[[ getFireworksFolder | Line: 555 | Upvalues: v8 (ref), Workspace (copy) ]]
	if v8 and v8.Parent then
		return v8
	end

	local World2UnlockFireworks = Instance.new("Folder")

	World2UnlockFireworks.Name = "World2UnlockFireworks"
	World2UnlockFireworks.Parent = Workspace
	v8 = World2UnlockFireworks

	return World2UnlockFireworks
end

local function clearFireworks() --[[ clearFireworks | Line: 566 | Upvalues: v8 (ref) ]]
	if not v8 then
		return
	end

	v8:Destroy()
	v8 = nil
end

local function makeFireworkPart() --[[ makeFireworkPart | Line: 573 | Upvalues: v8 (ref), Workspace (copy) ]]
	local Part = Instance.new("Part")

	Part.Anchored = true
	Part.CanCollide = false
	Part.CanQuery = false
	Part.CanTouch = false

	local v1

	if v8 and v8.Parent then
		v1 = v8
	else
		local World2UnlockFireworks = Instance.new("Folder")

		World2UnlockFireworks.Name = "World2UnlockFireworks"
		World2UnlockFireworks.Parent = Workspace
		v8 = World2UnlockFireworks
		v1 = World2UnlockFireworks
	end

	Part.Parent = v1

	return Part
end

local function playFireworkSound(p1, p2, p3) --[[ playFireworkSound | Line: 583 ]]
	if p2 ~= 0 then
		local Sound = Instance.new("Sound")

		Sound.SoundId = ("rbxassetid://%*"):format(p2)
		Sound.Volume = p3
		Sound.Parent = p1
		Sound:Play()
	end
end

local function burstFirework(p1, p2) --[[ burstFirework | Line: 594 | Upvalues: v8 (ref), Workspace (copy), Fireworks (copy), TweenService (copy) ]]
	local Part = Instance.new("Part")

	Part.Anchored = true
	Part.CanCollide = false
	Part.CanQuery = false
	Part.CanTouch = false

	local v1

	if v8 and v8.Parent then
		v1 = v8
	else
		local World2UnlockFireworks = Instance.new("Folder")

		World2UnlockFireworks.Name = "World2UnlockFireworks"
		World2UnlockFireworks.Parent = Workspace
		v8 = World2UnlockFireworks
		v1 = World2UnlockFireworks
	end

	Part.Parent = v1

	local v2 = Part

	v2.Transparency = 1
	v2.Size = Vector3.new(1, 1, 1)
	v2.Position = p1

	local ParticleEmitter = Instance.new("ParticleEmitter")

	ParticleEmitter.Enabled = false
	ParticleEmitter.Texture = "rbxasset://textures/particles/sparkles_main.dds"
	ParticleEmitter.Color = ColorSequence.new(p2)
	ParticleEmitter.LightEmission = 1
	ParticleEmitter.LightInfluence = 0
	ParticleEmitter.Lifetime = NumberRange.new(0.7, 1.3)
	ParticleEmitter.Speed = NumberRange.new(35, 55)
	ParticleEmitter.SpreadAngle = Vector2.new(180, 180)
	ParticleEmitter.Drag = 4
	ParticleEmitter.Acceleration = Vector3.new(0, -12, 0)
	ParticleEmitter.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1.4), NumberSequenceKeypoint.new(1, 0.15) })
	ParticleEmitter.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.7, 0), NumberSequenceKeypoint.new(1, 1) })
	ParticleEmitter.Parent = v2

	local PointLight = Instance.new("PointLight")

	PointLight.Color = p2
	PointLight.Brightness = 4
	PointLight.Range = 45
	PointLight.Parent = v2
	ParticleEmitter:Emit(140)

	local BurstSoundId = Fireworks.BurstSoundId
	local BurstVolume = Fireworks.BurstVolume

	if BurstSoundId ~= 0 then
		local Sound = Instance.new("Sound")

		Sound.SoundId = ("rbxassetid://%*"):format(BurstSoundId)
		Sound.Volume = BurstVolume
		Sound.Parent = v2
		Sound:Play()
	end

	TweenService:Create(PointLight, TweenInfo.new(0.6, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
		Brightness = 0
	}):Play()
	task.delay(Fireworks.BurstLifetime, function() --[[ Line: 632 | Upvalues: v2 (copy) ]]
		v2:Destroy()
	end)
end

local function launchRocket(p1, p2) --[[ launchRocket | Line: 640 | Upvalues: v8 (ref), Workspace (copy), Fireworks (copy), TweenService (copy), burstFirework (copy) ]]
	local Part = Instance.new("Part")

	Part.Anchored = true
	Part.CanCollide = false
	Part.CanQuery = false
	Part.CanTouch = false

	local v1

	if v8 and v8.Parent then
		v1 = v8
	else
		local World2UnlockFireworks = Instance.new("Folder")

		World2UnlockFireworks.Name = "World2UnlockFireworks"
		World2UnlockFireworks.Parent = Workspace
		v8 = World2UnlockFireworks
		v1 = World2UnlockFireworks
	end

	Part.Parent = v1

	local Rocket = Part

	Rocket.Name = "Rocket"
	Rocket.Material = Enum.Material.Neon
	Rocket.Color = p2
	Rocket.Size = Vector3.new(0.4, 2.5, 0.4)
	Rocket.Position = p1 - Vector3.new(0, 1, 0) * Fireworks.RocketRiseHeight

	local LaunchSoundId = Fireworks.LaunchSoundId
	local BurstVolume = Fireworks.BurstVolume

	if LaunchSoundId ~= 0 then
		local Sound = Instance.new("Sound")

		Sound.SoundId = ("rbxassetid://%*"):format(LaunchSoundId)
		Sound.Volume = BurstVolume
		Sound.Parent = Rocket
		Sound:Play()
	end

	local v2 = TweenService:Create(Rocket, TweenInfo.new(Fireworks.RocketRiseTime, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
		Position = p1
	})

	v2:Play()
	v2.Completed:Once(function(p12) --[[ Line: 655 | Upvalues: Rocket (copy), burstFirework (ref), p1 (copy), p2 (copy) ]]
		Rocket:Destroy()

		if p12 ~= Enum.PlaybackState.Completed then
			return
		end

		burstFirework(p1, p2)
	end)
end

local v9 = false

local function startFireworksShow(p1) --[[ startFireworksShow | Line: 669 | Upvalues: v9 (ref), Fireworks (copy), v3 (ref), launchRocket (copy) ]]
	v9 = true

	local Colors = Fireworks.Colors

	task.spawn(function() --[[ Line: 672 | Upvalues: v9 (ref), v3 (ref), Fireworks (ref), p1 (copy), launchRocket (ref), Colors (copy) ]]
		while v9 and not v3 do
			local v1 = math.random() * 2 * math.pi
			local v32 = math.sqrt((math.random())) * Fireworks.SpreadRadius
			local v4 = Fireworks.HeightMin + math.random() * (Fireworks.HeightMax - Fireworks.HeightMin)

			launchRocket(p1 + Vector3.new(math.cos(v1) * v32, v4, math.sin(v1) * v32), Colors[math.random(#Colors)])
			task.wait(Fireworks.LaunchInterval)
		end
	end)
end

local function stopFireworksShow() --[[ stopFireworksShow | Line: 686 | Upvalues: v9 (ref) ]]
	v9 = false
end

local function spinCFrame(p1, p2) --[[ spinCFrame | Line: 694 | Upvalues: Tour (copy) ]]
	local v1 = CFrame.new(p1.Position)
	local fromEulerAnglesYXZ = CFrame.fromEulerAnglesYXZ

	return v1 * fromEulerAnglesYXZ(-math.rad(Tour.SpinPitch), p2, 0)
end

local function standYaw(p1) --[[ standYaw | Line: 700 ]]
	local v1 = p1.CFrame.LookVector * Vector3.new(1, 0, 1)

	if v1.Magnitude < 0.01 then
		return 0
	end

	local Unit = v1.Unit

	return math.atan2(-Unit.X, -Unit.Z)
end

local function playSpin(p1, p2) --[[ playSpin | Line: 713 | Upvalues: Tour (copy), getBanner (copy), tweenCaptionLabel (copy), v3 (ref), t3 (copy), TweenService (copy), RunService (copy), v6 (ref) ]]
	if Tour.Label and Tour.Label ~= "" then
		local Sublabel = Tour.Sublabel
		local v1 = getBanner()

		v1.title.Text = Tour.Label
		tweenCaptionLabel(v1.title, 0, Tour.LabelFadeTime)
		v1.sub.Text = Sublabel or ""

		if Sublabel then
			tweenCaptionLabel(v1.sub, 0, Tour.LabelFadeTime)
		end
	end

	local v2 = p2.CFrame.LookVector * Vector3.new(1, 0, 1)
	local v32

	if v2.Magnitude < 0.01 then
		v32 = 0
	else
		local Unit = v2.Unit

		v32 = math.atan2(-Unit.X, -Unit.Z)
	end

	local v7 = math.rad(Tour.SpinDegrees)
	local v8 = os.clock()

	while os.clock() - v8 < Tour.SpinTime do
		if v3 then
			error(t3)
		end

		local v10 = v32 + v7 * TweenService:GetValue(math.min((os.clock() - v8) / Tour.SpinTime, 1), Enum.EasingStyle.Sine, Enum.EasingDirection.InOut)
		local v11 = CFrame.new(p2.Position)
		local fromEulerAnglesYXZ = CFrame.fromEulerAnglesYXZ

		p1.CFrame = v11 * fromEulerAnglesYXZ(-math.rad(Tour.SpinPitch), v10, 0)
		RunService.RenderStepped:Wait()
	end

	if not Tour.Label or Tour.Label == "" then
		return
	end

	if not v6 then
		return
	end

	tweenCaptionLabel(v6.title, 1, Tour.LabelFadeTime)
	tweenCaptionLabel(v6.sub, 1, Tour.LabelFadeTime)
end

local function runUnlockCinematic(p1) --[[ runUnlockCinematic | Line: 740 | Upvalues: Workspace (copy), t2 (copy), updateArrow (copy), ClientPlayerData (copy), removeBarrier (copy), Players (copy), ClientMusicController (copy), UnlockFx (copy), SoundService (copy), fadeOutBoards (copy), ReplicatedStorage (copy), v3 (ref), showSkipButton (copy), tweenCamera (copy), t3 (copy), RunService (copy), breakRopes (copy), CollectionService (copy), FishingVillage (copy), rideWait (copy), Tour (copy), fadeTo (copy), v9 (ref), Fireworks (copy), launchRocket (copy), playSpin (copy), v8 (ref), v6 (ref), tweenCaptionLabel (copy), v7 (ref), v4 (ref) ]]
	local CurrentCamera = Workspace.CurrentCamera

	if CurrentCamera then
		local Character = Players.LocalPlayer.Character
		local v1 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character
		local v2 = if v1 then v1.Anchored else false

		if v1 then
			v1.Anchored = true
		end

		local v32 = CurrentCamera.CFrame

		CurrentCamera.CameraType = Enum.CameraType.Scriptable
		ClientMusicController.SetDucked(UnlockFx.MusicDuck)

		if p1 then
			local MoneySoundId = UnlockFx.MoneySoundId
			local MoneySoundVolume = UnlockFx.MoneySoundVolume
			local Sound = Instance.new("Sound")

			Sound.SoundId = ("rbxassetid://%*"):format(MoneySoundId)
			Sound.Looped = false

			if MoneySoundVolume then
				Sound.Volume = MoneySoundVolume
			end

			Sound.Parent = SoundService
			Sound:Play()

			local v42 = Sound

			task.delay(3, function() --[[ Line: 768 | Upvalues: v42 (copy) ]]
				v42:Stop()
				v42:Destroy()
			end)
			task.delay(UnlockFx.BoardFadeDelay, function() --[[ Line: 776 | Upvalues: fadeOutBoards (ref), UnlockFx (ref) ]]
				fadeOutBoards(UnlockFx.BoardFadeTime)
			end)
		end

		local Satchel = require(ReplicatedStorage.client.Satchel)
		local topbarplus = require(ReplicatedStorage.client.Satchel.Package.topbarplus)

		pcall(function() --[[ Line: 788 | Upvalues: Satchel (copy), topbarplus (copy) ]]
			Satchel.SetEnabled(false)
			topbarplus.setTopbarEnabled(false)
		end)
		v3 = false
		showSkipButton()

		local v5 = nil
		local t = {}
		local ok, result = pcall(function() --[[ Line: 801 | Upvalues: p1 (copy), UnlockFx (ref), tweenCamera (ref), CurrentCamera (copy), v5 (ref), SoundService (ref), v3 (ref), t3 (ref), RunService (ref), breakRopes (ref), t2 (ref), updateArrow (ref), ClientPlayerData (ref), CollectionService (ref), FishingVillage (ref), rideWait (ref), Workspace (ref), Tour (ref), fadeTo (ref), t (copy), v9 (ref), Fireworks (ref), launchRocket (ref), playSpin (ref), v32 (copy) ]]
			if p1 then
				local v1 = CFrame.lookAt(p1.Position + p1.CFrame.LookVector * UnlockFx.CameraDistance, p1.Position)

				tweenCamera(CurrentCamera, v1, UnlockFx.CameraTime, Enum.EasingStyle.Quad)

				local Sound = Instance.new("Sound")

				Sound.SoundId = ("rbxassetid://%*"):format(UnlockFx.ChargeSoundId)
				Sound.Looped = true
				Sound.Parent = SoundService
				Sound:Play()
				v5 = Sound

				local v2 = os.clock()
				local v33 = false

				while os.clock() - v2 < UnlockFx.ShakeTime do
					if v3 then
						error(t3)
					end

					local v4 = os.clock() - v2

					if not v33 and UnlockFx.ShakeTime - UnlockFx.FanfareLeadTime <= v4 then
						local Sound2 = Instance.new("Sound")

						Sound2.SoundId = ("rbxassetid://%*"):format(UnlockFx.FanfareSoundId)
						Sound2.Looped = false
						Sound2.Parent = SoundService
						Sound2:Play()

						local v52 = Sound2

						task.delay(UnlockFx.FanfareSoundTime, function() --[[ Line: 820 | Upvalues: v52 (copy) ]]
							v52:Stop()
							v52:Destroy()
						end)
						v33 = true
					end

					local v6 = UnlockFx.ShakeAmplitude * math.min(v4 / 0.5, 1)

					CurrentCamera.CFrame = v1 * CFrame.new(math.noise(v4 * 9, 0) * v6, math.noise(0, v4 * 9) * v6, 0)
					RunService.RenderStepped:Wait()
				end

				Sound:Stop()
				breakRopes()

				local v7 = os.clock()

				while os.clock() - v7 < UnlockFx.BurstTime do
					if v3 then
						error(t3)
					end

					local v8 = 1 - (os.clock() - v7) / UnlockFx.BurstTime
					local v92 = UnlockFx.BurstAmplitude * v8 * v8

					CurrentCamera.CFrame = v1 * CFrame.new((math.random() - 0.5) * 2 * v92, (math.random() - 0.5) * 2 * v92, 0) * CFrame.Angles(0, 0, (math.random() - 0.5) * v92 * 0.04)
					RunService.RenderStepped:Wait()
				end

				CurrentCamera.CFrame = v1

				for v10 in t2 do
					local v11 = t2[v10]

					if v11 then
						t2[v10] = nil
						v11.gui:Destroy()
						updateArrow(ClientPlayerData.serverProfile:getState())
					end
				end

				for v12, v13 in CollectionService:GetTagged(FishingVillage.BoardTag) do
					v13:Destroy()
				end

				rideWait(UnlockFx.AfterBurstHoldTime)
			end

			local v14 = Workspace:FindFirstChild(Tour.FolderName)
			local v15 = v14 and v14:FindFirstChild(Tour.CenterPartName)
			local v16 = if v15 and v15:IsA("BasePart") then v15 else nil

			if not v16 then
				warn((("[FishingVillageBoard] stand \"%*\" missing in Workspace.%* \226\128\148 skipping the fly-by"):format(Tour.CenterPartName, Tour.FolderName)))

				return
			end

			fadeTo(0, UnlockFx.FadeTime)

			local v18 = v16.CFrame.LookVector * Vector3.new(1, 0, 1)
			local v19

			if v18.Magnitude < 0.01 then
				v19 = 0
			else
				local Unit = v18.Unit

				v19 = math.atan2(-Unit.X, -Unit.Z)
			end

			local v23 = CFrame.new(v16.Position)

			CurrentCamera.CFrame = v23 * CFrame.fromEulerAnglesYXZ(-math.rad(Tour.SpinPitch), v19, 0)

			local TourSoundVolume = UnlockFx.TourSoundVolume
			local Sound = Instance.new("Sound")

			Sound.SoundId = ("rbxassetid://%*"):format(UnlockFx.TourSoundId)
			Sound.Looped = true

			if TourSoundVolume then
				Sound.Volume = TourSoundVolume
			end

			Sound.Parent = SoundService
			Sound:Play()
			table.insert(t, Sound)

			local TourMusicVolume = UnlockFx.TourMusicVolume
			local Sound2 = Instance.new("Sound")

			Sound2.SoundId = ("rbxassetid://%*"):format(UnlockFx.TourMusicId)
			Sound2.Looped = true

			if TourMusicVolume then
				Sound2.Volume = TourMusicVolume
			end

			Sound2.Parent = SoundService
			Sound2:Play()
			table.insert(t, Sound2)

			local Position = v16.Position

			v9 = true

			local Colors = Fireworks.Colors

			task.spawn(function() --[[ Line: 672 | Upvalues: v9 (ref), v3 (ref), Fireworks (ref), Position (copy), launchRocket (ref), Colors (copy) ]]
				while v9 and not v3 do
					local v1 = math.random() * 2 * math.pi
					local v32 = math.sqrt((math.random())) * Fireworks.SpreadRadius
					local v4 = Fireworks.HeightMin + math.random() * (Fireworks.HeightMax - Fireworks.HeightMin)

					launchRocket(Position + Vector3.new(math.cos(v1) * v32, v4, math.sin(v1) * v32), Colors[math.random(#Colors)])
					task.wait(Fireworks.LaunchInterval)
				end
			end)
			fadeTo(1, UnlockFx.FadeTime)
			playSpin(CurrentCamera, v16)
			tweenCamera(CurrentCamera, v32, Tour.ReturnTime, Enum.EasingStyle.Quad)
			fadeTo(0, UnlockFx.FadeTime)
		end)

		if v5 then
			v5:Stop()
			v5:Destroy()
		end

		for v62, v72 in t do
			v72:Stop()
			v72:Destroy()
		end

		v9 = false

		if v8 then
			v8:Destroy()
			v8 = nil
		end

		if v6 then
			tweenCaptionLabel(v6.title, 1, Tour.LabelFadeTime)
			tweenCaptionLabel(v6.sub, 1, Tour.LabelFadeTime)
		end

		if v7 then
			v7:Destroy()
			v7 = nil
		end

		if v4 then
			v4:Cancel()
			v4 = nil
		end

		ClientMusicController.SetDucked(1)
		pcall(function() --[[ Line: 903 | Upvalues: Satchel (copy), topbarplus (copy) ]]
			Satchel.SetEnabled(true)
			topbarplus.setTopbarEnabled(true)
		end)
		CurrentCamera.CameraType = Enum.CameraType.Custom

		if v1 and v1.Parent then
			v1.Anchored = v2
		end

		fadeTo(1, UnlockFx.FadeTime)

		if ok or result == t3 then
			return
		end

		warn((("[FishingVillageBoard] unlock cinematic aborted: %*"):format(result)))
	else
		if not p1 then
			return
		end

		for v82 in t2 do
			local v92 = t2[v82]

			if v92 then
				t2[v82] = nil
				v92.gui:Destroy()
				updateArrow(ClientPlayerData.serverProfile:getState())
			end
		end

		removeBarrier()
	end
end

local function missingRequirement(p1) --[[ missingRequirement | Line: 922 | Upvalues: FishingVillage (copy), CashFormat (copy) ]]
	if if (if p1 then p1.unlockedFishingVillage else p1) == true then true else false then
		return nil
	end

	local Unlock = FishingVillage.Unlock

	if not Unlock then
		return nil
	end

	local RebirthLevel = Unlock.RebirthLevel

	if RebirthLevel then
		RebirthLevel = if (p1 and p1.rebirthLevel or 0) < Unlock.RebirthLevel then true else false
	end

	local CashCost = Unlock.CashCost

	if CashCost then
		CashCost = if (if p1 then p1.money or 0 else 0) < Unlock.CashCost then true else false
	end

	if RebirthLevel and CashCost then
		return ("You need Rebirth %* and %*."):format(Unlock.RebirthLevel, (CashFormat.token(Unlock.CashCost)))
	end

	if RebirthLevel then
		return ("You need Rebirth %*."):format(Unlock.RebirthLevel)
	end

	if CashCost then
		return ("You need %*."):format((CashFormat.token(Unlock.CashCost)))
	end

	return nil
end

local function onUnlockClicked(p1) --[[ onUnlockClicked | Line: 942 | Upvalues: v1 (ref), ClientPlayerData (copy), missingRequirement (copy), notifications (copy), Remotes (copy), runUnlockCinematic (copy), refreshAllBoards (copy) ]]
	if v1 then
		return
	end

	local v12 = ClientPlayerData.serverProfile:getState()

	if if (if v12 then v12.unlockedFishingVillage else v12) == true then true else false then
		return
	end

	local v4 = missingRequirement(v12)

	if v4 then
		notifications:Send(v4)
	else
		v1 = true
		task.spawn(function() --[[ Line: 958 | Upvalues: Remotes (ref), notifications (ref), runUnlockCinematic (ref), p1 (copy), v1 (ref), refreshAllBoards (ref) ]]
			local v12, v2 = Remotes.UnlockFishingVillage:Call():Await()

			if v12 and (typeof(v2) == "table" and v2.ok) then
				runUnlockCinematic(p1)
			else
				notifications:Send(if typeof(v2) == "table" then v2.reason or "Could not unlock. Try again." else "Could not unlock. Try again.")
			end

			v1 = false
			refreshAllBoards()
		end)
	end
end

local function attachBoard(p1, p2) --[[ attachBoard | Line: 974 | Upvalues: t2 (copy), ClientPlayerData (copy), FishingVillage (copy), Players (copy), onUnlockClicked (copy), refreshBoard (copy), updateArrow (copy) ]]
	if not p1:IsA("BasePart") or t2[p1] then
		return
	end

	local v1 = ClientPlayerData.serverProfile:getState()

	if if (if v1 then v1.unlockedFishingVillage else v1) == true then true else false then
		p1:Destroy()

		return
	end

	for v4, v5 in p1:GetChildren() do
		if v5:IsA("SurfaceGui") then
			v5.Enabled = false
		end
	end

	local v6 = p2:Clone()

	v6.Name = FishingVillage.TemplateName
	v6.Adornee = p1
	v6.ResetOnSpawn = false
	v6.Parent = Players.LocalPlayer.PlayerGui

	local Panel = v6.Main.Panel
	local t = {
		gui = v6,
		title = Panel.Title,
		rebirthLabel = Panel.Requirements.RebirthReq.Label,
		rebirthFiller = Panel.Requirements.RebirthReq.Bar.Filler,
		rebirthCapacity = Panel.Requirements.RebirthReq.Bar.Capacity,
		moneyLabel = Panel.Requirements.MoneyReq.Label,
		moneyFiller = Panel.Requirements.MoneyReq.Bar.Filler,
		moneyCapacity = Panel.Requirements.MoneyReq.Bar.Capacity,
		buttonLabel = Panel.UnlockButton.Content.TextLabel
	}

	t2[p1] = t
	Panel.UnlockButton.Activated:Connect(function() --[[ Line: 1017 | Upvalues: onUnlockClicked (ref), p1 (copy) ]]
		onUnlockClicked(p1)
	end)

	local v7 = ClientPlayerData.serverProfile:getState()

	refreshBoard(t, v7)
	updateArrow(v7)
end

function t.Init(p1) --[[ Init | Line: 1026 | Upvalues: ReplicatedStorage (copy), FishingVillage (copy), ClientPlayerData (copy), CollectionService (copy), attachBoard (copy), detachBoard (copy), removeBarrier (copy), Workspace (copy), Remotes (copy), v1 (ref), runUnlockCinematic (copy), refreshAllBoards (copy) ]]
	local v12 = ReplicatedStorage.shared.model:WaitForChild(FishingVillage.TemplateName, 10)

	if not v12 then
		warn((("[FishingVillageBoard] missing ReplicatedStorage.shared.model.%* \226\128\148 no board GUI"):format(FishingVillage.TemplateName)))

		return
	end

	repeat
		task.wait()
	until ClientPlayerData.isPlayerDataLoaded

	for v2, v3 in CollectionService:GetTagged(FishingVillage.BoardTag) do
		attachBoard(v3, v12)
	end

	CollectionService:GetInstanceAddedSignal(FishingVillage.BoardTag):Connect(function(p1) --[[ Line: 1040 | Upvalues: attachBoard (ref), v12 (copy) ]]
		attachBoard(p1, v12)
	end)
	CollectionService:GetInstanceRemovedSignal(FishingVillage.BoardTag):Connect(detachBoard)

	local v4 = ClientPlayerData.serverProfile:getState()

	if (if v4 then v4.unlockedFishingVillage else v4) == true then
		removeBarrier()
	end

	Workspace.ChildAdded:Connect(function(p1) --[[ Line: 1052 | Upvalues: FishingVillage (ref), ClientPlayerData (ref) ]]
		if p1.Name ~= FishingVillage.RopesModelName then
			return
		end

		local v1 = ClientPlayerData.serverProfile:getState()

		if not (if (if v1 then v1.unlockedFishingVillage else v1) == true then true else false) then
			return
		end

		task.defer(function() --[[ Line: 1054 | Upvalues: p1 (copy) ]]
			p1:Destroy()
		end)
	end)
	CollectionService:GetInstanceAddedSignal(FishingVillage.BarrierTag):Connect(function(p1) --[[ Line: 1059 | Upvalues: ClientPlayerData (ref) ]]
		local v1 = ClientPlayerData.serverProfile:getState()

		if not (if (if v1 then v1.unlockedFishingVillage else v1) == true then true else false) then
			return
		end

		task.defer(function() --[[ Line: 1061 | Upvalues: p1 (copy) ]]
			p1:Destroy()
		end)
	end)
	Remotes.PlayVillageFlyover:On(function() --[[ Line: 1070 | Upvalues: v1 (ref), runUnlockCinematic (ref), refreshAllBoards (ref) ]]
		if not v1 then
			v1 = true
			task.spawn(function() --[[ Line: 1075 | Upvalues: runUnlockCinematic (ref), v1 (ref), refreshAllBoards (ref) ]]
				runUnlockCinematic(nil)
				v1 = false
				refreshAllBoards()
			end)
		end
	end)
	ClientPlayerData.serverProfile:subscribe(refreshAllBoards)
end

return t