-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Remotes = require(ReplicatedStorage.shared.Remotes)
local SFX = require(ReplicatedStorage.client.SFX)
local TrainToolConfig = require(ReplicatedStorage.shared.config.TrainToolConfig)
local TrainingToolShop = require(ReplicatedStorage.shared.UECS.Components.TrainingToolShop)
local createConfigShop = require(ReplicatedStorage.shared.util.createConfigShop)

return {
	UECS = nil,
	Init = function(p1) --[[ Init | Line: 14 | Upvalues: Players (copy), createConfigShop (copy), TrainingToolShop (copy), TrainToolConfig (copy), Remotes (copy), ClientPlayerData (copy), SFX (copy) ]]
		createConfigShop({
			equippedField = "trainingTool",
			inspectType = "TrainingTool",
			inspectAttribute = "TrainingTool",
			inspectRequiresEnchants = true,
			shop = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI").TrainingToolShop,
			shopComponent = TrainingToolShop,
			config = TrainToolConfig,
			buyRemote = Remotes.BuyTrainingTool,
			equipRemote = Remotes.EquipTrainingTool,
			uecs = p1.UECS
		})
		ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 34 ]]
			return p1.inventory
		end, function(p1, p2) --[[ Line: 36 | Upvalues: SFX (ref) ]]
			if type(p1) ~= "table" then
				return
			end

			local v2 = if p2 then p2 else {}

			for v3, v4 in p1 do
				if v4.Category == "TrainingTool" and not v2[v3] then
					SFX.new(SFX.Sounds.Buy, 0.5)

					return
				end
			end
		end)
	end
}