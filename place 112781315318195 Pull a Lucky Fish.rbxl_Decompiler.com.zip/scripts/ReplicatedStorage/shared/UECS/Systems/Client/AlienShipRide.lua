-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ContentProvider = game:GetService("ContentProvider")
local ContextActionService = game:GetService("ContextActionService")
local Debris = game:GetService("Debris")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local SoundService = game:GetService("SoundService")
local Workspace = game:GetService("Workspace")
local ControlHint = require(ReplicatedStorage.client.ControlHint)
local SFX = require(ReplicatedStorage.client.SFX)
local Satchel = require(ReplicatedStorage.client.Satchel)
local AlienEventConfig = require(ReplicatedStorage.shared.config.AlienEventConfig)
local AlienFlightState = require(ReplicatedStorage.client.AlienFlightState)
local AlienOceanConfig = require(ReplicatedStorage.shared.config.AlienOceanConfig)
local ClientMusicController = require(ReplicatedStorage.shared.UECS.Systems.Client.ClientMusicController)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Remotes = require(ReplicatedStorage.shared.Remotes)
local TutorialGate = require(ReplicatedStorage.client.TutorialGate)
local WeatherEffects = require(ReplicatedStorage.shared.effects.WeatherEffects)
local notifications = require(ReplicatedStorage.shared.module.notifications)
local popInGui = require(ReplicatedStorage.shared.util.popInGui)
local t = {
	UECS = nil
}
local Anims = AlienEventConfig.Ship.Anims
local Ride = AlienEventConfig.Ship.Ride
local Flight = AlienEventConfig.Ship.Flight
local FixedY = AlienEventConfig.Ship.Flight.FixedY
local v1 = 0
local t2 = {
	Priority = 10000,
	FlyHome = Enum.KeyCode.ButtonB
}

local function setOceanSky(p1) --[[ setOceanSky | Line: 99 | Upvalues: WeatherEffects (copy), ReplicatedStorage (copy), Ride (copy) ]]
	if not p1 then
		WeatherEffects.SetSkyOverride(nil)

		return
	end

	local model = ReplicatedStorage.shared:FindFirstChild("model")
	local v1 = if model then model:FindFirstChild("AlienEvent") else model
	local v2 = if v1 then v1:FindFirstChild(Ride.OceanSkyName) else v1

	if v2 then
		WeatherEffects.SetSkyOverride(v2, Ride.OceanLook)
	else
		warn((("[AlienShipRide] shared.model.AlienEvent.%* not found \226\128\148 ocean keeps the lobby sky"):format(Ride.OceanSkyName)))
	end
end

local t3 = {}
local v2 = nil
local v3 = false
local t4 = {}

local function getAnimation(p1) --[[ getAnimation | Line: 173 | Upvalues: t4 (copy) ]]
	local v1 = t4[p1]

	if v1 then
		return v1
	end

	local Animation = Instance.new("Animation")

	Animation.AnimationId = p1
	t4[p1] = Animation

	return Animation
end

local function getCharacterParts() --[[ getCharacterParts | Line: 184 | Upvalues: Players (copy) ]]
	local Character = Players.LocalPlayer.Character

	if not Character then
		return nil, nil
	end

	local Humanoid = Character:FindFirstChildOfClass("Humanoid")
	local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")

	if HumanoidRootPart and HumanoidRootPart:IsA("BasePart") then
		return Humanoid, HumanoidRootPart
	end

	return Humanoid, nil
end

local v4 = nil

local function getControls() --[[ getControls | Line: 200 | Upvalues: v4 (ref), Players (copy) ]]
	if v4 then
		return v4
	end

	local PlayerScripts = Players.LocalPlayer:FindFirstChild("PlayerScripts")

	if not PlayerScripts then
		return nil
	end

	local PlayerModule = PlayerScripts:FindFirstChild("PlayerModule")

	if not (PlayerModule and PlayerModule:IsA("ModuleScript")) then
		return nil
	end

	local ok, result = pcall(function() --[[ Line: 212 | Upvalues: PlayerModule (copy) ]]
		return require(PlayerModule):GetControls()
	end)

	if ok then
		v4 = result

		return result
	end

	warn("[AlienShipRide] PlayerModule controls failed:", result)

	return nil
end

local function setControlsEnabled(p1) --[[ setControlsEnabled | Line: 223 | Upvalues: getControls (copy) ]]
	local v1 = getControls()

	if not v1 then
		return
	end

	if p1 then
		v1:Enable()
	else
		v1:Disable()
	end
end

local t5 = { "Running", "FreeFalling", "Jumping", "Landing", "GettingUp", "Climbing", "Swimming", "Splash" }
local v5 = nil

local function setCharacterSoundsMuted(p1) --[[ setCharacterSoundsMuted | Line: 245 | Upvalues: Players (copy), v5 (ref), t5 (copy) ]]
	local Character = Players.LocalPlayer.Character
	local v1

	if Character then
		Character:FindFirstChildOfClass("Humanoid")

		local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")

		v1 = if HumanoidRootPart and HumanoidRootPart:IsA("BasePart") then HumanoidRootPart else nil
	else
		v1 = nil
	end

	if not v1 then
		return
	end

	if p1 then
		if v5 then
			return
		end

		local t = {}

		for v2, v3 in t5 do
			local v4 = v1:FindFirstChild(v3)

			if v4 and v4:IsA("Sound") then
				t[v3] = v4.Volume
				v4.Volume = 0
			end
		end

		v5 = t
	else
		local v52 = v5

		v5 = nil

		if not v52 then
			return
		end

		for v6, v7 in v52 do
			local v8 = v1:FindFirstChild(v6)

			if v8 and v8:IsA("Sound") then
				v8.Volume = v7
			end
		end
	end
end

local function getFlightMoveVector() --[[ getFlightMoveVector | Line: 282 | Upvalues: getControls (copy), Workspace (copy) ]]
	local v1 = getControls()
	local CurrentCamera = Workspace.CurrentCamera

	if not (v1 and CurrentCamera) then
		return Vector3.new(0, 0, 0)
	end

	local ok, result = pcall(function() --[[ Line: 288 | Upvalues: v1 (copy) ]]
		return v1:GetMoveVector()
	end)

	if not ok or (typeof(result) ~= "Vector3" or result.Magnitude < 0.05) then
		return Vector3.new(0, 0, 0)
	end

	local v2 = CurrentCamera.CFrame:VectorToWorldSpace(result)
	local v3 = Vector3.new(v2.X, 0, v2.Z)

	if v3.Magnitude < 0.01 then
		return Vector3.new(0, 0, 0)
	end

	return v3.Unit * math.min(result.Magnitude, 1)
end

local v6 = nil
local v7 = 0

local function getOverlay() --[[ getOverlay | Line: 348 | Upvalues: v6 (ref), Players (copy), Ride (copy) ]]
	local v1 = v6

	if v1 and v1.gui.Parent then
		return v1
	end

	local AlienShipLoading = Instance.new("ScreenGui")

	AlienShipLoading.Name = "AlienShipLoading"
	AlienShipLoading.ResetOnSpawn = false
	AlienShipLoading.IgnoreGuiInset = true
	AlienShipLoading.DisplayOrder = 100
	AlienShipLoading.Parent = Players.LocalPlayer:WaitForChild("PlayerGui")

	local Cover = Instance.new("Frame")

	Cover.Name = "Cover"
	Cover.Size = UDim2.fromScale(1, 1)
	Cover.BackgroundColor3 = Color3.new(0/255, 0/255, 0/255)
	Cover.BackgroundTransparency = 0
	Cover.BorderSizePixel = 0
	Cover.Visible = false
	Cover.ZIndex = 1
	Cover.Parent = AlienShipLoading

	local Iris = Instance.new("Frame")

	Iris.Name = "Iris"
	Iris.AnchorPoint = Vector2.new(0.5, 0.5)
	Iris.Position = UDim2.fromScale(0.5, 0.5)
	Iris.Size = UDim2.fromOffset(0, 0)
	Iris.BackgroundTransparency = 1
	Iris.BorderSizePixel = 0
	Iris.Visible = false
	Iris.ZIndex = 2
	Iris.Parent = AlienShipLoading

	local UICorner = Instance.new("UICorner")

	UICorner.CornerRadius = UDim.new(1, 0)
	UICorner.Parent = Iris

	local UIStroke = Instance.new("UIStroke")

	UIStroke.Color = Color3.new(0/255, 0/255, 0/255)
	UIStroke.Transparency = 0
	UIStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	UIStroke.StrokeSizingMode = Enum.StrokeSizingMode.FixedSize
	UIStroke.Thickness = 0
	UIStroke.Parent = Iris

	local Text = Instance.new("TextLabel")

	Text.Name = "Text"
	Text.AnchorPoint = Vector2.new(0.5, 0.5)
	Text.Position = UDim2.fromScale(0.5, 0.5)
	Text.Size = UDim2.fromScale(0.9, 0.3)
	Text.BackgroundTransparency = 1
	Text.Font = Enum.Font.GothamBlack
	Text.TextScaled = true
	Text.TextColor3 = Color3.new(255/255, 255/255, 255/255)
	Text.TextTransparency = 1
	Text.Text = Ride.LoadingText
	Text.ZIndex = 3
	Text.Parent = AlienShipLoading

	local UITextSizeConstraint = Instance.new("UITextSizeConstraint")

	UITextSizeConstraint.MaxTextSize = Ride.LoadingTextSize
	UITextSizeConstraint.Parent = Text

	local t = {
		gui = AlienShipLoading,
		cover = Cover,
		iris = Iris,
		stroke = UIStroke,
		label = Text
	}

	v6 = t

	return t
end

local function getOuterRadius(p1) --[[ getOuterRadius | Line: 429 | Upvalues: Workspace (copy) ]]
	local AbsoluteSize = p1.gui.AbsoluteSize
	local CurrentCamera = Workspace.CurrentCamera

	if CurrentCamera then
		local ViewportSize = CurrentCamera.ViewportSize

		AbsoluteSize = Vector2.new(math.max(AbsoluteSize.X, ViewportSize.X), (math.max(AbsoluteSize.Y, ViewportSize.Y)))
	end

	if AbsoluteSize.X <= 0 or AbsoluteSize.Y <= 0 then
		AbsoluteSize = Vector2.new(1280, 720)
	end

	return math.sqrt(AbsoluteSize.X * AbsoluteSize.X + AbsoluteSize.Y * AbsoluteSize.Y) * 0.5 + 32
end

local function applyOverlay(p1, p2) --[[ applyOverlay | Line: 444 | Upvalues: getOuterRadius (copy) ]]
	local v1 = math.clamp(p2, 0, 1)

	p1.label.TextTransparency = 1 - math.clamp((v1 - 0.6) / 0.4, 0, 1)

	if v1 <= 0 then
		p1.cover.Visible = false
		p1.iris.Visible = false

		return
	end

	local v3 = getOuterRadius(p1)
	local v4 = v3 * (1 - (if v1 < 0.5 then v1 * 2 * v1 else 1 - (1 - v1) * 2 * (1 - v1)))

	if v4 <= 8 then
		p1.iris.Visible = false
		p1.cover.Visible = true
	else
		p1.cover.Visible = false
		p1.iris.Size = UDim2.fromOffset(v4 * 2, v4 * 2)
		p1.stroke.Thickness = v3
		p1.iris.Visible = true
	end
end

local v8 = 0

local function fadeOverlay(p1, p2) --[[ fadeOverlay | Line: 484 | Upvalues: getOverlay (copy), v8 (ref), v7 (ref), RunService (copy), applyOverlay (copy) ]]
	local v1 = getOverlay()

	v8 = v8 + 1

	local v2 = v8
	local v3 = math.clamp(p1, 0, 1)
	local v4 = v7

	if p2 > 0 then
		local sum = 0

		while sum < p2 do
			sum = sum + RunService.RenderStepped:Wait()

			if v8 ~= v2 then
				return
			end

			v7 = v4 + (v3 - v4) * math.clamp(sum / p2, 0, 1)
			applyOverlay(v1, v7)
		end
	end

	v7 = v3
	applyOverlay(v1, v3)
end

local v9 = nil
local v10 = 0
local v11 = 0
local v12 = false
local v13 = Vector3.new(0, 0, 0)
local v14 = 0
local identity = CFrame.identity

local function setHullQueryable(p1, p2) --[[ setHullQueryable | Line: 573 ]]
	if p2 then
		for v1, v2 in p1.queryState do
			if v1.Parent then
				v1.CanQuery = v2
			end
		end

		table.clear(p1.queryState)
	else
		table.clear(p1.queryState)

		for v3, v4 in p1.model:GetDescendants() do
			if v4:IsA("BasePart") then
				p1.queryState[v4] = v4.CanQuery
				v4.CanQuery = false
			end
		end
	end
end

local v15 = nil

local function setSeatedZoom(p1, p2) --[[ setSeatedZoom | Line: 608 | Upvalues: Players (copy), v15 (ref), Ride (copy) ]]
	local LocalPlayer = Players.LocalPlayer

	if p2 then
		v15 = v15 or LocalPlayer.CameraMinZoomDistance
		LocalPlayer.CameraMinZoomDistance = math.min(Ride.HullRadius + Ride.SeatedZoomClearance, LocalPlayer.CameraMaxZoomDistance)
	else
		if not v15 then
			return
		end

		LocalPlayer.CameraMinZoomDistance = v15
		v15 = nil
	end
end

local function beginCameraShot(p1) --[[ beginCameraShot | Line: 626 | Upvalues: Workspace (copy), identity (ref), v11 (ref), v10 (ref), v12 (ref), v9 (ref) ]]
	local CurrentCamera = Workspace.CurrentCamera

	if CurrentCamera then
		local v1 = p1.model:GetBoundingBox()

		identity = p1.model:GetPivot():Inverse() * v1

		local v2 = CurrentCamera.CFrame.Position - (p1.model:GetPivot() * identity).Position

		v11 = math.atan2(v2.X, v2.Z)
		v10 = 0
		v12 = false
		v9 = p1
		CurrentCamera.CameraType = Enum.CameraType.Scriptable
	end
end

local function beginDepartureCamera() --[[ beginDepartureCamera | Line: 648 | Upvalues: Workspace (copy), v9 (ref), v13 (ref), v14 (ref), v12 (ref) ]]
	local CurrentCamera = Workspace.CurrentCamera

	if v9 and CurrentCamera then
		v13 = CurrentCamera.CFrame.Position
		v14 = 0
		v12 = true
	end
end

local function frameSeatedCamera(p1) --[[ frameSeatedCamera | Line: 667 | Upvalues: Workspace (copy), Players (copy), Ride (copy) ]]
	local CurrentCamera = Workspace.CurrentCamera

	if CurrentCamera then
		local v1 = p1.model:GetPivot() * p1.seatOffset
		local v3 = math.min(Ride.HullRadius + Ride.SeatedZoomClearance, Players.LocalPlayer.CameraMaxZoomDistance)
		local Position = v1.Position

		CurrentCamera.CFrame = CFrame.lookAt(Position - v1.LookVector * v3 + Vector3.new(0, v3 * Ride.SeatedCameraLift, 0), Position)
	end
end

local function releaseCameraShot() --[[ releaseCameraShot | Line: 682 | Upvalues: v9 (ref), Workspace (copy), Players (copy) ]]
	v9 = nil

	local CurrentCamera = Workspace.CurrentCamera

	if not CurrentCamera then
		return
	end

	local Character = Players.LocalPlayer.Character
	local v1

	if Character then
		local Humanoid = Character:FindFirstChildOfClass("Humanoid")
		local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")
		local _ = HumanoidRootPart and HumanoidRootPart:IsA("BasePart")

		v1 = Humanoid
	else
		v1 = nil
	end

	if v1 then
		CurrentCamera.CameraSubject = v1
	end

	CurrentCamera.CameraType = Enum.CameraType.Custom
end

local function updateCameraShot(p1, p2) --[[ updateCameraShot | Line: 697 | Upvalues: Workspace (copy), v10 (ref), identity (ref), v12 (ref), v14 (ref), Ride (copy), v13 (ref), v11 (ref) ]]
	local CurrentCamera = Workspace.CurrentCamera

	if not CurrentCamera then
		return
	end

	v10 = v10 + p2

	local Position = (p1.model:GetPivot() * identity).Position
	local v1, v2

	if v12 then
		v14 = v14 + p2
		v1 = v13 + Vector3.new(0, Ride.CameraDepartRise * (1 - math.exp(-v14 / math.max(Ride.CameraDepartRiseTime, 0.01))), 0)
		v2 = Ride.CameraDepartSmoothing
	else
		local v7 = v11 + math.rad(Ride.CameraOrbitSpeed) * v10
		local v102 = Position + Vector3.new(math.sin(v7), 0, (math.cos(v7))) * Ride.CameraDistance

		v1 = v102 + Vector3.new(0, Ride.CameraHeight, 0)
		v2 = Ride.CameraSmoothing
	end

	if not ((Position - v1).Magnitude < 0.1) then
		local v112 = 1 - math.exp(-v2 * p2)

		CurrentCamera.CFrame = CurrentCamera.CFrame:Lerp(CFrame.lookAt(v1, Position), v112)
	end
end

local v16 = nil
local v17 = 0
local v18 = Vector3.new(1, 0, 0)

local function applySuckTilt(p1, p2) --[[ applySuckTilt | Line: 756 | Upvalues: AlienFlightState (copy), Ride (copy), v18 (ref), v17 (ref) ]]
	local fightTarget = AlienFlightState.fightTarget
	local v1 = 0

	if fightTarget then
		local v2 = fightTarget - p1.Position
		local v3 = Vector3.new(v2.X, 0, v2.Z)

		if v3.Magnitude > Ride.SuckTiltMinOffset then
			v18 = v3.Unit:Cross(Vector3.new(0, 1, 0))
		end

		if v3.Magnitude > 0.1 then
			local v8 = math.min(math.atan2(v3.Magnitude, (math.max(p1.Position.Y - fightTarget.Y, 1))), (math.rad(Ride.SuckTiltMax)))
			local v9 = if AlienFlightState.fighting then v8 else v8 * Ride.SuckTiltAimScale

			v1 = v9 * math.clamp(v3.Magnitude / Ride.SuckTiltMinOffset, 0, 1)
		end
	end

	v17 = v17 + (v1 - v17) * (1 - math.exp(-Ride.SuckTiltSmoothing * p2))

	if math.abs(v17) < 0.001 then
		return p1
	end

	return CFrame.new(p1.Position) * CFrame.fromAxisAngle(v18, v17) * p1.Rotation
end

local function setShipPose(p1, p2) --[[ setShipPose | Line: 803 ]]
	p1.root.CFrame = p2 * p1.rootOffset
end

local t6 = {}

local function playShipSound(p1, p2) --[[ playShipSound | Line: 827 | Upvalues: SoundService (copy), t6 (copy), Debris (copy) ]]
	local AlienUfoCue = Instance.new("Sound")

	AlienUfoCue.Name = "AlienUfoCue"
	AlienUfoCue.SoundId = p1
	AlienUfoCue.Volume = p2
	AlienUfoCue.Parent = SoundService:FindFirstChild("SFX") or SoundService
	AlienUfoCue:AddTag("SFX")
	AlienUfoCue:Play()
	table.insert(t6, AlienUfoCue)
	AlienUfoCue.Ended:Once(function() --[[ Line: 836 | Upvalues: AlienUfoCue (copy) ]]
		AlienUfoCue:Destroy()
	end)
	Debris:AddItem(AlienUfoCue, 30)
end

local function stopRideSounds() --[[ stopRideSounds | Line: 842 | Upvalues: t6 (copy) ]]
	for v1, v2 in t6 do
		if v2.Parent then
			v2:Stop()
			v2:Destroy()
		end
	end

	table.clear(t6)
end

local function shipCulled(p1) --[[ shipCulled | Line: 860 | Upvalues: v2 (ref), v9 (ref), Workspace (copy), Ride (copy) ]]
	local v1 = false

	if not (v2 or v9) then
		local CurrentCamera = Workspace.CurrentCamera
		local Position = p1.basePivot.Position

		if CurrentCamera and (CurrentCamera.CFrame.Position - Position).Magnitude > Ride.Perf.CullDistance then
			v1 = true
		elseif CurrentCamera then
			local v22 = CurrentCamera:WorldToViewportPoint(Position)
			local ViewportSize = CurrentCamera.ViewportSize
			local CullMargin = Ride.Perf.CullMargin

			v1 = if v22.Z <= 0 or (v22.X < -ViewportSize.X * CullMargin or (v22.X > ViewportSize.X * (1 + CullMargin) or v22.Y < -ViewportSize.Y * CullMargin)) then true else v22.Y > ViewportSize.Y * (1 + CullMargin)
		end
	end

	if v1 ~= p1.culled then
		p1.culled = v1

		local idleTrack = p1.idleTrack

		if idleTrack then
			idleTrack:AdjustSpeed(if v1 then 0 else 1)
		end
	end

	return v1
end

local function startRenderLoop(p1) --[[ startRenderLoop | Line: 894 | Upvalues: RunService (copy), shipCulled (copy), v16 (ref), Workspace (copy), Ride (copy), applySuckTilt (copy), Players (copy), v9 (ref), updateCameraShot (copy) ]]
	if not p1.renderConn then
		p1.renderConn = RunService.RenderStepped:Connect(function(p1) --[[ Line: 898 | Upvalues: p1 (copy), shipCulled (ref), v16 (ref), Workspace (ref), Ride (ref), applySuckTilt (ref), Players (ref), v9 (ref), updateCameraShot (ref) ]]
			if not p1.model.Parent or shipCulled(p1) then
				return
			end

			debug.profilebegin("UECS/AlienShipRide.Render")
			v16(p1, p1)

			local v3 = applySuckTilt(p1.basePivot * CFrame.new(0, math.sin(Workspace:GetServerTimeNow() * 6.283185307179586 / Ride.BobPeriod + p1.bobPhase) * Ride.BobAmplitude, 0), p1)
			local v4 = p1

			v4.root.CFrame = v3 * v4.rootOffset

			if p1.seated then
				local Character = Players.LocalPlayer.Character
				local v5

				if Character then
					Character:FindFirstChildOfClass("Humanoid")

					local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")

					v5 = if HumanoidRootPart and HumanoidRootPart:IsA("BasePart") then HumanoidRootPart else nil
				else
					v5 = nil
				end

				if v5 then
					v5.CFrame = v3 * p1.seatOffset
				end
			end

			if v9 == p1 then
				updateCameraShot(p1, p1)
			end

			debug.profileend()
		end)
	end
end

local function stopRenderLoop(p1) --[[ stopRenderLoop | Line: 933 ]]
	if not p1.renderConn then
		return
	end

	p1.renderConn:Disconnect()
	p1.renderConn = nil
end

local v19 = nil
local v20 = nil

local function getSeatedTrack() --[[ getSeatedTrack | Line: 959 | Upvalues: Players (copy), v19 (ref), v20 (ref), Anims (copy), t4 (copy) ]]
	local Character = Players.LocalPlayer.Character
	local v1

	if Character then
		local Humanoid = Character:FindFirstChildOfClass("Humanoid")
		local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")
		local _ = HumanoidRootPart and HumanoidRootPart:IsA("BasePart")

		v1 = Humanoid
	else
		v1 = nil
	end

	local v2 = if v1 then v1:FindFirstChildOfClass("Animator") else v1

	if not v2 then
		return nil
	end

	if v19 and v20 == v2 then
		return v19
	end

	local PlayerSeated = Anims.PlayerSeated
	local v3 = t4[PlayerSeated]
	local v4

	if v3 then
		v4 = v3
	else
		local Animation = Instance.new("Animation")

		Animation.AnimationId = PlayerSeated
		t4[PlayerSeated] = Animation
		v4 = Animation
	end

	local v5 = v2:LoadAnimation(v4)

	v5.Priority = Enum.AnimationPriority.Action
	v5.Looped = true
	v19 = v5
	v20 = v2

	return v5
end

local function playSeatedPose() --[[ playSeatedPose | Line: 976 | Upvalues: getSeatedTrack (copy) ]]
	local v1 = getSeatedTrack()

	if not v1 then
		return
	end

	v1:Play(0.2)
end

local function stopSeatedPose() --[[ stopSeatedPose | Line: 983 | Upvalues: v19 (ref), Players (copy), Anims (copy) ]]
	local v1 = v19

	if v1 then
		pcall(function() --[[ Line: 989 | Upvalues: v1 (copy) ]]
			v1:Stop(0.2)
		end)
	end

	local Character = Players.LocalPlayer.Character
	local v2

	if Character then
		local Humanoid = Character:FindFirstChildOfClass("Humanoid")
		local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")
		local _ = HumanoidRootPart and HumanoidRootPart:IsA("BasePart")

		v2 = Humanoid
	else
		v2 = nil
	end

	local v3 = if v2 then v2:FindFirstChildOfClass("Animator") else v2

	if not v3 then
		return
	end

	local v4 = string.match(Anims.PlayerSeated, "%d+")

	for v5, v6 in v3:GetPlayingAnimationTracks() do
		local Animation = v6.Animation

		if v6 ~= v1 and (Animation and string.match(Animation.AnimationId, "%d+") == v4) then
			v6:Stop(0.2)
		end
	end
end

local v21 = nil
local v22 = Color3.fromRGB(150, 255, 170)
local v23 = Color3.fromRGB(255, 90, 70)
local v24 = nil
local v25 = nil
local v26 = RaycastParams.new()

v26.FilterType = Enum.RaycastFilterType.Exclude
v26.RespectCanCollide = true

local v27 = nil
local v28 = 0

local function refreshGroundProbeFilter(p1) --[[ refreshGroundProbeFilter | Line: 1083 | Upvalues: v27 (ref), Workspace (copy), AlienOceanConfig (copy), Players (copy), v26 (copy) ]]
	if not (v27 and v27.Parent) then
		v27 = Workspace:FindFirstChild(AlienOceanConfig.Spawn.ClientFishFolderName)
	end

	local t = { p1.model }

	for v1, v2 in Players:GetPlayers() do
		local Character = v2.Character

		if Character then
			table.insert(t, Character)
		end
	end

	if v27 then
		table.insert(t, v27)
	end

	v26.FilterDescendantsInstances = t
end

local function probeGroundY(p1, p2, p3) --[[ probeGroundY | Line: 1108 | Upvalues: Workspace (copy), v26 (copy) ]]
	local v1 = Workspace:Raycast(Vector3.new(p1, p3 + 4, p2), Vector3.new(0, -300, 0), v26)

	if v1 then
		return v1.Position.Y
	end

	return nil
end

local t7 = {
	Vector2.new(0, 0),
	Vector2.new(1, 0),
	Vector2.new(-1, 0),
	Vector2.new(0, 1),
	Vector2.new(0, -1)
}

local function probeHullGroundY(p1, p2, p3) --[[ probeHullGroundY | Line: 1132 | Upvalues: Ride (copy), Flight (copy), t7 (copy), Workspace (copy), v26 (copy) ]]
	local v1 = Ride.HullRadius * Flight.HeightProbeSpread
	local v2 = nil

	for v3, v4 in t7 do
		local v7 = Workspace:Raycast(Vector3.new(p1 + v4.X * v1, p3 + 4, p2 + v4.Y * v1), Vector3.new(0, -300, 0), v26)
		local v8 = if v7 then v7.Position.Y else nil

		if v8 and (not v2 or v2 < v8) then
			v2 = v8
		end
	end

	return v2
end

local t8 = {
	{
		Side = 0,
		Front = 1
	},
	{
		Side = 0.75,
		Front = 0.66
	},
	{
		Side = -0.75,
		Front = 0.66
	}
}

local function clampHullMove(p1, p2) --[[ clampHullMove | Line: 1169 | Upvalues: t8 (copy), Ride (copy), Workspace (copy), Flight (copy), v26 (copy) ]]
	local Magnitude = p2.Magnitude

	if Magnitude < 0.01 then
		return p2, nil
	end

	local v1 = p2 / Magnitude
	local v3 = Vector3.new(-v1.Z, 0, v1.X)
	local v4, v5 = Magnitude, nil

	for v6, v7 in t8 do
		local v8 = Ride.HullRadius * v7.Front
		local v9 = Workspace:Raycast(p1 + v3 * (Ride.HullRadius * v7.Side), v1 * (Magnitude + v8 + Flight.WallSkin), v26)

		if v9 and v8 * 0.5 <= v9.Distance then
			local v11 = math.max(v9.Distance - v8 - Flight.WallSkin, 0)

			if v11 < v4 then
				v5 = v9.Normal
				v4 = v11
			end
		end
	end

	if v5 then
		return v1 * v4, v5
	end

	return p2, nil
end

local v29 = false
local v30 = nil

local function startOceanMusic() --[[ startOceanMusic | Line: 1216 | Upvalues: v30 (ref), ClientMusicController (copy), SFX (copy), Ride (copy) ]]
	v30 = ClientMusicController.PlayEventMusic(SFX.Sounds.AlienOceanMusic, Ride.OceanMusicVolume)
end

local function stopOceanMusic() --[[ stopOceanMusic | Line: 1220 | Upvalues: v30 (ref), ClientMusicController (copy) ]]
	local v1 = v30

	v30 = nil
	ClientMusicController.StopEventMusic(v1)
end

local function setGameHudEnabled(p1) --[[ setGameHudEnabled | Line: 1233 | Upvalues: Satchel (copy) ]]
	pcall(function() --[[ Line: 1234 | Upvalues: Satchel (ref), p1 (copy) ]]
		Satchel.SetEnabled(p1)
	end)
end

local v31 = nil
local v32 = nil

local function destroyFlightHud() --[[ destroyFlightHud | Line: 1270 | Upvalues: v32 (ref), popInGui (copy) ]]
	local v1 = v32

	v32 = nil

	if not v1 then
		return
	end

	if v1.homeConn then
		v1.homeConn:Disconnect()
	end

	if v1.homeHint then
		v1.homeHint:Destroy()
	end

	if v1.template then
		local root = v1.root
		local v2 = v1.fill.Parent

		if v2 and v2:IsA("GuiObject") then
			popInGui(v2, false)
		end

		if root:IsA("GuiObject") then
			task.delay(0.3, function() --[[ Line: 1291 | Upvalues: v32 (ref), root (copy) ]]
				if v32 ~= nil then
					return
				end

				root.Visible = false
			end)
		end
	else
		local root = v1.root
		local FuelBar = root:FindFirstChild("FuelBar")

		if FuelBar and FuelBar:IsA("GuiObject") then
			popInGui(FuelBar, false)
			task.delay(0.3, function() --[[ Line: 1305 | Upvalues: root (copy) ]]
				root:Destroy()
			end)

			return
		end

		root:Destroy()
	end
end

local function buildTemplateFlightHud() --[[ buildTemplateFlightHud | Line: 1317 | Upvalues: Players (copy), popInGui (copy), ControlHint (copy), t2 (copy), v31 (ref), v32 (ref) ]]
	local PlayerGui = Players.LocalPlayer:FindFirstChildOfClass("PlayerGui")
	local v1 = if PlayerGui then PlayerGui:FindFirstChild("MainUI") else PlayerGui
	local v2 = if v1 then v1:FindFirstChild("UfoEvent") else v1

	if not (v2 and v2:IsA("Frame")) then
		return nil
	end

	local FuelBar = v2:FindFirstChild("FuelBar")
	local v3 = if FuelBar then FuelBar:FindFirstChild("Filler") else FuelBar
	local v4 = if FuelBar then FuelBar:FindFirstChild("FishCapacity") else FuelBar
	local FlyHomeButton = v2:FindFirstChild("FlyHomeButton")

	if not (v3 and (v3:IsA("Frame") and (v4 and (v4:IsA("TextLabel") and (FlyHomeButton and FlyHomeButton:IsA("GuiButton")))))) then
		warn("[AlienShipRide] MainUI.UfoEvent is missing FuelBar.Filler/FuelBar.FishCapacity/FlyHomeButton \226\128\148 using the code-built HUD")

		return nil
	end

	v2.Visible = true

	if FuelBar and FuelBar:IsA("GuiObject") then
		popInGui(FuelBar, true)
	end

	FlyHomeButton.Visible = false
	FlyHomeButton.Active = true

	local BeamPower = v2:FindFirstChild("BeamPower", true)
	local t = {
		template = true,
		lastSeconds = -1,
		root = v2,
		fill = v3,
		label = v4,
		homeButton = FlyHomeButton,
		homeHint = ControlHint.new({
			label = "Fly Home",
			anchorTo = FlyHomeButton,
			keyCode = t2.FlyHome
		})
	}

	t.powerLabel = if BeamPower and BeamPower:IsA("TextLabel") then BeamPower else nil
	t.homeConn = FlyHomeButton.Activated:Connect(v31)
	v32 = t

	return t
end

local function buildFlightHud() --[[ buildFlightHud | Line: 1371 | Upvalues: destroyFlightHud (copy), buildTemplateFlightHud (copy), Players (copy), v22 (copy), ControlHint (copy), t2 (copy), v31 (ref), v32 (ref) ]]
	destroyFlightHud()

	local v1 = buildTemplateFlightHud()

	if v1 then
		return v1
	end

	local AlienFlightHud = Instance.new("ScreenGui")

	AlienFlightHud.Name = "AlienFlightHud"
	AlienFlightHud.ResetOnSpawn = false
	AlienFlightHud.DisplayOrder = 50
	AlienFlightHud.Parent = Players.LocalPlayer:WaitForChild("PlayerGui")

	local FuelBar = Instance.new("Frame")

	FuelBar.Name = "FuelBar"
	FuelBar.AnchorPoint = Vector2.new(0.5, 1)
	FuelBar.Position = UDim2.new(0.5, 0, 1, -24)
	FuelBar.Size = UDim2.new(0.4, 0, 0, 26)
	FuelBar.BackgroundColor3 = Color3.new(0/255, 0/255, 0/255)
	FuelBar.BackgroundTransparency = 0.4
	FuelBar.BorderSizePixel = 0
	FuelBar.Parent = AlienFlightHud

	local UISizeConstraint = Instance.new("UISizeConstraint")

	UISizeConstraint.MinSize = Vector2.new(220, 26)
	UISizeConstraint.MaxSize = Vector2.new(380, 26)
	UISizeConstraint.Parent = FuelBar

	local UICorner = Instance.new("UICorner")

	UICorner.CornerRadius = UDim.new(0, 8)
	UICorner.Parent = FuelBar

	local Fill = Instance.new("Frame")

	Fill.Name = "Fill"
	Fill.Size = UDim2.fromScale(1, 1)
	Fill.BackgroundColor3 = v22
	Fill.BorderSizePixel = 0
	Fill.Parent = FuelBar

	local UICorner2 = Instance.new("UICorner")

	UICorner2.CornerRadius = UDim.new(0, 8)
	UICorner2.Parent = Fill

	local Label = Instance.new("TextLabel")

	Label.Name = "Label"
	Label.Size = UDim2.fromScale(1, 1)
	Label.BackgroundTransparency = 1
	Label.Font = Enum.Font.GothamBlack
	Label.TextSize = 16
	Label.TextColor3 = Color3.new(255/255, 255/255, 255/255)
	Label.Text = "FUEL"
	Label.ZIndex = 2
	Label.Parent = FuelBar

	local UIStroke = Instance.new("UIStroke")

	UIStroke.Color = Color3.new(0/255, 0/255, 0/255)
	UIStroke.Thickness = 1.5
	UIStroke.Parent = Label

	local BeamPower = Instance.new("TextLabel")

	BeamPower.Name = "BeamPower"
	BeamPower.AnchorPoint = Vector2.new(0.5, 1)
	BeamPower.Position = UDim2.new(0.5, 0, 1, -54)
	BeamPower.Size = UDim2.fromOffset(220, 20)
	BeamPower.BackgroundTransparency = 1
	BeamPower.Font = Enum.Font.GothamBlack
	BeamPower.TextSize = 16
	BeamPower.TextColor3 = Color3.fromRGB(150, 225, 255)
	BeamPower.Text = ""
	BeamPower.Parent = AlienFlightHud

	local UIStroke2 = Instance.new("UIStroke")

	UIStroke2.Color = Color3.new(0/255, 0/255, 0/255)
	UIStroke2.Thickness = 1.5
	UIStroke2.Parent = BeamPower

	local FlyHome = Instance.new("TextButton")

	FlyHome.Name = "FlyHome"
	FlyHome.AnchorPoint = Vector2.new(0.5, 1)
	FlyHome.Position = UDim2.new(0.5, 0, 1, -64)
	FlyHome.Size = UDim2.fromOffset(190, 48)
	FlyHome.BackgroundColor3 = Color3.fromRGB(60, 170, 90)
	FlyHome.Font = Enum.Font.GothamBlack
	FlyHome.TextSize = 20
	FlyHome.TextColor3 = Color3.new(255/255, 255/255, 255/255)
	FlyHome.Text = "Fly Home"
	FlyHome.Visible = false
	FlyHome.Parent = AlienFlightHud

	local UICorner3 = Instance.new("UICorner")

	UICorner3.CornerRadius = UDim.new(0, 10)
	UICorner3.Parent = FlyHome

	local UIStroke3 = Instance.new("UIStroke")

	UIStroke3.Color = Color3.fromRGB(20, 80, 40)
	UIStroke3.Thickness = 2
	UIStroke3.Parent = FlyHome

	local t = {
		template = false,
		lastSeconds = -1,
		root = AlienFlightHud,
		fill = Fill,
		label = Label,
		homeButton = FlyHome,
		homeHint = ControlHint.new({
			label = "Fly Home",
			anchorTo = FlyHome,
			keyCode = t2.FlyHome
		}),
		powerLabel = BeamPower,
		homeConn = FlyHome.Activated:Connect(v31)
	}

	v32 = t

	return t
end

local function setBeamPowerHud(p1) --[[ setBeamPowerHud | Line: 1490 | Upvalues: v32 (ref) ]]
	local v1 = v32
	local v2 = if v1 then v1.powerLabel else v1

	if not v2 then
		return
	end

	v2.Text = ("Beam Power %*"):format(p1)
end

local function updateFuelHud(p1, p2) --[[ updateFuelHud | Line: 1498 | Upvalues: v32 (ref), v23 (copy), v22 (copy) ]]
	local v1 = v32

	if not v1 then
		return
	end

	local v3 = math.clamp(p1 / math.max(p2, 1), 0, 1)

	v1.fill.Size = UDim2.fromScale(v3, 1)

	local v5 = math.max(math.ceil(p1), 0)

	if v1.template then
		if v5 == v1.lastSeconds then
			return
		end

		v1.lastSeconds = v5
		v1.label.Text = ("%*/%*"):format(v5, (math.max(math.floor(p2), 1)))
	else
		v1.fill.BackgroundColor3 = if v3 <= 0.25 then v23 else v22

		if v5 == v1.lastSeconds then
			return
		end

		v1.lastSeconds = v5
		v1.label.Text = ("FUEL %*s"):format(v5)
	end
end

v31 = function() --[[ flyHome | Line: 1526 | Upvalues: v2 (ref), v25 (ref), v21 (ref) ]]
	local v1 = v2
	local v22 = v25

	if v1 and (v22 and not v22.landing) then
		v22.landing = true
		task.spawn(v21, v1)
	end
end

local function canFlyHome() --[[ canFlyHome | Line: 1544 | Upvalues: AlienFlightState (copy) ]]
	return AlienFlightState.overIsland and (not AlienFlightState.fighting and not AlienFlightState.catchAvailable)
end

local function onFlyHomeAction(p1, p2) --[[ onFlyHomeAction | Line: 1551 | Upvalues: AlienFlightState (copy), v31 (ref) ]]
	if p2 ~= Enum.UserInputState.Begin then
		return Enum.ContextActionResult.Pass
	end

	if not (AlienFlightState.overIsland and (not AlienFlightState.fighting and not AlienFlightState.catchAvailable)) then
		return Enum.ContextActionResult.Sink
	end

	v31()

	return Enum.ContextActionResult.Sink
end

local function restoreFlightScreen() --[[ restoreFlightScreen | Line: 1567 | Upvalues: destroyFlightHud (copy), Satchel (copy) ]]
	destroyFlightHud()

	local v1 = true

	pcall(function() --[[ Line: 1234 | Upvalues: Satchel (ref), v1 (copy) ]]
		Satchel.SetEnabled(v1)
	end)
end

local function stopFlight(p1, p2) --[[ stopFlight | Line: 1577 | Upvalues: v25 (ref), v24 (ref), v30 (ref), ClientMusicController (copy), ContextActionService (copy), destroyFlightHud (copy), Satchel (copy), AlienFlightState (copy), v29 (ref), Remotes (copy) ]]
	local v1 = v25

	v25 = nil
	v24 = nil

	local v2 = v30

	v30 = nil
	ClientMusicController.StopEventMusic(v2)
	pcall(function() --[[ Line: 1585 | Upvalues: ContextActionService (ref) ]]
		ContextActionService:UnbindAction("AlienFlyHome")
	end)

	if p2 ~= false then
		destroyFlightHud()

		local v3 = true

		pcall(function() --[[ Line: 1234 | Upvalues: Satchel (ref), v3 (copy) ]]
			Satchel.SetEnabled(v3)
		end)
	end

	AlienFlightState.shipModel = nil
	AlienFlightState.oceanCenter = nil
	AlienFlightState.inFlight = false
	AlienFlightState.overIsland = false

	if p1 and v29 then
		Remotes.AlienFlightEnd:Fire()
	end

	v29 = false

	if not v1 then
		return
	end

	AlienFlightState.FlightEnded:Fire()
end

local function beginFlight(p1, p2, p3) --[[ beginFlight | Line: 1607 | Upvalues: refreshGroundProbeFilter (copy), Flight (copy), Workspace (copy), v26 (copy), v25 (ref), AlienFlightState (copy), v30 (ref), ClientMusicController (copy), SFX (copy), Ride (copy), buildFlightHud (copy), v32 (ref), popInGui (copy), Satchel (copy), getControls (copy), ContextActionService (copy), onFlyHomeAction (copy), t2 (copy) ]]
	refreshGroundProbeFilter(p1)

	local Position = p3.Position
	local v2 = Workspace:Raycast(Vector3.new(Position.X, Position.Y + 4, Position.Z), Vector3.new(0, -300, 0), v26)
	local v3 = if v2 then v2.Position.Y else nil
	local v4 = if v3 then math.max(Position.Y - v3, 4) else Flight.HoverHeight

	v25 = {
		pausedFor = 0,
		velocity = Vector3.new(0, 0, 0),
		landing = false,
		fuelAtStart = p2.fuelAtStart,
		startedClock = os.clock(),
		flightY = Position.Y,
		hoverHeight = Flight.HoverLift + v4,
		center = Position
	}
	AlienFlightState.shipModel = p1.model
	AlienFlightState.oceanCenter = p3.Position
	AlienFlightState.inFlight = true
	AlienFlightState.overIsland = true
	v30 = ClientMusicController.PlayEventMusic(SFX.Sounds.AlienOceanMusic, Ride.OceanMusicVolume)

	local v7 = buildFlightHud()
	local shipPower = p2.shipPower
	local v8 = v32
	local v9 = v8 and v8.powerLabel

	if v9 then
		v9.Text = ("Beam Power %*"):format(shipPower)
	end

	popInGui(v7.homeButton, AlienFlightState.overIsland and not AlienFlightState.fighting and not AlienFlightState.catchAvailable)

	local v12 = false

	pcall(function() --[[ Line: 1234 | Upvalues: Satchel (ref), v12 (copy) ]]
		Satchel.SetEnabled(v12)
	end)

	local v13 = getControls()

	if v13 then
		v13:Enable()
	end

	pcall(function() --[[ Line: 1655 | Upvalues: ContextActionService (ref), onFlyHomeAction (ref), t2 (ref) ]]
		ContextActionService:UnbindAction("AlienFlyHome")
		ContextActionService:BindActionAtPriority("AlienFlyHome", onFlyHomeAction, false, t2.Priority, t2.FlyHome, Enum.KeyCode.DPadUp)
	end)
	AlienFlightState.FlightStarted:Fire(p1.model)
end

v16 = function(p1, p2) --[[ stepFlight | Line: 1675 | Upvalues: v25 (ref), v2 (ref), getFlightMoveVector (copy), Flight (copy), clampHullMove (copy), v27 (ref), v28 (ref), refreshGroundProbeFilter (copy), probeHullGroundY (copy), v1 (ref), Remotes (copy), AlienFlightState (copy), AlienOceanConfig (copy), v32 (ref), popInGui (copy), updateFuelHud (copy), notifications (copy), v21 (ref) ]]
	local v12 = v25

	if not v12 or (v2 ~= p1 or v12.landing) then
		return
	end

	local v22 = getFlightMoveVector() * Flight.Speed - v12.velocity
	local v3 = Flight.Acceleration * p2

	if v3 < v22.Magnitude then
		v22 = v22.Unit * v3
	end

	v12.velocity = v12.velocity + v22

	local v4 = Vector3.new(v12.velocity.X, 0, v12.velocity.Z) * p2

	if v4.Magnitude > 0.01 then
		local sum, v5 = clampHullMove(p1.basePivot.Position, v4)

		if v5 then
			local v6 = Vector3.new(v5.X, 0, v5.Z)

			if v6.Magnitude > 0.01 then
				local Unit = v6.Unit

				v12.velocity = v12.velocity - Unit * math.min(v12.velocity:Dot(Unit), 0)

				local v8 = v4 - sum
				local v9 = v8 - Unit * v8:Dot(Unit)

				if v9.Magnitude > 0.01 then
					sum = sum + clampHullMove(p1.basePivot.Position + sum, v9)
				end
			end
		end

		v4 = sum
	end

	local v10 = p1.basePivot.Position + v4
	local v13 = Vector3.new(v10.X - v12.center.X, 0, v10.Z - v12.center.Z)

	if v13.Magnitude > Flight.BoundsRadius then
		v13 = v13.Unit * Flight.BoundsRadius
	end

	if not v27 or v28 <= os.clock() then
		v28 = os.clock() + 2
		refreshGroundProbeFilter(p1)
	end

	local v14 = probeHullGroundY(v12.center.X + v13.X, v12.center.Z + v13.Z, v12.flightY)

	if v14 then
		local v15 = v14 + v12.hoverHeight - v12.flightY

		if Flight.HeightSmoothing > 0 then
			v15 = v15 * (1 - math.exp(-Flight.HeightSmoothing * p2))
		end

		local v18 = (if v15 > 0 then Flight.ClimbSpeed else Flight.DescendSpeed) * p2

		v12.flightY = v12.flightY + math.clamp(v15, -v18, v18)
	end

	local v212 = Vector3.new(v12.center.X + v13.X, v12.flightY, v12.center.Z + v13.Z)
	local Rotation = p1.basePivot.Rotation

	if v12.velocity.Magnitude > 2 then
		local v222 = Vector3.new(v12.velocity.X, 0, v12.velocity.Z)

		if v222.Magnitude > 0.01 then
			local Rotation2 = CFrame.lookAt(Vector3.new(0, 0, 0), v222).Rotation

			Rotation = Rotation:Lerp(Rotation2 * CFrame.Angles(0, math.rad(Flight.HeadingYawOffset), 0), 1 - math.exp(-Flight.TurnSmoothing * p2))
		end
	end

	p1.basePivot = CFrame.new(v212) * Rotation

	if v1 <= os.clock() then
		v1 = os.clock() + 0.1
		Remotes.AlienShipPose:Fire(p1.basePivot)
	end

	AlienFlightState.overIsland = if v13.Magnitude <= AlienOceanConfig.Catch.HomeRadius then true else false

	local v282 = v32

	if v282 then
		local v29 = AlienFlightState.overIsland and (not AlienFlightState.fighting and not AlienFlightState.catchAvailable)

		popInGui(v282.homeButton, v29)

		local homeHint = v282.homeHint

		if homeHint and v29 then
			homeHint:Show()
		elseif homeHint then
			homeHint:Hide()
		end
	end

	if AlienFlightState.fighting then
		v12.pausedFor = v12.pausedFor + p2
	end

	local v30 = v12.fuelAtStart - (os.clock() - v12.startedClock - v12.pausedFor)

	updateFuelHud(v30, v12.fuelAtStart)

	if not (v30 <= 0) then
		return
	end

	v12.landing = true
	notifications:Send("Out of fuel! Flying home...")
	task.spawn(v21, p1)
end

local function flattenToYaw(p1) --[[ flattenToYaw | Line: 1810 ]]
	local LookVector = p1.LookVector
	local v1 = Vector3.new(LookVector.X, 0, LookVector.Z)

	if v1.Magnitude < 0.01 then
		return CFrame.new(p1.Position)
	end

	return CFrame.lookAt(p1.Position, p1.Position + v1.Unit)
end

local v33 = nil

local function warmStream(p1) --[[ warmStream | Line: 1832 | Upvalues: v33 (ref), Players (copy) ]]
	local t = {
		done = false,
		position = p1
	}

	v33 = t
	task.spawn(function() --[[ Line: 1835 | Upvalues: Players (ref), p1 (copy), t (copy) ]]
		pcall(function() --[[ Line: 1838 | Upvalues: Players (ref), p1 (ref) ]]
			Players.LocalPlayer:RequestStreamAroundAsync(p1)
		end)
		t.done = true
	end)
end

local function waitForStream(p1, p2) --[[ waitForStream | Line: 1849 | Upvalues: v33 (ref), CollectionService (copy) ]]
	local v1 = os.clock() + 8
	local v2 = v33

	if v2 and (v2.position - p1).Magnitude < 64 then
		while not v2.done and os.clock() < v1 do
			task.wait()
		end
	end

	if not p2 then
		return
	end

	while os.clock() < v1 do
		for v3, v4 in CollectionService:GetTagged(p2) do
			if v4:IsA("BasePart") and (v4.Position - p1).Magnitude < 64 then
				return
			end
		end

		task.wait(0.05)
	end

	warn("[AlienShipRide] the destination didn\'t stream in before the timeout \226\128\148 revealing anyway")
end

local function canBoard() --[[ canBoard | Line: 1880 | Upvalues: v2 (ref), TutorialGate (copy) ]]
	return if v2 == nil then not TutorialGate.active() else false
end

local function setEnterPromptsEnabled(p1) --[[ setEnterPromptsEnabled | Line: 1884 | Upvalues: TutorialGate (copy), t3 (copy) ]]
	local v1 = if p1 then not TutorialGate.active() else p1

	for v2, v3 in t3 do
		if v3.enterPrompt then
			v3.enterPrompt.Enabled = v1
		end
	end
end

local function releasePlayer(p1, p2) --[[ releasePlayer | Line: 1895 | Upvalues: stopRideSounds (copy), stopSeatedPose (copy), WeatherEffects (copy), v9 (ref), Workspace (copy), Players (copy), v15 (ref), v5 (ref), getControls (copy) ]]
	p1.seated = false

	local hoverSound = p1.hoverSound

	if hoverSound then
		hoverSound:Stop()
	end

	stopRideSounds()
	stopSeatedPose()
	WeatherEffects.SetSkyOverride(nil)
	v9 = nil

	local CurrentCamera = Workspace.CurrentCamera

	if CurrentCamera then
		local Character = Players.LocalPlayer.Character
		local v1

		if Character then
			local Humanoid = Character:FindFirstChildOfClass("Humanoid")
			local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")
			local _ = HumanoidRootPart and HumanoidRootPart:IsA("BasePart")

			v1 = Humanoid
		else
			v1 = nil
		end

		if v1 then
			CurrentCamera.CameraSubject = v1
		end

		CurrentCamera.CameraType = Enum.CameraType.Custom
	end

	for v2, v3 in p1.queryState do
		if v2.Parent then
			v2.CanQuery = v3
		end
	end

	table.clear(p1.queryState)

	local LocalPlayer = Players.LocalPlayer

	if v15 then
		LocalPlayer.CameraMinZoomDistance = v15
		v15 = nil
	end

	local Character = Players.LocalPlayer.Character
	local v4, v52

	if Character then
		local Humanoid = Character:FindFirstChildOfClass("Humanoid")
		local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")

		if HumanoidRootPart and HumanoidRootPart:IsA("BasePart") then
			v4 = HumanoidRootPart
			v52 = Humanoid
		else
			v4 = nil
			v52 = Humanoid
		end
	else
		v4 = nil
		v52 = nil
	end

	if v4 then
		v4.Anchored = false

		if p2 then
			v4.CFrame = p2
		end
	end

	if v52 then
		v52.PlatformStand = false
	end

	local Character2 = Players.LocalPlayer.Character
	local v6

	if Character2 then
		Character2:FindFirstChildOfClass("Humanoid")

		local HumanoidRootPart = Character2:FindFirstChild("HumanoidRootPart")

		v6 = if HumanoidRootPart and HumanoidRootPart:IsA("BasePart") then HumanoidRootPart else nil
	else
		v6 = nil
	end

	if v6 then
		local v7 = v5

		v5 = nil

		if v7 then
			for v8, v92 in v7 do
				local v10 = v6:FindFirstChild(v8)

				if v10 and v10:IsA("Sound") then
					v10.Volume = v92
				end
			end
		end
	end

	local v11 = getControls()

	if v11 then
		v11:Enable()
	end
end

v21 = function(p1) --[[ leaveShip | Line: 1934 | Upvalues: v3 (ref), stopFlight (copy), warmStream (copy), fadeOverlay (copy), Ride (copy), v33 (ref), releasePlayer (copy), destroyFlightHud (copy), Satchel (copy), v2 (ref), TutorialGate (copy), t3 (copy) ]]
	if v3 then
		return
	end

	v3 = true
	stopFlight(true, false)

	if p1.leavePrompt then
		p1.leavePrompt.Enabled = false
	end

	warmStream(p1.homePivot.Position)

	local ok, result = pcall(function() --[[ Line: 1954 | Upvalues: fadeOverlay (ref), Ride (ref), p1 (copy), v33 (ref), releasePlayer (ref) ]]
		fadeOverlay(1, Ride.LoadingFadeIn)
		p1.basePivot = p1.homePivot

		local v1 = p1

		v1.root.CFrame = p1.homePivot * v1.rootOffset

		local v2 = os.clock() + 8
		local v3 = v33
		local v4, v5

		if v3 and (v3.position - p1.homePivot.Position).Magnitude < 64 then
			while not v3.done and os.clock() < v2 do
				task.wait()
			end
		end

		v4 = p1.homePivot * p1.exitOffset
		v5 = v4.Position + Vector3.new(0, 3, 0)
		releasePlayer(p1, CFrame.lookAt(v5, v5 + v4.LookVector))
	end)

	if not ok then
		warn("[AlienShipRide] landing sequence failed:", result)
	end

	destroyFlightHud()

	local v1 = true

	pcall(function() --[[ Line: 1234 | Upvalues: Satchel (ref), v1 (copy) ]]
		Satchel.SetEnabled(v1)
	end)
	fadeOverlay(0, Ride.LoadingFadeOut)
	v2 = nil
	v3 = false

	local v22 = not TutorialGate.active()

	for v32, v4 in t3 do
		if v4.enterPrompt then
			v4.enterPrompt.Enabled = v22
		end
	end
end

local function runPhase(p1, p2) --[[ runPhase | Line: 1989 | Upvalues: RunService (copy) ]]
	local v1 = math.max(p1, 0.01)
	local sum = 0

	while sum < v1 do
		sum = sum + RunService.RenderStepped:Wait()
		debug.profilebegin("UECS/AlienShipRide.Phase")
		p2((math.clamp(sum / v1, 0, 1)))
		debug.profileend()
	end

	p2(1)
end

local function takeOff(p1) --[[ takeOff | Line: 2001 | Upvalues: FixedY (copy), Workspace (copy), v9 (ref), v13 (ref), v14 (ref), v12 (ref), playShipSound (copy), SFX (copy), Ride (copy), runPhase (copy), fadeOverlay (copy), getOverlay (copy), v8 (ref), v7 (ref), getOuterRadius (copy), v24 (ref), waitForStream (copy), AlienOceanConfig (copy), setOceanSky (copy), beginFlight (copy), frameSeatedCamera (copy), Players (copy), v3 (ref) ]]
	local basePivot = p1.basePivot
	local v1 = FixedY - basePivot.Position.Y
	local LookVector = basePivot.LookVector
	local CurrentCamera = Workspace.CurrentCamera

	if v9 and CurrentCamera then
		v13 = CurrentCamera.CFrame.Position
		v14 = 0
		v12 = true
	end

	playShipSound(SFX.Sounds.UfoTakeoff, Ride.TakeoffSoundVolume)
	runPhase(Ride.ClimbDuration, function(p12) --[[ Line: 2016 | Upvalues: p1 (copy), basePivot (copy), v1 (copy) ]]
		p1.basePivot = basePivot + Vector3.new(0, v1 * (p12 * p12), 0)
	end)

	local basePivot2 = p1.basePivot

	runPhase(Ride.RecoilDuration, function(p12) --[[ Line: 2022 | Upvalues: p1 (copy), basePivot2 (copy), LookVector (copy), Ride (ref) ]]
		p1.basePivot = basePivot2 - LookVector * (Ride.RecoilDistance * math.sin(p12 * math.pi * 0.5))
	end)

	local basePivot3 = p1.basePivot

	playShipSound(SFX.Sounds.UfoFlyby, Ride.FlybySoundVolume)

	local v2 = task.delay
	local v32 = Ride.DepartDuration - Ride.LoadingFadeIn

	v2(math.max(v32, 0), function() --[[ Line: 2034 | Upvalues: fadeOverlay (ref), Ride (ref) ]]
		fadeOverlay(1, Ride.LoadingFadeIn)
	end)
	runPhase(Ride.DepartDuration, function(p12) --[[ Line: 2037 | Upvalues: p1 (copy), basePivot3 (copy), LookVector (copy), Ride (ref) ]]
		p1.basePivot = basePivot3 + LookVector * (Ride.DepartDistance * (p12 * p12))
	end)

	local v4 = getOverlay()

	v8 = v8 + 1
	v7 = 1
	v4.label.TextTransparency = 0

	local v5 = getOuterRadius(v4)
	local v6 = v5 * 0

	if v6 <= 8 then
		v4.iris.Visible = false
		v4.cover.Visible = true
	else
		v4.cover.Visible = false
		v4.iris.Size = UDim2.fromOffset(v6 * 2, v6 * 2)
		v4.stroke.Thickness = v5
		v4.iris.Visible = true
	end

	local v72 = v24

	v24 = nil

	local v82 = if v72 then v72.oceanStart else nil

	if v72 and v82 then
		local LookVector2 = v82.LookVector
		local v92 = Vector3.new(LookVector2.X, 0, LookVector2.Z)
		local v10 = if v92.Magnitude < 0.01 then CFrame.new(v82.Position) else CFrame.lookAt(v82.Position, v82.Position + v92.Unit)

		p1.basePivot = v10
		p1.root.CFrame = v10 * p1.rootOffset
		waitForStream(v10.Position, AlienOceanConfig.Catch.OceanStartTag)
		setOceanSky(true)
		task.wait(Ride.LoadingHold)
		beginFlight(p1, v72, v10)
	else
		task.wait(Ride.LoadingHold)
	end

	frameSeatedCamera(p1)
	v9 = nil

	local CurrentCamera2 = Workspace.CurrentCamera

	if CurrentCamera2 then
		local Character = Players.LocalPlayer.Character
		local v132

		if Character then
			local Humanoid = Character:FindFirstChildOfClass("Humanoid")
			local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")
			local _ = HumanoidRootPart and HumanoidRootPart:IsA("BasePart")

			v132 = Humanoid
		else
			v132 = nil
		end

		if v132 then
			CurrentCamera2.CameraSubject = v132
		end

		CurrentCamera2.CameraType = Enum.CameraType.Custom
	end

	fadeOverlay(0, Ride.LoadingFadeOut)

	if v72 and v82 or not p1.leavePrompt then
		v3 = false

		return
	end

	p1.leavePrompt.Enabled = true
	v3 = false
end

local function boardShip(p1) --[[ boardShip | Line: 2085 | Upvalues: v2 (ref), v3 (ref), Players (copy), t3 (copy), Remotes (copy), notifications (copy), TutorialGate (copy), v29 (ref), v24 (ref), warmStream (copy), Satchel (copy), stopFlight (copy), setCharacterSoundsMuted (copy), beginCameraShot (copy), setHullQueryable (copy), v15 (ref), Ride (copy), getControls (copy), releasePlayer (copy), RunService (copy), getSeatedTrack (copy), takeOff (copy) ]]
	if v2 or v3 then
		return
	end

	local Character = Players.LocalPlayer.Character
	local v1, v22

	if Character then
		local Humanoid = Character:FindFirstChildOfClass("Humanoid")
		local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")

		if HumanoidRootPart and HumanoidRootPart:IsA("BasePart") then
			v1 = Humanoid
			v22 = HumanoidRootPart
		else
			v1 = Humanoid
			v22 = nil
		end
	else
		v1 = nil
		v22 = nil
	end

	if not v1 or (not v22 or v1.Health <= 0) then
		return
	end

	v2 = p1
	v3 = true

	for v32, v4 in t3 do
		if v4.enterPrompt then
			v4.enterPrompt.Enabled = false
		end
	end

	local v5, v6 = Remotes.AlienFlightStart:Call():Await()

	if v2 == p1 then
		if v5 and (type(v6) == "table" and v6.Ok == true) then
			v29 = true

			local t = {}

			t.fuelAtStart = tonumber(v6.FuelAtStart) or 0
			t.oceanStart = if typeof(v6.OceanStart) == "CFrame" then v6.OceanStart else nil
			t.shipPower = tonumber(v6.ShipPower) or 0
			v24 = t

			local oceanStart = t.oceanStart

			if oceanStart then
				warmStream(oceanStart.Position)
			end

			local v8 = false

			pcall(function() --[[ Line: 1234 | Upvalues: Satchel (ref), v8 (copy) ]]
				Satchel.SetEnabled(v8)
			end)

			local Character2 = Players.LocalPlayer.Character
			local v9, v10

			if Character2 then
				local Humanoid = Character2:FindFirstChildOfClass("Humanoid")
				local HumanoidRootPart = Character2:FindFirstChild("HumanoidRootPart")

				if HumanoidRootPart and HumanoidRootPart:IsA("BasePart") then
					v9 = Humanoid
					v10 = HumanoidRootPart
				else
					v9 = Humanoid
					v10 = nil
				end
			else
				v9 = nil
				v10 = nil
			end

			if v9 and (v10 and not (v9.Health <= 0)) then
				v9:UnequipTools()
				setCharacterSoundsMuted(true)

				local hoverSound = p1.hoverSound

				if hoverSound then
					hoverSound:Play()
				end

				local boardTrack = p1.boardTrack

				if boardTrack then
					boardTrack:Play(0.1)
				end

				beginCameraShot(p1)
				setHullQueryable(p1, false)

				local LocalPlayer = Players.LocalPlayer

				v15 = v15 or LocalPlayer.CameraMinZoomDistance
				LocalPlayer.CameraMinZoomDistance = math.min(Ride.HullRadius + Ride.SeatedZoomClearance, LocalPlayer.CameraMaxZoomDistance)

				local v13 = getControls()

				if v13 then
					v13:Disable()
				end

				v14 = v10
				v152 = v9

				if Ride.BoardingDipLead > 0 then
					task.wait(Ride.BoardingDipLead)

					if v2 ~= p1 then
						return
					end

					if not v14.Parent or v152.Health <= 0 then
						stopFlight(true)
						releasePlayer(p1, nil)
						v2 = nil
						v3 = false

						local v16 = not TutorialGate.active()

						for v17, v18 in t3 do
							if v18.enterPrompt then
								v18.enterPrompt.Enabled = v16
							end
						end

						return
					end
				end

				v152:ChangeState(Enum.HumanoidStateType.Jumping)

				local v19 = v14.CFrame
				local Position = v19.Position
				local v20 = math.max(Ride.HopDuration, 0.01)
				local v21 = math.clamp(Ride.HopSpinFinish, 0.01, 1)
				local sum = 0

				while sum < v20 do
					sum = sum + RunService.RenderStepped:Wait()

					if v14.Parent and not (v152.Health <= 0) then
						local v222 = math.clamp(sum / v20, 0, 1)
						local v23 = 1 - (1 - v222) * (1 - v222)
						local v242 = p1.model:GetPivot() * p1.seatOffset
						local v25 = Position:Lerp(v242.Position, v23)
						local v27 = v25 + Vector3.new(0, math.sin(math.pi * v222) * Ride.HopArcHeight, 0)
						local v28 = math.clamp(v222 / v21, 0, 1)
						local v292 = math.rad(Ride.HopSpinDegrees) * (1 - (1 - v28) * (1 - v28))

						v14.CFrame = CFrame.new(v27) * v19.Rotation:Lerp(v242.Rotation, v23) * CFrame.Angles(v292, 0, 0)
					else
						stopFlight(true)
						releasePlayer(p1, nil)
						v2 = nil
						v3 = false

						local v30 = not TutorialGate.active()

						for v31, v32 in t3 do
							if v32.enterPrompt then
								v32.enterPrompt.Enabled = v30
							end
						end

						return
					end
				end

				v14.Anchored = true
				v152.PlatformStand = true
				p1.seated = true
				v14.CFrame = p1.model:GetPivot() * p1.seatOffset

				local v33 = getSeatedTrack()

				if v33 then
					v33:Play(0.2)
				end

				task.wait(Ride.TakeOffDelay)

				if v2 == p1 then
					takeOff(p1)
				else
					v3 = false
				end
			else
				stopFlight(true)
				v2 = nil
				v3 = false

				local v34 = not TutorialGate.active()

				for v35, v36 in t3 do
					if v36.enterPrompt then
						v36.enterPrompt.Enabled = v34
					end
				end
			end
		else
			if type(v6) == "table" and type(v6.Message) == "string" then
				notifications:Send(v6.Message)
			end

			v2 = nil
			v3 = false

			local v37 = not TutorialGate.active()

			for v38, v39 in t3 do
				if v39.enterPrompt then
					v39.enterPrompt.Enabled = v37
				end
			end
		end
	else
		if not v5 or (type(v6) ~= "table" or v6.Ok ~= true) then
			return
		end

		Remotes.AlienFlightEnd:Fire()
	end
end

local function hideMarker(p1) --[[ hideMarker | Line: 2261 ]]
	p1.Transparency = 1
	p1.CanCollide = false
	p1.CanQuery = false
	p1.CanTouch = false
	p1.CastShadow = false
	p1.Anchored = true
end

local function makePrompt(p1, p2, p3) --[[ makePrompt | Line: 2270 | Upvalues: Ride (copy) ]]
	local v1 = p1:FindFirstChild(p2)

	if not (v1 and v1:IsA("ProximityPrompt")) then
		local ProximityPrompt = Instance.new("ProximityPrompt")

		ProximityPrompt.Parent = p1
		v1 = ProximityPrompt
	end

	v1.Name = p2
	v1.Style = Enum.ProximityPromptStyle.Custom
	v1.ActionText = p3
	v1.ObjectText = "UFO"
	v1.HoldDuration = Ride.PromptHoldDuration
	v1.MaxActivationDistance = Ride.PromptMaxDistance
	v1.RequiresLineOfSight = false
	v1.ClickablePrompt = true

	return v1
end

local function teardownShip(p1) --[[ teardownShip | Line: 2287 | Upvalues: t3 (copy), v2 (ref), stopFlight (copy), releasePlayer (copy), v3 (ref), fadeOverlay (copy), TutorialGate (copy) ]]
	local v1 = t3[p1]

	if not v1 then
		return
	end

	t3[p1] = nil

	if v1.renderConn then
		v1.renderConn:Disconnect()
		v1.renderConn = nil
	end

	if v1.idleTrack then
		v1.idleTrack:Stop()
		v1.idleTrack:Destroy()
		v1.idleTrack = nil
	end

	if v1.boardTrack then
		v1.boardTrack:Stop()
		v1.boardTrack:Destroy()
		v1.boardTrack = nil
	end

	if v2 ~= v1 then
		return
	end

	stopFlight(true)
	releasePlayer(v1, nil)
	v2 = nil
	v3 = false
	task.spawn(fadeOverlay, 0, 0)

	local v22 = not TutorialGate.active()

	for v32, v4 in t3 do
		if v4.enterPrompt then
			v4.enterPrompt.Enabled = v22
		end
	end
end

local function getShipSpawnPart() --[[ getShipSpawnPart | Line: 2319 | Upvalues: CollectionService (copy), Ride (copy), Workspace (copy) ]]
	for v1, v2 in CollectionService:GetTagged(Ride.SpawnTag) do
		if v2:IsA("BasePart") and v2:IsDescendantOf(Workspace) then
			return v2
		end
	end

	return nil
end

local function pivotShipToSpawn(p1, p2) --[[ pivotShipToSpawn | Line: 2330 | Upvalues: Ride (copy) ]]
	local v1, v2 = p1:GetBoundingBox()
	local v3 = p1:GetPivot()
	local LookVector = p2.CFrame.LookVector
	local v6 = Vector3.new(LookVector.X, 0, LookVector.Z)
	local v7 = if v6.Magnitude > 0.01 then CFrame.lookAt(Vector3.new(0, 0, 0), v6.Unit).Rotation else v3.Rotation

	p1:PivotTo(CFrame.new((Vector3.new(p2.Position.X, p2.Position.Y + p2.Size.Y / 2 + Ride.SpawnHeight + (v3.Position.Y - (v1.Position.Y - v2.Y / 2)), p2.Position.Z))) * v7)
end

local function spawnLocalShip() --[[ spawnLocalShip | Line: 2352 | Upvalues: CollectionService (copy), Ride (copy), Workspace (copy), ReplicatedStorage (copy), getShipSpawnPart (copy), pivotShipToSpawn (copy), v2 (ref), t3 (copy) ]]
	for v1, v22 in CollectionService:GetTagged(Ride.Tag) do
		if v22:IsDescendantOf(Workspace) then
			return
		end
	end

	local model = ReplicatedStorage.shared:FindFirstChild("model")
	local v3 = if model then model:FindFirstChild("AlienEvent") else model
	local v4 = if v3 then v3:FindFirstChild(Ride.TemplateName) else v3

	if not (v4 and v4:IsA("Model")) then
		warn((("[AlienShipRide] shared.model.AlienEvent.%* not found \226\128\148 no ship to fly"):format(Ride.TemplateName)))

		return
	end

	local v5 = v4:Clone()
	local v6 = getShipSpawnPart()

	if v6 then
		pivotShipToSpawn(v5, v6)
	else
		local v7 = nil

		v7 = CollectionService:GetInstanceAddedSignal(Ride.SpawnTag):Connect(function(p1) --[[ Line: 2376 | Upvalues: Workspace (ref), v7 (ref), v2 (ref), v5 (copy), pivotShipToSpawn (ref), t3 (ref) ]]
			if not (p1:IsA("BasePart") and p1:IsDescendantOf(Workspace)) then
				return
			end

			v7:Disconnect()

			local v1 = v2

			if not v5.Parent or v1 and v1.model == v5 then
				return
			end

			pivotShipToSpawn(v5, p1)

			local v22 = t3[v5]

			if not v22 then
				return
			end

			v22.basePivot = v5:GetPivot()
		end)
	end

	v5.Parent = Workspace
end

local function setupShip(p1) --[[ setupShip | Line: 2396 | Upvalues: t3 (copy), Ride (copy), SFX (copy), Anims (copy), t4 (copy), RunService (copy), shipCulled (copy), v16 (ref), Workspace (copy), applySuckTilt (copy), Players (copy), v9 (ref), updateCameraShot (copy), makePrompt (copy), v2 (ref), TutorialGate (copy), boardShip (copy), v21 (ref), teardownShip (copy) ]]
	if t3[p1] then
		return
	end

	local RootPart = p1:WaitForChild("RootPart", 30)
	local AnimationController = p1:WaitForChild("AnimationController", 30)
	local v1 = p1:WaitForChild(Ride.SeatMarkerName, 30)

	if not (RootPart and RootPart:IsA("BasePart")) then
		warn((("[AlienShipRide] %* has no RootPart \226\128\148 skipped"):format((p1:GetFullName()))))

		return
	end

	if not AnimationController then
		warn((("[AlienShipRide] %* has no AnimationController \226\128\148 skipped"):format((p1:GetFullName()))))

		return
	end

	if not (v1 and v1:IsA("BasePart")) then
		warn((("[AlienShipRide] %* has no %* marker \226\128\148 skipped"):format(p1:GetFullName(), Ride.SeatMarkerName)))

		return
	end

	local v22 = AnimationController:FindFirstChildOfClass("Animator") or AnimationController:WaitForChild("Animator", 10)

	if v22 and v22:IsA("Animator") then
		local v3 = p1:WaitForChild(Ride.PromptMarkerName, 10)
		local v4 = p1:WaitForChild(Ride.ExitMarkerName, 10)
		local v5 = if v3 and v3:IsA("BasePart") then v3 else RootPart
		local v6 = if v4 and v4:IsA("BasePart") then v4 else RootPart

		if v5 ~= RootPart then
			v5.Transparency = 1
			v5.CanCollide = false
			v5.CanQuery = false
			v5.CanTouch = false
			v5.CastShadow = false
			v5.Anchored = true
		end

		if v6 ~= RootPart then
			v6.Transparency = 1
			v6.CanCollide = false
			v6.CanQuery = false
			v6.CanTouch = false
			v6.CastShadow = false
			v6.Anchored = true
		end

		if not v3 then
			warn((("[AlienShipRide] %* has no %* \226\128\148 prompt falls back to RootPart"):format(p1:GetFullName(), Ride.PromptMarkerName)))
		end

		if not v4 then
			warn((("[AlienShipRide] %* has no %* \226\128\148 exit falls back to the hull centre"):format(p1.Name, Ride.ExitMarkerName)))
		end

		v1.Transparency = 1
		v1.CanCollide = false
		v1.CanQuery = false
		v1.CanTouch = false
		v1.CastShadow = false
		v1.Anchored = true
		RootPart.Anchored = true

		if not p1.PrimaryPart then
			p1.PrimaryPart = RootPart
		end

		for v7, v8 in p1:GetDescendants() do
			if v8:IsA("BasePart") and v8 ~= RootPart then
				v8.Anchored = false

				if #v8:GetJoints() == 0 then
					local WeldConstraint = Instance.new("WeldConstraint")

					WeldConstraint.Part0 = RootPart
					WeldConstraint.Part1 = v8
					WeldConstraint.Parent = RootPart
				end
			end
		end

		for v92, v10 in p1:GetDescendants() do
			if v10:IsA("BasePart") then
				if not Ride.Perf.HullCollisions then
					v10.CanCollide = false
				end

				if not Ride.Perf.HullShadows then
					v10.CastShadow = false
				end
			end
		end

		local v11 = p1:GetPivot()
		local t = {
			idleTrack = nil,
			boardTrack = nil,
			enterPrompt = nil,
			leavePrompt = nil,
			renderConn = nil,
			hoverSound = nil,
			seated = false,
			culled = false,
			model = p1,
			root = RootPart,
			animator = v22,
			seat = v1,
			promptHost = v5,
			exitOffset = v11:Inverse() * v6.CFrame,
			seatOffset = v11:Inverse() * v1.CFrame,
			rootOffset = v11:Inverse() * RootPart.CFrame,
			basePivot = v11,
			homePivot = v11,
			queryState = {},
			bobPhase = math.random() * math.pi * 2
		}

		t3[p1] = t

		local AlienUfoHover = Instance.new("Sound")

		AlienUfoHover.Name = "AlienUfoHover"
		AlienUfoHover.SoundId = SFX.Sounds.UfoHover
		AlienUfoHover.Looped = true
		AlienUfoHover.Volume = Ride.HoverSoundVolume
		AlienUfoHover.RollOffMaxDistance = Ride.HoverSoundRange
		AlienUfoHover.Parent = RootPart
		t.hoverSound = AlienUfoHover

		local ShipIdle = Anims.ShipIdle
		local v12 = t4[ShipIdle]
		local v13

		if v12 then
			v13 = v12
		else
			local Animation = Instance.new("Animation")

			Animation.AnimationId = ShipIdle
			t4[ShipIdle] = Animation
			v13 = Animation
		end

		local v14 = v22:LoadAnimation(v13)

		v14.Priority = Enum.AnimationPriority.Idle
		v14.Looped = true
		v14:Play()
		t.idleTrack = v14

		local ShipBoarding = Anims.ShipBoarding
		local v15 = t4[ShipBoarding]
		local v162

		if v15 then
			v162 = v15
		else
			local Animation = Instance.new("Animation")

			Animation.AnimationId = ShipBoarding
			t4[ShipBoarding] = Animation
			v162 = Animation
		end

		local v17 = v22:LoadAnimation(v162)

		v17.Priority = Enum.AnimationPriority.Action
		v17.Looped = false
		t.boardTrack = v17

		if not t.renderConn then
			t.renderConn = RunService.RenderStepped:Connect(function(p1) --[[ Line: 898 | Upvalues: t (copy), shipCulled (ref), v16 (ref), Workspace (ref), Ride (ref), applySuckTilt (ref), Players (ref), v9 (ref), updateCameraShot (ref) ]]
				if not t.model.Parent or shipCulled(t) then
					return
				end

				debug.profilebegin("UECS/AlienShipRide.Render")
				v16(t, p1)

				local v3 = applySuckTilt(t.basePivot * CFrame.new(0, math.sin(Workspace:GetServerTimeNow() * 6.283185307179586 / Ride.BobPeriod + t.bobPhase) * Ride.BobAmplitude, 0), p1)
				local v4 = t

				v4.root.CFrame = v3 * v4.rootOffset

				if t.seated then
					local Character = Players.LocalPlayer.Character
					local v5

					if Character then
						Character:FindFirstChildOfClass("Humanoid")

						local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")

						v5 = if HumanoidRootPart and HumanoidRootPart:IsA("BasePart") then HumanoidRootPart else nil
					else
						v5 = nil
					end

					if v5 then
						v5.CFrame = v3 * t.seatOffset
					end
				end

				if v9 == t then
					updateCameraShot(t, p1)
				end

				debug.profileend()
			end)
		end

		local v18 = makePrompt(v5, "AlienShipEnter", "Enter")

		v18.Enabled = if v2 == nil then not TutorialGate.active() else false
		v18.Triggered:Connect(function() --[[ Line: 2550 | Upvalues: boardShip (ref), t (copy) ]]
			task.spawn(boardShip, t)
		end)
		t.enterPrompt = v18

		local v20 = makePrompt(v1, "AlienShipLeave", "Leave")

		v20.MaxActivationDistance = 12
		v20.Enabled = false
		v20.Triggered:Connect(function() --[[ Line: 2559 | Upvalues: v21 (ref), t (copy) ]]
			task.spawn(v21, t)
		end)
		t.leavePrompt = v20
		p1.Destroying:Connect(function() --[[ Line: 2564 | Upvalues: teardownShip (ref), p1 (copy) ]]
			teardownShip(p1)
		end)
	else
		warn((("[AlienShipRide] %* AnimationController has no Animator \226\128\148 skipped"):format((p1:GetFullName()))))
	end
end

function t.Init(p1) --[[ Init | Line: 2569 | Upvalues: AlienEventConfig (copy), TutorialGate (copy), v2 (ref), t3 (copy), ContentProvider (copy), Anims (copy), t4 (copy), getSeatedTrack (copy), Players (copy), spawnLocalShip (copy), CollectionService (copy), Ride (copy), Workspace (copy), setupShip (copy), teardownShip (copy), Remotes (copy), v29 (ref), v25 (ref), notifications (copy), v21 (ref), v5 (ref), v19 (ref), v20 (ref), stopFlight (copy), WeatherEffects (copy), stopRideSounds (copy), v3 (ref), getControls (copy), v9 (ref), v15 (ref), fadeOverlay (copy) ]]
	if not AlienEventConfig.Enabled then
		return
	end

	TutorialGate.onChanged(function() --[[ Line: 2580 | Upvalues: v2 (ref), TutorialGate (ref), t3 (ref) ]]
		local v1 = v2 == nil
		local v22 = if v1 then not TutorialGate.active() else v1

		for v3, v4 in t3 do
			if v4.enterPrompt then
				v4.enterPrompt.Enabled = v22
			end
		end
	end)
	task.spawn(function() --[[ Line: 2590 | Upvalues: ContentProvider (ref), Anims (ref), t4 (ref), getSeatedTrack (ref) ]]
		local t = {}
		local ShipIdle = Anims.ShipIdle
		local v2 = t4[ShipIdle]
		local v3

		if v2 then
			v3 = v2
		else
			local Animation = Instance.new("Animation")

			Animation.AnimationId = ShipIdle
			t4[ShipIdle] = Animation
			v3 = Animation
		end

		local ShipBoarding = Anims.ShipBoarding
		local v4 = t4[ShipBoarding]
		local v5

		if v4 then
			v5 = v4
		else
			local Animation = Instance.new("Animation")

			Animation.AnimationId = ShipBoarding
			t4[ShipBoarding] = Animation
			v5 = Animation
		end

		local PlayerSeated = Anims.PlayerSeated
		local v6 = t4[PlayerSeated]
		local v7

		if v6 then
			v7 = v6
		else
			local Animation = Instance.new("Animation")

			Animation.AnimationId = PlayerSeated
			t4[PlayerSeated] = Animation
			v7 = Animation
		end

		t[1] = v3
		t[2] = v5
		t[3] = v7
		ContentProvider:PreloadAsync(t)
		getSeatedTrack()
	end)
	Players.LocalPlayer.CharacterAdded:Connect(function(p1) --[[ Line: 2599 | Upvalues: getSeatedTrack (ref) ]]
		local Humanoid = p1:WaitForChild("Humanoid", 10)

		if not (Humanoid and Humanoid:FindFirstChildOfClass("Animator")) then
			return
		end

		getSeatedTrack()
	end)
	spawnLocalShip()

	for v1, v22 in CollectionService:GetTagged(Ride.Tag) do
		if v22:IsA("Model") and v22:IsDescendantOf(Workspace) then
			task.spawn(setupShip, v22)
		end
	end

	CollectionService:GetInstanceAddedSignal(Ride.Tag):Connect(function(p1) --[[ Line: 2618 | Upvalues: Workspace (ref), setupShip (ref) ]]
		if not (p1:IsA("Model") and p1:IsDescendantOf(Workspace)) then
			return
		end

		task.spawn(setupShip, p1)
	end)
	CollectionService:GetInstanceRemovedSignal(Ride.Tag):Connect(function(p1) --[[ Line: 2623 | Upvalues: teardownShip (ref) ]]
		if not p1:IsA("Model") then
			return
		end

		teardownShip(p1)
	end)
	Remotes.AlienFlightEnd:On(function(p1) --[[ Line: 2631 | Upvalues: v29 (ref), v2 (ref), v25 (ref), notifications (ref), v21 (ref) ]]
		v29 = false

		local v1 = v2

		if not (v1 and v25) then
			return
		end

		if type(p1) == "table" and p1.Reason == "OutOfFuel" then
			notifications:Send("Out of fuel! Flying home...")
		end

		task.spawn(v21, v1)
	end)
	Players.LocalPlayer.CharacterRemoving:Connect(function() --[[ Line: 2644 | Upvalues: v5 (ref), v19 (ref), v20 (ref), v2 (ref), stopFlight (ref), WeatherEffects (ref), stopRideSounds (ref), v3 (ref), getControls (ref), v9 (ref), Workspace (ref), Players (ref), v15 (ref), fadeOverlay (ref), TutorialGate (ref), t3 (ref) ]]
		v5 = nil
		v19 = nil
		v20 = nil

		local v1 = v2

		if not v1 then
			return
		end

		stopFlight(true)
		v1.seated = false
		v1.basePivot = v1.homePivot
		WeatherEffects.SetSkyOverride(nil)

		local hoverSound = v1.hoverSound

		if hoverSound then
			hoverSound:Stop()
		end

		stopRideSounds()

		if v1.leavePrompt then
			v1.leavePrompt.Enabled = false
		end

		v2 = nil
		v3 = false

		local v22 = getControls()

		if v22 then
			v22:Enable()
		end

		v9 = nil

		local CurrentCamera = Workspace.CurrentCamera

		if CurrentCamera then
			local Character = Players.LocalPlayer.Character
			local v32

			if Character then
				local Humanoid = Character:FindFirstChildOfClass("Humanoid")
				local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")
				local _ = HumanoidRootPart and HumanoidRootPart:IsA("BasePart")

				v32 = Humanoid
			else
				v32 = nil
			end

			if v32 then
				CurrentCamera.CameraSubject = v32
			end

			CurrentCamera.CameraType = Enum.CameraType.Custom
		end

		for v4, v52 in v1.queryState do
			if v4.Parent then
				v4.CanQuery = v52
			end
		end

		table.clear(v1.queryState)

		local LocalPlayer = Players.LocalPlayer

		if v15 then
			LocalPlayer.CameraMinZoomDistance = v15
			v15 = nil
		end

		task.spawn(fadeOverlay, 0, 0)

		local v6 = not TutorialGate.active()

		for v7, v8 in t3 do
			if v8.enterPrompt then
				v8.enterPrompt.Enabled = v6
			end
		end
	end)
end

return t