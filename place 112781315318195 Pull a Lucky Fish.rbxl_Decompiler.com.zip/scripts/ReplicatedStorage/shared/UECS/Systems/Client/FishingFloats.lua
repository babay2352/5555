-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ContextActionService = game:GetService("ContextActionService")
local GuiService = game:GetService("GuiService")
local MarketplaceService = game:GetService("MarketplaceService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")
local BeamTo = require(ReplicatedStorage.client.BeamTo)
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local CashDisplay = require(ReplicatedStorage.shared.module.CashDisplay)
local FishRodConfig = require(ReplicatedStorage.shared.config.FishRodConfig)
local FishingFloats = require(ReplicatedStorage.shared.UECS.Components.FishingFloats)
local FishingFloatsConfig = require(ReplicatedStorage.shared.config.FishingFloatsConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local RebirthUnlocksConfig = require(ReplicatedStorage.shared.config.RebirthUnlocksConfig)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local SFX = require(ReplicatedStorage.client.SFX)
local bindToButtonPress = require(ReplicatedStorage.shared.util.bindToButtonPress)
local notifications = require(ReplicatedStorage.shared.module.notifications)
local Click = SFX.Sounds.Click
local Pop = SFX.Sounds.Pop

local function animateEquipPop(p1) --[[ animateEquipPop | Line: 28 | Upvalues: TweenService (copy) ]]
	local UIScale = p1:FindFirstChildOfClass("UIScale")

	if not UIScale then
		UIScale = Instance.new("UIScale")
		UIScale.Parent = p1
	end

	UIScale.Scale = 0
	p1.Rotation = -15

	local v1 = TweenService:Create(UIScale, TweenInfo.new(0.3, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
		Scale = 1.3
	})

	TweenService:Create(p1, TweenInfo.new(0.3, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
		Rotation = 8
	}):Play()
	v1:Play()
	v1.Completed:Once(function() --[[ Line: 46 | Upvalues: TweenService (ref), UIScale (ref), p1 (copy) ]]
		TweenService:Create(UIScale, TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			Scale = 1
		}):Play()
		TweenService:Create(p1, TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			Rotation = 0
		}):Play()
	end)
end

local function animateUnequipPop(p1, p2) --[[ animateUnequipPop | Line: 57 | Upvalues: TweenService (copy) ]]
	local UIScale = p1:FindFirstChildOfClass("UIScale")

	if not UIScale then
		local UIScale2 = Instance.new("UIScale")

		UIScale2.Parent = p1
		UIScale = UIScale2
	end

	UIScale.Scale = 1

	local v1 = TweenService:Create(UIScale, TweenInfo.new(0.2, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
		Scale = 0
	})

	v1:Play()
	v1.Completed:Once(function() --[[ Line: 67 | Upvalues: p2 (copy) ]]
		if not p2 then
			return
		end

		p2()
	end)
end

local t = {
	UECS = nil
}

function t.Init(p1) --[[ Init | Line: 82 | Upvalues: Players (copy), FishingFloats (copy), bindToButtonPress (copy), UserInputService (copy), GuiService (copy), ContextActionService (copy), ClientPlayerData (copy), RebirthUnlocksConfig (copy), notifications (copy), BeamTo (copy), t (copy), TweenService (copy) ]]
	local MainUI = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI")

	p1.FishingFloatsUI = MainUI:WaitForChild("FishingFloats")
	p1.premiumPrompt = MainUI:WaitForChild("BuyPremiumSlotPrompt")
	p1.premiumPrompt.Visible = false
	p1.pendingPremiumSlot = nil
	p1.FishingFloatsUI.Visible = false

	local v1 = FishingFloats.Add(p1.FishingFloatsUI)

	p1._floatsComponent = v1
	v1.Visible.OnChange:Connect(function(p12, p2) --[[ Line: 93 | Upvalues: p1 (copy), MainUI (copy), bindToButtonPress (ref), UserInputService (ref), GuiService (ref), ContextActionService (ref) ]]
		p1.FishingFloatsUI.Visible = p12

		local HUD = MainUI:FindFirstChild("HUD")

		if HUD then
			HUD.Visible = not p12
		end

		if p12 then
			p1:DismissAlert()
		else
			p1.premiumPrompt.Visible = false
			p1.pendingPremiumSlot = nil
		end

		if p12 == p2 then
			return
		end

		if p12 then
			bindToButtonPress("FloatsCloseAction", Enum.KeyCode.ButtonB, function() --[[ Line: 111 | Upvalues: p1 (ref) ]]
				p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
			end)

			if UserInputService.PreferredInput == Enum.PreferredInput.Gamepad then
				GuiService:Select(p1.FishingFloatsUI)
			end
		else
			ContextActionService:UnbindAction("FloatsCloseAction")
			GuiService.SelectedObject = nil
		end
	end)
	GuiService:GetPropertyChangedSignal("SelectedObject"):Connect(function() --[[ Line: 125 | Upvalues: UserInputService (ref), GuiService (ref), v1 (copy), p1 (copy) ]]
		if UserInputService.PreferredInput ~= Enum.PreferredInput.Gamepad then
			return
		end

		local SelectedObject = GuiService.SelectedObject

		if not v1.Visible:Get() or SelectedObject and SelectedObject:IsDescendantOf(p1.FishingFloatsUI) then
			return
		end

		GuiService:Select(p1.FishingFloatsUI)
	end)

	local v2 = p1.FishingFloatsUI:FindFirstChild("TopBar") and p1.FishingFloatsUI.TopBar:FindFirstChild("CloseButton")

	if v2 then
		v2.MouseButton1Down:Connect(function() --[[ Line: 140 | Upvalues: p1 (copy) ]]
			p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
		end)
	end

	p1:SetupPremiumPrompt()

	if not ClientPlayerData.isPlayerDataLoaded then
		ClientPlayerData.playerDataLoadedSignal:Wait()
	end

	p1.inventoryFrame = p1.FishingFloatsUI.Content.ScrollingFrame
	p1.slotsFrame = p1.FishingFloatsUI.Content.SlotsBackground.Slots
	p1.inventoryTemplate = p1.inventoryFrame.Template:Clone()
	p1.inventoryFrame.Template:Destroy()

	local v3 = RebirthUnlocksConfig.getByFeature("HookShop")
	local v4 = if v3 then v3.RebirthRequired else 2
	local v5 = if v3 then v3.LockedText else ("Reach rebirth lvl %* to unlock the Hook Shop"):format(v4)

	p1.refreshNavigateLock = nil
	p1.noFloatsDisplay = p1.FishingFloatsUI.Content:FindFirstChild("NoFloatsDisplay")

	if p1.noFloatsDisplay then
		p1.noFloatsDisplay.Visible = false

		local v6 = p1.noFloatsDisplay:FindFirstChild("NavigateButton") or p1.noFloatsDisplay:FindFirstChildWhichIsA("ImageButton")

		if v6 then
			local noFloatsDisplay = p1.noFloatsDisplay
			local v7 = nil

			function p1.refreshNavigateLock() --[[ Line: 176 | Upvalues: ClientPlayerData (ref), v4 (copy), v7 (ref), noFloatsDisplay (copy), v6 (copy) ]]
				local v1 = (ClientPlayerData.serverProfile:getState().rebirthLevel or 0) < v4

				if v1 and (not v7 and noFloatsDisplay) then
					local RebirthLockLabel = Instance.new("TextLabel")

					RebirthLockLabel.Name = "RebirthLockLabel"
					RebirthLockLabel.BackgroundTransparency = 1
					RebirthLockLabel.AnchorPoint = v6.AnchorPoint
					RebirthLockLabel.Position = v6.Position
					RebirthLockLabel.Size = v6.Size
					RebirthLockLabel.Font = Enum.Font.GothamBlack
					RebirthLockLabel.TextScaled = true
					RebirthLockLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
					RebirthLockLabel.Text = ("Reach rebirth lvl %* to unlock"):format(v4)

					local UIStroke = Instance.new("UIStroke")

					UIStroke.Color = Color3.fromRGB(0, 0, 0)
					UIStroke.Thickness = 2
					UIStroke.Parent = RebirthLockLabel
					RebirthLockLabel.Parent = noFloatsDisplay
					v7 = RebirthLockLabel
				end

				v6.Visible = not v1

				if not v7 then
					return
				end

				v7.Visible = v1
			end

			local v8 = false

			v6.MouseButton1Down:Connect(function() --[[ Line: 206 | Upvalues: ClientPlayerData (ref), v4 (copy), notifications (ref), v5 (copy), v8 (ref), p1 (copy), BeamTo (ref), Players (ref) ]]
				if (ClientPlayerData.serverProfile:getState().rebirthLevel or 0) < v4 then
					notifications:Send(v5)

					return
				end

				if v8 then
					return
				end

				v8 = true
				p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)

				local SplawikShop = workspace:FindFirstChild("SplawikShop")

				if not SplawikShop then
					v8 = false

					return
				end

				local v1 = nil

				if SplawikShop:IsA("BasePart") then
					v1 = SplawikShop
				elseif SplawikShop:IsA("Model") then
					v1 = SplawikShop.PrimaryPart or SplawikShop:FindFirstChildWhichIsA("BasePart")
				end

				if v1 then
					task.spawn(BeamTo, v1)
					task.spawn(function() --[[ Line: 231 | Upvalues: Players (ref), v1 (ref), BeamTo (ref), v8 (ref) ]]
						task.wait(2)

						while true do
							local Character = Players.LocalPlayer.Character
							local v12 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character

							if v12 and (v12.Position - v1.Position).Magnitude < 10 then
								break
							end

							task.wait(0.5)
						end

						task.spawn(BeamTo, nil)
						v8 = false
					end)
				else
					v8 = false
				end
			end)
		end
	end

	p1:SetupSlotButtons()
	p1:RefreshInventory()
	p1:RefreshSlots()
	p1:RefreshEquippedRod()

	if p1.refreshNavigateLock then
		p1.refreshNavigateLock()
	end

	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 263 ]]
		return p1.fishingFloats
	end, function() --[[ Line: 265 | Upvalues: p1 (copy) ]]
		p1:RefreshInventory()
	end)
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 268 ]]
		return p1.equippedFloats
	end, function() --[[ Line: 270 | Upvalues: p1 (copy) ]]
		p1:RefreshSlots()
	end)
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 273 ]]
		return p1.boughtSlots
	end, function() --[[ Line: 275 | Upvalues: p1 (copy) ]]
		p1:RefreshSlots()
	end)
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 278 ]]
		return p1.rebirthLevel
	end, function() --[[ Line: 280 | Upvalues: p1 (copy) ]]
		p1:RefreshSlots()

		if not p1.refreshNavigateLock then
			return
		end

		p1.refreshNavigateLock()
	end)
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 286 ]]
		return p1.fishRod
	end, function() --[[ Line: 288 | Upvalues: p1 (copy) ]]
		p1:RefreshEquippedRod()
	end)

	local FishingFloat = MainUI:WaitForChild("HUD").Buttons:FindFirstChild("FishingFloat")
	local v9 = FishingFloat and FishingFloat:FindFirstChild("Alert")
	local v10 = v9 and v9:FindFirstChild("TextLabel")
	local v11 = nil

	local function countTotalFloats() --[[ countTotalFloats | Line: 303 | Upvalues: ClientPlayerData (ref) ]]
		local v1 = ClientPlayerData.serverProfile:getState()
		local sum = 0
		local v2 = pairs

		for v4, v5 in v2(v1.fishingFloats or {}) do
			for v6, v7 in v5 do
				sum = sum + v7
			end
		end

		return sum
	end

	local v12 = countTotalFloats()

	if v9 then
		v9.Visible = false
	end

	function t.DismissAlert(p1) --[[ DismissAlert | Line: 321 | Upvalues: v9 (copy), v11 (ref) ]]
		if not v9 then
			return
		end

		if v11 then
			v11:Cancel()
			v11 = nil
		end

		v9.Rotation = 0
		v9.Visible = false
	end

	local function showAlert() --[[ showAlert | Line: 333 | Upvalues: v9 (copy), v10 (copy), v11 (ref), TweenService (ref) ]]
		if not v9 then
			return
		end

		if v10 then
			v10.Text = "!"
		end

		if not v9.Visible then
			v9.Visible = true
			v9.Rotation = -8
			v11 = TweenService:Create(v9, TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true), {
				Rotation = 8
			})
			v11:Play()
		end
	end

	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 355 ]]
		return p1.fishingFloats
	end, function() --[[ Line: 357 | Upvalues: countTotalFloats (copy), v12 (ref), p1 (copy), showAlert (copy) ]]
		local v1 = countTotalFloats()

		if v12 < v1 and not p1.FishingFloatsUI.Visible then
			showAlert()
		end

		v12 = v1
	end)
end
function t.SetupPremiumPrompt(p1) --[[ SetupPremiumPrompt | Line: 366 | Upvalues: GuiService (copy), bindToButtonPress (copy), FishingFloatsConfig (copy), MarketplaceService (copy), Players (copy), ClientPlayerData (copy), notifications (copy), Remotes (copy), SFX (copy), ContextActionService (copy) ]]
	local v1 = p1.premiumPrompt.Content
	local v2 = p1.premiumPrompt:FindFirstChild("TopBar") and p1.premiumPrompt.TopBar:FindFirstChild("CloseButton")
	local BuyWithRobux = v1:FindFirstChild("BuyWithRobux")
	local BuyWithGems = v1:FindFirstChild("BuyWithGems")
	local BuyWithCash = v1:FindFirstChild("BuyWithCash")

	if v2 then
		v2.MouseButton1Down:Connect(function() --[[ Line: 376 | Upvalues: p1 (copy) ]]
			p1.premiumPrompt.Visible = false
			p1.FishingFloatsUI.Visible = true
			p1.pendingPremiumSlot = nil
		end)
	end

	p1.premiumPrompt:GetPropertyChangedSignal("Visible"):Connect(function() --[[ Line: 383 | Upvalues: p1 (copy), GuiService (ref), bindToButtonPress (ref), BuyWithRobux (copy), FishingFloatsConfig (ref), MarketplaceService (ref), Players (ref), BuyWithGems (copy), ClientPlayerData (ref), notifications (ref), Remotes (ref), SFX (ref), BuyWithCash (copy), ContextActionService (ref) ]]
		if p1.premiumPrompt.Visible then
			GuiService.SelectedObject = nil
			bindToButtonPress("FloatsPremiumCloseAction", Enum.KeyCode.ButtonB, function() --[[ Line: 386 | Upvalues: p1 (ref), GuiService (ref) ]]
				p1.premiumPrompt.Visible = false
				p1.FishingFloatsUI.Visible = true
				GuiService:Select(p1.FishingFloatsUI)
				p1.pendingPremiumSlot = nil
			end, 15000)
			bindToButtonPress("FloatsRobuxCurrencyAction", Enum.KeyCode.ButtonY, function() --[[ Line: 393 | Upvalues: BuyWithRobux (ref), p1 (ref), FishingFloatsConfig (ref), MarketplaceService (ref), Players (ref), GuiService (ref) ]]
				if not (BuyWithRobux and BuyWithRobux.Visible) then
					return
				end

				local pendingPremiumSlot = p1.pendingPremiumSlot

				if not pendingPremiumSlot then
					return
				end

				local v1 = FishingFloatsConfig.FloatSlots[pendingPremiumSlot]

				if v1 and v1.RobuxProductId then
					MarketplaceService:PromptProductPurchase(Players.LocalPlayer, v1.RobuxProductId)
				end

				p1.premiumPrompt.Visible = false
				p1.FishingFloatsUI.Visible = true
				GuiService:Select(p1.FishingFloatsUI)
				p1.pendingPremiumSlot = nil
			end, 15000)
			bindToButtonPress("FloatsPremiumCurrencyAction", Enum.KeyCode.ButtonX, function() --[[ Line: 410 | Upvalues: BuyWithGems (ref), p1 (ref), FishingFloatsConfig (ref), ClientPlayerData (ref), notifications (ref), Remotes (ref), SFX (ref), GuiService (ref), BuyWithCash (ref) ]]
				if BuyWithGems and BuyWithGems.Visible then
					local pendingPremiumSlot = p1.pendingPremiumSlot

					if not pendingPremiumSlot then
						return
					end

					local v1 = FishingFloatsConfig.FloatSlots[pendingPremiumSlot]
					local v2 = if v1 then v1.GemPrice or 0 else 0

					if ClientPlayerData.serverProfile.getState().gems < v2 then
						notifications:Send("Not enough gems!")
					else
						Remotes.BuyFishingSlotWithGems:Fire(pendingPremiumSlot)
						SFX.new(SFX.Sounds.Buy, 0.5)
						p1.premiumPrompt.Visible = false
						p1.FishingFloatsUI.Visible = true
						GuiService:Select(p1.FishingFloatsUI)
						p1.pendingPremiumSlot = nil
					end
				else
					if not (BuyWithCash and BuyWithCash.Visible) then
						return
					end

					local pendingPremiumSlot = p1.pendingPremiumSlot

					if not pendingPremiumSlot then
						return
					end

					local v3 = FishingFloatsConfig.FloatSlots[pendingPremiumSlot]

					if v3 and ClientPlayerData.serverProfile.getState().money < v3.Price then
						notifications:Send("Not enough money!")

						return
					end

					Remotes.BuyFishingSlot:Fire(pendingPremiumSlot)
					SFX.new(SFX.Sounds.Buy, 0.5)
					p1.premiumPrompt.Visible = false
					p1.FishingFloatsUI.Visible = true
					GuiService:Select(p1.FishingFloatsUI)
					p1.pendingPremiumSlot = nil
				end
			end, 15000)
		else
			ContextActionService:UnbindAction("FloatsRobuxCurrencyAction")
			ContextActionService:UnbindAction("FloatsPremiumCloseAction")
			ContextActionService:UnbindAction("FloatsPremiumCurrencyAction")
		end
	end)

	if BuyWithGems then
		BuyWithGems.MouseButton1Down:Connect(function() --[[ Line: 460 | Upvalues: p1 (copy), FishingFloatsConfig (ref), ClientPlayerData (ref), notifications (ref), Remotes (ref), SFX (ref) ]]
			local pendingPremiumSlot = p1.pendingPremiumSlot

			if not pendingPremiumSlot then
				return
			end

			local v1 = FishingFloatsConfig.FloatSlots[pendingPremiumSlot]
			local v2 = if v1 then v1.GemPrice or 0 else 0

			if ClientPlayerData.serverProfile.getState().gems < v2 then
				notifications:Send("Not enough gems!")
			else
				Remotes.BuyFishingSlotWithGems:Fire(pendingPremiumSlot)
				SFX.new(SFX.Sounds.Buy, 0.5)
				p1.premiumPrompt.Visible = false
				p1.FishingFloatsUI.Visible = true
				p1.pendingPremiumSlot = nil
			end
		end)
	end

	if BuyWithRobux then
		BuyWithRobux.MouseButton1Down:Connect(function() --[[ Line: 483 | Upvalues: p1 (copy), FishingFloatsConfig (ref), MarketplaceService (ref), Players (ref) ]]
			local pendingPremiumSlot = p1.pendingPremiumSlot

			if not pendingPremiumSlot then
				return
			end

			local v1 = FishingFloatsConfig.FloatSlots[pendingPremiumSlot]

			if not (v1 and v1.RobuxProductId) then
				p1.premiumPrompt.Visible = false
				p1.FishingFloatsUI.Visible = true
				p1.pendingPremiumSlot = nil

				return
			end

			MarketplaceService:PromptProductPurchase(Players.LocalPlayer, v1.RobuxProductId)
			p1.premiumPrompt.Visible = false
			p1.FishingFloatsUI.Visible = true
			p1.pendingPremiumSlot = nil
		end)
	end

	if not BuyWithCash then
		return
	end

	BuyWithCash.MouseButton1Down:Connect(function() --[[ Line: 501 | Upvalues: p1 (copy), FishingFloatsConfig (ref), ClientPlayerData (ref), notifications (ref), Remotes (ref), SFX (ref) ]]
		local pendingPremiumSlot = p1.pendingPremiumSlot

		if not pendingPremiumSlot then
			return
		end

		local v1 = FishingFloatsConfig.FloatSlots[pendingPremiumSlot]

		if v1 and ClientPlayerData.serverProfile.getState().money < v1.Price then
			notifications:Send("Not enough money!")
		else
			Remotes.BuyFishingSlot:Fire(pendingPremiumSlot)
			SFX.new(SFX.Sounds.Buy, 0.5)
			p1.premiumPrompt.Visible = false
			p1.FishingFloatsUI.Visible = true
			p1.pendingPremiumSlot = nil
		end
	end)
end

local function areRequirementsMet(p1) --[[ areRequirementsMet | Line: 522 | Upvalues: FishingFloatsConfig (copy), ClientPlayerData (copy) ]]
	local v1 = FishingFloatsConfig.FloatSlots[p1]

	if not v1 then
		return false
	end

	if v1.Premium then
		return true
	end

	return ClientPlayerData.serverProfile:getState().rebirthLevel >= v1.RebirthRequired
end

function t.SetupSlotButtons(p1) --[[ SetupSlotButtons | Line: 537 | Upvalues: ClientPlayerData (copy), animateUnequipPop (copy), SFX (copy), Pop (copy), Remotes (copy), UserInputService (copy), GuiService (copy), FishingFloatsConfig (copy) ]]
	for v1, v2 in p1.slotsFrame:GetChildren() do
		if v2:HasTag("FishingFloatSlot") then
			local v4 = tonumber(v2.Name)

			if v4 then
				local ImageButton = v2:FindFirstChild("ImageButton")

				if ImageButton then
					ImageButton.MouseButton1Up:Connect(function() --[[ Line: 550 | Upvalues: ClientPlayerData (ref), v4 (copy), p1 (copy), ImageButton (copy), animateUnequipPop (ref), SFX (ref), Pop (ref), Remotes (ref), UserInputService (ref), GuiService (ref), FishingFloatsConfig (ref) ]]
						local v1 = ClientPlayerData.serverProfile.getState()

						if table.find(v1.boughtSlots, v4) then
							if v1.equippedFloats[tostring(v4)] then
								p1._pendingUnequipSlot = v4

								local ImageLabel = ImageButton:FindFirstChild("ImageLabel")

								if ImageLabel then
									animateUnequipPop(ImageLabel)
								end

								local v3 = SFX.new(Pop, 0.4)

								if v3 then
									v3.PlaybackSpeed = 0.85
								end

								Remotes.UnequipFishingFloat:Fire(v4)
							else
								if UserInputService.PreferredInput ~= Enum.PreferredInput.Gamepad then
									return
								end

								GuiService:Select(p1.inventoryFrame)
							end
						else
							local v42 = FishingFloatsConfig.FloatSlots[v4]

							if not v42 then
								return
							end

							if not v42.Premium then
								local v6 = FishingFloatsConfig.FloatSlots[v4]

								if not (if v6 then if v6.Premium then true else ClientPlayerData.serverProfile:getState().rebirthLevel >= v6.RebirthRequired else false) then
									return
								end
							end

							p1:ShowBuyPrompt(v4)
						end
					end)
				end
			end
		end
	end
end
function t.RefreshEquippedRod(p1) --[[ RefreshEquippedRod | Line: 587 | Upvalues: ClientPlayerData (copy), FishRodConfig (copy) ]]
	local fishRod = ClientPlayerData.serverProfile.getState().fishRod
	local v1 = FishRodConfig[fishRod]

	if v1 then
		local ImageButton = p1.slotsFrame.FishingRodSlot.ImageButton

		ImageButton.Image = v1.Icon
		ImageButton:SetAttribute("InspectType", "FishingRod")
		ImageButton:SetAttribute("FishRod", fishRod)
	end
end
function t.ShowBuyPrompt(p1, p2) --[[ ShowBuyPrompt | Line: 601 | Upvalues: FishingFloatsConfig (copy), MarketplaceService (copy), CashDisplay (copy) ]]
	local v1 = FishingFloatsConfig.FloatSlots[p2]

	if not v1 then
		return
	end

	p1.pendingPremiumSlot = p2

	local v2 = v1.Premium or false
	local v3 = p1.premiumPrompt.Content
	local BuyWithGems = v3:FindFirstChild("BuyWithGems")
	local BuyWithRobux = v3:FindFirstChild("BuyWithRobux")
	local BuyWithCash = v3:FindFirstChild("BuyWithCash")

	if BuyWithGems then
		BuyWithGems.Visible = v2
	end

	if BuyWithRobux then
		BuyWithRobux.Visible = v2
	end

	if BuyWithCash then
		BuyWithCash.Visible = not v2
	end

	if v2 and BuyWithGems then
		local Price = BuyWithGems.Content.Frame:FindFirstChild("Price")

		if Price then
			Price.Text = tostring(v1.GemPrice or 1000)
		end
	end

	if v2 and BuyWithRobux then
		local TextLabel = BuyWithRobux.Content:FindFirstChild("TextLabel")

		if TextLabel and v1.RobuxProductId then
			local ok, result = pcall(MarketplaceService.GetProductInfo, MarketplaceService, v1.RobuxProductId, Enum.InfoType.Product)

			if ok and result then
				TextLabel.Text = "R$ " .. tostring(result.PriceInRobux or "?")
			else
				TextLabel.Text = "R$ ?"
			end
		end
	end

	if v2 or not BuyWithCash then
		p1.FishingFloatsUI.Visible = false
		p1.premiumPrompt.Visible = true

		return
	end

	local TextLabel = BuyWithCash.Content:FindFirstChild("TextLabel")

	if not TextLabel then
		p1.FishingFloatsUI.Visible = false
		p1.premiumPrompt.Visible = true

		return
	end

	CashDisplay.applyToLabel(TextLabel, v1.Price, {
		Compact = true
	})
	p1.FishingFloatsUI.Visible = false
	p1.premiumPrompt.Visible = true
end
function t.RefreshSlots(p1) --[[ RefreshSlots | Line: 656 | Upvalues: ClientPlayerData (copy), FishingFloatsConfig (copy), animateEquipPop (copy), CollectionService (copy) ]]
	local v1 = ClientPlayerData.serverProfile.getState()

	for v7, v8 in p1.slotsFrame:GetChildren() do
		local v2, v3, v4, v5, v6

		if v8:HasTag("FishingFloatSlot") then
			local v10 = tonumber(v8.Name)

			if v10 then
				local ImageButton = v8.ImageButton
				local v11 = FishingFloatsConfig.FloatSlots[v10]
				local v12 = if table.find(v1.boughtSlots, v10) == nil then false else true

				v3 = v8
				v2 = v11 and v11.Premium or false

				local v13 = FishingFloatsConfig.FloatSlots[v10]
				local v14 = if v13 then if v13.Premium then true elseif ClientPlayerData.serverProfile:getState().rebirthLevel >= v13.RebirthRequired then true else false else false

				if v11 and not v2 then
					ImageButton.RebirthLabel.Text = ("Rebirth %*"):format(v11.RebirthRequired)
				elseif v2 then
					ImageButton.RebirthLabel.Text = "Premium"
				end

				ImageButton.Lock.Visible = if v12 then false else true
				v4 = not (v12 or (v14 or v2))
				ImageButton.RebirthLabel.Visible = v4

				if v2 then
					ImageButton.LockedGradient.Enabled = false
					ImageButton.BuyGradient.Enabled = if v12 then false else true
					ImageButton.TextLabel.Text = if v12 then "" else "Unlock"
					ImageButton.RebirthLabel.Visible = if v12 then false else true
				else
					v5 = not (v12 or v14)
					ImageButton.LockedGradient.Enabled = v5
					v6 = not v12 and v14
					ImageButton.BuyGradient.Enabled = v6
					ImageButton.TextLabel.Text = if v12 then "" elseif v14 then "Buy" else "Locked"
				end

				local v20 = v1.equippedFloats[tostring(v10)]
				local ImageLabel = ImageButton:FindFirstChild("ImageLabel")

				if v20 then
					local v21 = FishingFloatsConfig.Floats[v20.name]
					local v22 = if v21 then v21.TierImages and v21.TierImages[v20.tier] else v21

					if ImageLabel then
						ImageLabel.Image = v22 or ""

						if p1._pendingEquipSlot == v10 then
							p1._pendingEquipSlot = nil
							animateEquipPop(ImageLabel)
						end
					else
						ImageButton.Image = v22 or ""
					end

					ImageButton:SetAttribute("InspectType", "FishingFloat")
					ImageButton:SetAttribute("FloatName", v20.name)
					ImageButton:SetAttribute("FloatTier", v20.tier)
					CollectionService:AddTag(ImageButton, "Inspect")

					local v23 = FishingFloatsConfig.TierColors[v20.tier]
					local Frame = v8:FindFirstChild("Frame")

					if Frame and v23 then
						local UIGradient = Frame:FindFirstChildOfClass("UIGradient")

						if UIGradient then
							UIGradient.Color = ColorSequence.new(v23, Color3.fromRGB(255, 255, 255))
						end

						Frame.BackgroundColor3 = v23
						Frame.Visible = true
					end

					continue
				end

				if ImageLabel then
					ImageLabel.Image = ""

					local UIScale = ImageLabel:FindFirstChildOfClass("UIScale")

					if UIScale then
						UIScale.Scale = 1
					end

					ImageLabel.Rotation = 0
				else
					ImageButton.Image = ""
				end

				ImageButton:SetAttribute("InspectType", nil)
				ImageButton:SetAttribute("FloatName", nil)
				ImageButton:SetAttribute("FloatTier", nil)
				CollectionService:RemoveTag(ImageButton, "Inspect")

				local Frame = v8:FindFirstChild("Frame")

				if Frame then
					Frame.Visible = false
				end
			end
		end
	end
end
function t.RefreshInventory(p1) --[[ RefreshInventory | Line: 757 | Upvalues: ClientPlayerData (copy), FishingFloatsConfig (copy), notifications (copy), SFX (copy), Click (copy), Remotes (copy) ]]
	for v1, v2 in p1.inventoryFrame:GetChildren() do
		if v2:HasTag("FloatInventoryItem") then
			v2:Destroy()
		end
	end

	local v3 = p1.inventoryTemplate:Clone()
	local v4 = ClientPlayerData.serverProfile:getState()
	local t = {}

	for v5, v6 in FishingFloatsConfig.TierOrder do
		t[v6] = v5
	end

	local t2 = {}

	for k, v in pairs(v4.fishingFloats) do
		for v7, v8 in v do
			table.insert(t2, {
				tier = k,
				name = v7,
				amount = v8
			})
		end
	end

	table.sort(t2, function(p1, p2) --[[ Line: 779 | Upvalues: t (copy) ]]
		local v1 = t[p1.tier] or 0
		local v2 = t[p2.tier] or 0

		if v1 == v2 then
			return p1.name < p2.name
		end

		return v2 < v1
	end)

	local v9 = p1.inventoryFrame:FindFirstChildWhichIsA("UIGridStyleLayout")

	if v9 then
		v9.SortOrder = Enum.SortOrder.LayoutOrder
	end

	for v10, v11 in t2 do
		local tier = v11.tier
		local name = v11.name
		local v12 = v3:Clone()

		v12.LayoutOrder = v10
		v12:AddTag("FloatInventoryItem")
		v12.Visible = true
		v12.Parent = p1.inventoryFrame
		v12.Name = name
		v12.Amount.Text = "x" .. v11.amount
		v12:SetAttribute("FloatName", name)
		v12:SetAttribute("FloatTier", tier)

		local v13 = FishingFloatsConfig.Floats[name]
		local v14 = if v13 then v13.TierImages and v13.TierImages[tier] else v13

		if v14 then
			local ImageLabel = v12:FindFirstChild("ImageLabel")

			if ImageLabel then
				ImageLabel.Image = v14
			else
				v12.Image = v14
			end
		end

		local v15 = FishingFloatsConfig.TierColors[tier]

		if v15 then
			local Frame = v12:FindFirstChild("Frame")

			if Frame then
				local UIGradient = Frame:FindFirstChildOfClass("UIGradient")

				if UIGradient then
					UIGradient.Color = ColorSequence.new(v15, Color3.fromRGB(255, 255, 255))
				end

				Frame.BackgroundColor3 = v15
			end
		end

		v12.Activated:Connect(function() --[[ Line: 830 | Upvalues: p1 (copy), notifications (ref), SFX (ref), Click (ref), Remotes (ref), name (copy), tier (copy) ]]
			local v1 = p1:FindFirstAvailableSlot()

			if v1 then
				p1._pendingEquipSlot = v1
				SFX.new(Click, 0.5)
				Remotes.EquipFishingFloat:Fire({
					FloatName = name,
					Tier = tier,
					Slot = v1
				})
			else
				notifications:Send("No available slot!")
			end
		end)
	end

	local v16 = false

	for v17, v18 in p1.inventoryFrame:GetChildren() do
		if v18:HasTag("FloatInventoryItem") then
			v16 = true

			break
		end
	end

	if not v16 then
		for v20 in v4.equippedFloats or {} do
			v16 = true

			break
		end
	end

	if not p1.noFloatsDisplay then
		return
	end

	p1.noFloatsDisplay.Visible = not v16
end
function t.FindFirstAvailableSlot(p1) --[[ FindFirstAvailableSlot | Line: 868 | Upvalues: ClientPlayerData (copy) ]]
	local v1 = ClientPlayerData.serverProfile.getState()

	for i = 1, 5 do
		if table.find(v1.boughtSlots, i) and not v1.equippedFloats[tostring(i)] then
			return i
		end
	end

	return nil
end

return t