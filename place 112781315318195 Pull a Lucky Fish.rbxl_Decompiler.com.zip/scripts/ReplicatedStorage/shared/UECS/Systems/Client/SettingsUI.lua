-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ContextActionService = game:GetService("ContextActionService")
local GamepadService = game:GetService("GamepadService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local CashDisplay = require(ReplicatedStorage.shared.module.CashDisplay)
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local topbarplus = require(ReplicatedStorage.client.Satchel.Package.topbarplus)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local SettingsUI = require(ReplicatedStorage.shared.UECS.Components.SettingsUI)
local bindToButtonPress = require(ReplicatedStorage.shared.util.bindToButtonPress)
local v1 = ColorSequence.new(Color3.fromRGB(117, 227, 0), Color3.fromRGB(31, 219, 0))
local v2 = Color3.fromRGB(14, 136, 0)
local v3 = Color3.fromRGB(8, 70, 0)
local v4 = Color3.fromRGB(90, 255, 76)
local v5 = ColorSequence.new(Color3.fromRGB(252, 29, 29), Color3.fromRGB(207, 12, 12))
local v6 = Color3.fromRGB(156, 5, 5)
local v7 = Color3.fromRGB(95, 10, 10)
local v8 = Color3.fromRGB(255, 77, 77)
local t = {
	{
		frameName = "MusicSwitch",
		key = "musicEnabled"
	},
	{
		frameName = "GiftingSwitch",
		key = "giftsEnabled"
	},
	{
		frameName = "TradingSwitch",
		key = "tradesEnabled"
	},
	{
		frameName = "ChaseMusicSwitch",
		key = "chaseMusicEnabled"
	},
	{
		frameName = "OtherFishingSwitch",
		key = "otherPlayersFishingEnabled"
	},
	{
		frameName = "CashIconsSwitch",
		key = "cashIconsEnabled",
		default = false
	},
	{
		frameName = "MutationVFXSwitch",
		key = "baseMutationVfxEnabled"
	}
}

local function resolveSetting(p1, p2, p3) --[[ resolveSetting | Line: 54 ]]
	local v1 = if p1 then p1[p2] else nil

	if v1 == nil then
		return p3
	end

	return v1
end

return {
	UECS = nil,
	Init = function(p1) --[[ Init | Line: 70 | Upvalues: CashDisplay (copy), ClientPlayerData (copy), Players (copy), SettingsUI (copy), bindToButtonPress (copy), GamepadService (copy), ContextActionService (copy), CollectionService (copy), t (copy), Remotes (copy), v1 (copy), v5 (copy), v2 (copy), v6 (copy), v3 (copy), v7 (copy), v4 (copy), v8 (copy), topbarplus (copy) ]]
		local function applyCashIconsMode(p1) --[[ applyCashIconsMode | Line: 74 | Upvalues: CashDisplay (ref) ]]
			local v1 = if p1 then p1.cashIconsEnabled else nil

			CashDisplay.setIconsEnabled(if v1 == nil then false else v1)
		end

		ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 77 ]]
			return p1.settings
		end, applyCashIconsMode)

		local v12 = ClientPlayerData.serverProfile:getState().settings
		local setIconsEnabled = CashDisplay.setIconsEnabled
		local v22 = if v12 then v12.cashIconsEnabled else nil

		setIconsEnabled(if v22 == nil then false else v22)

		local Settings = Players.LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("MainUI"):WaitForChild("Settings")

		Settings.Visible = false

		local ScrollingFrame = Settings:WaitForChild("Content"):WaitForChild("ScrollingFrame")
		local v42 = SettingsUI.Add(Settings)

		v42.Visible.OnChange:Connect(function(p12, p2) --[[ Line: 96 | Upvalues: Settings (copy), bindToButtonPress (ref), p1 (copy), GamepadService (ref), ContextActionService (ref) ]]
			Settings.Visible = p12

			if p12 == p2 then
				return
			end

			if p12 then
				bindToButtonPress("SettingsClose", Enum.KeyCode.ButtonB, function() --[[ Line: 100 | Upvalues: p1 (ref) ]]
					p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
				end)
				GamepadService:EnableGamepadCursor(nil)

				return
			end

			ContextActionService:UnbindAction("SettingsClose")
			GamepadService:DisableGamepadCursor()
		end)

		local CloseButton = Settings:WaitForChild("TopBar"):WaitForChild("CloseButton")

		CollectionService:AddTag(CloseButton, "VFX_ClickBounce")
		CollectionService:AddTag(CloseButton, "VFX_UIClickButton")
		CloseButton.MouseButton1Click:Connect(function() --[[ Line: 115 | Upvalues: p1 (copy) ]]
			p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
		end)

		local t2 = {}

		for v52, v62 in t do
			local v72 = ScrollingFrame:WaitForChild(v62.frameName, 10)

			if v72 then
				local SwitchButton = v72:WaitForChild("SwitchButton")
				local v82 = SwitchButton:WaitForChild("Content")
				local t3 = {
					Gradient = v82:FindFirstChild("UIGradient"),
					Darker = SwitchButton:FindFirstChild("DarkerColor"),
					StateLabel = v82:FindFirstChild("TextLabel", true),
					OuterStroke = SwitchButton:FindFirstChild("UIStroke"),
					InnerStroke = v82:FindFirstChild("UIStroke")
				}

				t3.Default = if v62.default == false then false else true
				t2[v62.key] = t3
				CollectionService:AddTag(SwitchButton, "VFX_ClickBounce")
				CollectionService:AddTag(SwitchButton, "VFX_UIClickButton")
				SwitchButton.MouseButton1Click:Connect(function() --[[ Line: 143 | Upvalues: ClientPlayerData (ref), v62 (copy), Remotes (ref) ]]
					local v1 = ClientPlayerData.serverProfile:getState().settings
					local v2 = if v1 then v1[v62.key] else nil

					Remotes.SetPlayerSetting:Fire({
						settingName = v62.key,
						enabled = not (if v2 == nil then v62.default ~= false else v2)
					})
				end)

				continue
			end

			warn((("[SettingsUI] Settings.Content.ScrollingFrame.%* is missing \226\128\148 skipping that switch"):format(v62.frameName)))
		end

		local function updateSwitches(p1) --[[ updateSwitches | Line: 150 | Upvalues: t2 (copy), v1 (ref), v5 (ref), v2 (ref), v6 (ref), v3 (ref), v7 (ref), v4 (ref), v8 (ref) ]]
			for v12, v22 in t2 do
				local v32 = if p1 then p1[v12] else nil
				local v42 = if v32 == nil then v22.Default else v32

				if v22.Gradient then
					v22.Gradient.Color = if v42 then v1 else v5
				end

				if v22.Darker then
					v22.Darker.BackgroundColor3 = if v42 then v2 else v6
				end

				if v22.StateLabel then
					v22.StateLabel.Text = if v42 then "ON" else "OFF"
				end

				if v22.OuterStroke then
					v22.OuterStroke.Color = if v42 then v3 else v7
				end

				if v22.InnerStroke then
					v22.InnerStroke.Color = if v42 then v4 else v8
				end
			end
		end

		ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 171 ]]
			return p1.settings
		end, updateSwitches)
		updateSwitches(ClientPlayerData.serverProfile:getState().settings)

		local v10 = topbarplus.new()

		v10:setName("Settings")
		v10:setRight()
		v10:setImage("rbxassetid://77275337372105")
		v10:setImageScale(0.7)
		v10:setCaption("Settings")
		v10:bindEvent("selected", function() --[[ Line: 183 | Upvalues: v10 (copy), p1 (copy), v42 (copy) ]]
			v10:deselect()

			local v1 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

			if v1.OpenedUIComponent:Get() == v42 then
				v1.OpenedUIComponent:Set(nil)
			else
				v1.OpenedUIComponent:Set(v42)
			end
		end)
	end
}