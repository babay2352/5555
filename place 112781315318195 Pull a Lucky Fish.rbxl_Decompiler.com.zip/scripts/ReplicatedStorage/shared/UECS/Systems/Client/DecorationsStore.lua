-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ContentProvider = game:GetService("ContentProvider")
local ContextActionService = game:GetService("ContextActionService")
local GuiService = game:GetService("GuiService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local CashDisplay = require(ReplicatedStorage.shared.module.CashDisplay)
local DecorationConfig = require(ReplicatedStorage.shared.config.DecorationConfig)
local DecorationsStore = require(ReplicatedStorage.shared.UECS.Components.DecorationsStore)
local DecorationsStoreConfig = require(ReplicatedStorage.shared.config.DecorationsStoreConfig)
local FloatLootboxConfig = require(ReplicatedStorage.shared.config.FloatLootboxConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local LuckyblockDropReel = require(ReplicatedStorage.shared.module.LuckyblockDropReel)
local Maid = require(ReplicatedStorage.shared.class.Maid)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local SFX = require(ReplicatedStorage.client.SFX)
local VaultConfig = require(ReplicatedStorage.shared.config.VaultConfig)
local bindToButtonPress = require(ReplicatedStorage.shared.util.bindToButtonPress)
local isGamepadActive = require(ReplicatedStorage.shared.util.isGamepadActive)
local notifications = require(ReplicatedStorage.shared.module.notifications)
local t = {
	UECS = nil
}
local v1 = Color3.fromRGB(255, 110, 110)
local t2 = { "icon", "ToolIcon", "Image" }
local t3 = { "Description", "ItemName", "DisplayName" }
local t4 = { "Price", "Cost" }
local t5 = { "Buy", "BuyButton" }
local t6 = { "Title", "CrateName" }
local t7 = { "LuckyBlockImg", "CrateImg", "icon" }
local t8 = { "Price", "Cost", "TextLabel" }

local function resolveNode(p1, p2, p3) --[[ resolveNode | Line: 106 ]]
	local t = {}

	for v1, v2 in p2 do
		t[v2:lower()] = true
	end

	for v3, v4 in p1:GetDescendants() do
		if v4:IsA(p3) and t[v4.Name:lower()] then
			return v4
		end
	end

	return nil
end

local function darken(p1, p2) --[[ darken | Line: 119 ]]
	return Color3.new(p1.R * (1 - p2), p1.G * (1 - p2), p1.B * (1 - p2))
end

local function lighten(p1, p2) --[[ lighten | Line: 123 ]]
	return Color3.new(p1.R + (1 - p1.R) * p2, p1.G + (1 - p1.G) * p2, p1.B + (1 - p1.B) * p2)
end

local function getButtonTextLabel(p1) --[[ getButtonTextLabel | Line: 133 ]]
	local v1 = p1:FindFirstChild("Content")

	if not v1 then
		return nil
	end

	for v2, v3 in v1:GetChildren() do
		if v3:IsA("TextLabel") then
			return v3
		end
	end

	return nil
end

local function getButtonIcon(p1) --[[ getButtonIcon | Line: 146 ]]
	local v1 = p1:FindFirstChild("Content")

	if not v1 then
		return nil
	end

	for v2, v3 in v1:GetChildren() do
		if v3:IsA("ImageLabel") and v3.Name ~= "Pattern" then
			return v3
		end
	end

	return nil
end

local function getSortedConfigNames() --[[ getSortedConfigNames | Line: 159 | Upvalues: DecorationConfig (copy), VaultConfig (copy) ]]
	local t = {}

	for k, v in pairs(DecorationConfig) do
		if v.Purchasable ~= false and not VaultConfig.isDisabledVault(k) then
			table.insert(t, k)
		end
	end

	table.sort(t, function(p1, p2) --[[ Line: 175 | Upvalues: DecorationConfig (ref) ]]
		local v1 = DecorationConfig[p1]
		local v2 = DecorationConfig[p2]
		local v3 = v1.GemCost or 0
		local v4 = v2.GemCost or 0

		if v3 > 0 == (if v4 > 0 then true else false) then
			local v7 = if v3 > 0 then v3 else v1.Cost
			local v8 = if v4 > 0 then v4 else v2.Cost

			if v7 == v8 then
				return p1 < p2
			end

			return v7 < v8
		end

		return v4 > 0
	end)

	return t
end

local function categoryIdFor(p1) --[[ categoryIdFor | Line: 195 | Upvalues: DecorationConfig (copy), DecorationsStoreConfig (copy) ]]
	return DecorationConfig[p1].StoreCategory or DecorationsStoreConfig.DefaultCategoryId
end

local function buildCratePool(p1) --[[ buildCratePool | Line: 202 | Upvalues: FloatLootboxConfig (copy), DecorationConfig (copy) ]]
	if p1.ItemType ~= "FloatLootbox" then
		return {}
	end

	local v1 = FloatLootboxConfig.Lootboxes[p1.ConfigName]
	local v2 = if v1 then v1.DecorationDrops else v1

	if not v2 or #v2 == 0 then
		return {}
	end

	local sum = 0

	for v3, v4 in v2 do
		sum = sum + v4.Weight
	end

	if sum <= 0 then
		return {}
	end

	local t = {}

	for v5, v6 in v2 do
		local v7 = DecorationConfig[v6.ConfigName]
		local t2 = {
			name = v6.ConfigName,
			chance = v6.Weight / sum * 100
		}

		t2.image = if v7 then v7.Icon else ""
		t2.itemLabel = if v7 then v7.DisplayName else v6.ConfigName
		table.insert(t, t2)
	end

	table.sort(t, function(p1, p2) --[[ Line: 232 ]]
		return p1.chance < p2.chance
	end)

	return t
end

local function takeTemplate(p1, p2) --[[ takeTemplate | Line: 240 ]]
	local v1 = nil

	for v2, v3 in p1:GetChildren() do
		if v3.Name == p2 and v3:IsA("GuiObject") then
			if v1 then
				v3:Destroy()

				continue
			end

			v1 = v3
		end
	end

	if v1 then
		v1.Visible = false
	end

	return v1
end

function t.Init(p1) --[[ Init | Line: 257 | Upvalues: Players (copy), takeTemplate (copy), resolveNode (copy), t4 (copy), t2 (copy), t3 (copy), t5 (copy), DecorationsStore (copy), DecorationsStoreConfig (copy), DecorationConfig (copy), v1 (copy), CashDisplay (copy), FloatLootboxConfig (copy), notifications (copy), getSortedConfigNames (copy), Remotes (copy), CollectionService (copy), t6 (copy), t7 (copy), t8 (copy), buildCratePool (copy), ContentProvider (copy), Maid (copy), LuckyblockDropReel (copy), isGamepadActive (copy), GuiService (copy), getButtonTextLabel (copy), getButtonIcon (copy), darken (copy), bindToButtonPress (copy), ContextActionService (copy), ClientPlayerData (copy), SFX (copy) ]]
	local MainUI = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI")
	local DecorationsStore2 = MainUI:FindFirstChild("DecorationsStore")

	if not DecorationsStore2 then
		warn("[DecorationsStore] MainUI.DecorationsStore not found \226\128\148 decorations store disabled")

		return
	end

	DecorationsStore2.Visible = false

	local v12 = DecorationsStore2:FindFirstChild("Content")
	local v2 = v12 and v12:FindFirstChild("ScrollingFrame")
	local v3 = if v2 then takeTemplate(v2, "Template") else v2

	if not (v12 and (v2 and v3)) then
		warn("[DecorationsStore] MainUI.DecorationsStore is missing Content.ScrollingFrame.Template \226\128\148 store disabled")

		return
	end

	local CratesScrollingFrame = v12:FindFirstChild("CratesScrollingFrame")
	local v4 = if CratesScrollingFrame then takeTemplate(CratesScrollingFrame, "template") else CratesScrollingFrame

	if not (CratesScrollingFrame and v4) then
		warn("[DecorationsStore] MainUI.DecorationsStore is missing Content.CratesScrollingFrame.template \226\128\148 crates tab disabled")
	end

	local Categories = v12:FindFirstChild("Categories")
	local v5 = if Categories then takeTemplate(Categories, "CategoryButtonTemplate") else Categories

	if not (Categories and v5) then
		warn("[DecorationsStore] MainUI.DecorationsStore is missing Content.Categories.CategoryButtonTemplate \226\128\148 tabs disabled")
	end

	local TopBar = DecorationsStore2:FindFirstChild("TopBar")
	local v6 = TopBar and TopBar:FindFirstChild("Refreshcountdown")
	local v7 = resolveNode(v3, t4, "TextLabel")
	local t = {}

	t.icon = if resolveNode(v3, t2, "ImageLabel") == nil then false else true
	t.name = if resolveNode(v3, t3, "TextLabel") == nil then false else true
	t.price = if v7 == nil then false else true
	t.buy = if resolveNode(v3, t5, "GuiButton") == nil then false else true

	for v122, v13 in t do
		if not v13 then
			warn((("[DecorationsStore] Template has no %* node \226\128\148 that part of each card stays unset"):format(v122)))
		end
	end

	local v14 = if v7 then v7.TextColor3 else Color3.fromRGB(255, 255, 255)
	local v15 = DecorationsStore.Add(DecorationsStore2)
	local t9 = {}
	local t10 = {}
	local t11 = {}
	local v16 = 0
	local v17 = (-1 / 0)
	local v18 = (-1 / 0)
	local v19 = DecorationsStoreConfig.Categories[1]

	local function refreshEntry(p1, p2) --[[ refreshEntry | Line: 338 | Upvalues: t9 (copy), DecorationConfig (ref), v14 (copy), v1 (ref), CashDisplay (ref) ]]
		local v12 = t9[p1]

		if not (v12 and v12.price) then
			return
		end

		local v2 = DecorationConfig[p1]
		local v3 = v2.GemCost or 0

		if v3 > 0 then
			local v5 = if v3 <= (p2.gems or 0) then v14 else v1

			if v12.gemRow and v12.gemAmount then
				v12.gemAmount.Text = tostring(v3)
				v12.gemAmount.TextColor3 = v5
				v12.gemRow.Visible = true
				v12.price.Visible = false

				return
			end

			v12.price.TextColor3 = v5
			CashDisplay.setPlainText(v12.price, (("%* Gems"):format(v3)))
		else
			if v12.gemRow then
				v12.gemRow.Visible = false
			end

			v12.price.Visible = true
			v12.price.TextColor3 = if (p2.money or 0) >= v2.Cost then v14 else v1
			CashDisplay.applyToLabel(v12.price, v2.Cost, {
				Compact = true
			})
		end
	end

	local function refreshCrateEntry(p1, p2) --[[ refreshCrateEntry | Line: 380 | Upvalues: t10 (copy), DecorationsStoreConfig (ref), t11 (ref), v16 (ref), v1 (ref), CashDisplay (ref), v14 (copy) ]]
		local v12 = t10[p1]

		if not (v12 and v12.price) then
			return
		end

		local v2 = DecorationsStoreConfig.Items[p1]
		local v5 = if (t11[p1] or 0) > 0 then true else false
		local v6 = if (p2.money or 0) >= v2.Price then true else false

		if not (if v16 > 0 then true else false) then
			v12.price.TextColor3 = v1
			CashDisplay.setPlainText(v12.price, "...")

			return
		end

		if not v5 then
			local v8 = math.max(v16 - os.time(), 0)

			v12.price.TextColor3 = v1
			CashDisplay.setPlainText(v12.price, string.format("Restock %d:%02d", math.floor(v8 / 60), v8 % 60))

			return
		end

		v12.price.TextColor3 = if v6 then v14 else v1
		CashDisplay.applyToLabel(v12.price, v2.Price, {
			Compact = true
		})
	end

	local function refreshCratePity(p1, p2) --[[ refreshCratePity | Line: 410 | Upvalues: t10 (copy), DecorationsStoreConfig (ref), FloatLootboxConfig (ref) ]]
		local v1 = t10[p1]

		if not (v1 and (v1.pityFill or v1.pityLabel)) then
			return
		end

		local v2 = DecorationsStoreConfig.Items[p1]
		local v3 = FloatLootboxConfig.Lootboxes[v2.ConfigName]
		local v4 = if v3 then v3.PityThreshold else v3

		if not v4 then
			return
		end

		local v7 = math.clamp((p2.luckyblockPity or {})[v2.ConfigName] or 0, 0, v4)

		if v1.pityLabel then
			v1.pityLabel.Text = ("%*/%*"):format(v7, v4)
		end

		if not v1.pityFill then
			return
		end

		local Size = v1.pityFill.Size

		v1.pityFill.Size = UDim2.new(v7 / v4, 0, Size.Y.Scale, Size.Y.Offset)
	end

	local function refreshAll(p1) --[[ refreshAll | Line: 431 | Upvalues: t9 (copy), refreshEntry (copy), t10 (copy), refreshCrateEntry (copy), refreshCratePity (copy) ]]
		for k in pairs(t9) do
			refreshEntry(k, p1)
		end

		for k in pairs(t10) do
			refreshCrateEntry(k, p1)
			refreshCratePity(k, p1)
		end
	end

	local function onBuyActivated(p1) --[[ onBuyActivated | Line: 441 | Upvalues: v18 (ref), notifications (ref) ]]
		return function() --[[ Line: 442 | Upvalues: v18 (ref), notifications (ref), p1 (copy) ]]
			local v1 = os.clock()

			if v1 - v18 < 0.2 then
				notifications:Send("You are buying too fast!")
			else
				v18 = v1
				p1()
			end
		end
	end

	local t12 = {}
	local v20 = nil

	for v21, v22 in DecorationsStoreConfig.Categories do
		t12[v22.Id] = v22.Kind
	end

	local v23 = #DecorationsStoreConfig.ItemOrder

	if CratesScrollingFrame then
		local Spacer = CratesScrollingFrame:FindFirstChild("Spacer")

		if Spacer and Spacer:IsA("GuiObject") then
			Spacer.LayoutOrder = 1000000
		end
	end

	if not v3:FindFirstChild("GemPrice", true) then
		warn("[DecorationsStore] Template has no GemPrice row (Buy.Content.GemPrice with Amount + GemIcon) \226\128\148 gem prices render as text until the card gets one")
	end

	for i, v in ipairs((getSortedConfigNames())) do
		local v24 = DecorationConfig[v]
		local v25 = DecorationConfig[v].StoreCategory or DecorationsStoreConfig.DefaultCategoryId
		local v26 = if t12[v25] == "Functional" then if CratesScrollingFrame == nil then false else true else false
		local v27 = v3:Clone()

		v27.Name = v
		v27.LayoutOrder = if v26 then v23 + i else i
		v27.Visible = false

		local v29 = resolveNode(v27, t2, "ImageLabel")

		if v29 then
			v29.Image = v24.Icon
		end

		local v30 = resolveNode(v27, t3, "TextLabel")

		if v30 then
			v30.Text = v24.DisplayName
		end

		local v31 = resolveNode(v27, t5, "GuiButton")

		if v31 then
			v31.Selectable = true
			v31.SelectionOrder = i

			local function f32() --[[ Line: 506 | Upvalues: Remotes (ref), v (copy) ]]
				Remotes.BuyDecoration:Fire(v)
			end

			v31.Activated:Connect(function() --[[ Line: 442 | Upvalues: v18 (ref), notifications (ref), f32 (copy) ]]
				local v1 = os.clock()

				if v1 - v18 < 0.2 then
					notifications:Send("You are buying too fast!")
				else
					v18 = v1
					f32()
				end
			end)
		end

		v27:SetAttribute("InspectType", "Decoration")
		v27:SetAttribute("DecorationConfigName", v)
		CollectionService:AddTag(v27, "Inspect")
		v27.Parent = if v26 then CratesScrollingFrame else v2

		local GemPrice = v27:FindFirstChild("GemPrice", true)
		local t13 = {
			frame = v27,
			price = resolveNode(v27, t4, "TextLabel"),
			gemRow = GemPrice
		}

		t13.gemAmount = if GemPrice then GemPrice:FindFirstChild("Amount") else nil
		t13.categoryId = v25
		t9[v] = t13
	end

	if CratesScrollingFrame and v4 then
		for i, v in ipairs(DecorationsStoreConfig.ItemOrder) do
			local v35 = DecorationsStoreConfig.Items[v]
			local v36 = v4:Clone()

			v36.Name = v
			v36.LayoutOrder = i
			v36.Visible = true

			local v37 = resolveNode(v36, t6, "TextLabel")

			if v37 then
				v37.Text = v35.DisplayName
			end

			local v38 = resolveNode(v36, t7, "ImageLabel")

			if v38 then
				v38.Image = v35.CardImage or v35.Icon
			end

			local Background = v36:FindFirstChild("Background", true)

			if Background and v35.CardBackground then
				Background.Image = v35.CardBackground
			end

			local Frame = v36:FindFirstChild("Frame")

			if Frame and v35.CardFrameColor then
				Frame.BackgroundColor3 = v35.CardFrameColor
			end

			local v40 = resolveNode(v36, t5, "GuiButton")
			local v41 = nil

			if v40 then
				v40.Selectable = true
				v40.SelectionOrder = i

				local function f42() --[[ Line: 567 | Upvalues: Remotes (ref), v (copy) ]]
					Remotes.BuyDecorationsStoreItem:Fire(v)
				end

				v40.Activated:Connect(function() --[[ Line: 442 | Upvalues: v18 (ref), notifications (ref), f42 (copy) ]]
					local v1 = os.clock()

					if v1 - v18 < 0.2 then
						notifications:Send("You are buying too fast!")
					else
						v18 = v1
						f42()
					end
				end)
				v41 = resolveNode(v40, t8, "TextLabel")
			else
				warn((("[DecorationsStore] crate card \"%*\" has no Buy button \226\128\148 card is display-only"):format(v)))
			end

			local v44 = FloatLootboxConfig.Lootboxes[v35.ConfigName]
			local PityBar = v36:FindFirstChild("PityBar", true)
			local v45 = PityBar and PityBar:FindFirstChild("Fill")
			local PityLabel = v36:FindFirstChild("PityLabel", true)
			local PityTitle = v36:FindFirstChild("PityTitle", true)
			local v46 = if v44 == nil then false elseif v44.PityThreshold == nil then false else true

			if PityBar then
				PityBar.Visible = v46
			end

			if PityLabel then
				PityLabel.Visible = v46
			end

			if PityTitle then
				PityTitle.Visible = v46

				if v46 and v44.PityTitle then
					PityTitle.Text = v44.PityTitle
				end
			end

			v36:SetAttribute("InspectType", "StoreCrate")
			v36:SetAttribute("StoreItemId", v)
			CollectionService:AddTag(v36, "Inspect")
			v36.Parent = CratesScrollingFrame

			local t13 = {
				frame = v36,
				price = v41
			}

			t13.pityFill = if v46 then v45 else nil
			t13.pityLabel = if v46 then PityLabel else nil
			t10[v] = t13
		end
	end

	task.spawn(function() --[[ Line: 616 | Upvalues: DecorationsStoreConfig (ref), buildCratePool (ref), ContentProvider (ref) ]]
		local t = {}
		local t2 = {}

		local function add(p1) --[[ add | Line: 619 | Upvalues: t (copy), t2 (copy) ]]
			if not p1 or (p1 == "" or t[p1]) then
				return
			end

			t[p1] = true
			table.insert(t2, p1)
		end

		for v1, v2 in DecorationsStoreConfig.ItemOrder do
			local v3 = DecorationsStoreConfig.Items[v2]
			local v4 = v3.CardImage or v3.Icon

			if v4 and (v4 ~= "" and not t[v4]) then
				t[v4] = true
				table.insert(t2, v4)
			end

			local CardBackground = v3.CardBackground

			if CardBackground and (CardBackground ~= "" and not t[CardBackground]) then
				t[CardBackground] = true
				table.insert(t2, CardBackground)
			end

			for v5, v6 in buildCratePool(v3) do
				local image = v6.image

				if image and (image ~= "" and not t[image]) then
					t[image] = true
					table.insert(t2, image)
				end
			end
		end

		if not (#t2 > 0) then
			return
		end

		ContentProvider:PreloadAsync(t2)
	end)

	local function stopReels() --[[ stopReels | Line: 643 | Upvalues: v20 (ref) ]]
		if not v20 then
			return
		end

		v20:Destroy()
		v20 = nil
	end

	local function startReels() --[[ startReels | Line: 650 | Upvalues: v20 (ref), CratesScrollingFrame (copy), Maid (ref), t10 (copy), buildCratePool (ref), DecorationsStoreConfig (ref), LuckyblockDropReel (ref) ]]
		if not v20 and CratesScrollingFrame then
			local v1 = Maid.new()

			v20 = v1
			task.defer(function() --[[ Line: 656 | Upvalues: v20 (ref), v1 (copy), t10 (ref), buildCratePool (ref), DecorationsStoreConfig (ref), LuckyblockDropReel (ref), CratesScrollingFrame (ref) ]]
				if v20 ~= v1 then
					return
				end

				for k2 in pairs(t10) do
					local v12 = buildCratePool(DecorationsStoreConfig.Items[k2])
					local v2 = LuckyblockDropReel.startWithPool(CratesScrollingFrame, k2, v12)

					if v2 then
						v1:GiveTask(v2)

						continue
					end

					if #v12 > 0 then
						warn((("[DecorationsStore] no drop reel for crate \"%*\" \226\128\148 needs a FishList frame"):format(k2)))
					end
				end
			end)
		end
	end

	local function activeList() --[[ activeList | Line: 673 | Upvalues: v19 (ref), CratesScrollingFrame (copy), v2 (copy) ]]
		if v19.Kind == "Functional" and CratesScrollingFrame then
			return CratesScrollingFrame
		end

		return v2
	end

	local t13 = {}

	local function applyCategory() --[[ applyCategory | Line: 683 | Upvalues: v19 (ref), v2 (copy), CratesScrollingFrame (copy), v6 (copy), t9 (copy), t13 (copy), DecorationsStore2 (copy), v20 (ref), Maid (ref), t10 (copy), buildCratePool (ref), DecorationsStoreConfig (ref), LuckyblockDropReel (ref), isGamepadActive (ref), GuiService (ref) ]]
		local isKind = v19.Kind == "Functional"

		v2.Visible = not isKind

		if CratesScrollingFrame then
			CratesScrollingFrame.Visible = isKind
		end

		if v6 then
			v6.Visible = isKind
		end

		for v1, v22 in t9 do
			v22.frame.Visible = v22.categoryId == v19.Id
		end

		for v3, v4 in t13 do
			v4(v3 == v19.Id)
		end

		if isKind and DecorationsStore2.Visible then
			if not v20 and CratesScrollingFrame then
				local v5 = Maid.new()

				v20 = v5
				task.defer(function() --[[ Line: 656 | Upvalues: v20 (ref), v5 (copy), t10 (ref), buildCratePool (ref), DecorationsStoreConfig (ref), LuckyblockDropReel (ref), CratesScrollingFrame (ref) ]]
					if v20 ~= v5 then
						return
					end

					for k2 in pairs(t10) do
						local v12 = buildCratePool(DecorationsStoreConfig.Items[k2])
						local v2 = LuckyblockDropReel.startWithPool(CratesScrollingFrame, k2, v12)

						if v2 then
							v5:GiveTask(v2)

							continue
						end

						if #v12 > 0 then
							warn((("[DecorationsStore] no drop reel for crate \"%*\" \226\128\148 needs a FishList frame"):format(k2)))
						end
					end
				end)
			end
		elseif v20 then
			v20:Destroy()
			v20 = nil
		end

		if not (DecorationsStore2.Visible and isGamepadActive()) then
			return
		end

		local defer = task.defer
		local v7 = if v19.Kind == "Functional" and CratesScrollingFrame then CratesScrollingFrame else v2

		defer(GuiService.Select, GuiService, v7)
	end

	if Categories and v5 then
		for i, v in ipairs(DecorationsStoreConfig.Categories) do
			local v49 = v5:Clone()

			v49.Name = v.Id
			v49.LayoutOrder = i
			v49.Visible = true
			v49.Selectable = true

			local v50 = getButtonTextLabel(v49)

			if v50 then
				v50.Text = v.DisplayName
			else
				warn((("[DecorationsStore] category button has no caption TextLabel \226\128\148 tab \"%*\" stays unlabeled"):format(v.Id)))
			end

			local v51 = getButtonIcon(v49)

			if v51 and v.Icon then
				v51.Image = v.Icon
				v51.Visible = true
			elseif v51 then
				v51.Visible = false
			end

			local v52 = v49:FindFirstChild("Content")
			local v53 = if v52 then v52:FindFirstChildOfClass("UIGradient") else v52
			local UIStroke = v49:FindFirstChildOfClass("UIStroke")
			local v54 = v52 and v52:FindFirstChildOfClass("UIStroke")
			local Line = v49:FindFirstChild("Line")

			if v.Color then
				local Color = v.Color

				if v53 then
					v53.Color = ColorSequence.new(Color, darken(Color, 0.18))
				end

				if v54 then
					v54.Color = Color3.new(Color.R + (1 - Color.R) * 0.2, Color.G + (1 - Color.G) * 0.2, Color.B + (1 - Color.B) * 0.2)
				end

				if UIStroke then
					UIStroke.Color = Color3.new(Color.R * 0.38, Color.G * 0.38, Color.B * 0.38)
				end

				if Line then
					Line.BackgroundColor3 = Color3.new(Color.R * 0.62, Color.G * 0.62, Color.B * 0.62)
				end
			end

			local UIScale = Instance.new("UIScale")

			UIScale.Scale = 1
			UIScale.Parent = v49
			t13[v.Id] = function(p1) --[[ Line: 768 | Upvalues: UIScale (copy) ]]
				UIScale.Scale = if p1 then 1.1 else 1
			end
			v49.Activated:Connect(function() --[[ Line: 772 | Upvalues: v19 (ref), v (copy), applyCategory (copy) ]]
				if v19 ~= v then
					v19 = v
					applyCategory()
				end
			end)
			v49.Parent = Categories
		end
	end

	local v55 = nil

	task.spawn(function() --[[ Line: 786 | Upvalues: v55 (ref), p1 (copy) ]]
		v55 = p1.UECS:WaitForAnyComponent("UIFrameOpener")
	end)

	local function closeWindow() --[[ closeWindow | Line: 790 | Upvalues: v55 (ref) ]]
		if not v55 then
			return
		end

		v55.OpenedUIComponent:Set(nil)
	end

	v15.Visible.OnChange:Connect(function(p1) --[[ Line: 796 | Upvalues: DecorationsStore2 (copy), MainUI (copy), Remotes (ref), bindToButtonPress (ref), closeWindow (copy), applyCategory (copy), isGamepadActive (ref), GuiService (ref), v19 (ref), CratesScrollingFrame (copy), v2 (copy), v20 (ref), ContextActionService (ref) ]]
		DecorationsStore2.Visible = p1

		local HUD = MainUI:FindFirstChild("HUD")

		if HUD then
			HUD.Visible = not p1
		end

		if p1 then
			Remotes.RequestDecorationsStoreState:Fire()
			bindToButtonPress("DecorationsStoreClose", Enum.KeyCode.ButtonB, closeWindow)
			applyCategory()

			if not isGamepadActive() then
				return
			end

			task.defer(GuiService.Select, GuiService, if v19.Kind == "Functional" and CratesScrollingFrame then CratesScrollingFrame else v2)

			return
		end

		if v20 then
			v20:Destroy()
			v20 = nil
		end

		ContextActionService:UnbindAction("DecorationsStoreClose")

		local SelectedObject = GuiService.SelectedObject

		if not (SelectedObject and SelectedObject:IsDescendantOf(DecorationsStore2)) then
			return
		end

		GuiService.SelectedObject = nil
	end)
	GuiService:GetPropertyChangedSignal("SelectedObject"):Connect(function() --[[ Line: 828 | Upvalues: v15 (copy), isGamepadActive (ref), GuiService (ref), DecorationsStore2 (copy), v19 (ref), CratesScrollingFrame (copy), v2 (copy) ]]
		if not (v15.Visible:Get() and isGamepadActive()) then
			return
		end

		local SelectedObject = GuiService.SelectedObject

		if SelectedObject and SelectedObject:IsDescendantOf(DecorationsStore2) then
			return
		end

		task.defer(GuiService.Select, GuiService, if v19.Kind == "Functional" and CratesScrollingFrame then CratesScrollingFrame else v2)
	end)

	local CloseButton = DecorationsStore2:FindFirstChild("CloseButton", true)

	if CloseButton then
		CloseButton.Active = true
		CloseButton.Activated:Connect(closeWindow)
	end

	applyCategory()
	refreshAll(ClientPlayerData.serverProfile:getState())
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 850 ]]
		return p1.money
	end, function() --[[ Line: 852 | Upvalues: refreshAll (copy), ClientPlayerData (ref) ]]
		refreshAll(ClientPlayerData.serverProfile:getState())
	end)
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 861 ]]
		return p1.gems
	end, function() --[[ Line: 863 | Upvalues: refreshAll (copy), ClientPlayerData (ref) ]]
		refreshAll(ClientPlayerData.serverProfile:getState())
	end)
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 869 ]]
		return p1.luckyblockPity
	end, function() --[[ Line: 871 | Upvalues: ClientPlayerData (ref), t10 (copy), refreshCratePity (copy) ]]
		local v1 = ClientPlayerData.serverProfile:getState()

		for k in pairs(t10) do
			refreshCratePity(k, v1)
		end
	end)
	Remotes.ReplicateDecorationsStore:On(function(p1) --[[ Line: 878 | Upvalues: t11 (ref), v16 (ref), refreshAll (copy), ClientPlayerData (ref) ]]
		if type(p1) ~= "table" then
			return
		end

		t11 = p1.Stock or {}
		v16 = p1.WindowEnd or 0
		refreshAll(ClientPlayerData.serverProfile:getState())
	end)

	if next(t10) ~= nil then
		task.spawn(function() --[[ Line: 891 | Upvalues: DecorationsStore2 (copy), v6 (copy), DecorationsStoreConfig (ref), ClientPlayerData (ref), t10 (copy), t11 (ref), refreshCrateEntry (copy), v16 (ref), v17 (ref), Remotes (ref) ]]
			while true do
				local v1

				repeat
					local v2

					repeat
						repeat
							task.wait(1)
						until DecorationsStore2.Visible

						if v6 and v6.Visible then
							local RestockInterval = DecorationsStoreConfig.RestockInterval
							local v3 = RestockInterval - os.time() % RestockInterval

							v6.Text = string.format(DecorationsStoreConfig.StoreCountdownFormat, math.floor(v3 / 60), v3 % 60)
						end

						local v4 = ClientPlayerData.serverProfile:getState()

						v2 = false

						for k in pairs(t10) do
							if (t11[k] or 0) <= 0 then
								refreshCrateEntry(k, v4)
								v2 = true
							end
						end
					until v2 and (v16 > 0 and v16 <= os.time())

					v1 = os.clock()
				until v1 - v17 >= 5

				v17 = v1
				Remotes.RequestDecorationsStoreState:Fire()
			end
		end)
	end

	local t14 = {
		Decoration = true,
		FloatLootbox = true
	}

	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 943 ]]
		return p1.inventory
	end, function(p1, p2) --[[ Line: 945 | Upvalues: DecorationsStore2 (copy), t14 (copy), SFX (ref) ]]
		if type(p1) ~= "table" or not DecorationsStore2.Visible then
			return
		end

		local v2 = if p2 then p2 else {}

		for v3, v4 in p1 do
			if t14[v4.Category] then
				local v5 = v2[v3]

				if not v5 or (v4.Stack or 0) > (v5.Stack or 0) then
					SFX.new(SFX.Sounds.Buy, 0.5)

					return
				end
			end
		end
	end)
end

return t