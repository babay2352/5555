-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local GymEventConfig = require(ReplicatedStorage.shared.config.GymEventConfig)
local GymEventState = require(ReplicatedStorage.client.GymEventState)
local convertTimeMS = require(ReplicatedStorage.shared.util.convertTimeMS)
local t = {
	UECS = nil
}
local TrainingZone = GymEventConfig.Tags.TrainingZone
local t2 = {}

local function findLabel(p1) --[[ findLabel | Line: 44 | Upvalues: GymEventConfig (copy) ]]
	local v1 = p1:FindFirstChildWhichIsA("BillboardGui", true)

	if not v1 then
		return nil
	end

	local v2 = v1:FindFirstChild(GymEventConfig.Ui.ZoneBillboardLabelName, true)

	if v2 and v2:IsA("TextLabel") then
		return v2
	end

	return v1:FindFirstChildWhichIsA("TextLabel", true)
end

local function nextMultiplierOf(p1) --[[ nextMultiplierOf | Line: 61 | Upvalues: GymEventConfig (copy) ]]
	for v1, v2 in GymEventConfig.Outcomes do
		if v2.Id == p1.tierId then
			local v3 = v2.Stages[p1.stageIndex + 1]

			return if v3 then v3.Multiplier else v3
		end
	end

	return nil
end

local function statusText() --[[ statusText | Line: 72 | Upvalues: GymEventState (copy), convertTimeMS (copy), nextMultiplierOf (copy) ]]
	local v1 = GymEventState.Get()

	if not v1 then
		return ""
	end

	local v2 = os.time()
	local buff = v1.buff

	if not buff then
		return ("Opens in %*"):format((convertTimeMS((math.max(0, v1.cycleEnd - v2)))))
	end

	local v7 = ("OPEN \194\183 x%* \194\183 %*"):format(buff.multiplier, (convertTimeMS((math.max(0, buff.expiresAt - v2))))) .. (" \194\183 %* uses"):format(buff.stageTicksLeft)
	local v8 = nextMultiplierOf(buff)

	if v8 then
		v7 = v7 .. ("\nNext level: %*x"):format(v8)
	end

	return v7
end

local function render() --[[ render | Line: 99 | Upvalues: statusText (copy), t2 (copy) ]]
	local v1 = statusText()

	if v1 == "" then
		return
	end

	for v2, v3 in t2 do
		if v3.label and v3.label.Parent then
			v3.label.Text = v1
		end
	end
end

local function startFor(p1) --[[ startFor | Line: 111 | Upvalues: t2 (copy), findLabel (copy), render (copy) ]]
	if p1:IsA("BasePart") and not t2[p1] then
		local t = {
			label = findLabel(p1),
			connections = {}
		}

		t2[p1] = t

		local function f1() --[[ Line: 124 | Upvalues: t (copy), findLabel (ref), p1 (copy), render (ref) ]]
			if not (t.label and t.label.Parent) then
				t.label = findLabel(p1)
				render()
			end
		end

		table.insert(t.connections, p1.DescendantAdded:Connect(f1))
		render()
	end
end

local function stopFor(p1) --[[ stopFor | Line: 136 | Upvalues: t2 (copy) ]]
	local v1 = t2[p1]

	if not v1 then
		return
	end

	for v2, v3 in v1.connections do
		v3:Disconnect()
	end

	t2[p1] = nil
end

function t.Init(p1) --[[ Init | Line: 147 | Upvalues: GymEventConfig (copy), GymEventState (copy), render (copy), CollectionService (copy), TrainingZone (copy), startFor (copy), stopFor (copy), RunService (copy) ]]
	if not GymEventConfig.Enabled then
		return
	end

	GymEventState.Start()
	GymEventState.Changed:Connect(render)

	for v1, v2 in CollectionService:GetTagged(TrainingZone) do
		startFor(v2)
	end

	CollectionService:GetInstanceAddedSignal(TrainingZone):Connect(startFor)
	CollectionService:GetInstanceRemovedSignal(TrainingZone):Connect(stopFor)

	local v3 = 0

	RunService.Heartbeat:Connect(function(p1) --[[ Line: 165 | Upvalues: v3 (ref), render (ref) ]]
		debug.profilebegin("UECS/GymZoneBillboard.Heartbeat")
		v3 = v3 + p1

		if v3 >= 1 then
			v3 = 0
			render()
		end

		debug.profileend()
	end)
end

return t