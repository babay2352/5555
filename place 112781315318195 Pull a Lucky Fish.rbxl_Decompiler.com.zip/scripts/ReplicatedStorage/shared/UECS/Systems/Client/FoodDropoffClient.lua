-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ContentProvider = game:GetService("ContentProvider")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local BeamTo = require(ReplicatedStorage.client.BeamTo)
local EventConfig = require(ReplicatedStorage.shared.config.EventConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Remotes = require(ReplicatedStorage.shared.Remotes)
local SFX = require(ReplicatedStorage.client.SFX)
local getFoodModelTemplate = require(ReplicatedStorage.shared.util.getFoodModelTemplate)
local t = {
	UECS = nil,
	Priority = 60
}
local FoodDropoffNpc = EventConfig.Tags.FoodDropoffNpc
local v1 = Vector2.new(0, -35)
local DropoffIdleAnimation = EventConfig.Theme.DropoffIdleAnimation
local DropoffFeedAnimation = EventConfig.Theme.DropoffFeedAnimation
local CookingStation = EventConfig.Tags.CookingStation
local PlatePart = EventConfig.WorkspaceNames.PlatePart
local v2 = CFrame.Angles(1.5707963267948966, 0, 0)
local ReactionPhrases = EventConfig.Theme.ReactionPhrases
local TurnInIntroSound = EventConfig.Theme.TurnInIntroSound
local t2 = {
	SFX.Sounds.DialogBlip1,
	SFX.Sounds.DialogBlip2,
	SFX.Sounds.DialogBlip3,
	SFX.Sounds.DialogBlip4,
	SFX.Sounds.DialogBlip5,
	SFX.Sounds.DialogBlip6,
	SFX.Sounds.DialogBlip7
}
local LocalPlayer = Players.LocalPlayer

local function playLetterBlip() --[[ playLetterBlip | Line: 79 | Upvalues: t2 (copy), SFX (copy) ]]
	SFX.PlaySoundWithRandomPitch(t2[math.random(1, #t2)], 0.8, 0.95, 1.05)
end

local function playReactionVoice() --[[ playReactionVoice | Line: 84 | Upvalues: SFX (copy), EventConfig (copy) ]]
	local v1 = SFX.Sounds[EventConfig.Theme.ReactionVoiceSfx]

	if not v1 then
		return
	end

	SFX.PlaySoundWithRandomPitch(v1, 0.8, 0.95, 1.05)
end

local function playIntroSound() --[[ playIntroSound | Line: 91 | Upvalues: SFX (copy), TurnInIntroSound (copy) ]]
	SFX.PlaySoundWithRandomPitch(TurnInIntroSound, 1, 1, 1)
end

local t3 = {}

local function playFeedAnimation(p1) --[[ playFeedAnimation | Line: 99 | Upvalues: t3 (copy), DropoffFeedAnimation (copy) ]]
	local AnimationController = p1:FindFirstChild("AnimationController")

	if not AnimationController then
		return
	end

	local v1 = t3[p1]

	if v1 then
		v1:Stop()
		t3[p1] = nil
	end

	local Animation = Instance.new("Animation")

	Animation.AnimationId = DropoffFeedAnimation

	local ok, result = pcall(function() --[[ Line: 111 | Upvalues: AnimationController (copy), Animation (copy) ]]
		return AnimationController:LoadAnimation(Animation)
	end)

	Animation:Destroy()

	if ok and result then
		result.Priority = Enum.AnimationPriority.Action
		result.Looped = false
		result:Play()
		t3[p1] = result
	end
end

local function getModelTemplate(p1) --[[ getModelTemplate | Line: 125 | Upvalues: ReplicatedStorage (copy) ]]
	local v1 = ReplicatedStorage:FindFirstChild("shared")
	local v2 = if v1 then v1:FindFirstChild("model") else v1
	local v3 = if v2 then v2:FindFirstChild(p1) else v2

	if v3 then
		return v3
	end

	warn((("[FoodDropoffClient] template \"%*\" not found in ReplicatedStorage.shared.model"):format(p1)))

	return v3
end

local t4 = {}

local function getOrCreateBillboardAnchor(p1) --[[ getOrCreateBillboardAnchor | Line: 139 | Upvalues: t4 (copy) ]]
	local v1 = t4[p1]

	if v1 and v1.Parent then
		return v1
	end

	local FoodNpcBillboardAnchor = p1:FindFirstChild("FoodNpcBillboardAnchor")

	if FoodNpcBillboardAnchor and FoodNpcBillboardAnchor:IsA("BasePart") then
		t4[p1] = FoodNpcBillboardAnchor

		return FoodNpcBillboardAnchor
	end

	local ok, result, result2 = pcall(function() --[[ Line: 150 | Upvalues: p1 (copy) ]]
		return p1:GetBoundingBox()
	end)

	if ok then
		local FoodNpcBillboardAnchor2 = Instance.new("Part")

		FoodNpcBillboardAnchor2.Name = "FoodNpcBillboardAnchor"
		FoodNpcBillboardAnchor2.Size = Vector3.new(0.1, 0.1, 0.1)
		FoodNpcBillboardAnchor2.Transparency = 1
		FoodNpcBillboardAnchor2.CanCollide = false
		FoodNpcBillboardAnchor2.CanQuery = false
		FoodNpcBillboardAnchor2.CanTouch = false
		FoodNpcBillboardAnchor2.CastShadow = false
		FoodNpcBillboardAnchor2.Anchored = true
		FoodNpcBillboardAnchor2.CFrame = result + result.UpVector * (result2.Y / 2 + 0.5)
		FoodNpcBillboardAnchor2.Parent = p1
		t4[p1] = FoodNpcBillboardAnchor2

		return FoodNpcBillboardAnchor2
	end

	warn("[FoodDropoffClient] GetBoundingBox failed for", p1.Name)

	return nil
end

local t5 = {}

local function createNameplate(p1) --[[ createNameplate | Line: 176 | Upvalues: getOrCreateBillboardAnchor (copy), t5 (copy), ReplicatedStorage (copy) ]]
	local v1 = getOrCreateBillboardAnchor(p1)

	if not v1 then
		return
	end

	local NpcNameplate = v1:FindFirstChild("NpcNameplate")

	if NpcNameplate then
		t5[p1] = NpcNameplate

		return
	end

	local v2 = ReplicatedStorage:FindFirstChild("shared")
	local v3 = if v2 then v2:FindFirstChild("model") else v2
	local v4 = if v3 then v3:FindFirstChild("NpcNameplateTemplate") else v3

	if not v4 then
		warn("[FoodDropoffClient] template \"NpcNameplateTemplate\" not found in ReplicatedStorage.shared.model")
	end

	if not v4 then
		return
	end

	local NpcNameplate2 = v4:Clone()

	NpcNameplate2.Name = "NpcNameplate"
	NpcNameplate2.Adornee = v1

	local NameLabel = NpcNameplate2:FindFirstChild("NameLabel")

	if NameLabel then
		NameLabel.Text = p1.Name
	end

	NpcNameplate2.Parent = v1
	t5[p1] = NpcNameplate2
end

local t6 = {}
local t7 = {}

local function showReaction(p1) --[[ showReaction | Line: 210 | Upvalues: getOrCreateBillboardAnchor (copy), ReplicatedStorage (copy), t6 (copy), t7 (copy), t5 (copy), SFX (copy), TurnInIntroSound (copy), playFeedAnimation (copy), ReactionPhrases (copy), EventConfig (copy), t2 (copy) ]]
	local v1 = getOrCreateBillboardAnchor(p1)

	if not v1 then
		return
	end

	local v2 = ReplicatedStorage:FindFirstChild("shared")
	local v3 = if v2 then v2:FindFirstChild("model") else v2
	local v4 = v3 and v3:FindFirstChild("NpcSpeechBillboardTemplate")

	if not v4 then
		warn("[FoodDropoffClient] template \"NpcSpeechBillboardTemplate\" not found in ReplicatedStorage.shared.model")
	end

	local v5 = v4

	if not v5 then
		return
	end

	local v6 = t6[p1]

	if v6 then
		v6:Destroy()
		t6[p1] = nil
	end

	local v7 = t7[p1]

	if v7 then
		pcall(task.cancel, v7)
	end

	local v8 = t5[p1]

	if v8 then
		v8.Enabled = true
	end

	t7[p1] = task.spawn(function() --[[ Line: 235 | Upvalues: SFX (ref), TurnInIntroSound (ref), playFeedAnimation (ref), p1 (copy), v8 (copy), v5 (copy), v1 (copy), t6 (ref), ReactionPhrases (ref), EventConfig (ref), t2 (ref), t7 (ref) ]]
		SFX.PlaySoundWithRandomPitch(TurnInIntroSound, 1, 1, 1)
		playFeedAnimation(p1)
		task.wait(2)

		if v8 then
			v8.Enabled = false
		end

		local FoodReactionBubble = v5:Clone()

		FoodReactionBubble.Name = "FoodReactionBubble"
		FoodReactionBubble.Adornee = v1

		local Bg = FoodReactionBubble:FindFirstChild("Bg")
		local v12 = if Bg then Bg:FindFirstChild("NpcName") else Bg
		local v2 = if Bg then Bg:FindFirstChild("SpeechText") else Bg

		if v12 then
			v12.Text = p1.Name
		end

		FoodReactionBubble.Parent = v1
		t6[p1] = FoodReactionBubble

		local v3 = ReactionPhrases[math.random(1, #ReactionPhrases)]
		local v4 = SFX.Sounds[EventConfig.Theme.ReactionVoiceSfx]

		if v4 then
			SFX.PlaySoundWithRandomPitch(v4, 0.8, 0.95, 1.05)
		end

		if v2 then
			v2.Text = ""

			for i = 1, #v3 do
				if t6[p1] ~= FoodReactionBubble then
					return
				end

				v2.Text = v3:sub(1, i)

				if v3:sub(i, i) ~= " " then
					SFX.PlaySoundWithRandomPitch(t2[math.random(1, #t2)], 0.8, 0.95, 1.05)
				end

				task.wait(0.03)
			end

			v2.Text = v3
		end

		task.wait(2.5)

		if t6[p1] ~= FoodReactionBubble then
			t7[p1] = nil

			return
		end

		FoodReactionBubble:Destroy()
		t6[p1] = nil

		if not v8 then
			t7[p1] = nil

			return
		end

		v8.Enabled = true
		t7[p1] = nil
	end)
end

local function playIdleAnimation(p1) --[[ playIdleAnimation | Line: 289 | Upvalues: DropoffIdleAnimation (copy) ]]
	local AnimationController = p1:FindFirstChild("AnimationController")

	if not AnimationController then
		return
	end

	local Animation = Instance.new("Animation")

	Animation.AnimationId = DropoffIdleAnimation

	local ok, result = pcall(function() --[[ Line: 296 | Upvalues: AnimationController (copy), Animation (copy) ]]
		return AnimationController:LoadAnimation(Animation)
	end)

	Animation:Destroy()

	if ok and result then
		result.Looped = true
		result:Play()
	end
end

local function getNpcAnchorPart(p1) --[[ getNpcAnchorPart | Line: 309 ]]
	return p1:FindFirstChild("PromptPart") or (p1:FindFirstChild("Head") or (p1.PrimaryPart or p1:FindFirstChildWhichIsA("BasePart", true)))
end

local function findNearestDropoffPart() --[[ findNearestDropoffPart | Line: 317 | Upvalues: LocalPlayer (copy), CollectionService (copy), FoodDropoffNpc (copy) ]]
	local Character = LocalPlayer.Character
	local v1 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character

	if not v1 then
		return nil
	end

	local v2 = (1 / 0)
	local v3 = nil

	for v4, v5 in CollectionService:GetTagged(FoodDropoffNpc) do
		if v5:IsA("Model") then
			local v6 = v5:FindFirstChild("PromptPart") or (v5:FindFirstChild("Head") or (v5.PrimaryPart or v5:FindFirstChildWhichIsA("BasePart", true)))

			if v6 then
				local Magnitude = (v6.Position - v1.Position).Magnitude

				if Magnitude < v2 then
					v2 = Magnitude
					v3 = v6
				end
			end
		end
	end

	return v3
end

local function isHoldingFood() --[[ isHoldingFood | Line: 340 | Upvalues: LocalPlayer (copy), t (copy) ]]
	local Character = LocalPlayer.Character

	if not Character then
		return false
	end

	local Tool = Character:FindFirstChildOfClass("Tool")

	if not Tool then
		return false
	end

	local UECS = t.UECS

	if not UECS then
		return false
	end

	return UECS:GetComponent(Tool, "Food") ~= nil
end

local function getHeldFoodConfig() --[[ getHeldFoodConfig | Line: 358 | Upvalues: LocalPlayer (copy), t (copy) ]]
	local Character = LocalPlayer.Character
	local v1 = if Character then Character:FindFirstChildOfClass("Tool") else Character
	local UECS = t.UECS

	if not (v1 and UECS) then
		return nil
	end

	local v2 = UECS:GetComponent(v1, "Food")

	if not v2 then
		return nil
	end

	local v3 = v2.ConfigName:Get()

	if type(v3) == "string" and v3 ~= "" then
		return v3
	end

	return nil
end

local function findCriticCatPlate() --[[ findCriticCatPlate | Line: 377 | Upvalues: CollectionService (copy), CookingStation (copy), PlatePart (copy) ]]
	for v1, v2 in CollectionService:GetTagged(CookingStation) do
		local v3 = v2:FindFirstChild(PlatePart)

		if v3 and v3:IsA("BasePart") then
			return v3
		end
	end

	return nil
end

local v3 = nil

local function showFoodOnPlate(p1) --[[ showFoodOnPlate | Line: 390 | Upvalues: findCriticCatPlate (copy), getFoodModelTemplate (copy), v3 (ref), v2 (copy) ]]
	local v1 = findCriticCatPlate()

	if not v1 then
		return
	end

	local v22 = getFoodModelTemplate(p1)

	if not (v22 and (v22:IsA("Model") and v22.PrimaryPart)) then
		return
	end

	if v3 then
		v3:Destroy()
		v3 = nil
	end

	local v32 = v22:Clone()

	for v4, v5 in v32:GetDescendants() do
		if v5:IsA("BasePart") then
			v5.Anchored = true
			v5.CanCollide = false
			v5.CanQuery = false
		end
	end

	v32:PivotTo(v2)

	local _, v6 = v32:GetBoundingBox()

	v32.Parent = v1
	v32:PivotTo(CFrame.new(v1.Position.X, v1.Position.Y + v1.Size.Y / 2 + v6.Y / 2, v1.Position.Z) * v2)
	v3 = v32
	task.delay(2, function() --[[ Line: 422 | Upvalues: v3 (ref), v32 (copy) ]]
		if v3 ~= v32 then
			v32:Destroy()

			return
		end

		v3 = nil
		v32:Destroy()
	end)
end

local function setupNpc(p1) --[[ setupNpc | Line: 430 | Upvalues: v1 (copy), getHeldFoodConfig (copy), Remotes (copy), showFoodOnPlate (copy), createNameplate (copy), playIdleAnimation (copy), isHoldingFood (copy) ]]
	if not p1:IsA("Model") then
		return
	end

	local v12 = p1:FindFirstChild("PromptPart") or (p1:FindFirstChild("Head") or (p1.PrimaryPart or p1:FindFirstChildWhichIsA("BasePart", true)))

	if v12 then
		local ProximityPrompt = Instance.new("ProximityPrompt")

		ProximityPrompt.Style = Enum.ProximityPromptStyle.Custom
		ProximityPrompt.ActionText = "Give Food"
		ProximityPrompt.ObjectText = p1.Name
		ProximityPrompt.HoldDuration = 0
		ProximityPrompt.MaxActivationDistance = 10
		ProximityPrompt.RequiresLineOfSight = false
		ProximityPrompt.Enabled = false
		ProximityPrompt.KeyboardKeyCode = Enum.KeyCode.F
		ProximityPrompt.UIOffset = v1
		ProximityPrompt.Exclusivity = Enum.ProximityPromptExclusivity.AlwaysShow
		ProximityPrompt.Parent = v12
		ProximityPrompt.Triggered:Connect(function() --[[ Line: 456 | Upvalues: getHeldFoodConfig (ref), Remotes (ref), p1 (copy), showFoodOnPlate (ref) ]]
			local v1 = getHeldFoodConfig()

			Remotes.TurnInFood:Fire(p1)

			if not v1 then
				return
			end

			showFoodOnPlate(v1)
		end)
		createNameplate(p1)
		playIdleAnimation(p1)
		task.spawn(function() --[[ Line: 469 | Upvalues: p1 (copy), isHoldingFood (ref), ProximityPrompt (copy) ]]
			while p1.Parent do
				local ok, result = pcall(isHoldingFood)

				ProximityPrompt.Enabled = ok and result
				task.wait(0.25)
			end
		end)
	else
		warn("[FoodDropoffClient] no BasePart found on", p1.Name)
	end
end

function t.Init(p1) --[[ Init | Line: 480 | Upvalues: DropoffIdleAnimation (copy), DropoffFeedAnimation (copy), ContentProvider (copy), CollectionService (copy), FoodDropoffNpc (copy), setupNpc (copy), Remotes (copy), showReaction (copy), isHoldingFood (copy), findNearestDropoffPart (copy), BeamTo (copy) ]]
	task.spawn(function() --[[ Line: 481 | Upvalues: DropoffIdleAnimation (ref), DropoffFeedAnimation (ref), ContentProvider (ref) ]]
		local t = {}

		for v1, v2 in { DropoffIdleAnimation, DropoffFeedAnimation } do
			local Animation = Instance.new("Animation")

			Animation.AnimationId = v2
			table.insert(t, Animation)
		end

		ContentProvider:PreloadAsync(t)

		for v3, v4 in t do
			v4:Destroy()
		end
	end)

	for v1, v2 in CollectionService:GetTagged(FoodDropoffNpc) do
		task.spawn(setupNpc, v2)
	end

	CollectionService:GetInstanceAddedSignal(FoodDropoffNpc):Connect(function(p1) --[[ Line: 497 | Upvalues: setupNpc (ref) ]]
		task.spawn(setupNpc, p1)
	end)
	Remotes.FoodTurnInReaction:On(function(p1) --[[ Line: 502 | Upvalues: CollectionService (ref), FoodDropoffNpc (ref), showReaction (ref) ]]
		if typeof(p1) ~= "table" then
			return
		end

		local Npc = p1.Npc

		if typeof(Npc) == "Instance" and (Npc:IsA("Model") and CollectionService:HasTag(Npc, FoodDropoffNpc)) then
			showReaction(Npc)
		end
	end)
	task.spawn(function() --[[ Line: 516 | Upvalues: isHoldingFood (ref), findNearestDropoffPart (ref), BeamTo (ref) ]]
		local v1 = false

		while true do
			local v2
			local ok, result = pcall(isHoldingFood)

			v2 = if ok and result then findNearestDropoffPart() else nil

			if v2 then
				BeamTo(v2)
				v1 = true
			elseif v1 then
				BeamTo(nil)
				v1 = false
			end

			task.wait(0.25)
		end
	end)
end

return t