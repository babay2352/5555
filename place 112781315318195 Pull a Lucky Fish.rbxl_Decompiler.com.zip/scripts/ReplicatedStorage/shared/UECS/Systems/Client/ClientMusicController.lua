-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local SoundService = game:GetService("SoundService")
local TweenService = game:GetService("TweenService")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local GetSignal = require(ReplicatedStorage.shared.util.GetSignal)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local topbarplus = require(ReplicatedStorage.client.Satchel.Package.topbarplus)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local LocalPlayer = Players.LocalPlayer
local t = {
	UECS = nil
}
local v1 = nil
local v2 = nil
local v3 = nil
local v4 = nil
local v5 = nil
local v6 = 1
local v7 = false
local v8 = false
local v9 = 1
local v10 = nil
local v11 = false
local v12 = 0

local function isSilenced() --[[ isSilenced | Line: 49 | Upvalues: v7 (ref), v8 (ref), v11 (ref) ]]
	return v7 or (v8 or v11)
end

local function eventTargetVolume(p1) --[[ eventTargetVolume | Line: 54 | Upvalues: v7 (ref), v8 (ref), v6 (ref), v9 (ref) ]]
	if v7 or v8 then
		return 0
	end

	return (p1:GetAttribute("Volume") or p1.Volume) * v6 * v9
end

local function trackTargetVolume() --[[ trackTargetVolume | Line: 61 | Upvalues: v3 (ref), v6 (ref), v9 (ref) ]]
	if not v3 then
		return v6 * v9
	end

	return (v3:GetAttribute("Volume") or v3.Volume) * v6 * v9
end

local function getVolumeTween(p1, p2, p3) --[[ getVolumeTween | Line: 69 | Upvalues: TweenService (copy) ]]
	return TweenService:Create(p1, TweenInfo.new(p3), {
		Volume = p2
	})
end

local function getRandomTrackFromFolder(p1) --[[ getRandomTrackFromFolder | Line: 73 ]]
	local v1 = p1:GetChildren()

	if #v1 == 0 then
		return nil
	end

	return v1[math.random(1, #v1)]
end

local function v13(p1) --[[ trackInit | Line: 81 | Upvalues: v1 (ref), v2 (ref), v3 (ref), TweenService (copy), LocalPlayer (copy), v4 (ref), v6 (ref), v9 (ref), v7 (ref), v8 (ref), v11 (ref), v5 (ref), v13 (copy) ]]
	if not (v1 and v2) then
		return
	end

	local v12 = v1:FindFirstChild(p1)

	if not v12 then
		warn((("[ClientMusicController] no track folder: %*"):format(p1)))

		return
	end

	local v22 = v12:GetChildren()
	local v32 = if #v22 == 0 then nil else v22[math.random(1, #v22)]

	if not v32 then
		warn((("[ClientMusicController] no tracks in folder: %*"):format(p1)))

		return
	end

	if v3 and v3 ~= v32 then
		local v42 = TweenService:Create(v2, TweenInfo.new(1), {
			Volume = 0
		})

		v42:Play()
		v42.Completed:Wait()
		v3:Stop()
	end

	if LocalPlayer:GetAttribute("CurrentMusicFolder") ~= p1 then
		return
	end

	v3 = v32
	v4 = p1

	local v52 = v32:GetAttribute("Volume") or v32.Volume
	local v62 = v32:GetAttribute("Start")

	v2.TimePosition = 0

	if v62 then
		v2.TimePosition = v62
	end

	if v32:HasTag("VisualizeWhenPlaying") then
		v2:AddTag("Visualize")
	else
		v2:RemoveTag("Visualize")
	end

	v2.SoundId = v32.SoundId

	local v82 = v2
	local v112 = TweenService:Create(v82, TweenInfo.new(1), {
		Volume = if v7 or v8 or v11 then 0 else v52 * (v6 * v9)
	})

	v2:Play()
	v112:Play()
	LocalPlayer:SetAttribute("CurrentMusicFolder", p1)

	if not v5 then
		v5 = task.spawn(function() --[[ Line: 140 | Upvalues: v2 (ref), LocalPlayer (ref), v4 (ref), v13 (ref), p1 (copy) ]]
			v2.Ended:Wait()

			if LocalPlayer:GetAttribute("CurrentMusicFolder") ~= v4 then
				return
			end

			v13(p1)
		end)

		return
	end

	pcall(task.cancel, v5)
	v5 = task.spawn(function() --[[ Line: 140 | Upvalues: v2 (ref), LocalPlayer (ref), v4 (ref), v13 (ref), p1 (copy) ]]
		v2.Ended:Wait()

		if LocalPlayer:GetAttribute("CurrentMusicFolder") ~= v4 then
			return
		end

		v13(p1)
	end)
end

function t.SetMuted(p1, p2) --[[ SetMuted | Line: 154 | Upvalues: v7 (ref), v10 (ref), v8 (ref), v6 (ref), v9 (ref), TweenService (copy), v2 (ref), v11 (ref), v3 (ref) ]]
	if p1 == v7 then
		return
	end

	v7 = p1

	local v1 = p2 or 0.3

	if v10 then
		local v32 = v10
		local v4 = if p1 or v8 then 0 else (v32:GetAttribute("Volume") or v32.Volume) * v6 * v9

		TweenService:Create(v10, TweenInfo.new(v1), {
			Volume = v4
		}):Play()
	end

	if not v2 then
		return
	end

	local v82 = if p1 or v8 or v11 then 0 elseif v3 then (v3:GetAttribute("Volume") or v3.Volume) * v6 * v9 else v6 * v9

	TweenService:Create(v2, TweenInfo.new(v1), {
		Volume = v82
	}):Play()
end
function t.SetUserMuted(p1) --[[ SetUserMuted | Line: 171 | Upvalues: v8 (ref), v10 (ref), v7 (ref), v6 (ref), v9 (ref), TweenService (copy), v2 (ref), v11 (ref), v3 (ref) ]]
	if p1 == v8 then
		return
	end

	v8 = p1

	if v10 then
		local v22 = v10
		local v32 = if v7 or p1 then 0 else (v22:GetAttribute("Volume") or v22.Volume) * v6 * v9

		TweenService:Create(v10, TweenInfo.new(0.3), {
			Volume = v32
		}):Play()
	end

	if not v2 then
		return
	end

	local v72 = if v7 or p1 or v11 then 0 elseif v3 then (v3:GetAttribute("Volume") or v3.Volume) * v6 * v9 else v6 * v9

	TweenService:Create(v2, TweenInfo.new(0.3), {
		Volume = v72
	}):Play()
end
function t.IsUserMuted() --[[ IsUserMuted | Line: 185 | Upvalues: v8 (ref) ]]
	return v8
end
function t.SetDucked(p1) --[[ SetDucked | Line: 193 | Upvalues: v9 (ref), v10 (ref), v7 (ref), v8 (ref), v6 (ref), TweenService (copy), v2 (ref), v11 (ref), v3 (ref) ]]
	local v1 = math.clamp(p1, 0, 1)

	if v1 == v9 then
		return
	end

	v9 = v1

	if v10 then
		local v32 = v10
		local v4 = if v7 or v8 then 0 else (v32:GetAttribute("Volume") or v32.Volume) * v6 * v1

		TweenService:Create(v10, TweenInfo.new(0.3), {
			Volume = v4
		}):Play()
	end

	if not v2 then
		return
	end

	local v82 = if v7 or v8 or v11 then 0 elseif v3 then (v3:GetAttribute("Volume") or v3.Volume) * v6 * v1 else v6 * v1

	TweenService:Create(v2, TweenInfo.new(0.3), {
		Volume = v82
	}):Play()
end
function t.PlayEventMusic(p1, p2) --[[ PlayEventMusic | Line: 219 | Upvalues: v12 (ref), SoundService (copy), v10 (ref), TweenService (copy), v11 (ref), v2 (ref), v7 (ref), v8 (ref), v6 (ref), v9 (ref) ]]
	v12 = v12 + 1

	local v1 = v12
	local v22

	if string.match(p1, "^rbxassetid://") then
		local Sound = Instance.new("Sound")

		Sound.SoundId = p1
		Sound.Volume = p2 or 0.5
		v22 = Sound
	else
		local v3 = SoundService:FindFirstChild(p1, true)

		v22 = if v3 and v3:IsA("Sound") then v3 else nil
	end

	if not v22 then
		warn((("[ClientMusicController] event track \'%*\' not found under SoundService"):format(p1)))

		return v1
	end

	local v4 = if v10 == nil then false else true

	if v10 then
		local v5 = v10

		v10 = nil
		TweenService:Create(v5, TweenInfo.new(0.5), {
			Volume = 0
		}):Play()
		task.delay(0.6, function() --[[ Line: 244 | Upvalues: v5 (copy) ]]
			v5:Destroy()
		end)
	end

	v11 = true

	if v2 then
		TweenService:Create(v2, TweenInfo.new(if v4 then 0.5 else 2), {
			Volume = 0
		}):Play()
	end

	local function startTrack() --[[ startTrack | Line: 256 | Upvalues: v1 (copy), v12 (ref), v22 (ref), SoundService (ref), v10 (ref), v7 (ref), v8 (ref), v6 (ref), v9 (ref), TweenService (ref) ]]
		if v1 == v12 then
			local v13 = v22:Clone()

			v13:SetAttribute("Volume", v22:GetAttribute("Volume") or v22.Volume)

			if not v22.Parent then
				v22:Destroy()
			end

			v13.Looped = true
			v13.PlayOnRemove = false
			v13.Volume = 0
			v13.Parent = SoundService:FindFirstChild("SFX") or SoundService
			v13:Play()
			v10 = v13

			local v5 = if v7 or v8 then 0 else (v13:GetAttribute("Volume") or v13.Volume) * v6 * v9

			TweenService:Create(v13, TweenInfo.new(1), {
				Volume = v5
			}):Play()
		else
			if v22.Parent then
				return
			end

			v22:Destroy()
		end
	end

	if v4 then
		startTrack()
	else
		task.delay(2, startTrack)
	end

	return v1
end
function t.StopEventMusic(p1, p2) --[[ StopEventMusic | Line: 298 | Upvalues: v12 (ref), v10 (ref), TweenService (copy), v11 (ref), v2 (ref), v7 (ref), v8 (ref), v3 (ref), v6 (ref), v9 (ref) ]]
	if p1 ~= nil and p1 ~= v12 then
		return
	end

	v12 = v12 + 1

	local v1 = p2 or 2

	if v10 then
		local v22 = v10

		v10 = nil
		TweenService:Create(v22, TweenInfo.new(v1), {
			Volume = 0
		}):Play()
		task.delay(v1 + 0.1, function() --[[ Line: 308 | Upvalues: v22 (copy) ]]
			v22:Destroy()
		end)
	end

	v11 = false

	if not v2 then
		return
	end

	local v5 = if v7 or v8 or v11 then 0 elseif v3 then (v3:GetAttribute("Volume") or v3.Volume) * v6 * v9 else v6 * v9

	TweenService:Create(v2, TweenInfo.new(v1), {
		Volume = v5
	}):Play()
end
function t.Init(p1) --[[ Init | Line: 318 | Upvalues: v1 (ref), SoundService (copy), v2 (ref), LocalPlayer (copy), v4 (ref), v13 (copy), GetSignal (copy), v6 (ref), v3 (ref), topbarplus (copy), t (copy), Remotes (copy), v8 (ref), ClientPlayerData (copy) ]]
	v1 = SoundService:FindFirstChild("Music")

	if not v1 then
		warn("[ClientMusicController] SoundService.Music not found; music disabled")

		return
	end

	local Audio = v1:WaitForChild("Audio", 10)

	if not Audio then
		warn("[ClientMusicController] SoundService.Music.Audio not found; music disabled")

		return
	end

	v2 = Audio:WaitForChild("AudioPlayer", 10)

	if not v2 then
		warn("[ClientMusicController] AudioPlayer not found; music disabled")

		return
	end

	local v12 = false

	LocalPlayer:GetAttributeChangedSignal("CurrentMusicFolder"):Connect(function() --[[ Line: 342 | Upvalues: v12 (ref), LocalPlayer (ref), v4 (ref), v13 (ref) ]]
		if not v12 then
			return
		end

		local v1 = LocalPlayer:GetAttribute("CurrentMusicFolder")

		if typeof(v1) ~= "string" or v1 == v4 then
			return
		end

		v13(v1)
	end)
	GetSignal("SettingsChanged"):Connect(function(p1, p2) --[[ Line: 352 | Upvalues: v6 (ref), v3 (ref), v2 (ref) ]]
		if p2 ~= "musicVolume" then
			return
		end

		v6 = p1 / 100

		if not (v3 and v2) then
			return
		end

		v2.Volume = (v3:GetAttribute("Volume") or 0.5) * v6
	end)
	workspace:GetAttributeChangedSignal("CurrentMusicFolder"):Connect(function() --[[ Line: 363 | Upvalues: LocalPlayer (ref) ]]
		LocalPlayer:SetAttribute("CurrentMusicFolder", workspace:GetAttribute("CurrentMusicFolder") or "Start")
	end)

	local v22 = topbarplus.new()

	v22:setName("MusicToggle")
	v22:setRight()
	v22:setEnabled(false)
	v22:autoDeselect(false)

	local function applyAppearance(p1) --[[ applyAppearance | Line: 385 | Upvalues: v22 (copy) ]]
		local v1 = if p1 then "rbxassetid://110896073236215" else "rbxassetid://110848612479824"

		if v1 == "" then
			v22:setLabel(if p1 then "Music: Off" else "Music: On")
		else
			v22:setImage(v1)
			v22:setLabel("")
		end

		v22:setCaption(if p1 then "Unmute music" else "Mute music")
	end

	v22:bindEvent("selected", function() --[[ Line: 396 | Upvalues: t (ref), v22 (copy), Remotes (ref) ]]
		t.SetUserMuted(true)
		v22:setImage("rbxassetid://110896073236215")
		v22:setLabel("")
		v22:setCaption("Unmute music")
		Remotes.SetPlayerSetting:Fire({
			settingName = "musicEnabled",
			enabled = false
		})
	end)
	v22:bindEvent("deselected", function() --[[ Line: 401 | Upvalues: t (ref), v22 (copy), Remotes (ref) ]]
		t.SetUserMuted(false)
		v22:setImage("rbxassetid://110848612479824")
		v22:setLabel("")
		v22:setCaption("Mute music")
		Remotes.SetPlayerSetting:Fire({
			settingName = "musicEnabled",
			enabled = true
		})
	end)

	local v32 = v8
	local v42 = if v32 then "rbxassetid://110896073236215" else "rbxassetid://110848612479824"

	if v42 == "" then
		v22:setLabel(if v32 then "Music: Off" else "Music: On")
	else
		v22:setImage(v42)
		v22:setLabel("")
	end

	v22:setCaption(if v32 then "Unmute music" else "Mute music")

	local function applyMusicSetting(p1) --[[ applyMusicSetting | Line: 413 | Upvalues: t (ref), v22 (copy) ]]
		local v1 = if p1 then p1.musicEnabled ~= false else true

		t.SetUserMuted(not v1)

		local v2 = not v1
		local v3 = if v2 then "rbxassetid://110896073236215" else "rbxassetid://110848612479824"

		if v3 == "" then
			v22:setLabel(if v2 then "Music: Off" else "Music: On")
		else
			v22:setImage(v3)
			v22:setLabel("")
		end

		v22:setCaption(if v2 then "Unmute music" else "Mute music")

		if not (v1 or v22.isSelected) then
			v22:select()

			return
		end

		if not (v1 and v22.isSelected) then
			return
		end

		v22:deselect()
	end

	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 424 ]]
		return p1.settings
	end, applyMusicSetting)
	applyMusicSetting(ClientPlayerData.serverProfile:getState().settings)
	task.spawn(function() --[[ Line: 430 | Upvalues: ClientPlayerData (ref), applyMusicSetting (copy), LocalPlayer (ref), v12 (ref), v13 (ref) ]]
		if not ClientPlayerData.isPlayerDataLoaded then
			ClientPlayerData.playerDataLoadedSignal:Wait()
		end

		applyMusicSetting(ClientPlayerData.serverProfile:getState().settings)

		local sum = 0

		while not LocalPlayer:GetAttribute("LoadingScreenFinished") and sum < 120 do
			sum = sum + task.wait(0.25)
		end

		v12 = true

		local v1 = LocalPlayer:GetAttribute("CurrentMusicFolder")

		if typeof(v1) ~= "string" then
			v1 = "Start"
		end

		LocalPlayer:SetAttribute("CurrentMusicFolder", v1)
		v13(v1)
	end)
end

return t