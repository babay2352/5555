-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ContextActionService = game:GetService("ContextActionService")
local MarketplaceService = game:GetService("MarketplaceService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local ConvertValue = require(ReplicatedStorage.shared.util.ConvertValue)
local FishRodConfig = require(ReplicatedStorage.shared.config.FishRodConfig)
local FishingFloatsConfig = require(ReplicatedStorage.shared.config.FishingFloatsConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local MonetizationConfig = require(ReplicatedStorage.shared.config.MonetizationConfig)
local Rebirth = require(ReplicatedStorage.shared.UECS.Components.Rebirth)
local RebirthConfig = require(ReplicatedStorage.shared.config.RebirthConfig)
local RebirthUnlocksConfig = require(ReplicatedStorage.shared.config.RebirthUnlocksConfig)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local SFX = require(ReplicatedStorage.client.SFX)
local VFX = require(ReplicatedStorage.client.VFX)
local bindToButtonPress = require(ReplicatedStorage.shared.util.bindToButtonPress)
local v1 = Color3.fromRGB(255, 255, 255)
local v2 = Color3.fromRGB(0, 0, 0)

local function showRebirthBanner() --[[ showRebirthBanner | Line: 51 | Upvalues: Players (copy), v1 (copy), v2 (copy), TweenService (copy) ]]
	local PlayerGui = Players.LocalPlayer:FindFirstChildOfClass("PlayerGui")

	if PlayerGui then
		local RebirthBanner = Instance.new("ScreenGui")

		RebirthBanner.Name = "RebirthBanner"
		RebirthBanner.ResetOnSpawn = false
		RebirthBanner.DisplayOrder = 100
		RebirthBanner.IgnoreGuiInset = true
		RebirthBanner.Parent = PlayerGui

		local Frame = Instance.new("Frame")

		Frame.Size = UDim2.fromScale(1, 1)
		Frame.BackgroundColor3 = Color3.new(0/255, 0/255, 0/255)
		Frame.BackgroundTransparency = 1
		Frame.BorderSizePixel = 0
		Frame.Parent = RebirthBanner

		local TextLabel = Instance.new("TextLabel")

		TextLabel.AnchorPoint = Vector2.new(0.5, 0.5)
		TextLabel.Position = UDim2.fromScale(0.5, 0.5)
		TextLabel.Size = UDim2.fromScale(0.8, 0.2)
		TextLabel.BackgroundTransparency = 1
		TextLabel.Text = "NEW REBIRTH LEVEL!"
		TextLabel.TextColor3 = v1
		TextLabel.TextTransparency = 1
		TextLabel.TextStrokeTransparency = 1
		TextLabel.Font = Enum.Font.GothamBlack
		TextLabel.TextScaled = true
		TextLabel.Parent = RebirthBanner

		local UIStroke = Instance.new("UIStroke")

		UIStroke.Color = v2
		UIStroke.Thickness = 3
		UIStroke.Transparency = 1
		UIStroke.Parent = TextLabel

		local v12 = TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

		TweenService:Create(Frame, v12, {
			BackgroundTransparency = 0.4
		}):Play()
		TweenService:Create(TextLabel, v12, {
			TextTransparency = 0
		}):Play()
		TweenService:Create(UIStroke, v12, {
			Transparency = 0
		}):Play()
		task.delay(1.8, function() --[[ Line: 95 | Upvalues: TweenService (ref), Frame (copy), TextLabel (copy), UIStroke (copy), RebirthBanner (copy) ]]
			local v1 = TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.In)

			TweenService:Create(Frame, v1, {
				BackgroundTransparency = 1
			}):Play()
			TweenService:Create(TextLabel, v1, {
				TextTransparency = 1
			}):Play()
			TweenService:Create(UIStroke, v1, {
				Transparency = 1
			}):Play()
			task.delay(0.4, function() --[[ Line: 100 | Upvalues: RebirthBanner (ref) ]]
				RebirthBanner:Destroy()
			end)
		end)
	end
end

local function playJumpBackflip(p1) --[[ playJumpBackflip | Line: 110 | Upvalues: RunService (copy) ]]
	local Humanoid = p1:FindFirstChildOfClass("Humanoid")
	local HumanoidRootPart = p1:FindFirstChild("HumanoidRootPart")

	if Humanoid and (HumanoidRootPart and HumanoidRootPart:IsA("BasePart")) then
		local PlatformStand = Humanoid.PlatformStand
		local Anchored = HumanoidRootPart.Anchored

		Humanoid.PlatformStand = true
		HumanoidRootPart.Anchored = true

		local v1 = HumanoidRootPart.CFrame

		task.spawn(function() --[[ Line: 124 | Upvalues: HumanoidRootPart (copy), v1 (copy), RunService (ref), Anchored (copy), Humanoid (copy), PlatformStand (copy) ]]
			local v12 = os.clock()

			while HumanoidRootPart.Parent do
				local v3 = math.min((os.clock() - v12) / 0.85, 1)

				HumanoidRootPart.CFrame = v1 * CFrame.Angles(-v3 * math.pi * 2 * 1, 0, 0) + Vector3.new(0, v3 * 56 * (1 - v3), 0)

				if v3 >= 1 then
					HumanoidRootPart.CFrame = v1
					HumanoidRootPart.Anchored = Anchored
					Humanoid.PlatformStand = PlatformStand

					return
				end

				RunService.Heartbeat:Wait()
			end
		end)
	end
end

return {
	UECS = nil,
	Priority = 30,
	Init = function(p1) --[[ Init | Line: 150 | Upvalues: Players (copy), Rebirth (copy), bindToButtonPress (copy), ClientPlayerData (copy), RebirthConfig (copy), Remotes (copy), MarketplaceService (copy), MonetizationConfig (copy), ContextActionService (copy), TweenService (copy), RebirthUnlocksConfig (copy), FishRodConfig (copy), FishingFloatsConfig (copy), ConvertValue (copy), SFX (copy), VFX (copy), playJumpBackflip (copy), showRebirthBanner (copy) ]]
		local MainUI = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI")
		local Rebirth2 = MainUI:WaitForChild("Rebirth")
		local v1 = Rebirth2:WaitForChild("Content")
		local TopBar = Rebirth2:WaitForChild("TopBar")
		local Rebirth3 = v1:WaitForChild("Rebirth")
		local BuyDP = v1:WaitForChild("BuyDP")
		local Reward = v1:WaitForChild("Reward")
		local CashMultiplierBefore = Reward:FindFirstChild("CashMultiplierBefore")
		local CashMultiplierAfter = Reward:FindFirstChild("CashMultiplierAfter")
		local v2 = if CashMultiplierBefore then CashMultiplierBefore:FindFirstChild("Counter") else nil
		local v3 = if CashMultiplierAfter then CashMultiplierAfter:FindFirstChild("Counter") else nil
		local Requires = v1:WaitForChild("Requires")
		local TextLabel = Requires:WaitForChild("TextLabel")
		local CollectBar = Requires:WaitForChild("CollectBar")
		local Bar = CollectBar:WaitForChild("Bar")
		local NumberProgress = CollectBar:WaitForChild("NumberProgress")
		local ScrollingFrame = v1:FindFirstChild("ScrollingFrame")

		if ScrollingFrame then
			local Template = ScrollingFrame:FindFirstChild("Template")

			if Template and Template:IsA("GuiObject") then
				Template.Visible = false
			end
		end

		local Rewards = Reward:FindFirstChild("Rewards")
		local v4 = if Rewards then Rewards:FindFirstChild("Template") else nil
		local v5 = if v4 then v4.Size.X.Scale else 0

		if Rewards and v4 then
			v4.Visible = false

			local UIListLayout = Rewards:FindFirstChildOfClass("UIListLayout")

			if UIListLayout then
				UIListLayout.FillDirection = Enum.FillDirection.Horizontal
				UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder
				UIListLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center
				UIListLayout.VerticalAlignment = Enum.VerticalAlignment.Center
				UIListLayout.Padding = UDim.new(0.02, 0)
			end
		end

		Rebirth2.Visible = false
		Rebirth.Add(Rebirth2).Visible.OnChange:Connect(function(p12, p2) --[[ Line: 203 | Upvalues: Rebirth2 (copy), bindToButtonPress (ref), ClientPlayerData (ref), RebirthConfig (ref), Remotes (ref), p1 (copy), MarketplaceService (ref), Players (ref), MonetizationConfig (ref), ContextActionService (ref) ]]
			Rebirth2.Visible = p12

			if p12 == p2 then
				return
			end

			if p12 then
				bindToButtonPress("RebirthAction", Enum.KeyCode.ButtonX, function() --[[ Line: 208 | Upvalues: ClientPlayerData (ref), RebirthConfig (ref), Remotes (ref), p1 (ref) ]]
					local v1 = ClientPlayerData.serverProfile:getState()
					local v3 = RebirthConfig.Config[(v1.rebirthLevel or 0) + 1]

					if v3 and not ((v1.strength or 0) < v3.RequiredStrength) then
						Remotes.RequestRebirth:Fire()
						p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
					end
				end)
				bindToButtonPress("RebirthCloseAction", Enum.KeyCode.ButtonB, function() --[[ Line: 222 | Upvalues: p1 (ref) ]]
					p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
				end)
				bindToButtonPress("RebirthDPAction", Enum.KeyCode.ButtonY, function() --[[ Line: 227 | Upvalues: ClientPlayerData (ref), RebirthConfig (ref), MarketplaceService (ref), Players (ref), MonetizationConfig (ref) ]]
					if RebirthConfig.Config[(ClientPlayerData.serverProfile:getState().rebirthLevel or 0) + 1] then
						MarketplaceService:PromptProductPurchase(Players.LocalPlayer, MonetizationConfig.DevProducts.SkipRebirthReset.ProductId)
					end
				end)

				return
			end

			ContextActionService:UnbindAction("RebirthAction")
			ContextActionService:UnbindAction("RebirthCloseAction")
			ContextActionService:UnbindAction("RebirthDPAction")
		end)
		TopBar:WaitForChild("CloseButton").MouseButton1Down:Connect(function() --[[ Line: 247 | Upvalues: p1 (copy) ]]
			p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
		end)
		BuyDP.MouseButton1Down:Connect(function() --[[ Line: 252 | Upvalues: ClientPlayerData (ref), RebirthConfig (ref), MarketplaceService (ref), Players (ref), MonetizationConfig (ref) ]]
			if RebirthConfig.Config[(ClientPlayerData.serverProfile:getState().rebirthLevel or 0) + 1] then
				MarketplaceService:PromptProductPurchase(Players.LocalPlayer, MonetizationConfig.DevProducts.SkipRebirthReset.ProductId)
			end
		end)
		Rebirth3.MouseButton1Down:Connect(function() --[[ Line: 264 | Upvalues: ClientPlayerData (ref), RebirthConfig (ref), Remotes (ref), p1 (copy) ]]
			local v1 = ClientPlayerData.serverProfile:getState()
			local v3 = RebirthConfig.Config[(v1.rebirthLevel or 0) + 1]

			if v3 and not ((v1.strength or 0) < v3.RequiredStrength) then
				Remotes.RequestRebirth:Fire()
				p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
			end
		end)

		local Alert = MainUI:WaitForChild("HUD"):WaitForChild("Buttons"):WaitForChild("Rebirth"):WaitForChild("Alert")

		Alert.Visible = false
		Alert.Rotation = 0

		local v6 = nil

		local function setAlertActive(p1) --[[ setAlertActive | Line: 286 | Upvalues: Alert (copy), v6 (ref), TweenService (ref) ]]
			if p1 then
				if not Alert.Visible then
					Alert.Visible = true
					Alert.Rotation = -8
					v6 = TweenService:Create(Alert, TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true), {
						Rotation = 8
					})
					v6:Play()
				end
			else
				if not v6 then
					Alert.Rotation = 0
					Alert.Visible = false

					return
				end

				v6:Cancel()
				v6 = nil
				Alert.Rotation = 0
				Alert.Visible = false
			end
		end

		local t = {}
		local v7 = nil

		local function collectRewards(p1, p2) --[[ collectRewards | Line: 320 | Upvalues: RebirthConfig (ref), RebirthUnlocksConfig (ref), FishRodConfig (ref), FishingFloatsConfig (ref) ]]
			local t = {
				{
					Icon = "rbxassetid://135287528028888",
					Text = ("x%* Cash"):format(p2.CashMultiplier)
				}
			}

			if p1 <= RebirthConfig.STRENGTH_BONUS_MAX_LEVEL then
				table.insert(t, {
					Icon = "rbxassetid://136868578369874",
					Text = ("+%*%% Strength Gain"):format((math.round((RebirthConfig.getStrengthMultiplier(p1) - 1) * 100)))
				})
			end

			local v2 = RebirthUnlocksConfig.getByRebirthLevel(p1)

			if v2 then
				table.insert(t, {
					Text = v2.DisplayName,
					Icon = v2.Icon
				})
			end

			for v4, v5 in p2.ExtraRewards or {} do
				table.insert(t, {
					Text = v5.Name,
					Icon = v5.Icon
				})
			end

			local t2 = {}

			for v6, v7 in FishRodConfig do
				if v7.RebirthRequired == p1 then
					table.insert(t2, v7)
				end
			end

			table.sort(t2, function(p1, p2) --[[ Line: 351 ]]
				if p1.Cost == p2.Cost then
					return p1.ConfigName < p2.ConfigName
				end

				return p1.Cost < p2.Cost
			end)

			for v8, v9 in t2 do
				table.insert(t, {
					Text = v9.DisplayName,
					Icon = v9.Icon
				})
			end

			local t3 = {}

			for v10, v11 in FishingFloatsConfig.FloatSlots do
				if not v11.Premium and v11.RebirthRequired == p1 then
					table.insert(t3, v10)
				end
			end

			table.sort(t3)

			for v12, v13 in t3 do
				table.insert(t, {
					Text = ("Float Slot %*"):format(v13),
					Icon = FishingFloatsConfig.FloatSlots[v13].Icon
				})
			end

			return t
		end

		local function buildRewards(p1, p2) --[[ buildRewards | Line: 378 | Upvalues: Rewards (copy), v4 (copy), v7 (ref), t (copy), collectRewards (copy), v5 (copy) ]]
			if not (Rewards and v4) then
				return
			end

			if v7 == p1 then
				return
			end

			v7 = p1

			for v1, v2 in t do
				v2:Destroy()
			end

			table.clear(t)

			if not p2 then
				return
			end

			local v3 = collectRewards(p1, p2)
			local v42 = v5

			if v42 > 0 then
				v42 = math.min(v42, (1 - (#v3 - 1) * 0.02) / #v3)
			end

			for v6, v72 in v3 do
				local v8 = v4:Clone()

				v8.Name = ("Reward%*"):format(v6)
				v8.LayoutOrder = v6
				v8.Visible = true

				if v42 > 0 then
					v8.Size = UDim2.new(v42, 0, v8.Size.Y.Scale, v8.Size.Y.Offset)
				end

				if v72.Icon then
					v8.Image = v72.Icon
				end

				local Name = v8:FindFirstChild("Name")

				if Name then
					Name.Text = v72.Text
				end

				v8.Parent = Rewards
				table.insert(t, v8)
			end
		end

		local function refresh() --[[ refresh | Line: 428 | Upvalues: ClientPlayerData (ref), RebirthConfig (ref), v2 (copy), buildRewards (copy), TextLabel (copy), v3 (copy), NumberProgress (copy), ConvertValue (ref), Bar (copy), Rebirth3 (copy), BuyDP (copy), setAlertActive (copy) ]]
			local v1 = ClientPlayerData.serverProfile:getState()
			local v22 = v1.rebirthLevel or 0
			local v32 = v1.strength or 0
			local v4 = v22 + 1
			local v5 = RebirthConfig.getRebirthMultiplier(v22)
			local v6 = RebirthConfig.Config[v4]
			local v7 = if v6 == nil then false elseif v6.RequiredStrength <= v32 then true else false

			if v2 then
				v2.Text = ("x%* Cash"):format(v5)
			end

			buildRewards(v4, v6)

			if v6 then
				TextLabel.Text = ("Rebirth %*"):format(v4)

				if v3 then
					v3.Text = ("x%* Cash"):format(v6.CashMultiplier)
				end

				NumberProgress.Text = ("%*/%* Throw Power"):format(ConvertValue.suffixformat(v32), (ConvertValue.suffixformat(v6.RequiredStrength)))
				Bar.Size = UDim2.new(math.clamp(v32 / v6.RequiredStrength, 0, 1), 0, 1, 0)
				Rebirth3.Visible = true
				Rebirth3.Active = if v6.RequiredStrength <= v32 then true else false
			else
				TextLabel.Text = "Max Rebirth"

				if v3 then
					v3.Text = ("x%* Cash"):format(v5)
				end

				NumberProgress.Text = "MAX"
				Bar.Size = UDim2.new(1, 0, 1, 0)
				Rebirth3.Visible = false
				Rebirth3.Active = false
				BuyDP.Visible = false
			end

			setAlertActive(v7)
		end

		refresh()

		local v8 = ClientPlayerData.serverProfile:getState().rebirthLevel or 0

		ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 476 ]]
			return p1.rebirthLevel
		end, function(p12) --[[ Line: 478 | Upvalues: v8 (ref), p1 (copy), SFX (ref), Players (ref), VFX (ref), playJumpBackflip (ref), showRebirthBanner (ref), refresh (copy) ]]
			if not (v8 < p12) then
				refresh()

				return
			end

			v8 = p12
			p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
			SFX.new(SFX.Sounds.Rebirth, 0.5)

			local Character = Players.LocalPlayer.Character

			if Character then
				local v1 = Character:FindFirstChild("UpperTorso") or (Character:FindFirstChild("Torso") or Character:FindFirstChild("HumanoidRootPart"))

				if v1 and v1:IsA("BasePart") then
					VFX.new("Rebirth_fx", v1)
				end

				playJumpBackflip(Character)
			end

			task.delay(1, showRebirthBanner)
			refresh()
		end)
		ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 503 ]]
			return p1.strength
		end, refresh)
	end
}