-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ContextActionService = game:GetService("ContextActionService")
local GuiService = game:GetService("GuiService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local UserInputService = game:GetService("UserInputService")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local CashDisplay = require(ReplicatedStorage.shared.module.CashDisplay)
local EquipBestOptions = require(ReplicatedStorage.shared.UECS.Components.EquipBestOptions)
local EquipBestConfig = require(ReplicatedStorage.shared.config.EquipBestConfig)
local EquipBestPlan = require(ReplicatedStorage.shared.util.EquipBestPlan)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Remotes = require(ReplicatedStorage.shared.Remotes)

require(ReplicatedStorage.shared.UECS.Components.TycoonComponent)

local UnlockEquipBest = require(ReplicatedStorage.shared.UECS.Components.UnlockEquipBest)
local WalkableUI = require(ReplicatedStorage.shared.UECS.Components.WalkableUI)
local bindToButtonPress = require(ReplicatedStorage.shared.util.bindToButtonPress)
local notifications = require(ReplicatedStorage.shared.module.notifications)
local LocalPlayer = Players.LocalPlayer

local function isGamepad() --[[ isGamepad | Line: 40 | Upvalues: UserInputService (copy) ]]
	return UserInputService.PreferredInput == Enum.PreferredInput.Gamepad
end

return {
	UECS = nil,
	Priority = 30,
	Init = function(p1) --[[ Init | Line: 59 | Upvalues: LocalPlayer (copy), EquipBestOptions (copy), UnlockEquipBest (copy), bindToButtonPress (copy), Remotes (copy), ContextActionService (copy), CashDisplay (copy), EquipBestConfig (copy), ClientPlayerData (copy), EquipBestPlan (copy), notifications (copy), UserInputService (copy), GuiService (copy), ReplicatedStorage (copy), WalkableUI (copy) ]]
		local PlayerGui = LocalPlayer.PlayerGui
		local MainUI = PlayerGui:WaitForChild("MainUI")
		local EquipBestOptions2 = MainUI:WaitForChild("EquipBestOptions")
		local v1 = EquipBestOptions2:WaitForChild("Content")
		local TopBar = EquipBestOptions2:WaitForChild("TopBar")

		EquipBestOptions2.Visible = false

		local v2 = EquipBestOptions.Add(EquipBestOptions2)

		TopBar:WaitForChild("CloseButton").MouseButton1Down:Connect(function() --[[ Line: 70 | Upvalues: p1 (copy) ]]
			p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
		end)

		local UnlockEquipBest2 = MainUI:WaitForChild("UnlockEquipBest")

		UnlockEquipBest2.Visible = false

		local v3 = UnlockEquipBest.Add(UnlockEquipBest2)

		v3.Visible.OnChange:Connect(function(p1, p2) --[[ Line: 79 | Upvalues: UnlockEquipBest2 (copy), bindToButtonPress (ref), Remotes (ref), ContextActionService (ref) ]]
			UnlockEquipBest2.Visible = p1

			if p1 == p2 then
				return
			end

			if p1 then
				bindToButtonPress("UnlockEquipBestPurchase", Enum.KeyCode.ButtonX, function() --[[ Line: 84 | Upvalues: Remotes (ref) ]]
					Remotes.RequestBuyEquipBest:Fire()
				end)

				return
			end

			ContextActionService:UnbindAction("UnlockEquipBestPurchase")
		end)
		UnlockEquipBest2:WaitForChild("TopBar"):WaitForChild("CloseButton").MouseButton1Click:Connect(function() --[[ Line: 94 | Upvalues: p1 (copy) ]]
			p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
		end)

		local Buy = UnlockEquipBest2:WaitForChild("Content"):WaitForChild("Buy")
		local Price = Buy:FindFirstChild("Price", true)

		if Price then
			CashDisplay.applyToLabel(Price, EquipBestConfig.Cost, {
				Compact = true
			})
		end

		Buy.MouseButton1Click:Connect(function() --[[ Line: 104 | Upvalues: Remotes (ref) ]]
			Remotes.RequestBuyEquipBest:Fire()
		end)
		ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 110 ]]
			return p1.hasEquipBest
		end, function(p12) --[[ Line: 112 | Upvalues: p1 (copy), v3 (copy) ]]
			if not p12 then
				return
			end

			local v1 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

			if v1.OpenedUIComponent:Get() ~= v3 then
				return
			end

			v1.OpenedUIComponent:Set(nil)
		end)

		local CardNow = v1:WaitForChild("CardNow")
		local CardPossible = v1:WaitForChild("CardPossible")
		local CardFlat = v1:WaitForChild("CardFlat")
		local BestNowButton = CardNow:WaitForChild("BestNowButton")
		local BestPossibleButton = CardPossible:WaitForChild("BestPossibleButton")
		local BestFlatButton = CardFlat:WaitForChild("BestFlatButton")
		local NowValue = CardNow.Stats:FindFirstChild("NowValue")
		local MaxValue = CardNow.Stats:FindFirstChild("MaxValue")
		local NowValue2 = CardPossible.Stats:FindFirstChild("NowValue")
		local MaxValue2 = CardPossible.Stats:FindFirstChild("MaxValue")
		local NowValue3 = CardFlat.Stats:FindFirstChild("NowValue")
		local MaxValue3 = CardFlat.Stats:FindFirstChild("MaxValue")

		local function setVal(p1, p2) --[[ setVal | Line: 141 | Upvalues: CashDisplay (ref) ]]
			if not p1 then
				return
			end

			CashDisplay.applyToLabel(p1, p2, {
				Suffix = "/s",
				Compact = true
			})
		end

		local function refreshPreview() --[[ refreshPreview | Line: 147 | Upvalues: ClientPlayerData (ref), EquipBestPlan (ref), LocalPlayer (ref), NowValue (copy), CashDisplay (ref), MaxValue (copy), NowValue2 (copy), MaxValue2 (copy), NowValue3 (copy), MaxValue3 (copy) ]]
			local v1 = ClientPlayerData.serverProfile:getState()
			local v2 = EquipBestPlan.compute(LocalPlayer, v1, EquipBestPlan.Options.BestNow)
			local v3 = EquipBestPlan.compute(LocalPlayer, v1, EquipBestPlan.Options.BestPossible)
			local v4 = EquipBestPlan.compute(LocalPlayer, v1, EquipBestPlan.Options.BestFlat)
			local v5 = NowValue
			local ProjectedNow = v2.ProjectedNow

			if v5 then
				CashDisplay.applyToLabel(v5, ProjectedNow, {
					Suffix = "/s",
					Compact = true
				})
			end

			local v6 = MaxValue
			local ProjectedMax = v2.ProjectedMax

			if v6 then
				CashDisplay.applyToLabel(v6, ProjectedMax, {
					Suffix = "/s",
					Compact = true
				})
			end

			local v7 = NowValue2
			local ProjectedNow2 = v3.ProjectedNow

			if v7 then
				CashDisplay.applyToLabel(v7, ProjectedNow2, {
					Suffix = "/s",
					Compact = true
				})
			end

			local v8 = MaxValue2
			local ProjectedMax2 = v3.ProjectedMax

			if v8 then
				CashDisplay.applyToLabel(v8, ProjectedMax2, {
					Suffix = "/s",
					Compact = true
				})
			end

			local v9 = NowValue3
			local ProjectedNow3 = v4.ProjectedNow

			if v9 then
				CashDisplay.applyToLabel(v9, ProjectedNow3, {
					Suffix = "/s",
					Compact = true
				})
			end

			local v10 = MaxValue3

			if not v10 then
				return
			end

			CashDisplay.applyToLabel(v10, v4.ProjectedMax, {
				Suffix = "/s",
				Compact = true
			})
		end

		local v4 = 0

		local function requestEquip(p12) --[[ requestEquip | Line: 164 | Upvalues: ClientPlayerData (ref), p1 (copy), v3 (copy), v4 (ref), EquipBestConfig (ref), notifications (ref), Remotes (ref) ]]
			if not ClientPlayerData.serverProfile:getState().hasEquipBest then
				p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(v3)

				return
			end

			local v1 = os.clock()

			if v1 - v4 < EquipBestConfig.Cooldown then
				notifications:Send((("Equip Best is resting. Try again in %*s."):format((math.ceil(EquipBestConfig.Cooldown - (v1 - v4))))))
			else
				v4 = v1
				Remotes.RequestEquipBest:Fire(p12)
			end
		end

		BestNowButton.MouseButton1Down:Connect(function() --[[ Line: 182 | Upvalues: requestEquip (copy), EquipBestPlan (ref) ]]
			requestEquip(EquipBestPlan.Options.BestNow)
		end)
		BestPossibleButton.MouseButton1Down:Connect(function() --[[ Line: 185 | Upvalues: requestEquip (copy), EquipBestPlan (ref) ]]
			requestEquip(EquipBestPlan.Options.BestPossible)
		end)
		BestFlatButton.MouseButton1Down:Connect(function() --[[ Line: 188 | Upvalues: requestEquip (copy), EquipBestPlan (ref) ]]
			requestEquip(EquipBestPlan.Options.BestFlat)
		end)
		v2.Visible.OnChange:Connect(function(p1, p2) --[[ Line: 192 | Upvalues: EquipBestOptions2 (copy), MainUI (copy), refreshPreview (copy), bindToButtonPress (ref), requestEquip (copy), EquipBestPlan (ref), ContextActionService (ref) ]]
			EquipBestOptions2.Visible = p1

			local HUD = MainUI:FindFirstChild("HUD")

			if HUD then
				HUD.Visible = not p1
			end

			if p1 then
				refreshPreview()
			end

			if p1 == p2 then
				return
			end

			if p1 then
				bindToButtonPress("EquipBestCurrent", Enum.KeyCode.ButtonX, function() --[[ Line: 208 | Upvalues: requestEquip (ref), EquipBestPlan (ref) ]]
					requestEquip(EquipBestPlan.Options.BestNow)
				end)
				bindToButtonPress("EquipBestPossible", Enum.KeyCode.ButtonY, function() --[[ Line: 212 | Upvalues: requestEquip (ref), EquipBestPlan (ref) ]]
					requestEquip(EquipBestPlan.Options.BestPossible)
				end)
				bindToButtonPress("EquipBestFlat", Enum.KeyCode.ButtonR1, function() --[[ Line: 216 | Upvalues: requestEquip (ref), EquipBestPlan (ref) ]]
					requestEquip(EquipBestPlan.Options.BestFlat)
				end)

				return
			end

			ContextActionService:UnbindAction("EquipBestCurrent")
			ContextActionService:UnbindAction("EquipBestPossible")
			ContextActionService:UnbindAction("EquipBestFlat")
		end)

		local function setupControllerNav(p12, p2, p3, p4) --[[ setupControllerNav | Line: 231 | Upvalues: UserInputService (ref), bindToButtonPress (ref), p1 (copy), GuiService (ref), ContextActionService (ref) ]]
			for v1, v2 in p2:GetDescendants() do
				if v2:IsA("GuiButton") then
					v2.Selectable = true
				end
			end

			p12.Visible.OnChange:Connect(function(p13) --[[ Line: 237 | Upvalues: UserInputService (ref), bindToButtonPress (ref), p4 (copy), p1 (ref), p12 (copy), GuiService (ref), p3 (copy), ContextActionService (ref), p2 (copy) ]]
				if not (if UserInputService.PreferredInput == Enum.PreferredInput.Gamepad then true else false) then
					return
				end

				if p13 then
					bindToButtonPress(p4, Enum.KeyCode.ButtonB, function() --[[ Line: 242 | Upvalues: p1 (ref) ]]
						p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
					end)
					task.defer(function() --[[ Line: 247 | Upvalues: p12 (ref), GuiService (ref), p3 (ref) ]]
						if not p12.Visible:Get() then
							return
						end

						GuiService:Select(p3)
					end)

					return
				end

				ContextActionService:UnbindAction(p4)

				local SelectedObject = GuiService.SelectedObject

				if not (SelectedObject and SelectedObject:IsDescendantOf(p2)) then
					return
				end

				GuiService.SelectedObject = nil
			end)
		end

		setupControllerNav(v2, EquipBestOptions2, BestNowButton, "EquipBestClose")
		setupControllerNav(v3, UnlockEquipBest2, Buy, "UnlockEquipBestClose")
		ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 266 ]]
			return {
				p1.inventory,
				p1.baseSlots,
				p1.tycoonLevel,
				p1.hasEquipBest,
				p1.rebirthLevel
			}
		end, function() --[[ Line: 274 | Upvalues: EquipBestOptions2 (copy), refreshPreview (copy) ]]
			if not EquipBestOptions2.Visible then
				return
			end

			refreshPreview()
		end)

		local v5 = nil
		local v6 = nil
		local v7 = nil

		local function refreshModelState(p1) --[[ refreshModelState | Line: 288 | Upvalues: ClientPlayerData (ref), CashDisplay (ref), EquipBestConfig (ref), v6 (ref) ]]
			local v1 = if ClientPlayerData.serverProfile:getState().hasEquipBest == true then true else false
			local BguiPart = p1:FindFirstChild("BguiPart")
			local v2 = if BguiPart then BguiPart:FindFirstChildOfClass("BillboardGui") else BguiPart
			local v3 = if v2 then v2:FindFirstChild("TextUp") else v2

			if v3 and v3:IsA("TextLabel") then
				if v1 then
					CashDisplay.setPlainText(v3, "Equip Best")
				else
					CashDisplay.applyParts(v3, {
						"Equip Best - Unlock: ",
						{
							Compact = true,
							Value = EquipBestConfig.Cost
						}
					})
				end
			end

			if not v6 then
				return
			end

			v6.UIComponentName:Set(if v1 then "EquipBestOptions" else "UnlockEquipBest")
		end

		local function spawnPlotModel(p1) --[[ spawnPlotModel | Line: 306 | Upvalues: v5 (ref), ReplicatedStorage (ref), v6 (ref), WalkableUI (ref), refreshModelState (copy) ]]
			if v5 then
				v5:Destroy()
				v5 = nil
			end

			local EquipBestModel = ReplicatedStorage.shared.model:FindFirstChild("EquipBestModel")

			if not EquipBestModel then
				return
			end

			local EquipBestModel2 = EquipBestModel:Clone()

			EquipBestModel2.Name = "EquipBestModel"

			local PlayerSpawn = p1:FindFirstChild("PlayerSpawn")

			if PlayerSpawn and PlayerSpawn:IsA("BasePart") then
				local Position = (PlayerSpawn.CFrame * CFrame.new(-20, 0, -11)).Position
				local v3 = workspace:Raycast(Vector3.new(Position.X, Position.Y + 50, Position.Z), Vector3.new(0, -100, 0), RaycastParams.new())
				local v4 = if v3 then v3.Position.Y else Position.Y

				EquipBestModel2:PivotTo(CFrame.new(Position.X, v4 + 0, Position.Z) * PlayerSpawn.CFrame.Rotation * CFrame.Angles(0, 1.5707963267948966, 0))
			end

			EquipBestModel2.Parent = workspace
			v5 = EquipBestModel2

			local Button = EquipBestModel2:FindFirstChild("Button")

			if Button then
				v6 = WalkableUI.Add(Button)
			end

			refreshModelState(EquipBestModel2)
		end

		local function destroyPlotModel() --[[ destroyPlotModel | Line: 348 | Upvalues: v5 (ref), v6 (ref) ]]
			if v5 then
				v5:Destroy()
				v5 = nil
			end

			v6 = nil
		end

		local function watchTycoon(p1) --[[ watchTycoon | Line: 356 | Upvalues: LocalPlayer (ref), v7 (ref), spawnPlotModel (copy), v5 (ref), v6 (ref) ]]
			p1.Owner.OnChange:Connect(function(p12) --[[ Line: 357 | Upvalues: LocalPlayer (ref), p1 (copy), v7 (ref), spawnPlotModel (ref), v5 (ref), v6 (ref) ]]
				if p12 == LocalPlayer and p1.Entity then
					v7 = p1
					spawnPlotModel(p1.Entity)

					return
				end

				if p1 ~= v7 or p12 == LocalPlayer then
					return
				end

				v7 = nil

				if v5 then
					v5:Destroy()
					v5 = nil
				end

				v6 = nil
			end)

			if p1.Owner:Get() ~= LocalPlayer or not p1.Entity then
				return
			end

			v7 = p1
			spawnPlotModel(p1.Entity)
		end

		for v8, v9 in p1.UECS:GetComponents("TycoonComponent") do
			watchTycoon(v9)
		end

		p1.UECS.OnComponentCreated("TycoonComponent"):Connect(watchTycoon)
		ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 378 ]]
			return p1.hasEquipBest
		end, function() --[[ Line: 380 | Upvalues: v5 (ref), refreshModelState (copy) ]]
			if not v5 then
				return
			end

			refreshModelState(v5)
		end)
		task.spawn(function() --[[ Line: 391 | Upvalues: PlayerGui (copy), ReplicatedStorage (ref), ClientPlayerData (ref), p1 (copy), v3 (copy), v2 (copy) ]]
			local BackpackGui = PlayerGui:WaitForChild("BackpackGui", 30)
			local v1 = if BackpackGui then BackpackGui:WaitForChild("Backpack", 30) else BackpackGui
			local v22 = if v1 then v1:WaitForChild("Inventory", 30) else v1
			local v32 = if v22 then v22:WaitForChild("EquipBestButton", 30) else v22

			if not v32 then
				return
			end

			local Satchel = require(ReplicatedStorage.client.Satchel)
			local v4 = v32:FindFirstChildWhichIsA("TextLabel", true)

			local function updateLock(p1) --[[ updateLock | Line: 403 | Upvalues: v4 (copy) ]]
				if not v4 then
					return
				end

				v4.Text = if p1 then "Equip Best" else "\240\159\148\146 Equip Best"
			end

			local hasEquipBest = ClientPlayerData.serverProfile:getState().hasEquipBest

			if v4 then
				v4.Text = if hasEquipBest then "Equip Best" else "\240\159\148\146 Equip Best"
			end

			ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 409 ]]
				return p1.hasEquipBest
			end, updateLock)
			v32.MouseButton1Click:Connect(function() --[[ Line: 413 | Upvalues: ClientPlayerData (ref), p1 (ref), v3 (ref), Satchel (copy), v2 (ref) ]]
				local v1 = ClientPlayerData.serverProfile:getState()
				local v22 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

				if v1.hasEquipBest then
					if v22.OpenedUIComponent:Get() == v2 then
						v22.OpenedUIComponent:Set(nil)

						return
					end

					v22.OpenedUIComponent:Set(v2)
				else
					v22.OpenedUIComponent:Set(v3)
				end

				if not Satchel.IsOpen then
					return
				end

				Satchel.OpenClose()
			end)
		end)
	end
}