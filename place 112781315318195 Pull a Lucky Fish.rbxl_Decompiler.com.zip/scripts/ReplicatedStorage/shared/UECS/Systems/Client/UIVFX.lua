-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local UIVFX = require(ReplicatedStorage.shared.module.UIVFX)

return {
	UECS = nil,
	Priority = 5,
	Init = function(p1) --[[ Init | Line: 9 | Upvalues: UIVFX (copy) ]]
		UIVFX.Init()
	end
}