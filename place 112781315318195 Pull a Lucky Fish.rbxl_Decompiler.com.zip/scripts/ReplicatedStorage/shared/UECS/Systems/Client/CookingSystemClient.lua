-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local EventConfig = require(ReplicatedStorage.shared.config.EventConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Remotes = require(ReplicatedStorage.shared.Remotes)
local SFX = require(ReplicatedStorage.client.SFX)
local buildFishModel = require(ReplicatedStorage.shared.util.buildFishModel)
local findBestCookingDish = require(ReplicatedStorage.shared.util.findBestCookingDish)
local getFoodModelTemplate = require(ReplicatedStorage.shared.util.getFoodModelTemplate)
local tweenModelScale = require(ReplicatedStorage.shared.util.tweenModelScale)
local LocalPlayer = Players.LocalPlayer
local t = {
	UECS = nil,
	Priority = 60
}
local CookingStation = EventConfig.Tags.CookingStation
local CookingSystem = EventConfig.CookingSystem
local v1 = Vector2.new(0, -35)
local v2 = Vector2.new(0, 35)
local v3 = TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
local v4 = TweenInfo.new(0.65, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
local v5 = CFrame.Angles(1.5707963267948966, 0, 0)
local v6 = TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local v7 = CFrame.Angles(-1.5707963267948966, 0, 0)
local v8 = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
local v9 = Color3.fromRGB(160, 32, 240)
local v10 = TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local v11 = TweenInfo.new(0.8, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
local v12 = TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local v13 = TweenInfo.new(0.9, Enum.EasingStyle.Bounce, Enum.EasingDirection.Out)

local function getTemplate(p1) --[[ getTemplate | Line: 118 | Upvalues: ReplicatedStorage (copy) ]]
	local v1 = ReplicatedStorage:FindFirstChild("shared")
	local v2 = if v1 then v1:FindFirstChild("model") else v1
	local v3 = if v2 then v2:FindFirstChild(p1) else v2

	if v3 then
		return v3
	end

	warn((("[CookingSystemClient] Template \"%*\" not found in ReplicatedStorage.shared.model"):format(p1)))

	return v3
end

local t2 = {
	cookingPoints = 0,
	cookingState = "idle",
	cookingStartTime = 0
}

local function getCookingState() --[[ getCookingState | Line: 131 | Upvalues: ClientPlayerData (copy), EventConfig (copy), t2 (copy) ]]
	local v1 = ClientPlayerData.serverProfile:getState()
	local v2 = v1.events and v1.events[EventConfig.Event.Id]

	return if v2 then v2 else t2
end

local function isCookingReady(p1) --[[ isCookingReady | Line: 141 | Upvalues: CookingSystem (copy) ]]
	return if p1.cookingState == "cooking" then workspace:GetServerTimeNow() >= p1.cookingStartTime + CookingSystem.CookingTime else false
end

local function formatMMSS(p1) --[[ formatMMSS | Line: 146 ]]
	local v2 = math.max(0, (math.floor(p1)))

	return string.format("%d:%02d", math.floor(v2 / 60), v2 % 60)
end

local function makePrompt(p1, p2, p3, p4, p5) --[[ makePrompt | Line: 153 ]]
	local ProximityPrompt = Instance.new("ProximityPrompt")

	ProximityPrompt.Style = Enum.ProximityPromptStyle.Custom
	ProximityPrompt.ActionText = p2
	ProximityPrompt.ObjectText = "Cooking Pot"
	ProximityPrompt.HoldDuration = 0
	ProximityPrompt.MaxActivationDistance = 10
	ProximityPrompt.RequiresLineOfSight = false
	ProximityPrompt.Enabled = p3
	ProximityPrompt.KeyboardKeyCode = p4
	ProximityPrompt.UIOffset = p5
	ProximityPrompt.Exclusivity = Enum.ProximityPromptExclusivity.AlwaysShow
	ProximityPrompt.Parent = p1

	return ProximityPrompt
end

local function setupStation(p1) --[[ setupStation | Line: 183 | Upvalues: TweenService (copy), v10 (copy), v9 (copy), v12 (copy), v11 (copy), v13 (copy), SFX (copy), v6 (copy), buildFishModel (copy), v7 (copy), v8 (copy), getFoodModelTemplate (copy), v5 (copy), v4 (copy), tweenModelScale (copy), v3 (copy), v1 (copy), v2 (copy), ReplicatedStorage (copy), LocalPlayer (copy), t (copy), Remotes (copy), ClientPlayerData (copy), EventConfig (copy), t2 (copy), CookingSystem (copy), findBestCookingDish (copy) ]]
	if not p1:IsA("Model") then
		return
	end

	local Pot = p1:FindFirstChild("Pot")

	if not Pot then
		warn("[CookingSystemClient] CookingStation missing Pot part:", p1.Name)

		return
	end

	local PointsDisplay = p1:FindFirstChild("PointsDisplay")
	local FoodSpawningPart = p1:FindFirstChild("FoodSpawningPart")
	local Spoon = p1:FindFirstChild("Spoon")
	local StartingPosition = p1:FindFirstChild("StartingPosition")
	local WaterSurface = p1:FindFirstChild("WaterSurface")
	local WaterPart = p1:FindFirstChild("WaterPart")
	local v14 = WaterPart and WaterPart:FindFirstChild("BoilParticles")
	local v22

	if WaterPart then
		local Color = WaterPart.Color
		local v32 = WaterPart.CFrame
		local ParticleEmitter = WaterPart:FindFirstChild("ParticleEmitter")
		local Bubble = WaterPart:FindFirstChild("Bubble")
		local v42 = 0

		v22 = function() --[[ Line: 210 | Upvalues: v42 (ref), ParticleEmitter (copy), Bubble (copy), TweenService (ref), WaterPart (copy), v10 (ref), v9 (ref), v12 (ref), v32 (copy), v11 (ref), Color (copy), v13 (ref) ]]
			v42 = v42 + 1

			local v1 = v42

			task.spawn(function() --[[ Line: 214 | Upvalues: v42 (ref), v1 (copy), ParticleEmitter (ref), Bubble (ref), TweenService (ref), WaterPart (ref), v10 (ref), v9 (ref), v12 (ref), v32 (ref), v11 (ref), Color (ref), v13 (ref) ]]
				task.wait(0.2)

				if v42 ~= v1 then
					return
				end

				if ParticleEmitter then
					ParticleEmitter:Emit(12)
				end

				if Bubble then
					Bubble:Emit(20)
				end

				TweenService:Create(WaterPart, v10, {
					Color = v9
				}):Play()
				TweenService:Create(WaterPart, v12, {
					CFrame = v32 * CFrame.new(0, 0.6, 0)
				}):Play()
				task.wait(v10.Time)

				if v42 == v1 then
					TweenService:Create(WaterPart, v11, {
						Color = Color
					}):Play()
					TweenService:Create(WaterPart, v13, {
						CFrame = v32
					}):Play()
				end
			end)
		end
	else
		v22 = nil
	end

	local v52, v62

	if Spoon and (StartingPosition and WaterSurface) then
		local v72 = Spoon.CFrame
		local v92 = CFrame.new((Vector3.new(WaterSurface.Position.X, StartingPosition.Position.Y, WaterSurface.Position.Z)))
		local v102 = v92:ToObjectSpace(StartingPosition.CFrame)
		local StirringBubbles = Instance.new("Sound")

		StirringBubbles.Name = "StirringBubbles"
		StirringBubbles.SoundId = SFX.Sounds.Bubbles
		StirringBubbles.Looped = true
		StirringBubbles.Volume = 1
		StirringBubbles.RollOffMaxDistance = 50
		StirringBubbles.Parent = WaterSurface

		local v112 = 0

		v52 = function() --[[ Line: 271 | Upvalues: v112 (ref), TweenService (ref), Spoon (copy), v6 (ref), v72 (copy), StirringBubbles (copy) ]]
			v112 = v112 + 1
			TweenService:Create(Spoon, v6, {
				CFrame = v72
			}):Play()
			StirringBubbles:Stop()
		end
		v62 = function() --[[ Line: 277 | Upvalues: v112 (ref), StirringBubbles (copy), TweenService (ref), Spoon (copy), v6 (ref), StartingPosition (copy), p1 (copy), v92 (copy), v102 (copy) ]]
			v112 = v112 + 1

			local v1 = v112

			StirringBubbles:Play()
			task.spawn(function() --[[ Line: 281 | Upvalues: TweenService (ref), Spoon (ref), v6 (ref), StartingPosition (ref), v112 (ref), v1 (copy), p1 (ref), v92 (ref), v102 (ref) ]]
				TweenService:Create(Spoon, v6, {
					CFrame = StartingPosition.CFrame
				}):Play()
				task.wait(v6.Time)

				local sum = 0

				while v112 == v1 and p1.Parent do
					sum = sum + 3.839724354387525 * task.wait()
					Spoon.CFrame = v92 * CFrame.Angles(0, sum, 0) * v102
				end
			end)
		end
	else
		v62 = nil
		v52 = nil
	end

	local function buildFishDropInstance(p1, p2, p3) --[[ buildFishDropInstance | Line: 296 | Upvalues: buildFishModel (ref) ]]
		local FishDropVFX

		if not p1 then
			FishDropVFX = Instance.new("Part")
			FishDropVFX.Name = "FishDropVFX"
			FishDropVFX.Shape = Enum.PartType.Ball
			FishDropVFX.Size = Vector3.new(5, 5, 5)
			FishDropVFX.Material = Enum.Material.SmoothPlastic
			FishDropVFX.Color = Color3.fromRGB(90, 160, 220)
			FishDropVFX.CanCollide = false
			FishDropVFX.CanQuery = false
			FishDropVFX.CastShadow = false

			return FishDropVFX, false
		end

		local v1 = buildFishModel.clone(p1, p2, p3)

		if not (v1 and v1.PrimaryPart) then
			FishDropVFX = Instance.new("Part")
			FishDropVFX.Name = "FishDropVFX"
			FishDropVFX.Shape = Enum.PartType.Ball
			FishDropVFX.Size = Vector3.new(5, 5, 5)
			FishDropVFX.Material = Enum.Material.SmoothPlastic
			FishDropVFX.Color = Color3.fromRGB(90, 160, 220)
			FishDropVFX.CanCollide = false
			FishDropVFX.CanQuery = false
			FishDropVFX.CastShadow = false

			return FishDropVFX, false
		end

		local _, v2 = v1:GetBoundingBox()
		local v3 = math.max(v2.X, v2.Y, v2.Z)

		if v3 > 0 then
			v1:ScaleTo(v1:GetScale() * (5 / v3))
		end

		for v4, v5 in v1:GetDescendants() do
			if v5:IsA("BasePart") then
				v5.Anchored = true
				v5.CanCollide = false
				v5.CanQuery = false
				v5.CastShadow = false
			end
		end

		return v1, true
	end

	local function playFishDropVFX(p1, p2, p3) --[[ playFishDropVFX | Line: 329 | Upvalues: WaterSurface (copy), buildFishDropInstance (copy), v7 (ref), v8 (ref), TweenService (ref) ]]
		if not WaterSurface then
			return
		end

		local v1, v2 = buildFishDropInstance(p1, p2, p3)

		local function setPose(p1) --[[ setPose | Line: 335 | Upvalues: v2 (copy), v1 (copy) ]]
			if v2 then
				v1:PivotTo(p1)
			else
				v1.Anchored = true
				v1.CFrame = p1
			end
		end

		local Position = WaterSurface.Position
		local v3 = CFrame.new(Position + Vector3.new(0, 4, 0)) * v7
		local v4 = CFrame.new(Position - Vector3.new(0, 4, 0)) * v7

		if v2 then
			v1:PivotTo(v3)
		else
			v1.Anchored = true
			v1.CFrame = v3
		end

		v1.Parent = WaterSurface
		task.spawn(function() --[[ Line: 354 | Upvalues: v8 (ref), TweenService (ref), v3 (copy), v4 (copy), v2 (copy), v1 (copy) ]]
			local Time = v8.Time
			local v12 = os.clock()

			while true do
				local v32 = math.clamp((os.clock() - v12) / Time, 0, 1)
				local v42 = v3:Lerp(v4, (TweenService:GetValue(v32, v8.EasingStyle, v8.EasingDirection)))

				if v2 then
					v1:PivotTo(v42)
				else
					v1.Anchored = true
					v1.CFrame = v42
				end

				if v32 >= 1 then
					break
				end

				task.wait()
			end

			v1:Destroy()
		end)
	end

	local v122 = nil
	local count = 0

	local function setBoil(p1) --[[ setBoil | Line: 381 | Upvalues: count (ref), v14 (copy) ]]
		count = count + 1

		if v14 then
			v14.Enabled = p1
		end

		if not p1 then
			return
		end

		local v1 = count

		task.delay(3, function() --[[ Line: 388 | Upvalues: count (ref), v1 (copy), v14 (ref) ]]
			if count ~= v1 or not v14 then
				return
			end

			v14.Enabled = false
		end)
	end

	count = count + 1

	if v14 then
		v14.Enabled = false
	end

	local function clearDishDisplayInstant() --[[ clearDishDisplayInstant | Line: 397 | Upvalues: v122 (ref) ]]
		if not (v122 and v122.Parent) then
			v122 = nil

			return
		end

		v122:Destroy()
		v122 = nil
	end

	local function spawnDishDisplay(p1) --[[ spawnDishDisplay | Line: 404 | Upvalues: v122 (ref), FoodSpawningPart (copy), getFoodModelTemplate (ref), v5 (ref), WaterPart (copy), v4 (ref), TweenService (ref) ]]
		if v122 and v122.Parent then
			v122:Destroy()
		end

		v122 = nil

		if not FoodSpawningPart then
			return
		end

		local v1 = getFoodModelTemplate(p1)

		if not (v1 and (v1:IsA("Model") and v1.PrimaryPart)) then
			return
		end

		local v2 = v1:Clone()

		v2:ScaleTo(v2:GetScale() * 1.5)

		for v3, v42 in v2:GetDescendants() do
			if v42:IsA("BasePart") then
				v42.Anchored = true
				v42.CanCollide = false
				v42.CanQuery = false
			end
		end

		v2:PivotTo(v5)

		local _, v52 = v2:GetBoundingBox()
		local v6 = FoodSpawningPart.Position.X + -3.5
		local Z = FoodSpawningPart.Position.Z
		local v7, v8

		if WaterPart then
			local v9 = WaterPart.Position.Y + WaterPart.Size.Y / 2

			v7 = CFrame.new(v6, v9 + 0.15 + v52.Y / 2, Z) * v5
			v8 = CFrame.new(v6, v9 - 1.6 - v52.Y / 2, Z) * v5
		else
			v7 = CFrame.new(v6, FoodSpawningPart.Position.Y + v52.Y / 2, Z) * v5
			v8 = v7
		end

		v2.Parent = FoodSpawningPart
		v2:PivotTo(v8)
		v122 = v2
		task.spawn(function() --[[ Line: 453 | Upvalues: v4 (ref), v2 (copy), v122 (ref), TweenService (ref), v8 (ref), v7 (ref) ]]
			local v1 = v4
			local v22 = os.clock()

			while v2.Parent and v122 == v2 do
				local v42 = math.clamp((os.clock() - v22) / v1.Time, 0, 1)

				v2:PivotTo(v8:Lerp(v7, (TweenService:GetValue(v42, v1.EasingStyle, v1.EasingDirection))))

				if v42 >= 1 then
					break
				end

				task.wait()
			end
		end)
	end

	local function collectDishDisplay() --[[ collectDishDisplay | Line: 468 | Upvalues: v122 (ref), count (ref), v14 (copy), tweenModelScale (ref), v3 (ref) ]]
		local v1 = v122

		v122 = nil
		count = count + 1

		if v14 then
			v14.Enabled = false
		end

		if v1 and v1.Parent then
			task.spawn(function() --[[ Line: 475 | Upvalues: tweenModelScale (ref), v1 (copy), v3 (ref) ]]
				tweenModelScale(v1, v3, 0.05)
				v1:Destroy()
			end)
		end
	end

	local E = Enum.KeyCode.E
	local ProximityPrompt = Instance.new("ProximityPrompt")

	ProximityPrompt.Style = Enum.ProximityPromptStyle.Custom
	ProximityPrompt.ActionText = "Insert Fish"
	ProximityPrompt.ObjectText = "Cooking Pot"
	ProximityPrompt.HoldDuration = 0
	ProximityPrompt.MaxActivationDistance = 10
	ProximityPrompt.RequiresLineOfSight = false
	ProximityPrompt.Enabled = true
	ProximityPrompt.KeyboardKeyCode = E
	ProximityPrompt.UIOffset = v1
	ProximityPrompt.Exclusivity = Enum.ProximityPromptExclusivity.AlwaysShow
	ProximityPrompt.Parent = Pot

	local v142 = ProximityPrompt
	local E2 = Enum.KeyCode.E
	local ProximityPrompt2 = Instance.new("ProximityPrompt")

	ProximityPrompt2.Style = Enum.ProximityPromptStyle.Custom
	ProximityPrompt2.ActionText = "Claim Dish"
	ProximityPrompt2.ObjectText = "Cooking Pot"
	ProximityPrompt2.HoldDuration = 0
	ProximityPrompt2.MaxActivationDistance = 10
	ProximityPrompt2.RequiresLineOfSight = false
	ProximityPrompt2.Enabled = false
	ProximityPrompt2.KeyboardKeyCode = E2
	ProximityPrompt2.UIOffset = v1
	ProximityPrompt2.Exclusivity = Enum.ProximityPromptExclusivity.AlwaysShow
	ProximityPrompt2.Parent = Pot

	local v16 = ProximityPrompt2
	local F = Enum.KeyCode.F
	local ProximityPrompt3 = Instance.new("ProximityPrompt")

	ProximityPrompt3.Style = Enum.ProximityPromptStyle.Custom
	ProximityPrompt3.ActionText = "Start Cooking"
	ProximityPrompt3.ObjectText = "Cooking Pot"
	ProximityPrompt3.HoldDuration = 0
	ProximityPrompt3.MaxActivationDistance = 10
	ProximityPrompt3.RequiresLineOfSight = false
	ProximityPrompt3.Enabled = false
	ProximityPrompt3.KeyboardKeyCode = F
	ProximityPrompt3.UIOffset = v2
	ProximityPrompt3.Exclusivity = Enum.ProximityPromptExclusivity.AlwaysShow
	ProximityPrompt3.Parent = Pot

	local v18 = ProximityPrompt3
	local v19 = nil
	local v20 = nil
	local v21 = nil

	if PointsDisplay then
		local ok, result = pcall(function() --[[ Line: 492 | Upvalues: ReplicatedStorage (ref), PointsDisplay (copy), v19 (ref), v20 (ref), v21 (ref) ]]
			local v1 = ReplicatedStorage:FindFirstChild("shared")
			local v2 = if v1 then v1:FindFirstChild("model") else v1
			local v3 = if v2 then v2:FindFirstChild("CookingPointsDisplay") else v2

			if not v3 then
				warn("[CookingSystemClient] Template \"CookingPointsDisplay\" not found in ReplicatedStorage.shared.model")
			end

			if v3 then
				local v4 = v3:Clone()

				v4.Adornee = PointsDisplay
				v4.Parent = PointsDisplay
				v19 = v4:FindFirstChild("Points", true)
				v20 = v4:FindFirstChild("Dish")
				v21 = v4:FindFirstChild("Timer")
			end
		end)

		if not ok then
			warn((("[CookingSystemClient] points display setup failed for %*: %*"):format(p1.Name, result)))
		end
	end

	local v222 = nil

	local function captureEquippedFish() --[[ captureEquippedFish | Line: 514 | Upvalues: v222 (ref), LocalPlayer (ref), t (ref) ]]
		v222 = nil

		local Character = LocalPlayer.Character
		local v1 = if Character then Character:FindFirstChildOfClass("Tool") else Character
		local UECS = t.UECS

		if not (v1 and UECS) then
			return
		end

		local v2 = UECS:GetComponent(v1, "PlaceableFish")

		if not v2 then
			return
		end

		local v3 = v2.FishConfigName:Get()

		if type(v3) ~= "string" then
			return
		end

		local v4 = v2.Level and v2.Level:Get() or 1
		local v5 = v2.Mutation and v2.Mutation:Get()

		v222 = {
			configName = v3,
			level = v4,
			mutation = if typeof(v5) == "string" and v5 ~= "" then v5 else nil
		}
	end

	v142.Triggered:Connect(function() --[[ Line: 536 | Upvalues: captureEquippedFish (copy), Remotes (ref) ]]
		captureEquippedFish()
		Remotes.CookingInsertFish:Fire()
	end)
	v16.Triggered:Connect(function() --[[ Line: 540 | Upvalues: Remotes (ref), v122 (ref), count (ref), v14 (copy), tweenModelScale (ref), v3 (ref) ]]
		Remotes.CookingClaim:Fire()

		local v1 = v122

		v122 = nil
		count = count + 1

		if v14 then
			v14.Enabled = false
		end

		if not v1 then
			return
		end

		if not v1.Parent then
			return
		end

		task.spawn(function() --[[ Line: 475 | Upvalues: tweenModelScale (ref), v1 (copy), v3 (ref) ]]
			tweenModelScale(v1, v3, 0.05)
			v1:Destroy()
		end)
	end)
	v18.Triggered:Connect(function() --[[ Line: 544 | Upvalues: Remotes (ref) ]]
		print("[CookingSystemClient] cookPrompt Triggered fired")
		Remotes.CookingStartCook:Fire()
	end)

	local v23 = nil

	local function updateDisplay() --[[ updateDisplay | Line: 551 | Upvalues: ClientPlayerData (ref), EventConfig (ref), t2 (ref), CookingSystem (ref), v142 (copy), v16 (copy), v18 (copy), v19 (ref), v20 (ref), findBestCookingDish (ref), v23 (ref), SFX (ref), v222 (ref), playFishDropVFX (copy), v22 (ref) ]]
		local v1 = ClientPlayerData.serverProfile:getState()
		local v2 = v1.events and v1.events[EventConfig.Event.Id]
		local v3 = if v2 then v2 else t2
		local cookingPoints = v3.cookingPoints
		local cookingState = v3.cookingState
		local v4 = if v3.cookingState == "cooking" then workspace:GetServerTimeNow() >= v3.cookingStartTime + CookingSystem.CookingTime else false

		v142.Enabled = if cookingState == "idle" then true else false
		v16.Enabled = v4
		v18.Enabled = if cookingState == "idle" then if CookingSystem.MinPointsToCook <= cookingPoints then true else false else false

		if v19 then
			v19.Text = tostring(cookingPoints)
		end

		if v20 then
			local v9 = findBestCookingDish(cookingPoints)

			v20.Text = if v9 then ("Best: %* (+%*)"):format(v9.DishName, v9.CoinsReward) else ("Need %* more pts"):format(CookingSystem.MinPointsToCook - cookingPoints)
		end

		if v23 ~= nil and v23 < cookingPoints then
			SFX.new(SFX.Sounds.Bubbles, 1)
			SFX.new(SFX.Sounds.MudPuddleSplash, 1)

			local v12 = v222

			playFishDropVFX(if v12 then v12.configName else v12, if v12 then v12.level else v12, if v12 then v12.mutation else v12)

			if v22 then
				v22()
			end
		end

		v23 = cookingPoints
	end

	updateDisplay()
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 590 | Upvalues: EventConfig (ref) ]]
		local v1 = p1.events and p1.events[EventConfig.Event.Id]

		return if v1 then v1.cookingPoints or 0 else 0
	end, updateDisplay)
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 594 | Upvalues: EventConfig (ref) ]]
		local v1 = p1.events and p1.events[EventConfig.Event.Id]

		return if v1 then v1.cookingState or "idle" else "idle"
	end, updateDisplay)

	local v24 = false
	local v25 = false

	task.spawn(function() --[[ Line: 605 | Upvalues: p1 (copy), ClientPlayerData (ref), EventConfig (ref), t2 (ref), CookingSystem (ref), v24 (ref), v16 (copy), SFX (ref), count (ref), v14 (copy), findBestCookingDish (ref), spawnDishDisplay (copy), v122 (ref), v25 (ref), v62 (ref), v52 (ref), v21 (ref) ]]
		while p1.Parent do
			local ok, result = pcall(function() --[[ Line: 607 | Upvalues: ClientPlayerData (ref), EventConfig (ref), t2 (ref), CookingSystem (ref), v24 (ref), v16 (ref), SFX (ref), count (ref), v14 (ref), findBestCookingDish (ref), spawnDishDisplay (ref), v122 (ref), v25 (ref), v62 (ref), v52 (ref), v21 (ref) ]]
				local v1 = ClientPlayerData.serverProfile:getState()
				local v2 = v1.events and v1.events[EventConfig.Event.Id]
				local v3 = if v2 then v2 else t2
				local v4 = if v3.cookingState == "cooking" then if workspace:GetServerTimeNow() >= v3.cookingStartTime + CookingSystem.CookingTime then true else false else false
				local v5 = if v3.cookingState == "cooking" then not v4 else false

				if v4 and not v24 then
					v16.Enabled = true
					SFX.new(SFX.Sounds.Ding, 1)
					count = count + 1

					if v14 then
						v14.Enabled = true
					end

					local v6 = count

					task.delay(3, function() --[[ Line: 388 | Upvalues: count (ref), v6 (copy), v14 (ref) ]]
						if count ~= v6 or not v14 then
							return
						end

						v14.Enabled = false
					end)

					local v7 = findBestCookingDish(v3.cookingPoints)

					if v7 then
						spawnDishDisplay(v7.ConfigName)
					end
				elseif not v4 and v24 then
					count = count + 1

					if v14 then
						v14.Enabled = false
					end

					if v122 and v122.Parent then
						v122:Destroy()
					end

					v122 = nil
				end

				v24 = v4

				if v5 and (not v25 and v62) then
					v62()
				elseif not v5 and (v25 and v52) then
					v52()
				end

				v25 = v5

				if not v21 then
					return
				end

				if v3.cookingState == "cooking" and v4 then
					v21.Text = "Ready!"

					return
				end

				if v3.cookingState == "cooking" then
					local v11 = math.max(0, (math.floor(v3.cookingStartTime + CookingSystem.CookingTime - workspace:GetServerTimeNow())))

					v21.Text = string.format("%d:%02d", math.floor(v11 / 60), v11 % 60)

					return
				end

				v21.Text = ""
			end)

			if not ok then
				warn((("[CookingSystemClient] readiness check failed for %*: %*"):format(p1.Name, result)))
			end

			task.wait(1)
		end
	end)
end

function t.Init(p1) --[[ Init | Line: 659 | Upvalues: CollectionService (copy), CookingStation (copy), setupStation (copy) ]]
	for v1, v2 in CollectionService:GetTagged(CookingStation) do
		task.spawn(setupStation, v2)
	end

	CollectionService:GetInstanceAddedSignal(CookingStation):Connect(function(p1) --[[ Line: 663 | Upvalues: setupStation (ref) ]]
		task.spawn(setupStation, p1)
	end)
end

return t