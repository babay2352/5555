-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ContextActionService = game:GetService("ContextActionService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ControlHint = require(ReplicatedStorage.client.ControlHint)
local CashDisplay = require(ReplicatedStorage.shared.module.CashDisplay)
local FishConfig = require(ReplicatedStorage.shared.config.FishConfig)
local FishEarnings = require(ReplicatedStorage.shared.util.FishEarnings)
local GiftConfirm = require(ReplicatedStorage.shared.UECS.Components.GiftConfirm)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local MutationList = require(ReplicatedStorage.shared.util.MutationList)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local v1 = Color3.new(255/255, 255/255, 255/255)
local t = {
	UECS = nil
}
local v2 = nil

function t.Init(p1) --[[ Init | Line: 43 | Upvalues: Players (copy), GiftConfirm (copy), Remotes (copy), ControlHint (copy), ContextActionService (copy), v2 (ref), FishConfig (copy), v1 (copy), MutationList (copy), FishEarnings (copy), CashDisplay (copy) ]]
	local LocalPlayer = Players.LocalPlayer
	local GiftConfirm2 = LocalPlayer.PlayerGui:WaitForChild("MainUI"):WaitForChild("GiftConfirm")
	local v12 = GiftConfirm2:WaitForChild("Content")
	local GiftText = v12:WaitForChild("GiftText")
	local FishTemplateNotAcquired = v12:WaitForChild("FishTemplateNotAcquired")
	local Accept = v12:WaitForChild("Accept")
	local Decline = v12:WaitForChild("Decline")
	local CloseButton = GiftConfirm2:WaitForChild("TopBar"):WaitForChild("CloseButton")
	local Frame = FishTemplateNotAcquired:WaitForChild("Frame")
	local UIGradient = Frame:WaitForChild("UIGradient")
	local Icon = FishTemplateNotAcquired:WaitForChild("Icon")
	local DisplayName = FishTemplateNotAcquired:WaitForChild("DisplayName")
	local Earnings = FishTemplateNotAcquired:WaitForChild("Earnings")

	GiftConfirm2.Visible = false

	local v22 = GiftConfirm.Add(GiftConfirm2)
	local v3 = nil

	local function closeViaOpener() --[[ closeViaOpener | Line: 71 | Upvalues: p1 (copy), v22 (copy) ]]
		local v1 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

		if v1.OpenedUIComponent:Get() ~= v22 then
			return
		end

		v1.OpenedUIComponent:Set(nil)
	end

	local function confirm() --[[ confirm | Line: 79 | Upvalues: v3 (ref), Remotes (ref), p1 (copy), v22 (copy) ]]
		local v1 = v3

		if not v1 then
			return
		end

		v3 = nil

		if v1.Parent then
			Remotes.RequestGiftFish:Fire(v1)
		end

		local v2 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

		if v2.OpenedUIComponent:Get() ~= v22 then
			return
		end

		v2.OpenedUIComponent:Set(nil)
	end

	local function cancel() --[[ cancel | Line: 93 | Upvalues: v3 (ref), p1 (copy), v22 (copy) ]]
		v3 = nil

		local v1 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

		if v1.OpenedUIComponent:Get() ~= v22 then
			return
		end

		v1.OpenedUIComponent:Set(nil)
	end

	Accept.MouseButton1Click:Connect(confirm)
	Decline.MouseButton1Click:Connect(cancel)
	CloseButton.MouseButton1Click:Connect(cancel)

	local v4 = ControlHint.new({
		label = "Send",
		anchorTo = Accept,
		keyCode = Enum.KeyCode.ButtonA
	})
	local v5 = ControlHint.new({
		label = "Cancel",
		anchorTo = Decline,
		keyCode = Enum.KeyCode.ButtonB
	})

	local function bindGamepad() --[[ bindGamepad | Line: 106 | Upvalues: ContextActionService (ref), v3 (ref), Remotes (ref), p1 (copy), v22 (copy), v4 (copy), v5 (copy) ]]
		ContextActionService:BindActionAtPriority("GiftConfirmSend", function(p12, p2) --[[ Line: 109 | Upvalues: v3 (ref), Remotes (ref), p1 (ref), v22 (ref) ]]
			if p2 ~= Enum.UserInputState.Begin then
				return Enum.ContextActionResult.Pass
			end

			local v1 = v3

			if not v1 then
				return Enum.ContextActionResult.Sink
			end

			v3 = nil

			if v1.Parent then
				Remotes.RequestGiftFish:Fire(v1)
			end

			local v2 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

			if v2.OpenedUIComponent:Get() ~= v22 then
				return Enum.ContextActionResult.Sink
			end

			v2.OpenedUIComponent:Set(nil)

			return Enum.ContextActionResult.Sink
		end, false, 10000, Enum.KeyCode.ButtonA)
		ContextActionService:BindActionAtPriority("GiftConfirmCancel", function(p12, p2) --[[ Line: 122 | Upvalues: v3 (ref), p1 (ref), v22 (ref) ]]
			if p2 ~= Enum.UserInputState.Begin then
				return Enum.ContextActionResult.Pass
			end

			v3 = nil

			local v1 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

			if v1.OpenedUIComponent:Get() ~= v22 then
				return Enum.ContextActionResult.Sink
			end

			v1.OpenedUIComponent:Set(nil)

			return Enum.ContextActionResult.Sink
		end, false, 10000, Enum.KeyCode.ButtonB)
		v4:Show()
		v5:Show()
	end

	local function unbindGamepad() --[[ unbindGamepad | Line: 137 | Upvalues: ContextActionService (ref), v4 (copy), v5 (copy) ]]
		ContextActionService:UnbindAction("GiftConfirmSend")
		ContextActionService:UnbindAction("GiftConfirmCancel")
		v4:Hide()
		v5:Hide()
	end

	v22.Visible.OnChange:Connect(function(p1) --[[ Line: 146 | Upvalues: GiftConfirm2 (copy), bindGamepad (copy), ContextActionService (ref), v4 (copy), v5 (copy), v3 (ref) ]]
		GiftConfirm2.Visible = p1

		if p1 then
			bindGamepad()
		else
			ContextActionService:UnbindAction("GiftConfirmSend")
			ContextActionService:UnbindAction("GiftConfirmCancel")
			v4:Hide()
			v5:Hide()
		end

		if p1 then
			return
		end

		v3 = nil
	end)
	v2 = function(p12, p2) --[[ Line: 159 | Upvalues: FishConfig (ref), v3 (ref), GiftText (copy), UIGradient (copy), Frame (copy), Icon (copy), v1 (ref), MutationList (ref), DisplayName (copy), FishEarnings (ref), LocalPlayer (copy), CashDisplay (ref), Earnings (copy), p1 (copy), v22 (copy) ]]
		local v12 = FishConfig[p2.ConfigName]

		if not v12 then
			return
		end

		local v32 = if typeof(p2.Mutation) == "string" and p2.Mutation ~= "" then p2.Mutation else nil

		v3 = p12
		GiftText.Text = ("Send this gift to %*?"):format(p12.DisplayName)
		UIGradient.Color = ColorSequence.new(v12.Rarity.rarityColor, Color3.fromRGB(255, 255, 255))
		Frame.BackgroundColor3 = v12.Rarity.rarityColor
		Icon.Image = v12.Image
		Icon.ImageColor3 = v1

		local v4 = MutationList.displayLabel(MutationList.parse(v32))

		DisplayName.Text = ("%*%*"):format(if v4 == "" then "" else ("[%*] "):format(v4), v12.DisplayName)
		CashDisplay.applyToLabel(Earnings, FishEarnings.perFish(LocalPlayer, p2.ConfigName, false, p2.Level or 1, v32), {
			Suffix = "/s",
			Compact = true
		})
		p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(v22)
	end
end
function t.Show(p1, p2) --[[ Show | Line: 193 | Upvalues: v2 (ref) ]]
	local v1 = v2

	if v1 then
		v1(p1, p2)

		return true
	end

	return false
end

return t