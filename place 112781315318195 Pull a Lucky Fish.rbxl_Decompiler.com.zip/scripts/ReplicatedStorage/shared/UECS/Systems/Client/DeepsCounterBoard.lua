-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local Workspace = game:GetService("Workspace")
local DeepsConfig = require(ReplicatedStorage.shared.config.DeepsConfig)
local FishConfig = require(ReplicatedStorage.shared.config.FishConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local t = {
	UECS = nil
}
local t2 = {}

local function getGuiFaceNormal(p1) --[[ getGuiFaceNormal | Line: 47 ]]
	local v1 = p1:FindFirstChildWhichIsA("SurfaceGui")

	if v1 and (v1.Face ~= Enum.NormalId.Top and v1.Face ~= Enum.NormalId.Bottom) then
		return Vector3.FromNormalId(v1.Face)
	end

	return Vector3.FromNormalId(Enum.NormalId.Front)
end

local function getPlayerPosition() --[[ getPlayerPosition | Line: 56 | Upvalues: Players (copy), Workspace (copy) ]]
	local v1 = Players.LocalPlayer and Players.LocalPlayer.Character
	local v2 = if v1 then v1.PrimaryPart else v1

	if v2 then
		return v2.Position
	end

	local CurrentCamera = Workspace.CurrentCamera

	if CurrentCamera then
		return CurrentCamera.CFrame.Position
	end

	return nil
end

local function faceBoards() --[[ faceBoards | Line: 68 | Upvalues: Players (copy), Workspace (copy), DeepsConfig (copy), t2 (copy), getGuiFaceNormal (copy) ]]
	local v1 = Players.LocalPlayer and Players.LocalPlayer.Character
	local v2 = if v1 then v1.PrimaryPart else v1
	local v3

	if v2 then
		v3 = v2.Position
	else
		local CurrentCamera = Workspace.CurrentCamera

		v3 = if CurrentCamera then CurrentCamera.CFrame.Position else nil
	end

	if not v3 then
		return
	end

	local CounterBoardFaceRange = DeepsConfig.CounterBoardFaceRange

	for v4 in t2 do
		local Position = v4.Position
		local v7 = Vector3.new(v3.X - Position.X, 0, v3.Z - Position.Z)
		local Magnitude = v7.Magnitude

		if not (CounterBoardFaceRange < Magnitude or Magnitude < 0.01) then
			v4.CFrame = CFrame.lookAt(Position, Position + v7) * CFrame.lookAt(Vector3.new(0, 0, 0), getGuiFaceNormal(v4)):Inverse()
		end
	end
end

local function formatTime(p1) --[[ formatTime | Line: 89 ]]
	local v2 = math.max(math.floor(p1), 0)
	local v3 = v2 // 86400
	local v4 = v2 % 86400 // 3600
	local v5 = v2 % 3600 // 60
	local v6 = v2 % 60

	if v3 > 0 then
		return ("%*d %*"):format(v3, (string.format("%02d:%02d:%02d", v4, v5, v6)))
	end

	return string.format("%02d:%02d:%02d", v4, v5, v6)
end

local function getTemplate() --[[ getTemplate | Line: 101 | Upvalues: ReplicatedStorage (copy) ]]
	local v1 = ReplicatedStorage:FindFirstChild("shared")
	local v2 = if v1 then v1:FindFirstChild("model") else v1
	local v3 = if v2 then v2:FindFirstChild("DeepsCounterBoard") else v2

	if v3 and v3:IsA("SurfaceGui") then
		return v3
	end

	return nil
end

local function buildTemplateBoard(p1) --[[ buildTemplateBoard | Line: 111 | Upvalues: ReplicatedStorage (copy), DeepsConfig (copy) ]]
	local v1 = ReplicatedStorage:FindFirstChild("shared")
	local v2 = if v1 then v1:FindFirstChild("model") else v1
	local v3 = if v2 then v2:FindFirstChild("DeepsCounterBoard") else v2
	local v4 = if v3 and v3:IsA("SurfaceGui") then v3 else nil

	if not v4 then
		return nil
	end

	local v5 = v4:Clone()

	v5.Enabled = true

	local RowTemplate = v5:FindFirstChild("RowTemplate")

	if not (RowTemplate and RowTemplate:IsA("GuiObject")) then
		v5:Destroy()

		return nil
	end

	local t = {}

	for v6 in DeepsConfig.GuaranteedSpawns do
		local v7 = RowTemplate:Clone()

		v7.Name = ("Row%*"):format(v6)
		v7.LayoutOrder = v6
		v7.Visible = true

		local Label = v7:FindFirstChild("Label", true)

		if Label and Label:IsA("TextLabel") then
			Label.Text = ""
			table.insert(t, Label)
		end

		v7.Parent = v5
	end

	if #t == #DeepsConfig.GuaranteedSpawns then
		v5.Parent = p1

		return {
			template = true,
			rows = t
		}
	end

	v5:Destroy()

	return nil
end

local function buildFallbackBoard(p1) --[[ buildFallbackBoard | Line: 145 | Upvalues: DeepsConfig (copy), FishConfig (copy) ]]
	local DeepsCounterGui = Instance.new("SurfaceGui")

	DeepsCounterGui.Name = "DeepsCounterGui"
	DeepsCounterGui.Face = Enum.NormalId.Front
	DeepsCounterGui.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
	DeepsCounterGui.PixelsPerStud = 30
	DeepsCounterGui.Parent = p1

	local UIListLayout = Instance.new("UIListLayout")

	UIListLayout.Padding = UDim.new(0.02, 0)
	UIListLayout.VerticalAlignment = Enum.VerticalAlignment.Center
	UIListLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center
	UIListLayout.Parent = DeepsCounterGui

	local t = {}

	for v1, v2 in DeepsConfig.GuaranteedSpawns do
		local v3 = FishConfig[v2.FishName]
		local TextLabel = Instance.new("TextLabel")

		TextLabel.LayoutOrder = v1
		TextLabel.Size = UDim2.fromScale(0.95, 0.9 / math.max(#DeepsConfig.GuaranteedSpawns, 1))
		TextLabel.BackgroundTransparency = 1
		TextLabel.Font = Enum.Font.GothamBlack
		TextLabel.TextScaled = true
		TextLabel.TextColor3 = v3 and v3.Rarity.rarityColor or Color3.new(255/255, 255/255, 255/255)
		TextLabel.Text = ""

		local UIStroke = Instance.new("UIStroke")

		UIStroke.Color = Color3.new(0/255, 0/255, 0/255)
		UIStroke.Thickness = 2
		UIStroke.Parent = TextLabel
		TextLabel.Parent = DeepsCounterGui
		table.insert(t, TextLabel)
	end

	return {
		template = false,
		rows = t
	}
end

local function buildBoard(p1) --[[ buildBoard | Line: 180 | Upvalues: t2 (copy), buildTemplateBoard (copy), buildFallbackBoard (copy) ]]
	if t2[p1] then
		return
	end

	t2[p1] = buildTemplateBoard(p1) or buildFallbackBoard(p1)
end

local function scanBoards() --[[ scanBoards | Line: 187 | Upvalues: t2 (copy), Workspace (copy), DeepsConfig (copy), buildTemplateBoard (copy), buildFallbackBoard (copy) ]]
	for v1 in t2 do
		if not v1.Parent then
			t2[v1] = nil
		end
	end

	for v2, v3 in Workspace:GetDescendants() do
		if v3.Name == DeepsConfig.CounterBoardName and v3:IsA("BasePart") and not t2[v3] then
			t2[v3] = buildTemplateBoard(v3) or buildFallbackBoard(v3)
		end
	end
end

local function updateBoards() --[[ updateBoards | Line: 202 | Upvalues: Workspace (copy), t2 (copy), DeepsConfig (copy), FishConfig (copy), formatTime (copy) ]]
	local v2 = math.floor((Workspace:GetServerTimeNow()))

	for v3, v4 in t2 do
		for v5, v6 in DeepsConfig.GuaranteedSpawns do
			local v7 = v4.rows[v5]

			if v7 then
				local v8 = FishConfig[v6.FishName]
				local v9 = FishConfig[v6.FishName] and string.upper(v8.DisplayName) or v6.FishName
				local v10 = v6.Interval - v2 % v6.Interval

				if v4.template then
					local v12 = (v8 and v8.Rarity.rarityColor or Color3.new(255/255, 255/255, 255/255)):ToHex()

					v7.Text = ("GUARANTEED <font color=\"#%*\">%*</font> SPAWNS IN : %*"):format(v12, v9, (("<font color=\"#%*\">%*</font>"):format(v12, (formatTime(v10)))))

					continue
				end

				v7.Text = ("GUARANTEED %* IN: %*"):format(v9, (formatTime(v10)))
			end
		end
	end
end

function t.Init(p1) --[[ Init | Line: 227 | Upvalues: DeepsConfig (copy), RunService (copy), scanBoards (copy), updateBoards (copy), faceBoards (copy) ]]
	if DeepsConfig.Enabled then
		local v1 = 0
		local v2 = 0

		RunService.Heartbeat:Connect(function() --[[ Line: 233 | Upvalues: v1 (ref), scanBoards (ref), v2 (ref), updateBoards (ref), faceBoards (ref) ]]
			local v12 = os.clock()

			if v1 <= v12 then
				v1 = v12 + 5
				scanBoards()
			end

			if v2 <= v12 then
				v2 = v12 + 1
				updateBoards()
			end

			faceBoards()
		end)
	end
end

return t