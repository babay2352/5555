-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Maid = require(ReplicatedStorage.shared.class.Maid)
local t = {
	UECS = nil
}

local function resolveAssetId(p1) --[[ resolveAssetId | Line: 37 ]]
	if p1 == nil then
		return nil
	end

	local v1 = tostring(p1)

	if v1 == "" or v1 == "0" then
		return nil
	end

	if not string.match(v1, "^%a+://") then
		v1 = "rbxassetid://" .. v1
	end

	return v1
end

local function findSoundParent(p1) --[[ findSoundParent | Line: 51 ]]
	if p1:IsA("BasePart") then
		return p1
	end

	if not p1:IsA("Model") then
		return nil
	end

	return p1.PrimaryPart or p1:FindFirstChildWhichIsA("BasePart", true)
end

local function setupSound(p1, p2) --[[ setupSound | Line: 64 ]]
	local v1 = if p1:IsA("BasePart") then p1 elseif p1:IsA("Model") then p1.PrimaryPart or p1:FindFirstChildWhichIsA("BasePart", true) else nil

	if not v1 then
		return nil
	end

	local AnimatedHammerSFX = Instance.new("Sound")

	AnimatedHammerSFX.Name = "AnimatedHammerSFX"
	AnimatedHammerSFX.Volume = p1:GetAttribute("SoundVolume") or 1.5
	AnimatedHammerSFX.RollOffMaxDistance = 240

	local v2 = p1:GetAttribute("SoundId")
	local v3

	if v2 == nil then
		v3 = nil
	else
		local v4 = tostring(v2)

		if v4 == "" or v4 == "0" then
			v3 = nil
		else
			if not string.match(v4, "^%a+://") then
				v4 = "rbxassetid://" .. v4
			end

			v3 = v4
		end
	end

	if not v3 then
		local v5 = tostring("")

		if v5 == "" or v5 == "0" then
			v3 = nil
		else
			if not string.match(v5, "^%a+://") then
				v5 = "rbxassetid://" .. v5
			end

			v3 = v5
		end

		if not v3 then
			v3 = ""
		end
	end

	AnimatedHammerSFX.SoundId = v3
	AnimatedHammerSFX:AddTag("SFX")
	AnimatedHammerSFX.Parent = v1
	p2:GiveTask(AnimatedHammerSFX)
	p2:GiveTask(p1:GetAttributeChangedSignal("SoundId"):Connect(function() --[[ Line: 80 | Upvalues: AnimatedHammerSFX (copy), p1 (copy) ]]
		local v2 = p1:GetAttribute("SoundId")
		local v3

		if v2 == nil then
			v3 = nil
		else
			local v4 = tostring(v2)

			if v4 == "" or v4 == "0" then
				v3 = nil
			else
				if not string.match(v4, "^%a+://") then
					v4 = "rbxassetid://" .. v4
				end

				v3 = v4
			end
		end

		if not v3 then
			local v5 = tostring("")

			if v5 == "" or v5 == "0" then
				v3 = nil
			else
				if not string.match(v5, "^%a+://") then
					v5 = "rbxassetid://" .. v5
				end

				v3 = v5
			end

			if not v3 then
				v3 = ""
			end
		end

		AnimatedHammerSFX.SoundId = v3
	end))
	p2:GiveTask(p1:GetAttributeChangedSignal("SoundVolume"):Connect(function() --[[ Line: 83 | Upvalues: AnimatedHammerSFX (copy), p1 (copy) ]]
		AnimatedHammerSFX.Volume = p1:GetAttribute("SoundVolume") or 1.5
	end))

	return function() --[[ Line: 87 | Upvalues: AnimatedHammerSFX (copy), p1 (copy) ]]
		if AnimatedHammerSFX.SoundId == "" then
			return
		end

		if not (AnimatedHammerSFX.Parent and p1:IsDescendantOf(workspace)) then
			return
		end

		AnimatedHammerSFX:Play()
	end
end

local function setupParticles(p1, p2) --[[ setupParticles | Line: 100 ]]
	local v1 = nil

	local function resolve() --[[ resolve | Line: 103 | Upvalues: v1 (ref), p1 (copy) ]]
		if v1 then
			return v1
		end

		local v12 = if p1.Name == "7" then p1 else p1:FindFirstChild("7", true)

		if not v12 then
			return {}
		end

		local t = {}

		for v2, v3 in v12:GetDescendants() do
			if v3:IsA("ParticleEmitter") then
				table.insert(t, v3)
			end
		end

		if #t == 0 then
			return {}
		end

		v1 = t

		return t
	end

	local function setEnabled(p1, p2) --[[ setEnabled | Line: 124 ]]
		for v1, v2 in p1 do
			v2.Enabled = p2
		end
	end

	for v2, v3 in resolve() do
		v3.Enabled = false
	end

	p2:GiveTask(function() --[[ Line: 133 | Upvalues: resolve (copy) ]]
		for v1, v2 in resolve() do
			v2.Enabled = false
		end
	end)

	local v4 = 0

	return function() --[[ Line: 141 | Upvalues: resolve (copy), v4 (ref) ]]
		local v1 = resolve()

		if #v1 == 0 then
			return
		end

		v4 = v4 + 1

		local v2 = v4

		for v3, v42 in v1 do
			v42.Enabled = true
		end

		task.delay(0.5, function() --[[ Line: 149 | Upvalues: v4 (ref), v2 (copy), v1 (copy) ]]
			if v4 ~= v2 then
				return
			end

			for v12, v22 in v1 do
				v22.Enabled = false
			end
		end)
	end
end

local function setupHammer(p1, p2) --[[ setupHammer | Line: 157 | Upvalues: setupSound (copy), setupParticles (copy) ]]
	if not (p1:IsA("Model") or p1:IsA("BasePart")) then
		return
	end

	local v1 = p1:FindFirstChildOfClass("AnimationController") or p1:FindFirstChildOfClass("Humanoid")

	if not v1 then
		v1 = p1:WaitForChild("AnimationController", 30)
	end

	if not p1.Parent then
		return
	end

	if not v1 then
		local AnimationController = Instance.new("AnimationController")

		AnimationController.Parent = p1
		v1 = AnimationController
	end

	local v2 = v1:FindFirstChildOfClass("Animator") or v1:WaitForChild("Animator", 30)

	if not p1.Parent then
		return
	end

	if not v2 then
		local Animator = Instance.new("Animator")

		Animator.Parent = v1
		v2 = Animator
	end

	local Animation = Instance.new("Animation")

	Animation.AnimationId = "rbxassetid://70623205617887"

	local v3 = v2:LoadAnimation(Animation)

	v3.Looped = true
	p2:GiveTask(function() --[[ Line: 194 | Upvalues: v3 (copy) ]]
		v3:Stop(0)
		v3:Destroy()
	end)

	local v4 = setupSound(p1, p2)
	local v5 = setupParticles(p1, p2)

	local function playHit() --[[ playHit | Line: 203 | Upvalues: p1 (copy), v4 (copy), v5 (copy) ]]
		if not p1:IsDescendantOf(workspace) then
			return
		end

		if v4 then
			v4()
		end

		v5()
	end

	v3:Play(0)

	local function scheduleHit() --[[ scheduleHit | Line: 218 | Upvalues: v3 (copy), p1 (copy), playHit (copy) ]]
		local Length = v3.Length

		if not (Length <= 0) then
			task.delay(math.max(Length + (p1:GetAttribute("SoundDelay") or -0.2), 0), playHit)
		end
	end

	local v6 = false

	p2:GiveTask(v3.DidLoop:Connect(function() --[[ Line: 228 | Upvalues: v6 (ref), v3 (copy), p1 (copy), playHit (copy) ]]
		v6 = true

		local Length = v3.Length

		if not (Length <= 0) then
			task.delay(math.max(Length + (p1:GetAttribute("SoundDelay") or -0.2), 0), playHit)
		end
	end))
	p2:GiveTask(task.spawn(function() --[[ Line: 236 | Upvalues: v3 (copy), p1 (copy), v6 (ref), playHit (copy) ]]
		while v3.Length <= 0 and p1.Parent do
			task.wait()
		end

		if v6 or not p1.Parent then
			return
		end

		local Length = v3.Length

		if Length <= 0 then
			return
		end

		task.delay(math.max(Length + (p1:GetAttribute("SoundDelay") or -0.2), 0), playHit)
	end))

	local v7 = false

	p2:GiveTask(p1.DescendantAdded:Connect(function(p12) --[[ Line: 249 | Upvalues: v7 (ref), p1 (copy), v3 (copy) ]]
		if not (p12:IsA("Motor6D") or p12:IsA("Bone")) then
			return
		end

		if not v7 then
			v7 = true
			task.delay(0.5, function() --[[ Line: 257 | Upvalues: v7 (ref), p1 (ref), v3 (ref) ]]
				v7 = false

				if p1.Parent then
					v3:Stop(0)
					v3:Play(0)
					v3.TimePosition = v3.TimePosition
				end
			end)
		end
	end))
end

function t.Init(p1) --[[ Init | Line: 270 | Upvalues: Maid (copy), setupHammer (copy), CollectionService (copy) ]]
	local t = {}

	local function add(p1) --[[ add | Line: 273 | Upvalues: t (copy), Maid (ref), setupHammer (ref) ]]
		if not t[p1] then
			local v1 = Maid.new()

			t[p1] = v1
			task.spawn(function() --[[ Line: 279 | Upvalues: setupHammer (ref), p1 (copy), v1 (copy) ]]
				setupHammer(p1, v1)
			end)
		end
	end

	local function remove(p1) --[[ remove | Line: 284 | Upvalues: t (copy) ]]
		local v1 = t[p1]

		if v1 then
			t[p1] = nil
			v1:DoCleaning()
		end
	end

	for v1, v2 in CollectionService:GetTagged("AnimatedHammer") do
		if not t[v2] then
			local v3 = Maid.new()

			t[v2] = v3
			task.spawn(function() --[[ Line: 279 | Upvalues: setupHammer (ref), v2 (copy), v3 (copy) ]]
				setupHammer(v2, v3)
			end)
		end
	end

	CollectionService:GetInstanceAddedSignal("AnimatedHammer"):Connect(add)
	CollectionService:GetInstanceRemovedSignal("AnimatedHammer"):Connect(remove)
end

return t