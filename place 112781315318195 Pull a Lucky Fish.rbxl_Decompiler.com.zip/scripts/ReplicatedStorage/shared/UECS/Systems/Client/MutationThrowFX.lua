-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Debris = game:GetService("Debris")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local Workspace = game:GetService("Workspace")
local CameraShaker = require(ReplicatedStorage.package.CameraShaker)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Remotes = require(ReplicatedStorage.shared.Remotes)
local SFX = require(ReplicatedStorage.client.SFX)
local UIVFX = require(ReplicatedStorage.shared.module.UIVFX)
local tweenModelScale = require(ReplicatedStorage.shared.util.tweenModelScale)
local v1 = CFrame.new(0, -0.4, 0)
local v2 = Color3.fromRGB(255, 70, 45)
local t = { "rbxassetid://137683791224666", "rbxassetid://136971903655399" }
local t2 = {
	UECS = nil
}
local v3 = nil

local function spawnExplosion(p1, p2) --[[ spawnExplosion | Line: 81 | Upvalues: ReplicatedStorage (copy), Workspace (copy), RunService (copy), Debris (copy) ]]
	local fx = ReplicatedStorage.shared.model:FindFirstChild("fx")
	local v1 = if fx then fx:FindFirstChild(p1) else fx

	if not v1 then
		warn((("[MutationThrowFX] explosion template \'%*\' not found in model.fx"):format(p1)))

		return
	end

	local v2 = v1:Clone()

	if v2:IsA("BasePart") then
		v2.Anchored = true
		v2.CanCollide = false
		v2.CFrame = CFrame.new(p2)
		v2.Parent = Workspace
	elseif v2:IsA("Model") then
		v2.Parent = Workspace

		for v3, v4 in v2:GetDescendants() do
			if v4:IsA("BasePart") then
				v4.Anchored = true
				v4.CanCollide = false
			end
		end

		v2:PivotTo(CFrame.new(p2))
	else
		v2.Parent = Workspace
	end

	task.spawn(function() --[[ Line: 111 | Upvalues: RunService (ref), v2 (copy), Debris (ref) ]]
		RunService.Heartbeat:Wait()

		local v1 = 0

		for v22, v3 in v2:GetDescendants() do
			if v3:IsA("ParticleEmitter") then
				local v4 = v3:GetAttribute("EmitDelay")
				local v5 = if typeof(v4) == "number" then v4 else 0
				local v7 = math.max(v1, v5 + v3.Lifetime.Max)

				if v3.Enabled then
					v1 = v7

					continue
				end

				local v8 = v3:GetAttribute("EmitCount")
				local v9 = if typeof(v8) == "number" then v8 else 1

				if v5 > 0 then
					task.delay(v5, function() --[[ Line: 124 | Upvalues: v3 (copy), v9 (copy) ]]
						if not v3.Parent then
							return
						end

						v3:Emit(v9)
					end)
					v1 = v7

					continue
				end

				v3:Emit(v9)
				v1 = v7
			end
		end

		Debris:AddItem(v2, v1 + 1)
	end)
end

local function playGrenadeExplosionVFX(p1) --[[ playGrenadeExplosionVFX | Line: 140 | Upvalues: spawnExplosion (copy), SFX (copy), t (copy), v3 (ref), UIVFX (copy), v2 (copy) ]]
	spawnExplosion("Red-Explosion", p1)
	SFX.new("rbxassetid://137715760191944", 0.6)
	task.delay(0.12, function() --[[ Line: 144 | Upvalues: spawnExplosion (ref), p1 (copy), t (ref), SFX (ref) ]]
		spawnExplosion("HolyExplosion", p1)

		for v1, v2 in t do
			SFX.new(v2, 0.6)
		end
	end)

	if v3 then
		v3:ShakeOnce(5, 10, 0, 1.5)
	end

	UIVFX.Vignette.Start(v2)
	task.delay(1.2, function() --[[ Line: 161 | Upvalues: UIVFX (ref) ]]
		UIVFX.Vignette.Stop()
	end)
end

local function playCharacterDisappearVFX(p1, p2) --[[ playCharacterDisappearVFX | Line: 167 ]]
	print("[MutationThrowFX] character disappear VFX slot @", p2)
end

local function buildAvatar(p1, p2) --[[ buildAvatar | Line: 179 | Upvalues: Players (copy) ]]
	local ok, result = pcall(function() --[[ Line: 180 | Upvalues: Players (ref), p1 (copy) ]]
		return Players:CreateHumanoidModelFromDescription(Players:GetHumanoidDescriptionFromUserId(p1), Enum.HumanoidRigType.R15)
	end)

	if ok and result then
		return result
	end

	warn("[MutationThrowFX] avatar load failed, cloning marker rig:", result)

	local v1 = p2:Clone()
	local AnimSaves = v1:FindFirstChild("AnimSaves")

	if not AnimSaves then
		return v1
	end

	AnimSaves:Destroy()

	return v1
end

local function rigidifyTo(p1, p2) --[[ rigidifyTo | Line: 198 ]]
	for v1, v2 in p1:GetDescendants() do
		if v2:IsA("BasePart") then
			v2.CanCollide = false
			v2.Massless = true

			if v2 ~= p2 then
				v2.Anchored = false

				local WeldConstraint = Instance.new("WeldConstraint")

				WeldConstraint.Part0 = p2
				WeldConstraint.Part1 = v2
				WeldConstraint.Parent = p2
			end
		end
	end
end

local function loadTrack(p1, p2) --[[ loadTrack | Line: 214 ]]
	local Animator = p1:FindFirstChildOfClass("Animator")

	if not Animator then
		Animator = Instance.new("Animator")
		Animator.Parent = p1
	end

	local Animation = Instance.new("Animation")

	Animation.AnimationId = p2

	local ok, result = pcall(function() --[[ Line: 222 | Upvalues: Animator (ref), Animation (copy) ]]
		return Animator:LoadAnimation(Animation)
	end)

	if ok then
		return result
	end

	warn("[MutationThrowFX] failed to load animation", p2, result)

	return nil
end

local function dissolveAndCleanup(p1, p2, p3) --[[ dissolveAndCleanup | Line: 233 | Upvalues: TweenService (copy) ]]
	local t = {}

	for v1, v2 in p1:GetDescendants() do
		if v2:IsA("BasePart") or v2:IsA("Decal") then
			table.insert(t, TweenService:Create(v2, TweenInfo.new(0.6), {
				Transparency = 1
			}))
		end
	end

	for v5, v6 in t do
		v6:Play()
	end

	task.delay(0.6, function() --[[ Line: 246 | Upvalues: p1 (copy), p2 (copy), p3 (copy) ]]
		p1:Destroy()

		if not p2 then
			p3()

			return
		end

		p2:Destroy()
		p3()
	end)
end

local function playSequence(p1) --[[ playSequence | Line: 259 | Upvalues: Workspace (copy), buildAvatar (copy), tweenModelScale (copy), SFX (copy), TweenService (copy), ReplicatedStorage (copy), rigidifyTo (copy), v1 (copy), loadTrack (copy), RunService (copy), playGrenadeExplosionVFX (copy), dissolveAndCleanup (copy) ]]
	local FinalThrowPositionStart = Workspace:FindFirstChild("FinalThrowPositionStart")
	local FinalThrowPosition = Workspace:FindFirstChild("FinalThrowPosition")

	if not (FinalThrowPositionStart and (FinalThrowPosition and (FinalThrowPositionStart.PrimaryPart and FinalThrowPosition.PrimaryPart))) then
		warn("[MutationThrowFX] missing FinalThrowPositionStart / FinalThrowPosition markers")

		return
	end

	local v2 = FinalThrowPosition.PrimaryPart.CFrame
	local v3 = buildAvatar(p1, FinalThrowPositionStart)

	if not v3 then
		return
	end

	local HumanoidRootPart = v3:FindFirstChild("HumanoidRootPart")
	local Humanoid = v3:FindFirstChildOfClass("Humanoid")

	if not (HumanoidRootPart and Humanoid) then
		v3:Destroy()

		return
	end

	for v4, v5 in v3:GetDescendants() do
		if v5:IsA("BasePart") then
			v5.CanCollide = false
		end
	end

	HumanoidRootPart.Anchored = true
	Humanoid.PlatformStand = true
	v3:PivotTo(FinalThrowPositionStart.PrimaryPart.CFrame)
	v3.Parent = Workspace
	tweenModelScale(v3, TweenInfo.new(0.7, Enum.EasingStyle.Back, Enum.EasingDirection.Out), 15.314)
	SFX.new("rbxassetid://140049602451857", 0.6)

	local v6 = TweenService:Create(HumanoidRootPart, TweenInfo.new(1.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
		CFrame = v2
	})

	v6:Play()
	v6.Completed:Wait()

	local RightHand = v3:FindFirstChild("RightHand")
	local fx = ReplicatedStorage.shared.model:FindFirstChild("fx")
	local v7 = if fx then fx:FindFirstChild("MutationGrenade") else fx
	local v8 = nil
	local v9 = nil
	local v10 = nil

	if v7 and RightHand then
		v8 = v7:Clone()
		v9 = v8.PrimaryPart or v8:FindFirstChild("Core") or v8:FindFirstChildWhichIsA("BasePart")

		if v9 then
			rigidifyTo(v8, v9)
			v9.Anchored = false
			v8.Parent = v3
			v9.CFrame = RightHand.CFrame * v1
			v10 = Instance.new("WeldConstraint")
			v10.Part0 = RightHand
			v10.Part1 = v9
			v10.Parent = v9
		end
	elseif not v7 then
		warn("[MutationThrowFX] ReplicatedStorage.shared.model.fx.MutationGrenade not found")
	end

	local v122 = loadTrack(Humanoid, "rbxassetid://107364603410071")

	if v122 then
		v122.Looped = true
		v122:Play()
	end

	local v13 = os.clock()
	local v14 = RunService.RenderStepped:Connect(function() --[[ Line: 354 | Upvalues: v13 (copy), HumanoidRootPart (copy), v2 (copy) ]]
		debug.profilebegin("UECS/MutationThrowFX.FloatBob")
		HumanoidRootPart.CFrame = v2 * CFrame.new(0, math.sin((os.clock() - v13) * math.pi * 1.6) * 0.5, 0)
		debug.profileend()
	end)

	task.wait(1.5)

	local v15 = loadTrack(Humanoid, "rbxassetid://129399266651723")

	if v15 then
		v15.Priority = Enum.AnimationPriority.Action
		v15.Looped = false
		v15:Play()
	end

	SFX.new("rbxassetid://138249323589226", 0.6)
	task.delay(0.53, function() --[[ Line: 372 | Upvalues: v8 (ref), v9 (ref), v10 (ref), RunService (ref), playGrenadeExplosionVFX (ref), v14 (ref), v122 (copy), v3 (copy), HumanoidRootPart (copy), dissolveAndCleanup (ref) ]]
		local v1

		if v8 and v9 then
			if v10 then
				v10:Destroy()
			end

			v9.Anchored = true

			local Position = v9.Position
			local v4 = (Position + Vector3.new(146, 6.5, -378)) / 2 + Vector3.new(0, math.max(12, (Vector3.new(146, 6.5, -378) - Position).Magnitude * 0.35), 0)
			local sum = 0

			while sum < 1 do
				sum = sum + RunService.RenderStepped:Wait()

				local v5 = math.min(sum / 1, 1)
				local v6 = 1 - v5
				local v7 = v6 * v6 * Position + v6 * 2 * v5 * v4 + v5 * v5 * Vector3.new(146, 6.5, -378)
				local v82 = v6 * 2 * (v4 - Position) + v5 * 2 * (Vector3.new(146, 6.5, -378) - v4)

				if v82.Magnitude > 0.001 then
					v9.CFrame = CFrame.lookAt(v7, v7 + v82.Unit)

					continue
				end

				v9.CFrame = CFrame.new(v7)
			end

			v1 = v9.Position
		else
			v1 = Vector3.new(146, 6.5, -378)
		end

		playGrenadeExplosionVFX(v1)

		if v8 then
			v8:Destroy()
		end

		if v14 then
			v14:Disconnect()
		end

		local mutationthrowfxcharacterdisappearvfxslot

		if v122 then
			v122:Stop()
		end

		mutationthrowfxcharacterdisappearvfxslot = HumanoidRootPart.Position
		print("[MutationThrowFX] character disappear VFX slot @", mutationthrowfxcharacterdisappearvfxslot)
		dissolveAndCleanup(v3, nil, function() --[[ Line: 415 ]] end)
	end)
end

function t2.Init(p1) --[[ Init | Line: 419 | Upvalues: v3 (ref), CameraShaker (copy), Workspace (copy), Remotes (copy), playSequence (copy) ]]
	v3 = CameraShaker.new(Enum.RenderPriority.Camera.Value, function(p1) --[[ Line: 421 | Upvalues: Workspace (ref) ]]
		local CurrentCamera = Workspace.CurrentCamera

		if not CurrentCamera then
			return
		end

		CurrentCamera.CFrame = CurrentCamera.CFrame * p1
	end)
	v3:Start()
	Remotes.MutationThrowFX:On(function(p1) --[[ Line: 429 | Upvalues: playSequence (ref) ]]
		if type(p1) ~= "table" then
			return
		end

		local v1 = tonumber(p1.AuthorId)

		if v1 and not (v1 <= 0) then
			task.spawn(playSequence, v1)
		end
	end)
end

return t2