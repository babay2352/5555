-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ContextActionService = game:GetService("ContextActionService")
local GuiService = game:GetService("GuiService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local UserInputService = game:GetService("UserInputService")
local AnimationConfig = require(ReplicatedStorage.shared.config.AnimationConfig)
local BeamTo = require(ReplicatedStorage.client.BeamTo)
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local FishingFloatsConfig = require(ReplicatedStorage.shared.config.FishingFloatsConfig)
local FishingFloatsRecycle = require(ReplicatedStorage.shared.UECS.Components.FishingFloatsRecycle)
local FloatRecycleMachineConfig = require(ReplicatedStorage.shared.config.FloatRecycleMachineConfig)
local GardenConfig = require(ReplicatedStorage.shared.config.GardenConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local RebirthUnlocksConfig = require(ReplicatedStorage.shared.config.RebirthUnlocksConfig)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local SFX = require(ReplicatedStorage.client.SFX)
local bindToButtonPress = require(ReplicatedStorage.shared.util.bindToButtonPress)
local createAnimationInstance = require(ReplicatedStorage.shared.util.createAnimationInstance)
local notifications = require(ReplicatedStorage.shared.module.notifications)
local FloatRecycleTag = GardenConfig.FloatRecycleTag
local v1 = Color3.fromRGB(85, 85, 85)
local v2 = Color3.fromRGB(255, 255, 255)
local LocalPlayer = Players.LocalPlayer

local function getAnimator(p1) --[[ getAnimator | Line: 36 ]]
	local v1 = p1:FindFirstChildWhichIsA("AnimationController", true)

	if not v1 then
		local AnimationController = Instance.new("AnimationController")

		AnimationController.Parent = p1
		v1 = AnimationController
	end

	local v2 = v1:FindFirstChildWhichIsA("Animator")

	if not v2 then
		local Animator = Instance.new("Animator")

		Animator.Parent = v1
		v2 = Animator
	end

	return v2
end

local function recycleAnimationId() --[[ recycleAnimationId | Line: 50 | Upvalues: AnimationConfig (copy) ]]
	local FloatRecycleMachine = AnimationConfig.FloatRecycleMachine
	local v1 = if FloatRecycleMachine then FloatRecycleMachine.Recycle else FloatRecycleMachine

	if typeof(v1) == "string" and v1 ~= "" then
		return v1
	end

	return nil
end

local function loadTrack(p1, p2) --[[ loadTrack | Line: 59 | Upvalues: createAnimationInstance (copy) ]]
	local ok, result = pcall(function() --[[ Line: 60 | Upvalues: p1 (copy), createAnimationInstance (ref), p2 (copy) ]]
		return p1:LoadAnimation(createAnimationInstance(p2))
	end)

	if ok and result then
		result.Looped = false
		result.Priority = Enum.AnimationPriority.Action

		return result
	end

	warn((("[FloatRecycleMachine] failed to load animation %*: %*"):format(p2, result)))

	return nil
end

local function findButton(p1) --[[ findButton | Line: 72 ]]
	if p1:IsA("GuiButton") then
		return p1
	end

	return p1:FindFirstChildWhichIsA("GuiButton", true)
end

local function paintTile(p1, p2, p3, p4) --[[ paintTile | Line: 79 | Upvalues: v1 (copy), v2 (copy) ]]
	local ImageLabel = p1:FindFirstChild("ImageLabel")
	local v12 = if ImageLabel and ImageLabel:IsA("ImageLabel") then ImageLabel else nil

	if p2 and v12 then
		v12.Image = p2
	elseif p2 and (p1:IsA("ImageButton") or p1:IsA("ImageLabel")) then
		p1.Image = p2
	end

	local v22 = if p4 then v1 else v2

	if v12 then
		v12.ImageColor3 = v22
	elseif p1:IsA("ImageButton") or p1:IsA("ImageLabel") then
		p1.ImageColor3 = v22
	end

	local Frame = p1:FindFirstChild("Frame")

	if not (Frame and Frame:IsA("Frame")) then
		return
	end

	local v3 = if p4 then v1 else p3

	Frame.BackgroundColor3 = v3

	local UIGradient = Frame:FindFirstChildOfClass("UIGradient")

	if not UIGradient then
		return
	end

	UIGradient.Color = ColorSequence.new(v3, if p4 then v1 else v2)
end

return {
	UECS = nil,
	Init = function(p1) --[[ Init | Line: 110 | Upvalues: LocalPlayer (copy), FishingFloatsRecycle (copy), FishingFloatsConfig (copy), UserInputService (copy), GuiService (copy), FloatRecycleMachineConfig (copy), v2 (copy), paintTile (copy), SFX (copy), ClientPlayerData (copy), notifications (copy), Remotes (copy), RebirthUnlocksConfig (copy), BeamTo (copy), bindToButtonPress (copy), ContextActionService (copy), GardenConfig (copy), getAnimator (copy), AnimationConfig (copy), loadTrack (copy), CollectionService (copy), FloatRecycleTag (copy) ]]
		local MainUI = LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("MainUI")
		local FishingFloatsRecycle2 = MainUI:FindFirstChild("FishingFloatsRecycle", true)

		if not FishingFloatsRecycle2 then
			warn("[FloatRecycleMachine] MainUI.FishingFloatsRecycle not found \226\128\148 the recycle machine has no UI")

			return
		end

		FishingFloatsRecycle2.Visible = false

		local v1 = FishingFloatsRecycle2:FindFirstChild("Content")
		local v22 = v1 and v1:FindFirstChild("AllFloats")
		local v3 = v1 and v1:FindFirstChild("SelectedFloats")
		local v4 = v1 and v1:FindFirstChild("ClaimFloatCrate")
		local v5 = v1 and v1:FindFirstChild("SelectedLabel")
		local v6 = v1 and v1:FindFirstChild("NoFloatsDisplay")

		if not (v22 and (v3 and v4)) then
			warn("[FloatRecycleMachine] MainUI.FishingFloatsRecycle.Content is missing AllFloats/SelectedFloats/ClaimFloatCrate")

			return
		end

		local Template = v22:FindFirstChild("Template")
		local Template2 = v3:FindFirstChild("Template")

		if not (Template and Template2) then
			warn("[FloatRecycleMachine] AllFloats and SelectedFloats each need a Template child")

			return
		end

		local v7 = Template:Clone()
		local v8 = Template2:Clone()

		Template:Destroy()
		Template2:Destroy()

		local v9 = nil
		local ImageLabel = v4:FindFirstChild("ImageLabel")

		if ImageLabel and ImageLabel:IsA("ImageLabel") then
			v9 = ImageLabel.Image
		elseif v4:IsA("ImageButton") then
			v9 = v4.Image
		end

		local v10 = FishingFloatsRecycle.Add(FishingFloatsRecycle2)
		local t = {}
		local v11 = 0
		local v12 = false
		local v13 = nil
		local v14 = nil
		local t2 = {}

		for v15, v16 in FishingFloatsConfig.TierOrder do
			t[v16] = v15
		end

		local v17 = nil
		local t3 = {}
		local t4 = {}

		local function refocusAllFloats(p1) --[[ refocusAllFloats | Line: 174 | Upvalues: UserInputService (ref), t3 (copy), GuiService (ref) ]]
			if not p1 or UserInputService.PreferredInput ~= Enum.PreferredInput.Gamepad then
				return
			end

			for i = 0, #t3 do
				local v1 = t3[p1 + i] or t3[p1 - i]

				if v1 and v1.Selectable then
					GuiService.SelectedObject = v1

					return
				end
			end
		end

		local function clearSelection() --[[ clearSelection | Line: 188 | Upvalues: v14 (ref), t2 (ref), v11 (ref) ]]
			v14 = nil
			t2 = {}
			v11 = 0
		end

		local function closeWindow() --[[ closeWindow | Line: 194 | Upvalues: p1 (copy), v10 (copy) ]]
			local v1 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

			if not v1 or v1.OpenedUIComponent:Get() ~= v10 then
				return
			end

			v1.OpenedUIComponent:Set(nil)
		end

		local function f18() --[[ Line: 201 | Upvalues: v14 (ref), FloatRecycleMachineConfig (ref), v11 (ref), FishingFloatsConfig (ref), v2 (ref), paintTile (ref), v4 (copy), v9 (ref) ]]
			local v1 = if v14 then FloatRecycleMachineConfig.crateForTier(v14) else nil
			local v22 = if v11 == FloatRecycleMachineConfig.RequiredFloats then if v1 == nil then false else true else false

			paintTile(v4, if v1 then v1.Image else v9, if v14 then FishingFloatsConfig.TierColors[v14] or v2 else v2, not v22)

			local Amount = v4:FindFirstChild("Amount")

			if Amount and Amount:IsA("TextLabel") then
				Amount.Text = if v22 then "x1" else ""
			end

			local v8 = v4
			local v92 = if v8:IsA("GuiButton") then v8 else v8:FindFirstChildWhichIsA("GuiButton", true)

			if not v92 then
				return
			end

			v92.Selectable = v22
			v92.AutoButtonColor = v22
		end

		local function v19() --[[ Line: 220 | Upvalues: v3 (copy), v5 (copy), v11 (ref), FloatRecycleMachineConfig (ref), v14 (ref), f18 (ref), t2 (ref), v8 (copy), FishingFloatsConfig (ref), paintTile (ref), v2 (ref), SFX (ref), v17 (ref), v19 (ref), refocusAllFloats (copy), t4 (copy) ]]
			for v1, v22 in v3:GetChildren() do
				if v22:HasTag("RecycleSelectedItem") then
					v22:Destroy()
				end
			end

			if v5 then
				v5.Text = string.format("Selected Floats (%d/%d)", v11, FloatRecycleMachineConfig.RequiredFloats)
			end

			if v14 then
				local v32 = v14
				local t = {}
				local count = 0

				for v4 in t2 do
					table.insert(t, v4)
				end

				table.sort(t)

				for v52, v6 in t do
					for i = 1, t2[v6] do
						count = count + 1

						local v7 = v8:Clone()

						v7:AddTag("RecycleSelectedItem")
						v7.Name = v6
						v7.Visible = true
						v7.LayoutOrder = count
						v7.Parent = v3

						local Amount = v7:FindFirstChild("Amount")

						if Amount and Amount:IsA("TextLabel") then
							Amount.Text = ""
						end

						local v82 = FishingFloatsConfig.Floats[v6]

						paintTile(v7, if v82 then v82.TierImages and v82.TierImages[v32] else v82, FishingFloatsConfig.TierColors[v32] or v2, false)

						local v12 = if v7:IsA("GuiButton") then v7 else v7:FindFirstChildWhichIsA("GuiButton", true)

						if v12 then
							v12.Selectable = true
							v12.SelectionOrder = count
							v12.Activated:Connect(function() --[[ Line: 268 | Upvalues: t2 (ref), v6 (copy), v11 (ref), v14 (ref), SFX (ref), v17 (ref), v19 (ref), refocusAllFloats (ref), t4 (ref), v32 (copy) ]]
								local v1 = t2[v6]

								if not v1 or v1 <= 0 then
									return
								end

								if v1 <= 1 then
									t2[v6] = nil
								else
									t2[v6] = v1 - 1
								end

								v11 = v11 - 1

								if v11 <= 0 then
									v14 = nil
									t2 = {}
									v11 = 0
								end

								SFX.new(SFX.Sounds.Pop, 0.5)
								v17()
								v19()
								refocusAllFloats(t4[("%*/%*"):format(v32, v6)])
							end)
						end
					end
				end
			end

			f18()
		end

		v17 = function() --[[ Line: 294 | Upvalues: v22 (copy), t3 (copy), t4 (copy), ClientPlayerData (ref), t (copy), v14 (ref), t2 (ref), FloatRecycleMachineConfig (ref), v11 (ref), v7 (copy), FishingFloatsConfig (ref), paintTile (ref), v2 (ref), SFX (ref), notifications (ref), v17 (ref), v19 (ref), refocusAllFloats (copy), v6 (copy) ]]
			for v1, v23 in v22:GetChildren() do
				if v23:HasTag("RecycleFloatItem") then
					v23:Destroy()
				end
			end

			table.clear(t3)
			table.clear(t4)

			local v3 = ClientPlayerData.serverProfile:getState()
			local t5 = {}

			for v62, v72 in pairs(v3.fishingFloats or {}) do
				for v8, v9 in v72 do
					table.insert(t5, {
						tier = v62,
						name = v8,
						amount = v9
					})
				end
			end

			table.sort(t5, function(p1, p2) --[[ Line: 310 | Upvalues: t (ref) ]]
				local v1 = t[p1.tier] or 0
				local v2 = t[p2.tier] or 0

				if v1 == v2 then
					return p1.name < p2.name
				end

				return v2 < v1
			end)

			local v10 = v22:FindFirstChildWhichIsA("UIGridStyleLayout")

			if v10 then
				v10.SortOrder = Enum.SortOrder.LayoutOrder
			end

			for v112, v12 in t5 do
				local tier = v12.tier
				local name = v12.name
				local v13 = if v14 == tier then t2[name] or 0 else 0
				local v142 = v12.amount - v13
				local v15 = FloatRecycleMachineConfig.isRecyclable(tier)
				local v16 = if v14 == nil then false elseif v14 == tier then false else true
				local v172 = if v11 >= FloatRecycleMachineConfig.RequiredFloats then true else false
				local v18 = if v15 then not v16 and (not v172 and (if v142 > 0 then true else false)) else v15
				local v192 = v7:Clone()

				v192:AddTag("RecycleFloatItem")
				v192.Name = name
				v192.Visible = true
				v192.LayoutOrder = v112
				v192:SetAttribute("FloatName", name)
				v192:SetAttribute("FloatTier", tier)
				v192.Parent = v22

				local Amount = v192:FindFirstChild("Amount")

				if Amount and Amount:IsA("TextLabel") then
					Amount.Text = ("x%*"):format(v142)
				end

				local v20 = FishingFloatsConfig.Floats[name]

				paintTile(v192, if v20 then v20.TierImages and v20.TierImages[tier] else v20, FishingFloatsConfig.TierColors[tier] or v2, not v18)

				local v24 = if v192:IsA("GuiButton") then v192 else v192:FindFirstChildWhichIsA("GuiButton", true)

				if v24 then
					t3[v112] = v24
					t4[("%*/%*"):format(tier, name)] = v112
					v24.Selectable = v18
					v24.SelectionOrder = v112
					v24.AutoButtonColor = v18
					v24.Activated:Connect(function() --[[ Line: 356 | Upvalues: FloatRecycleMachineConfig (ref), tier (copy), SFX (ref), notifications (ref), v14 (ref), v11 (ref), ClientPlayerData (ref), name (copy), t2 (ref), v17 (ref), v19 (ref), refocusAllFloats (ref), v112 (copy) ]]
						if not FloatRecycleMachineConfig.isRecyclable(tier) then
							SFX.new(SFX.Sounds.Error, 0.5)
							notifications:Send((("%* floats cannot be recycled."):format(tier)))

							return
						end

						if v14 ~= nil and v14 ~= tier then
							SFX.new(SFX.Sounds.Error, 0.5)
							notifications:Send("Floats must all be the same rarity.")

							return
						end

						if v11 >= FloatRecycleMachineConfig.RequiredFloats then
							SFX.new(SFX.Sounds.Error, 0.5)
							notifications:Send((("Only %* floats at a time."):format(FloatRecycleMachineConfig.RequiredFloats)))

							return
						end

						if not ((((ClientPlayerData.serverProfile:getState().fishingFloats or {})[tier] or {})[name] or 0) - (t2[name] or 0) <= 0) then
							v14 = tier
							t2[name] = (t2[name] or 0) + 1
							v11 = v11 + 1
							SFX.new(SFX.Sounds.Click, 0.5)
							v17()
							v19()
							refocusAllFloats(v112)
						end
					end)
				end
			end

			if not v6 then
				return
			end

			v6.Visible = #t5 == 0
		end

		local function claim() --[[ claim | Line: 395 | Upvalues: v12 (ref), v14 (ref), v11 (ref), FloatRecycleMachineConfig (ref), SFX (ref), notifications (ref), v13 (ref), t2 (ref), Remotes (ref), v17 (ref), v19 (ref), p1 (copy), v10 (copy) ]]
			if v12 then
				return
			end

			local v1 = v14

			if not v1 or v11 ~= FloatRecycleMachineConfig.RequiredFloats then
				SFX.new(SFX.Sounds.Error, 0.5)
				notifications:Send((("Select %* floats of the same rarity."):format(FloatRecycleMachineConfig.RequiredFloats)))

				return
			end

			local v2 = v13

			if not v2 then
				return
			end

			v12 = true

			local v4, v5 = Remotes.RequestRecycleFloats:Call({
				PlacementId = v2,
				Tier = v1,
				Floats = table.clone(t2)
			}):Await()

			v12 = false

			if v4 and (typeof(v5) == "table" and v5.ok) then
				SFX.new(SFX.Sounds.Buy, 0.5)
				v14 = nil
				t2 = {}
				v11 = 0

				local v6 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

				if not v6 or v6.OpenedUIComponent:Get() ~= v10 then
					return
				end

				v6.OpenedUIComponent:Set(nil)
			else
				local v7 = if typeof(v5) == "table" then v5.reason else nil

				if v4 then
					SFX.new(SFX.Sounds.Error, 0.5)
					notifications:Send(v7 or "Couldn\'t recycle those floats.")
					v17()
					v19()

					return
				end

				warn((("[FloatRecycleMachine] RequestRecycleFloats errored on the server: %*"):format(v5)))
				SFX.new(SFX.Sounds.Error, 0.5)
				notifications:Send(v7 or "Couldn\'t recycle those floats.")
				v17()
				v19()
			end
		end

		local v20 = if v4:IsA("GuiButton") then v4 else v4:FindFirstChildWhichIsA("GuiButton", true)

		if v20 then
			v20.Activated:Connect(claim)
		end

		local CloseButton = FishingFloatsRecycle2:FindFirstChild("CloseButton", true)

		if CloseButton and CloseButton:IsA("GuiButton") then
			CloseButton.MouseButton1Down:Connect(closeWindow)
		end

		if v6 then
			v6.Visible = false

			local v21 = RebirthUnlocksConfig.getByFeature("HookShop")
			local v222 = if v21 then v21.RebirthRequired else 2
			local v23 = if v21 then v21.LockedText else ("Reach rebirth lvl %* to unlock the Hook Shop"):format(v222)
			local v24 = v6:FindFirstChild("Navigate") or v6:FindFirstChildWhichIsA("ImageButton")

			if v24 and v24:IsA("GuiButton") then
				local v25 = false

				v24.MouseButton1Down:Connect(function() --[[ Line: 459 | Upvalues: ClientPlayerData (ref), v222 (copy), notifications (ref), v23 (copy), v25 (ref), p1 (copy), v10 (copy), BeamTo (ref), LocalPlayer (ref) ]]
					if (ClientPlayerData.serverProfile:getState().rebirthLevel or 0) < v222 then
						notifications:Send(v23)

						return
					end

					if v25 then
						return
					end

					v25 = true

					local v1 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

					if v1 and v1.OpenedUIComponent:Get() == v10 then
						v1.OpenedUIComponent:Set(nil)
					end

					local SplawikShop = workspace:FindFirstChild("SplawikShop")
					local v2 = nil

					if SplawikShop and SplawikShop:IsA("BasePart") then
						v2 = SplawikShop
					elseif SplawikShop and SplawikShop:IsA("Model") then
						v2 = SplawikShop.PrimaryPart or SplawikShop:FindFirstChildWhichIsA("BasePart")
					end

					if v2 then
						task.spawn(BeamTo, v2)
						task.spawn(function() --[[ Line: 482 | Upvalues: LocalPlayer (ref), v2 (ref), BeamTo (ref), v25 (ref) ]]
							task.wait(2)

							while true do
								local Character = LocalPlayer.Character
								local v1 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character

								if v1 and (v1.Position - v2.Position).Magnitude < 10 then
									break
								end

								task.wait(0.5)
							end

							task.spawn(BeamTo, nil)
							v25 = false
						end)
					else
						v25 = false
					end
				end)
			end
		end

		v10.Visible.OnChange:Connect(function(p1, p2) --[[ Line: 499 | Upvalues: FishingFloatsRecycle2 (copy), MainUI (copy), v14 (ref), t2 (ref), v11 (ref), v17 (ref), v19 (ref), bindToButtonPress (ref), closeWindow (copy), claim (copy), UserInputService (ref), GuiService (ref), ContextActionService (ref), v13 (ref) ]]
			FishingFloatsRecycle2.Visible = p1

			local HUD = MainUI:FindFirstChild("HUD")

			if HUD then
				HUD.Visible = not p1
			end

			if p1 then
				v14 = nil
				t2 = {}
				v11 = 0
				v17()
				v19()
			end

			if p1 == p2 then
				return
			end

			if p1 then
				bindToButtonPress("FloatRecycleClose", Enum.KeyCode.ButtonB, closeWindow)
				bindToButtonPress("FloatRecycleClaim", Enum.KeyCode.ButtonX, claim)

				if UserInputService.PreferredInput == Enum.PreferredInput.Gamepad then
					task.defer(GuiService.Select, GuiService, FishingFloatsRecycle2)
				end
			else
				ContextActionService:UnbindAction("FloatRecycleClose")
				ContextActionService:UnbindAction("FloatRecycleClaim")
				v13 = nil
				v14 = nil
				t2 = {}
				v11 = 0
				v19()

				local SelectedObject = GuiService.SelectedObject

				if not (SelectedObject and SelectedObject:IsDescendantOf(FishingFloatsRecycle2)) then
					return
				end

				GuiService.SelectedObject = nil
			end
		end)
		GuiService:GetPropertyChangedSignal("SelectedObject"):Connect(function() --[[ Line: 536 | Upvalues: UserInputService (ref), GuiService (ref), v10 (copy), FishingFloatsRecycle2 (copy) ]]
			if UserInputService.PreferredInput ~= Enum.PreferredInput.Gamepad then
				return
			end

			local SelectedObject = GuiService.SelectedObject

			if not v10.Visible:Get() or SelectedObject and SelectedObject:IsDescendantOf(FishingFloatsRecycle2) then
				return
			end

			GuiService:Select(FishingFloatsRecycle2)
		end)
		ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 546 ]]
			return p1.fishingFloats
		end, function() --[[ Line: 548 | Upvalues: v10 (copy), v17 (ref) ]]
			if not v10.Visible:Get() then
				return
			end

			v17()
		end)

		local t5 = {}

		local function teardown(p12) --[[ teardown | Line: 563 | Upvalues: t5 (copy), v13 (ref), p1 (copy), v10 (copy) ]]
			local v1 = t5[p12]

			if not v1 then
				return
			end

			t5[p12] = nil

			for v2, v3 in v1.connections do
				v3:Disconnect()
			end

			if v1.track then
				v1.track:Stop()
				v1.track:Destroy()
			end

			if not v13 or v1.model:GetAttribute("PlacementId") ~= v13 then
				return
			end

			local v4 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

			if not v4 or v4.OpenedUIComponent:Get() ~= v10 then
				return
			end

			v4.OpenedUIComponent:Set(nil)
		end

		local function setup(p12) --[[ setup | Line: 581 | Upvalues: t5 (copy), GardenConfig (ref), LocalPlayer (ref), getAnimator (ref), AnimationConfig (ref), loadTrack (ref), v13 (ref), p1 (copy), v10 (copy) ]]
			if not p12:IsA("Model") or t5[p12] then
				return
			end

			local v1 = p12:FindFirstChild(GardenConfig.FloatRecycleRootName, true) or p12:WaitForChild(GardenConfig.FloatRecycleRootName, 10)

			if not p12.Parent then
				return
			end

			local v2 = if v1 then v1:WaitForChild(GardenConfig.FloatRecyclePromptName, 10) else v1

			if not v2 then
				warn((("[FloatRecycleMachine] \"%*\" has no %* \226\128\148 cannot be opened"):format(p12.Name, GardenConfig.FloatRecyclePromptName)))
			end

			local v3 = if p12:GetAttribute("OwnerUserId") == LocalPlayer.UserId then true else false
			local v4 = nil
			local v5 = getAnimator(p12)
			local FloatRecycleMachine = AnimationConfig.FloatRecycleMachine
			local v6 = if FloatRecycleMachine then FloatRecycleMachine.Recycle else FloatRecycleMachine
			local v7 = if typeof(v6) == "string" and v6 ~= "" then v6 else nil

			if v5 and v7 then
				v4 = loadTrack(v5, v7)
			end

			local t = {
				model = p12,
				prompt = v2,
				track = v4,
				connections = {}
			}

			t5[p12] = t

			if v2 then
				v2.Enabled = v3

				local function f9(p13) --[[ Line: 619 | Upvalues: LocalPlayer (ref), p12 (copy), v13 (ref), p1 (ref), v10 (ref) ]]
					if p13 ~= LocalPlayer then
						return
					end

					local v1 = p12:GetAttribute("PlacementId")

					if typeof(v1) ~= "string" then
						return
					end

					v13 = v1

					local v2 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

					if not v2 then
						return
					end

					v2.OpenedUIComponent:Set(v10)
				end

				table.insert(t.connections, v2.Triggered:Connect(f9))
			end

			local v102 = p12:GetAttributeChangedSignal(GardenConfig.FloatRecycleAnimAttribute)

			local function f11() --[[ Line: 638 | Upvalues: p12 (copy), GardenConfig (ref), t (copy) ]]
				local v1 = p12:GetAttribute(GardenConfig.FloatRecycleAnimAttribute)

				if typeof(v1) ~= "number" then
					return
				end

				if math.abs(workspace:GetServerTimeNow() - v1) > 3 then
					return
				end

				if not t.track then
					return
				end

				t.track:Stop()
				t.track:Play()
			end

			table.insert(t.connections, v102:Connect(f11))
		end

		CollectionService:GetInstanceAddedSignal(FloatRecycleTag):Connect(setup)
		CollectionService:GetInstanceRemovedSignal(FloatRecycleTag):Connect(teardown)

		for v26, v27 in CollectionService:GetTagged(FloatRecycleTag) do
			task.spawn(setup, v27)
		end
	end
}