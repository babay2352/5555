-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Remotes = require(ReplicatedStorage.shared.Remotes)
local SignalBag = require(ReplicatedStorage.client.SignalBag)
local TradeConfig = require(ReplicatedStorage.shared.config.TradeConfig)
local TutorialConfig = require(ReplicatedStorage.shared.config.TutorialConfig)
local logger = require(ReplicatedStorage.shared.util.logger)
local t = {
	UECS = nil
}
local v1 = #TutorialConfig + 1

local function localPlayerInTutorial() --[[ localPlayerInTutorial | Line: 23 | Upvalues: ClientPlayerData (copy), v1 (copy) ]]
	if not ClientPlayerData.isPlayerDataLoaded then
		return true
	end

	local tutorialInfo = ClientPlayerData.serverProfile:getState().tutorialInfo

	return if tutorialInfo == nil then false else tutorialInfo.tutorialStep < v1
end

local function canSeeTradingPrompts() --[[ canSeeTradingPrompts | Line: 31 | Upvalues: Players (copy), ClientPlayerData (copy), v1 (copy) ]]
	local LocalPlayer = Players.LocalPlayer

	if LocalPlayer then
		LocalPlayer = Players.LocalPlayer.Character

		if LocalPlayer then
			LocalPlayer = not Players.LocalPlayer.Character:FindFirstChildOfClass("Tool")

			if LocalPlayer then
				local v12

				if ClientPlayerData.isPlayerDataLoaded then
					local tutorialInfo = ClientPlayerData.serverProfile:getState().tutorialInfo

					v12 = if tutorialInfo == nil then false else tutorialInfo.tutorialStep < v1
				else
					v12 = true
				end

				LocalPlayer = not v12
			end
		end
	end

	return LocalPlayer
end

local function toggleTradingPrompts() --[[ toggleTradingPrompts | Line: 38 | Upvalues: Players (copy), ClientPlayerData (copy), v1 (copy), CollectionService (copy) ]]
	local LocalPlayer = Players.LocalPlayer

	if LocalPlayer then
		LocalPlayer = Players.LocalPlayer.Character

		if LocalPlayer then
			LocalPlayer = not Players.LocalPlayer.Character:FindFirstChildOfClass("Tool")

			if LocalPlayer then
				local v12

				if ClientPlayerData.isPlayerDataLoaded then
					local tutorialInfo = ClientPlayerData.serverProfile:getState().tutorialInfo

					v12 = if tutorialInfo == nil then false else tutorialInfo.tutorialStep < v1
				else
					v12 = true
				end

				LocalPlayer = not v12
			end
		end
	end

	for v2, v3 in CollectionService:GetTagged("TradePrompt") do
		if v3:IsA("ProximityPrompt") then
			v3.Enabled = LocalPlayer
		end
	end
end

local function setupLocalCharacter() --[[ setupLocalCharacter | Line: 47 | Upvalues: Players (copy), toggleTradingPrompts (copy) ]]
	local Character = Players.LocalPlayer.Character

	if Character then
		Character.ChildAdded:Connect(toggleTradingPrompts)
		Character.ChildRemoved:Connect(toggleTradingPrompts)
	end
end

local function onTradeableCharacterAdded(p1) --[[ onTradeableCharacterAdded | Line: 57 | Upvalues: Players (copy), ClientPlayerData (copy), v1 (copy), Remotes (copy), SignalBag (copy), logger (copy) ]]
	if p1:QueryDescendants("ProximityPrompt.TradePrompt")[1] then
		return
	end

	if not (p1:IsA("Model") and p1.PrimaryPart) then
		return
	end

	local v12 = Players:GetPlayerFromCharacter(p1)

	if not v12 or v12 == Players.LocalPlayer then
		return
	end

	local ProximityPrompt = Instance.new("ProximityPrompt")

	ProximityPrompt.ObjectText = v12.DisplayName
	ProximityPrompt.ActionText = "Trade"
	ProximityPrompt.KeyboardKeyCode = Enum.KeyCode.E
	ProximityPrompt.RequiresLineOfSight = false
	ProximityPrompt.MaxActivationDistance = 8
	ProximityPrompt.Style = Enum.ProximityPromptStyle.Custom
	ProximityPrompt.HoldDuration = 0
	ProximityPrompt:AddTag("TradePrompt")
	ProximityPrompt.Parent = p1.PrimaryPart

	local LocalPlayer = Players.LocalPlayer

	if LocalPlayer then
		LocalPlayer = Players.LocalPlayer.Character

		if LocalPlayer then
			LocalPlayer = not Players.LocalPlayer.Character:FindFirstChildOfClass("Tool")

			if LocalPlayer then
				local v2

				if ClientPlayerData.isPlayerDataLoaded then
					local tutorialInfo = ClientPlayerData.serverProfile:getState().tutorialInfo

					v2 = if tutorialInfo == nil then false else tutorialInfo.tutorialStep < v1
				else
					v2 = true
				end

				LocalPlayer = not v2
			end
		end
	end

	ProximityPrompt.Enabled = LocalPlayer
	ProximityPrompt.Triggered:Connect(function() --[[ Line: 83 | Upvalues: Remotes (ref), v12 (copy), SignalBag (ref), logger (ref) ]]
		local v1, v2 = Remotes.SendTradeRequest:Call(v12):Await()

		if v1 then
			SignalBag.Notification:Fire(v2)
		else
			SignalBag.Notification:Fire("Failed to send trade request")
			logger.warn(v2)
		end
	end)
end

local function onTradeableCharacterRemoved(p1) --[[ onTradeableCharacterRemoved | Line: 94 ]]
	local v1 = p1:QueryDescendants("ProximityPrompt.TradePrompt")[1]

	if not v1 then
		return
	end

	v1:Destroy()
end

function t.Init(p1) --[[ Init | Line: 101 | Upvalues: CollectionService (copy), TradeConfig (copy), onTradeableCharacterAdded (copy), onTradeableCharacterRemoved (copy), Players (copy), setupLocalCharacter (copy), toggleTradingPrompts (copy), ClientPlayerData (copy) ]]
	CollectionService:GetInstanceAddedSignal(TradeConfig.TRADEABLE_TAG):Connect(onTradeableCharacterAdded)
	CollectionService:GetInstanceRemovedSignal(TradeConfig.TRADEABLE_TAG):Connect(onTradeableCharacterRemoved)

	for v1, v2 in CollectionService:GetTagged(TradeConfig.TRADEABLE_TAG) do
		onTradeableCharacterAdded(v2)
	end

	Players.LocalPlayer.CharacterAdded:Connect(setupLocalCharacter)

	if not Players.LocalPlayer.Character then
		task.spawn(function() --[[ Line: 117 | Upvalues: ClientPlayerData (ref), toggleTradingPrompts (ref) ]]
			if not ClientPlayerData.isPlayerDataLoaded then
				ClientPlayerData.playerDataLoadedSignal:Wait()
			end

			toggleTradingPrompts()
			ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 122 ]]
				return p1.tutorialInfo
			end, toggleTradingPrompts)
		end)

		return
	end

	local Character = Players.LocalPlayer.Character

	if not Character then
		task.spawn(function() --[[ Line: 117 | Upvalues: ClientPlayerData (ref), toggleTradingPrompts (ref) ]]
			if not ClientPlayerData.isPlayerDataLoaded then
				ClientPlayerData.playerDataLoadedSignal:Wait()
			end

			toggleTradingPrompts()
			ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 122 ]]
				return p1.tutorialInfo
			end, toggleTradingPrompts)
		end)

		return
	end

	Character.ChildAdded:Connect(toggleTradingPrompts)
	Character.ChildRemoved:Connect(toggleTradingPrompts)
	task.spawn(function() --[[ Line: 117 | Upvalues: ClientPlayerData (ref), toggleTradingPrompts (ref) ]]
		if not ClientPlayerData.isPlayerDataLoaded then
			ClientPlayerData.playerDataLoadedSignal:Wait()
		end

		toggleTradingPrompts()
		ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 122 ]]
			return p1.tutorialInfo
		end, toggleTradingPrompts)
	end)
end

return t