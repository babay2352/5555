-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ConvertValue = require(ReplicatedStorage.shared.util.ConvertValue)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local GymEventConfig = require(ReplicatedStorage.shared.config.GymEventConfig)
local GymEventState = require(ReplicatedStorage.client.GymEventState)
local RBXThumbModule = require(ReplicatedStorage.shared.module.RBXThumbModule)
local t = {
	UECS = nil
}
local ContributionBoard = GymEventConfig.Tags.ContributionBoard
local t2 = {}

local function buildRows(p1, p2) --[[ buildRows | Line: 69 | Upvalues: GymEventConfig (copy), GymEventState (copy), ConvertValue (copy), RBXThumbModule (copy) ]]
	local v1 = p1:FindFirstChild(GymEventConfig.Ui.ContributionRowTemplateName, true)
	local v2 = if v1 then v1.Parent else v1

	if not (v1 and (v1:IsA("GuiObject") and v2)) then
		return
	end

	p2.generation = p2.generation + 1

	local generation = p2.generation

	for v3, v4 in v2:GetChildren() do
		if v4.Name == "GymContributionRow" then
			v4:Destroy()
		end
	end

	v1.Visible = false

	local v5 = GymEventState.Get()

	if not v5 then
		return
	end

	for v6, v7 in v5.contributions do
		local GymContributionRow = v1:Clone()

		GymContributionRow.Name = "GymContributionRow"
		GymContributionRow.Visible = true
		GymContributionRow.LayoutOrder = v6

		local BoardPosition = GymContributionRow:FindFirstChild("BoardPosition")

		if BoardPosition and BoardPosition:IsA("TextLabel") then
			BoardPosition.Text = ("#%*"):format(v6)
		end

		local Nickname = GymContributionRow:FindFirstChild("Nickname")

		if Nickname and Nickname:IsA("TextLabel") then
			Nickname.Text = v7.name
		end

		local Value = GymContributionRow:FindFirstChild("Value")

		if Value and Value:IsA("TextLabel") then
			Value.Text = ConvertValue.suffixformat(v7.points)
		end

		local LeaderboardIcon = GymContributionRow:FindFirstChild("LeaderboardIcon")

		if LeaderboardIcon and LeaderboardIcon:IsA("ImageLabel") then
			LeaderboardIcon.Image = GymEventConfig.Currency.Icon
		end

		local PlayerIcon = GymContributionRow:FindFirstChild("PlayerIcon")

		if PlayerIcon and PlayerIcon:IsA("ImageLabel") then
			local userId = v7.userId

			task.spawn(function() --[[ Line: 132 | Upvalues: RBXThumbModule (ref), userId (copy), p2 (copy), generation (copy), PlayerIcon (copy) ]]
				local v1 = RBXThumbModule:GetAvatarHeadshotUri(userId)

				if v1 == "" then
					return
				end

				if p2.generation == generation and PlayerIcon.Parent ~= nil then
					PlayerIcon.Image = v1
				end
			end)
		end

		GymContributionRow.Parent = v2
	end
end

local function startFor(p1) --[[ startFor | Line: 148 | Upvalues: t2 (copy), buildRows (copy) ]]
	if p1:IsA("SurfaceGui") and not t2[p1] then
		local t = {
			generation = 0,
			connections = {}
		}

		t2[p1] = t

		local function f1() --[[ Line: 165 | Upvalues: buildRows (ref), p1 (copy), t (copy) ]]
			buildRows(p1, t)
		end

		table.insert(t.connections, p1.ChildAdded:Connect(f1))
		buildRows(p1, t)
	end
end

local function stopFor(p1) --[[ stopFor | Line: 173 | Upvalues: t2 (copy) ]]
	local v1 = t2[p1]

	if not v1 then
		return
	end

	for v2, v3 in v1.connections do
		v3:Disconnect()
	end

	v1.generation = v1.generation + 1
	t2[p1] = nil
end

function t.Init(p1) --[[ Init | Line: 187 | Upvalues: GymEventConfig (copy), GymEventState (copy), t2 (copy), buildRows (copy), CollectionService (copy), ContributionBoard (copy), startFor (copy), stopFor (copy) ]]
	if not GymEventConfig.Enabled then
		return
	end

	GymEventState.Start()
	GymEventState.Changed:Connect(function() --[[ Line: 195 | Upvalues: t2 (ref), buildRows (ref) ]]
		for v1, v2 in t2 do
			buildRows(v1, v2)
		end
	end)

	for v1, v2 in CollectionService:GetTagged(ContributionBoard) do
		startFor(v2)
	end

	CollectionService:GetInstanceAddedSignal(ContributionBoard):Connect(startFor)
	CollectionService:GetInstanceRemovedSignal(ContributionBoard):Connect(stopFor)
end

return t