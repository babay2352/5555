-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Debris = game:GetService("Debris")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local Flight = require(ReplicatedStorage.client.remoteFishing.Flight)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Maid = require(ReplicatedStorage.shared.class.Maid)
local Outcome = require(ReplicatedStorage.client.remoteFishing.Outcome)
local Reel = require(ReplicatedStorage.client.remoteFishing.Reel)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local RemoteFishingState = require(ReplicatedStorage.client.RemoteFishingState)
local RodRig = require(ReplicatedStorage.client.remoteFishing.RodRig)
local ThrowZoneState = require(ReplicatedStorage.client.ThrowZoneState)
local buildFishModel = require(ReplicatedStorage.shared.util.buildFishModel)
local t = {
	UECS = nil
}

local function playSoundAt(p1, p2, p3, p4) --[[ playSoundAt | Line: 69 | Upvalues: Debris (copy) ]]
	local v1 = p1:FindFirstChild("HumanoidRootPart") or p1.PrimaryPart

	if not v1 then
		return
	end

	local Sound = Instance.new("Sound")

	Sound.SoundId = p2
	Sound.Volume = p3

	if p4 then
		Sound.PlaybackSpeed = p4
	end

	Sound.RollOffMode = Enum.RollOffMode.InverseTapered
	Sound.RollOffMaxDistance = 150
	Sound.Parent = v1
	Sound:Play()
	Debris:AddItem(Sound, 8)
end

local function extentAlong(p1, p2, p3) --[[ extentAlong | Line: 90 ]]
	local v2 = math.abs((p3:Dot(p1.RightVector))) * p2.X
	local v4 = v2 + math.abs((p3:Dot(p1.UpVector))) * p2.Y

	return v4 + math.abs((p3:Dot(p1.LookVector))) * p2.Z
end

function t.Init(p1) --[[ Init | Line: 124 | Upvalues: Players (copy), RodRig (copy), ThrowZoneState (copy), Remotes (copy), RemoteFishingState (copy), ClientPlayerData (copy), Maid (copy), Flight (copy), playSoundAt (copy), Reel (copy), Outcome (copy), buildFishModel (copy), extentAlong (copy), RunService (copy) ]]
	local LocalPlayer = Players.LocalPlayer
	local t = {}

	RodRig.start()
	ThrowZoneState.OnChanged:Connect(function(p1) --[[ Line: 134 | Upvalues: Remotes (ref) ]]
		Remotes.SetThrowZoneState:Fire(p1)
	end)

	if ThrowZoneState.InZone then
		Remotes.SetThrowZoneState:Fire(true)
	end

	local function characterOf(p1) --[[ characterOf | Line: 141 | Upvalues: Players (ref) ]]
		local v1 = Players:GetPlayerByUserId(p1)

		return if v1 then v1.Character or nil else nil
	end

	local function endCast(p1) --[[ endCast | Line: 146 | Upvalues: t (copy) ]]
		local v1 = t[p1]

		if not v1 then
			return
		end

		t[p1] = nil

		for v2, v3 in v1.FishModels do
			v3:Destroy()
		end

		table.clear(v1.FishModels)
		v1.Maid:DoCleaning()
	end

	local function endAll() --[[ endAll | Line: 162 | Upvalues: t (copy), endCast (copy) ]]
		for v1 in t do
			endCast(v1)
		end
	end

	local function scheduleTimeout(p1, p2) --[[ scheduleTimeout | Line: 171 | Upvalues: endCast (copy) ]]
		p1.TimeoutAt = os.clock() + p2
		p1.Maid:GiveTask(task.delay(p2, function() --[[ Line: 173 | Upvalues: p1 (copy), endCast (ref) ]]
			if not (os.clock() >= p1.TimeoutAt - 0.5) then
				return
			end

			endCast(p1.UserId)
		end))
	end

	local function applyVisibility(p1) --[[ applyVisibility | Line: 183 | Upvalues: RemoteFishingState (ref), t (copy), endCast (copy) ]]
		if p1 or not RemoteFishingState.SettingDisabled then
			for v1, v2 in t do
				if v2.Flight then
					v2.Flight:SetVisible(p1)
				end

				if v2.Reel then
					v2.Reel:SetVisible(p1)
				end

				if v2.BossGui then
					v2.BossGui.Enabled = p1
				end

				if v2.Showup then
					v2.Showup:SetVisible(p1)
				end

				for v3, v4 in v2.FishModels do
					v4.Parent = if p1 then workspace else nil
				end
			end
		else
			for v6 in t do
				endCast(v6)
			end
		end
	end

	RemoteFishingState.OnChanged:Connect(applyVisibility)

	local function syncSetting(p1) --[[ syncSetting | Line: 210 | Upvalues: RemoteFishingState (ref), RodRig (ref) ]]
		local v1 = if p1 == nil then false else p1.otherPlayersFishingEnabled == false

		RemoteFishingState.SetSettingDisabled(v1)
		RodRig.setEnabled(not v1)
	end

	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 217 ]]
		return p1.settings
	end, syncSetting)

	local v1 = ClientPlayerData.serverProfile:getState().settings
	local v2 = if v1 == nil then false else v1.otherPlayersFishingEnabled == false

	RemoteFishingState.SetSettingDisabled(v2)
	RodRig.setEnabled(not v2)

	local function spawnFacing(p1) --[[ spawnFacing | Line: 225 ]]
		local LandingPos = p1.Flight.LandingPos
		local HumanoidRootPart = p1.Character:FindFirstChild("HumanoidRootPart")

		if not HumanoidRootPart then
			return CFrame.new(LandingPos)
		end

		local v1 = Vector3.new(HumanoidRootPart.Position.X, LandingPos.Y, HumanoidRootPart.Position.Z)

		if (v1 - LandingPos).Magnitude < 0.1 then
			return CFrame.new(LandingPos)
		end

		return CFrame.lookAt(LandingPos, v1)
	end

	local function reelCount() --[[ reelCount | Line: 238 | Upvalues: t (copy) ]]
		local count = 0

		for v1, v2 in t do
			if v2.Reel then
				count = count + 1
			end
		end

		return count
	end

	Remotes.FishingRemoteCast:On(function(p1) --[[ Line: 248 | Upvalues: LocalPlayer (copy), endCast (copy), RemoteFishingState (ref), Players (ref), Maid (ref), Flight (ref), RodRig (ref), playSoundAt (ref), t (copy), scheduleTimeout (copy) ]]
		local UserId = p1.UserId

		if not UserId or UserId == LocalPlayer.UserId then
			return
		end

		endCast(UserId)

		if not RemoteFishingState.Visible() then
			return
		end

		local v1 = Players:GetPlayerByUserId(UserId)
		local v2 = if v1 then v1.Character or nil else nil

		if not v2 then
			return
		end

		local v3 = Maid.new()
		local v4 = Players:GetPlayerByUserId(UserId)
		local v5, v6, v7

		if v4 then
			v5 = RodRig.rigFor(v4)

			if v5 then
				v6 = v2
				v7 = p1
			else
				v6 = v2
				v7 = p1
				v5 = nil
			end
		else
			v6 = v2
			v7 = p1
			v5 = nil
		end

		local v8 = Flight.start(v6, v7, v5)

		if not v8 then
			return
		end

		playSoundAt(v2, if p1.RodConfig == "FISHROD_Cat" then "rbxassetid://134699420140804" else "rbxassetid://119135010875996", 1)
		v3:GiveTask(function() --[[ Line: 277 | Upvalues: v8 (copy) ]]
			v8:Destroy()
		end)

		local t2 = {
			Reel = nil,
			FishHalfLength = 0,
			HookHalfLength = 0,
			PullProgress = 0,
			RenderedProgress = 0,
			BossGui = nil,
			Showup = nil,
			RollPlan = nil,
			TimeoutAt = 0,
			UserId = UserId,
			Character = v2,
			Payload = p1,
			Maid = v3,
			Flight = v8,
			FishModels = {},
			StartedAt = os.clock()
		}

		t[UserId] = t2

		if not v4 then
			scheduleTimeout(t2, 90)

			return
		end

		v3:GiveTask(v4.CharacterRemoving:Connect(function() --[[ Line: 304 | Upvalues: endCast (ref), UserId (copy) ]]
			endCast(UserId)
		end))
		scheduleTimeout(t2, 90)
	end)
	Remotes.FishingRemoteStage:On(function(p1) --[[ Line: 311 | Upvalues: t (copy), playSoundAt (ref), Reel (ref), RemoteFishingState (ref), Outcome (ref), scheduleTimeout (copy), buildFishModel (ref), spawnFacing (copy), extentAlong (ref), endCast (copy) ]]
		local v1 = t[p1.UserId]

		if not v1 then
			return
		end

		local Kind = p1.Kind

		if Kind == "landed" then
			v1.Flight:Land()
			playSoundAt(v1.Character, "rbxassetid://83673781452193", 1)

			return
		end

		if Kind == "rollPlan" then
			v1.RollPlan = p1.Tracks

			return
		end

		if Kind == "rollRow" then
			if not v1.Reel then
				local count = 0

				for v2, v3 in t do
					if v3.Reel then
						count = count + 1
					end
				end

				if count < 3 then
					v1.Reel = Reel.create(v1.Character, v1.Payload, v1.RollPlan)

					if v1.Reel then
						local Reel2 = v1.Reel

						v1.Maid:GiveTask(function() --[[ Line: 331 | Upvalues: Reel2 (copy) ]]
							Reel2:Destroy()
						end)
						Reel2:SetVisible(RemoteFishingState.Visible())
					end
				end
			end

			if v1.Reel then
				v1.Reel:StartRow(p1.Row)
			end

			playSoundAt(v1.Character, "rbxassetid://127989598863324", 0.5, 1 + ((p1.Row or 1) - 1) * 0.15)
		elseif Kind == "rollSettle" then
			if v1.Reel then
				v1.Reel:Settle(p1.Row, p1.Track)
			end

			playSoundAt(v1.Character, "rbxassetid://127089163163176", 0.5, 1 + ((p1.Row or 1) - 1) * 0.15)
		elseif Kind == "rollEnd" then
			if v1.Reel then
				v1.Reel:Finish()
				v1.Reel = nil
			end
		elseif Kind == "showup" then
			if v1.Showup then
				v1.Showup:Destroy()
			end

			local v5 = Outcome.playShowup(v1.Character, v1.Payload, v1.Flight and v1.Flight.Hook)

			if v5 then
				v5:SetVisible(RemoteFishingState.Visible())
				v1.Showup = v5
				v1.Maid:GiveTask(function() --[[ Line: 379 | Upvalues: v5 (copy) ]]
					v5:Destroy()
				end)
			end
		else
			if Kind == "bossFight" then
				v1.Flight:Destroy()

				local v6 = Outcome.playBossFight(v1.Character, v1.Payload.Fish)

				if v6 then
					v6.Enabled = RemoteFishingState.Visible()
					v1.BossGui = v6
					v1.Maid:GiveTask(function() --[[ Line: 394 | Upvalues: v6 (copy) ]]
						v6:Destroy()
					end)
				end

				scheduleTimeout(v1, 180)

				return
			end

			if Kind == "chase" then
				if v1.Showup then
					v1.Showup:Finish()
					v1.Showup = nil
				end

				v1.Flight:BeginChase()

				local t2 = {}

				if v1.Payload.Fish then
					table.insert(t2, v1.Payload.Fish)
				end

				if v1.Payload.BonusFish then
					for v7, v8 in v1.Payload.BonusFish do
						if v8.Fish then
							table.insert(t2, v8.Fish)
						end
					end
				end

				for v9, v10 in t2 do
					local ok, result = pcall(function() --[[ Line: 421 | Upvalues: buildFishModel (ref), v10 (copy), v9 (copy), v1 (copy) ]]
						return buildFishModel.clone(v10, 1, if v9 == 1 then v1.Payload.Mutation else nil)
					end)

					if ok and result then
						result.Parent = workspace

						for v11, v12 in result:GetDescendants() do
							if v12:IsA("BasePart") then
								v12.Anchored = true
								v12.CanCollide = false
								v12.CanQuery = false
							end
						end

						result:PivotTo(spawnFacing(v1) * CFrame.new((v9 - 1) * 6, 0, 0))
						table.insert(v1.FishModels, result)
					end
				end

				local v13 = v1.FishModels[1]
				local Hook = v1.Flight.Hook

				if not (v13 and Hook) then
					return
				end

				local v14 = spawnFacing(v1)
				local LookVector = v14.LookVector
				local v15, v16 = v13:GetBoundingBox()

				v1.FishHalfLength = extentAlong(v15, v16, LookVector) / 2

				local HookModel = v1.Flight.HookModel
				local v17, v18

				if HookModel then
					local v19, v20 = HookModel:GetBoundingBox()

					v17 = v19
					v18 = v20
				else
					v17 = Hook.CFrame
					v18 = Hook.Size
				end

				v1.HookHalfLength = extentAlong(v17, v18, LookVector) / 2
				v1.Flight:MoveHook(CFrame.new(v14.Position + LookVector * (v1.FishHalfLength + v1.HookHalfLength)) * (Hook.CFrame - Hook.CFrame.Position))

				return
			end

			if Kind == "pull" then
				v1.PullProgress = math.clamp(p1.P or 0, 0, 1)

				return
			end

			if Kind ~= "done" then
				return
			end

			if v1.BossGui then
				v1.BossGui:Destroy()
				v1.BossGui = nil
			end

			if v1.Showup then
				v1.Showup:Finish()
				v1.Showup = nil
			end

			if p1.Ok then
				playSoundAt(v1.Character, "rbxassetid://114813573682393", 1)
				task.delay(0.5, function() --[[ Line: 485 | Upvalues: v1 (copy), playSoundAt (ref) ]]
					if not v1.Character.Parent then
						return
					end

					playSoundAt(v1.Character, "rbxassetid://112533303080427", 1)
				end)
			else
				playSoundAt(v1.Character, "rbxassetid://138366598268192", 0.7)
				playSoundAt(v1.Character, "rbxassetid://8275897472", 0.7)
			end

			if p1.Ok then
				local t2 = {}

				if v1.Payload.Fish then
					table.insert(t2, v1.Payload.Fish)
				end

				if v1.Payload.BonusFish then
					for v23, v24 in v1.Payload.BonusFish do
						if v24.Fish then
							table.insert(t2, v24.Fish)
						end
					end
				end

				Outcome.playSuccess(v1.Character, t2, v1.Payload.BiomeId)

				local FishModels = v1.FishModels

				v1.FishModels = {}

				local Flight = v1.Flight
				local v25 = Flight and Flight.Hook

				Outcome.playCollectFlight(v1.Character, FishModels, if v25 and v25.Parent then function(p1) --[[ Line: 519 | Upvalues: v25 (copy), Flight (copy) ]]
	if not v25.Parent then
		return
	end

	Flight:MoveHook(CFrame.new(p1.Position) * (v25.CFrame - v25.CFrame.Position))
end else nil, function() --[[ Line: 528 | Upvalues: t (ref), p1 (copy), v1 (copy), endCast (ref) ]]
					if t[p1.UserId] ~= v1 then
						return
					end

					endCast(p1.UserId)
				end)

				return
			end

			Outcome.playFail(v1.Character)
			endCast(p1.UserId)
		end
	end)
	RunService.RenderStepped:Connect(function(p1) --[[ Line: 547 | Upvalues: t (copy) ]]
		debug.profilebegin("UECS/RemoteFishing.Pull")

		for v1, v2 in t do
			if #v2.FishModels ~= 0 then
				local HumanoidRootPart = v2.Character:FindFirstChild("HumanoidRootPart")

				if HumanoidRootPart then
					v2.RenderedProgress = v2.RenderedProgress + (v2.PullProgress - v2.RenderedProgress) * math.min(p1 * 8, 1)

					local LandingPos = v2.Flight.LandingPos
					local v3 = Vector3.new(HumanoidRootPart.Position.X, LandingPos.Y, HumanoidRootPart.Position.Z) - LandingPos
					local Magnitude = v3.Magnitude

					if not (Magnitude <= 6) then
						local Unit = v3.Unit
						local v4 = LandingPos + Unit * ((Magnitude - 6) * v2.RenderedProgress)
						local v5 = CFrame.lookAt(v4, v4 + Unit)

						for v6, v7 in v2.FishModels do
							v7:PivotTo(v5 * CFrame.new((v6 - 1) * 6, 0, 0))
						end

						local Hook = v2.Flight.Hook

						if Hook and Hook.Parent then
							v2.Flight:MoveHook(CFrame.new(v4 + Unit * (v2.FishHalfLength + v2.HookHalfLength)) * (Hook.CFrame - Hook.CFrame.Position))
						end
					end
				end
			end
		end

		debug.profileend()
	end)
	Players.PlayerRemoving:Connect(function(p1) --[[ Line: 595 | Upvalues: endCast (copy) ]]
		endCast(p1.UserId)
	end)
end

return t