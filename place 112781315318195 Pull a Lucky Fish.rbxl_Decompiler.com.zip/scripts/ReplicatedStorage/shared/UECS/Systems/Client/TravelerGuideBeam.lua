-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local TutorialPointer = require(ReplicatedStorage.client.TutorialPointer)
local WorldsConfig = require(ReplicatedStorage.shared.config.WorldsConfig)
local t = {
	UECS = nil
}
local TravelerGuide = WorldsConfig.TravelerGuide
local v1 = TravelerGuide.ArrivalDistance * TravelerGuide.ArrivalDistance

function t.Init(p1) --[[ Init | Line: 54 | Upvalues: Players (copy), TutorialPointer (copy), CollectionService (copy), TravelerGuide (copy), ClientPlayerData (copy), WorldsConfig (copy), v1 (copy), RunService (copy) ]]
	local LocalPlayer = Players.LocalPlayer
	local v12 = false

	local function clearArrow() --[[ clearArrow | Line: 60 | Upvalues: v12 (ref), TutorialPointer (ref) ]]
		if not v12 then
			return
		end

		TutorialPointer.guide(nil)
		v12 = false
	end

	local function findTraveler() --[[ findTraveler | Line: 69 | Upvalues: CollectionService (ref), TravelerGuide (ref) ]]
		for v1, v2 in CollectionService:GetTagged(TravelerGuide.NpcTag) do
			if v2:IsA("Model") and v2.Name == TravelerGuide.NpcName then
				return v2
			end
		end

		return nil
	end

	local function resolveNpcRoot(p1) --[[ resolveNpcRoot | Line: 80 ]]
		local Head = p1:FindFirstChild("Head")

		if Head and Head:IsA("BasePart") then
			return Head
		end

		return p1.PrimaryPart or p1:FindFirstChildWhichIsA("BasePart", true)
	end

	local function shouldShow() --[[ shouldShow | Line: 88 | Upvalues: ClientPlayerData (ref), WorldsConfig (ref), TravelerGuide (ref) ]]
		local v1 = ClientPlayerData.serverProfile:getState()

		if not v1 then
			return false
		end

		local v2 = WorldsConfig.Get(TravelerGuide.WorldId)
		local v3 = if v2 then v2.Unlock else v2

		if not (v2 and v3) then
			return false
		end

		if table.find(v1.unlockedWorlds or {}, v2.Id) then
			return false
		end

		return WorldsConfig.GetUnlockProgress(v1, v3).MeetsAll
	end

	local function update() --[[ update | Line: 109 | Upvalues: shouldShow (copy), v12 (ref), TutorialPointer (ref), LocalPlayer (copy), findTraveler (copy), v1 (ref), TravelerGuide (ref) ]]
		if shouldShow() then
			local Character = LocalPlayer.Character
			local v13 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character
			local v2 = findTraveler()
			local v3

			if v2 then
				local Head = v2:FindFirstChild("Head")

				if Head and Head:IsA("BasePart") then
					v3 = Head
				else
					v3 = v2.PrimaryPart

					if not v3 then
						v3 = v2:FindFirstChildWhichIsA("BasePart", true)
					end
				end
			else
				v3 = v2
			end

			if v13 and v3 then
				local v5 = v3.Position - v13.Position

				if not (v5:Dot(v5) <= v1) then
					TutorialPointer.guide(v3, false, (Vector3.new(0, TravelerGuide.PointerHeight, 0)))
					v12 = true

					return
				end
			end
		end

		if not v12 then
			return
		end

		TutorialPointer.guide(nil)
		v12 = false
	end

	LocalPlayer.CharacterRemoving:Connect(clearArrow)

	local v2 = 0

	RunService.Heartbeat:Connect(function(p1) --[[ Line: 140 | Upvalues: v2 (ref), update (copy) ]]
		debug.profilebegin("UECS/TravelerGuideBeam.Update")
		v2 = v2 + p1

		if not (v2 < 0.5) then
			v2 = 0
			update()
		end

		debug.profileend()
	end)
end

return t