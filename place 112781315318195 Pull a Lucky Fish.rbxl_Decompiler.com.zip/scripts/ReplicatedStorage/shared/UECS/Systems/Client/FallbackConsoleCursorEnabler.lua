-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local GamepadService = game:GetService("GamepadService")
local GuiService = game:GetService("GuiService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local bindToButtonPress = require(ReplicatedStorage.shared.util.bindToButtonPress)

return {
	UECS = nil,
	Priority = 100,
	Init = function(p1) --[[ Init | Line: 11 | Upvalues: GuiService (copy), GamepadService (copy), bindToButtonPress (copy) ]]
		GuiService.AutoSelectGuiEnabled = false

		local function toggleCursor() --[[ toggleCursor | Line: 18 | Upvalues: GamepadService (ref) ]]
			if GamepadService.GamepadCursorEnabled then
				GamepadService:DisableGamepadCursor()
			else
				GamepadService:EnableGamepadCursor(nil)
			end
		end

		bindToButtonPress("CursorToggle", Enum.KeyCode.ButtonL3, toggleCursor)
		bindToButtonPress("CursorToggleTouchpad", Enum.KeyCode.ButtonSelect, toggleCursor)
	end
}