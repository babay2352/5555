-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ContextActionService = game:GetService("ContextActionService")
local GuiService = game:GetService("GuiService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local Feedback = require(ReplicatedStorage.shared.UECS.Components.Feedback)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Remotes = require(ReplicatedStorage.shared.Remotes)
local bindToButtonPress = require(ReplicatedStorage.shared.util.bindToButtonPress)

return {
	UECS = nil,
	Priority = 30,
	Init = function(p1) --[[ Init | Line: 19 | Upvalues: Players (copy), Feedback (copy), bindToButtonPress (copy), GuiService (copy), Remotes (copy), ContextActionService (copy), ClientPlayerData (copy) ]]
		local Feedback2 = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI"):WaitForChild("Feedback")
		local TopBar = Feedback2:WaitForChild("TopBar")
		local v1 = Feedback2:WaitForChild("Content")
		local SendFeedback = v1:WaitForChild("SendFeedback")
		local TextBox = v1:WaitForChild("TextBox")
		local CloseButton = TopBar:WaitForChild("CloseButton")

		Feedback2.Visible = false

		local v2 = Feedback.Add(Feedback2)

		v2.Visible.OnChange:Connect(function(p1, p2) --[[ Line: 31 | Upvalues: Feedback2 (copy), bindToButtonPress (ref), GuiService (ref), TextBox (copy), v2 (copy), Remotes (ref), ContextActionService (ref) ]]
			if p1 == p2 then
				return
			end

			Feedback2.Visible = p1

			if p1 then
				bindToButtonPress("FeedbackFocusText", Enum.KeyCode.ButtonY, function() --[[ Line: 39 | Upvalues: GuiService (ref), TextBox (ref) ]]
					GuiService.SelectedObject = TextBox
					TextBox:CaptureFocus()
				end, 20000)
				bindToButtonPress("FeedbackExitButton", Enum.KeyCode.ButtonB, function() --[[ Line: 44 | Upvalues: v2 (ref) ]]
					v2.Visible:Set(false)
				end, 20000)
				bindToButtonPress("FeedbackSendButton", Enum.KeyCode.ButtonX, function() --[[ Line: 48 | Upvalues: TextBox (ref), Remotes (ref), v2 (ref) ]]
					local Text = TextBox.Text

					if typeof(Text) == "string" and #Text ~= 0 then
						Remotes.SendFeedback:Fire(Text)
						TextBox.Text = ""
						v2.Visible:Set(false)
					end
				end, 20000)
			else
				ContextActionService:UnbindAction("FeedbackFocusText")
				ContextActionService:UnbindAction("FeedbackExitButton")
				ContextActionService:UnbindAction("FeedbackSendButton")
			end
		end)
		GuiService.MenuOpened:Connect(function() --[[ Line: 67 | Upvalues: ClientPlayerData (ref), v2 (copy) ]]
			if not ClientPlayerData.serverProfile:getState().hasSendFeedback then
				v2.Visible:Set(true)
			end
		end)
		CloseButton.MouseButton1Down:Connect(function() --[[ Line: 75 | Upvalues: v2 (copy) ]]
			v2.Visible:Set(false)
		end)
		SendFeedback.MouseButton1Down:Connect(function() --[[ Line: 79 | Upvalues: TextBox (copy), Remotes (ref), v2 (copy) ]]
			local Text = TextBox.Text

			if typeof(Text) == "string" and #Text ~= 0 then
				Remotes.SendFeedback:Fire(Text)
				TextBox.Text = ""
				v2.Visible:Set(false)
			end
		end)
	end
}