-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ContentProvider = game:GetService("ContentProvider")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local Workspace = game:GetService("Workspace")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local DeepsConfig = require(ReplicatedStorage.shared.config.DeepsConfig)
local DeepsLootConfig = require(ReplicatedStorage.shared.config.DeepsLootConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Remotes = require(ReplicatedStorage.shared.Remotes)
local notifications = require(ReplicatedStorage.shared.module.notifications)
local playSellSound = require(ReplicatedStorage.shared.util.playSellSound)
local popInGui = require(ReplicatedStorage.shared.util.popInGui)
local t = {
	UECS = nil
}
local LocalPlayer = Players.LocalPlayer
local Machine = DeepsConfig.Machine

task.spawn(function() --[[ Line: 52 | Upvalues: DeepsLootConfig (copy), ContentProvider (copy) ]]
	local t = {}

	local function add(p1) --[[ add | Line: 54 | Upvalues: t (copy) ]]
		if type(p1) ~= "string" or p1 == "" then
			return
		end

		table.insert(t, p1)
	end

	for v1, v2 in DeepsLootConfig.Items do
		local Icon = v2.Icon

		if type(Icon) == "string" and Icon ~= "" then
			table.insert(t, Icon)
		end
	end

	local Icon = DeepsLootConfig.EnchantStone.Icon

	if type(Icon) == "string" and Icon ~= "" then
		table.insert(t, Icon)
	end

	if not (#t > 0) then
		return
	end

	pcall(function() --[[ Line: 64 | Upvalues: ContentProvider (ref), t (copy) ]]
		ContentProvider:PreloadAsync(t)
	end)
end)

local v1 = nil
local v2 = false
local v3 = nil
local v4 = nil
local t2 = {}
local v5 = false

local function getState() --[[ getState | Line: 102 | Upvalues: ClientPlayerData (copy) ]]
	return ClientPlayerData.serverProfile:getState()
end

local function ownedLoot() --[[ ownedLoot | Line: 107 | Upvalues: ClientPlayerData (copy), DeepsLootConfig (copy) ]]
	local t = {}

	for v1, v2 in ClientPlayerData.serverProfile:getState().inventory do
		if v2.Category == "DeepsLoot" and (v2.Stack or 0) > 0 then
			table.insert(t, v1)
		end
	end

	table.sort(t, function(p1, p2) --[[ Line: 114 | Upvalues: DeepsLootConfig (ref) ]]
		local v1 = DeepsLootConfig.Items[p1] and DeepsLootConfig.Items[p1].StonesYield or 0
		local v2 = DeepsLootConfig.Items[p2] and DeepsLootConfig.Items[p2].StonesYield or 0

		if v1 == v2 then
			return p1 < p2
		end

		return v1 < v2
	end)

	return t
end

local function stackStones(p1) --[[ stackStones | Line: 125 | Upvalues: DeepsLootConfig (copy), ClientPlayerData (copy) ]]
	local v1 = DeepsLootConfig.Items[p1]
	local v2 = ClientPlayerData.serverProfile:getState().inventory[p1]
	local v3 = if v2 then v2.Stack or 0 else 0

	if v1 then
		return v1.StonesYield * v3
	end

	return 0
end

local function buttonLabel(p1) --[[ buttonLabel | Line: 132 ]]
	local v1 = p1:FindFirstChild("Content")
	local v2 = if v1 then v1:FindFirstChild("Frame") else v1
	local v3 = if v2 then v2:FindFirstChild("TextLabel") else v2

	if v3 and v3:IsA("TextLabel") then
		return v3
	end

	return nil
end

local function hideButtonIcon(p1) --[[ hideButtonIcon | Line: 143 ]]
	local v1 = if p1 then p1:FindFirstChild("Content") else p1
	local v2 = if v1 then v1:FindFirstChild("Frame") else v1
	local v3 = if v2 then v2:FindFirstChild("ImageLabel") else v2

	if not (v3 and v3:IsA("ImageLabel")) then
		return
	end

	v3.Visible = false
end

local function resolveUi() --[[ resolveUi | Line: 156 | Upvalues: v1 (ref), LocalPlayer (copy), Machine (copy), t (copy) ]]
	if v1 then
		return v1
	end

	local PlayerGui = LocalPlayer:FindFirstChildOfClass("PlayerGui")
	local v12 = if PlayerGui then PlayerGui:FindFirstChild("MainUI") else PlayerGui
	local v2 = if v12 then v12:FindFirstChild(Machine.FrameName) else v12

	if not (v2 and v2:IsA("Frame")) then
		return nil
	end

	local v3 = v2:FindFirstChild("Content")
	local v4 = if v3 then v3:FindFirstChild("ScrollingFrame") else v3
	local v5 = if v4 then v4:FindFirstChild("Template") else v4
	local v6 = if v4 then v4:FindFirstChild("TemplateSellAll") else v4
	local v7 = if v6 then v6:FindFirstChild("SellValue") else v6

	if not (v4 and (v4:IsA("ScrollingFrame") and (v5 and (v5:IsA("Frame") and (v6 and (v6:IsA("Frame") and (v7 and v7:IsA("TextLabel")))))))) then
		warn((("[DeepsMachine] MainUI.%* is missing an expected child \226\128\148 window disabled"):format(Machine.FrameName)))

		return nil
	end

	v5.Visible = false
	v2.Visible = false

	local v8 = if v3 then v3:FindFirstChild("ProcessingFrame") else v3

	if v8 and v8:IsA("GuiObject") then
		v8.Visible = false
	end

	local SellButton = v6:FindFirstChild("SellButton")
	local v9 = if SellButton then SellButton:FindFirstChild("Content") else SellButton
	local v10 = if v9 then v9:FindFirstChild("Frame") else v9
	local v11 = if v10 then v10:FindFirstChild("ImageLabel") else v10

	if v11 and v11:IsA("ImageLabel") then
		v11.Visible = false
	end

	local SellButton2 = v5:FindFirstChild("SellButton")
	local v122 = if SellButton2 then SellButton2:FindFirstChild("Content") else SellButton2
	local v13 = if v122 then v122:FindFirstChild("Frame") else v122
	local v14 = if v13 then v13:FindFirstChild("ImageLabel") else v13

	if v14 and v14:IsA("ImageLabel") then
		v14.Visible = false
	end

	local EmptyLabel = v4:FindFirstChild("EmptyLabel")

	if not (EmptyLabel and EmptyLabel:IsA("TextLabel")) then
		local DisplayName = v5:FindFirstChild("DisplayName")
		local EmptyLabel2 = if DisplayName and DisplayName:IsA("TextLabel") then DisplayName:Clone() else Instance.new("TextLabel")

		EmptyLabel2.Name = "EmptyLabel"
		EmptyLabel2.Size = UDim2.new(1, 0, v5.Size.Y.Scale, v5.Size.Y.Offset)
		EmptyLabel2.Position = UDim2.new()
		EmptyLabel2.AnchorPoint = Vector2.new()
		EmptyLabel2.BackgroundTransparency = 1
		EmptyLabel2.TextScaled = true
		EmptyLabel2.TextXAlignment = Enum.TextXAlignment.Center
		EmptyLabel2.TextColor3 = Color3.fromRGB(235, 235, 235)
		EmptyLabel2.Text = "Nothing to process :("
		EmptyLabel2.LayoutOrder = 0
		EmptyLabel2.Visible = false
		EmptyLabel2.Parent = v4
		EmptyLabel = EmptyLabel2
	end

	local t2 = {
		frame = v2,
		list = v4,
		rowTemplate = v5,
		allRow = v6,
		allValue = v7,
		emptyLabel = EmptyLabel
	}

	v1 = t2

	local TopBar = v2:FindFirstChild("TopBar")
	local v15 = if TopBar then TopBar:FindFirstChild("CloseButton") else TopBar

	if v15 and v15:IsA("GuiButton") then
		v15.MouseButton1Click:Connect(function() --[[ Line: 232 | Upvalues: t (ref) ]]
			t.SetOpen(false)
		end)
	end

	local SellButton3 = v6:FindFirstChild("SellButton")

	if SellButton3 and SellButton3:IsA("GuiButton") then
		local v16 = SellButton3:FindFirstChild("Content")
		local v17 = if v16 then v16:FindFirstChild("Frame") else v16
		local v18 = if v17 then v17:FindFirstChild("TextLabel") else v17
		local v19 = if v18 and v18:IsA("TextLabel") then v18 else nil

		if v19 then
			v19.Text = "Sell"
		end

		SellButton3.MouseButton1Click:Connect(function() --[[ Line: 243 | Upvalues: t (ref) ]]
			t.ProcessAll()
		end)
	end

	return t2
end

local function refreshList() --[[ refreshList | Line: 255 | Upvalues: resolveUi (copy), t2 (copy), ownedLoot (copy), DeepsLootConfig (copy), ClientPlayerData (copy), t (copy) ]]
	local v1 = resolveUi()

	if not v1 then
		return
	end

	for v2, v3 in t2 do
		v3:Destroy()
	end

	table.clear(t2)

	local v4 = ownedLoot()
	local sum = 0

	for v6, v7 in v4 do
		local v5
		local v8 = DeepsLootConfig.Items[v7]
		local v9 = DeepsLootConfig.Items[v7]
		local v10 = ClientPlayerData.serverProfile:getState().inventory[v7]
		local v12 = if v9 then v9.StonesYield * (if v10 then v10.Stack or 0 else 0) else 0

		sum = sum + v12

		local v13 = ClientPlayerData.serverProfile:getState().inventory[v7]
		local v14 = if v13 then v13.Stack or 0 else 0
		local v15 = v1.rowTemplate:Clone()

		v15.Name = v7
		v15.LayoutOrder = v6
		v15.Visible = true

		local DisplayName = v15:FindFirstChild("DisplayName")

		if DisplayName and DisplayName:IsA("TextLabel") then
			DisplayName.Text = ("%* x%*"):format(v8 and v8.DisplayName or v7, v14)

			if v8 then
				DisplayName.TextColor3 = v8.Rarity.rarityColor
			end
		end

		local SellValue = v15:FindFirstChild("SellValue")

		if SellValue and SellValue:IsA("TextLabel") then
			SellValue.Text = ("+%*"):format(v12)
		end

		local FishInfo = v15:FindFirstChild("FishInfo")
		local v18 = if FishInfo then FishInfo:FindFirstChild("Icon") else FishInfo
		local v19 = if v8 then v8.Icon else v8

		if v18 and v18:IsA("ImageLabel") then
			v18.Image = if type(v19) == "string" then v19 else ""
			v18.Visible = if v18.Image == "" then false else true
		end

		local SellButton = v15:FindFirstChild("SellButton")

		if SellButton and SellButton:IsA("GuiButton") then
			local v22 = SellButton:FindFirstChild("Content")
			local v23 = if v22 then v22:FindFirstChild("Frame") else v22
			local v24 = if v23 then v23:FindFirstChild("TextLabel") else v23

			v5 = if v24 and v24:IsA("TextLabel") then v24 else nil

			if v5 then
				v5.Text = "Sell"
			end

			SellButton.MouseButton1Click:Connect(function() --[[ Line: 308 | Upvalues: t (ref), v7 (copy) ]]
				t.ProcessOne(v7)
			end)
		end

		v15.Parent = v1.list
		t2[v7] = v15
	end

	v1.allRow.Visible = #v4 > 0
	v1.allRow.LayoutOrder = 0
	v1.allValue.Text = ("+%*"):format(sum)
	v1.emptyLabel.Visible = #v4 == 0
end

local function process(p1) --[[ process | Line: 329 | Upvalues: v5 (ref), notifications (copy), Remotes (copy), playSellSound (copy), refreshList (copy) ]]
	if v5 then
		return
	end

	if #p1 == 0 then
		notifications:Send("Nothing to process!")
	else
		v5 = true
		task.spawn(function() --[[ Line: 338 | Upvalues: Remotes (ref), p1 (copy), v5 (ref), playSellSound (ref), notifications (ref), refreshList (ref) ]]
			local v12, v2 = Remotes.DeepsProcessLoot:Call({
				Items = p1
			}):Await()

			v5 = false

			local v3 = if v12 and type(v2) == "table" then v2 else nil

			if v3 and v3.Ok == true then
				playSellSound()
			elseif not v3 then
			elseif type(v3.Message) == "string" then
				notifications:Send(v3.Message)
			end

			refreshList()
		end)
	end
end

function t.ProcessOne(p1) --[[ ProcessOne | Line: 351 | Upvalues: v5 (ref), notifications (copy), Remotes (copy), playSellSound (copy), refreshList (copy) ]]
	local t = { p1 }

	if v5 then
		return
	end

	if #t == 0 then
		notifications:Send("Nothing to process!")
	else
		v5 = true
		task.spawn(function() --[[ Line: 338 | Upvalues: Remotes (ref), t (copy), v5 (ref), playSellSound (ref), notifications (ref), refreshList (ref) ]]
			local v12, v2 = Remotes.DeepsProcessLoot:Call({
				Items = t
			}):Await()

			v5 = false

			local v3 = if v12 and type(v2) == "table" then v2 else nil

			if v3 and v3.Ok == true then
				playSellSound()
			elseif not v3 then
			elseif type(v3.Message) == "string" then
				notifications:Send(v3.Message)
			end

			refreshList()
		end)
	end
end
function t.ProcessAll() --[[ ProcessAll | Line: 355 | Upvalues: ownedLoot (copy), v5 (ref), notifications (copy), Remotes (copy), playSellSound (copy), refreshList (copy) ]]
	local v1 = ownedLoot()

	if v5 then
		return
	end

	if #v1 == 0 then
		notifications:Send("Nothing to process!")
	else
		v5 = true
		task.spawn(function() --[[ Line: 338 | Upvalues: Remotes (ref), v1 (copy), v5 (ref), playSellSound (ref), notifications (ref), refreshList (ref) ]]
			local v12, v2 = Remotes.DeepsProcessLoot:Call({
				Items = v1
			}):Await()

			v5 = false

			local v3 = if v12 and type(v2) == "table" then v2 else nil

			if v3 and v3.Ok == true then
				playSellSound()
			elseif not v3 then
			elseif type(v3.Message) == "string" then
				notifications:Send(v3.Message)
			end

			refreshList()
		end)
	end
end
function t.SetOpen(p1) --[[ SetOpen | Line: 359 | Upvalues: resolveUi (copy), v2 (ref), refreshList (copy), popInGui (copy) ]]
	local v1 = resolveUi()

	if not v1 then
		return
	end

	v2 = p1
	v1.frame.Visible = p1

	local v22 = v1.frame.Parent
	local v3 = if v22 then v22:FindFirstChild("HUD") else v22

	if v3 and v3:IsA("GuiObject") then
		v3.Visible = not p1
	end

	if not p1 then
		return
	end

	refreshList()
	popInGui(v1.frame, true)
end

local function attachPrompt(p1) --[[ attachPrompt | Line: 384 | Upvalues: v4 (ref), t (copy), v2 (ref) ]]
	if not (v4 and v4.Parent) then
		local DeepsMachinePrompt = Instance.new("ProximityPrompt")

		DeepsMachinePrompt.Name = "DeepsMachinePrompt"
		DeepsMachinePrompt.Style = Enum.ProximityPromptStyle.Custom
		DeepsMachinePrompt.ActionText = "Process Loot"
		DeepsMachinePrompt.ObjectText = "Loot Processor"
		DeepsMachinePrompt.HoldDuration = 0.25
		DeepsMachinePrompt.MaxActivationDistance = 10
		DeepsMachinePrompt.RequiresLineOfSight = false
		DeepsMachinePrompt.KeyboardKeyCode = Enum.KeyCode.E
		DeepsMachinePrompt.Parent = p1
		DeepsMachinePrompt.Triggered:Connect(function() --[[ Line: 398 | Upvalues: t (ref), v2 (ref) ]]
			t.SetOpen(not v2)
		end)
		v4 = DeepsMachinePrompt
	end
end

function t.Init(p1) --[[ Init | Line: 404 | Upvalues: DeepsConfig (copy), ClientPlayerData (copy), v2 (ref), refreshList (copy), RunService (copy), v3 (ref), Workspace (copy), Machine (copy), attachPrompt (copy) ]]
	if DeepsConfig.Enabled then
		ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 409 ]]
			return p1.inventory
		end, function() --[[ Line: 411 | Upvalues: v2 (ref), refreshList (ref) ]]
			if not v2 then
				return
			end

			refreshList()
		end)

		local v1 = 0

		RunService.Heartbeat:Connect(function() --[[ Line: 418 | Upvalues: v1 (ref), v3 (ref), Workspace (ref), Machine (ref), attachPrompt (ref) ]]
			local v12 = os.clock()

			if not (v1 <= v12) then
				return
			end

			v1 = v12 + 5

			if v3 and v3.Parent then
				return
			end

			local v2 = Workspace:FindFirstChild(Machine.PartName, true)

			v3 = if v2 and v2:IsA("BasePart") then v2 else nil

			if not v3 then
				return
			end

			attachPrompt(v3)
		end)
	end
end

return t