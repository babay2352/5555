-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local ActiveEffects = require(ReplicatedStorage.shared.effects.ActiveEffects)
local TutorialGate = require(ReplicatedStorage.client.TutorialGate)
local WeatherEffects = require(ReplicatedStorage.shared.effects.WeatherEffects)
local WeatherRegistry = require(ReplicatedStorage.shared.weather.WeatherRegistry)
local t = {
	UECS = nil
}
local t2 = {}
local v1 = nil

local function safeCall(p1, p2, p3) --[[ safeCall | Line: 33 | Upvalues: WeatherRegistry (copy) ]]
	local ok, result = pcall(function() --[[ Line: 34 | Upvalues: WeatherRegistry (ref), p1 (copy), p2 (copy), p3 (copy) ]]
		WeatherRegistry.Modules[p1][p2](WeatherRegistry.Modules[p1], p3)
	end)

	if ok then
		return
	end

	warn((("[WeatherSystem] Error calling %* for %*: %*"):format(p2, p1, result)))
end

local function applyWeatherState() --[[ applyWeatherState | Line: 42 | Upvalues: TutorialGate (copy), ActiveEffects (copy), WeatherRegistry (copy), t2 (copy), v1 (ref) ]]
	local t = {}

	if not TutorialGate.active() then
		for v12, v2 in ActiveEffects.GetActive() do
			if WeatherRegistry.IsWeather(v2.Name) then
				t[v2.Name] = v2.ExpiresAt
			end
		end
	end

	local v3 = workspace:GetServerTimeNow()

	local function remainingOf(p1) --[[ remainingOf | Line: 60 | Upvalues: t (copy), v3 (copy) ]]
		return math.max(0, t[p1] - v3)
	end

	local v4 = nil

	for v5 in t do
		local Config = WeatherRegistry.Modules[v5].Config

		if v4 then
			local Config2 = WeatherRegistry.Modules[v4].Config

			if Config.Weight < Config2.Weight or Config.Weight == Config2.Weight and v5 < v4 then
				v4 = v5
			end

			continue
		end

		v4 = v5
	end

	for v6 in t2 do
		if not t[v6] then
			t2[v6] = nil

			local v7 = "EndOwn"
			local v8 = nil
			local ok, result = pcall(function() --[[ Line: 34 | Upvalues: WeatherRegistry (ref), v6 (copy), v7 (copy), v8 (copy) ]]
				WeatherRegistry.Modules[v6][v7](WeatherRegistry.Modules[v6], v8)
			end)

			if not ok then
				warn((("[WeatherSystem] Error calling EndOwn for %*: %*"):format(v6, result)))
			end
		end
	end

	for v9 in t do
		if not t2[v9] then
			t2[v9] = true

			local v11 = math.max(0, t[v9] - v3)
			local v12 = "StartOwn"
			local ok, result = pcall(function() --[[ Line: 34 | Upvalues: WeatherRegistry (ref), v9 (copy), v12 (copy), v11 (copy) ]]
				WeatherRegistry.Modules[v9][v12](WeatherRegistry.Modules[v9], v11)
			end)

			if not ok then
				warn((("[WeatherSystem] Error calling StartOwn for %*: %*"):format(v9, result)))
			end
		end
	end

	if v4 == v1 then
		return
	end

	if v1 then
		local v13 = v1
		local v14 = "EndGlobals"
		local v15 = nil
		local ok, result = pcall(function() --[[ Line: 34 | Upvalues: WeatherRegistry (ref), v13 (copy), v14 (copy), v15 (copy) ]]
			WeatherRegistry.Modules[v13][v14](WeatherRegistry.Modules[v13], v15)
		end)

		if not ok then
			warn((("[WeatherSystem] Error calling EndGlobals for %*: %*"):format(v13, result)))
		end
	end

	v1 = v4

	if not v4 then
		return
	end

	local v16 = v4
	local v18 = math.max(0, t[v4] - v3)
	local v19 = "StartGlobals"
	local ok, result = pcall(function() --[[ Line: 34 | Upvalues: WeatherRegistry (ref), v16 (copy), v19 (copy), v18 (copy) ]]
		WeatherRegistry.Modules[v16][v19](WeatherRegistry.Modules[v16], v18)
	end)

	if ok then
		return
	end

	warn((("[WeatherSystem] Error calling StartGlobals for %*: %*"):format(v16, result)))
end

local v2 = false
local v3 = false

local function refresh() --[[ refresh | Line: 113 | Upvalues: v2 (ref), v3 (ref), applyWeatherState (copy) ]]
	if v2 then
		v3 = true

		return
	end

	v2 = true

	repeat
		v3 = false
		applyWeatherState()
	until not v3

	v2 = false
end

function t.Init(p1) --[[ Init | Line: 126 | Upvalues: WeatherEffects (copy), ActiveEffects (copy), refresh (copy), TutorialGate (copy), v2 (ref), v3 (ref), applyWeatherState (copy) ]]
	WeatherEffects.CaptureDefaults()
	ActiveEffects.Changed:Connect(refresh)
	TutorialGate.onChanged(refresh)

	if v2 then
		v3 = true

		return
	end

	v2 = true

	repeat
		v3 = false
		applyWeatherState()
	until not v3

	v2 = false
end

return t