-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local Lighting = game:GetService("Lighting")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Maid = require(ReplicatedStorage.shared.class.Maid)
local t = { "WatchTower", "Cloud", "Float", "Skybox", "AnimateClone", "ScaleUpOnClone" }
local t2 = {
	UECS = nil
}
local t3 = {}
local t4 = {}

local function addPartToBulkMove(p1, p2) --[[ addPartToBulkMove | Line: 23 | Upvalues: t3 (copy), t4 (copy) ]]
	table.insert(t3, p1)
	table.insert(t4, p2)
end

local function collectPartOffsets(p1, p2) --[[ collectPartOffsets | Line: 33 ]]
	local t = {}

	for v1, v2 in p1:QueryDescendants("BasePart") do
		table.insert(t, {
			part = v2,
			offset = p2.CFrame:ToObjectSpace(v2.CFrame)
		})
	end

	return t
end

local function ApplyCFrame(p1, p2, p3) --[[ ApplyCFrame | Line: 41 | Upvalues: t3 (copy), t4 (copy) ]]
	debug.profilebegin("Apply CFrame")

	if p1:IsA("Model") then
		if not p1.PrimaryPart then
			debug.profileend()

			return
		end

		local _, v1 = workspace.CurrentCamera:WorldToViewportPoint(p2.Position)

		if not v1 then
			debug.profileend()

			return
		end

		if p3 then
			for v2, v3 in p3 do
				table.insert(t3, v3.part)
				table.insert(t4, p2 * v3.offset)
			end
		else
			local v7 = p1:GetPivot()

			for v8, v9 in p1:QueryDescendants("BasePart") do
				local v10 = p2 * v7:ToObjectSpace(v9.CFrame)

				table.insert(t3, v9)
				table.insert(t4, v10)
			end
		end
	else
		if not p1:IsA("BasePart") then
			debug.profileend()

			return
		end

		table.insert(t3, p1)
		table.insert(t4, p2)
	end

	debug.profileend()
end

local function WaitForPrimaryPart(p1) --[[ WaitForPrimaryPart | Line: 69 ]]
	if p1:IsA("Model") then
		while not p1.PrimaryPart and p1.Parent do
			task.wait(0.1)
		end

		return p1.PrimaryPart
	end

	if p1:IsA("BasePart") then
		return p1
	end

	return nil
end

function t2.Init(p1) --[[ Init | Line: 81 | Upvalues: Maid (copy), WaitForPrimaryPart (copy), collectPartOffsets (copy), ApplyCFrame (copy), RunService (copy), CollectionService (copy), Players (copy), Lighting (copy), t (copy), t3 (copy), t4 (copy) ]]
	local v1 = Maid.new()

	local function animateWatchTower(p1) --[[ animateWatchTower | Line: 86 | Upvalues: v1 (copy), WaitForPrimaryPart (ref), collectPartOffsets (ref), ApplyCFrame (ref), RunService (ref) ]]
		local v12 = CFrame.Angles(0, math.rad(1), 0)

		v1:GiveTask(task.spawn(function() --[[ Line: 88 | Upvalues: p1 (copy), WaitForPrimaryPart (ref), collectPartOffsets (ref), ApplyCFrame (ref), v12 (copy), RunService (ref) ]]
			local v1 = p1.PrimaryPart or WaitForPrimaryPart(p1)

			if not v1 then
				return
			end

			local v22 = collectPartOffsets(p1, v1)

			while p1.Parent and p1:IsDescendantOf(workspace) do
				ApplyCFrame(p1, v1.CFrame * v12, v22)
				RunService.Heartbeat:Wait()
			end
		end))
	end

	local function animateCloud(p1) --[[ animateCloud | Line: 102 | Upvalues: v1 (copy), WaitForPrimaryPart (ref), collectPartOffsets (ref), ApplyCFrame (ref), RunService (ref) ]]
		local v12 = math.random(2, 5) / 10
		local v2 = math.random() * math.pi * 2

		v1:GiveTask(task.spawn(function() --[[ Line: 107 | Upvalues: p1 (copy), WaitForPrimaryPart (ref), collectPartOffsets (ref), v12 (copy), v2 (copy), ApplyCFrame (ref), RunService (ref) ]]
			local v1 = nil

			if p1:IsA("BasePart") then
				v1 = p1
			elseif p1:IsA("Model") then
				v1 = p1.PrimaryPart or WaitForPrimaryPart(p1)
			end

			if not v1 then
				return
			end

			local v3 = v1.CFrame
			local v4 = if p1:IsA("Model") then collectPartOffsets(p1, v1) else nil

			while p1.Parent and p1:IsDescendantOf(workspace) do
				ApplyCFrame(p1, v3 * CFrame.new(math.sin(os.clock() * v12 + v2) * 20, 0, 0), v4)
				RunService.Heartbeat:Wait()
			end
		end))
	end

	local function animateFloat(p1) --[[ animateFloat | Line: 129 | Upvalues: v1 (copy), WaitForPrimaryPart (ref), CollectionService (ref), collectPartOffsets (ref), RunService (ref), Players (ref), ApplyCFrame (ref) ]]
		v1:GiveTask(task.spawn(function() --[[ Line: 133 | Upvalues: p1 (copy), WaitForPrimaryPart (ref), CollectionService (ref), collectPartOffsets (ref), RunService (ref), Players (ref), ApplyCFrame (ref) ]]
			local v1 = nil

			if p1:IsA("BasePart") then
				v1 = p1
			elseif p1:IsA("Model") then
				v1 = p1.PrimaryPart or WaitForPrimaryPart(p1)
			end

			if not v1 then
				return
			end

			local v3 = CollectionService:HasTag(p1, "AnimateClone") or CollectionService:HasTag(p1, "ScaleUpOnClone")

			if CollectionService:HasTag(p1, "AnimateClone") then
				while CollectionService:HasTag(p1, "AnimateClone") and p1.Parent do
					task.wait(0.1)
				end
			end

			if CollectionService:HasTag(p1, "ScaleUpOnClone") then
				while CollectionService:HasTag(p1, "ScaleUpOnClone") and p1.Parent do
					task.wait(0.1)
				end
			end

			local v4 = v1.CFrame
			local v5 = math.random() * math.pi * 2
			local v6 = math.random() * math.pi * 2
			local v7 = math.random() * math.pi * 2

			if v3 then
				local v8 = os.clock()

				v5 = -v8 * 1
				v6 = -v8 * 0.5
				v7 = 1.5707963267948966 - v8 * 0.5
			end

			local v9 = if p1:IsA("Model") then collectPartOffsets(p1, v1) else nil

			while p1.Parent and p1:IsDescendantOf(workspace) do
				RunService.Heartbeat:Wait()

				local CurrentCamera = workspace.CurrentCamera
				local v10, v11, v122, v13, v14, v15, v16

				if CurrentCamera then
					local _, v17 = CurrentCamera:WorldToViewportPoint(v1.Position)

					if v17 then
						v10 = Players.LocalPlayer.Character
						v11 = if v10 then v10:FindFirstChild("HumanoidRootPart") else v10

						if v11 and v11:IsA("BasePart") then
							v122 = v1.Position - v11.Position

							if v122.X * v122.X + v122.Y * v122.Y + v122.Z * v122.Z > 40000 then
								continue
							end

							v13 = os.clock()
							v14 = math.sin(v13 * 1 + v5) * 1
							v15 = math.sin(v13 * 0.5 + v6) * 1
							v16 = math.cos(v13 * 0.5 + v7) * 0.5
							ApplyCFrame(p1, v4 * CFrame.new(v15, v14, v16), v9)
						else
							v13 = os.clock()
							v14 = math.sin(v13 * 1 + v5) * 1
							v15 = math.sin(v13 * 0.5 + v6) * 1
							v16 = math.cos(v13 * 0.5 + v7) * 0.5
							ApplyCFrame(p1, v4 * CFrame.new(v15, v14, v16), v9)
						end
					else
						continue
					end
				else
					v10 = Players.LocalPlayer.Character
					v11 = if v10 then v10:FindFirstChild("HumanoidRootPart") else v10

					if v11 and v11:IsA("BasePart") then
						v122 = v1.Position - v11.Position

						if v122.X * v122.X + v122.Y * v122.Y + v122.Z * v122.Z > 40000 then
							continue
						end

						v13 = os.clock()
						v14 = math.sin(v13 * 1 + v5) * 1
						v15 = math.sin(v13 * 0.5 + v6) * 1
						v16 = math.cos(v13 * 0.5 + v7) * 0.5
						ApplyCFrame(p1, v4 * CFrame.new(v15, v14, v16), v9)
					else
						v13 = os.clock()
						v14 = math.sin(v13 * 1 + v5) * 1
						v15 = math.sin(v13 * 0.5 + v6) * 1
						v16 = math.cos(v13 * 0.5 + v7) * 0.5
						ApplyCFrame(p1, v4 * CFrame.new(v15, v14, v16), v9)
					end
				end
			end
		end))
	end

	local function animateSkybox() --[[ animateSkybox | Line: 201 | Upvalues: RunService (ref), Lighting (ref), v1 (copy) ]]
		local v12 = 0

		v1:GiveTask((RunService.Heartbeat:Connect(function(p13) --[[ Line: 203 | Upvalues: Lighting (ref), v12 (ref) ]]
			debug.profilebegin("UECS/AnimateObjects.SkyboxRotate")

			local v1 = Lighting:FindFirstChildWhichIsA("Sky")

			if not v1 then
				debug.profileend()

				return
			end

			v12 = (v12 + p13 * 0.5) % 360
			v1.SkyboxOrientation = Vector3.new(0, v12, 0)
			debug.profileend()
		end)))
	end

	local function animateAnimateClone(p1) --[[ animateAnimateClone | Line: 216 | Upvalues: v1 (copy), WaitForPrimaryPart (ref), collectPartOffsets (ref), ApplyCFrame (ref), RunService (ref), CollectionService (ref) ]]
		local v12 = os.clock()

		v1:GiveTask(task.spawn(function() --[[ Line: 220 | Upvalues: p1 (copy), WaitForPrimaryPart (ref), collectPartOffsets (ref), ApplyCFrame (ref), v12 (copy), RunService (ref), CollectionService (ref) ]]
			local v1 = p1.PrimaryPart or WaitForPrimaryPart(p1)

			if not v1 then
				return
			end

			local v2 = collectPartOffsets(p1, v1)
			local v32 = v1.CFrame

			ApplyCFrame(p1, v32 * CFrame.new(0, 0, 80), v2)

			while p1.Parent and p1:IsDescendantOf(workspace) do
				local v4 = os.clock() - v12

				if v4 >= 4 then
					break
				end

				local v5 = math.clamp(v4 / 4, 0, 1)

				ApplyCFrame(p1, v32 * CFrame.new(0, 0, (1 - v5 * (2 - v5)) * 80), v2)
				RunService.Heartbeat:Wait()
			end

			if not (p1.Parent and p1:IsDescendantOf(workspace)) then
				return
			end

			ApplyCFrame(p1, v32, v2)
			CollectionService:RemoveTag(p1, "AnimateClone")
		end))
	end

	local function animateScaleUpOnClone(p1) --[[ animateScaleUpOnClone | Line: 256 | Upvalues: v1 (copy), RunService (ref), CollectionService (ref) ]]
		local v12 = p1:GetScale()
		local v2 = os.clock()

		v1:GiveTask(task.spawn(function() --[[ Line: 261 | Upvalues: p1 (copy), v12 (copy), v2 (copy), RunService (ref), CollectionService (ref) ]]
			p1:ScaleTo(v12 * 0.1)

			while p1.Parent and p1:IsDescendantOf(workspace) do
				local v1 = os.clock() - v2

				if v1 >= 4 then
					break
				end

				local v22 = math.clamp(v1 / 4, 0, 1)

				p1:ScaleTo(v12 * (v22 * (2 - v22) * 0.9 + 0.1))
				RunService.Heartbeat:Wait()
			end

			if not (p1.Parent and p1:IsDescendantOf(workspace)) then
				return
			end

			p1:ScaleTo(v12)
			CollectionService:RemoveTag(p1, "ScaleUpOnClone")
		end))
	end

	local function handleTagged(p1, p2) --[[ handleTagged | Line: 287 | Upvalues: RunService (ref), Lighting (ref), v1 (copy), WaitForPrimaryPart (ref), collectPartOffsets (ref), ApplyCFrame (ref), animateCloud (copy), CollectionService (ref), Players (ref), animateScaleUpOnClone (copy) ]]
		if p1 == "Skybox" then
			local v12 = 0

			v1:GiveTask((RunService.Heartbeat:Connect(function(p13) --[[ Line: 203 | Upvalues: Lighting (ref), v12 (ref) ]]
				debug.profilebegin("UECS/AnimateObjects.SkyboxRotate")

				local v1 = Lighting:FindFirstChildWhichIsA("Sky")

				if not v1 then
					debug.profileend()

					return
				end

				v12 = (v12 + p13 * 0.5) % 360
				v1.SkyboxOrientation = Vector3.new(0, v12, 0)
				debug.profileend()
			end)))

			return
		end

		if not p2:IsDescendantOf(workspace) then
			return
		end

		if p1 == "WatchTower" and p2:IsA("Model") then
			local v2 = CFrame.Angles(0, math.rad(1), 0)

			v1:GiveTask(task.spawn(function() --[[ Line: 88 | Upvalues: p2 (copy), WaitForPrimaryPart (ref), collectPartOffsets (ref), ApplyCFrame (ref), v2 (copy), RunService (ref) ]]
				local v1 = p2.PrimaryPart or WaitForPrimaryPart(p2)

				if not v1 then
					return
				end

				local v22 = collectPartOffsets(p2, v1)

				while p2.Parent and p2:IsDescendantOf(workspace) do
					ApplyCFrame(p2, v1.CFrame * v2, v22)
					RunService.Heartbeat:Wait()
				end
			end))

			return
		end

		if p1 == "Cloud" then
			animateCloud(p2)

			return
		end

		if p1 == "Float" then
			v1:GiveTask(task.spawn(function() --[[ Line: 133 | Upvalues: p2 (copy), WaitForPrimaryPart (ref), CollectionService (ref), collectPartOffsets (ref), RunService (ref), Players (ref), ApplyCFrame (ref) ]]
				local v1 = nil

				if p2:IsA("BasePart") then
					v1 = p2
				elseif p2:IsA("Model") then
					v1 = p2.PrimaryPart or WaitForPrimaryPart(p2)
				end

				if not v1 then
					return
				end

				local v3 = CollectionService:HasTag(p2, "AnimateClone") or CollectionService:HasTag(p2, "ScaleUpOnClone")

				if CollectionService:HasTag(p2, "AnimateClone") then
					while CollectionService:HasTag(p2, "AnimateClone") and p2.Parent do
						task.wait(0.1)
					end
				end

				if CollectionService:HasTag(p2, "ScaleUpOnClone") then
					while CollectionService:HasTag(p2, "ScaleUpOnClone") and p2.Parent do
						task.wait(0.1)
					end
				end

				local v4 = v1.CFrame
				local v5 = math.random() * math.pi * 2
				local v6 = math.random() * math.pi * 2
				local v7 = math.random() * math.pi * 2

				if v3 then
					local v8 = os.clock()

					v5 = -v8 * 1
					v6 = -v8 * 0.5
					v7 = 1.5707963267948966 - v8 * 0.5
				end

				local v9 = if p2:IsA("Model") then collectPartOffsets(p2, v1) else nil

				while p2.Parent and p2:IsDescendantOf(workspace) do
					RunService.Heartbeat:Wait()

					local CurrentCamera = workspace.CurrentCamera
					local v10, v11, v122, v13, v14, v15, v16

					if CurrentCamera then
						local _, v17 = CurrentCamera:WorldToViewportPoint(v1.Position)

						if v17 then
							v10 = Players.LocalPlayer.Character
							v11 = if v10 then v10:FindFirstChild("HumanoidRootPart") else v10

							if v11 and v11:IsA("BasePart") then
								v122 = v1.Position - v11.Position

								if v122.X * v122.X + v122.Y * v122.Y + v122.Z * v122.Z > 40000 then
									continue
								end

								v13 = os.clock()
								v14 = math.sin(v13 * 1 + v5) * 1
								v15 = math.sin(v13 * 0.5 + v6) * 1
								v16 = math.cos(v13 * 0.5 + v7) * 0.5
								ApplyCFrame(p2, v4 * CFrame.new(v15, v14, v16), v9)
							else
								v13 = os.clock()
								v14 = math.sin(v13 * 1 + v5) * 1
								v15 = math.sin(v13 * 0.5 + v6) * 1
								v16 = math.cos(v13 * 0.5 + v7) * 0.5
								ApplyCFrame(p2, v4 * CFrame.new(v15, v14, v16), v9)
							end
						else
							continue
						end
					else
						v10 = Players.LocalPlayer.Character
						v11 = if v10 then v10:FindFirstChild("HumanoidRootPart") else v10

						if v11 and v11:IsA("BasePart") then
							v122 = v1.Position - v11.Position

							if v122.X * v122.X + v122.Y * v122.Y + v122.Z * v122.Z > 40000 then
								continue
							end

							v13 = os.clock()
							v14 = math.sin(v13 * 1 + v5) * 1
							v15 = math.sin(v13 * 0.5 + v6) * 1
							v16 = math.cos(v13 * 0.5 + v7) * 0.5
							ApplyCFrame(p2, v4 * CFrame.new(v15, v14, v16), v9)
						else
							v13 = os.clock()
							v14 = math.sin(v13 * 1 + v5) * 1
							v15 = math.sin(v13 * 0.5 + v6) * 1
							v16 = math.cos(v13 * 0.5 + v7) * 0.5
							ApplyCFrame(p2, v4 * CFrame.new(v15, v14, v16), v9)
						end
					end
				end
			end))

			return
		end

		if p1 == "AnimateClone" and p2:IsA("Model") then
			local v3 = os.clock()

			v1:GiveTask(task.spawn(function() --[[ Line: 220 | Upvalues: p2 (copy), WaitForPrimaryPart (ref), collectPartOffsets (ref), ApplyCFrame (ref), v3 (copy), RunService (ref), CollectionService (ref) ]]
				local v1 = p2.PrimaryPart or WaitForPrimaryPart(p2)

				if not v1 then
					return
				end

				local v2 = collectPartOffsets(p2, v1)
				local v32 = v1.CFrame

				ApplyCFrame(p2, v32 * CFrame.new(0, 0, 80), v2)

				while p2.Parent and p2:IsDescendantOf(workspace) do
					local v4 = os.clock() - v3

					if v4 >= 4 then
						break
					end

					local v5 = math.clamp(v4 / 4, 0, 1)

					ApplyCFrame(p2, v32 * CFrame.new(0, 0, (1 - v5 * (2 - v5)) * 80), v2)
					RunService.Heartbeat:Wait()
				end

				if not (p2.Parent and p2:IsDescendantOf(workspace)) then
					return
				end

				ApplyCFrame(p2, v32, v2)
				CollectionService:RemoveTag(p2, "AnimateClone")
			end))

			return
		end

		if p1 ~= "ScaleUpOnClone" or not p2:IsA("Model") then
			return
		end

		animateScaleUpOnClone(p2)
	end

	for v2, v3 in t do
		for v4, v5 in CollectionService:GetTagged(v3) do
			handleTagged(v3, v5)
		end

		v1:GiveTask(CollectionService:GetInstanceAddedSignal(v3):Connect(function(p1) --[[ Line: 312 | Upvalues: handleTagged (copy), v3 (copy) ]]
			handleTagged(v3, p1)
		end))
	end

	RunService:BindToRenderStep("MoveModels", Enum.RenderPriority.First.Value, function() --[[ Line: 317 | Upvalues: t3 (ref), t4 (ref) ]]
		debug.profilebegin("BulkMoveModels")

		if not (#t3 > 0) then
			debug.profileend()

			return
		end

		workspace:BulkMoveTo(t3, t4, Enum.BulkMoveMode.FireCFrameChanged)
		table.clear(t3)
		table.clear(t4)
		debug.profileend()
	end)
end

return t2