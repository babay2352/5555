-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Debris = game:GetService("Debris")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local GymEventConfig = require(ReplicatedStorage.shared.config.GymEventConfig)
local GymEventState = require(ReplicatedStorage.client.GymEventState)
local t = {
	UECS = nil
}
local Quad = Enum.EasingStyle.Quad
local Quad2 = Enum.EasingStyle.Quad
local v1 = nil
local v2 = nil
local v3 = nil
local v4 = nil
local t2 = {}

local function stopAnimation() --[[ stopAnimation | Line: 59 | Upvalues: v4 (ref) ]]
	if not v4 then
		return
	end

	v4:Disconnect()
	v4 = nil
end

local function setEmittersEnabled(p1, p2) --[[ setEmittersEnabled | Line: 66 ]]
	for v1, v2 in p1:GetDescendants() do
		if v2:IsA("ParticleEmitter") then
			v2.Enabled = p2
		end
	end
end

local function setBeamsEnabled(p1, p2) --[[ setBeamsEnabled | Line: 74 ]]
	for v1, v2 in p1:GetDescendants() do
		if v2:IsA("Beam") then
			v2.Enabled = p2
		end
	end
end

local function collectUsesLabels(p1) --[[ collectUsesLabels | Line: 84 | Upvalues: GymEventConfig (copy) ]]
	local t = {}

	for v2, v3 in p1:GetDescendants() do
		local v1

		if v3:IsA("BillboardGui") then
			local v4 = v3:FindFirstChild(GymEventConfig.MiniGym.TimerLabelName, true)

			v1 = if v4 and v4:IsA("TextLabel") then v4 else v3:FindFirstChildWhichIsA("TextLabel", true)

			if v1 then
				table.insert(t, v1)
			end
		end
	end

	return t
end

local function playSequenceSound(p1) --[[ playSequenceSound | Line: 107 | Upvalues: GymEventConfig (copy), Debris (copy) ]]
	local MiniGym = GymEventConfig.MiniGym
	local GymMiniGymSound = Instance.new("Part")

	GymMiniGymSound.Name = "GymMiniGymSound"
	GymMiniGymSound.Anchored = true
	GymMiniGymSound.CanCollide = false
	GymMiniGymSound.CanQuery = false
	GymMiniGymSound.CanTouch = false
	GymMiniGymSound.Transparency = 1
	GymMiniGymSound.Size = Vector3.new(1, 1, 1)
	GymMiniGymSound.CFrame = CFrame.new(p1)
	GymMiniGymSound.Parent = workspace

	local GymMiniGymSequence = Instance.new("Sound")

	GymMiniGymSequence.Name = "GymMiniGymSequence"
	GymMiniGymSequence.SoundId = MiniGym.Sound
	GymMiniGymSequence.Volume = MiniGym.SoundVolume
	GymMiniGymSequence.RollOffMaxDistance = MiniGym.SoundRollOffMaxDistance
	GymMiniGymSequence.Parent = GymMiniGymSound
	GymMiniGymSequence:Play()
	GymMiniGymSequence.Ended:Once(function() --[[ Line: 127 | Upvalues: GymMiniGymSound (copy) ]]
		GymMiniGymSound:Destroy()
	end)
	Debris:AddItem(GymMiniGymSound, MiniGym.RiseDuration + 30)
end

local function findTemplate(p1) --[[ findTemplate | Line: 135 | Upvalues: ReplicatedStorage (copy), GymEventConfig (copy) ]]
	local v1 = ReplicatedStorage:FindFirstChild("shared")
	local v2 = if v1 then v1:FindFirstChild("model") else v1
	local v3 = if v2 then v2:FindFirstChild(GymEventConfig.Hatch.ModelFolder) else v2
	local v4 = if v3 then v3:FindFirstChild(GymEventConfig.MiniGym.ModelSubFolder) else v3
	local v5 = if v4 then v4:FindFirstChild(p1) else v4

	if v5 and v5:IsA("Model") then
		return v5
	end

	return nil
end

local function despawn() --[[ despawn | Line: 147 | Upvalues: v4 (ref), v2 (ref), v3 (ref), t2 (ref), v1 (ref), GymEventConfig (copy), setBeamsEnabled (copy), setEmittersEnabled (copy), playSequenceSound (copy), RunService (copy), TweenService (copy), Quad2 (copy), Debris (copy) ]]
	if v4 then
		v4:Disconnect()
		v4 = nil
	end

	local v12 = v2

	v2 = nil
	v3 = nil
	table.clear(t2)
	v1 = nil

	if not v12 then
		return
	end

	local MiniGym = GymEventConfig.MiniGym
	local v22 = v12:GetPivot()
	local v42 = v22 + Vector3.new(0, -MiniGym.SpawnDepth, 0)

	setBeamsEnabled(v12, false)
	setEmittersEnabled(v12, true)

	for v5, v6 in v12:GetDescendants() do
		if v6:IsA("BillboardGui") or v6:IsA("SurfaceGui") then
			v6.Enabled = false
		end
	end

	playSequenceSound(v22.Position)

	local v7 = 0
	local v8 = nil

	v8 = RunService.RenderStepped:Connect(function(p1) --[[ Line: 182 | Upvalues: v7 (ref), MiniGym (copy), TweenService (ref), Quad2 (ref), v12 (copy), v22 (copy), v42 (copy), v8 (ref) ]]
		debug.profilebegin("UECS/GymMiniGym.Sink")
		v7 = v7 + p1

		local v2 = math.clamp(v7 / MiniGym.SinkDuration, 0, 1)

		v12:PivotTo(v22:Lerp(v42, (TweenService:GetValue(v2, Quad2, Enum.EasingDirection.In))))

		if not (v2 >= 1) then
			debug.profileend()

			return
		end

		if v8 then
			v8:Disconnect()
		end

		v12:Destroy()
		debug.profileend()
	end)
	Debris:AddItem(v12, MiniGym.SinkDuration + 5)
end

local function refreshTimer(p1) --[[ refreshTimer | Line: 202 | Upvalues: GymEventConfig (copy), t2 (ref) ]]
	local v3 = GymEventConfig.MiniGym.TimerText(math.max(0, p1.expiresAt - os.time()), p1.multiplier)

	for v4, v5 in t2 do
		if v5.Parent then
			v5.Text = v3
		end
	end
end

local function v(p1) --[[ spawn | Line: 212 | Upvalues: findTemplate (copy), GymEventConfig (copy), v2 (ref), setEmittersEnabled (copy), setBeamsEnabled (copy), t2 (ref), collectUsesLabels (copy), v3 (ref), refreshTimer (copy), playSequenceSound (copy), v4 (ref), RunService (copy), TweenService (copy), Quad (copy) ]]
	local v1 = findTemplate(p1.modelName)

	if not v1 then
		return
	end

	local pivot = p1.pivot

	if not pivot then
		return
	end

	local MiniGym = GymEventConfig.MiniGym
	local v22 = v1:Clone()

	v2 = v22

	for v32, v42 in v22:GetDescendants() do
		if v42:IsA("BasePart") then
			v42.Anchored = true
		end
	end

	local v6 = pivot + Vector3.new(0, -MiniGym.SpawnDepth, 0)

	setEmittersEnabled(v22, true)
	setBeamsEnabled(v22, true)
	t2 = collectUsesLabels(v22)
	v3 = p1
	refreshTimer(p1)
	v22:PivotTo(v6)
	v22.Parent = workspace
	playSequenceSound(pivot.Position)

	local v7 = 0
	local v8 = false

	if v4 then
		v4:Disconnect()
		v4 = nil
	end

	v4 = RunService.RenderStepped:Connect(function(p1) --[[ Line: 271 | Upvalues: v7 (ref), v8 (ref), MiniGym (copy), TweenService (ref), Quad (ref), v22 (copy), v6 (copy), pivot (copy), setEmittersEnabled (ref), setBeamsEnabled (ref), v4 (ref) ]]
		debug.profilebegin("UECS/GymMiniGym.Rise")
		v7 = v7 + p1

		if not v8 then
			local v2 = math.clamp(v7 / MiniGym.RiseDuration, 0, 1)

			v22:PivotTo(v6:Lerp(pivot, (TweenService:GetValue(v2, Quad, Enum.EasingDirection.Out))))

			if v2 >= 1 then
				v8 = true
				setEmittersEnabled(v22, false)
			end
		end

		if not (v7 >= MiniGym.RiseDuration + MiniGym.BeamLingerDuration) then
			debug.profileend()

			return
		end

		setBeamsEnabled(v22, false)

		if not v4 then
			debug.profileend()

			return
		end

		v4:Disconnect()
		v4 = nil
		debug.profileend()
	end)
end

local function sync() --[[ sync | Line: 294 | Upvalues: GymEventState (copy), v1 (ref), despawn (copy), v (copy), v2 (ref), v3 (ref), refreshTimer (copy) ]]
	local v12 = GymEventState.Get()
	local v22 = if v12 then v12.miniGym else v12
	local v32 = if v22 then ("%*@%*"):format(v22.modelName, v22.expiresAt) else nil

	if v32 ~= v1 then
		despawn()

		if v22 then
			v1 = v32
			v(v22)
		end
	end

	if not (v22 and v2) then
		return
	end

	v3 = v22
	refreshTimer(v22)
end

function t.Init(p1) --[[ Init | Line: 318 | Upvalues: GymEventState (copy), sync (copy), RunService (copy), v3 (ref), v2 (ref), refreshTimer (copy) ]]
	GymEventState.Start()
	GymEventState.Changed:Connect(function() --[[ Line: 325 | Upvalues: sync (ref) ]]
		local ok, result = pcall(sync)

		if ok then
			return
		end

		warn((("[GymMiniGym] sync failed: %*"):format(result)))
	end)
	sync()

	local v1 = 0

	RunService.Heartbeat:Connect(function(p1) --[[ Line: 337 | Upvalues: v1 (ref), v3 (ref), v2 (ref), refreshTimer (ref) ]]
		v1 = v1 + p1

		if v1 < 1 then
			return
		end

		v1 = 0

		if not (v3 and v2) then
			return
		end

		refreshTimer(v3)
	end)
end

return t