-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ProximityPromptService = game:GetService("ProximityPromptService")
local CollectionService = game:GetService("CollectionService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local ConvertValue = require(ReplicatedStorage.shared.util.ConvertValue)
local DecorationConfig = require(ReplicatedStorage.shared.config.DecorationConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local GymEventConfig = require(ReplicatedStorage.shared.config.GymEventConfig)
local LuckyblockConfig = require(ReplicatedStorage.shared.config.LuckyblockConfig)
local TrainToolConfig = require(ReplicatedStorage.shared.config.TrainToolConfig)
local PersonalRewardsShop = require(ReplicatedStorage.shared.UECS.Components.PersonalRewardsShop)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local SFX = require(ReplicatedStorage.client.SFX)
local createGamepadListNav = require(ReplicatedStorage.shared.util.createGamepadListNav)
local notifications = require(ReplicatedStorage.shared.module.notifications)
local t = {
	UECS = nil
}
local v1 = Color3.fromRGB(120, 120, 120)
local v2 = Color3.fromRGB(126, 255, 143)
local v3 = Color3.fromRGB(255, 90, 90)

local function resolveIcon(p1) --[[ resolveIcon | Line: 79 | Upvalues: DecorationConfig (copy), LuckyblockConfig (copy), TrainToolConfig (copy) ]]
	if p1.ItemType == "Decoration" then
		local v1 = DecorationConfig[p1.ConfigName]

		return if v1 then v1.Icon else v1
	end

	if p1.ItemType == "Luckyblock" then
		local v3 = LuckyblockConfig[p1.ConfigName]

		return if v3 then v3.Image else v3
	end

	if p1.ItemType ~= "TrainTool" then
		return nil
	end

	local v5 = TrainToolConfig[p1.ConfigName]

	return if v5 then v5.Icon else v5
end

local function resolveRarity(p1) --[[ resolveRarity | Line: 98 | Upvalues: DecorationConfig (copy), TrainToolConfig (copy) ]]
	if p1.ItemType == "Decoration" then
		local v1 = DecorationConfig[p1.ConfigName]

		return if v1 then v1.Rarity else v1
	end

	if p1.ItemType ~= "TrainTool" then
		return nil
	end

	local v3 = TrainToolConfig[p1.ConfigName]

	return if v3 then v3.Rarity else v3
end

local function purchasedSet(p1) --[[ purchasedSet | Line: 109 | Upvalues: GymEventConfig (copy) ]]
	local v1 = p1.events and p1.events[GymEventConfig.EventId]

	return if v1 then v1.storePurchases or {} else {}
end

function t.Init(p1) --[[ Init | Line: 114 | Upvalues: GymEventConfig (copy), ClientPlayerData (copy), Players (copy), PersonalRewardsShop (copy), DecorationConfig (copy), TrainToolConfig (copy), LuckyblockConfig (copy), SFX (copy), Remotes (copy), createGamepadListNav (copy), notifications (copy), ConvertValue (copy), v1 (copy), v2 (copy), v3 (copy), CollectionService (copy), ProximityPromptService (copy) ]]
	if not GymEventConfig.Enabled then
		return
	end

	repeat
		task.wait()
	until ClientPlayerData.isPlayerDataLoaded

	local PersonalRewards = GymEventConfig.PersonalRewards
	local LocalPlayer = Players.LocalPlayer
	local MainUI = LocalPlayer.PlayerGui:WaitForChild("MainUI")
	local v12 = MainUI:FindFirstChild(PersonalRewards.UiName)

	if not v12 then
		return
	end

	local v22 = v12:FindFirstChild("Content")
	local v32 = if v22 then v22:FindFirstChild("ScrollingFrame") else v22
	local v4 = if v32 then v32:FindFirstChild("Template") else v32

	if v32 and v4 then
		v12.Visible = false
		v4.Visible = false

		local v5 = PersonalRewardsShop.Add(v12)
		local v6 = nil

		v5.Visible.OnChange:Connect(function(p1) --[[ Line: 146 | Upvalues: v12 (copy), MainUI (copy), v6 (ref) ]]
			v12.Visible = p1

			local HUD = MainUI:FindFirstChild("HUD")

			if HUD then
				HUD.Visible = not p1
			end

			if not v6 then
				return
			end

			v6:SetOpen(p1)
		end)

		local function setOpen(p12) --[[ setOpen | Line: 163 | Upvalues: p1 (copy), v5 (copy) ]]
			local v1 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

			if not v1 then
				return
			end

			if p12 then
				v1.OpenedUIComponent:Set(v5)

				return
			end

			if v1.OpenedUIComponent:Get() ~= v5 then
				return
			end

			v1.OpenedUIComponent:Set(nil)
		end

		local TopBar = v12:FindFirstChild("TopBar")
		local v7 = if TopBar then TopBar:FindFirstChild("CloseButton") else TopBar

		if v7 then
			v7.MouseButton1Down:Connect(function() --[[ Line: 178 | Upvalues: p1 (copy), v5 (copy) ]]
				local v1 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

				if not v1 then
					return
				end

				if v1.OpenedUIComponent:Get() ~= v5 then
					return
				end

				v1.OpenedUIComponent:Set(nil)
			end)
		else
			warn((("[PersonalRewardsShop] %* has no TopBar.CloseButton \226\128\148 the shop cannot be closed"):format((v12:GetFullName()))))
		end

		local t = {}

		for v11, v122 in PersonalRewards.Rewards do
			local v8, v9, v10
			local v13 = v4:Clone()

			v13.Name = v122.Id
			v13.LayoutOrder = v122.LayoutOrder
			v13.Visible = true

			local ItemName = v13:FindFirstChild("ItemName")

			if ItemName then
				ItemName.Text = v122.Label
			end

			local Description = v13:FindFirstChild("Description")

			if Description then
				Description.Text = v122.Description
			end

			local Rarity = v13:FindFirstChild("Rarity")

			if Rarity and Description then
				if v122.ItemType == "Decoration" then
					local v14 = DecorationConfig[v122.ConfigName]

					v8 = if v14 then v14.Rarity else v14
				elseif v122.ItemType == "TrainTool" then
					local v15 = TrainToolConfig[v122.ConfigName]

					v8 = if v15 then v15.Rarity else v15
				else
					v8 = nil
				end

				if v8 then
					Rarity.Text = v8.displayName
					Rarity.TextColor3 = v8.rarityColor
				else
					Rarity.Visible = false
				end
			elseif Rarity then
				Rarity.Text = v122.Description
			end

			local ToolIcon = v13:FindFirstChild("ToolIcon")

			if ToolIcon then
				if v122.ItemType == "Decoration" then
					local v16 = DecorationConfig[v122.ConfigName]

					v9 = if v16 then v16.Icon else v16
				elseif v122.ItemType == "Luckyblock" then
					local v17 = LuckyblockConfig[v122.ConfigName]

					v9 = if v17 then v17.Image else v17
				elseif v122.ItemType == "TrainTool" then
					local v18 = TrainToolConfig[v122.ConfigName]

					v9 = if v18 then v18.Icon else v18
				else
					v9 = nil
				end

				if v9 then
					ToolIcon.Image = v9
				end
			end

			local Buttons = v13:FindFirstChild("Buttons")
			local v19 = if Buttons then Buttons:FindFirstChild("BuyButtonRobux") else Buttons

			if v19 then
				v19.Visible = false
			end

			local v20 = if Buttons then Buttons:FindFirstChild("BuyButton") else Buttons

			local function buy() --[[ buy | Line: 247 | Upvalues: SFX (ref), Remotes (ref), v122 (copy) ]]
				SFX.new(SFX.Sounds.Buy, 0.5)
				Remotes.BuyGymPersonalReward:Fire(v122.Id)
			end

			if v20 then
				local v21 = v20:FindFirstChild("Content")
				local v222 = if v21 then v21:FindFirstChild("TextLabel") else v21

				v20.MouseButton1Down:Connect(buy)
				v10 = v222
			else
				v10 = nil
			end

			v13.Parent = v32
			table.insert(t, {
				reward = v122,
				frame = v13,
				priceLabel = v10,
				buyButton = v20,
				buy = buy
			})
		end

		v6 = createGamepadListNav({
			actionPrefix = "GymPersonalRewards",
			confirmLabel = "Buy",
			shop = v12,
			scroll = v32,
			closeButton = v7,
			confirmKey = Enum.KeyCode.ButtonA,
			onClose = function() --[[ onClose | Line: 278 | Upvalues: p1 (copy), v5 (copy) ]]
				local v1 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

				if not v1 then
					return
				end

				if v1.OpenedUIComponent:Get() ~= v5 then
					return
				end

				v1.OpenedUIComponent:Set(nil)
			end
		})

		local t2 = {}

		for v23, v24 in t do
			table.insert(t2, {
				frame = v24.frame,
				button = v24.buyButton,
				activate = function() --[[ activate | Line: 287 | Upvalues: v24 (copy) ]]
					if not v24.buyButton or v24.buyButton.Active then
						v24.buy()
					end
				end
			})
		end

		v6:SetRows(t2)

		local t3 = {}
		local v25 = false

		local function refresh() --[[ refresh | Line: 309 | Upvalues: ClientPlayerData (ref), GymEventConfig (ref), t (copy), t3 (copy), v25 (ref), notifications (ref), PersonalRewards (copy), ConvertValue (ref), v1 (ref), v2 (ref), v3 (ref), v6 (ref) ]]
			local v12 = ClientPlayerData.serverProfile:getState()
			local v22 = v12.events and v12.events[GymEventConfig.EventId]
			local v32 = v22 and v22.storePurchases or {}
			local v4 = GymEventConfig.GetSpendable(v12)

			for v62, v7 in t do
				local v5
				local v8 = GymEventConfig.GetRewardPrice(v7.reward)
				local v9 = if v32[v7.reward.Id] == true then true else false
				local v10 = GymEventConfig.IsRewardAvailable(v7.reward)
				local v11 = if v10 then not v9 and (if v8 <= v4 then true else false) else v10

				if v11 and (not t3[v7.reward.Id] and v25) then
					notifications:Send(PersonalRewards.AffordAlert(v7.reward.Label))
				end

				t3[v7.reward.Id] = v11

				if v7.priceLabel then
					v7.priceLabel.Text = if v9 then "Owned" elseif v10 then ConvertValue.suffixformat(v8) else "Soon"
					v5 = if v9 or not v10 then v1 elseif v8 <= v4 then v2 else v3
					v7.priceLabel.TextColor3 = v5
				end

				if v7.buyButton then
					v7.buyButton.Active = not v9 and v10
				end
			end

			if not v6 then
				v25 = true

				return
			end

			v6:Refresh()
			v25 = true
		end

		refresh()
		ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 357 | Upvalues: GymEventConfig (ref) ]]
			return p1.events and p1.events[GymEventConfig.EventId]
		end, refresh)

		local function attachPrompt(p1) --[[ attachPrompt | Line: 362 | Upvalues: PersonalRewards (copy) ]]
			local v1 = if p1:IsA("Model") then p1.PrimaryPart or p1:FindFirstChildWhichIsA("BasePart") else p1

			if not (v1 and v1:IsA("BasePart")) then
				return
			end

			if not v1:FindFirstChild("GymPersonalRewardsPrompt") then
				local GymPersonalRewardsPrompt = Instance.new("ProximityPrompt")

				GymPersonalRewardsPrompt.Name = "GymPersonalRewardsPrompt"
				GymPersonalRewardsPrompt.ActionText = PersonalRewards.PromptActionText
				GymPersonalRewardsPrompt.ObjectText = PersonalRewards.PromptObjectText
				GymPersonalRewardsPrompt.MaxActivationDistance = PersonalRewards.PromptMaxDistance
				GymPersonalRewardsPrompt.RequiresLineOfSight = false
				GymPersonalRewardsPrompt.Parent = v1
			end
		end

		for v26, v27 in CollectionService:GetTagged(PersonalRewards.Tag) do
			attachPrompt(v27)
		end

		CollectionService:GetInstanceAddedSignal(PersonalRewards.Tag):Connect(attachPrompt)
		ProximityPromptService.PromptTriggered:Connect(function(p12, p2) --[[ Line: 392 | Upvalues: LocalPlayer (copy), p1 (copy), v5 (copy) ]]
			if p12.Name ~= "GymPersonalRewardsPrompt" or p2 ~= LocalPlayer then
				return
			end

			local v1 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

			if v1 then
				v1.OpenedUIComponent:Set(v5)
			end
		end)
	else
		warn((("[PersonalRewardsShop] %* is missing Content.ScrollingFrame.Template"):format((v12:GetFullName()))))
	end
end

return t