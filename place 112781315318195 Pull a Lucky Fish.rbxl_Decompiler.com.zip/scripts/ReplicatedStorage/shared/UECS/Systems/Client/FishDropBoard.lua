-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local MutationList = require(ReplicatedStorage.shared.util.MutationList)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local Signal = require(ReplicatedStorage.package.Signal)
local t = {}
local v1 = nil
local t2 = {}
local v2 = nil
local t3 = {}
local v3 = Signal.new()
local v4 = false
local v5 = false

local function c3(p1) --[[ c3 | Line: 41 ]]
	if p1 then
		return Color3.fromRGB(p1.R, p1.G, p1.B)
	end

	return Color3.new(255/255, 255/255, 255/255)
end

local function tierColors(p1) --[[ tierColors | Line: 48 ]]
	if p1 >= 500000 then
		return Color3.fromRGB(255, 50, 0)
	end

	if p1 >= 100000 then
		return Color3.fromRGB(180, 0, 255)
	end

	if p1 >= 10000 then
		return Color3.fromRGB(255, 200, 0)
	end

	return Color3.fromRGB(60, 65, 80)
end

local function populateEntry(p1, p2) --[[ populateEntry | Line: 61 | Upvalues: tierColors (copy), MutationList (copy) ]]
	p1.Visible = true

	local v1 = p2.Chance or 1
	local v2 = tierColors(v1)
	local RarityColor = p2.RarityColor
	local v3 = if RarityColor then Color3.fromRGB(RarityColor.R, RarityColor.G, RarityColor.B) else Color3.new(255/255, 255/255, 255/255)
	local EntryBorder = p1:FindFirstChild("EntryBorder")

	if EntryBorder and EntryBorder:IsA("UIStroke") then
		EntryBorder.Color = v2
	end

	local Avatar = p1:FindFirstChild("Avatar")

	if Avatar and Avatar:IsA("ImageLabel") then
		Avatar.Image = p2.AvatarUrl or ""
	end

	local PlayerName = p1:FindFirstChild("PlayerName")

	if PlayerName then
		PlayerName.Text = p2.DisplayName or "???"
	end

	local FishIcon = p1:FindFirstChild("FishIcon")

	if FishIcon and FishIcon:IsA("ImageLabel") then
		FishIcon.Image = p2.FishImage or ""
	end

	local FishName = p1:FindFirstChild("FishName")

	if FishName then
		local v6 = p2.FishDisplayName or "???"

		if p2.Mutation and p2.Mutation ~= "" then
			local v7 = MutationList.displayLabel(MutationList.parse(p2.Mutation))

			if v7 ~= "" then
				v6 = v7 .. " " .. v6
			end
		end

		FishName.Text = v6
		FishName.TextColor3 = v3
	end

	local Chance = p1:FindFirstChild("Chance")

	if not Chance then
		return
	end

	Chance.Text = "1/" .. tostring(v1)
	Chance.TextColor3 = Color3.fromRGB(255, 255, 255)
end

local function refreshFeed(p1) --[[ refreshFeed | Line: 116 | Upvalues: t (copy), populateEntry (copy) ]]
	local Background = p1.gui:FindFirstChild("Background")

	if not Background then
		return
	end

	local FeedFrame = Background:FindFirstChild("FeedFrame")

	if not FeedFrame then
		return
	end

	for i = 1, 8 do
		local v1 = FeedFrame:FindFirstChild("Entry_" .. i)

		if v1 then
			local v2 = #t - (i - 1)

			if v2 >= 1 then
				populateEntry(v1, t[v2])

				continue
			end

			v1.Visible = false
		end
	end
end

local function addNewEntry(p1, p2) --[[ addNewEntry | Line: 144 | Upvalues: populateEntry (copy) ]]
	local Background = p1.gui:FindFirstChild("Background")

	if not Background then
		return
	end

	local FeedFrame = Background:FindFirstChild("FeedFrame")

	if not FeedFrame then
		return
	end

	for i = 8, 2, -1 do
		local v1 = FeedFrame:FindFirstChild("Entry_" .. i)
		local v2 = FeedFrame:FindFirstChild("Entry_" .. i - 1)

		if v1 and (v2 and v2.Visible) then
			v1.Visible = true

			local EntryBorder = v1:FindFirstChild("EntryBorder")
			local EntryBorder2 = v2:FindFirstChild("EntryBorder")

			if EntryBorder and EntryBorder2 then
				EntryBorder.Color = EntryBorder2.Color
				EntryBorder.Thickness = EntryBorder2.Thickness
			end

			local Avatar = v1:FindFirstChild("Avatar")
			local Avatar2 = v2:FindFirstChild("Avatar")

			if Avatar and Avatar2 then
				Avatar.Image = Avatar2.Image
			end

			local PlayerName = v1:FindFirstChild("PlayerName")
			local PlayerName2 = v2:FindFirstChild("PlayerName")

			if PlayerName and PlayerName2 then
				PlayerName.Text = PlayerName2.Text
			end

			local FishIcon = v1:FindFirstChild("FishIcon")
			local FishIcon2 = v2:FindFirstChild("FishIcon")

			if FishIcon and FishIcon2 then
				FishIcon.Image = FishIcon2.Image
			end

			local FishName = v1:FindFirstChild("FishName")
			local FishName2 = v2:FindFirstChild("FishName")

			if FishName and FishName2 then
				FishName.Text = FishName2.Text
				FishName.TextColor3 = FishName2.TextColor3
			end

			local Chance = v1:FindFirstChild("Chance")
			local Chance2 = v2:FindFirstChild("Chance")

			if Chance and Chance2 then
				Chance.Text = Chance2.Text
				Chance.TextColor3 = Chance2.TextColor3
			end

			continue
		end

		if v1 and (v2 and not v2.Visible) then
			v1.Visible = false
		end
	end

	local Entry_1 = FeedFrame:FindFirstChild("Entry_1")

	if not Entry_1 then
		return
	end

	populateEntry(Entry_1, p2)
end

local function updateHourlyBest(p1, p2) --[[ updateHourlyBest | Line: 207 ]] end

local function clearPodiumCharacter() --[[ clearPodiumCharacter | Line: 211 | Upvalues: v2 (ref) ]]
	if not v2 then
		return
	end

	local v1 = v2.Parent

	if v1 then
		local playerModelSpawn = v1:FindFirstChild("playerModelSpawn")

		if playerModelSpawn then
			local PodiumInfoGui = playerModelSpawn:FindFirstChild("PodiumInfoGui")

			if PodiumInfoGui then
				PodiumInfoGui.Enabled = false
				PodiumInfoGui.Adornee = playerModelSpawn
			end
		end
	end

	v2:Destroy()
	v2 = nil
end

local function spawnPodiumCharacter(p1, p2) --[[ spawnPodiumCharacter | Line: 230 | Upvalues: v3 (copy), v4 (ref), v2 (ref), Players (copy), ReplicatedStorage (copy), MutationList (copy) ]]
	if not (p2 and p2.UserId) then
		v3:Fire()

		return
	end

	local v1 = p1.part and p1.part.Parent

	if not v1 then
		v3:Fire()

		return
	end

	local playerModelSpawn = v1:FindFirstChild("playerModelSpawn")

	if not playerModelSpawn then
		warn("[FishDropBoard] No playerModelSpawn in model")
		v3:Fire()

		return
	end

	if v4 then
		return
	end

	v4 = true

	if v2 then
		local v22 = v2.Parent

		if v22 then
			local playerModelSpawn2 = v22:FindFirstChild("playerModelSpawn")

			if playerModelSpawn2 then
				local PodiumInfoGui = playerModelSpawn2:FindFirstChild("PodiumInfoGui")

				if PodiumInfoGui then
					PodiumInfoGui.Enabled = false
					PodiumInfoGui.Adornee = playerModelSpawn2
				end
			end
		end

		v2:Destroy()
		v2 = nil
	end

	for v32, v42 in v1:GetChildren() do
		if v42.Name == "TierParticleHolder" then
			v42:Destroy()
		end
	end

	local v5 = p2.Chance or 1
	local v6, v7, v8, v9

	if v5 >= 500000 then
		local v10 = Color3.fromRGB(180, 0, 0)

		v6 = Color3.fromRGB(255, 50, 0)
		Color3.fromRGB(255, 50, 0)
		v7 = v10
		v8 = "\240\159\148\165 LEGENDARY CATCH \240\159\148\165"
		v9 = "\226\152\133\226\152\133\226\152\133"
	elseif v5 >= 100000 then
		local v11 = Color3.fromRGB(100, 0, 180)

		v6 = Color3.fromRGB(180, 0, 255)
		Color3.fromRGB(180, 0, 255)
		v7 = v11
		v8 = "\240\159\146\142 ULTRA RARE CATCH \240\159\146\142"
		v9 = "\226\152\133\226\152\133"
	elseif v5 >= 10000 then
		local v12 = Color3.fromRGB(200, 170, 0)

		v6 = Color3.fromRGB(255, 215, 0)
		Color3.fromRGB(255, 200, 0)
		v7 = v12
		v8 = "\226\173\144 RARE CATCH \226\173\144"
		v9 = "\226\152\133"
	else
		local v13 = Color3.fromRGB(255, 215, 0)

		v6 = Color3.fromRGB(255, 200, 0)
		Color3.fromRGB(255, 200, 0)
		v7 = v13
		v8 = "\240\159\145\145 BEST CATCH THIS HOUR"
		v9 = ""
	end

	local PodiumPart = v1:FindFirstChild("PodiumPart")

	if PodiumPart then
		PodiumPart.Color = v7

		if v5 >= 500000 or v5 >= 100000 then
			PodiumPart.Material = Enum.Material.Neon
		else
			PodiumPart.Material = Enum.Material.Marble
		end
	end

	local PodiumTop = v1:FindFirstChild("PodiumTop")

	if PodiumTop then
		PodiumTop.Color = v6
	end

	local PodiumStep = v1:FindFirstChild("PodiumStep")

	if PodiumStep then
		PodiumStep.Color = v7
	end

	if v5 >= 10000 then
		local TierParticleHolder = Instance.new("Part")

		TierParticleHolder.Name = "TierParticleHolder"
		TierParticleHolder.Size = Vector3.new(4, 0.1, 3)
		TierParticleHolder.CFrame = playerModelSpawn.CFrame * CFrame.new(0, -0.5, 0)
		TierParticleHolder.Anchored = true
		TierParticleHolder.CanCollide = false
		TierParticleHolder.Transparency = 1
		TierParticleHolder.Parent = v1

		if v5 >= 500000 then
			local ParticleEmitter = Instance.new("ParticleEmitter")

			ParticleEmitter.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 100, 0)), ColorSequenceKeypoint.new(0.5, Color3.fromRGB(255, 50, 0)), ColorSequenceKeypoint.new(1, Color3.fromRGB(200, 0, 0)) })
			ParticleEmitter.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.3), NumberSequenceKeypoint.new(0.5, 0.8), NumberSequenceKeypoint.new(1, 0) })
			ParticleEmitter.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.3), NumberSequenceKeypoint.new(0.7, 0.5), NumberSequenceKeypoint.new(1, 1) })
			ParticleEmitter.Lifetime = NumberRange.new(0.5, 1.2)
			ParticleEmitter.Speed = NumberRange.new(3, 8)
			ParticleEmitter.SpreadAngle = Vector2.new(20, 20)
			ParticleEmitter.Rate = 30
			ParticleEmitter.RotSpeed = NumberRange.new(-90, 90)
			ParticleEmitter.LightEmission = 1
			ParticleEmitter.LightInfluence = 0
			ParticleEmitter.Parent = TierParticleHolder

			local ParticleEmitter2 = Instance.new("ParticleEmitter")

			ParticleEmitter2.Color = ColorSequence.new(Color3.fromRGB(255, 215, 0))
			ParticleEmitter2.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.1), NumberSequenceKeypoint.new(0.5, 0.3), NumberSequenceKeypoint.new(1, 0) })
			ParticleEmitter2.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
			ParticleEmitter2.Lifetime = NumberRange.new(0.8, 2)
			ParticleEmitter2.Speed = NumberRange.new(5, 15)
			ParticleEmitter2.SpreadAngle = Vector2.new(180, 180)
			ParticleEmitter2.Rate = 15
			ParticleEmitter2.LightEmission = 1
			ParticleEmitter2.LightInfluence = 0
			ParticleEmitter2.Parent = TierParticleHolder

			local PointLight = Instance.new("PointLight")

			PointLight.Color = Color3.fromRGB(255, 50, 0)
			PointLight.Brightness = 3
			PointLight.Range = 15
			PointLight.Parent = TierParticleHolder
		elseif v5 >= 100000 then
			local ParticleEmitter = Instance.new("ParticleEmitter")

			ParticleEmitter.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(180, 0, 255)), ColorSequenceKeypoint.new(1, Color3.fromRGB(100, 0, 200)) })
			ParticleEmitter.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.1), NumberSequenceKeypoint.new(0.5, 0.5), NumberSequenceKeypoint.new(1, 0) })
			ParticleEmitter.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.3), NumberSequenceKeypoint.new(1, 1) })
			ParticleEmitter.Lifetime = NumberRange.new(0.5, 1.5)
			ParticleEmitter.Speed = NumberRange.new(2, 5)
			ParticleEmitter.SpreadAngle = Vector2.new(60, 60)
			ParticleEmitter.Rate = 15
			ParticleEmitter.LightEmission = 1
			ParticleEmitter.LightInfluence = 0
			ParticleEmitter.Parent = TierParticleHolder

			local PointLight = Instance.new("PointLight")

			PointLight.Color = Color3.fromRGB(160, 0, 255)
			PointLight.Brightness = 2
			PointLight.Range = 10
			PointLight.Parent = TierParticleHolder
		else
			local ParticleEmitter = Instance.new("ParticleEmitter")

			ParticleEmitter.Color = ColorSequence.new(Color3.fromRGB(255, 215, 0))
			ParticleEmitter.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.05), NumberSequenceKeypoint.new(0.5, 0.2), NumberSequenceKeypoint.new(1, 0) })
			ParticleEmitter.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.3), NumberSequenceKeypoint.new(1, 1) })
			ParticleEmitter.Lifetime = NumberRange.new(1, 2)
			ParticleEmitter.Speed = NumberRange.new(1, 3)
			ParticleEmitter.SpreadAngle = Vector2.new(180, 180)
			ParticleEmitter.Rate = 8
			ParticleEmitter.LightEmission = 1
			ParticleEmitter.LightInfluence = 0
			ParticleEmitter.Parent = TierParticleHolder
		end
	end

	task.spawn(function() --[[ Line: 426 | Upvalues: Players (ref), p2 (copy), v4 (ref), v3 (ref), playerModelSpawn (copy), v1 (copy), v2 (ref), ReplicatedStorage (ref), v8 (ref), v6 (ref), MutationList (ref), v9 (ref) ]]
		local ok, PodiumCharacter = pcall(function() --[[ Line: 427 | Upvalues: Players (ref), p2 (ref) ]]
			return Players:CreateHumanoidModelFromUserId(p2.UserId)
		end)

		if ok and PodiumCharacter then
			PodiumCharacter.Name = "PodiumCharacter"
			PodiumCharacter:SetPrimaryPartCFrame(playerModelSpawn.CFrame * CFrame.new(0, 1.5, 0) * CFrame.Angles(0, math.pi, 0))

			local v12 = PodiumCharacter.PrimaryPart or PodiumCharacter:FindFirstChild("HumanoidRootPart")

			if v12 then
				v12.Anchored = true
			end

			for v22, v32 in PodiumCharacter:GetDescendants() do
				if v32:IsA("BasePart") then
					v32.CanCollide = false
				end
			end

			PodiumCharacter.Parent = v1
			v2 = PodiumCharacter

			local Head = PodiumCharacter:FindFirstChild("Head")
			local PodiumInfoGui = playerModelSpawn:FindFirstChild("PodiumInfoGui")

			if PodiumInfoGui and Head then
				PodiumInfoGui.Adornee = Head
				PodiumInfoGui.Enabled = true
			end

			local Humanoid = PodiumCharacter:FindFirstChildOfClass("Humanoid")

			if Humanoid then
				Humanoid.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None

				local Animator = Humanoid:FindFirstChildOfClass("Animator")

				if not Animator then
					Animator = Instance.new("Animator")
					Animator.Parent = Humanoid
				end

				local Animation = Instance.new("Animation")

				Animation.AnimationId = "rbxassetid://507770239"
				pcall(function() --[[ Line: 477 | Upvalues: Animator (ref), Animation (copy) ]]
					local v1 = Animator:LoadAnimation(Animation)

					v1.Looped = true
					v1:Play()
				end)
			end

			local v42 = ReplicatedStorage:FindFirstChild("shared") and (ReplicatedStorage.shared:FindFirstChild("model") and ReplicatedStorage.shared.model:FindFirstChild("FishModels"))

			if v42 then
				local v5 = v42:FindFirstChild(p2.FishName)

				if v5 then
					local HeldFish = v5:Clone()

					HeldFish.Name = "HeldFish"

					local v62 = PodiumCharacter:FindFirstChild("RightHand") or PodiumCharacter:FindFirstChild("Right Arm")

					if v62 then
						if HeldFish.PrimaryPart or HeldFish:FindFirstChildWhichIsA("BasePart") then
							local v7 = HeldFish.PrimaryPart or HeldFish:FindFirstChildWhichIsA("BasePart")

							for v82, v92 in HeldFish:GetDescendants() do
								if v92:IsA("BasePart") then
									v92.Anchored = false
									v92.CanCollide = false
								end
							end

							HeldFish:SetPrimaryPartCFrame(v62.CFrame * CFrame.new(0, -0.5, -0.5))

							local WeldConstraint = Instance.new("WeldConstraint")

							WeldConstraint.Part0 = v62
							WeldConstraint.Part1 = v7
							WeldConstraint.Parent = v7
						end

						HeldFish.Parent = PodiumCharacter
					end
				end
			end

			local PodiumInfoGui2 = playerModelSpawn:FindFirstChild("PodiumInfoGui")

			if not PodiumInfoGui2 then
				v4 = false
				v3:Fire()

				return
			end

			local CrownTitle = PodiumInfoGui2:FindFirstChild("CrownTitle")

			if CrownTitle then
				CrownTitle.Text = v8
				CrownTitle.TextColor3 = v6
			end

			local PlayerRow = PodiumInfoGui2:FindFirstChild("PlayerRow")

			if PlayerRow then
				local AvatarImage = PlayerRow:FindFirstChild("AvatarImage")

				if AvatarImage then
					AvatarImage.Image = p2.AvatarUrl or ""

					local AvatarStroke = AvatarImage:FindFirstChild("AvatarStroke")

					if AvatarStroke then
						AvatarStroke.Color = v6
					end
				end

				local PlayerName = PlayerRow:FindFirstChild("PlayerName")

				if PlayerName then
					PlayerName.Text = p2.DisplayName or "???"
				end
			end

			local FishRow = PodiumInfoGui2:FindFirstChild("FishRow")

			if FishRow then
				local FishIcon = FishRow:FindFirstChild("FishIcon")

				if FishIcon then
					FishIcon.Image = p2.FishImage or ""
				end

				local FishName = FishRow:FindFirstChild("FishName")

				if FishName then
					local v10 = p2.FishDisplayName or "???"

					if p2.Mutation and p2.Mutation ~= "" then
						local v11 = MutationList.displayLabel(MutationList.parse(p2.Mutation))

						if v11 ~= "" then
							v10 = v11 .. " " .. v10
						end
					end

					FishName.Text = v10

					local RarityColor = p2.RarityColor

					FishName.TextColor3 = if RarityColor then Color3.fromRGB(RarityColor.R, RarityColor.G, RarityColor.B) else Color3.new(255/255, 255/255, 255/255)
				end
			end

			local ChanceText = PodiumInfoGui2:FindFirstChild("ChanceText")

			if not ChanceText then
				v4 = false
				v3:Fire()

				return
			end

			local v16 = "1 in " .. tostring(p2.Chance or 1)

			if v9 ~= "" then
				v16 = v9 .. " " .. v16 .. " " .. v9
			end

			ChanceText.Text = v16
			ChanceText.TextColor3 = v6
		else
			warn("[FishDropBoard] Failed to create character model:", PodiumCharacter)
		end

		v4 = false
		v3:Fire()
	end)
end

local function handleQueue() --[[ handleQueue | Line: 582 | Upvalues: v5 (ref), t3 (copy), t2 (copy), spawnPodiumCharacter (copy), v3 (copy) ]]
	if v5 or #t3 == 0 then
		return
	end

	v5 = true

	repeat
		local v1 = #t3
		local v2 = t3[v1]

		if not v2 then
			break
		end

		for i = 1, v1 do
			table.remove(t3, i)
		end

		for v32, v4 in t2 do
			task.delay(0.5, spawnPodiumCharacter, v4, v2)
			v3:Wait()
		end
	until #t3 == 0

	v5 = false
end

local function fireworks(p1) --[[ fireworks | Line: 611 ]]
	local part = p1.part

	if not part then
		return
	end

	local Part = Instance.new("Part")

	Part.Size = Vector3.new(1, 1, 1)
	Part.CFrame = part.CFrame * CFrame.new(0, 8, -2)
	Part.Anchored = true
	Part.CanCollide = false
	Part.Transparency = 1
	Part.Parent = workspace

	local t = {
		Color3.fromRGB(255, 50, 0),
		Color3.fromRGB(255, 200, 0),
		Color3.fromRGB(255, 100, 0),
		Color3.fromRGB(255, 255, 100),
		Color3.fromRGB(255, 150, 50)
	}

	for i = 1, 3 do
		local ParticleEmitter = Instance.new("ParticleEmitter")

		ParticleEmitter.Color = ColorSequence.new(t[i], t[i % #t + 1])
		ParticleEmitter.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.3), NumberSequenceKeypoint.new(0.5, 0.8), NumberSequenceKeypoint.new(1, 0) })
		ParticleEmitter.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.8, 0), NumberSequenceKeypoint.new(1, 1) })
		ParticleEmitter.Lifetime = NumberRange.new(0.5, 1.5)
		ParticleEmitter.Speed = NumberRange.new(15, 30)
		ParticleEmitter.SpreadAngle = Vector2.new(180, 180)
		ParticleEmitter.Rate = 0
		ParticleEmitter.RotSpeed = NumberRange.new(-180, 180)
		ParticleEmitter.LightEmission = 1
		ParticleEmitter.LightInfluence = 0
		ParticleEmitter.Parent = Part
		ParticleEmitter:Emit(25)
		task.delay(i * 0.3, function() --[[ Line: 655 | Upvalues: ParticleEmitter (copy) ]]
			ParticleEmitter:Emit(20)
		end)
	end

	local ParticleEmitter = Instance.new("ParticleEmitter")

	ParticleEmitter.Color = ColorSequence.new(Color3.fromRGB(255, 215, 0))
	ParticleEmitter.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.1), NumberSequenceKeypoint.new(0.5, 0.4), NumberSequenceKeypoint.new(1, 0) })
	ParticleEmitter.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.3), NumberSequenceKeypoint.new(1, 1) })
	ParticleEmitter.Lifetime = NumberRange.new(1, 2)
	ParticleEmitter.Speed = NumberRange.new(5, 10)
	ParticleEmitter.SpreadAngle = Vector2.new(360, 360)
	ParticleEmitter.Rate = 30
	ParticleEmitter.LightEmission = 1
	ParticleEmitter.LightInfluence = 0
	ParticleEmitter.Parent = Part
	task.delay(3, function() --[[ Line: 676 | Upvalues: Part (copy) ]]
		for v1, v2 in Part:GetChildren() do
			if v2:IsA("ParticleEmitter") then
				v2.Rate = 0
			end
		end

		task.wait(2)
		Part:Destroy()
	end)
end

local function startPulseAnimations(p1) --[[ startPulseAnimations | Line: 689 | Upvalues: TweenService (copy) ]]
	local Background = p1.gui:FindFirstChild("Background")

	if not Background then
		return
	end

	local TitleBar = Background:FindFirstChild("TitleBar")

	if TitleBar then
		local LiveDot = TitleBar:FindFirstChild("LiveDot")

		if LiveDot then
			task.spawn(function() --[[ Line: 701 | Upvalues: LiveDot (copy), TweenService (ref) ]]
				while LiveDot.Parent do
					TweenService:Create(LiveDot, TweenInfo.new(0.5, Enum.EasingStyle.Sine), {
						BackgroundTransparency = 0.7
					}):Play()
					task.wait(0.5)
					TweenService:Create(LiveDot, TweenInfo.new(0.5, Enum.EasingStyle.Sine), {
						BackgroundTransparency = 0
					}):Play()
					task.wait(0.5)
				end
			end)
		end
	end

	local HourlyFrame = Background:FindFirstChild("HourlyFrame")

	if not HourlyFrame then
		return
	end

	local PodiumBg = HourlyFrame:FindFirstChild("PodiumBg")

	if not PodiumBg then
		return
	end

	local CrownTitle = PodiumBg:FindFirstChild("CrownTitle")

	if not CrownTitle then
		return
	end

	task.spawn(function() --[[ Line: 723 | Upvalues: CrownTitle (copy), TweenService (ref) ]]
		while CrownTitle.Parent do
			TweenService:Create(CrownTitle, TweenInfo.new(1, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
				TextColor3 = Color3.fromRGB(255, 180, 50)
			}):Play()
			task.wait(1)
			TweenService:Create(CrownTitle, TweenInfo.new(1, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
				TextColor3 = Color3.fromRGB(255, 215, 0)
			}):Play()
			task.wait(1)
		end
	end)
end

local function registerBoard(p1) --[[ registerBoard | Line: 746 | Upvalues: t2 (copy), startPulseAnimations (copy), refreshFeed (copy), v1 (ref) ]]
	local DropFeedGui = p1:FindFirstChild("DropFeedGui")

	if DropFeedGui and DropFeedGui:IsA("SurfaceGui") then
		local t = {
			part = p1,
			gui = DropFeedGui
		}

		table.insert(t2, t)
		startPulseAnimations(t)
		refreshFeed(t)
	else
		warn("[FishDropBoard] Part tagged FishDropBoard but has no DropFeedGui SurfaceGui:", p1:GetFullName())
	end
end

return {
	UECS = nil,
	Init = function(p1) --[[ Init | Line: 770 | Upvalues: CollectionService (copy), registerBoard (copy), t2 (copy), t (copy), addNewEntry (copy), v1 (ref), Remotes (copy), fireworks (copy), t3 (copy), handleQueue (copy) ]]
		local function discoverBoards() --[[ discoverBoards | Line: 772 | Upvalues: CollectionService (ref), registerBoard (ref), t2 (ref) ]]
			for v1, v2 in CollectionService:GetTagged("FishDropBoard") do
				if v2:IsA("BasePart") then
					registerBoard(v2)
				end
			end

			if #t2 ~= 0 then
				return
			end

			for v3, v4 in workspace:GetChildren() do
				if v4.Name == "FishDropBoard" and v4:IsA("Model") then
					local Board = v4:FindFirstChild("Board")

					if Board and (Board:IsA("BasePart") and Board:FindFirstChild("DropFeedGui")) then
						warn("[FishDropBoard] Found board via name fallback:", Board:GetFullName())
						registerBoard(Board)
					end
				end
			end
		end

		discoverBoards()
		warn("[FishDropBoard] Init: registered", #t2, "boards")

		if #t2 ~= 0 then
			CollectionService:GetInstanceAddedSignal("FishDropBoard"):Connect(function(p13) --[[ Line: 819 | Upvalues: registerBoard (ref) ]]
				warn("[FishDropBoard] Tag added to:", p13:GetFullName())

				if not p13:IsA("BasePart") then
					return
				end

				registerBoard(p13)
			end)
			CollectionService:GetInstanceRemovedSignal("FishDropBoard"):Connect(function(p13) --[[ Line: 825 | Upvalues: t2 (ref) ]]
				for i = #t2, 1, -1 do
					if t2[i].part == p13 then
						table.remove(t2, i)
					end
				end
			end)
			Remotes.ReplicateFishDropFeed:On(function(p13) --[[ Line: 834 | Upvalues: t (ref), t2 (ref), addNewEntry (ref), fireworks (ref) ]]
				table.insert(t, p13)

				if #t > 50 then
					table.remove(t, 1)
				end

				for v2, v3 in t2 do
					addNewEntry(v3, p13)
				end

				if not (p13.Chance and p13.Chance >= 500000) then
					return
				end

				for v4, v5 in t2 do
					fireworks(v5)
				end
			end)
			Remotes.ReplicateHourlyBest:On(function(p13) --[[ Line: 853 | Upvalues: v1 (ref), t3 (ref), handleQueue (ref), t2 (ref), fireworks (ref) ]]
				warn("[FishDropBoard] Received hourly best:", p13.FishDisplayName, "chance:", p13.Chance, "userId:", p13.UserId)
				v1 = p13
				table.insert(t3, p13)
				handleQueue()

				for v2, v3 in t2 do

				end

				if not (p13.Chance and p13.Chance >= 500000) then
					return
				end

				for v4, v5 in t2 do
					fireworks(v5)
				end
			end)
			Remotes.RequestCurrentHourlyBest:Fire()

			return
		end

		warn("[FishDropBoard] No boards found yet, retrying in 5s...")
		task.delay(5, function() --[[ Line: 803 | Upvalues: t2 (ref), discoverBoards (copy), t (ref), addNewEntry (ref), v1 (ref) ]]
			if #t2 ~= 0 then
				return
			end

			discoverBoards()
			warn("[FishDropBoard] Retry: registered", #t2, "boards")

			for v12, v2 in t2 do
				for v3, v4 in t do
					addNewEntry(v2, v4)
				end
			end
		end)
		CollectionService:GetInstanceAddedSignal("FishDropBoard"):Connect(function(p13) --[[ Line: 819 | Upvalues: registerBoard (ref) ]]
			warn("[FishDropBoard] Tag added to:", p13:GetFullName())

			if not p13:IsA("BasePart") then
				return
			end

			registerBoard(p13)
		end)
		CollectionService:GetInstanceRemovedSignal("FishDropBoard"):Connect(function(p13) --[[ Line: 825 | Upvalues: t2 (ref) ]]
			for i = #t2, 1, -1 do
				if t2[i].part == p13 then
					table.remove(t2, i)
				end
			end
		end)
		Remotes.ReplicateFishDropFeed:On(function(p13) --[[ Line: 834 | Upvalues: t (ref), t2 (ref), addNewEntry (ref), fireworks (ref) ]]
			table.insert(t, p13)

			if #t > 50 then
				table.remove(t, 1)
			end

			for v2, v3 in t2 do
				addNewEntry(v3, p13)
			end

			if not (p13.Chance and p13.Chance >= 500000) then
				return
			end

			for v4, v5 in t2 do
				fireworks(v5)
			end
		end)
		Remotes.ReplicateHourlyBest:On(function(p13) --[[ Line: 853 | Upvalues: v1 (ref), t3 (ref), handleQueue (ref), t2 (ref), fireworks (ref) ]]
			warn("[FishDropBoard] Received hourly best:", p13.FishDisplayName, "chance:", p13.Chance, "userId:", p13.UserId)
			v1 = p13
			table.insert(t3, p13)
			handleQueue()

			for v2, v3 in t2 do

			end

			if not (p13.Chance and p13.Chance >= 500000) then
				return
			end

			for v4, v5 in t2 do
				fireworks(v5)
			end
		end)
		Remotes.RequestCurrentHourlyBest:Fire()
	end
}