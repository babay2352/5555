-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ContentProvider = game:GetService("ContentProvider")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local ConvertValue = require(ReplicatedStorage.shared.util.ConvertValue)
local CurrencyCounterSlot = require(ReplicatedStorage.shared.module.CurrencyCounterSlot)
local EventConfig = require(ReplicatedStorage.shared.config.EventConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local SFX = require(ReplicatedStorage.client.SFX)
local GymEventConfig = require(ReplicatedStorage.shared.config.GymEventConfig)
local TweenNumber = require(ReplicatedStorage.shared.util.TweenNumber)
local t = {
	UECS = nil,
	Priority = 31
}
local Icon = GymEventConfig.Currency.Icon
local v1 = UDim2.fromOffset(64, 64)

task.spawn(function() --[[ Line: 43 | Upvalues: ContentProvider (copy), Icon (copy) ]]
	ContentProvider:PreloadAsync({ Icon })
end)

local CounterProximity = EventConfig.Tags.CounterProximity
local v2 = TweenInfo.new(0.35, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
local v3 = TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.In)

local function selectEventCoins(p1) --[[ selectEventCoins | Line: 62 | Upvalues: GymEventConfig (copy) ]]
	return GymEventConfig.GetSpendable(p1)
end

function t.Init(p1) --[[ Init | Line: 66 | Upvalues: ClientPlayerData (copy), Players (copy), GymEventConfig (copy), EventConfig (copy), Icon (copy), TweenService (copy), v2 (copy), v3 (copy), TweenNumber (copy), selectEventCoins (copy), ConvertValue (copy), CurrencyCounterSlot (copy), CollectionService (copy), CounterProximity (copy), SFX (copy), v1 (copy), RunService (copy) ]]
	repeat
		task.wait()
	until ClientPlayerData.isPlayerDataLoaded

	local LocalPlayer = Players.LocalPlayer
	local PlayerGui = LocalPlayer.PlayerGui
	local Counters = PlayerGui:WaitForChild("MainUI"):WaitForChild("HUD"):WaitForChild("Counters")

	if GymEventConfig.Enabled then
		local v12 = Counters:WaitForChild(EventConfig.Ui.CoinCounterFrameName)
		local Counter = v12:WaitForChild("Counter")
		local Icon2 = v12:FindFirstChild("Icon")
		local v22, v32, v4, v5, v6, v7, v8, v9, v10, v11, EventCoinFlyoutLayer, v122, v13, v14

		if Icon2 and Icon2:IsA("ImageLabel") then
			Icon2.Image = Icon
		end

		v22 = function() --[[ getState | Line: 99 | Upvalues: ClientPlayerData (ref) ]]
			return ClientPlayerData.serverProfile:getState()
		end
		v32 = v12.Size
		v4 = UDim2.new(v32.X.Scale, v32.X.Offset, 0, 0)
		v12.Size = v4
		v12.Visible = false
		v5 = false
		v6 = nil
		v7 = function() --[[ showCounter | Line: 111 | Upvalues: v5 (ref), v12 (copy), v6 (ref), TweenService (ref), v2 (ref), v32 (copy) ]]
			if v5 then
				return
			end

			v5 = true
			v12.Visible = true

			if not v6 then
				v6 = TweenService:Create(v12, v2, {
					Size = v32
				})
				v6:Play()

				return
			end

			v6:Cancel()
			v6 = TweenService:Create(v12, v2, {
				Size = v32
			})
			v6:Play()
		end
		v8 = function() --[[ hideCounter | Line: 124 | Upvalues: v5 (ref), v6 (ref), TweenService (ref), v12 (copy), v3 (ref), v4 (copy) ]]
			if not v5 then
				return
			end

			v5 = false

			if v6 then
				v6:Cancel()
			end

			v6 = TweenService:Create(v12, v3, {
				Size = v4
			})
			v6:Play()
			v6.Completed:Connect(function() --[[ Line: 134 | Upvalues: v5 (ref), v12 (ref) ]]
				if v5 then
					return
				end

				v12.Visible = false
			end)
		end
		v9 = TweenNumber.new(0.35, selectEventCoins(v22()))
		v9:OnChange(function(p1) --[[ Line: 142 | Upvalues: Counter (copy), ConvertValue (ref) ]]
			Counter.Text = ConvertValue.suffixformat(p1)
		end)
		Counter.Text = ConvertValue.suffixformat(selectEventCoins(v22()))
		v10 = 0
		CurrencyCounterSlot.register("EventCoins", function() --[[ Line: 152 | Upvalues: v10 (ref), v8 (copy) ]]
			v10 = 0
			v8()
		end)
		v11 = function() --[[ isNearAnyTaggedPart | Line: 157 | Upvalues: LocalPlayer (copy), CollectionService (ref), CounterProximity (ref) ]]
			local Character = LocalPlayer.Character

			if not Character then
				return false
			end

			local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")

			if not HumanoidRootPart then
				return false
			end

			for v1, v2 in CollectionService:GetTagged(CounterProximity) do
				if v2:IsA("BasePart") and (HumanoidRootPart.Position - v2.Position).Magnitude <= 40 then
					return true
				end
			end

			return false
		end
		EventCoinFlyoutLayer = Instance.new("ScreenGui")
		EventCoinFlyoutLayer.Name = "EventCoinFlyoutLayer"
		EventCoinFlyoutLayer.DisplayOrder = 101
		EventCoinFlyoutLayer.IgnoreGuiInset = true
		EventCoinFlyoutLayer.ResetOnSpawn = false
		EventCoinFlyoutLayer.Parent = PlayerGui
		v122 = function() --[[ playCoinFlyout | Line: 181 | Upvalues: v12 (copy), EventCoinFlyoutLayer (copy), Icon (ref), SFX (ref), TweenService (ref), v1 (ref) ]]
			local v13 = v12.AbsolutePosition + v12.AbsoluteSize / 2
			local v2 = EventCoinFlyoutLayer.AbsoluteSize / 2

			for i = 1, 8 do
				task.delay((i - 1) * 0.07, function() --[[ Line: 186 | Upvalues: Icon (ref), EventCoinFlyoutLayer (ref), v2 (copy), SFX (ref), TweenService (ref), v1 (ref), v13 (copy) ]]
					local ImageLabel = Instance.new("ImageLabel")

					ImageLabel.Image = Icon
					ImageLabel.BackgroundTransparency = 1
					ImageLabel.AnchorPoint = Vector2.new(0.5, 0.5)
					ImageLabel.Size = UDim2.fromOffset(0, 0)

					local AbsoluteSize = EventCoinFlyoutLayer.AbsoluteSize
					local v12 = (math.random() - 0.5) * 2 * 0.4 * AbsoluteSize.X

					ImageLabel.Position = UDim2.fromOffset(v2.X + v12, v2.Y + (math.random() - 0.5) * 2 * 0.4 * AbsoluteSize.Y)
					ImageLabel.Parent = EventCoinFlyoutLayer
					SFX.PlaySoundWithRandomPitch(SFX.Sounds.Pop, 0.7, 0.9, 1.3)

					local v3 = TweenService:Create(ImageLabel, TweenInfo.new(0.2, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
						Size = v1
					})

					v3:Play()
					v3.Completed:Wait()

					local v4 = TweenService:Create(ImageLabel, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
						Position = UDim2.fromOffset(v13.X, v13.Y),
						Size = UDim2.fromOffset(0, 0)
					})

					v4:Play()
					v4.Completed:Wait()
					ImageLabel:Destroy()
				end)
			end
		end
		v13 = ClientPlayerData.serverProfile:getState()
		v14 = GymEventConfig.GetSpendable(v13)
		ClientPlayerData.serverProfile:subscribe(selectEventCoins, function(p1) --[[ Line: 227 | Upvalues: v14 (ref), v10 (ref), CurrencyCounterSlot (ref), v7 (copy), v122 (copy), v9 (copy) ]]
			local v1 = p1 - v14

			v14 = p1
			v10 = (1 / 0)
			CurrencyCounterSlot.claim("EventCoins")
			v7()

			if not (v1 > 0) then
				v9:Set(p1, function() --[[ Line: 241 | Upvalues: v10 (ref) ]]
					v10 = os.clock() + 4
				end)

				return
			end

			v122()
			v9:Set(p1, function() --[[ Line: 241 | Upvalues: v10 (ref) ]]
				v10 = os.clock() + 4
			end)
		end)
		RunService.Heartbeat:Connect(function() --[[ Line: 246 | Upvalues: v11 (copy), CurrencyCounterSlot (ref), v7 (copy), v10 (ref), v8 (copy) ]]
			debug.profilebegin("UECS/EventCoinCounterUI.Heartbeat")

			if v11() then
				if CurrencyCounterSlot.tryClaim("EventCoins") then
					v7()
				end
			elseif v10 <= os.clock() then
				v8()
				CurrencyCounterSlot.release("EventCoins")
			end

			debug.profileend()
		end)
	else
		local v15 = Counters:FindFirstChild(EventConfig.Ui.CoinCounterFrameName)

		if not (v15 and v15:IsA("GuiObject")) then
			return
		end

		v15.Visible = false
	end
end

return t