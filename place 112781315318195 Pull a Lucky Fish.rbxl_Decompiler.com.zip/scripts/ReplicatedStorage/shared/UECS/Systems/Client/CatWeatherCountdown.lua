-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

game:GetService("RunService")
require(ReplicatedStorage.shared.effects.ActiveEffects)
require(ReplicatedStorage.shared.UECS.GlobalTypes)
require(ReplicatedStorage.shared.weather.WeatherRegistry)

local t = {
	UECS = nil
}

local function formatCountdown(p1) --[[ formatCountdown | Line: 22 ]]
	return string.format("%02d:%02d", math.floor(p1 / 60), p1 % 60)
end

function t.Init(p1) --[[ Init | Line: 29 | Upvalues: CollectionService (copy) ]]
	local _ = CollectionService:GetTagged("CatWeatherCountdown")[1]
end

return t