-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local topbarplus = require(ReplicatedStorage.client.Satchel.Package.topbarplus)

return {
	UECS = nil,
	Priority = 100,
	Init = function(p1) --[[ Init | Line: 11 | Upvalues: topbarplus (copy), RunService (copy) ]]
		local v1 = topbarplus.new()

		v1:setName("RestartNotification")
		v1:setLeft()
		v1:oneClick(true)
		v1:setImage("rbxassetid://77909163430665")
		v1:setCaption("Scheduled server restart")
		v1:setLabel("00:00")
		v1:setEnabled(false)
		RunService:BindToRenderStep("UpdateRestartTimer", Enum.RenderPriority.Last.Value, function() --[[ Line: 22 | Upvalues: v1 (copy) ]]
			local v12 = workspace:GetAttribute("shutdownAt")

			if v12 and typeof(v12) == "number" then
				if not v1.isEnabled then
					v1:setEnabled(true)
				end

				local v3 = math.floor(v12 - workspace:GetServerTimeNow())

				if v3 < 0 then
					v1:setLabel("Restarting...")
				else
					local v4 = v3 // 60

					v1:setLabel((string.format("%.2i:%.2i", v4, v3 - v4 * 60)))
				end
			else
				if not v1.isEnabled then
					return
				end

				v1:setEnabled(false)
			end
		end)
	end
}