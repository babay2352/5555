-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ContextActionService = game:GetService("ContextActionService")
local GuiService = game:GetService("GuiService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local UserInputService = game:GetService("UserInputService")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local FishConfig = require(ReplicatedStorage.shared.config.FishConfig)
local FishEarnings = require(ReplicatedStorage.shared.util.FishEarnings)
local FishVault = require(ReplicatedStorage.shared.UECS.Components.FishVault)
local GardenConfig = require(ReplicatedStorage.shared.config.GardenConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local MutationConfig = require(ReplicatedStorage.shared.config.MutationConfig)
local MutationList = require(ReplicatedStorage.shared.util.MutationList)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local SFX = require(ReplicatedStorage.client.SFX)
local VaultConfig = require(ReplicatedStorage.shared.config.VaultConfig)
local bindToButtonPress = require(ReplicatedStorage.shared.util.bindToButtonPress)
local favoriteCount = require(ReplicatedStorage.shared.util.favoriteCount)
local notifications = require(ReplicatedStorage.shared.module.notifications)
local VaultTag = GardenConfig.VaultTag
local LocalPlayer = Players.LocalPlayer
local t = {
	UECS = nil
}

local function capacityNow() --[[ capacityNow | Line: 76 | Upvalues: VaultConfig (copy), ClientPlayerData (copy) ]]
	return VaultConfig.capacityFor(ClientPlayerData.serverProfile:getState().garden)
end

local function storedNow() --[[ storedNow | Line: 80 | Upvalues: VaultConfig (copy), ClientPlayerData (copy) ]]
	return VaultConfig.countStored(ClientPlayerData.serverProfile:getState().vault)
end

local function sortRows(p1) --[[ sortRows | Line: 87 ]]
	table.sort(p1, function(p1, p2) --[[ Line: 88 ]]
		if p1.earnings == p2.earnings then
			if p1.configName == p2.configName then
				return p1.level > p2.level
			end

			return p1.configName < p2.configName
		end

		return p1.earnings > p2.earnings
	end)
end

local function dumpVault() --[[ dumpVault | Line: 105 | Upvalues: RunService (copy), ClientPlayerData (copy), VaultConfig (copy), FishConfig (copy) ]]
	if not RunService:IsStudio() then
		return
	end

	local v1 = ClientPlayerData.serverProfile:getState()
	local vault = v1.vault
	local v2 = vault and vault.fish or {}
	local count = 0
	local count2 = 0

	for k in pairs(v2) do
		count = count + 1
	end

	local v3 = print
	local format = string.format

	v3(format("[FishVault] vault dump: %d rows, countStored=%d, capacity=%d, vault=%s, vault.fish=%s", count, VaultConfig.countStored(vault), VaultConfig.capacityFor(v1.garden), typeof(vault), (typeof(if vault then vault.fish else vault))))

	for k, v in pairs(v2) do
		local ExtraInfo = v.ExtraInfo
		local v9 = if FishConfig[v.ConfigName] == nil then false else true

		if v9 then
			count2 = count2 + 1
		end

		local v10 = print
		local format2 = string.format
		local v12 = tostring(k)
		local v13 = tostring(v.ConfigName)
		local v14 = typeof(v.ConfigName)
		local v15 = tostring(v9)
		local v16 = tostring(v.Stack)
		local v17 = typeof(v.Stack)
		local v18 = tostring(v.Favorited)
		local v19 = typeof(ExtraInfo)

		v10(format2("[FishVault]   key=%q ConfigName=%s (%s) inFishConfig=%s Stack=%s (%s) Favorited=%s ExtraInfo=%s Level=%s Mutation=%s Scanned=%s Untradable=%s", v12, v13, v14, v15, v16, v17, v18, v19, tostring(if ExtraInfo then ExtraInfo.Level else ExtraInfo), tostring(if ExtraInfo then ExtraInfo.Mutation else ExtraInfo), tostring(if ExtraInfo then ExtraInfo.Scanned else ExtraInfo), (tostring(if ExtraInfo then ExtraInfo.Untradable else ExtraInfo))))

		for k2, v27 in pairs(v) do
			if k2 ~= "ConfigName" and (k2 ~= "Stack" and (k2 ~= "Favorited" and k2 ~= "ExtraInfo")) then
				print(string.format("[FishVault]     extra field %s = %s (%s)", tostring(k2), tostring(v27), (typeof(v27))))
			end
		end
	end

	print(string.format("[FishVault] %d of %d rows will draw a tile", count2, count))
end

function t.Init(p1) --[[ Init | Line: 172 | Upvalues: VaultConfig (copy), LocalPlayer (copy), FishVault (copy), SFX (copy), notifications (copy), FishConfig (copy), MutationList (copy), MutationConfig (copy), ClientPlayerData (copy), favoriteCount (copy), FishEarnings (copy), Remotes (copy), dumpVault (copy), bindToButtonPress (copy), UserInputService (copy), GuiService (copy), ContextActionService (copy), capacityNow (copy), GardenConfig (copy), CollectionService (copy), VaultTag (copy) ]]
	if not VaultConfig.Enabled then
		return
	end

	local MainUI = LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("MainUI")
	local v1 = MainUI:FindFirstChild(VaultConfig.UIName, true)

	if not v1 then
		warn((("[FishVault] MainUI.%* not found \226\128\148 the vault has no UI"):format(VaultConfig.UIName)))

		return
	end

	v1.Visible = false

	local v2 = v1:FindFirstChild("Content")
	local v3 = v2 and v2:FindFirstChild("Inventory")
	local v4 = v2 and v2:FindFirstChild("Stored")
	local ItemContainer = v1:FindFirstChild("ItemContainer", true)

	if not (v3 and (v4 and ItemContainer)) then
		warn((("[FishVault] MainUI.%* is missing Content.Inventory/Content.Stored/ItemContainer"):format(VaultConfig.UIName)))

		return
	end

	local v5 = ItemContainer:Clone()

	for v6, v7 in { v3, v4 } do
		local v8 = v7:FindFirstChildWhichIsA("UIGridStyleLayout")

		if v8 then
			v8.SortOrder = Enum.SortOrder.LayoutOrder
		end
	end

	local v9 = v2 and v2:FindFirstChild("StoredLabel")
	local v10 = if v2 then v2:FindFirstChild("DepositAll") else v2
	local v11 = if v2 then v2:FindFirstChild("CloseButton") else v2
	local v12 = FishVault.Add(v1)
	local v13 = false

	local function closeWindow() --[[ closeWindow | Line: 213 | Upvalues: p1 (copy), v12 (copy) ]]
		local v1 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

		if not v1 or v1.OpenedUIComponent:Get() ~= v12 then
			return
		end

		v1.OpenedUIComponent:Set(nil)
	end

	local function findButton(p1) --[[ findButton | Line: 220 ]]
		if p1:IsA("GuiButton") then
			return p1
		end

		return p1:FindFirstChildWhichIsA("GuiButton", true)
	end

	local v14 = nil
	local v15 = false

	local function queueRefresh() --[[ queueRefresh | Line: 234 | Upvalues: v15 (ref), v12 (copy), v14 (ref) ]]
		if not v15 then
			v15 = true
			task.defer(function() --[[ Line: 239 | Upvalues: v15 (ref), v12 (ref), v14 (ref) ]]
				v15 = false

				if not v12.Visible:Get() then
					return
				end

				v14()
			end)
		end
	end

	local function send(p1, p2) --[[ send | Line: 250 | Upvalues: v13 (ref), SFX (ref), notifications (ref), v15 (ref), v12 (copy), v14 (ref) ]]
		if v13 then
			return
		end

		v13 = true

		local v1, v2 = p1()

		v13 = false

		if v1 and (typeof(v2) == "table" and v2.ok) then
			SFX.new(p2, 0.5)

			if not v15 then
				v15 = true
				task.defer(function() --[[ Line: 239 | Upvalues: v15 (ref), v12 (ref), v14 (ref) ]]
					v15 = false

					if not v12.Visible:Get() then
						return
					end

					v14()
				end)
			end
		else
			local v3 = if typeof(v2) == "table" then v2.reason else nil

			if not v1 then
				warn((("[FishVault] vault remote errored on the server: %*"):format(v2)))
			end

			SFX.new(SFX.Sounds.Error, 0.5)
			notifications:Send(v3 or "Couldn\'t move that fish.")

			if not v15 then
				v15 = true
				task.defer(function() --[[ Line: 239 | Upvalues: v15 (ref), v12 (ref), v14 (ref) ]]
					v15 = false

					if not v12.Visible:Get() then
						return
					end

					v14()
				end)
			end
		end
	end

	local function setFavoriteBadge(p1, p2) --[[ setFavoriteBadge | Line: 273 ]]
		local FavoriteIcon = p1:FindFirstChild("FavoriteIcon")

		if not FavoriteIcon then
			if not p2 then
				return
			end

			local FavoriteIcon2 = Instance.new("ImageLabel")

			FavoriteIcon2.Name = "FavoriteIcon"
			FavoriteIcon2.BackgroundTransparency = 1
			FavoriteIcon2.Image = "rbxassetid://131999210320254"
			FavoriteIcon2.Size = UDim2.fromScale(0.3, 0.3)
			FavoriteIcon2.Position = UDim2.new(1, -4, 1, -4)
			FavoriteIcon2.AnchorPoint = Vector2.new(1, 1)
			FavoriteIcon2.ZIndex = 3
			FavoriteIcon2.Parent = p1
			FavoriteIcon = FavoriteIcon2
		end

		if not FavoriteIcon then
			return
		end

		FavoriteIcon.Visible = p2
	end

	local function nameTextCap(p1) --[[ nameTextCap | Line: 301 ]]
		return math.max(math.floor(p1.AbsoluteSize.X * 0.17200000000000001 * 0.28 + 0.5), 8)
	end

	local function buildTile(p1, p2, p3, p4) --[[ buildTile | Line: 308 | Upvalues: FishConfig (ref), v5 (copy), MutationList (ref), MutationConfig (ref), setFavoriteBadge (copy) ]]
		local v1 = FishConfig[p1.configName]
		local v2 = v5:Clone()

		v2:AddTag("FishVaultTile")
		v2.Name = p1.key
		v2.Visible = true
		v2.LayoutOrder = p2
		v2.Parent = p3

		local ItemButton = v2:FindFirstChild("ItemButton")

		if not ItemButton then
			return
		end

		ItemButton.ItemImage.Image = if v1 then v1.Image or (v1.Icon or "") else ""

		local Name = ItemButton:FindFirstChild("Name")

		if Name then
			Name.Text = if v1 then v1.DisplayName else p1.configName

			local v52 = if v1 then v1.Rarity and v1.Rarity.rarityColor else v1

			Name.UIGradient.Color = ColorSequence.new(if v52 then v52 else Color3.new(255/255, 255/255, 255/255))
			Name.SizeCap.MaxTextSize = math.max(math.floor(p3.AbsoluteSize.X * 0.17200000000000001 * 0.28 + 0.5), 8)
		end

		ItemButton.Level.Visible = true
		ItemButton.Level.Text = ("Lv. %*"):format(p1.level)
		ItemButton.Number.Visible = if p1.stack > 1 then true else false
		ItemButton.Number.Text = ("x%*"):format(p1.stack)

		local v11 = if p1.mutation then MutationList.parse(p1.mutation) else {}
		local v12 = MutationList.best(v11)

		if v12 and MutationConfig.Mutations[v12] then
			ItemButton.MutationIcon.Image = MutationConfig.Mutations[v12].image
			ItemButton.MutationIcon.Visible = true
			ItemButton.MutationIcon.Count.Text = ("+%*"):format(#v11 - 1)
			ItemButton.MutationIcon.Count.Visible = if #v11 > 1 then true else false
		else
			ItemButton.MutationIcon.Visible = false
			ItemButton.MutationIcon.Count.Visible = false
		end

		setFavoriteBadge(ItemButton, if p1.favorited > 0 then true else false)

		local v16 = if v2:IsA("GuiButton") then v2 else v2:FindFirstChildWhichIsA("GuiButton", true)

		if not v16 then
			return
		end

		v16.Selectable = true
		v16.SelectionOrder = p2
		v16.Activated:Connect(p4)
	end

	local function clearTiles(p1) --[[ clearTiles | Line: 371 ]]
		for v1, v2 in p1:GetChildren() do
			if v2:HasTag("FishVaultTile") then
				v2:Destroy()
			end
		end
	end

	v14 = function() --[[ Line: 379 | Upvalues: ClientPlayerData (ref), VaultConfig (ref), clearTiles (copy), v3 (copy), v4 (copy), FishConfig (ref), favoriteCount (ref), FishEarnings (ref), LocalPlayer (ref), buildTile (copy), send (copy), Remotes (ref), SFX (ref), v9 (copy) ]]
		local v1 = ClientPlayerData.serverProfile:getState()
		local v2 = VaultConfig.capacityFor(ClientPlayerData.serverProfile:getState().garden)
		local v32 = VaultConfig.countStored(v1.vault)

		clearTiles(v3)
		clearTiles(v4)

		local t = {}
		local v42 = pairs

		for v6, v7 in v42(v1.inventory or {}) do
			if v7.Category == "Fish" and FishConfig[v7.ConfigName] then
				local v8 = v7.ExtraInfo or {}
				local v92 = v8.Level or 1
				local Mutation = v8.Mutation
				local t2 = {
					key = v6,
					configName = v7.ConfigName
				}

				t2.stack = math.max(1, (math.floor(v7.Stack or 1)))
				t2.level = v92
				t2.mutation = Mutation
				t2.favorited = favoriteCount(v1.favorites, v6)
				t2.earnings = FishEarnings.perFish(LocalPlayer, v7.ConfigName, false, v92, Mutation or "")
				table.insert(t, t2)
			end
		end

		table.sort(t, function(p1, p2) --[[ Line: 88 ]]
			if p1.earnings == p2.earnings then
				if p1.configName == p2.configName then
					return p1.level > p2.level
				end

				return p1.configName < p2.configName
			end

			return p1.earnings > p2.earnings
		end)

		local t2 = {}
		local v12 = pairs

		for v14, v15 in v12(v1.vault and v1.vault.fish or {}) do
			local v16 = v15.ExtraInfo or {}
			local v17 = v16.Level or 1
			local Mutation = v16.Mutation
			local t3 = {
				key = v14,
				configName = if typeof(v15.ConfigName) == "string" then v15.ConfigName else "?"
			}

			t3.stack = math.max(1, (math.floor(v15.Stack or 1)))
			t3.level = v17
			t3.mutation = Mutation
			t3.favorited = math.max(0, (math.floor(v15.Favorited or 0)))
			t3.earnings = FishEarnings.perFish(LocalPlayer, v15.ConfigName, false, v17, Mutation or "")
			table.insert(t2, t3)
		end

		table.sort(t2, function(p1, p2) --[[ Line: 88 ]]
			if p1.earnings == p2.earnings then
				if p1.configName == p2.configName then
					return p1.level > p2.level
				end

				return p1.configName < p2.configName
			end

			return p1.earnings > p2.earnings
		end)

		for v23, v24 in t do
			buildTile(v24, v23, v3, function() --[[ Line: 434 | Upvalues: send (ref), Remotes (ref), v24 (copy), SFX (ref) ]]
				send(function() --[[ Line: 435 | Upvalues: Remotes (ref), v24 (ref) ]]
					return Remotes.RequestDepositVaultFish:Call({
						InventoryKey = v24.key,
						Amount = v24.stack
					}):Await()
				end, SFX.Sounds.Click)
			end)
		end

		for v25, v26 in t2 do
			buildTile(v26, v25, v4, function() --[[ Line: 442 | Upvalues: send (ref), Remotes (ref), v26 (copy), SFX (ref) ]]
				send(function() --[[ Line: 443 | Upvalues: Remotes (ref), v26 (ref) ]]
					return Remotes.RequestWithdrawVaultFish:Call({
						VaultKey = v26.key,
						Amount = v26.stack
					}):Await()
				end, SFX.Sounds.Pop)
			end)
		end

		if not v9 then
			return
		end

		v9.Text = ("In Vault (%*)"):format((VaultConfig.CountText(v32, v2)))
	end

	if v10 then
		local v16 = if v10:IsA("GuiButton") then v10 else v10:FindFirstChildWhichIsA("GuiButton", true)

		if v16 then
			v16.Activated:Connect(function() --[[ Line: 457 | Upvalues: send (copy), Remotes (ref), SFX (ref) ]]
				send(function() --[[ Line: 458 | Upvalues: Remotes (ref) ]]
					return Remotes.RequestDepositAllVaultFish:Call():Await()
				end, SFX.Sounds.Buy)
			end)
		end
	end

	if v11 then
		local v17 = if v11:IsA("GuiButton") then v11 else v11:FindFirstChildWhichIsA("GuiButton", true)

		if v17 then
			v17.Activated:Connect(closeWindow)
		end
	end

	local CloseButton = v1:FindFirstChild("CloseButton", true)

	if CloseButton and (CloseButton:IsA("GuiButton") and CloseButton ~= v11) then
		CloseButton.MouseButton1Down:Connect(closeWindow)
	end

	v12.Visible.OnChange:Connect(function(p1, p2) --[[ Line: 476 | Upvalues: v1 (copy), MainUI (copy), dumpVault (ref), v14 (ref), bindToButtonPress (ref), closeWindow (copy), send (copy), Remotes (ref), SFX (ref), UserInputService (ref), GuiService (ref), ContextActionService (ref) ]]
		v1.Visible = p1

		local HUD = MainUI:FindFirstChild("HUD")

		if HUD then
			HUD.Visible = not p1
		end

		if p1 then
			dumpVault()
			v14()
		end

		if p1 == p2 then
			return
		end

		if p1 then
			bindToButtonPress("FishVaultClose", Enum.KeyCode.ButtonB, closeWindow)
			bindToButtonPress("FishVaultDepositAll", Enum.KeyCode.ButtonX, function() --[[ Line: 495 | Upvalues: send (ref), Remotes (ref), SFX (ref) ]]
				send(function() --[[ Line: 496 | Upvalues: Remotes (ref) ]]
					return Remotes.RequestDepositAllVaultFish:Call():Await()
				end, SFX.Sounds.Buy)
			end)

			if UserInputService.PreferredInput == Enum.PreferredInput.Gamepad then
				task.defer(GuiService.Select, GuiService, v1)
			end
		else
			ContextActionService:UnbindAction("FishVaultClose")
			ContextActionService:UnbindAction("FishVaultDepositAll")

			local SelectedObject = GuiService.SelectedObject

			if not (SelectedObject and SelectedObject:IsDescendantOf(v1)) then
				return
			end

			GuiService.SelectedObject = nil
		end
	end)
	GuiService:GetPropertyChangedSignal("SelectedObject"):Connect(function() --[[ Line: 513 | Upvalues: UserInputService (ref), GuiService (ref), v12 (copy), v1 (copy) ]]
		if UserInputService.PreferredInput ~= Enum.PreferredInput.Gamepad then
			return
		end

		local SelectedObject = GuiService.SelectedObject

		if not v12.Visible:Get() or SelectedObject and SelectedObject:IsDescendantOf(v1) then
			return
		end

		GuiService:Select(v1)
	end)

	local t = {}

	local function refreshBoards() --[[ refreshBoards | Line: 528 | Upvalues: VaultConfig (ref), ClientPlayerData (ref), capacityNow (ref), t (copy) ]]
		local v1 = VaultConfig.CountText(VaultConfig.countStored(ClientPlayerData.serverProfile:getState().vault), capacityNow())

		for v2, v3 in t do
			if v3.Parent then
				v3.Text = v1
			end
		end
	end

	local t2 = {}

	local function teardown(p12) --[[ teardown | Line: 542 | Upvalues: t2 (copy), t (copy), v12 (copy), VaultConfig (ref), ClientPlayerData (ref), p1 (copy) ]]
		local v1 = t2[p12]

		t[p12] = nil

		if not v1 then
			return
		end

		t2[p12] = nil

		for v2, v3 in v1.connections do
			v3:Disconnect()
		end

		if not (v12.Visible:Get() and VaultConfig.capacityFor(ClientPlayerData.serverProfile:getState().garden) <= 0) then
			return
		end

		local v4 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

		if not v4 or v4.OpenedUIComponent:Get() ~= v12 then
			return
		end

		v4.OpenedUIComponent:Set(nil)
	end

	local function setup(p12) --[[ setup | Line: 559 | Upvalues: t2 (copy), GardenConfig (ref), LocalPlayer (ref), t (copy), VaultConfig (ref), ClientPlayerData (ref), capacityNow (ref), p1 (copy), v12 (copy) ]]
		if not p12:IsA("Model") or t2[p12] then
			return
		end

		local v1 = p12:FindFirstChild(GardenConfig.VaultRootName, true) or p12:WaitForChild(GardenConfig.VaultRootName, 10)

		if not p12.Parent then
			return
		end

		local v2 = if p12:GetAttribute("OwnerUserId") == LocalPlayer.UserId then true else false
		local t3 = {
			connections = {}
		}

		t2[p12] = t3

		local v3 = p12:FindFirstChild(GardenConfig.VaultBillboardName, true)
		local v4 = if v3 then v3:FindFirstChild(GardenConfig.VaultCountLabelName, true) else v3

		if v4 then
			v4.Visible = v2

			if v2 then
				t[p12] = v4

				local v5 = VaultConfig.CountText(VaultConfig.countStored(ClientPlayerData.serverProfile:getState().vault), capacityNow())

				for v6, v7 in t do
					if v7.Parent then
						v7.Text = v5
					end
				end
			end
		end

		local v8 = if v1 then v1:WaitForChild(GardenConfig.VaultPromptName, 10) else v1

		if v8 then
			v8.Enabled = v2

			local function f9(p12) --[[ Line: 596 | Upvalues: LocalPlayer (ref), v2 (copy), p1 (ref), v12 (ref) ]]
				if p12 ~= LocalPlayer or not v2 then
					return
				end

				local v1 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

				if not v1 then
					return
				end

				v1.OpenedUIComponent:Set(v12)
			end

			table.insert(t3.connections, v8.Triggered:Connect(f9))
		else
			warn((("[FishVault] \"%*\" has no %* \226\128\148 it cannot be opened"):format(p12.Name, GardenConfig.VaultPromptName)))
		end
	end

	CollectionService:GetInstanceAddedSignal(VaultTag):Connect(setup)
	CollectionService:GetInstanceRemovedSignal(VaultTag):Connect(teardown)

	for v18, v19 in CollectionService:GetTagged(VaultTag) do
		task.spawn(setup, v19)
	end

	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 616 ]]
		return p1.vault
	end, function() --[[ Line: 618 | Upvalues: VaultConfig (ref), ClientPlayerData (ref), capacityNow (ref), t (copy), v15 (ref), v12 (copy), v14 (ref) ]]
		local v1 = VaultConfig.CountText(VaultConfig.countStored(ClientPlayerData.serverProfile:getState().vault), capacityNow())

		for v2, v3 in t do
			if v3.Parent then
				v3.Text = v1
			end
		end

		if not v15 then
			v15 = true
			task.defer(function() --[[ Line: 239 | Upvalues: v15 (ref), v12 (ref), v14 (ref) ]]
				v15 = false

				if not v12.Visible:Get() then
					return
				end

				v14()
			end)
		end
	end)
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 623 ]]
		return p1.inventory
	end, function() --[[ Line: 625 | Upvalues: v15 (ref), v12 (copy), v14 (ref) ]]
		if not v15 then
			v15 = true
			task.defer(function() --[[ Line: 239 | Upvalues: v15 (ref), v12 (ref), v14 (ref) ]]
				v15 = false

				if not v12.Visible:Get() then
					return
				end

				v14()
			end)
		end
	end)
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 629 ]]
		return p1.garden and p1.garden.items
	end, function() --[[ Line: 631 | Upvalues: VaultConfig (ref), ClientPlayerData (ref), capacityNow (ref), t (copy), v15 (ref), v12 (copy), v14 (ref) ]]
		local v1 = VaultConfig.CountText(VaultConfig.countStored(ClientPlayerData.serverProfile:getState().vault), capacityNow())

		for v2, v3 in t do
			if v3.Parent then
				v3.Text = v1
			end
		end

		if not v15 then
			v15 = true
			task.defer(function() --[[ Line: 239 | Upvalues: v15 (ref), v12 (ref), v14 (ref) ]]
				v15 = false

				if not v12.Visible:Get() then
					return
				end

				v14()
			end)
		end
	end)
end

return t