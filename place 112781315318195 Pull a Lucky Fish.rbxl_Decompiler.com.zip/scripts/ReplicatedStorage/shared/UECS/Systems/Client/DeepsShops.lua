-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local DeepsBagShop = require(ReplicatedStorage.shared.UECS.Components.DeepsBagShop)
local DeepsConfig = require(ReplicatedStorage.shared.config.DeepsConfig)
local DeepsFinsShop = require(ReplicatedStorage.shared.UECS.Components.DeepsFinsShop)
local DeepsGearConfig = require(ReplicatedStorage.shared.config.DeepsGearConfig)
local DeepsOxygenShop = require(ReplicatedStorage.shared.UECS.Components.DeepsOxygenShop)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Remotes = require(ReplicatedStorage.shared.Remotes)
local SFX = require(ReplicatedStorage.client.SFX)
local createConfigShop = require(ReplicatedStorage.shared.util.createConfigShop)
local t = {
	UECS = nil
}
local t2 = {
	{
		FrameName = "DeepsFinsShop",
		Slot = "fins",
		Component = DeepsFinsShop,
		Config = DeepsGearConfig.Fins,
		StatFormatter = function(p1) --[[ StatFormatter | Line: 45 ]]
			return p1.SwimSpeed .. " Swim Speed"
		end
	},
	{
		FrameName = "DeepsOxygenShop",
		Slot = "tank",
		Component = DeepsOxygenShop,
		Config = DeepsGearConfig.OxygenTanks,
		StatFormatter = function(p1) --[[ StatFormatter | Line: 54 ]]
			return p1.OxygenSeconds .. "s Oxygen"
		end
	},
	{
		FrameName = "DeepsBagShop",
		Slot = "bag",
		Component = DeepsBagShop,
		Config = DeepsGearConfig.LootBags,
		StatFormatter = function(p1) --[[ StatFormatter | Line: 63 ]]
			return p1.Slots .. " Loot Slots"
		end
	}
}

function t.Init(p1) --[[ Init | Line: 69 | Upvalues: Players (copy), t2 (copy), DeepsConfig (copy), Remotes (copy), createConfigShop (copy), ClientPlayerData (copy), SFX (copy) ]]
	local MainUI = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI")

	for v1, v2 in t2 do
		local v4 = MainUI:WaitForChild(v2.FrameName, if DeepsConfig.Enabled then 15 else 1)

		if v4 and v4:IsA("Frame") then
			if DeepsConfig.Enabled then
				local Slot = v2.Slot
				local t = {
					Fire = function(p1, p2) --[[ Fire | Line: 92 | Upvalues: Remotes (ref), Slot (copy) ]]
						Remotes.BuyDeepsGear:Fire({
							Slot = Slot,
							Name = p2
						})
					end
				}
				local t3 = {
					Fire = function(p1, p2) --[[ Fire | Line: 97 | Upvalues: Remotes (ref), Slot (copy) ]]
						Remotes.EquipDeepsGear:Fire({
							Slot = Slot,
							Name = p2
						})
					end
				}

				createConfigShop({
					shop = v4,
					shopComponent = v2.Component,
					config = v2.Config,
					buyRemote = t,
					equipRemote = t3,
					uecs = p1.UECS,
					statFormatter = v2.StatFormatter,
					isOwned = function(p1, p2) --[[ isOwned | Line: 110 | Upvalues: Slot (copy) ]]
						local deepsGear = p1.deepsGear

						if not deepsGear then
							return false
						end

						local v1 = true

						if (deepsGear.owned and deepsGear.owned[p2]) ~= true then
							v1 = deepsGear[Slot] == p2
						end

						return v1
					end,
					getEquipped = function(p1) --[[ getEquipped | Line: 117 | Upvalues: Slot (copy) ]]
						local deepsGear = p1.deepsGear

						return if deepsGear then deepsGear[Slot] else deepsGear
					end,
					extraSubscription = function(p1) --[[ extraSubscription | Line: 121 ]]
						return p1.deepsGear
					end
				})

				continue
			end

			v4.Visible = false

			continue
		end

		if DeepsConfig.Enabled then
			warn((("[DeepsShops] MainUI.%* (Frame) not found \226\128\148 that deeps shop has no UI"):format(v2.FrameName)))
		end
	end

	if DeepsConfig.Enabled then
		ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 134 ]]
			local deepsGear = p1.deepsGear

			return if deepsGear then deepsGear.owned else deepsGear
		end, function(p1, p2) --[[ Line: 137 | Upvalues: SFX (ref) ]]
			if type(p1) ~= "table" then
				return
			end

			local v2 = if p2 then p2 else {}

			for v3 in p1 do
				if not v2[v3] then
					SFX.new(SFX.Sounds.Buy, 0.5)

					return
				end
			end
		end)
	end
end

return t