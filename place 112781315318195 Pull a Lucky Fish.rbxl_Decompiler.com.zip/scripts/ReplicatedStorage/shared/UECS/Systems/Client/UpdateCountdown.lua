-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local SocialService = game:GetService("SocialService")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local EventId = require(ReplicatedStorage.shared.config.TeaserConfig).EventId
local t = {
	UECS = nil
}
local t2 = {}

local function findLabels(p1, p2) --[[ findLabels | Line: 48 ]]
	local v1 = p1:FindFirstChild(p2)

	if v1 then
		return v1:FindFirstChild("TextUp"), v1:FindFirstChild("Shadow")
	end

	return nil, nil
end

local function setText(p1, p2, p3) --[[ setText | Line: 60 ]]
	if p1 then
		p1.Text = p3
	end

	if not (p2 and p2:IsA("TextLabel")) then
		return
	end

	p2.Text = p3
end

local function eventTimeToUnix(p1) --[[ eventTimeToUnix | Line: 70 ]]
	return DateTime.fromUniversalTime(p1.Year, p1.Month, p1.Day, p1.Hour, p1.Minute, p1.Second).UnixTimestamp
end

local function formatCountdown(p1) --[[ formatCountdown | Line: 83 ]]
	if p1 <= 0 then
		return "00:00"
	end

	local v1 = math.floor(p1 / 86400)
	local v2 = math.floor(p1 % 86400 / 3600)
	local v3 = math.floor(p1 % 3600 / 60)
	local v4 = math.floor(p1 % 60)

	if v1 > 0 then
		return string.format("%dd %02dh %02dm %02ds", v1, v2, v3, v4)
	end

	if v2 > 0 then
		return string.format("%02dh %02dm %02ds", v2, v3, v4)
	end

	return string.format("%02dm %02ds", v3, v4)
end

local function resolveTargetUnix() --[[ resolveTargetUnix | Line: 106 | Upvalues: SocialService (copy), EventId (copy) ]]
	local ok, result = pcall(function() --[[ Line: 107 | Upvalues: SocialService (ref), EventId (ref) ]]
		local v1 = SocialService:GetExperienceEventAsync(EventId)

		if not v1 then
			warn("[UpdateCountdown] GetExperienceEventAsync returned nil for ID:", EventId)

			return nil
		end

		if v1.HasEnded or v1.HasStarted then
			return nil
		end

		local StartTime = v1.StartTime

		return DateTime.fromUniversalTime(StartTime.Year, StartTime.Month, StartTime.Day, StartTime.Hour, StartTime.Minute, StartTime.Second).UnixTimestamp
	end)

	if ok then
		return result
	end

	warn("[UpdateCountdown] Failed to resolve event time:", result)

	return nil
end

local function startFor(p1) --[[ startFor | Line: 126 | Upvalues: t2 (copy), SocialService (copy), EventId (copy), RunService (copy), formatCountdown (copy) ]]
	if not p1:IsA("BillboardGui") or t2[p1] then
		return
	end

	local Timer = p1:FindFirstChild("Timer")
	local v1, v2

	if Timer then
		local TextUp = Timer:FindFirstChild("TextUp")

		v1 = Timer:FindFirstChild("Shadow")
		v2 = TextUp
	else
		v2 = nil
		v1 = nil
	end

	if v2 then
		task.spawn(function() --[[ Line: 141 | Upvalues: SocialService (ref), EventId (ref), RunService (ref), v2 (copy), v1 (copy), formatCountdown (ref), p1 (copy), t2 (ref) ]]
			local ok, result = pcall(function() --[[ Line: 107 | Upvalues: SocialService (ref), EventId (ref) ]]
				local v1 = SocialService:GetExperienceEventAsync(EventId)

				if not v1 then
					warn("[UpdateCountdown] GetExperienceEventAsync returned nil for ID:", EventId)

					return nil
				end

				if v1.HasEnded or v1.HasStarted then
					return nil
				end

				local StartTime = v1.StartTime

				return DateTime.fromUniversalTime(StartTime.Year, StartTime.Month, StartTime.Day, StartTime.Hour, StartTime.Minute, StartTime.Second).UnixTimestamp
			end)
			local v12

			if ok then
				v12 = result
			else
				warn("[UpdateCountdown] Failed to resolve event time:", result)
				v12 = nil
			end

			if v12 == nil then
				return
			end

			local v22 = 0
			local v3 = RunService.RenderStepped:Connect(function(p1) --[[ Line: 149 | Upvalues: v22 (ref), v12 (copy), v2 (ref), v1 (ref), formatCountdown (ref) ]]
				debug.profilebegin("UECS/UpdateCountdown.RenderStepped")
				v22 = v22 + p1

				if v22 < 1 then
					debug.profileend()

					return
				end

				v22 = 0

				local v13 = v12 - workspace:GetServerTimeNow()

				if not (v13 > 0) then
					debug.profileend()

					return
				end

				local v23 = v2
				local v3 = v1
				local v4 = formatCountdown(v13)

				if v23 then
					v23.Text = v4
				end

				if not (v3 and v3:IsA("TextLabel")) then
					debug.profileend()

					return
				end

				v3.Text = v4
				debug.profileend()
			end)
			local v4 = v12 - workspace:GetServerTimeNow()

			if v4 > 0 then
				local v5 = v2
				local v6 = v1
				local v7 = formatCountdown(v4)

				if v5 then
					v5.Text = v7
				end

				if v6 and v6:IsA("TextLabel") then
					v6.Text = v7
				end
			end

			t2[p1] = {
				connection = v3,
				targetUnix = v12,
				destroying = p1.Destroying:Connect(function() --[[ Line: 172 | Upvalues: t2 (ref), p1 (ref) ]]
					local v1 = t2[p1]

					if not v1 then
						return
					end

					v1.connection:Disconnect()
					t2[p1] = nil
				end)
			}
		end)
	else
		warn("[UpdateCountdown] No Timer/TextUp found in", p1:GetFullName())
	end
end

local function stopFor(p1) --[[ stopFor | Line: 188 | Upvalues: t2 (copy) ]]
	if not p1:IsA("BillboardGui") then
		return
	end

	local v1 = t2[p1]

	if not v1 then
		return
	end

	v1.connection:Disconnect()

	if v1.destroying then
		v1.destroying:Disconnect()
	end

	t2[p1] = nil
end

function t.Init(p1) --[[ Init | Line: 202 | Upvalues: CollectionService (copy), startFor (copy), stopFor (copy) ]]
	for v1, v2 in CollectionService:GetTagged("UpdateBgui") do
		startFor(v2)
	end

	CollectionService:GetInstanceAddedSignal("UpdateBgui"):Connect(startFor)
	CollectionService:GetInstanceRemovedSignal("UpdateBgui"):Connect(stopFor)
end

return t