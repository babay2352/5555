-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local BaseSkinConfig = require(ReplicatedStorage.shared.config.BaseSkinConfig)
local FishConfig = require(ReplicatedStorage.shared.config.FishConfig)
local FishRodConfig = require(ReplicatedStorage.shared.config.FishRodConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local LuckyblockConfig = require(ReplicatedStorage.shared.config.LuckyblockConfig)
local MutationList = require(ReplicatedStorage.shared.util.MutationList)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local SFX = require(ReplicatedStorage.client.SFX)
local t = {
	UECS = nil,
	Priority = 34
}

local function waitForPopupsClosed(p1) --[[ waitForPopupsClosed | Line: 33 ]]
	local OfflineEarnings = p1:FindFirstChild("OfflineEarnings")
	local UpdateLog = p1:FindFirstChild("UpdateLog")
	local DailyLoginNew = p1:FindFirstChild("DailyLoginNew")

	if OfflineEarnings and OfflineEarnings.Visible then
		repeat
			task.wait(0.2)
		until not OfflineEarnings.Visible

		task.wait(0.4)
	end

	if UpdateLog and UpdateLog.Visible then
		repeat
			task.wait(0.2)
		until not UpdateLog.Visible

		task.wait(0.4)
	end

	if not (DailyLoginNew and DailyLoginNew.Visible) then
		return
	end

	repeat
		task.wait(0.2)
	until not DailyLoginNew.Visible

	task.wait(0.4)
end

local function animateCardAppear(p1, p2) --[[ animateCardAppear | Line: 60 | Upvalues: TweenService (copy) ]]
	local Container = p1:FindFirstChild("Container")

	if Container then
		Container.Size = UDim2.new(0.6, 0, 0.6, 0)
		Container.Rotation = math.random(-8, 8)
		task.delay(p2, function() --[[ Line: 69 | Upvalues: p1 (copy), TweenService (ref), Container (copy) ]]
			p1.Visible = true
			TweenService:Create(Container, TweenInfo.new(0.25, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
				Rotation = 0,
				Size = UDim2.new(1, 0, 1, 0)
			}):Play()
			task.delay(0.35, function() --[[ Line: 79 | Upvalues: Container (ref), TweenService (ref) ]]
				local v1 = math.random(-10, 10)

				Container.Rotation = v1

				local v3 = TweenService:Create(Container, TweenInfo.new(math.max(math.abs(10 - v1) / 20 * 1.2, 0.1), Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
					Rotation = 10
				})

				v3:Play()
				v3.Completed:Once(function() --[[ Line: 92 | Upvalues: TweenService (ref), Container (ref) ]]
					TweenService:Create(Container, TweenInfo.new(1.2, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true), {
						Rotation = -10
					}):Play()
				end)
			end)
		end)
	end
end

local function resolveCardInfo(p1) --[[ resolveCardInfo | Line: 105 | Upvalues: FishConfig (copy), MutationList (copy), FishRodConfig (copy), LuckyblockConfig (copy), BaseSkinConfig (copy) ]]
	if type(p1) ~= "table" then
		return nil
	end

	local v1 = tonumber(p1.Amount) or 0

	if v1 < 1 then
		return nil
	end

	if p1.Type == "Gems" then
		return {
			Image = "rbxassetid://86270302884166",
			Label = "Gems",
			Amount = v1
		}
	end

	if p1.Type == "Fish" then
		local v2 = if type(p1.ConfigName) == "string" then FishConfig[p1.ConfigName] else nil

		if not v2 then
			return nil
		end

		local DisplayName = v2.DisplayName
		local v3 = MutationList.parse(p1.Mutation)

		if #v3 > 0 then
			DisplayName = ("%* %*"):format(MutationList.displayLabel(v3), DisplayName)
		end

		return {
			Image = v2.Image,
			Label = DisplayName,
			Amount = v1
		}
	end

	local v5 = if p1.Type == "FishRod" then FishRodConfig elseif p1.Type == "Luckyblock" then LuckyblockConfig elseif p1.Type == "BaseSkin" then BaseSkinConfig.Config else nil

	if not v5 then
		return nil
	end

	local v6 = if type(p1.ConfigName) == "string" then v5[p1.ConfigName] else nil

	if type(v6) ~= "table" then
		return nil
	end

	local t = {}

	t.Image = v6.Image or v6.Icon or ""
	t.Label = v6.DisplayName or p1.ConfigName
	t.Amount = v1

	return t
end

function t.Init(p1) --[[ Init | Line: 144 | Upvalues: Players (copy), TweenService (copy), resolveCardInfo (copy), waitForPopupsClosed (copy), SFX (copy), animateCardAppear (copy), Remotes (copy) ]]
	local MainUI = Players.LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("MainUI")
	local AdminRewardPopUp = MainUI:WaitForChild("AdminRewardPopUp")
	local v1 = AdminRewardPopUp:WaitForChild("Content")
	local TopBar = AdminRewardPopUp:WaitForChild("TopBar")
	local TextLabel = v1:WaitForChild("TextLabel")
	local RewardsContainer = v1:WaitForChild("RewardsContainer")
	local CardTemplate = RewardsContainer:WaitForChild("CardTemplate")
	local ClaimBtn = v1:WaitForChild("ClaimBtn")
	local CloseButton = TopBar:WaitForChild("CloseButton")

	CloseButton.ZIndex = 10
	CloseButton.Active = true

	local Size = AdminRewardPopUp.Size
	local v2 = false

	local function showPopup() --[[ showPopup | Line: 163 | Upvalues: AdminRewardPopUp (copy), TweenService (ref), Size (copy) ]]
		AdminRewardPopUp.Size = UDim2.new(0, 0, 0, 0)
		AdminRewardPopUp.Visible = true
		TweenService:Create(AdminRewardPopUp, TweenInfo.new(0.35, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
			Size = Size
		}):Play()
	end

	local function closePopup() --[[ closePopup | Line: 173 | Upvalues: v2 (ref), TweenService (ref), AdminRewardPopUp (copy), Size (copy) ]]
		if not v2 then
			v2 = true

			local v1 = TweenService:Create(AdminRewardPopUp, TweenInfo.new(0.25, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
				Size = UDim2.new(0, 0, 0, 0)
			})

			v1:Play()
			v1.Completed:Once(function() --[[ Line: 184 | Upvalues: AdminRewardPopUp (ref), Size (ref), v2 (ref) ]]
				AdminRewardPopUp.Visible = false
				AdminRewardPopUp.Size = Size
				v2 = false
			end)
		end
	end

	local Size2 = ClaimBtn.Size

	local function pressButton() --[[ pressButton | Line: 192 | Upvalues: TweenService (ref), ClaimBtn (copy), Size2 (copy) ]]
		local v1 = TweenService:Create(ClaimBtn, TweenInfo.new(0.08, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			Size = UDim2.new(Size2.X.Scale * 0.9, Size2.X.Offset, Size2.Y.Scale * 0.9, Size2.Y.Offset)
		})

		v1:Play()
		v1.Completed:Once(function() --[[ Line: 203 | Upvalues: TweenService (ref), ClaimBtn (ref), Size2 (ref) ]]
			TweenService:Create(ClaimBtn, TweenInfo.new(0.15, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
				Size = Size2
			}):Play()
		end)
	end

	ClaimBtn.Activated:Connect(function() --[[ Line: 210 | Upvalues: pressButton (copy), closePopup (copy) ]]
		pressButton()
		task.delay(0.15, closePopup)
	end)
	CloseButton.Activated:Connect(closePopup)

	local function handleRewardPopup(p1) --[[ handleRewardPopup | Line: 216 | Upvalues: resolveCardInfo (ref), waitForPopupsClosed (ref), MainUI (copy), TextLabel (copy), RewardsContainer (copy), CardTemplate (copy), showPopup (copy), SFX (ref), animateCardAppear (ref) ]]
		if type(p1) ~= "table" then
			warn("[AdminRewardPopup] Invalid data received")

			return
		end

		if type(p1.Items) ~= "table" then
			warn("[AdminRewardPopup] Invalid data received")

			return
		end

		local t = {}

		for v1, v2 in p1.Items do
			local v3 = resolveCardInfo(v2)

			if v3 then
				table.insert(t, v3)
			end
		end

		if #t ~= 0 then
			task.spawn(function() --[[ Line: 233 | Upvalues: waitForPopupsClosed (ref), MainUI (ref), TextLabel (ref), p1 (copy), RewardsContainer (ref), t (copy), CardTemplate (ref), showPopup (ref), SFX (ref), animateCardAppear (ref) ]]
				waitForPopupsClosed(MainUI)
				TextLabel.Text = if type(p1.Message) == "string" and p1.Message ~= "" then p1.Message else "An admin sent you a gift!"

				for v3, v4 in RewardsContainer:GetChildren() do
					if v4:IsA("Frame") and v4.Name ~= "CardTemplate" then
						v4:Destroy()
					end
				end

				local t2 = {}

				for v5, v6 in t do
					local v7 = CardTemplate:Clone()

					v7.Name = "Card" .. v5
					v7.LayoutOrder = v5
					v7.Visible = false

					local Container = v7:FindFirstChild("Container")

					if Container then
						local Icon = Container:FindFirstChild("Icon")

						if Icon then
							Icon.Image = v6.Image
						end

						local RewardName = Container:FindFirstChild("RewardName")

						if RewardName then
							RewardName.Text = v6.Label
						end

						local RewardAmount = Container:FindFirstChild("RewardAmount")

						if RewardAmount then
							RewardAmount.Text = if v6.Amount > 1 then "x" .. v6.Amount else ""
						end

						v7.Parent = RewardsContainer
						table.insert(t2, v7)

						continue
					end

					warn("[AdminRewardPopup] CardTemplate missing Container")
				end

				showPopup()
				SFX.PlaySoundWithRandomPitch(SFX.Sounds.EggReward, 0.8, 0.95, 1.05)

				for v9, v10 in t2 do
					animateCardAppear(v10, (v9 - 1) * 0.12)
				end
			end)
		end
	end

	Remotes.AdminRewardPopup:On(handleRewardPopup)
	Remotes.AdminRewardPopupReady:Fire()
end

return t