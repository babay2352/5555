-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local FishRodConfig = require(ReplicatedStorage.shared.config.FishRodConfig)
local FishingRodShop = require(ReplicatedStorage.shared.UECS.Components.FishingRodShop)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Remotes = require(ReplicatedStorage.shared.Remotes)
local SFX = require(ReplicatedStorage.client.SFX)
local createConfigShop = require(ReplicatedStorage.shared.util.createConfigShop)

return {
	UECS = nil,
	Init = function(p1) --[[ Init | Line: 14 | Upvalues: Players (copy), createConfigShop (copy), FishingRodShop (copy), FishRodConfig (copy), Remotes (copy), ClientPlayerData (copy), SFX (copy) ]]
		createConfigShop({
			equippedField = "fishRod",
			keepOwnedInShop = true,
			inspectType = "FishingRod",
			inspectAttribute = "FishRod",
			inspectRequiresEnchants = true,
			shop = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI").FishingRodShop,
			shopComponent = FishingRodShop,
			config = FishRodConfig,
			buyRemote = Remotes.BuyFishRod,
			equipRemote = Remotes.EquipFishRod,
			uecs = p1.UECS,
			statFormatter = function(p1) --[[ statFormatter | Line: 29 ]]
				return "x" .. p1.LuckMultiplier .. " Luck"
			end
		})
		ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 34 ]]
			return p1.inventory
		end, function(p1, p2) --[[ Line: 36 | Upvalues: SFX (ref) ]]
			if type(p1) ~= "table" then
				return
			end

			local v2 = if p2 then p2 else {}

			for v3, v4 in p1 do
				if v4.Category == "FishRod" and not v2[v3] then
					SFX.new(SFX.Sounds.Buy, 0.5)

					return
				end
			end
		end)
	end
}