-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
game:GetService("Players")

local ReplicatedStorage = game:GetService("ReplicatedStorage")

game:GetService("StarterGui")
game:GetService("TweenService")

local CashDisplay = require(ReplicatedStorage.shared.module.CashDisplay)

require(ReplicatedStorage.client.ClientPlayerData)
require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Players = game:GetService("Players")
local ProximityPromptService = game:GetService("ProximityPromptService")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")
local Base = ReplicatedStorage.shared.model.Tycoon.Base
local t = {
	UECS = nil
}

local function sz(p1) --[[ sz | Line: 22 ]]
	return math.round(p1 * 1.5)
end

local UIStroke = Instance.new("UIStroke")

UIStroke.StrokeSizingMode = Enum.StrokeSizingMode.FixedSize
UIStroke.Thickness = 3
function t.Init(p1) --[[ Init | Line: 30 | Upvalues: Players (copy), TweenService (copy), UIStroke (copy), UserInputService (copy), CashDisplay (copy), RunService (copy), ProximityPromptService (copy) ]]
	local LocalPlayer = Players.LocalPlayer

	while LocalPlayer == nil do
		Players.ChildAdded:wait()
		LocalPlayer = Players.LocalPlayer
	end

	local PlayerGui = LocalPlayer:WaitForChild("PlayerGui")
	local t = {
		[Enum.KeyCode.Backspace] = "rbxasset://textures/ui/Controls/backspace.png",
		[Enum.KeyCode.Return] = "rbxasset://textures/ui/Controls/return.png",
		[Enum.KeyCode.LeftShift] = "rbxasset://textures/ui/Controls/shift.png",
		[Enum.KeyCode.RightShift] = "rbxasset://textures/ui/Controls/shift.png",
		[Enum.KeyCode.Tab] = "rbxasset://textures/ui/Controls/tab.png"
	}
	local t2 = {
		["\'"] = "rbxasset://textures/ui/Controls/apostrophe.png",
		[","] = "rbxasset://textures/ui/Controls/comma.png",
		["`"] = "rbxasset://textures/ui/Controls/graveaccent.png",
		["."] = "rbxasset://textures/ui/Controls/period.png",
		[" "] = "rbxasset://textures/ui/Controls/spacebar.png"
	}
	local t3 = {
		[Enum.KeyCode.LeftControl] = "Ctrl",
		[Enum.KeyCode.RightControl] = "Ctrl",
		[Enum.KeyCode.LeftAlt] = "Alt",
		[Enum.KeyCode.RightAlt] = "Alt",
		[Enum.KeyCode.F1] = "F1",
		[Enum.KeyCode.F2] = "F2",
		[Enum.KeyCode.F3] = "F3",
		[Enum.KeyCode.F4] = "F4",
		[Enum.KeyCode.F5] = "F5",
		[Enum.KeyCode.F6] = "F6",
		[Enum.KeyCode.F7] = "F7",
		[Enum.KeyCode.F8] = "F8",
		[Enum.KeyCode.F9] = "F9",
		[Enum.KeyCode.F10] = "F10",
		[Enum.KeyCode.F11] = "F11",
		[Enum.KeyCode.F12] = "F12",
		[Enum.KeyCode.PageUp] = "PgUp",
		[Enum.KeyCode.PageDown] = "PgDn",
		[Enum.KeyCode.Home] = "Home",
		[Enum.KeyCode.End] = "End",
		[Enum.KeyCode.Insert] = "Ins",
		[Enum.KeyCode.Delete] = "Del"
	}
	local t4 = {
		[Enum.KeyCode.LeftControl] = 18,
		[Enum.KeyCode.RightControl] = 18,
		[Enum.KeyCode.LeftAlt] = 18,
		[Enum.KeyCode.RightAlt] = 18,
		[Enum.KeyCode.F10] = 18,
		[Enum.KeyCode.F11] = 18,
		[Enum.KeyCode.F12] = 18,
		[Enum.KeyCode.PageUp] = 12,
		[Enum.KeyCode.PageDown] = 12,
		[Enum.KeyCode.Home] = 12,
		[Enum.KeyCode.End] = 15,
		[Enum.KeyCode.Insert] = 15,
		[Enum.KeyCode.Delete] = 15
	}
	local v1 = Color3.new(0.07, 0.07, 0.07)
	local v2 = Color3.new(255/255, 255/255, 255/255)
	local v3 = Color3.new(0.7, 0.7, 0.7)
	local v4 = TweenInfo.new(0.06, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)
	local v5 = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	local v6 = TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	local v7 = TweenInfo.new(0.5, Enum.EasingStyle.Bounce, Enum.EasingDirection.Out)
	local v8 = TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.In)

	local function getScreenGui() --[[ getScreenGui | Line: 112 | Upvalues: PlayerGui (copy) ]]
		local ProximityPrompts = PlayerGui:FindFirstChild("ProximityPrompts")

		if ProximityPrompts == nil then
			local ProximityPrompts2 = Instance.new("ScreenGui")

			ProximityPrompts2.Name = "ProximityPrompts"
			ProximityPrompts2.ResetOnSpawn = false
			ProximityPrompts2.Parent = PlayerGui
			ProximityPrompts2.IgnoreGuiInset = true
			ProximityPrompts = ProximityPrompts2
		end

		return ProximityPrompts
	end

	local function createProgressBarGradient(p1, p2, p3, p4) --[[ createProgressBarGradient | Line: 125 | Upvalues: TweenService (ref), v4 (copy) ]]
		local Frame = Instance.new("Frame")

		Frame.Size = UDim2.fromScale(0.5, 1)
		Frame.Position = UDim2.fromScale(if p2 then 0 else 0.5, 0)
		Frame.BackgroundTransparency = 1
		Frame.ClipsDescendants = true
		Frame.Visible = false
		Frame.Parent = p1

		local ImageLabel = Instance.new("ImageLabel")

		ImageLabel.BackgroundTransparency = 1
		ImageLabel.Size = UDim2.fromScale(2, 1)
		ImageLabel.Position = UDim2.fromScale(if p2 then 0 else -1, 0)
		ImageLabel.Image = "rbxasset://textures/ui/Controls/RadialFill.png"
		ImageLabel.Parent = Frame

		local UIGradient = Instance.new("UIGradient")

		UIGradient.Transparency = NumberSequence.new({
			NumberSequenceKeypoint.new(0, 0),
			NumberSequenceKeypoint.new(0.5, 0),
			NumberSequenceKeypoint.new(0.51, 1),
			NumberSequenceKeypoint.new(1, 1)
		})
		UIGradient.Rotation = if p2 then 180 else 0
		UIGradient.Parent = ImageLabel
		table.insert(p3, TweenService:Create(ImageLabel, v4, {
			ImageTransparency = 1
		}))
		table.insert(p4, TweenService:Create(ImageLabel, v4, {
			ImageTransparency = 0
		}))

		return UIGradient, Frame
	end

	local function createCircularProgressBar(p1, p2) --[[ createCircularProgressBar | Line: 157 | Upvalues: createProgressBarGradient (copy) ]]
		local CircularProgressBar = Instance.new("Frame")

		CircularProgressBar.Name = "CircularProgressBar"
		CircularProgressBar.Size = UDim2.fromOffset(87, 87)
		CircularProgressBar.AnchorPoint = Vector2.new(0.5, 0.5)
		CircularProgressBar.Position = UDim2.fromScale(0.5, 0.5)
		CircularProgressBar.BackgroundTransparency = 1

		local v1, v2 = createProgressBarGradient(CircularProgressBar, true, p1, p2)
		local v3, v4 = createProgressBarGradient(CircularProgressBar, false, p1, p2)
		local Progress = Instance.new("NumberValue")

		Progress.Name = "Progress"
		Progress.Parent = CircularProgressBar
		Progress.Changed:Connect(function(p1) --[[ Line: 171 | Upvalues: v2 (copy), Progress (copy), v1 (copy), v4 (copy), v3 (copy) ]]
			local v12 = math.clamp(p1 * 360, 0, 360)

			v2.Visible = Progress.Value > 0.5
			v1.Rotation = math.clamp(v12, 180, 360)
			v4.Visible = Progress.Value > 0.01
			v3.Rotation = math.clamp(v12, 0, 180)
		end)

		return CircularProgressBar
	end

	local function createPrompt(p1, p2, p3) --[[ createPrompt | Line: 182 | Upvalues: v1 (copy), TweenService (ref), v7 (copy), v8 (copy), v6 (copy), UIStroke (ref), v2 (copy), v3 (copy), v4 (copy), UserInputService (ref), t (copy), t2 (copy), t3 (copy), t4 (copy), createCircularProgressBar (copy), v5 (copy), CashDisplay (ref), RunService (ref) ]]
		local t5 = {}
		local t6 = {}
		local t7 = {}
		local list = {}
		local v12 = TweenInfo.new(p1.HoldDuration, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)
		local Prompt = Instance.new("BillboardGui")

		Prompt.Name = "Prompt"
		Prompt.AlwaysOnTop = true

		local Frame = Instance.new("Frame")

		Frame.Size = UDim2.fromScale(0.5, 1)
		Frame.BackgroundTransparency = 1
		Frame.BackgroundColor3 = v1
		Frame.AnchorPoint = Vector2.new(0.5, 0)
		Frame.Position = UDim2.fromScale(0.5, 0)
		Frame.Size = UDim2.fromScale(0, 1)
		Frame.AutomaticSize = Enum.AutomaticSize.X
		Frame.Rotation = -20
		Frame.Parent = Prompt

		local UIScale = Instance.new("UIScale")

		UIScale.Scale = 1
		UIScale.Parent = Frame
		table.insert(list, TweenService:Create(Frame, v7, {
			Rotation = 0
		}))
		table.insert(list, TweenService:Create(UIScale, v7, {
			Scale = 1
		}))
		table.insert(t7, TweenService:Create(UIScale, v8, {
			Scale = 0.3
		}))

		local UIPadding = Instance.new("UIPadding")

		UIPadding.Parent = Frame
		Instance.new("UICorner").Parent = Frame

		local InputFrame = Instance.new("Frame")

		InputFrame.Name = "InputFrame"
		InputFrame.Size = UDim2.fromScale(1, 1)
		InputFrame.BackgroundTransparency = 1
		InputFrame.SizeConstraint = Enum.SizeConstraint.RelativeYY
		InputFrame.Parent = Frame

		local Frame2 = Instance.new("Frame")

		Frame2.Size = UDim2.fromScale(1, 1)
		Frame2.Position = UDim2.fromScale(0.5, 0.5)
		Frame2.AnchorPoint = Vector2.new(0.5, 0.5)
		Frame2.BackgroundTransparency = 1
		Frame2.Parent = InputFrame

		local UIScale2 = Instance.new("UIScale")

		UIScale2.Parent = Frame2
		table.insert(t5, TweenService:Create(UIScale2, v6, {
			Scale = if p2 == Enum.ProximityPromptInputType.Touch then 1.6 else 1.33
		}))
		table.insert(t6, TweenService:Create(UIScale2, v6, {
			Scale = 1
		}))

		local v13 = UIStroke:Clone()
		local ActionText = Instance.new("TextLabel")

		ActionText.Name = "ActionText"
		ActionText.Font = Enum.Font.GothamBlack
		v13.Parent = ActionText
		ActionText.TextSize = 29
		ActionText.BackgroundTransparency = 1
		ActionText.TextTransparency = 1
		ActionText.TextColor3 = v2
		ActionText.TextXAlignment = Enum.TextXAlignment.Left
		ActionText.TextTransparency = 0

		local v14 = UIStroke:Clone()
		local ObjectText = Instance.new("TextLabel")

		v14.Parent = ObjectText
		ObjectText.Name = "ObjectText"
		ObjectText.Font = Enum.Font.GothamBold
		ObjectText.TextSize = 21
		ObjectText.BackgroundTransparency = 1
		ObjectText.TextTransparency = 1
		ObjectText.TextColor3 = v3
		ObjectText.TextXAlignment = Enum.TextXAlignment.Left

		local UIListLayout = Instance.new("UIListLayout")

		UIListLayout.FillDirection = Enum.FillDirection.Horizontal
		UIListLayout.Padding = UDim.new(-0.25, 0)
		UIListLayout.Parent = Frame
		table.insert(t5, TweenService:Create(UIListLayout, v6, {
			Padding = UDim.new(-0.25, 0)
		}))
		table.insert(t6, TweenService:Create(UIListLayout, v6, {
			Padding = UDim.new(0, 0)
		}))
		table.insert(t7, TweenService:Create(UIListLayout, v6, {
			Padding = UDim.new(-0.25, 0)
		}))
		table.insert(list, TweenService:Create(UIListLayout, v6, {
			Padding = UDim.new(0, 0)
		}))

		local TextFrame = Instance.new("Frame")

		TextFrame.Name = "TextFrame"
		TextFrame.Size = UDim2.fromScale(0, 1)
		TextFrame.AutomaticSize = Enum.AutomaticSize.X
		TextFrame.BackgroundTransparency = 1
		TextFrame.Parent = Frame
		ActionText.Size = UDim2.fromScale(0, 1)
		ActionText.AutomaticSize = Enum.AutomaticSize.X
		ActionText.Parent = TextFrame
		ObjectText.Size = UDim2.fromScale(0, 1)
		ObjectText.AutomaticSize = Enum.AutomaticSize.X
		ObjectText.Parent = TextFrame
		table.insert(t5, TweenService:Create(ObjectText, v6, {
			TextTransparency = 1
		}))
		table.insert(t6, TweenService:Create(ObjectText, v6, {
			TextTransparency = 0
		}))
		table.insert(t7, TweenService:Create(ObjectText, v6, {
			TextTransparency = 1
		}))
		table.insert(list, TweenService:Create(ObjectText, v6, {
			TextTransparency = 0
		}))
		table.insert(t5, TweenService:Create(Frame, v6, {
			BackgroundTransparency = 1
		}))
		table.insert(t6, TweenService:Create(Frame, v6, {
			BackgroundTransparency = 0.2
		}))
		table.insert(t7, TweenService:Create(Frame, v6, {
			BackgroundTransparency = 1
		}))

		local RoundFrame = Instance.new("Frame")

		RoundFrame.Name = "RoundFrame"
		RoundFrame.Size = UDim2.fromOffset(72, 72)
		RoundFrame.AnchorPoint = Vector2.new(0.5, 0.5)
		RoundFrame.Position = UDim2.fromScale(0.5, 0.5)
		RoundFrame.BackgroundTransparency = 1
		RoundFrame.Parent = Frame2
		RoundFrame.BackgroundColor3 = Color3.fromRGB(0, 0, 0)

		local UICorner = Instance.new("UICorner")

		UICorner.CornerRadius = UDim.new(0.5, 0)
		UICorner.Parent = RoundFrame
		table.insert(t7, TweenService:Create(RoundFrame, v4, {
			BackgroundTransparency = 1
		}))
		table.insert(list, TweenService:Create(RoundFrame, v4, {
			BackgroundTransparency = 0.5
		}))

		if p2 == Enum.ProximityPromptInputType.Gamepad then
			local v41 = UserInputService:GetImageForKeyCode(p1.GamepadKeyCode)

			if v41 then
				local ButtonImage = Instance.new("ImageLabel")

				ButtonImage.Name = "ButtonImage"
				ButtonImage.AnchorPoint = Vector2.new(0.5, 0.5)
				ButtonImage.Size = UDim2.fromOffset(36, 36)
				ButtonImage.Position = UDim2.fromScale(0.5, 0.5)
				ButtonImage.BackgroundTransparency = 1
				ButtonImage.ImageTransparency = 1
				ButtonImage.Image = v41
				ButtonImage.Parent = Frame2
				table.insert(t7, TweenService:Create(ButtonImage, v4, {
					ImageTransparency = 1
				}))
				table.insert(list, TweenService:Create(ButtonImage, v4, {
					ImageTransparency = 0
				}))
			end
		elseif p2 == Enum.ProximityPromptInputType.Touch then
			local ButtonImage = Instance.new("ImageLabel")

			ButtonImage.Name = "ButtonImage"
			ButtonImage.BackgroundTransparency = 1
			ButtonImage.ImageTransparency = 1
			ButtonImage.Size = UDim2.fromOffset(38, 47)
			ButtonImage.AnchorPoint = Vector2.new(0.5, 0.5)
			ButtonImage.Position = UDim2.fromScale(0.5, 0.5)
			ButtonImage.Image = "rbxasset://textures/ui/Controls/TouchTapIcon.png"
			ButtonImage.Parent = Frame2
			table.insert(t7, TweenService:Create(ButtonImage, v4, {
				ImageTransparency = 1
			}))
			table.insert(list, TweenService:Create(ButtonImage, v4, {
				ImageTransparency = 0
			}))
		else
			local ButtonImage = Instance.new("ImageLabel")

			ButtonImage.Name = "ButtonImage"
			ButtonImage.BackgroundTransparency = 1
			ButtonImage.ImageTransparency = 1
			ButtonImage.Size = UDim2.fromOffset(42, 45)
			ButtonImage.AnchorPoint = Vector2.new(0.5, 0.5)
			ButtonImage.Position = UDim2.fromScale(0.5, 0.5)
			ButtonImage.Image = "rbxasset://textures/ui/Controls/key_single.png"
			ButtonImage.Parent = Frame2
			table.insert(t7, TweenService:Create(ButtonImage, v4, {
				ImageTransparency = 1
			}))
			table.insert(list, TweenService:Create(ButtonImage, v4, {
				ImageTransparency = 0
			}))

			local v54 = UserInputService:GetStringForKeyCode(p1.KeyboardKeyCode)
			local v55 = t[p1.KeyboardKeyCode]

			if v55 == nil then
				v55 = t2[v54]
			end

			if v55 == nil then
				local v56 = t3[p1.KeyboardKeyCode]

				if v56 then
					v54 = v56
				end
			end

			if v55 then
				local ButtonImage2 = Instance.new("ImageLabel")

				ButtonImage2.Name = "ButtonImage"
				ButtonImage2.AnchorPoint = Vector2.new(0.5, 0.5)
				ButtonImage2.Size = UDim2.fromOffset(54, 54)
				ButtonImage2.Position = UDim2.fromScale(0.5, 0.5)
				ButtonImage2.BackgroundTransparency = 1
				ButtonImage2.ImageTransparency = 1
				ButtonImage2.Image = v55
				ButtonImage2.Parent = Frame2
				table.insert(t7, TweenService:Create(ButtonImage2, v4, {
					ImageTransparency = 1
				}))
				table.insert(list, TweenService:Create(ButtonImage2, v4, {
					ImageTransparency = 0
				}))
			else
				if v54 == nil or v54 == "" then
					error("ProximityPrompt \'" .. p1.Name .. "\' has an unsupported keycode for rendering UI: " .. tostring(p1.KeyboardKeyCode))
				end

				local ButtonText = Instance.new("TextLabel")

				ButtonText.Name = "ButtonText"
				ButtonText.AutoLocalize = false
				ButtonText.Position = UDim2.fromOffset(0, -1)
				ButtonText.Size = UDim2.fromScale(1, 1)
				ButtonText.Font = Enum.Font.GothamBlack

				local v63 = t4[p1.KeyboardKeyCode]

				if v63 == nil then
					v63 = 21
				end

				ButtonText.TextSize = v63
				ButtonText.BackgroundTransparency = 1
				ButtonText.TextTransparency = 1
				ButtonText.TextColor3 = v2
				ButtonText.TextXAlignment = Enum.TextXAlignment.Center
				ButtonText.Text = v54
				ButtonText.Parent = Frame2
				table.insert(t7, TweenService:Create(ButtonText, v4, {
					TextTransparency = 1
				}))
				table.insert(list, TweenService:Create(ButtonText, v4, {
					TextTransparency = 0
				}))
			end
		end

		if p2 == Enum.ProximityPromptInputType.Touch or p1.ClickablePrompt then
			local TextButton = Instance.new("TextButton")

			TextButton.BackgroundTransparency = 1
			TextButton.TextTransparency = 1
			TextButton.Size = UDim2.fromScale(1, 1)
			TextButton.Parent = Prompt
			TextButton.Selectable = false

			local v68 = false

			TextButton.InputBegan:Connect(function(p12) --[[ Line: 456 | Upvalues: p1 (copy), v68 (ref) ]]
				if p12.UserInputType ~= Enum.UserInputType.Touch and p12.UserInputType ~= Enum.UserInputType.MouseButton1 then
					return
				end

				if p12.UserInputState == Enum.UserInputState.Change then
					return
				end

				p1:InputHoldBegin()
				v68 = true
			end)
			TextButton.InputEnded:Connect(function(p12) --[[ Line: 467 | Upvalues: v68 (ref), p1 (copy) ]]
				if p12.UserInputType ~= Enum.UserInputType.Touch and p12.UserInputType ~= Enum.UserInputType.MouseButton1 or not v68 then
					return
				end

				v68 = false
				p1:InputHoldEnd()
			end)
			Prompt.Active = true
		end

		if p1.HoldDuration > 0 then
			local v69 = createCircularProgressBar(t7, list)

			v69.Parent = Frame2
			table.insert(t5, TweenService:Create(v69.Progress, v12, {
				Value = 1
			}))
			table.insert(t6, TweenService:Create(v69.Progress, v5, {
				Value = 0
			}))
		end

		local v73, v74

		if p1.HoldDuration > 0 then
			v73 = p1.PromptButtonHoldBegan:Connect(function() --[[ Line: 501 | Upvalues: t5 (copy) ]]
				for i, v in ipairs(t5) do
					v:Play()
				end
			end)
			v74 = p1.PromptButtonHoldEnded:Connect(function() --[[ Line: 507 | Upvalues: t6 (copy) ]]
				for i, v in ipairs(t6) do
					v:Play()
				end
			end)
		else
			v73 = nil
			v74 = nil
		end

		local v75 = p1.Triggered:Connect(function() --[[ Line: 514 | Upvalues: p1 (copy), t7 (copy) ]]
			if p1:HasTag("NoFade") then
				return
			end

			for i, v in ipairs(t7) do
				v:Play()
			end
		end)
		local v76 = p1.TriggerEnded:Connect(function() --[[ Line: 523 | Upvalues: p1 (copy), list (copy) ]]
			if p1:HasTag("NoFade") then
				return
			end

			for i, v in ipairs(list) do
				v:Play()
			end
		end)

		local function updateUIFromPrompt() --[[ updateUIFromPrompt | Line: 532 | Upvalues: p1 (copy), CashDisplay (ref), ActionText (copy), ObjectText (copy), UIPadding (copy), Prompt (copy), RunService (ref), Frame (copy) ]]
			local v1 = 108
			local v2 = 108
			local v3 = 36
			local v4 = if p1.ObjectText == nil or p1.ObjectText == "" then 0 else 14

			CashDisplay.applyTokens(ActionText, p1.ActionText, {
				Compact = true
			})
			ObjectText.Text = p1.ObjectText
			ActionText.AutoLocalize = p1.AutoLocalize
			ActionText.RootLocalizationTable = p1.RootLocalizationTable
			ObjectText.AutoLocalize = p1.AutoLocalize
			ObjectText.RootLocalizationTable = p1.RootLocalizationTable

			if (p1.ActionText == nil or p1.ActionText == "") and (p1.ObjectText == nil or p1.ObjectText == "") then
				UIPadding.PaddingRight = UDim.new(0, 0)
			else
				UIPadding.PaddingRight = UDim.new(0, v3 - v4)
			end

			ActionText.Position = UDim2.new(0, 0, 0, v4)
			ObjectText.Position = UDim2.new(0, 0, 0, -15)
			Prompt.Size = UDim2.fromOffset(v2, v1)
			Prompt.SizeOffset = Vector2.new(p1.UIOffset.X / Prompt.Size.Width.Offset, p1.UIOffset.Y / Prompt.Size.Height.Offset)
			task.defer(function() --[[ Line: 573 | Upvalues: RunService (ref), v2 (ref), Frame (ref), Prompt (ref), v1 (copy), p1 (ref) ]]
				RunService.RenderStepped:Wait()
				RunService.RenderStepped:Wait()
				v2 = Frame.AbsoluteSize.X
				Prompt.Size = UDim2.fromOffset(v2, v1)
				Prompt.SizeOffset = Vector2.new(p1.UIOffset.X / Prompt.Size.Width.Offset, p1.UIOffset.Y / Prompt.Size.Height.Offset)
			end)
		end

		local v77 = p1.Changed:Connect(updateUIFromPrompt)

		updateUIFromPrompt()
		Prompt.Adornee = p1.Parent
		Prompt.Parent = p3

		local function updateUIAncestry() --[[ updateUIAncestry | Line: 593 | Upvalues: Prompt (copy), p1 (copy) ]]
			Prompt.Adornee = p1.Parent
		end

		local v78 = p1.AncestryChanged:Connect(updateUIAncestry)

		for i, v in ipairs(list) do
			v:Play()
		end

		return function() --[[ cleanup | Line: 602 | Upvalues: v73 (ref), v74 (ref), v75 (ref), v76 (ref), v77 (copy), v78 (copy), t7 (copy), Prompt (copy) ]]
			if v73 then
				v73:Disconnect()
			end

			if v74 then
				v74:Disconnect()
			end

			v75:Disconnect()
			v76:Disconnect()
			v77:Disconnect()
			v78:Disconnect()

			for i, v in ipairs(t7) do
				v:Play()
			end

			wait(0.2)
			Prompt.Parent = nil
		end
	end

	local function createIndicator(p1, p2) --[[ createIndicator | Line: 628 | Upvalues: v1 (copy), v2 (copy), TweenService (ref), v4 (copy) ]]
		local t = {}
		local list = {}
		local Indicator = Instance.new("BillboardGui")

		Indicator.Name = "Indicator"
		Indicator.Size = UDim2.fromOffset(23, 23)
		Indicator.AlwaysOnTop = true

		local Frame = Instance.new("Frame")

		Frame.Size = UDim2.fromScale(1, 1)
		Frame.BackgroundTransparency = 1
		Frame.BackgroundColor3 = v1
		Frame.AnchorPoint = Vector2.new(0.5, 0)
		Frame.Position = UDim2.fromScale(0.5, 0)
		Frame.Parent = Indicator

		local UICorner = Instance.new("UICorner")

		UICorner.CornerRadius = UDim.new(1, 0)
		UICorner.Parent = Frame

		local UIStroke = Instance.new("UIStroke")

		UIStroke.Color = v2
		UIStroke.Thickness = 2
		UIStroke.Transparency = 1
		UIStroke.Parent = Frame
		table.insert(t, TweenService:Create(UIStroke, v4, {
			Transparency = 1
		}))
		table.insert(list, TweenService:Create(UIStroke, v4, {
			Transparency = 0.2
		}))
		Indicator.Adornee = p1.Parent
		Indicator.Parent = p2

		local function updateUIAncestry() --[[ updateUIAncestry | Line: 661 | Upvalues: Indicator (copy), p1 (copy) ]]
			Indicator.Adornee = p1.Parent
		end

		local v5 = p1.AncestryChanged:Connect(updateUIAncestry)

		for i, v in ipairs(list) do
			v:Play()
		end

		return function() --[[ cleanup | Line: 670 | Upvalues: v5 (copy), t (copy), Indicator (copy) ]]
			v5:Disconnect()

			for i, v in ipairs(t) do
				v:Play()
			end

			wait(0.2)
			Indicator.Parent = nil
		end
	end

	(function() --[[ onLoad | Line: 685 | Upvalues: ProximityPromptService (ref), PlayerGui (copy), createPrompt (copy), createIndicator (copy) ]]
		ProximityPromptService.PromptShown:Connect(function(p1, p2) --[[ Line: 686 | Upvalues: PlayerGui (ref), createPrompt (ref) ]]
			if p1.Style ~= Enum.ProximityPromptStyle.Custom then
				return
			end

			local ProximityPrompts = PlayerGui:FindFirstChild("ProximityPrompts")

			if ProximityPrompts == nil then
				local ProximityPrompts2 = Instance.new("ScreenGui")

				ProximityPrompts2.Name = "ProximityPrompts"
				ProximityPrompts2.ResetOnSpawn = false
				ProximityPrompts2.Parent = PlayerGui
				ProximityPrompts2.IgnoreGuiInset = true
				ProximityPrompts = ProximityPrompts2
			end

			local v1 = createPrompt(p1, p2, ProximityPrompts)
			local v2 = Instance.new("BindableEvent")
			local v3 = p1.PromptHidden:Connect(function() --[[ Line: 697 | Upvalues: v2 (copy) ]]
				v2:Fire()
			end)
			local v4 = p1.Destroying:Connect(function() --[[ Line: 700 | Upvalues: v2 (copy) ]]
				v2:Fire()
			end)

			v2.Event:Wait()
			v3:Disconnect()
			v4:Disconnect()
			v1()
		end)
		ProximityPromptService.IndicatorShown:Connect(function(p1) --[[ Line: 710 | Upvalues: PlayerGui (ref), createIndicator (ref) ]]
			if p1.Style ~= Enum.ProximityPromptStyle.Custom then
				return
			end

			local ProximityPrompts = PlayerGui:FindFirstChild("ProximityPrompts")

			if ProximityPrompts == nil then
				local ProximityPrompts2 = Instance.new("ScreenGui")

				ProximityPrompts2.Name = "ProximityPrompts"
				ProximityPrompts2.ResetOnSpawn = false
				ProximityPrompts2.Parent = PlayerGui
				ProximityPrompts2.IgnoreGuiInset = true
				ProximityPrompts = ProximityPrompts2
			end

			local v1 = createIndicator(p1, ProximityPrompts)
			local v2 = Instance.new("BindableEvent")
			local v3 = p1.IndicatorHidden:Connect(function() --[[ Line: 721 | Upvalues: v2 (copy) ]]
				v2:Fire()
			end)
			local v4 = p1.Destroying:Connect(function() --[[ Line: 724 | Upvalues: v2 (copy) ]]
				v2:Fire()
			end)

			v2.Event:Wait()
			v3:Disconnect()
			v4:Disconnect()
			v1()
		end)
	end)()
end

return t