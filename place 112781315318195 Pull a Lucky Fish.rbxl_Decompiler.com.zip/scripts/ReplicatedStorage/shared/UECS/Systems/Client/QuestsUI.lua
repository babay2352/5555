-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ContextActionService = game:GetService("ContextActionService")
local GamepadService = game:GetService("GamepadService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local QuestConfig = require(ReplicatedStorage.shared.config.QuestConfig)
local QuestView = require(ReplicatedStorage.shared.util.QuestView)
local QuestsUI = require(ReplicatedStorage.shared.UECS.Components.QuestsUI)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local bindToButtonPress = require(ReplicatedStorage.shared.util.bindToButtonPress)
local t = {
	UECS = nil
}
local t2 = {
	AlertWobbleAngle = 8,
	AlertWobbleTime = 0.5,
	BarTween = TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.Out),
	ClaimedColor = Color3.fromRGB(39, 188, 49)
}

local function tagButton(p1) --[[ tagButton | Line: 62 | Upvalues: CollectionService (copy) ]]
	CollectionService:AddTag(p1, "VFX_ClickBounce")
	CollectionService:AddTag(p1, "VFX_UIClickButton")
end

local function childrenNamed(p1, p2) --[[ childrenNamed | Line: 69 ]]
	local t = {}

	for v1, v2 in p1:GetChildren() do
		if v2.Name == p2 then
			table.insert(t, v2)
		end
	end

	return t
end

local function setBarFill(p1, p2) --[[ setBarFill | Line: 79 | Upvalues: TweenService (copy), t2 (copy) ]]
	if p1 then
		TweenService:Create(p1, t2.BarTween, {
			Size = UDim2.fromScale(math.clamp(p2, 0, 1), 1)
		}):Play()
	end
end

function t.Init(p1) --[[ Init | Line: 86 | Upvalues: ClientPlayerData (copy), Players (copy), QuestsUI (copy), bindToButtonPress (copy), GamepadService (copy), ContextActionService (copy), CollectionService (copy), QuestConfig (copy), QuestView (copy), Remotes (copy), childrenNamed (copy), t2 (copy), setBarFill (copy), TweenService (copy) ]]
	repeat
		task.wait()
	until ClientPlayerData.isPlayerDataLoaded

	local MainUI = Players.LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("MainUI")
	local Quests = MainUI:WaitForChild("Quests")

	Quests.Visible = false

	local TopBar = Quests:WaitForChild("TopBar")
	local CloseButton = TopBar:WaitForChild("CloseButton")
	local refresh = CloseButton:FindFirstChild("refresh")
	local v1 = Quests:WaitForChild("Content")
	local ScrollingFrame = v1:WaitForChild("ScrollingFrame")
	local QuestTemplate = ScrollingFrame:WaitForChild("QuestTemplate")

	QuestTemplate.Visible = false

	local HUD = MainUI:WaitForChild("HUD")
	local v2 = HUD:FindFirstChild("ButtonsRightSide") or HUD:FindFirstChild("Buttons")
	local v3 = if v2 then v2:FindFirstChild("Quest") else nil
	local v4 = if v3 then v3:FindFirstChild("Alert") else nil
	local v5 = nil
	local CollectBar = v1:FindFirstChild("CollectBar")
	local v6 = if CollectBar then CollectBar:FindFirstChild("Bar") else nil
	local v7 = if CollectBar then CollectBar:FindFirstChild("Counter") else nil
	local v8 = if CollectBar then CollectBar:FindFirstChild("NumberProgress") else nil
	local v9

	if v7 then
		v9 = v7:FindFirstChildWhichIsA("TextLabel")

		if v8 then
			v8.Visible = false
		end
	else
		v9 = v8
	end

	local function getState() --[[ getState | Line: 135 | Upvalues: ClientPlayerData (ref) ]]
		return ClientPlayerData.serverProfile:getState()
	end

	local v10 = QuestsUI.Add(Quests)

	local function close() --[[ close | Line: 143 | Upvalues: p1 (copy) ]]
		p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
	end

	local v11 = false

	v10.Visible.OnChange:Connect(function(p1, p2) --[[ Line: 149 | Upvalues: Quests (copy), v11 (ref), bindToButtonPress (ref), close (copy), GamepadService (ref), ContextActionService (ref) ]]
		Quests.Visible = p1
		v11 = p1

		if p1 == p2 then
			return
		end

		if p1 then
			bindToButtonPress("QuestsClose", Enum.KeyCode.ButtonB, close)
			GamepadService:EnableGamepadCursor(nil)
		else
			ContextActionService:UnbindAction("QuestsClose")
			GamepadService:DisableGamepadCursor()
		end
	end)
	CollectionService:AddTag(CloseButton, "VFX_ClickBounce")
	CollectionService:AddTag(CloseButton, "VFX_UIClickButton")
	CloseButton.MouseButton1Click:Connect(close)

	local GemsShop = TopBar:FindFirstChild("GemsShop", true)

	if GemsShop then
		CollectionService:AddTag(GemsShop, "VFX_ClickBounce")
		CollectionService:AddTag(GemsShop, "VFX_UIClickButton")
		GemsShop.MouseButton1Click:Connect(function() --[[ Line: 176 | Upvalues: p1 (copy) ]]
			p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(p1.UECS:WaitForAnyComponent("GemsShop"))
		end)
	end

	local Milestones = TopBar:FindFirstChild("Milestones", true)

	if Milestones then
		CollectionService:AddTag(Milestones, "VFX_ClickBounce")
		CollectionService:AddTag(Milestones, "VFX_UIClickButton")
		Milestones.MouseButton1Click:Connect(function() --[[ Line: 187 | Upvalues: p1 (copy) ]]
			p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(p1.UECS:WaitForAnyComponent("MilestonesUI"))
		end)
	end

	local t = {}

	local function bindMilestoneTiles() --[[ bindMilestoneTiles | Line: 215 | Upvalues: CollectBar (copy), t (copy), QuestConfig (ref), QuestView (ref), CollectionService (ref), getState (copy), Remotes (ref) ]]
		if not CollectBar then
			return
		end

		table.clear(t)

		local t2 = {}

		for v1, v2 in CollectBar:GetChildren() do
			if (v2.Name == "MilestoneReward" or v2.Name == "BigReward") and v2:IsA("GuiObject") then
				table.insert(t2, v2)
			end
		end

		table.sort(t2, function(p1, p2) --[[ Line: 227 ]]
			return p1.Position.X.Scale < p2.Position.X.Scale
		end)

		for v3, v4 in t2 do
			local v5 = QuestConfig.Milestones[v3]

			if v5 then
				v4.Visible = true

				local v6 = v5.Rewards[1]

				if v6 then
					local Icon = v4:FindFirstChild("Icon")

					if Icon then
						Icon.Image = QuestConfig.GetRewardIcon(v6)

						local Title = Icon:FindFirstChild("Title")

						if Title then
							Title.Text = QuestView.FormatRewardAmount(v6)
						end
					end
				end

				continue
			end

			v4.Visible = false
		end

		for v7, v8 in t2 do
			local ClaimReward = v8:FindFirstChild("ClaimReward")

			if ClaimReward then
				ClaimReward.Visible = false
				t[v7] = ClaimReward
				CollectionService:AddTag(ClaimReward, "VFX_ClickBounce")
				CollectionService:AddTag(ClaimReward, "VFX_UIClickButton")
				ClaimReward.MouseButton1Click:Connect(function() --[[ Line: 265 | Upvalues: QuestView (ref), getState (ref), v7 (copy), Remotes (ref) ]]
					if QuestView.ClaimableMilestone(getState()) == v7 then
						Remotes.RequestClaimQuestMilestone:Fire(v7)
					end
				end)
			end
		end

		if not (#t2 < #QuestConfig.Milestones) then
			return
		end

		warn(("[QuestsUI] %* milestones configured but only %* tiles "):format(#QuestConfig.Milestones, #t2) .. "in CollectBar \226\128\148 add MilestoneReward frames for the rest")
	end

	local t3 = {}

	local function bindCard(p1, p2) --[[ bindCard | Line: 302 | Upvalues: CollectionService (ref), QuestView (ref), ClientPlayerData (ref), Remotes (ref) ]]
		local Button = p2.Button

		if Button then
			CollectionService:AddTag(Button, "VFX_ClickBounce")
			CollectionService:AddTag(Button, "VFX_UIClickButton")
			Button.MouseButton1Click:Connect(function() --[[ Line: 308 | Upvalues: QuestView (ref), ClientPlayerData (ref), p1 (copy), Remotes (ref) ]]
				local v1 = QuestView.FindActive(ClientPlayerData.serverProfile:getState(), p1)

				if not v1 or v1.Claimed then
					return
				end

				if v1.Done then
					Remotes.RequestClaimQuest:Fire(p1)
				else
					Remotes.RequestSkipQuest:Fire(p1)
				end
			end)
		end
	end

	local function buildCard(p1) --[[ buildCard | Line: 324 | Upvalues: QuestTemplate (copy), childrenNamed (ref), QuestConfig (ref), QuestView (ref), ScrollingFrame (copy), CollectionService (ref), ClientPlayerData (ref), Remotes (ref) ]]
		local v1 = QuestTemplate:Clone()

		v1.Name = p1.Def.Id
		v1.Visible = true

		local Bar = v1:FindFirstChild("Bar")
		local RightSideFrame = v1:FindFirstChild("RightSideFrame")
		local v2 = if RightSideFrame then RightSideFrame:FindFirstChild("SkipOrClaimButton") else nil
		local v3 = if v2 then v2:FindFirstChild("Price", true) else nil
		local t = {}

		if RightSideFrame then
			for v4, v5 in childrenNamed(RightSideFrame, "RewardFrame") do
				table.insert(t, v5)
			end
		end

		local Frame = v1:FindFirstChild("Frame")
		local t2 = {
			Root = v1,
			Background = Frame
		}

		t2.BaseColor = if Frame then Frame.BackgroundColor3 else Color3.new(255/255, 255/255, 255/255)
		t2.Title = v1:FindFirstChild("Title")
		t2.Difficulty = v1:FindFirstChild("Difficulty")
		t2.Fill = if Bar then Bar:FindFirstChild("Filler") else nil
		t2.Progress = if Bar then Bar:FindFirstChild("NumberProgress") else nil
		t2.Button = v2
		t2.ButtonLabel = v3
		t2.Rewards = t

		for v9, v10 in t do
			local v11 = p1.Rewards[v9]

			if v11 then
				v10.Visible = true

				local Icon = v10:FindFirstChild("Icon")

				if Icon then
					Icon.Image = QuestConfig.GetRewardIcon(v11)

					local Title = Icon:FindFirstChild("Title")

					if Title then
						Title.Text = QuestView.FormatRewardAmount(v11)
					end
				end

				continue
			end

			v10.Visible = false
		end

		if t2.Title then
			t2.Title.Text = p1.Def.DisplayText
		end

		if t2.Difficulty then
			local v12 = QuestConfig.Difficulties[p1.Def.Difficulty]

			if v12 then
				t2.Difficulty.Text = v12.DisplayName
				t2.Difficulty.TextColor3 = v12.Color
			end
		end

		v1.Parent = ScrollingFrame

		local Id = p1.Def.Id
		local Button = t2.Button

		if Button then
			CollectionService:AddTag(Button, "VFX_ClickBounce")
			CollectionService:AddTag(Button, "VFX_UIClickButton")
			Button.MouseButton1Click:Connect(function() --[[ Line: 308 | Upvalues: QuestView (ref), ClientPlayerData (ref), Id (copy), Remotes (ref) ]]
				local v1 = QuestView.FindActive(ClientPlayerData.serverProfile:getState(), Id)

				if not v1 or v1.Claimed then
					return
				end

				if v1.Done then
					Remotes.RequestClaimQuest:Fire(Id)
				else
					Remotes.RequestSkipQuest:Fire(Id)
				end
			end)
		end

		return t2
	end

	local function refreshCard(p1, p2, p3) --[[ refreshCard | Line: 396 | Upvalues: t2 (ref), QuestView (ref), setBarFill (ref) ]]
		local v2 = math.min(if p3 then p3 else p2.Progress, p2.Def.Goal)

		if p1.Background then
			p1.Background.BackgroundColor3 = if p2.Claimed then t2.ClaimedColor else p1.BaseColor
		end

		if p1.Progress then
			p1.Progress.Text = QuestView.FormatProgress(p2.Def, v2)
		end

		setBarFill(p1.Fill, QuestView.ProgressFraction(p2.Def, v2))

		local Button = p1.Button

		if not Button then
			return
		end

		Button.Visible = true

		if not p1.ButtonLabel then
			return
		end

		p1.ButtonLabel.Text = if p2.Claimed then "Claimed" elseif p2.Done then "Claim!" else "Skip!"
	end

	local function rebuildCards() --[[ rebuildCards | Line: 423 | Upvalues: t3 (copy), QuestView (ref), getState (copy), buildCard (copy), refreshCard (copy) ]]
		for v1, v2 in t3 do
			v2.Root:Destroy()
		end

		table.clear(t3)

		for v3, v4 in QuestView.GetActive(getState()) do
			local v5 = buildCard(v4)

			v5.Root.LayoutOrder = math.min(v3, 9998)
			refreshCard(v5, v4)
			t3[v4.Def.Id] = v5
		end
	end

	local function refreshClaimButtons() --[[ refreshClaimButtons | Line: 440 | Upvalues: QuestView (ref), getState (copy), t (copy) ]]
		local v1 = QuestView.ClaimableMilestone(getState())

		for v2, v3 in t do
			v3.Visible = v2 == v1
		end
	end

	local function refreshTrack() --[[ refreshTrack | Line: 447 | Upvalues: QuestView (ref), getState (copy), setBarFill (ref), v6 (copy), v9 (ref), t (copy) ]]
		local v1 = QuestView.GetTrack(getState())

		setBarFill(v6, v1.Fraction)

		if v9 then
			v9.Text = ("%*/%*"):format(v1.SegmentDone, v1.SegmentGoal)
		end

		local v2 = QuestView.ClaimableMilestone(getState())

		for v3, v4 in t do
			v4.Visible = v3 == v2
		end
	end

	local function refreshAlert() --[[ refreshAlert | Line: 460 | Upvalues: v4 (copy), QuestView (ref), getState (copy), t2 (ref), TweenService (ref), v5 (ref) ]]
		if not v4 then
			return
		end

		if QuestView.HasAnythingToClaim(getState()) then
			if not v4.Visible then
				v4.Visible = true
				v4.Rotation = -t2.AlertWobbleAngle

				local v1 = TweenService:Create(v4, TweenInfo.new(t2.AlertWobbleTime, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true), {
					Rotation = t2.AlertWobbleAngle
				})

				v5 = v1
				v1:Play()
			end
		else
			if not v5 then
				v4.Rotation = 0
				v4.Visible = false

				return
			end

			v5:Cancel()
			v5 = nil
			v4.Rotation = 0
			v4.Visible = false
		end
	end

	local function refreshCountdown() --[[ refreshCountdown | Line: 490 | Upvalues: refresh (copy), QuestView (ref), getState (copy) ]]
		if refresh then
			refresh.Text = ("Resets in: %*"):format((QuestView.FormatCountdown(QuestView.SecondsUntilReset(getState()))))
		end
	end

	local function activeIdSet() --[[ activeIdSet | Line: 499 | Upvalues: QuestView (ref), getState (copy) ]]
		local t = {}

		for v1, v2 in QuestView.GetActive(getState()) do
			t[v2.Def.Id] = true
		end

		return t
	end

	local v12 = activeIdSet()
	local v13 = 0
	local v14 = os.clock()

	local function refreshAll() --[[ refreshAll | Line: 514 | Upvalues: QuestView (ref), getState (copy), t3 (copy), QuestConfig (ref), v13 (ref), refreshCard (copy) ]]
		for v2, v3 in QuestView.GetActive(getState()) do
			local v1
			local v4 = t3[v3.Def.Id]

			if v4 then
				local v5 = QuestConfig.Trackers[v3.Def.TrackerType]

				v1 = if (if v5 == nil then false else v5.Kind == "Timer") and not v3.Done then v3.Progress + v13 else nil
				refreshCard(v4, v3, v1)
			end
		end
	end

	local function onQuestsChanged() --[[ onQuestsChanged | Line: 527 | Upvalues: v13 (ref), v14 (ref), activeIdSet (copy), v12 (ref), rebuildCards (copy), refreshAll (copy), QuestView (ref), getState (copy), setBarFill (ref), v6 (copy), v9 (ref), t (copy), refresh (copy), refreshAlert (copy) ]]
		v13 = 0
		v14 = os.clock()

		local v1 = activeIdSet()
		local v2 = false

		for v3 in v1 do
			if not v12[v3] then
				v2 = true

				break
			end
		end

		if not v2 then
			for v4 in v12 do
				if not v1[v4] then
					v2 = true

					break
				end
			end
		end

		v12 = v1

		if v2 then
			rebuildCards()
		else
			refreshAll()
		end

		local v5 = QuestView.GetTrack(getState())

		setBarFill(v6, v5.Fraction)

		if v9 then
			v9.Text = ("%*/%*"):format(v5.SegmentDone, v5.SegmentGoal)
		end

		local v62 = QuestView.ClaimableMilestone(getState())

		for v7, v8 in t do
			v8.Visible = v7 == v62
		end

		if not refresh then
			refreshAlert()

			return
		end

		refresh.Text = ("Resets in: %*"):format((QuestView.FormatCountdown(QuestView.SecondsUntilReset(getState()))))
		refreshAlert()
	end

	bindMilestoneTiles()
	rebuildCards()

	local v15 = QuestView.GetTrack(getState())

	setBarFill(v6, v15.Fraction)

	if v9 then
		v9.Text = ("%*/%*"):format(v15.SegmentDone, v15.SegmentGoal)
	end

	local v16 = QuestView.ClaimableMilestone(getState())

	for v17, v18 in t do
		v18.Visible = v17 == v16
	end

	if refresh then
		refresh.Text = ("Resets in: %*"):format((QuestView.FormatCountdown(QuestView.SecondsUntilReset(getState()))))
	end

	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 564 ]]
		return p1.quests
	end, onQuestsChanged)
	task.spawn(function() --[[ Line: 570 | Upvalues: v11 (ref), v14 (ref), v13 (ref), refresh (copy), QuestView (ref), getState (copy), refreshAll (copy) ]]
		while true do
			while true do
				task.wait(1)

				if v11 then
					break
				end

				v14 = os.clock()
			end

			local v1 = os.clock()

			v13 = v13 + math.floor(v1 - v14)
			v14 = v1

			if refresh then
				refresh.Text = ("Resets in: %*"):format((QuestView.FormatCountdown(QuestView.SecondsUntilReset(getState()))))
			end

			refreshAll()
		end
	end)
	refreshAlert()
end

return t