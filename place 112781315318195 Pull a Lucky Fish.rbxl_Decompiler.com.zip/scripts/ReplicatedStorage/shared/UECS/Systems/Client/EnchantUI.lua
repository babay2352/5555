-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ContextActionService = game:GetService("ContextActionService")
local GamepadService = game:GetService("GamepadService")
local MarketplaceService = game:GetService("MarketplaceService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local ControlHint = require(ReplicatedStorage.client.ControlHint)
local ConvertValue = require(ReplicatedStorage.shared.util.ConvertValue)
local EnchantConfig = require(ReplicatedStorage.shared.config.EnchantConfig)
local EnchantUI = require(ReplicatedStorage.shared.UECS.Components.EnchantUI)
local FishRodConfig = require(ReplicatedStorage.shared.config.FishRodConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local MonetizationConfig = require(ReplicatedStorage.shared.config.MonetizationConfig)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local TrainToolConfig = require(ReplicatedStorage.shared.config.TrainToolConfig)
local bindToButtonPress = require(ReplicatedStorage.shared.util.bindToButtonPress)
local enchantEffectModels = require(ReplicatedStorage.shared.util.enchantEffectModels)
local fetchRobuxPriceInto = require(ReplicatedStorage.shared.util.fetchRobuxPriceInto)
local isGamepadActive = require(ReplicatedStorage.shared.util.isGamepadActive)
local notifications = require(ReplicatedStorage.shared.module.notifications)
local t = {
	UECS = nil,
	Priority = 30
}
local v1 = Color3.fromRGB(255, 221, 51)
local v2 = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(247, 181, 0)), ColorSequenceKeypoint.new(0.3945, Color3.fromRGB(247, 181, 0)), ColorSequenceKeypoint.new(1, Color3.fromRGB(251, 119, 0)) })
local t2 = { "I", "II", "III", "IV" }
local TierColors = EnchantConfig.TierColors
local v3 = Color3.fromRGB(70, 255, 120)
local v4 = Color3.fromRGB(255, 65, 65)

local function getCirclePosition(p1, p2) --[[ getCirclePosition | Line: 83 ]]
	local v1 = p1 * 2 * math.pi

	return UDim2.fromScale(p2 * math.sin(v1) + 0.5, 0.5 - p2 * math.cos(v1))
end

local function tintSequence(p1, p2, p3) --[[ tintSequence | Line: 91 ]]
	local t = {}

	for v1, v2 in p1.Keypoints do
		local v3 = if v1 <= 2 then v2.Value:Lerp(p2, p3) else v2.Value
		local v4 = ColorSequenceKeypoint.new

		table.insert(t, v4(v2.Time, v3))
	end

	return ColorSequence.new(t)
end

function t.Init(p1) --[[ Init | Line: 100 | Upvalues: Players (copy), EnchantUI (copy), EnchantConfig (copy), ClientPlayerData (copy), TrainToolConfig (copy), FishRodConfig (copy), v2 (copy), enchantEffectModels (copy), ConvertValue (copy), v1 (copy), MonetizationConfig (copy), fetchRobuxPriceInto (copy), UserInputService (copy), TierColors (copy), t2 (copy), RunService (copy), tintSequence (copy), TweenService (copy), v3 (copy), v4 (copy), notifications (copy), Remotes (copy), MarketplaceService (copy), isGamepadActive (copy), bindToButtonPress (copy), ContextActionService (copy), ControlHint (copy), GamepadService (copy) ]]
	local MainUI = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI")
	local EnchantUI2 = MainUI:WaitForChild("EnchantUI")
	local TopBar = EnchantUI2:WaitForChild("TopBar")
	local v12 = EnchantUI2:WaitForChild("Content")
	local Rod = v12:WaitForChild("Rod")
	local ScrollingFrame = Rod:WaitForChild("CurrentRodEnchants"):WaitForChild("ScrollingFrame")
	local Template = ScrollingFrame:WaitForChild("Template")
	local EnchantList = v12:WaitForChild("EnchantList")
	local ScrollingFrame2 = EnchantList:WaitForChild("ScrollingFrame")
	local Template2 = ScrollingFrame2:WaitForChild("Template")
	local Tiers = EnchantList:WaitForChild("TierList"):WaitForChild("Tiers")
	local Template3 = Tiers:WaitForChild("Template")
	local Roll = v12:WaitForChild("Roll")
	local Requirements = Roll:WaitForChild("Requirements")
	local Chance = Roll:WaitForChild("Chance")
	local Slider = Roll:WaitForChild("Slider")
	local SliderButton = Slider:WaitForChild("SliderButton")
	local RollBar = Roll:WaitForChild("RollBar")
	local UIGradient = RollBar:WaitForChild("Left"):WaitForChild("ImageLabel"):WaitForChild("UIGradient")
	local UIGradient2 = RollBar:WaitForChild("Right"):WaitForChild("ImageLabel"):WaitForChild("UIGradient")
	local RollIndicator = RollBar:WaitForChild("RollIndicator")
	local BuyButton = RollBar:WaitForChild("BuyButton")
	local TextLabel = BuyButton:WaitForChild("Content"):WaitForChild("TextLabel")
	local BuyButtonRobux = RollBar:WaitForChild("BuyButtonRobux")
	local TextLabel2 = BuyButtonRobux:WaitForChild("Content"):WaitForChild("TextLabel")

	RollIndicator.AnchorPoint = Vector2.new(0.5, 0.5)

	local v22 = 0.5 - RollIndicator.Size.X.Scale / 2

	RollIndicator.Position = UDim2.fromScale(v22 * 1.2246467991473532e-16 + 0.5, 0.5 - v22 * -1)
	RollIndicator.Rotation = 270
	EnchantUI2.Visible = false
	Template2.Visible = false
	Template.Visible = false
	Template3.Visible = false

	for v32, v42 in { Template2, Template, Template3 } do
		v42:RemoveTag("VFX_HoverShine")
	end

	local v5 = EnchantUI.Add(EnchantUI2)

	local function applyEnchantIcon(p1, p2) --[[ applyEnchantIcon | Line: 161 | Upvalues: EnchantConfig (ref) ]]
		local v1 = EnchantConfig.GetStatIcon(p2)

		if v1 == "" then
			return
		end

		local ImageLabel = p1:FindFirstChild("ImageLabel")

		if not ImageLabel then
			return
		end

		ImageLabel.Image = v1
	end

	local Id = EnchantConfig.List[1].Id
	local v6 = 1
	local v7 = false
	local v8 = false
	local v9 = 0
	local v10 = nil
	local v11 = 0
	local t = {}
	local t3 = {}
	local Color = Template2.Frame.UIStroke.Color

	local function getState() --[[ getState | Line: 193 | Upvalues: ClientPlayerData (ref) ]]
		return ClientPlayerData.serverProfile:getState()
	end

	local function currentTarget() --[[ currentTarget | Line: 199 | Upvalues: v5 (copy) ]]
		if v5.Target:Get() == "Barbell" then
			return "Barbell"
		end

		return "Rod"
	end

	local function firstStatFor(p1) --[[ firstStatFor | Line: 204 | Upvalues: EnchantConfig (ref) ]]
		for v1, v2 in EnchantConfig.Stats do
			if (v2.Target or "Rod") == p1 then
				return v2.Stat
			end
		end

		return "Luck"
	end

	local function equippedConfig() --[[ equippedConfig | Line: 215 | Upvalues: ClientPlayerData (ref), v5 (copy), TrainToolConfig (ref), FishRodConfig (ref) ]]
		local v1 = ClientPlayerData.serverProfile:getState()

		if (if v5.Target:Get() == "Barbell" then "Barbell" else "Rod") == "Barbell" then
			return TrainToolConfig[v1.trainingTool]
		end

		return FishRodConfig[v1.fishRod]
	end

	local AddTrainValue = Rod:FindFirstChild("AddTrainValue")
	local v122 = AddTrainValue and AddTrainValue:FindFirstChild("Icon")
	local v13 = AddTrainValue and AddTrainValue:FindFirstChild("Value")
	local v14 = v13 and v13:FindFirstChildOfClass("UIGradient")
	local v15 = if v122 then v122.Image else ""
	local v16 = if v14 then v14.Color else v2
	local t4 = {}

	local function refreshCurrentEnchants() --[[ refreshCurrentEnchants | Line: 235 | Upvalues: t4 (copy), ClientPlayerData (ref), v5 (copy), EnchantConfig (ref), Template (copy), enchantEffectModels (ref), ScrollingFrame (copy) ]]
		for v1, v2 in t4 do
			v2:Destroy()
		end

		table.clear(t4)

		local v3 = ClientPlayerData.serverProfile:getState()
		local v4 = if v5.Target:Get() == "Barbell" then "Barbell" else "Rod"
		local v52 = EnchantConfig.GetEquippedItemFor(v3, v4)
		local v6 = v3.rodEnchants and (if v52 then v3.rodEnchants[v52] else v52)

		if not v6 then
			return
		end

		local count = 0

		for v7, v8 in EnchantConfig.List do
			if v8.Target == v4 and v6[v8.Stat] == v8.Tier then
				count = count + 1

				local v9 = Template:Clone()

				v9.Name = v8.Id
				v9.LayoutOrder = count
				v9.Visible = true
				v9:SetAttribute("InspectType", "Enchant")
				v9:SetAttribute("EnchantId", v8.Id)
				v9:AddTag("Inspect")

				local Title = v9:FindFirstChild("Title")

				if Title then
					Title.Text = v8.DisplayName

					local v10 = enchantEffectModels.GetColor(v8.Stat)

					if v10 then
						Title.TextColor3 = v10
					end
				end

				local v11 = EnchantConfig.GetStatIcon(v8.Stat)

				if v11 ~= "" then
					local ImageLabel = v9:FindFirstChild("ImageLabel")

					if ImageLabel then
						ImageLabel.Image = v11
					end
				end

				v9.Parent = ScrollingFrame
				table.insert(t4, v9)
			end
		end
	end

	local function refreshRod() --[[ refreshRod | Line: 275 | Upvalues: ClientPlayerData (ref), v5 (copy), TrainToolConfig (ref), FishRodConfig (ref), Rod (copy), v122 (copy), v15 (copy), v14 (copy), v2 (ref), v16 (copy), v13 (copy), ConvertValue (ref), refreshCurrentEnchants (copy) ]]
		local v1 = ClientPlayerData.serverProfile:getState()
		local v3 = if (if v5.Target:Get() == "Barbell" then "Barbell" else "Rod") == "Barbell" then TrainToolConfig[v1.trainingTool] else FishRodConfig[v1.fishRod]
		local ItemName = Rod:FindFirstChild("ItemName")

		if ItemName then
			ItemName.Text = if v3 then v3.DisplayName else "Nothing equipped"
		end

		local Rarity = Rod:FindFirstChild("Rarity")

		if Rarity and v3 then
			Rarity.Text = v3.Rarity.displayName
			Rarity.TextColor3 = v3.Rarity.rarityColor
		elseif Rarity then
			Rarity.Text = ""
		end

		local ToolIcon = Rod:FindFirstChild("ToolIcon")

		if ToolIcon then
			ToolIcon.Image = if v3 then v3.Icon or "" else ""
		end

		local v7 = if (if v5.Target:Get() == "Barbell" then "Barbell" else "Rod") == "Barbell" then true else false

		if v122 then
			v122.Image = if v7 then "rbxassetid://136868578369874" else v15
		end

		if v14 then
			v14.Color = if v7 then v2 else v16
		end

		if v13 and v3 then
			if v7 then
				v13.Text = ("+%* Strength"):format((ConvertValue.suffixformat(v3.AddStrength)))
			else
				v13.Text = ("x%* Luck"):format(v3.LuckMultiplier)
			end
		elseif v13 then
			v13.Text = ""
		end

		local Buttons = Rod:FindFirstChild("Buttons")

		if Buttons then
			Buttons.Visible = false
		end

		local Blackout = Rod:FindFirstChild("Blackout")

		if Blackout then
			Blackout.Visible = false
		end

		refreshCurrentEnchants()
	end

	local function ownedTierFor(p1) --[[ ownedTierFor | Line: 329 | Upvalues: ClientPlayerData (ref), EnchantConfig (ref) ]]
		local v1 = ClientPlayerData.serverProfile:getState()
		local v2 = EnchantConfig.GetEquippedItemFor(v1, EnchantConfig.GetTargetOf(p1))
		local v3 = v1.rodEnchants and (if v2 then v1.rodEnchants[v2] else v2)

		return if v3 then v3[p1] or 0 else 0
	end

	local function isBlocked(p1) --[[ isBlocked | Line: 338 | Upvalues: ClientPlayerData (ref), EnchantConfig (ref) ]]
		local Stat = p1.Stat
		local v1 = ClientPlayerData.serverProfile:getState()
		local v2 = EnchantConfig.GetEquippedItemFor(v1, EnchantConfig.GetTargetOf(Stat))
		local v3 = v1.rodEnchants and (if v2 then v1.rodEnchants[v2] else v2)

		return p1.Tier <= (v3 and v3[Stat] or 0)
	end

	local function entryText(p1) --[[ entryText | Line: 342 | Upvalues: ClientPlayerData (ref), EnchantConfig (ref) ]]
		local Stat = p1.Stat
		local v1 = ClientPlayerData.serverProfile:getState()
		local v2 = EnchantConfig.GetEquippedItemFor(v1, EnchantConfig.GetTargetOf(Stat))
		local v3 = v1.rodEnchants and (if v2 then v1.rodEnchants[v2] else v2)

		if (v3 and v3[Stat] or 0) == p1.Tier then
			return ("%* \226\156\147"):format(p1.DisplayName)
		end

		return p1.DisplayName
	end

	local function refreshListTexts() --[[ refreshListTexts | Line: 349 | Upvalues: t (copy), EnchantConfig (ref), ClientPlayerData (ref), enchantEffectModels (ref), t3 (copy), Id (ref), v1 (ref), Color (copy) ]]
		for v2, v3 in t do
			local v12
			local v4 = EnchantConfig.Enchants[v2]
			local Stat = v4.Stat
			local v5 = ClientPlayerData.serverProfile:getState()
			local v6 = EnchantConfig.GetEquippedItemFor(v5, EnchantConfig.GetTargetOf(Stat))
			local v7 = v5.rodEnchants and (if v6 then v5.rodEnchants[v6] else v6)
			local v9 = if (v7 and v7[Stat] or 0) == v4.Tier then true else false

			v12 = if v9 then ("%* \226\156\147"):format(v4.DisplayName) else v4.DisplayName
			v3.Title.Text = v12

			local Stat2 = v4.Stat
			local v11 = ClientPlayerData.serverProfile:getState()
			local v122 = EnchantConfig.GetEquippedItemFor(v11, EnchantConfig.GetTargetOf(Stat2))
			local v13 = v11.rodEnchants and (if v122 then v11.rodEnchants[v122] else v122)

			v3.Title.TextTransparency = if if v4.Tier <= (v13 and v13[Stat2] or 0) then true else false then 0.5 else 0

			local v17 = enchantEffectModels.GetColor(v4.Stat)

			if v17 then
				v3.Title.TextColor3 = v17
			end

			t3[v2].Color = if Id == v2 then v1 else Color
		end
	end

	local v17 = nil

	local function currentExtraGems(p1) --[[ currentExtraGems | Line: 368 | Upvalues: v9 (ref) ]]
		return math.floor(v9 * p1.GemCost + 0.5)
	end

	local function drawWedge(p1) --[[ drawWedge | Line: 376 | Upvalues: UIGradient (copy), UIGradient2 (copy), Chance (copy) ]]
		UIGradient.Rotation = (1 - p1) * -180
		UIGradient2.Rotation = p1 * -180
		Chance.Text = ("Chance: %*%%"):format((math.floor(p1 * 100 + 0.5)))
	end

	local function refreshRollPanel() --[[ refreshRollPanel | Line: 382 | Upvalues: Id (ref), EnchantConfig (ref), v9 (ref), v10 (ref), UIGradient (copy), UIGradient2 (copy), Chance (copy), Requirements (copy), ConvertValue (ref), getState (copy), ClientPlayerData (ref), TextLabel (copy), TextLabel2 (copy), v17 (ref), MonetizationConfig (ref), fetchRobuxPriceInto (ref) ]]
		local v1 = Id and EnchantConfig.Enchants[Id]

		if not v1 then
			return
		end

		local v3 = math.floor(v9 * v1.GemCost + 0.5)
		local v4 = v10 or EnchantConfig.GetBoostedChance(v1, v3)

		UIGradient.Rotation = (1 - v4) * -180
		UIGradient2.Rotation = v4 * -180
		Chance.Text = ("Chance: %*%%"):format((math.floor(v4 * 100 + 0.5)))

		local v5, v6 = EnchantConfig.GetAttemptCost(v1, v3)

		Requirements.Text = ("%*/%*"):format(ConvertValue.suffixformat(EnchantConfig.GetStoneCount(getState())), (ConvertValue.suffixformat(v6)))

		local Stat = v1.Stat
		local v7 = ClientPlayerData.serverProfile:getState()
		local v8 = EnchantConfig.GetEquippedItemFor(v7, EnchantConfig.GetTargetOf(Stat))
		local v92 = v7.rodEnchants and (if v8 then v7.rodEnchants[v8] else v8)

		if if v1.Tier <= (v92 and v92[Stat] or 0) then true else false then
			local Stat2 = v1.Stat
			local v13 = ClientPlayerData.serverProfile:getState()
			local v14 = EnchantConfig.GetEquippedItemFor(v13, EnchantConfig.GetTargetOf(Stat2))
			local v15 = v13.rodEnchants and (if v14 then v13.rodEnchants[v14] else v14)

			TextLabel.Text = if (v15 and v15[Stat2] or 0) == v1.Tier then "Owned" else "Owned better"
			TextLabel2.Text = "\226\128\148"
			v17 = nil
		else
			TextLabel.Text = ("%* Gems"):format(v5)

			local v18 = MonetizationConfig.DevProducts[v1.RobuxProductKey]

			if v18 and v18.ProductId ~= 0 then
				if v17 ~= v18.ProductId then
					v17 = v18.ProductId
					TextLabel2.Text = ""
					fetchRobuxPriceInto(TextLabel2, v18.ProductId)
				end
			else
				TextLabel2.Text = "Soon"
				v17 = nil
			end
		end
	end

	SliderButton.AnchorPoint = Vector2.new(0.5, 0.5)

	local function setSlider(p1) --[[ setSlider | Line: 444 | Upvalues: v9 (ref), SliderButton (copy), v10 (ref), refreshRollPanel (copy) ]]
		v9 = math.clamp(p1, 0, 1)
		SliderButton.Position = UDim2.fromScale(v9 * 0.8999999999999999 + 0.05, 0.5)
		v10 = nil
		refreshRollPanel()
	end

	local v18 = false

	local function setSliderFromScreenX(p1) --[[ setSliderFromScreenX | Line: 456 | Upvalues: Slider (copy), v9 (ref), SliderButton (copy), v10 (ref), refreshRollPanel (copy) ]]
		local X = Slider.AbsolutePosition.X
		local X2 = Slider.AbsoluteSize.X

		if not (X2 <= 0) then
			v9 = math.clamp(((p1 - X) / X2 - 0.05) / 0.8999999999999999, 0, 1)
			SliderButton.Position = UDim2.fromScale(v9 * 0.8999999999999999 + 0.05, 0.5)
			v10 = nil
			refreshRollPanel()
		end
	end

	local function beginSliderInput(p1) --[[ beginSliderInput | Line: 466 | Upvalues: v7 (ref), v18 (ref), Slider (copy), v9 (ref), SliderButton (copy), v10 (ref), refreshRollPanel (copy) ]]
		if v7 then
			return
		end

		if p1.UserInputType ~= Enum.UserInputType.MouseButton1 and p1.UserInputType ~= Enum.UserInputType.Touch then
			return
		end

		v18 = true

		local X3 = Slider.AbsoluteSize.X

		if X3 <= 0 then
			return
		end

		v9 = math.clamp(((p1.Position.X - Slider.AbsolutePosition.X) / X3 - 0.05) / 0.8999999999999999, 0, 1)
		SliderButton.Position = UDim2.fromScale(v9 * 0.8999999999999999 + 0.05, 0.5)
		v10 = nil
		refreshRollPanel()
	end

	SliderButton.InputBegan:Connect(beginSliderInput)
	Slider.InputBegan:Connect(beginSliderInput)
	UserInputService.InputChanged:Connect(function(p1) --[[ Line: 482 | Upvalues: v18 (ref), Slider (copy), v9 (ref), SliderButton (copy), v10 (ref), refreshRollPanel (copy) ]]
		if not v18 then
			return
		end

		if p1.UserInputType ~= Enum.UserInputType.MouseMovement and p1.UserInputType ~= Enum.UserInputType.Touch then
			return
		end

		local X3 = Slider.AbsoluteSize.X

		if X3 <= 0 then
			return
		end

		v9 = math.clamp(((p1.Position.X - Slider.AbsolutePosition.X) / X3 - 0.05) / 0.8999999999999999, 0, 1)
		SliderButton.Position = UDim2.fromScale(v9 * 0.8999999999999999 + 0.05, 0.5)
		v10 = nil
		refreshRollPanel()
	end)
	UserInputService.InputEnded:Connect(function(p1) --[[ Line: 494 | Upvalues: v18 (ref) ]]
		if p1.UserInputType ~= Enum.UserInputType.MouseButton1 and p1.UserInputType ~= Enum.UserInputType.Touch then
			return
		end

		v18 = false
	end)

	for v19, v20 in EnchantConfig.List do
		local v21 = Template2:Clone()

		v21.Name = v20.Id
		v21.LayoutOrder = v19
		v21.Visible = true
		v21:SetAttribute("InspectType", "Enchant")
		v21:SetAttribute("EnchantId", v20.Id)
		v21:AddTag("Inspect")

		local v222 = EnchantConfig.GetStatIcon(v20.Stat)

		if v222 ~= "" then
			local ImageLabel = v21:FindFirstChild("ImageLabel")

			if ImageLabel then
				ImageLabel.Image = v222
			end
		end

		local UIStroke = v21.Frame.UIStroke

		v21.Selectable = true
		v21.Activated:Connect(function() --[[ Line: 518 | Upvalues: v7 (ref), Id (ref), v20 (copy), refreshListTexts (copy), v9 (ref), SliderButton (copy), v10 (ref), refreshRollPanel (copy) ]]
			if not v7 then
				Id = v20.Id
				refreshListTexts()
				v9 = 0
				SliderButton.Position = UDim2.fromScale(v9 * 0.8999999999999999 + 0.05, 0.5)
				v10 = nil
				refreshRollPanel()
			end
		end)
		t[v20.Id] = v21
		t3[v20.Id] = UIStroke
		v21.Parent = ScrollingFrame2
	end

	local t5 = {}

	local function refreshTierList() --[[ refreshTierList | Line: 537 | Upvalues: t5 (copy), v6 (ref) ]]
		for v1, v2 in t5 do
			local v3 = v1 == v6
			local Frame = v2:FindFirstChild("Frame")

			if Frame then
				Frame.BackgroundTransparency = if v3 then 0 else 0.35

				local UIStroke = Frame:FindFirstChild("UIStroke")

				if UIStroke then
					UIStroke.Transparency = if v3 then 0 else 0.5
				end
			end
		end
	end

	local function refreshEnchantListVisibility() --[[ refreshEnchantListVisibility | Line: 551 | Upvalues: v5 (copy), t (copy), EnchantConfig (ref), v6 (ref) ]]
		local v1 = if v5.Target:Get() == "Barbell" then "Barbell" else "Rod"

		for v2, v3 in t do
			local v4 = EnchantConfig.Enchants[v2]

			v3.Visible = if v4.Tier == v6 then if v4.Target == v1 then true else false else false
		end
	end

	local function selectTier(p1) --[[ selectTier | Line: 559 | Upvalues: v7 (ref), v6 (ref), v5 (copy), Id (ref), EnchantConfig (ref), refreshTierList (copy), refreshEnchantListVisibility (copy), refreshListTexts (copy), v9 (ref), SliderButton (copy), v10 (ref), refreshRollPanel (copy) ]]
		if v7 then
			return
		end

		v6 = p1

		local v1 = if v5.Target:Get() == "Barbell" then "Barbell" else "Rod"
		local v2 = Id and EnchantConfig.Enchants[Id]
		local v3

		if v2 and v2.Target == v1 then
			v3 = v2.Stat
		else
			do
				local __inline_returned = false

				for v4, v52 in EnchantConfig.Stats do
					if (v52.Target or "Rod") == v1 then
						v3 = v52.Stat
						__inline_returned = true

						break
					end
				end

				if not __inline_returned then
					v3 = "Luck"
				end
			end
		end

		Id = v3 .. p1
		refreshTierList()
		refreshEnchantListVisibility()
		refreshListTexts()
		v9 = 0
		SliderButton.Position = UDim2.fromScale(v9 * 0.8999999999999999 + 0.05, 0.5)
		v10 = nil
		refreshRollPanel()
	end

	for i = 1, 4 do
		local v23 = Template3:Clone()

		v23.Name = "Tier" .. i
		v23.LayoutOrder = i
		v23.Visible = true

		local v24 = TierColors[i]
		local Title = v23:FindFirstChild("Title")

		if Title then
			Title.Text = "Tier " .. t2[i]
			Title.TextColor3 = v24.Stroke
		end

		local Frame = v23:FindFirstChild("Frame")

		if Frame then
			Frame.BackgroundColor3 = v24.Background

			local UIStroke = Frame:FindFirstChild("UIStroke")

			if UIStroke then
				UIStroke.Color = v24.Stroke
			end
		end

		v23.Selectable = true
		v23.Activated:Connect(function() --[[ Line: 598 | Upvalues: selectTier (copy), i (copy) ]]
			selectTier(i)
		end)
		t5[i] = v23
		v23.Parent = Tiers
	end

	local Color2 = UIGradient.Color
	local Color4 = UIGradient2.Color
	local v25 = 0

	local function stopFlash() --[[ stopFlash | Line: 613 | Upvalues: v25 (ref), UIGradient (copy), Color2 (copy), UIGradient2 (copy), Color4 (copy) ]]
		v25 = v25 + 1
		UIGradient.Color = Color2
		UIGradient2.Color = Color4
	end

	local function flashRollBar(p1) --[[ flashRollBar | Line: 621 | Upvalues: v25 (ref), RunService (ref), UIGradient (copy), tintSequence (ref), Color2 (copy), UIGradient2 (copy), Color4 (copy) ]]
		v25 = v25 + 1

		local v1 = v25
		local v2 = 0
		local v3 = nil

		v3 = RunService.RenderStepped:Connect(function(p1) --[[ Line: 626 | Upvalues: v1 (copy), v25 (ref), v3 (ref), v2 (ref), UIGradient (ref), tintSequence (ref), Color2 (ref), p1 (copy), UIGradient2 (ref), Color4 (ref) ]]
			if v1 ~= v25 then
				v3:Disconnect()

				return
			end

			v2 = math.min(v2 + p1, 0.8)

			local v32 = math.sin(v2 / 0.8 * math.pi)

			UIGradient.Color = tintSequence(Color2, p1, v32)
			UIGradient2.Color = tintSequence(Color4, p1, v32)

			if not (v2 >= 0.8) then
				return
			end

			v3:Disconnect()
			UIGradient.Color = Color2
			UIGradient2.Color = Color4
		end)
	end

	local function pickLandingOffset(p1, p2) --[[ pickLandingOffset | Line: 650 ]]
		if p2 then
			return 0.5 + (math.random() - 0.5) * p1 * 0.9
		end

		return (p1 / 2 + 0.5 + (1 - p1) * (0.1 + 0.8 * math.random())) % 1
	end

	local function playRollAnimation(p1, p2, p3) --[[ playRollAnimation | Line: 660 | Upvalues: v7 (ref), v11 (ref), v25 (ref), UIGradient (copy), Color2 (copy), UIGradient2 (copy), Color4 (copy), v10 (ref), Chance (copy), RunService (ref), TweenService (ref), RollIndicator (copy), v22 (copy), v3 (ref), v4 (ref), tintSequence (ref), notifications (ref), refreshListTexts (copy), refreshCurrentEnchants (copy), refreshRollPanel (copy) ]]
		v7 = true
		v11 = v11 + 1
		v25 = v25 + 1
		UIGradient.Color = Color2
		UIGradient2.Color = Color4

		local v1 = v11

		v10 = p1
		UIGradient.Rotation = (1 - p1) * -180
		UIGradient2.Rotation = p1 * -180
		Chance.Text = ("Chance: %*%%"):format((math.floor(p1 * 100 + 0.5)))

		local v32 = (if p2 then 0.5 + (math.random() - 0.5) * p1 * 0.9 else (p1 / 2 + 0.5 + (1 - p1) * (0.1 + 0.8 * math.random())) % 1) + 3
		local v42 = 0
		local v5 = nil

		v5 = RunService.RenderStepped:Connect(function(p1) --[[ Line: 675 | Upvalues: v1 (copy), v11 (ref), v5 (ref), v42 (ref), TweenService (ref), v32 (copy), RollIndicator (ref), v22 (ref), v7 (ref), p2 (copy), v3 (ref), v4 (ref), v25 (ref), RunService (ref), UIGradient (ref), tintSequence (ref), Color2 (ref), UIGradient2 (ref), Color4 (ref), p3 (copy), notifications (ref), refreshListTexts (ref), refreshCurrentEnchants (ref), refreshRollPanel (ref) ]]
			if v1 ~= v11 then
				v5:Disconnect()

				return
			end

			v42 = math.min(v42 + p1, 3)

			local v2 = TweenService:GetValue(v42 / 3, Enum.EasingStyle.Quint, Enum.EasingDirection.Out) * v32
			local v33 = v22
			local v43 = v2 * 2 * math.pi

			RollIndicator.Position = UDim2.fromScale(v33 * math.sin(v43) + 0.5, 0.5 - v33 * math.cos(v43))
			RollIndicator.Rotation = v2 % 1 * 360 + 90

			if not (v42 >= 3) then
				return
			end

			v5:Disconnect()
			v7 = false

			local v52 = if p2 then v3 else v4

			v25 = v25 + 1

			local v6 = v25
			local v72 = 0
			local v8 = nil

			v8 = RunService.RenderStepped:Connect(function(p1) --[[ Line: 626 | Upvalues: v6 (copy), v25 (ref), v8 (ref), v72 (ref), UIGradient (ref), tintSequence (ref), Color2 (ref), v52 (copy), UIGradient2 (ref), Color4 (ref) ]]
				if v6 ~= v25 then
					v8:Disconnect()

					return
				end

				v72 = math.min(v72 + p1, 0.8)

				local v32 = math.sin(v72 / 0.8 * math.pi)

				UIGradient.Color = tintSequence(Color2, v52, v32)
				UIGradient2.Color = tintSequence(Color4, v52, v32)

				if not (v72 >= 0.8) then
					return
				end

				v8:Disconnect()
				UIGradient.Color = Color2
				UIGradient2.Color = Color4
			end)

			if p2 then
				notifications:Send((("You enchanted your %* with %*!"):format(if p3.Target == "Barbell" then "barbells" else "rod", p3.DisplayName)))
			else
				notifications:Send((("The %* enchant failed..."):format(p3.DisplayName)))
			end

			refreshListTexts()
			refreshCurrentEnchants()
			refreshRollPanel()
		end)
	end

	BuyButton.Selectable = true
	BuyButtonRobux.Selectable = true

	local function buyWithGems() --[[ buyWithGems | Line: 714 | Upvalues: Id (ref), EnchantConfig (ref), v7 (ref), ClientPlayerData (ref), v9 (ref), Remotes (ref), playRollAnimation (copy) ]]
		local v1 = Id and EnchantConfig.Enchants[Id]

		if v7 or not v1 then
			return
		end

		local Stat = v1.Stat
		local v2 = ClientPlayerData.serverProfile:getState()
		local v3 = EnchantConfig.GetEquippedItemFor(v2, EnchantConfig.GetTargetOf(Stat))
		local v4 = v2.rodEnchants and (if v3 then v2.rodEnchants[v3] else v3)

		if if v1.Tier <= (v4 and v4[Stat] or 0) then true else false then
			return
		end

		local v8 = math.floor(v9 * v1.GemCost + 0.5)
		local v92, v10 = Remotes.RequestEnchantRoll:Call({
			Method = "Gems",
			EnchantId = v1.Id,
			ExtraGems = v8
		}):Await()

		if not v92 or (typeof(v10) ~= "table" or not v10.ok) then
			return
		end

		playRollAnimation(if typeof(v10.chance) == "number" then v10.chance else EnchantConfig.GetBoostedChance(v1, v8), if v10.success == true then true else false, v1)
	end

	local function buyWithRobux() --[[ buyWithRobux | Line: 733 | Upvalues: Id (ref), EnchantConfig (ref), v7 (ref), ClientPlayerData (ref), MonetizationConfig (ref), Remotes (ref), v8 (ref), MarketplaceService (ref), Players (ref) ]]
		local v1 = Id and EnchantConfig.Enchants[Id]

		if v7 or not v1 then
			return
		end

		local Stat = v1.Stat
		local v2 = ClientPlayerData.serverProfile:getState()
		local v3 = EnchantConfig.GetEquippedItemFor(v2, EnchantConfig.GetTargetOf(Stat))
		local v4 = v2.rodEnchants and (if v3 then v2.rodEnchants[v3] else v3)

		if if v1.Tier <= (v4 and v4[Stat] or 0) then true else false then
			return
		end

		local v72 = MonetizationConfig.DevProducts[v1.RobuxProductKey]

		if not v72 or v72.ProductId == 0 then
			return
		end

		local v82, v9 = Remotes.RequestEnchantRoll:Call({
			Method = "Robux",
			EnchantId = v1.Id
		}):Await()

		if v82 and (typeof(v9) == "table" and v9.ok) then
			v8 = true
			MarketplaceService:PromptProductPurchase(Players.LocalPlayer, v72.ProductId)
		end
	end

	MarketplaceService.PromptProductPurchaseFinished:Connect(function() --[[ Line: 754 | Upvalues: v8 (ref) ]]
		task.delay(3, function() --[[ Line: 757 | Upvalues: v8 (ref) ]]
			v8 = false
		end)
	end)
	BuyButton.Activated:Connect(buyWithGems)
	BuyButtonRobux.Activated:Connect(buyWithRobux)

	local DPadUp = Enum.KeyCode.DPadUp
	local DPadDown = Enum.KeyCode.DPadDown
	local ButtonL1 = Enum.KeyCode.ButtonL1
	local ButtonR1 = Enum.KeyCode.ButtonR1
	local ButtonX = Enum.KeyCode.ButtonX
	local ButtonY = Enum.KeyCode.ButtonY
	local ButtonB = Enum.KeyCode.ButtonB

	local function visibleEntryIds() --[[ visibleEntryIds | Line: 784 | Upvalues: v5 (copy), EnchantConfig (ref), v6 (ref) ]]
		local v1 = if v5.Target:Get() == "Barbell" then "Barbell" else "Rod"
		local t = {}

		for v2, v3 in EnchantConfig.List do
			if v3.Tier == v6 and v3.Target == v1 then
				table.insert(t, v3.Id)
			end
		end

		return t
	end

	local function navigateList(p1) --[[ navigateList | Line: 795 | Upvalues: v7 (ref), visibleEntryIds (copy), Id (ref), refreshListTexts (copy), v9 (ref), SliderButton (copy), v10 (ref), refreshRollPanel (copy) ]]
		if v7 then
			return
		end

		local v1 = visibleEntryIds()

		if #v1 == 0 then
			return
		end

		local v2 = 1

		for v3, v4 in v1 do
			if v4 == Id then
				v2 = v3

				break
			end
		end

		Id = v1[math.clamp(v2 + p1, 1, #v1)]
		refreshListTexts()
		v9 = 0
		SliderButton.Position = UDim2.fromScale(v9 * 0.8999999999999999 + 0.05, 0.5)
		v10 = nil
		refreshRollPanel()
	end

	local function bindGamepad() --[[ bindGamepad | Line: 815 | Upvalues: isGamepadActive (ref), bindToButtonPress (ref), DPadUp (copy), navigateList (copy), DPadDown (copy), ButtonL1 (copy), selectTier (copy), v6 (ref), ButtonR1 (copy), ButtonX (copy), buyWithGems (copy), ButtonY (copy), buyWithRobux (copy), ButtonB (copy), v8 (ref), p1 (copy) ]]
		if isGamepadActive() then
			bindToButtonPress("EnchantUIListPrev", DPadUp, function() --[[ Line: 819 | Upvalues: navigateList (ref) ]]
				navigateList(-1)
			end)
			bindToButtonPress("EnchantUIListNext", DPadDown, function() --[[ Line: 822 | Upvalues: navigateList (ref) ]]
				navigateList(1)
			end)
			bindToButtonPress("EnchantUITierPrev", ButtonL1, function() --[[ Line: 825 | Upvalues: selectTier (ref), v6 (ref) ]]
				selectTier((math.clamp(v6 - 1, 1, 4)))
			end)
			bindToButtonPress("EnchantUITierNext", ButtonR1, function() --[[ Line: 828 | Upvalues: selectTier (ref), v6 (ref) ]]
				selectTier((math.clamp(v6 + 1, 1, 4)))
			end)
			bindToButtonPress("EnchantUIBuyGems", ButtonX, buyWithGems)
			bindToButtonPress("EnchantUIBuyRobux", ButtonY, buyWithRobux)
			bindToButtonPress("EnchantUIClose", ButtonB, function() --[[ Line: 833 | Upvalues: v8 (ref), p1 (ref) ]]
				if not v8 then
					p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
				end
			end)
		end
	end

	local function unbindGamepad() --[[ unbindGamepad | Line: 842 | Upvalues: ContextActionService (ref) ]]
		for v1, v2 in { "ListPrev", "ListNext", "TierPrev", "TierNext", "BuyGems", "BuyRobux", "Close" } do
			ContextActionService:UnbindAction("EnchantUI" .. v2)
		end
	end

	UserInputService.LastInputTypeChanged:Connect(function() --[[ Line: 849 | Upvalues: EnchantUI2 (copy), isGamepadActive (ref), bindGamepad (copy) ]]
		if not (EnchantUI2.Visible and isGamepadActive()) then
			return
		end

		bindGamepad()
	end)
	Remotes.EnchantRollResult:On(function(p1) --[[ Line: 857 | Upvalues: EnchantConfig (ref), v5 (copy), notifications (ref), playRollAnimation (copy) ]]
		if typeof(p1) ~= "table" then
			return
		end

		local v1 = EnchantConfig.Enchants[p1.EnchantId]

		if not v1 then
			return
		end

		local isSuccess = p1.Success == true
		local v2 = if typeof(p1.Chance) == "number" then p1.Chance else v1.Chance

		if v5.Visible:Get() then
			playRollAnimation(v2, isSuccess, v1)

			return
		end

		if not isSuccess then
			notifications:Send((("The %* enchant failed..."):format(v1.DisplayName)))

			return
		end

		notifications:Send((("You enchanted your %* with %*!"):format(if v1.Target == "Barbell" then "barbells" else "rod", v1.DisplayName)))
	end)

	local CloseButton = TopBar:WaitForChild("CloseButton")

	CloseButton.Active = true
	CloseButton.Selectable = true
	CloseButton.Activated:Connect(function() --[[ Line: 891 | Upvalues: p1 (copy) ]]
		p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
	end)

	local v26 = ControlHint.new({
		label = "",
		anchorTo = CloseButton,
		keyCode = ButtonB
	})

	v26:Hide()

	local function ensureSelectionMatchesTarget() --[[ ensureSelectionMatchesTarget | Line: 902 | Upvalues: v5 (copy), Id (ref), EnchantConfig (ref), v6 (ref) ]]
		local v1 = if v5.Target:Get() == "Barbell" then "Barbell" else "Rod"
		local v2 = Id and EnchantConfig.Enchants[Id]

		if v2 and v2.Target == v1 then
			return
		end

		local v3

		do
			local __inline_returned = false

			for v4, v52 in EnchantConfig.Stats do
				if (v52.Target or "Rod") == v1 then
					v3 = v52.Stat
					__inline_returned = true

					break
				end
			end

			if not __inline_returned then
				v3 = "Luck"
			end
		end

		Id = v3 .. v6
	end

	v5.Target.OnChange:Connect(function() --[[ Line: 911 | Upvalues: v5 (copy), Id (ref), EnchantConfig (ref), v6 (ref), refreshRod (copy), refreshEnchantListVisibility (copy), refreshListTexts (copy), v9 (ref), SliderButton (copy), v10 (ref), refreshRollPanel (copy) ]]
		local v1 = if v5.Target:Get() == "Barbell" then "Barbell" else "Rod"
		local v2 = Id and EnchantConfig.Enchants[Id]
		local v3

		if not v2 or v2.Target ~= v1 then
			local v4

			do
				local __inline_returned = false

				for v52, v62 in EnchantConfig.Stats do
					if (v62.Target or "Rod") == v1 then
						v4 = v62.Stat
						__inline_returned = true

						break
					end
				end

				if not __inline_returned then
					v4 = "Luck"
				end
			end

			Id = v4 .. v6
		end

		refreshRod()
		refreshEnchantListVisibility()
		refreshListTexts()
		v9 = 0
		v3 = v9 * 0.8999999999999999 + 0.05
		SliderButton.Position = UDim2.fromScale(v3, 0.5)
		v10 = nil
		refreshRollPanel()
	end)
	v5.Visible.OnChange:Connect(function(p12) --[[ Line: 919 | Upvalues: EnchantUI2 (copy), MainUI (copy), p1 (copy), GamepadService (ref), bindGamepad (copy), v26 (copy), unbindGamepad (copy), v5 (copy), Id (ref), EnchantConfig (ref), v6 (ref), refreshRod (copy), refreshEnchantListVisibility (copy), refreshListTexts (copy), v9 (ref), SliderButton (copy), v10 (ref), refreshRollPanel (copy), v11 (ref), v7 (ref), v25 (ref), UIGradient (copy), Color2 (copy), UIGradient2 (copy), Color4 (copy) ]]
		EnchantUI2.Visible = p12

		local HUD = MainUI:FindFirstChild("HUD")

		if HUD and p12 then
			HUD.Visible = false
		elseif HUD then
			HUD.Visible = not p1.UECS:WaitForAnyComponent("EnchantUISelection").Visible:Get()
		end

		if p12 then
			GamepadService:EnableGamepadCursor(EnchantUI2)
			bindGamepad()
			v26:Show()
		else
			unbindGamepad()
			v26:Hide()

			if not p1.UECS:WaitForAnyComponent("EnchantUISelection").Visible:Get() then
				GamepadService:DisableGamepadCursor()
			end
		end

		if not p12 then
			v11 = v11 + 1
			v7 = false
			v25 = v25 + 1
			UIGradient.Color = Color2
			UIGradient2.Color = Color4

			return
		end

		local v1 = if v5.Target:Get() == "Barbell" then "Barbell" else "Rod"
		local v2 = Id and EnchantConfig.Enchants[Id]
		local v3

		if not v2 or v2.Target ~= v1 then
			local v4

			do
				local __inline_returned = false

				for v52, v62 in EnchantConfig.Stats do
					if (v62.Target or "Rod") == v1 then
						v4 = v62.Stat
						__inline_returned = true

						break
					end
				end

				if not __inline_returned then
					v4 = "Luck"
				end
			end

			Id = v4 .. v6
		end

		refreshRod()
		refreshEnchantListVisibility()
		refreshListTexts()
		v9 = 0
		v3 = v9 * 0.8999999999999999 + 0.05
		SliderButton.Position = UDim2.fromScale(v3, 0.5)
		v10 = nil
		refreshRollPanel()
	end)
	GamepadService:GetPropertyChangedSignal("GamepadCursorEnabled"):Connect(function() --[[ Line: 964 | Upvalues: GamepadService (ref), EnchantUI2 (copy) ]]
		if GamepadService.GamepadCursorEnabled or not EnchantUI2.Visible then
			return
		end

		GamepadService:EnableGamepadCursor(EnchantUI2)
	end)
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 970 ]]
		return p1.fishRod
	end, function() --[[ Line: 972 | Upvalues: refreshRod (copy), refreshListTexts (copy) ]]
		refreshRod()
		refreshListTexts()
	end)
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 976 ]]
		return p1.trainingTool
	end, function() --[[ Line: 978 | Upvalues: refreshRod (copy), refreshListTexts (copy) ]]
		refreshRod()
		refreshListTexts()
	end)
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 982 ]]
		return p1.rodEnchants
	end, function() --[[ Line: 984 | Upvalues: v7 (ref), refreshListTexts (copy), refreshCurrentEnchants (copy), refreshRollPanel (copy) ]]
		if not v7 then
			refreshListTexts()
			refreshCurrentEnchants()
			refreshRollPanel()
		end
	end)
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 996 ]]
		return p1.inventory
	end, function() --[[ Line: 1000 | Upvalues: refreshRollPanel (copy) ]]
		refreshRollPanel()
	end)
	refreshRod()
	refreshTierList()
	refreshEnchantListVisibility()
	refreshListTexts()
	v9 = 0

	local v27 = v9 * 0.8999999999999999 + 0.05

	SliderButton.Position = UDim2.fromScale(v27, 0.5)
	v10 = nil
	refreshRollPanel()
end

return t