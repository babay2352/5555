-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local EventConfig = require(ReplicatedStorage.shared.config.EventConfig)
local FoodConfig = require(ReplicatedStorage.shared.config.FoodConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local t = {
	UECS = nil,
	Priority = 60
}
local CookingProgressBoard = EventConfig.Tags.CookingProgressBoard
local DishTiers = EventConfig.CookingSystem.DishTiers
local PointsRequired = DishTiers[#DishTiers].PointsRequired

local function thermometerFraction(p1) --[[ thermometerFraction | Line: 45 | Upvalues: DishTiers (copy) ]]
	local v1 = #DishTiers
	local count = 0

	for v2, v3 in DishTiers do
		if v3.PointsRequired <= p1 then
			count = count + 1
		end
	end

	if v1 <= count then
		return 1
	end

	local v4 = if count == 0 then 0 else DishTiers[count].PointsRequired
	local PointsRequired = DishTiers[count + 1].PointsRequired

	return math.clamp((count + (if v4 < PointsRequired then (p1 - v4) / (PointsRequired - v4) else 0)) / v1, 0, 1)
end

local function setupBoard(p1) --[[ setupBoard | Line: 69 | Upvalues: ReplicatedStorage (copy), Players (copy), DishTiers (copy), FoodConfig (copy), EventConfig (copy), ClientPlayerData (copy), PointsRequired (copy), thermometerFraction (copy) ]]
	if not p1:IsA("BasePart") then
		return
	end

	local CookingProgressBoard = ReplicatedStorage.shared.model:FindFirstChild("CookingProgressBoard")

	if not CookingProgressBoard then
		warn("[CookingProgressBoard] Template not found in ReplicatedStorage.shared.model")

		return
	end

	local PlayerGui = Players.LocalPlayer:FindFirstChildOfClass("PlayerGui")

	if not PlayerGui then
		return
	end

	local v1 = CookingProgressBoard:Clone()

	v1.Adornee = p1
	v1.Parent = PlayerGui

	local Background = v1:FindFirstChild("Background")
	local Subtitle = Background:FindFirstChild("Subtitle")
	local Rows = Background:FindFirstChild("Rows")
	local RowTemplate = Rows:FindFirstChild("RowTemplate")
	local t = {}

	for i = #DishTiers, 1, -1 do
		local v2 = DishTiers[i]
		local v3 = RowTemplate:Clone()

		v3.Name = "Row" .. v2.PointsRequired
		v3.LayoutOrder = #DishTiers - i
		v3.Visible = true

		local Points = v3:FindFirstChild("Points")

		if Points then
			Points.Text = tostring(v2.PointsRequired)
		end

		local Dish = v3:FindFirstChild("Dish")
		local v4 = if Dish then Dish:FindFirstChild("DoneGlow") else Dish

		if Dish then
			local v5 = FoodConfig[v2.ConfigName]

			Dish.Image = if v5 then v5.Image else ""
		end

		local Info = v3:FindFirstChild("Info")
		local v7 = if Info then Info:FindFirstChild("Reward") else Info

		if v7 then
			v7.Text = tostring(v2.CoinsReward)
		end

		v3.Parent = Rows

		if v4 then
			table.insert(t, {
				tier = v2,
				doneGlow = v4
			})
		end
	end

	RowTemplate:Destroy()

	local Thermometer = Background:FindFirstChild("Thermometer")
	local v8 = Thermometer and Thermometer:FindFirstChild("Fill")

	local function selectCookingPoints(p1) --[[ selectCookingPoints | Line: 136 | Upvalues: EventConfig (ref) ]]
		local v1 = p1.events and p1.events[EventConfig.Event.Id]

		return if v1 then v1.cookingPoints or 0 else 0
	end

	local function updateProgress() --[[ updateProgress | Line: 141 | Upvalues: ClientPlayerData (ref), EventConfig (ref), Subtitle (copy), PointsRequired (ref), t (copy), v8 (copy), thermometerFraction (ref) ]]
		local v1 = ClientPlayerData.serverProfile:getState()
		local v2 = v1.events and v1.events[EventConfig.Event.Id]
		local v3 = if v2 then v2.cookingPoints or 0 else 0

		if Subtitle then
			Subtitle.Text = ("%* / %* pts banked"):format(v3, PointsRequired)
		end

		for v4, v5 in t do
			v5.doneGlow.Transparency = if v5.tier.PointsRequired <= v3 then 0 else 1
		end

		if not v8 then
			return
		end

		v8.Size = UDim2.fromScale(1, (thermometerFraction(v3)))
	end

	updateProgress()
	ClientPlayerData.serverProfile:subscribe(selectCookingPoints, updateProgress)
end

function t.Init(p1) --[[ Init | Line: 162 | Upvalues: CollectionService (copy), CookingProgressBoard (copy), setupBoard (copy) ]]
	for v1, v2 in CollectionService:GetTagged(CookingProgressBoard) do
		task.spawn(setupBoard, v2)
	end

	CollectionService:GetInstanceAddedSignal(CookingProgressBoard):Connect(function(p1) --[[ Line: 166 | Upvalues: setupBoard (ref) ]]
		task.spawn(setupBoard, p1)
	end)
end

return t