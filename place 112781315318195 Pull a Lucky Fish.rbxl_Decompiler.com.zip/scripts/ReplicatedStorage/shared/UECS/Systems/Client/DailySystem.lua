-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Players = game:GetService("Players")

game:GetService("ProximityPromptService")

local ReplicatedStorage = game:GetService("ReplicatedStorage")

game:GetService("ServerScriptService")
require(ReplicatedStorage.shared.config.AnimationConfig)
require(ReplicatedStorage.shared.UECS.Components.Animator)

local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)

require(ReplicatedStorage.shared.UECS.GlobalTypes)
require(ReplicatedStorage.shared.UECS.Components.OfflineEarnings)
require(ReplicatedStorage.shared.Remotes)
require(ReplicatedStorage.shared.UECS.Components.TrainToolComponent)
require(ReplicatedStorage.shared.UECS.UECS)
require(ReplicatedStorage.shared.UECS.Components.UIFrameOpener)

local Base = ReplicatedStorage.shared.model.Tycoon.Base

return {
	UECS = nil,
	Priority = 40,
	Init = function(p1) --[[ Init | Line: 21 | Upvalues: ClientPlayerData (copy), Players (copy) ]]
		repeat
			task.wait()
		until ClientPlayerData.isPlayerDataLoaded

		local function ShowOfflineEarningsFrame(p12) --[[ ShowOfflineEarningsFrame | Line: 26 | Upvalues: p1 (copy), Players (ref) ]]
			local v1 = p1.UECS:WaitForComponent(Players.LocalPlayer.PlayerGui.MainUI.OfflineEarnings, "OfflineEarnings")

			v1.OfflineEarned:Set(p12)
			p1.UECS:WaitForComponent(Players.LocalPlayer.PlayerGui.MainUI, "UIFrameOpener").OpenedUIComponent:Set(v1)
		end

		if ClientPlayerData.serverProfile:getState().offlineMoney > 0 then
			ShowOfflineEarningsFrame(ClientPlayerData.serverProfile:getState().offlineMoney)
		end

		ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 41 ]]
			return p1.offlineMoney
		end, function(p1) --[[ Line: 43 | Upvalues: ShowOfflineEarningsFrame (copy) ]]
			if not (p1 > 0) then
				return
			end

			ShowOfflineEarningsFrame(p1)
		end)
	end
}