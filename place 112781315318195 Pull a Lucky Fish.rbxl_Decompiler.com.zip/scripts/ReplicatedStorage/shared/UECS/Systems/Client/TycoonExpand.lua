-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local CashDisplay = require(ReplicatedStorage.shared.module.CashDisplay)
local CashFormat = require(ReplicatedStorage.shared.util.CashFormat)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Remotes = require(ReplicatedStorage.shared.Remotes)
local SFX = require(ReplicatedStorage.client.SFX)

require(ReplicatedStorage.shared.UECS.Components.TycoonComponent)

local TycoonLevelConfig = require(ReplicatedStorage.shared.config.TycoonLevelConfig)
local notifications = require(ReplicatedStorage.shared.module.notifications)
local v1 = Color3.fromRGB(255, 90, 90)

return {
	UECS = nil,
	Init = function(p1) --[[ Init | Line: 19 | Upvalues: Players (copy), ClientPlayerData (copy), TycoonLevelConfig (copy), CashDisplay (copy), notifications (copy), CashFormat (copy), v1 (copy), SFX (copy), Remotes (copy) ]]
		local LocalPlayer = Players.LocalPlayer
		local v12 = nil
		local v2 = nil

		local function applyBuySlotVisibility(p1, p2) --[[ applyBuySlotVisibility | Line: 27 ]]
			local InfoBoard = p1:FindFirstChild("InfoBoard")
			local v1 = if InfoBoard then InfoBoard:FindFirstChild("BuySlot") else InfoBoard

			if not v1 then
				return
			end

			local function applyTo(p1) --[[ applyTo | Line: 33 | Upvalues: p2 (copy) ]]
				if p1:IsA("BasePart") then
					p1.LocalTransparencyModifier = if p2 then 0 else 1
				else
					if not p1:IsA("SurfaceGui") then
						return
					end

					p1.Enabled = p2
				end
			end

			if v1:IsA("BasePart") then
				v1.LocalTransparencyModifier = if p2 then 0 else 1
			elseif v1:IsA("SurfaceGui") then
				v1.Enabled = p2
			end

			for v3, v4 in v1:GetDescendants() do
				if v4:IsA("BasePart") then
					v4.LocalTransparencyModifier = if p2 then 0 else 1

					continue
				end

				if v4:IsA("SurfaceGui") then
					v4.Enabled = p2
				end
			end
		end

		local function bindTycoonUI(p12) --[[ bindTycoonUI | Line: 46 | Upvalues: v12 (ref), ClientPlayerData (ref), TycoonLevelConfig (ref), CashDisplay (ref), v2 (ref), notifications (ref), CashFormat (ref), v1 (ref), p1 (copy), SFX (ref), Remotes (ref) ]]
			if v12 == p12 then
				return
			end

			v12 = p12

			local InfoBoard = p12:FindFirstChild("InfoBoard")

			if not InfoBoard then
				return
			end

			local BuySlot = InfoBoard:FindFirstChild("BuySlot")

			if not BuySlot then
				return
			end

			local UI = BuySlot:FindFirstChild("UI")
			local v13 = if UI then UI:FindFirstChildOfClass("SurfaceGui") else UI
			local v22 = if v13 then v13:FindFirstChild("Main") else v13

			if not v22 then
				return
			end

			local SlotNumberToUnlock = v22.TopBar:FindFirstChild("SlotNumberToUnlock")
			local BuySlotButton = v22:FindFirstChild("BuySlotButton")
			local v3 = BuySlotButton and BuySlotButton:FindFirstChild("Content") and BuySlotButton.Content:FindFirstChild("TextLabel")

			if not (SlotNumberToUnlock and (BuySlotButton and v3)) then
				return
			end

			local function refresh() --[[ refresh | Line: 73 | Upvalues: ClientPlayerData (ref), TycoonLevelConfig (ref), SlotNumberToUnlock (copy), CashDisplay (ref), v3 (copy) ]]
				local v1 = TycoonLevelConfig[(ClientPlayerData.serverProfile:getState().tycoonLevel or 1) + 1]

				if v1 then
					SlotNumberToUnlock.Text = ("Slots %*"):format(v1.Slots)
					CashDisplay.applyToLabel(v3, v1.UpgradeCost, {
						Compact = true
					})
				else
					SlotNumberToUnlock.Text = "MAX"
					CashDisplay.setPlainText(v3, "MAX")
				end
			end

			refresh()

			if v2 then
				v2()
				v2 = nil
			end

			v2 = ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 91 ]]
				return p1.tycoonLevel
			end, refresh)
			BuySlotButton.MouseButton1Down:Connect(function() --[[ Line: 95 | Upvalues: ClientPlayerData (ref), TycoonLevelConfig (ref), notifications (ref), CashFormat (ref), v1 (ref), p1 (ref), SFX (ref), Remotes (ref) ]]
				local v12 = ClientPlayerData.serverProfile:getState()
				local v2 = TycoonLevelConfig[(v12.tycoonLevel or 1) + 1]

				if not v2 then
					return
				end

				local v3 = v12.money or 0

				if not (v3 < v2.UpgradeCost) then
					SFX.new(SFX.Sounds.Buy, 0.5)
					Remotes.RequestBuySlotUpgrade:Fire()

					return
				end

				notifications:Send((("You need %* more!"):format((CashFormat.token(math.max(0, v2.UpgradeCost - v3), v1)))))

				local v6 = p1.UECS:WaitForAnyComponent("UIFrameOpener")
				local v7 = p1.UECS:WaitForAnyComponent("Store")

				if not (v6 and v7) then
					return
				end

				v6.OpenedUIComponent:Set(v7)
			end)
		end

		local function tryBind(p1) --[[ tryBind | Line: 125 | Upvalues: applyBuySlotVisibility (copy), LocalPlayer (copy), bindTycoonUI (copy) ]]
			local function applyVisibility() --[[ applyVisibility | Line: 126 | Upvalues: p1 (copy), applyBuySlotVisibility (ref), LocalPlayer (ref) ]]
				if not p1.Entity then
					return
				end

				applyBuySlotVisibility(p1.Entity, p1.Owner:Get() == LocalPlayer)
			end

			p1.Owner.OnChange:Connect(function(p12) --[[ Line: 132 | Upvalues: p1 (copy), applyBuySlotVisibility (ref), LocalPlayer (ref), bindTycoonUI (ref) ]]
				if p1.Entity then
					applyBuySlotVisibility(p1.Entity, p1.Owner:Get() == LocalPlayer)
				end

				if p12 ~= LocalPlayer or not p1.Entity then
					return
				end

				bindTycoonUI(p1.Entity)
			end)

			if p1.Entity then
				applyBuySlotVisibility(p1.Entity, p1.Owner:Get() == LocalPlayer)
			end

			if p1.Owner:Get() ~= LocalPlayer or not p1.Entity then
				return
			end

			bindTycoonUI(p1.Entity)
		end

		for k, v in pairs(p1.UECS:GetComponents("TycoonComponent")) do
			tryBind(v)
		end

		p1.UECS.OnComponentCreated("TycoonComponent"):Connect(tryBind)
	end
}