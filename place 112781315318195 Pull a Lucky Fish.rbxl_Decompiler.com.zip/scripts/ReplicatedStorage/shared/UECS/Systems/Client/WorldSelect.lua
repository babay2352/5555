-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ContentProvider = game:GetService("ContentProvider")
local ContextActionService = game:GetService("ContextActionService")
local GuiService = game:GetService("GuiService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")
local Workspace = game:GetService("Workspace")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local CashDisplay = require(ReplicatedStorage.shared.module.CashDisplay)
local CashFormat = require(ReplicatedStorage.shared.util.CashFormat)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local notifications = require(ReplicatedStorage.shared.module.notifications)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local Worlds = require(ReplicatedStorage.shared.util.Worlds)
local Worlds2 = require(ReplicatedStorage.shared.UECS.Components.Worlds)
local WorldsConfig = require(ReplicatedStorage.shared.config.WorldsConfig)
local bindToButtonPress = require(ReplicatedStorage.shared.util.bindToButtonPress)

task.spawn(function() --[[ Line: 64 | Upvalues: WorldsConfig (copy), ContentProvider (copy) ]]
	local t = {}

	for v1, v2 in WorldsConfig.Ordered() do
		if v2.Image ~= "" then
			table.insert(t, v2.Image)
		end
	end

	if not (#t > 0) then
		return
	end

	ContentProvider:PreloadAsync(t)
end)

local t = {
	UECS = nil,
	Priority = 30
}
local Travel = WorldsConfig.Travel

local function isEmitter(p1) --[[ isEmitter | Line: 103 ]]
	return p1:IsA("ParticleEmitter") or (p1:IsA("Beam") or (p1:IsA("Trail") or p1:IsA("Light")))
end

local function hideInstance(p1) --[[ hideInstance | Line: 107 ]]
	if p1:IsA("BasePart") then
		if p1:GetAttribute("WorldDecorSaved") == nil then
			p1:SetAttribute("WorldDecorSaved", (Vector3.new(p1.Transparency, if p1.CanCollide then 1 else 0, if p1.CastShadow then 1 else 0)))
		end

		p1.Transparency = 1
		p1.CanCollide = false
		p1.CastShadow = false
	elseif p1:IsA("Decal") or p1:IsA("Texture") then
		if p1:GetAttribute("WorldDecorSaved") == nil then
			p1:SetAttribute("WorldDecorSaved", p1.Transparency)
		end

		p1.Transparency = 1
	else
		if not (p1:IsA("ParticleEmitter") or (p1:IsA("Beam") or (p1:IsA("Trail") or p1:IsA("Light")))) then
			return
		end

		if p1:GetAttribute("WorldDecorSaved") == nil then
			p1:SetAttribute("WorldDecorSaved", p1.Enabled)
		end

		p1.Enabled = false

		if not (p1:IsA("ParticleEmitter") or p1:IsA("Trail")) then
			return
		end

		p1:Clear()
	end
end

local function showInstance(p1) --[[ showInstance | Line: 140 ]]
	local v1 = p1:GetAttribute("WorldDecorSaved")

	if v1 == nil then
		return
	end

	if p1:IsA("BasePart") and typeof(v1) == "Vector3" then
		p1.Transparency = v1.X
		p1.CanCollide = v1.Y > 0.5
		p1.CastShadow = v1.Z > 0.5
	elseif (p1:IsA("Decal") or p1:IsA("Texture")) and typeof(v1) == "number" then
		p1.Transparency = v1
	else
		local v4

		v4 = p1:IsA("ParticleEmitter") or (p1:IsA("Beam") or (p1:IsA("Trail") or p1:IsA("Light")))

		if v4 and typeof(v1) == "boolean" then
			p1.Enabled = v1
		end
	end

	p1:SetAttribute("WorldDecorSaved", nil)
end

local t2 = {}

local function setWatcher(p1, p2, p3) --[[ setWatcher | Line: 161 | Upvalues: t2 (copy), hideInstance (copy) ]]
	local v1 = t2[p1]

	if v1 then
		v1:Disconnect()
		t2[p1] = nil
	end

	if not (p3 and p2) then
		return
	end

	t2[p1] = p2.DescendantAdded:Connect(hideInstance)
end

local function decorFolderFor(p1) --[[ decorFolderFor | Line: 172 | Upvalues: WorldsConfig (copy), Workspace (copy) ]]
	local v1 = WorldsConfig.Get(p1)
	local v2 = if v1 then v1.DecorFolderName else v1

	if not v2 then
		return nil
	end

	local Map = Workspace:FindFirstChild("Map")

	return if Map then Map:FindFirstChild(v2) else Map
end

local function applyVisibility(p1, p2, p3) --[[ applyVisibility | Line: 185 | Upvalues: showInstance (copy), hideInstance (copy), Travel (copy), RunService (copy) ]]
	local v1 = p1:GetDescendants()
	local count = 0

	for v2, v3 in v1 do
		if p2 then
			showInstance(v3)
		else
			hideInstance(v3)
		end

		count = count + 1

		if count % Travel.SwapBatchSize == 0 then
			if p3 then
				p3(count)
			end

			RunService.Heartbeat:Wait()
		end
	end

	if not p3 then
		return #v1
	end

	p3(count)

	return #v1
end

local function zoneChunks(p1) --[[ zoneChunks | Line: 213 ]]
	local t = {}

	for v1, v2 in p1:GetChildren() do
		local t2 = {
			container = v2
		}

		t2.ordinal = tonumber(v2.Name) or (1 / 0)
		table.insert(t, t2)
	end

	return t
end

local function applyWorldDecor(p1, p2) --[[ applyWorldDecor | Line: 223 | Upvalues: WorldsConfig (copy), Workspace (copy), t2 (copy), hideInstance (copy), zoneChunks (copy), applyVisibility (copy) ]]
	for v2, v3 in WorldsConfig.Ordered() do
		local v1
		local v4 = WorldsConfig.Get(v3.Id)
		local v5 = if v4 then v4.DecorFolderName else v4

		if v5 then
			local Map = Workspace:FindFirstChild("Map")

			v1 = Map and Map:FindFirstChild(v5)
		else
			v1 = nil
		end

		local Id2 = v3.Id
		local v7 = if v3.Id == p1 then false else true
		local v8 = t2[Id2]

		if v8 then
			v8:Disconnect()
			t2[Id2] = nil
		end

		if v7 and v1 then
			t2[Id2] = v1.DescendantAdded:Connect(hideInstance)
		end
	end

	local sum = 0
	local t = {}

	for v10, v11 in WorldsConfig.Ordered() do
		local v9
		local v12 = WorldsConfig.Get(v11.Id)
		local v13 = if v12 then v12.DecorFolderName else v12

		if v13 then
			local Map = Workspace:FindFirstChild("Map")

			v9 = Map and Map:FindFirstChild(v13)
		else
			v9 = nil
		end

		if v9 then
			local v15 = if v11.Id == p1 then true else false

			for v16, v17 in zoneChunks(v9) do
				local v18 = #v17.container:GetDescendants()

				table.insert(t, {
					container = v17.container,
					visible = v15,
					count = v18,
					ordinal = v17.ordinal
				})
				sum = sum + v18
			end
		end
	end

	if sum ~= 0 then
		table.sort(t, function(p1, p2) --[[ Line: 267 ]]
			if p1.ordinal == p2.ordinal then
				return not p1.visible and p2.visible
			end

			return p1.ordinal < p2.ordinal
		end)

		local sum2 = 0

		for v19, v20 in t do
			applyVisibility(v20.container, v20.visible, function(p1) --[[ Line: 276 | Upvalues: p2 (copy), sum2 (ref), sum (ref) ]]
				if not p2 then
					return
				end

				p2((math.clamp((sum2 + p1) / sum, 0, 1)))
			end)
			sum2 = sum2 + v20.count
		end
	end

	if p2 then
		p2(1)
	end
end

function t.Init(p1) --[[ Init | Line: 289 | Upvalues: Players (copy), Worlds2 (copy), bindToButtonPress (copy), UserInputService (copy), GuiService (copy), ContextActionService (copy), ReplicatedStorage (copy), Travel (copy), TweenService (copy), WorldsConfig (copy), CashFormat (copy), ClientPlayerData (copy), CashDisplay (copy), applyWorldDecor (copy), Worlds (copy), notifications (copy), Remotes (copy), RunService (copy), t (copy) ]]
	local MainUI = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI")
	local Worlds3 = MainUI:WaitForChild("Worlds")
	local v1 = Worlds3:WaitForChild("Content")
	local TopBar = Worlds3:WaitForChild("TopBar")
	local Template = v1:WaitForChild("Template")
	local WorldLoading = MainUI:WaitForChild("WorldLoading")
	local Title = WorldLoading:WaitForChild("Title")
	local Bar = WorldLoading:WaitForChild("BarBg"):WaitForChild("Bar")
	local Tip = WorldLoading:WaitForChild("Tip")

	Worlds3.Visible = false
	Template.Visible = false
	WorldLoading.Visible = false
	WorldLoading.GroupTransparency = 1

	local v2 = Worlds2.Add(Worlds3)

	local function closeFrame() --[[ closeFrame | Line: 309 | Upvalues: p1 (copy) ]]
		p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
	end

	v2.Visible.OnChange:Connect(function(p1, p2) --[[ Line: 314 | Upvalues: Worlds3 (copy), bindToButtonPress (ref), closeFrame (copy), UserInputService (ref), GuiService (ref), v1 (copy), ContextActionService (ref) ]]
		Worlds3.Visible = p1

		if p1 == p2 then
			return
		end

		if p1 then
			bindToButtonPress("WorldSelectCloseAction", Enum.KeyCode.ButtonB, closeFrame)

			if UserInputService.PreferredInput == Enum.PreferredInput.Gamepad then
				GuiService:Select(v1)
			end
		else
			ContextActionService:UnbindAction("WorldSelectCloseAction")

			local SelectedObject = GuiService.SelectedObject

			if not (SelectedObject and SelectedObject:IsDescendantOf(Worlds3)) then
				return
			end

			GuiService.SelectedObject = nil
		end
	end)
	GuiService:GetPropertyChangedSignal("SelectedObject"):Connect(function() --[[ Line: 335 | Upvalues: UserInputService (ref), GuiService (ref), v2 (copy), Worlds3 (copy), v1 (copy) ]]
		if UserInputService.PreferredInput ~= Enum.PreferredInput.Gamepad then
			return
		end

		local SelectedObject = GuiService.SelectedObject

		if not v2.Visible:Get() or SelectedObject and SelectedObject:IsDescendantOf(Worlds3) then
			return
		end

		task.defer(GuiService.Select, GuiService, v1)
	end)
	TopBar:WaitForChild("CloseButton").MouseButton1Down:Connect(closeFrame)

	local function setCoverShown(p1, p2) --[[ setCoverShown | Line: 351 | Upvalues: ReplicatedStorage (ref), WorldLoading (copy), Title (copy), Travel (ref), Tip (copy), Bar (copy), TweenService (ref) ]]
		local Satchel = require(ReplicatedStorage.client.Satchel)

		if p1 then
			WorldLoading.Visible = true
			Title.Text = Travel.LoadingTitle
			Tip.Text = p2 or ""
			Bar.Size = UDim2.fromScale(0, 1)
			Satchel.SetEnabled(false)
		end

		local v5 = TweenInfo.new(if p1 then Travel.FadeInTime else Travel.FadeOutTime, Enum.EasingStyle.Quad)
		local t = {}

		t.GroupTransparency = if p1 then 0 else 1

		local v7 = TweenService:Create(WorldLoading, v5, t)

		v7:Play()
		v7.Completed:Wait()

		if p1 then
			return
		end

		WorldLoading.Visible = false
		Satchel.SetEnabled(true)
	end

	local function setProgress(p1) --[[ setProgress | Line: 373 | Upvalues: Bar (copy) ]]
		Bar.Size = UDim2.fromScale(math.clamp(p1, 0, 1), 1)
	end

	local v3 = false
	local t2 = {}

	local function isUnlocked(p1, p2) --[[ isUnlocked | Line: 381 ]]
		if not p2.Unlock then
			return true
		end

		return table.find(if p1 then p1.unlockedWorlds or {} else {}, p2.Id) ~= nil
	end

	local function missingParts(p1, p2) --[[ missingParts | Line: 398 | Upvalues: WorldsConfig (ref), CashFormat (ref) ]]
		local v1 = WorldsConfig.GetUnlockProgress(p1, p2)
		local t = {}

		if v1.NeedsRebirth then
			table.insert(t, (("Rebirth %*"):format(p2.RebirthLevel or 0)))
		end

		if v1.NeedsCash then
			table.insert(t, CashFormat.token(p2.CashCost or 0))
		end

		if v1.NeedsRarity then
			table.insert(t, (("%*/%* caught %* fish"):format(v1.RarityCaught, v1.RarityRequired, if p2.RarityCaught then p2.RarityCaught.RarityId else "")))
		end

		return t
	end

	local function missingRequirement(p1, p2) --[[ missingRequirement | Line: 423 | Upvalues: missingParts (copy) ]]
		local v1

		if p2.Unlock then
			local find = table.find

			v1 = if find(p1 and p1.unlockedWorlds or {}, p2.Id) == nil then false else true
		else
			v1 = true
		end

		if v1 then
			return nil
		end

		local Unlock = p2.Unlock

		if not Unlock then
			return nil
		end

		local v3 = missingParts(p1, Unlock)

		if #v3 == 0 then
			return nil
		end

		return ("You need %* to go here."):format((table.concat(v3, " and ")))
	end

	local function lockedReason(p1, p2) --[[ lockedReason | Line: 440 | Upvalues: missingParts (copy), CashFormat (ref) ]]
		local v1

		if p2.Unlock then
			local find = table.find

			v1 = if find(p1 and p1.unlockedWorlds or {}, p2.Id) == nil then false else true
		else
			v1 = true
		end

		if v1 then
			return nil
		end

		local Unlock = p2.Unlock

		if not Unlock then
			return nil
		end

		local v3 = missingParts(p1, Unlock)

		if #v3 > 0 then
			return ("\240\159\148\146 %*"):format((table.concat(v3, " + ")))
		end

		if Unlock.CashCost then
			return ("Unlock for %*"):format((CashFormat.token(Unlock.CashCost)))
		end

		return "Unlock"
	end

	local v4 = nil

	local function buildTiles() --[[ buildTiles | Line: 463 | Upvalues: t2 (copy), WorldsConfig (ref), Template (copy), v1 (copy), v4 (ref) ]]
		for v12, v2 in t2 do
			v2:Destroy()
		end

		table.clear(t2)

		for v3, v42 in WorldsConfig.Ordered() do
			local v5 = Template:Clone()

			v5.Name = "World" .. v42.Id
			v5.LayoutOrder = v42.LayoutOrder
			v5.SelectionOrder = v42.LayoutOrder
			v5.Selectable = true
			v5.Visible = true
			v5.Parent = v1

			local Image = v5:FindFirstChild("Image")

			if Image then
				Image.Image = v42.Image
				Image.Visible = v42.Image ~= ""
			end

			local Title = v5:FindFirstChild("Title")

			if Title then
				Title.Text = v42.Title
			end

			local Subtitle = v5:FindFirstChild("Subtitle")

			if Subtitle then
				Subtitle.Text = v42.Subtitle or ""
				Subtitle.Visible = v42.Subtitle ~= nil
			end

			v5.Activated:Connect(function() --[[ Line: 495 | Upvalues: v4 (ref), v42 (copy) ]]
				v4(v42.Id)
			end)
			t2[v42.Id] = v5
		end
	end

	local function refreshLocks() --[[ refreshLocks | Line: 505 | Upvalues: ClientPlayerData (ref), WorldsConfig (ref), t2 (copy), lockedReason (copy), CashDisplay (ref) ]]
		local v1 = ClientPlayerData.serverProfile:getState()

		for v2, v3 in WorldsConfig.Ordered() do
			local v4 = t2[v3.Id]
			local v5 = if v4 then v4:FindFirstChild("Lock") else v4

			if v5 then
				local v6 = lockedReason(v1, v3)

				v5.Visible = v6 ~= nil

				local Text = v5:FindFirstChild("Text")

				if Text and v6 then
					CashDisplay.applyTokens(Text, v6, {
						Compact = true
					})
				end
			end
		end
	end

	local function runSwap(p1) --[[ runSwap | Line: 523 | Upvalues: applyWorldDecor (ref), setProgress (copy) ]]
		applyWorldDecor(p1, setProgress)
	end

	v4 = function(p12) --[[ Line: 527 | Upvalues: v3 (ref), Worlds (ref), p1 (copy), WorldsConfig (ref), ClientPlayerData (ref), missingParts (copy), notifications (ref), setCoverShown (copy), Remotes (ref), RunService (ref), applyWorldDecor (ref), setProgress (copy), Travel (ref), refreshLocks (copy) ]]
		if v3 then
			return
		end

		if Worlds.GetLocalWorldId() == p12 then
			p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)

			return
		end

		local v1 = WorldsConfig.Get(p12)

		if not v1 then
			return
		end

		local v2 = ClientPlayerData.serverProfile:getState()
		local v32

		if v1.Unlock then
			local find = table.find

			v32 = if find(v2 and v2.unlockedWorlds or {}, v1.Id) == nil then false else true
		else
			v32 = true
		end

		local v5

		if v32 then
			v5 = nil
		else
			local Unlock = v1.Unlock

			if Unlock then
				local v6 = missingParts(v2, Unlock)

				v5 = if #v6 == 0 then nil else ("You need %* to go here."):format((table.concat(v6, " and ")))
			else
				v5 = nil
			end
		end

		if v5 then
			notifications:Send(v5)
		else
			v3 = true
			task.spawn(function() --[[ Line: 553 | Upvalues: p1 (ref), setCoverShown (ref), v1 (copy), Remotes (ref), p12 (copy), notifications (ref), v3 (ref), Worlds (ref), RunService (ref), applyWorldDecor (ref), setProgress (ref), Travel (ref), refreshLocks (ref) ]]
				local v12 = os.clock()

				p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
				setCoverShown(true, v1.Title)

				local v2, v32 = Remotes.TravelToWorld:Call(p12):Await()

				if v2 and (typeof(v32) == "table" and v32.ok) then
					local v4 = Worlds.GetLocalWorldId()

					if v4 ~= p12 then
						local v5 = os.clock() + 3

						while Worlds.GetLocalWorldId() ~= p12 and os.clock() < v5 do
							RunService.Heartbeat:Wait()
						end

						v4 = Worlds.GetLocalWorldId()
					end

					if v4 ~= p12 then
						warn(("[WorldSelect] travel to world %* was accepted but %* "):format(p12, Worlds.Attribute) .. ("is still %* \226\128\148 the swap will do nothing"):format(v4))
					end

					applyWorldDecor(v4, setProgress)

					local v7 = os.clock() - v12

					if not (v7 < Travel.MinCoverTime) then
						setCoverShown(false)
						v3 = false
						refreshLocks()

						return
					end

					task.wait(Travel.MinCoverTime - v7)
					setCoverShown(false)
					v3 = false
					refreshLocks()
				else
					notifications:Send(if typeof(v32) == "table" then v32.reason or "Could not travel. Try again." else "Could not travel. Try again.")
					setCoverShown(false)
					v3 = false
				end
			end)
		end
	end
	buildTiles()
	refreshLocks()
	ClientPlayerData.serverProfile:subscribe(refreshLocks)
	task.spawn(function() --[[ Line: 614 | Upvalues: Worlds (ref), WorldsConfig (ref), applyWorldDecor (ref), v3 (ref), setCoverShown (copy), setProgress (copy) ]]
		local v1 = Worlds.GetLocalWorldId()

		if v1 == WorldsConfig.DefaultWorldId then
			applyWorldDecor(v1)

			return
		end

		v3 = true

		local v2 = WorldsConfig.Get(v1)

		setCoverShown(true, if v2 then v2.Title else v2)
		applyWorldDecor(v1, setProgress)
		setCoverShown(false)
		v3 = false
	end)
	Worlds.OnLocalWorldChanged(function(p1) --[[ Line: 629 | Upvalues: v3 (ref), WorldsConfig (ref), setCoverShown (copy), applyWorldDecor (ref), setProgress (copy), Travel (ref), refreshLocks (copy) ]]
		if not v3 then
			v3 = true
			task.spawn(function() --[[ Line: 634 | Upvalues: WorldsConfig (ref), p1 (copy), setCoverShown (ref), applyWorldDecor (ref), setProgress (ref), Travel (ref), v3 (ref), refreshLocks (ref) ]]
				local v1 = WorldsConfig.Get(p1)

				setCoverShown(true, if v1 then v1.Title else v1)
				applyWorldDecor(p1, setProgress)
				task.wait(Travel.MinCoverTime)
				setCoverShown(false)
				v3 = false
				refreshLocks()
			end)
		end
	end)
	function t.TravelTo(p1) --[[ Line: 650 | Upvalues: v4 (ref) ]]
		v4(p1)
	end
	function t.Open() --[[ Line: 655 | Upvalues: p1 (copy), v2 (copy) ]]
		p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(v2)
	end
	require(ReplicatedStorage.shared.UECS.Systems.Client.DialogController).Actions.OPEN_WORLD_SELECT = function() --[[ Line: 664 | Upvalues: t (ref) ]]
		t.Open()
	end
end

return t