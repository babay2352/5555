-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local AdService = game:GetService("AdService")
local ContextActionService = game:GetService("ContextActionService")
local Lighting = game:GetService("Lighting")
local MarketplaceService = game:GetService("MarketplaceService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local SoundService = game:GetService("SoundService")
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")
local Workspace = game:GetService("Workspace")
local CashDisplay = require(ReplicatedStorage.shared.module.CashDisplay)
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local CollectFishUI = require(ReplicatedStorage.shared.module.CollectFishUI)
local DeepsConfig = require(ReplicatedStorage.shared.config.DeepsConfig)
local DeepsGearConfig = require(ReplicatedStorage.shared.config.DeepsGearConfig)
local DeepsLootConfig = require(ReplicatedStorage.shared.config.DeepsLootConfig)
local DeepsLootFeed = require(ReplicatedStorage.client.DeepsLootFeed)
local DeepsState = require(ReplicatedStorage.client.DeepsState)
local FishConfig = require(ReplicatedStorage.shared.config.FishConfig)
local FishEarnings = require(ReplicatedStorage.shared.util.FishEarnings)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Remotes = require(ReplicatedStorage.shared.Remotes)
local SFX = require(ReplicatedStorage.client.SFX)
local Satchel = require(ReplicatedStorage.client.Satchel)
local ThrowFX = require(ReplicatedStorage.client.throw.ThrowFX)
local WeatherEffects = require(ReplicatedStorage.shared.effects.WeatherEffects)
local Worlds = require(ReplicatedStorage.shared.util.Worlds)
local bindToButtonPress = require(ReplicatedStorage.shared.util.bindToButtonPress)
local popInGui = require(ReplicatedStorage.shared.util.popInGui)
local t = {
	UECS = nil
}
local Swim = DeepsConfig.Swim
local Oxygen = DeepsConfig.Oxygen
local Minigame = DeepsConfig.Minigame
local v1 = Color3.fromRGB(255, 80, 80)
local v2 = Color3.fromRGB(110, 210, 255)
local v3 = Color3.new(0/255, 0/255, 0/255)
local LocalPlayer = Players.LocalPlayer

local function getCharacterParts() --[[ getCharacterParts | Line: 88 | Upvalues: LocalPlayer (copy) ]]
	local Character = LocalPlayer.Character

	if not Character then
		return nil, nil
	end

	local Humanoid = Character:FindFirstChildOfClass("Humanoid")
	local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")

	if HumanoidRootPart and HumanoidRootPart:IsA("BasePart") then
		return Humanoid, HumanoidRootPart
	end

	return Humanoid, nil
end

local v4 = nil

local function getControls() --[[ getControls | Line: 101 | Upvalues: v4 (ref), LocalPlayer (copy) ]]
	if v4 then
		return v4
	end

	local PlayerScripts = LocalPlayer:FindFirstChild("PlayerScripts")
	local v1 = PlayerScripts and PlayerScripts:FindFirstChild("PlayerModule")

	if not (v1 and v1:IsA("ModuleScript")) then
		return nil
	end

	local ok, result = pcall(function() --[[ Line: 110 | Upvalues: v1 (copy) ]]
		return require(v1):GetControls()
	end)

	if ok then
		v4 = result

		return result
	end

	return nil
end

local function setGameHudEnabled(p1) --[[ setGameHudEnabled | Line: 120 | Upvalues: Satchel (copy) ]]
	pcall(function() --[[ Line: 121 | Upvalues: Satchel (ref), p1 (copy) ]]
		Satchel.SetEnabled(p1)
	end)
end

local GetSurfaceY = DeepsConfig.GetSurfaceY
local IsInsideVolume = DeepsConfig.IsInsideVolume

local function zoneForDepth(p1) --[[ zoneForDepth | Line: 131 | Upvalues: DeepsConfig (copy) ]]
	for v1, v2 in DeepsConfig.Zones do
		if v2.FromDepth <= p1 and p1 < v2.ToDepth then
			return v1
		end
	end

	local v3 = #DeepsConfig.Zones

	if v3 > 0 and DeepsConfig.Zones[v3].FromDepth <= p1 then
		return v3
	end

	return nil
end

local function getGear() --[[ getGear | Line: 145 | Upvalues: ClientPlayerData (copy) ]]
	return ClientPlayerData.serverProfile:getState().deepsGear
end

local function getBag() --[[ getBag | Line: 150 | Upvalues: ClientPlayerData (copy) ]]
	local v1 = ClientPlayerData.serverProfile:getState()

	return if v1.deeps then v1.deeps.bag or {} else {}
end

local function entryDisplayName(p1) --[[ entryDisplayName | Line: 155 | Upvalues: FishConfig (copy), DeepsLootConfig (copy) ]]
	if p1.Type == "Fish" then
		return FishConfig[p1.Name] and FishConfig[p1.Name].DisplayName or p1.Name
	end

	return DeepsLootConfig.Items[p1.Name] and DeepsLootConfig.Items[p1.Name].DisplayName or p1.Name
end

local function entryColor(p1) --[[ entryColor | Line: 164 | Upvalues: FishConfig (copy), DeepsLootConfig (copy) ]]
	local v1 = if p1.Type == "Fish" then FishConfig[p1.Name] else DeepsLootConfig.Items[p1.Name]

	return v1 and v1.Rarity and v1.Rarity.rarityColor or Color3.new(255/255, 255/255, 255/255)
end

local v5 = nil

local function totalZoneDepth() --[[ totalZoneDepth | Line: 193 | Upvalues: DeepsConfig (copy) ]]
	local v1 = DeepsConfig.Zones[#DeepsConfig.Zones]

	if v1 then
		return v1.ToDepth
	end

	return 1
end

local function setupZoneFrame(p1) --[[ setupZoneFrame | Line: 207 | Upvalues: DeepsConfig (copy), Worlds (copy), Players (copy), LocalPlayer (copy) ]]
	local ClipFrame = p1:FindFirstChild("ClipFrame")
	local v1 = ClipFrame and ClipFrame:FindFirstChild("Bar")
	local v2 = if v1 then v1:FindFirstChild("Template") else v1
	local UserProgress = p1:FindFirstChild("UserProgress")

	if not (ClipFrame and (ClipFrame:IsA("GuiObject") and (v1 and (v1:IsA("GuiObject") and (v2 and (v2:IsA("Frame") and (UserProgress and UserProgress:IsA("ImageLabel")))))))) then
		warn("[DeepsDiving] Deeps.ZoneFrame is missing ClipFrame.Bar.Template / UserProgress \226\128\148 no depth bar")

		return nil
	end

	ClipFrame.ClipsDescendants = true

	local UIListLayout = v1:FindFirstChildOfClass("UIListLayout")

	if UIListLayout then
		UIListLayout.FillDirection = Enum.FillDirection.Vertical
		UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder
	end

	for v3, v4 in v1:GetChildren() do
		if v4.Name == "ZonePanel" then
			v4:Destroy()
		end
	end

	local v5 = DeepsConfig.Zones[#DeepsConfig.Zones]
	local v6 = if v5 then v5.ToDepth else 1
	local v7 = v6 / DeepsConfig.DepthBarViewportDepth

	v1.AnchorPoint = Vector2.new(0, 0)
	v1.BackgroundTransparency = 1
	v1.Position = UDim2.new(0, 0, 0, 0)
	v1.Size = UDim2.new(1, 0, v7, 0)

	for v8, v9 in DeepsConfig.Zones do
		local ZonePanel = v2:Clone()

		ZonePanel.Name = "ZonePanel"
		ZonePanel.LayoutOrder = v8
		ZonePanel.AnchorPoint = Vector2.new(0, 0)
		ZonePanel.Position = UDim2.new(0, 0, 0, 0)
		ZonePanel.Size = UDim2.new(1, 0, (v9.ToDepth - v9.FromDepth) / v6, 0)
		ZonePanel.Visible = true

		local ZoneName = ZonePanel:FindFirstChild("ZoneName")

		if ZoneName and ZoneName:IsA("TextLabel") then
			ZoneName.Text = v9.DisplayName
			ZoneName.Position = UDim2.new(0, 0, 0, 0)
			ZoneName.Size = UDim2.new(1, 0, 1, 0)
		end

		local UIGradient = ZonePanel:FindFirstChildOfClass("UIGradient")

		if UIGradient then
			local v10 = Worlds.GetBiomeById(v9.BiomeId)

			if v10 then
				UIGradient.Color = v10.DisplayColor
			end

			UIGradient.Rotation = 90
		end

		local MilestoneBadge = ZonePanel:FindFirstChild("MilestoneBadge")

		if MilestoneBadge then
			MilestoneBadge:Destroy()
		end

		ZonePanel.Parent = v1
	end

	UserProgress.AnchorPoint = Vector2.new(1, 0.5)

	local Luck = UserProgress:FindFirstChild("Luck")

	if not (Luck and Luck:IsA("GuiObject")) then
		task.spawn(function() --[[ Line: 284 | Upvalues: Players (ref), LocalPlayer (ref), UserProgress (copy) ]]
			local ok, result = pcall(function() --[[ Line: 285 | Upvalues: Players (ref), LocalPlayer (ref) ]]
				return Players:GetUserThumbnailAsync(LocalPlayer.UserId, Enum.ThumbnailType.HeadShot, Enum.ThumbnailSize.Size420x420)
			end)

			if not ok or (typeof(result) ~= "string" or not UserProgress.Parent) then
				return
			end

			UserProgress.Image = result
		end)

		return function(p13) --[[ Line: 304 | Upvalues: DeepsConfig (ref), v7 (copy), v1 (copy), UserProgress (copy) ]]
			local DepthBarViewportDepth = DeepsConfig.DepthBarViewportDepth
			local v2 = math.clamp(0.5 - p13 / DepthBarViewportDepth, 1 - v7, 0)

			v1.Position = UDim2.new(0, 0, v2, 0)
			UserProgress.Position = UDim2.new(0, -20, p13 / DepthBarViewportDepth + v2, 0)
		end
	end

	Luck.Visible = false
	task.spawn(function() --[[ Line: 284 | Upvalues: Players (ref), LocalPlayer (ref), UserProgress (copy) ]]
		local ok, result = pcall(function() --[[ Line: 285 | Upvalues: Players (ref), LocalPlayer (ref) ]]
			return Players:GetUserThumbnailAsync(LocalPlayer.UserId, Enum.ThumbnailType.HeadShot, Enum.ThumbnailSize.Size420x420)
		end)

		if not ok or (typeof(result) ~= "string" or not UserProgress.Parent) then
			return
		end

		UserProgress.Image = result
	end)

	return function(p13) --[[ Line: 304 | Upvalues: DeepsConfig (ref), v7 (copy), v1 (copy), UserProgress (copy) ]]
		local DepthBarViewportDepth = DeepsConfig.DepthBarViewportDepth
		local v2 = math.clamp(0.5 - p13 / DepthBarViewportDepth, 1 - v7, 0)

		v1.Position = UDim2.new(0, 0, v2, 0)
		UserProgress.Position = UDim2.new(0, -20, p13 / DepthBarViewportDepth + v2, 0)
	end
end

local function buildTemplateHud() --[[ buildTemplateHud | Line: 318 | Upvalues: LocalPlayer (copy), DeepsConfig (copy), popInGui (copy), setupZoneFrame (copy) ]]
	local PlayerGui = LocalPlayer:FindFirstChildOfClass("PlayerGui")
	local v1 = if PlayerGui then PlayerGui:FindFirstChild("MainUI") else PlayerGui
	local v2 = v1 and v1:FindFirstChild(DeepsConfig.UiFrameName)

	if not (v2 and v2:IsA("Frame")) then
		return nil
	end

	local OxygenBar = v2:FindFirstChild("OxygenBar")
	local v3 = if OxygenBar then OxygenBar:FindFirstChild("Filler") else OxygenBar

	if not (OxygenBar and (v3 and v3:IsA("Frame"))) then
		warn((("[DeepsDiving] MainUI.%* is missing OxygenBar.Filler \226\128\148 using the fallback HUD"):format(DeepsConfig.UiFrameName)))

		return nil
	end

	local v4 = OxygenBar:FindFirstChild("Label") or OxygenBar:FindFirstChild("FishCapacity")
	local BackpackImage = OxygenBar:FindFirstChild("BackpackImage")
	local v5 = if BackpackImage then BackpackImage:FindFirstChild("CapacityLabel") else BackpackImage

	v2.Visible = true

	if OxygenBar:IsA("GuiObject") then
		popInGui(OxygenBar, true)
	end

	local function textChild(p1) --[[ textChild | Line: 341 | Upvalues: v2 (copy) ]]
		local v1 = v2:FindFirstChild(p1)

		if v1 and v1:IsA("TextLabel") then
			return v1
		end

		return nil
	end

	local BagList = v2:FindFirstChild("BagList")
	local BagLabel = v2:FindFirstChild("BagLabel")
	local v6 = if BagLabel and BagLabel:IsA("TextLabel") then BagLabel else nil

	if v5 and (v5:IsA("TextLabel") and v6) then
		v6.Visible = false
		v6 = nil
	end

	local ZoneFrame = v2:FindFirstChild("ZoneFrame")

	if ZoneFrame and ZoneFrame:IsA("GuiObject") then
		ZoneFrame.Visible = true
	end

	local t = {
		template = true,
		root = v2,
		frame = v2,
		oxygenFill = v3
	}

	t.oxygenLabel = if v4 and v4:IsA("TextLabel") then v4 else nil

	local DepthLabel = v2:FindFirstChild("DepthLabel")

	t.depthLabel = if DepthLabel and DepthLabel:IsA("TextLabel") then DepthLabel else nil
	t.bagLabel = v6
	t.bagList = if BagList and BagList:IsA("GuiObject") then BagList else nil
	t.capacityLabel = if v5 and v5:IsA("TextLabel") then v5 else nil
	t.updateDepth = if ZoneFrame and ZoneFrame:IsA("GuiObject") then setupZoneFrame(ZoneFrame) else nil

	return t
end

local function buildFallbackHud() --[[ buildFallbackHud | Line: 370 | Upvalues: LocalPlayer (copy), v2 (copy) ]]
	local DeepsHud = Instance.new("ScreenGui")

	DeepsHud.Name = "DeepsHud"
	DeepsHud.ResetOnSpawn = false
	DeepsHud.DisplayOrder = 50
	DeepsHud.Parent = LocalPlayer:WaitForChild("PlayerGui")

	local OxygenBar = Instance.new("Frame")

	OxygenBar.Name = "OxygenBar"
	OxygenBar.AnchorPoint = Vector2.new(0.5, 1)
	OxygenBar.Position = UDim2.new(0.5, 0, 1, -24)
	OxygenBar.Size = UDim2.new(0.24, 0, 0, 26)
	OxygenBar.BackgroundColor3 = Color3.fromRGB(25, 25, 25)
	OxygenBar.BorderSizePixel = 0
	OxygenBar.Parent = DeepsHud

	local UISizeConstraint = Instance.new("UISizeConstraint")

	UISizeConstraint.MinSize = Vector2.new(220, 26)
	UISizeConstraint.MaxSize = Vector2.new(380, 26)
	UISizeConstraint.Parent = OxygenBar

	local UICorner = Instance.new("UICorner")

	UICorner.CornerRadius = UDim.new(0, 8)
	UICorner.Parent = OxygenBar

	local Filler = Instance.new("Frame")

	Filler.Name = "Filler"
	Filler.Size = UDim2.fromScale(1, 1)
	Filler.BackgroundColor3 = v2
	Filler.BorderSizePixel = 0
	Filler.Parent = OxygenBar

	local UICorner2 = Instance.new("UICorner")

	UICorner2.CornerRadius = UDim.new(0, 8)
	UICorner2.Parent = Filler

	local Label = Instance.new("TextLabel")

	Label.Name = "Label"
	Label.Size = UDim2.fromScale(1, 1)
	Label.BackgroundTransparency = 1
	Label.Font = Enum.Font.GothamBlack
	Label.TextSize = 15
	Label.TextColor3 = Color3.new(255/255, 255/255, 255/255)
	Label.TextStrokeTransparency = 0.4
	Label.Text = ""
	Label.ZIndex = 2
	Label.Parent = OxygenBar

	local function makeLine(p1, p2, p3) --[[ makeLine | Line: 415 | Upvalues: DeepsHud (copy) ]]
		local TextLabel = Instance.new("TextLabel")

		TextLabel.Name = p1
		TextLabel.AnchorPoint = Vector2.new(0.5, 1)
		TextLabel.Position = UDim2.new(0.5, 0, 1, p2)
		TextLabel.Size = UDim2.fromOffset(320, 20)
		TextLabel.BackgroundTransparency = 1
		TextLabel.Font = Enum.Font.GothamBlack
		TextLabel.TextSize = p3
		TextLabel.TextColor3 = Color3.new(255/255, 255/255, 255/255)
		TextLabel.TextStrokeTransparency = 0.4
		TextLabel.Text = ""
		TextLabel.Parent = DeepsHud

		return TextLabel
	end

	local v1 = makeLine("DepthLabel", -2, 16)
	local BagList = Instance.new("Frame")

	BagList.Name = "BagList"
	BagList.AnchorPoint = Vector2.new(1, 0.5)
	BagList.Position = UDim2.new(1, -16, 0.5, 0)
	BagList.Size = UDim2.fromOffset(200, 300)
	BagList.BackgroundTransparency = 1
	BagList.Parent = DeepsHud

	local UIListLayout = Instance.new("UIListLayout")

	UIListLayout.Padding = UDim.new(0, 4)
	UIListLayout.VerticalAlignment = Enum.VerticalAlignment.Center
	UIListLayout.Parent = BagList

	local BagLabel = Instance.new("TextLabel")

	BagLabel.Name = "BagLabel"
	BagLabel.AnchorPoint = Vector2.new(1, 0.5)
	BagLabel.Position = UDim2.new(1, -16, 0.5, -160)
	BagLabel.Size = UDim2.fromOffset(200, 22)
	BagLabel.BackgroundTransparency = 1
	BagLabel.Font = Enum.Font.GothamBlack
	BagLabel.TextSize = 18
	BagLabel.TextColor3 = Color3.fromRGB(255, 210, 120)
	BagLabel.TextStrokeTransparency = 0.4
	BagLabel.Text = ""
	BagLabel.Parent = DeepsHud

	return {
		template = false,
		frame = nil,
		updateDepth = nil,
		root = DeepsHud,
		oxygenFill = Filler,
		oxygenLabel = Label,
		depthLabel = v1,
		bagLabel = BagLabel,
		bagList = BagList
	}
end

local function destroyHud() --[[ destroyHud | Line: 475 | Upvalues: v5 (ref) ]]
	local v1 = v5

	v5 = nil

	if not v1 then
		return
	end

	if v1.template then
		local frame = v1.frame

		if frame then
			frame.Visible = false
		end
	else
		v1.root:Destroy()
	end
end

local function getBlackout() --[[ getBlackout | Line: 493 | Upvalues: LocalPlayer (copy) ]]
	local PlayerGui = LocalPlayer:FindFirstChildOfClass("PlayerGui")
	local v1 = if PlayerGui then PlayerGui:FindFirstChild("MainUI") else PlayerGui
	local v2 = if v1 then v1:FindFirstChild("Blackout") else v1

	if v2 and v2:IsA("Frame") then
		return v2
	end

	return nil
end

local v6 = nil
local v7 = nil
local v8 = 0

local function destroyZoneBanner() --[[ destroyZoneBanner | Line: 511 | Upvalues: v6 (ref) ]]
	local v1 = v6

	v6 = nil

	if not v1 then
		return
	end

	v1:Destroy()
end

local function buildZoneBannerHolder(p1) --[[ buildZoneBannerHolder | Line: 523 | Upvalues: LocalPlayer (copy), DeepsConfig (copy) ]]
	local PlayerGui = LocalPlayer:FindFirstChildOfClass("PlayerGui")
	local v1 = if PlayerGui then PlayerGui:FindFirstChild("MainUI") else PlayerGui
	local v2 = if v1 then v1:FindFirstChild(DeepsConfig.UiFrameName) else v1
	local v3 = if v2 then v2:FindFirstChild("ZoneBanner") else v2

	if v3 and v3:IsA("Frame") then
		local ZoneBannerLive = v3:Clone()

		ZoneBannerLive.Name = "ZoneBannerLive"

		local ZoneName = ZoneBannerLive:FindFirstChild("ZoneName")

		if ZoneName and ZoneName:IsA("TextLabel") then
			ZoneName.Text = p1.DisplayName
			ZoneName.TextColor3 = p1.BannerColor or Color3.new(255/255, 255/255, 255/255)
		end

		ZoneBannerLive.Visible = true
		ZoneBannerLive.Parent = v3.Parent

		return ZoneBannerLive, ZoneBannerLive
	end

	local DeepsZoneBanner = Instance.new("ScreenGui")

	DeepsZoneBanner.Name = "DeepsZoneBanner"
	DeepsZoneBanner.ResetOnSpawn = false
	DeepsZoneBanner.DisplayOrder = 65
	DeepsZoneBanner.Parent = LocalPlayer:WaitForChild("PlayerGui")

	local Frame = Instance.new("Frame")

	Frame.AnchorPoint = Vector2.new(0.5, 0.5)
	Frame.Position = UDim2.fromScale(0.5, 0.3)
	Frame.Size = UDim2.fromOffset(600, 82)
	Frame.BackgroundTransparency = 1
	Frame.Parent = DeepsZoneBanner

	local Entering = Instance.new("TextLabel")

	Entering.Name = "Entering"
	Entering.Size = UDim2.new(1, 0, 0, 22)
	Entering.BackgroundTransparency = 1
	Entering.Font = Enum.Font.GothamBold
	Entering.TextSize = 20
	Entering.TextColor3 = Color3.new(255/255, 255/255, 255/255)
	Entering.TextStrokeTransparency = 0.3
	Entering.Text = "Entering"
	Entering.Parent = Frame

	local ZoneName = Instance.new("TextLabel")

	ZoneName.Name = "ZoneName"
	ZoneName.Position = UDim2.fromOffset(0, 20)
	ZoneName.Size = UDim2.new(1, 0, 0, 58)
	ZoneName.BackgroundTransparency = 1
	ZoneName.Font = Enum.Font.GothamBlack
	ZoneName.TextSize = 52
	ZoneName.TextColor3 = p1.BannerColor or Color3.new(255/255, 255/255, 255/255)
	ZoneName.TextStrokeTransparency = 0.2
	ZoneName.Text = p1.DisplayName
	ZoneName.Parent = Frame

	local UIStroke = Instance.new("UIStroke")

	UIStroke.Color = Color3.new(0/255, 0/255, 0/255)
	UIStroke.Thickness = 2
	UIStroke.Parent = ZoneName

	return DeepsZoneBanner, Frame
end

local function showZoneBanner(p1) --[[ showZoneBanner | Line: 584 | Upvalues: DeepsConfig (copy), v6 (ref), buildZoneBannerHolder (copy), SFX (copy), popInGui (copy), TweenService (copy) ]]
	local v1 = DeepsConfig.Zones[p1]

	if not v1 then
		return
	end

	local v2 = v6

	v6 = nil

	if v2 then
		v2:Destroy()
	end

	local v3, v4 = buildZoneBannerHolder(v1)

	if v3 and v4 then
		v6 = v3
		SFX.new(DeepsConfig.ZoneBanner.SoundId, DeepsConfig.ZoneBanner.SoundVolume)
		popInGui(v4, true)
		task.delay(DeepsConfig.ZoneBanner.HoldSeconds, function() --[[ Line: 599 | Upvalues: v6 (ref), v3 (copy), v4 (copy), TweenService (ref) ]]
			if v6 ~= v3 then
				return
			end

			local v1 = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
			local v2 = nil

			for v32, v42 in v4:GetDescendants() do
				if v42:IsA("TextLabel") then
					local v5 = TweenService:Create(v42, v1, {
						TextTransparency = 1,
						TextStrokeTransparency = 1
					})

					v5:Play()
					v2 = v5

					continue
				end

				if v42:IsA("UIStroke") then
					TweenService:Create(v42, v1, {
						Transparency = 1
					}):Play()
				end
			end

			if v2 then
				v2.Completed:Once(function() --[[ Line: 615 | Upvalues: v6 (ref), v3 (ref) ]]
					if v6 ~= v3 then
						return
					end

					local v1 = v6

					v6 = nil

					if not v1 then
						return
					end

					v1:Destroy()
				end)

				return
			end

			local v62 = v6

			v6 = nil

			if not v62 then
				return
			end

			v62:Destroy()
		end)
	end
end

local t2 = { "Density", "Offset", "Color", "Decay", "Glare", "Haze" }
local v9 = false
local t3 = {}
local v10 = nil
local v11 = nil
local v12 = false
local v13 = nil

local function setWeatherVisualsLock(p1) --[[ setWeatherVisualsLock | Line: 654 | Upvalues: DeepsConfig (copy), v12 (ref), WeatherEffects (copy), ReplicatedStorage (copy), v13 (ref), t2 (copy) ]]
	local Underwater = DeepsConfig.Underwater

	if not Underwater.BlockWeatherVisuals or p1 == v12 then
		return
	end

	v12 = p1

	if p1 then
		local v1 = ReplicatedStorage:FindFirstChild("shared")
		local v2 = if v1 then v1:FindFirstChild("model") else v1
		local v3 = if v2 then v2:FindFirstChild(Underwater.WeatherOverrideFolderName) else v2

		if not v3 then
			local v4 = v13

			if not v4 then
				local DeepsWeatherLockStandIn = Instance.new("Folder")

				DeepsWeatherLockStandIn.Name = "DeepsWeatherLockStandIn"
				v13 = DeepsWeatherLockStandIn
				v4 = DeepsWeatherLockStandIn
			end

			v3 = v4
		end

		if not v3:FindFirstChildOfClass("Atmosphere") then
			local Atmosphere = Instance.new("Atmosphere")

			for v5, v6 in t2 do
				Atmosphere[v6] = Underwater.Atmosphere[v6]
			end

			Atmosphere.Parent = v3
		end

		if not v3:FindFirstChildOfClass("Sky") then
			local DeepsUnderwaterDefaultSky = Instance.new("Sky")

			DeepsUnderwaterDefaultSky.Name = "DeepsUnderwaterDefaultSky"
			DeepsUnderwaterDefaultSky.Parent = v3
		end

		local ok, result = pcall(WeatherEffects.SetSkyOverride, v3)

		if ok then
			return
		end

		warn((("[DeepsDiving] weather lock failed: %*"):format(result)))
	else
		local ok, result = pcall(WeatherEffects.SetSkyOverride, nil)

		if ok then
			return
		end

		warn((("[DeepsDiving] weather lock release failed: %*"):format(result)))
	end
end

local v14 = nil
local v15 = nil

local function getSubmergeSound() --[[ getSubmergeSound | Line: 719 | Upvalues: DeepsConfig (copy), v14 (ref), SoundService (copy), v15 (ref) ]]
	local Underwater = DeepsConfig.Underwater

	if Underwater.SubmergeSoundId == "" then
		return nil
	end

	local v1 = v14

	if v1 and v1.Parent then
		return v1
	end

	local DeepsSubmergeSound = Instance.new("Sound")

	DeepsSubmergeSound.Name = "DeepsSubmergeSound"
	DeepsSubmergeSound.SoundId = Underwater.SubmergeSoundId

	local DeepsSubmergeMuffle = Instance.new("EqualizerSoundEffect")

	DeepsSubmergeMuffle.Name = "DeepsSubmergeMuffle"
	DeepsSubmergeMuffle.HighGain = 0
	DeepsSubmergeMuffle.MidGain = 0
	DeepsSubmergeMuffle.LowGain = 0
	DeepsSubmergeMuffle.Parent = DeepsSubmergeSound
	DeepsSubmergeSound.Parent = SoundService
	v14 = DeepsSubmergeSound
	v15 = DeepsSubmergeMuffle

	return DeepsSubmergeSound
end

local function warmSubmergeSound() --[[ warmSubmergeSound | Line: 743 | Upvalues: getSubmergeSound (copy) ]]
	local v1 = getSubmergeSound()

	if v1 and not v1.IsPlaying then
		v1.Volume = 0.001
		v1:Play()
	end
end

local v16 = 0

local function playSubmergeSound() --[[ playSubmergeSound | Line: 754 | Upvalues: getSubmergeSound (copy), DeepsConfig (copy), v16 (ref), v15 (ref), TweenService (copy) ]]
	local v1 = getSubmergeSound()

	if not v1 then
		return
	end

	local Underwater = DeepsConfig.Underwater

	if os.clock() - v16 < Underwater.SubmergeSoundCooldown then
		return
	end

	v16 = os.clock()
	v1:Stop()
	v1.TimePosition = 0
	v1.Volume = Underwater.SubmergeSoundVolume

	local v2 = v15

	if not v2 then
		v1:Play()

		return
	end

	v2.HighGain = 0
	TweenService:Create(v2, TweenInfo.new(Underwater.SubmergeMuffleSeconds, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
		HighGain = -80
	}):Play()
	v1:Play()
end

local function applyUnderwaterAtmosphere() --[[ applyUnderwaterAtmosphere | Line: 786 | Upvalues: DeepsConfig (copy), Lighting (copy), t2 (copy), TweenService (copy) ]]
	local Underwater = DeepsConfig.Underwater
	local Atmosphere = Lighting:FindFirstChildOfClass("Atmosphere")

	if not Atmosphere then
		return
	end

	local t = {}

	for v1, v2 in t2 do
		t[v2] = Underwater.Atmosphere[v2]
	end

	TweenService:Create(Atmosphere, TweenInfo.new(Underwater.AtmosphereTweenSeconds, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), t):Play()
end

local function setUnderwaterAmbience(p1) --[[ setUnderwaterAmbience | Line: 803 | Upvalues: v9 (ref), DeepsConfig (copy), setWeatherVisualsLock (copy), Lighting (copy), v10 (ref), v12 (ref), t2 (copy), v11 (ref), applyUnderwaterAtmosphere (copy), playSubmergeSound (copy), SoundService (copy), TweenService (copy), t3 (copy), WeatherEffects (copy) ]]
	if p1 == v9 then
		return
	end

	v9 = p1

	local Underwater = DeepsConfig.Underwater

	if p1 then
		setWeatherVisualsLock(true)

		local Atmosphere = Lighting:FindFirstChildOfClass("Atmosphere")

		if Atmosphere then
			if not v12 then
				local t = {}

				for v1, v2 in t2 do
					t[v2] = Atmosphere[v2]
				end

				v11 = t
			end
		else
			local Atmosphere2 = Instance.new("Atmosphere")

			v10 = Atmosphere2
			Atmosphere2.Parent = Lighting
		end

		applyUnderwaterAtmosphere()
		playSubmergeSound()

		for v3, v4 in Underwater.AmbienceSoundIds do
			local DeepsUnderwaterAmbience = Instance.new("Sound")

			DeepsUnderwaterAmbience.Name = "DeepsUnderwaterAmbience"
			DeepsUnderwaterAmbience.SoundId = v4
			DeepsUnderwaterAmbience.Looped = true
			DeepsUnderwaterAmbience.Volume = 0

			local DeepsLowAirEqualizer = Instance.new("EqualizerSoundEffect")

			DeepsLowAirEqualizer.Name = "DeepsLowAirEqualizer"
			DeepsLowAirEqualizer.HighGain = 0
			DeepsLowAirEqualizer.MidGain = 0
			DeepsLowAirEqualizer.LowGain = 0
			DeepsLowAirEqualizer.Parent = DeepsUnderwaterAmbience

			local DeepsLowAirPitch = Instance.new("PitchShiftSoundEffect")

			DeepsLowAirPitch.Name = "DeepsLowAirPitch"
			DeepsLowAirPitch.Octave = 1
			DeepsLowAirPitch.Parent = DeepsUnderwaterAmbience
			DeepsUnderwaterAmbience.Parent = SoundService
			DeepsUnderwaterAmbience:Play()
			TweenService:Create(DeepsUnderwaterAmbience, TweenInfo.new(Underwater.AmbienceFadeSeconds, Enum.EasingStyle.Linear), {
				Volume = Underwater.AmbienceVolume
			}):Play()
			table.insert(t3, DeepsUnderwaterAmbience)
		end
	else
		if v10 then
			v10:Destroy()
			v10 = nil
		else
			local Atmosphere = Lighting:FindFirstChildOfClass("Atmosphere")
			local v6 = v11

			if Atmosphere and v6 then
				TweenService:Create(Atmosphere, TweenInfo.new(Underwater.AtmosphereTweenSeconds, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), v6):Play()
			end
		end

		v11 = nil

		for v7, v8 in t3 do
			v8:Destroy()
		end

		table.clear(t3)

		if not DeepsConfig.Underwater.BlockWeatherVisuals then
			return
		end

		if v12 == false then
			return
		end

		v12 = false

		local ok, result = pcall(WeatherEffects.SetSkyOverride, nil)

		if ok then
			return
		end

		warn((("[DeepsDiving] weather lock release failed: %*"):format(result)))
	end
end

local v17 = false

local function applyLowAirFx(p1) --[[ applyLowAirFx | Line: 900 | Upvalues: v17 (ref), LocalPlayer (copy), t3 (copy) ]]
	if p1 <= 0 and not v17 then
		return
	end

	v17 = p1 > 0

	local PlayerGui = LocalPlayer:FindFirstChildOfClass("PlayerGui")
	local v2 = if PlayerGui then PlayerGui:FindFirstChild("MainUI") else PlayerGui
	local v3 = if v2 then v2:FindFirstChild("Blackout") else v2
	local v4 = if v3 and v3:IsA("Frame") then v3 else nil

	if v4 then
		v4.BackgroundTransparency = 1 - p1 * 1
	end

	for v5, v6 in t3 do
		local DeepsLowAirEqualizer = v6:FindFirstChild("DeepsLowAirEqualizer")

		if DeepsLowAirEqualizer and DeepsLowAirEqualizer:IsA("EqualizerSoundEffect") then
			DeepsLowAirEqualizer.HighGain = p1 * -80
		end

		local DeepsLowAirPitch = v6:FindFirstChild("DeepsLowAirPitch")

		if DeepsLowAirPitch and DeepsLowAirPitch:IsA("PitchShiftSoundEffect") then
			DeepsLowAirPitch.Octave = 1 - p1 * 0.9
		end
	end
end

local function updateZoneBanner(p1) --[[ updateZoneBanner | Line: 922 | Upvalues: v7 (ref), v8 (ref), DeepsConfig (copy), showZoneBanner (copy) ]]
	if p1 == v7 then
		return
	end

	v7 = p1

	if p1 == nil then
		return
	end

	local v1 = os.clock()

	if not (v1 - v8 < DeepsConfig.ZoneBanner.CooldownSeconds) then
		v8 = v1
		showZoneBanner(p1)
	end
end

local function updateBagHud() --[[ updateBagHud | Line: 940 | Upvalues: v5 (ref), ClientPlayerData (copy), DeepsGearConfig (copy), FishConfig (copy), DeepsLootConfig (copy) ]]
	local v1 = v5

	if not v1 then
		return
	end

	local v2 = ClientPlayerData.serverProfile:getState()
	local v3 = if v2.deeps then v2.deeps.bag or {} else {}
	local v4 = DeepsGearConfig.GetBagSlots(ClientPlayerData.serverProfile:getState().deepsGear)

	if v1.capacityLabel then
		v1.capacityLabel.Text = ("%*/%*"):format(#v3, v4)
		v1.capacityLabel.TextColor3 = if v4 <= #v3 then Color3.fromRGB(255, 120, 90) else Color3.fromRGB(255, 255, 255)
	elseif v1.bagLabel then
		v1.bagLabel.Text = ("Bag %*/%*"):format(#v3, v4)
		v1.bagLabel.TextColor3 = if v4 <= #v3 then Color3.fromRGB(255, 120, 90) else Color3.fromRGB(255, 210, 120)
	end

	local bagList = v1.bagList

	if not bagList then
		return
	end

	for v7, v8 in bagList:GetChildren() do
		if v8:IsA("TextLabel") then
			v8:Destroy()
		end
	end

	for v11, v12 in v3 do
		local v9, v10
		local TextLabel = Instance.new("TextLabel")

		TextLabel.Name = ("Entry%*"):format(v11)
		TextLabel.LayoutOrder = v11
		TextLabel.Size = UDim2.new(1, 0, 0, 20)
		TextLabel.BackgroundTransparency = 1
		TextLabel.Font = Enum.Font.GothamBold
		TextLabel.TextSize = 15
		TextLabel.TextXAlignment = Enum.TextXAlignment.Right
		TextLabel.TextStrokeTransparency = 0.4

		local v13 = if v12.Type == "Fish" then FishConfig[v12.Name] else DeepsLootConfig.Items[v12.Name]
		local v14

		if v13 and v13.Rarity then
			v9 = v13.Rarity.rarityColor

			if not v9 then
				v14 = Color3.new(255/255, 255/255, 255/255)
				v9 = v14
			end
		else
			v14 = Color3.new(255/255, 255/255, 255/255)
			v9 = v14
		end

		TextLabel.TextColor3 = v9
		v10 = if v12.Type == "Fish" then FishConfig[v12.Name] and FishConfig[v12.Name].DisplayName or v12.Name else DeepsLootConfig.Items[v12.Name] and DeepsLootConfig.Items[v12.Name].DisplayName or v12.Name
		TextLabel.Text = v10
		TextLabel.Parent = bagList
	end
end

local v18 = nil
local t4 = {}

local function getAnimation(p1) --[[ getAnimation | Line: 1015 | Upvalues: t4 (copy) ]]
	local v1 = t4[p1]

	if v1 then
		return v1
	end

	local Animation = Instance.new("Animation")

	Animation.AnimationId = p1
	t4[p1] = Animation

	return Animation
end

local function loadTrack(p1, p2) --[[ loadTrack | Line: 1026 | Upvalues: t4 (copy) ]]
	local Animator = p1:FindFirstChildOfClass("Animator")

	if not Animator then
		return nil
	end

	local ok, result = pcall(function() --[[ Line: 1031 | Upvalues: Animator (copy), p2 (copy), t4 (ref) ]]
		local v2 = p2
		local v3 = t4[v2]
		local v4

		if v3 then
			v4 = v3
		else
			local Animation = Instance.new("Animation")

			Animation.AnimationId = v2
			t4[v2] = Animation
			v4 = Animation
		end

		return Animator:LoadAnimation(v4)
	end)

	if ok then
		result.Priority = Enum.AnimationPriority.Action

		return result
	end

	return nil
end

local v19 = 0
local v20 = nil

local function playEntrySplash(p1, p2) --[[ playEntrySplash | Line: 1054 | Upvalues: DeepsConfig (copy), ThrowFX (copy), GetSurfaceY (copy), SFX (copy) ]]
	local SurfaceFx = DeepsConfig.SurfaceFx

	ThrowFX.landingSplash(CFrame.new(p2.X, GetSurfaceY(p1), p2.Z), SurfaceFx.EntrySplashScale, true)

	if SurfaceFx.EntrySoundId == "" then
		return
	end

	SFX.PlaySoundWithRandomPitch(SurfaceFx.EntrySoundId, SurfaceFx.EntrySoundVolume, 0.9, 1.1)
end

local function getCircleFxEmitter() --[[ getCircleFxEmitter | Line: 1064 | Upvalues: v20 (ref), DeepsConfig (copy), ReplicatedStorage (copy), Workspace (copy) ]]
	local v1 = v20

	if v1 and v1.Parent then
		local v2 = v1:FindFirstChildWhichIsA("ParticleEmitter")

		if v2 then
			return v2
		end
	end

	local model = ReplicatedStorage.shared:FindFirstChild("model")
	local v3 = if model then model:FindFirstChild("fx") else model
	local v4 = if v3 then v3:FindFirstChild(DeepsConfig.SurfaceFx.CircleEmitterName) else v3

	if v4 and v4:IsA("ParticleEmitter") then
		local DeepsCircleFx = Instance.new("Part")

		DeepsCircleFx.Name = "DeepsCircleFx"
		DeepsCircleFx.Anchored = true
		DeepsCircleFx.CanCollide = false
		DeepsCircleFx.CanQuery = false
		DeepsCircleFx.CanTouch = false
		DeepsCircleFx.Transparency = 1
		DeepsCircleFx.Size = Vector3.new(1, 1, 1)

		local v5 = v4:Clone()

		v5.Enabled = false
		v5.Parent = DeepsCircleFx
		DeepsCircleFx.Parent = Workspace
		v20 = DeepsCircleFx

		return v5
	end

	return nil
end

local function destroyCircleFx() --[[ destroyCircleFx | Line: 1095 | Upvalues: v20 (ref) ]]
	local v1 = v20

	v20 = nil

	if not v1 then
		return
	end

	v1:Destroy()
end

local function startDive(p1, p2) --[[ startDive | Line: 1103 | Upvalues: Swim (copy), t4 (copy), v18 (ref), DeepsGearConfig (copy), ClientPlayerData (copy), RunService (copy), DeepsConfig (copy), DeepsState (copy), getSubmergeSound (copy), playEntrySplash (copy), v19 (ref) ]]
	local DeepsSwimAttachment = Instance.new("Attachment")

	DeepsSwimAttachment.Name = "DeepsSwimAttachment"
	DeepsSwimAttachment.Parent = p2

	local DeepsSwimVelocity = Instance.new("LinearVelocity")

	DeepsSwimVelocity.Name = "DeepsSwimVelocity"
	DeepsSwimVelocity.Attachment0 = DeepsSwimAttachment
	DeepsSwimVelocity.MaxForce = (1 / 0)
	DeepsSwimVelocity.VectorVelocity = Vector3.new(0, 0, 0)
	DeepsSwimVelocity.Parent = p2

	local v3 = math.atan2(-p2.CFrame.LookVector.X, -p2.CFrame.LookVector.Z)
	local DeepsSwimAlign = Instance.new("AlignOrientation")

	DeepsSwimAlign.Name = "DeepsSwimAlign"
	DeepsSwimAlign.Mode = Enum.OrientationAlignmentMode.OneAttachment
	DeepsSwimAlign.Attachment0 = DeepsSwimAttachment
	DeepsSwimAlign.RigidityEnabled = true
	DeepsSwimAlign.CFrame = CFrame.Angles(0, v3, 0)
	DeepsSwimAlign.Parent = p2
	p1:UnequipTools()
	p1:ChangeState(Enum.HumanoidStateType.Physics)

	local t = {
		oxygenUsed = 0,
		bubbles = nil,
		bubbleAttachment = nil,
		pitch = 0,
		lastVelocity = Vector3.new(0, 0, 0),
		velocity = DeepsSwimVelocity,
		align = DeepsSwimAlign,
		attachment = DeepsSwimAttachment
	}
	local SwimAnimationId = Swim.SwimAnimationId
	local Animator = p1:FindFirstChildOfClass("Animator")
	local v4

	if Animator then
		local ok, result = pcall(function() --[[ Line: 1031 | Upvalues: Animator (copy), SwimAnimationId (copy), t4 (ref) ]]
			local v2 = SwimAnimationId
			local v3 = t4[v2]
			local v4

			if v3 then
				v4 = v3
			else
				local Animation = Instance.new("Animation")

				Animation.AnimationId = v2
				t4[v2] = Animation
				v4 = Animation
			end

			return Animator:LoadAnimation(v4)
		end)

		if ok then
			result.Priority = Enum.AnimationPriority.Action
			v4 = result
		else
			v4 = nil
		end
	else
		v4 = nil
	end

	t.swimTrack = v4

	local SwimIdleAnimationId = Swim.SwimIdleAnimationId
	local Animator2 = p1:FindFirstChildOfClass("Animator")
	local v5

	if Animator2 then
		local ok, result = pcall(function() --[[ Line: 1031 | Upvalues: Animator2 (copy), SwimIdleAnimationId (copy), t4 (ref) ]]
			local v2 = SwimIdleAnimationId
			local v3 = t4[v2]
			local v4

			if v3 then
				v4 = v3
			else
				local Animation = Instance.new("Animation")

				Animation.AnimationId = v2
				t4[v2] = Animation
				v4 = Animation
			end

			return Animator2:LoadAnimation(v4)
		end)

		if ok then
			result.Priority = Enum.AnimationPriority.Action
			v5 = result
		else
			v5 = nil
		end
	else
		v5 = nil
	end

	t.idleTrack = v5
	t.yaw = v3
	v18 = t

	local v6 = DeepsGearConfig.GetOxygenSeconds(ClientPlayerData.serverProfile:getState().deepsGear)

	if RunService:IsStudio() and DeepsConfig.Debug.ShortOxygen then
		v6 = 10
	end

	DeepsState.underwater = true
	DeepsState.oxygenCapacity = v6
	DeepsState.oxygenRemaining = v6

	local v7 = getSubmergeSound()

	if v7 and not v7.IsPlaying then
		v7.Volume = 0.001
		v7:Play()
	end

	local SurfaceFx = DeepsConfig.SurfaceFx
	local volume = DeepsState.volume

	if not (SurfaceFx.Enabled and volume) then
		DeepsState.DiveStarted:Fire()

		return
	end

	playEntrySplash(volume, p2.Position)
	v19 = os.clock() + SurfaceFx.WakeInterval
	DeepsState.DiveStarted:Fire()
end

local function endDive() --[[ endDive | Line: 1176 | Upvalues: v18 (ref), applyLowAirFx (copy), LocalPlayer (copy), DeepsState (copy), v6 (ref), v7 (ref), v20 (ref), v5 (ref), Satchel (copy) ]]
	local v1 = v18

	v18 = nil

	if v1 then
		v1.velocity:Destroy()
		v1.align:Destroy()
		v1.attachment:Destroy()

		if v1.bubbles then
			v1.bubbles:Destroy()
		end

		if v1.bubbleAttachment then
			v1.bubbleAttachment:Destroy()
		end

		applyLowAirFx(0)

		if v1.swimTrack then
			v1.swimTrack:Stop(0.2)
		end

		if v1.idleTrack then
			v1.idleTrack:Stop(0.2)
		end
	end

	local Character = LocalPlayer.Character
	local v2, v3

	if Character then
		local Humanoid = Character:FindFirstChildOfClass("Humanoid")
		local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")

		if HumanoidRootPart and HumanoidRootPart:IsA("BasePart") then
			v2 = Humanoid
			v3 = HumanoidRootPart
		else
			v2 = Humanoid
			v3 = nil
		end
	else
		v2 = nil
		v3 = nil
	end

	if v2 then
		if v3 then
			local LookVector = v3.CFrame.LookVector
			local v62 = math.atan2(-LookVector.X, -LookVector.Z)

			v3.CFrame = CFrame.new(v3.Position) * CFrame.Angles(0, v62, 0)
		end

		v2:ChangeState(Enum.HumanoidStateType.Freefall)

		if v3 and v1 then
			v3.AssemblyLinearVelocity = v1.lastVelocity
		end
	end

	DeepsState.underwater = false
	DeepsState.zoneIndex = nil
	DeepsState.depth = 0

	local v72 = v6

	v6 = nil

	if v72 then
		v72:Destroy()
	end

	v7 = nil

	local v8 = v20

	v20 = nil

	if v8 then
		v8:Destroy()
	end

	local v9 = v5

	v5 = nil

	local v10

	if not v9 then
		v10 = true
		pcall(function() --[[ Line: 121 | Upvalues: Satchel (ref), v10 (copy) ]]
			Satchel.SetEnabled(v10)
		end)
		DeepsState.DiveEnded:Fire()

		return
	end

	if v9.template then
		local frame = v9.frame

		if not frame then
			v10 = true
			pcall(function() --[[ Line: 121 | Upvalues: Satchel (ref), v10 (copy) ]]
				Satchel.SetEnabled(v10)
			end)
			DeepsState.DiveEnded:Fire()

			return
		end

		frame.Visible = false
	else
		v9.root:Destroy()
	end

	v10 = true
	pcall(function() --[[ Line: 121 | Upvalues: Satchel (ref), v10 (copy) ]]
		Satchel.SetEnabled(v10)
	end)
	DeepsState.DiveEnded:Fire()
end

local function computeSwimVelocity(p1) --[[ computeSwimVelocity | Line: 1228 | Upvalues: Workspace (copy), getControls (copy), DeepsGearConfig (copy), ClientPlayerData (copy), UserInputService (copy), Swim (copy) ]]
	local CurrentCamera = Workspace.CurrentCamera
	local v1 = getControls()
	local v2 = DeepsGearConfig.GetSwimSpeed(ClientPlayerData.serverProfile:getState().deepsGear)
	local v3 = Vector3.new(0, 0, 0)

	if v1 and CurrentCamera then
		local ok, result = pcall(function() --[[ Line: 1235 | Upvalues: v1 (copy) ]]
			return v1:GetMoveVector()
		end)

		if ok and (typeof(result) == "Vector3" and result.Magnitude > 0.05) then
			local v4 = CurrentCamera.CFrame:VectorToWorldSpace(result)

			v3 = if v4.Magnitude > 1 then v4.Unit else v4
		end
	end

	local v7 = v3 * v2 + Vector3.new(0, (if p1.Jump or UserInputService:IsKeyDown(Enum.KeyCode.Space) then 1 else 0) * v2 * Swim.VerticalFactor, 0)

	if v7.Magnitude < 0.05 then
		return Vector3.new(0, 0, 0)
	end

	return Vector3.new(v7.X, v7.Y * Swim.VerticalFactor, v7.Z)
end

local function stepDive(p1, p2) --[[ stepDive | Line: 1260 | Upvalues: v18 (ref), LocalPlayer (copy), computeSwimVelocity (copy), GetSurfaceY (copy), DeepsState (copy), Minigame (copy), UserInputService (copy), Swim (copy), DeepsConfig (copy), getCircleFxEmitter (copy), v20 (ref), v19 (ref), SFX (copy), zoneForDepth (copy), Oxygen (copy), v7 (ref), v8 (ref), showZoneBanner (copy), DeepsGearConfig (copy), ClientPlayerData (copy), RunService (copy), applyLowAirFx (copy), v5 (ref), buildTemplateHud (copy), buildFallbackHud (copy), updateBagHud (copy), Satchel (copy), ReplicatedStorage (copy), v1 (copy), v2 (copy) ]]
	local v12 = v18
	local Character = LocalPlayer.Character
	local v22, v3

	if Character then
		local Humanoid = Character:FindFirstChildOfClass("Humanoid")
		local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")

		if HumanoidRootPart and HumanoidRootPart:IsA("BasePart") then
			v22 = Humanoid
			v3 = HumanoidRootPart
		else
			v22 = Humanoid
			v3 = nil
		end
	else
		v22 = nil
		v3 = nil
	end

	if not (v12 and (v22 and v3)) then
		return
	end

	if v22:GetState() ~= Enum.HumanoidStateType.Physics then
		v22:ChangeState(Enum.HumanoidStateType.Physics)
	end

	local v4 = computeSwimVelocity(v22)
	local v52 = GetSurfaceY(p1)
	local v6 = v22.Parent
	local v72 = DeepsState.fighting or (if v6 then v6:IsA("Model") and (if v6:GetAttribute(Minigame.FightLockAttribute) == true then true else false) else v6)
	local v82 = if v72 then DeepsState.fightTarget else nil

	if v72 then
		v4 = Vector3.new(0, 0, 0)

		if v82 then
			local v9 = v3.Position - v82

			if v9.Magnitude > 0.05 and v9.Magnitude < Minigame.FightSeparationDistance then
				v4 = v9.Unit * Minigame.FightSeparationSpeed
			end
		end
	elseif (v22.Jump or UserInputService:IsKeyDown(Enum.KeyCode.Space)) and v3.Position.Y > v52 - Swim.SurfaceJumpDepth then
		v4 = Vector3.new(v4.X, Swim.SurfaceJumpSpeed, v4.Z)
	elseif v4.Y > 0 and v3.Position.Y > v52 - Swim.SurfaceHoldDepth then
		v4 = Vector3.new(v4.X, 0, v4.Z)
	elseif v4.Y < 0 and v3.Position.Y > v52 - Swim.SurfaceSkimDepth then
		local v13 = Vector3.new(v4.X, 0, v4.Z)
		local v15 = math.atan2(-v4.Y, v13.Magnitude)

		if v15 < math.rad(Swim.SurfaceDiveAngleDeg) then
			v4 = Vector3.new(v13.X, if v3.Position.Y < v52 - Swim.SurfaceHoldDepth then Swim.SurfaceSkimLift else 0, v13.Z)
		end
	end

	v12.velocity.VectorVelocity = v4
	v12.lastVelocity = v4

	local SurfaceFx = DeepsConfig.SurfaceFx

	if SurfaceFx.Enabled then
		local v182 = Vector3.new(v4.X, 0, v4.Z)
		local v192 = not v72 and (if v3.Position.Y > v52 - SurfaceFx.CircleDepth then true else false)
		local v202 = getCircleFxEmitter()
		local v21 = v20

		if v202 and v21 and v192 then
			local v222 = if v6 and v6:IsA("Model") then v6:FindFirstChild("Head") else nil
			local v23 = if v222 and v222:IsA("BasePart") then v222 else v3

			v21.CFrame = CFrame.new(v23.Position.X, GetSurfaceY(p1), v23.Position.Z)
			v202.Rate = SurfaceFx.CircleIdleRate + (SurfaceFx.CircleFullRate - SurfaceFx.CircleIdleRate) * math.clamp(v182.Magnitude / SurfaceFx.CircleFullSpeed, 0, 1)
			v202.Enabled = true
		elseif v202 and v21 then
			v202.Enabled = false
		end

		local v26 = if v192 then if v182.Magnitude >= SurfaceFx.WakeMinSpeed then true else false else v192

		if v26 and (SurfaceFx.WakeSoundId ~= "" and v19 <= os.clock()) then
			v19 = os.clock() + SurfaceFx.WakeInterval
			SFX.PlaySoundWithRandomPitch(SurfaceFx.WakeSoundId, SurfaceFx.WakeSoundVolume, 0.9, 1.1)
		end
	end

	local v27 = Vector3.new(v4.X, 0, v4.Z)
	local v28 = 0

	if v82 then
		local v31 = Vector3.new(v82.X - v3.Position.X, 0, v82.Z - v3.Position.Z)

		if v31.Magnitude > 0.5 then
			local v34 = math.atan2(-v31.X, -v31.Z)
			local v39 = math.atan2(math.sin(v34 - v12.yaw), (math.cos(v34 - v12.yaw)))

			v12.yaw = v12.yaw + v39 * math.min(p2 * 8, 1)
		end
	elseif v4.Magnitude > 0.5 then
		if v27.Magnitude > 0.5 then
			local v42 = math.atan2(-v4.X, -v4.Z)
			local v47 = math.atan2(math.sin(v42 - v12.yaw), (math.cos(v42 - v12.yaw)))

			v12.yaw = v12.yaw + v47 * math.min(p2 * 8, 1)
		end

		v28 = math.atan2(v4.Y, v27.Magnitude) - 1.5707963267948966
	end

	v12.pitch = v12.pitch + (v28 - v12.pitch) * math.min(p2 * 6, 1)
	v12.align.CFrame = CFrame.Angles(0, v12.yaw, 0) * CFrame.Angles(v12.pitch, 0, 0)

	local v48 = if v4.Magnitude > 0.5 then true else false
	local swimTrack = v12.swimTrack
	local idleTrack = v12.idleTrack

	if swimTrack and (v48 and not swimTrack.IsPlaying) then
		if idleTrack then
			idleTrack:Stop(0.2)
		end

		swimTrack:Play(0.2)
	elseif idleTrack and not (v48 or idleTrack.IsPlaying) then
		if swimTrack then
			swimTrack:Stop(0.2)
		end

		idleTrack:Play(0.2)
	end

	local v50 = math.max(v52 - v3.Position.Y, 0)

	DeepsState.depth = v50
	DeepsState.zoneIndex = zoneForDepth(v50)

	local v51 = if Oxygen.SurfaceGraceDepth < v50 then true else false
	local v522 = if v51 then DeepsState.zoneIndex else nil

	if v522 ~= v7 then
		v7 = v522

		if v522 ~= nil then
			local v53 = os.clock()

			if not (v53 - v8 < DeepsConfig.ZoneBanner.CooldownSeconds) then
				v8 = v53
				showZoneBanner(v522)
			end
		end
	end

	if v51 then
		v12.oxygenUsed = v12.oxygenUsed + p2
	else
		v12.oxygenUsed = 0

		local v54 = DeepsGearConfig.GetOxygenSeconds(ClientPlayerData.serverProfile:getState().deepsGear)

		if RunService:IsStudio() and DeepsConfig.Debug.ShortOxygen then
			v54 = 10
		end

		DeepsState.oxygenCapacity = v54
	end

	DeepsState.oxygenRemaining = math.max(DeepsState.oxygenCapacity - v12.oxygenUsed, 0)
	applyLowAirFx(if Oxygen.LowAirFxSeconds > 0 then math.clamp(1 - DeepsState.oxygenRemaining / Oxygen.LowAirFxSeconds, 0, 1) else 0)

	if v51 and not v5 then
		v5 = buildTemplateHud() or buildFallbackHud()
		updateBagHud()

		local v60 = false

		pcall(function() --[[ Line: 121 | Upvalues: Satchel (ref), v60 (copy) ]]
			Satchel.SetEnabled(v60)
		end)
	elseif not v51 and v5 then
		local v61 = v5

		v5 = nil

		if v61 and v61.template then
			local frame = v61.frame

			if frame then
				frame.Visible = false
			end
		elseif v61 then
			v61.root:Destroy()
		end

		local v62 = true

		pcall(function() --[[ Line: 121 | Upvalues: Satchel (ref), v62 (copy) ]]
			Satchel.SetEnabled(v62)
		end)
	end

	local v63 = if v6 and v6:IsA("Model") then v6:FindFirstChild("Head") else nil
	local v64 = if Swim.BubbleFxDepth < v50 and v63 ~= nil then v63:IsA("BasePart") else false
	local bubbles = v12.bubbles

	if v64 and not (bubbles and bubbles.Parent) then
		local v65 = ReplicatedStorage:FindFirstChild("shared")
		local v66 = if v65 then v65:FindFirstChild("model") else v65
		local v67 = if v66 then v66:FindFirstChild("fx") else v66
		local v68 = if v67 then v67:FindFirstChild(Swim.BubbleFxName) else v67

		if v68 and v68:IsA("ParticleEmitter") then
			local DeepsBubbleAttachment = Instance.new("Attachment")

			DeepsBubbleAttachment.Name = "DeepsBubbleAttachment"
			DeepsBubbleAttachment.Parent = v63

			local v69 = v68:Clone()

			v69.Enabled = true
			v69.Parent = DeepsBubbleAttachment
			v12.bubbleAttachment = DeepsBubbleAttachment
			v12.bubbles = v69
		end
	elseif not v64 and bubbles then
		bubbles:Destroy()
		v12.bubbles = nil

		if v12.bubbleAttachment then
			v12.bubbleAttachment:Destroy()
			v12.bubbleAttachment = nil
		end
	end

	local bubbleAttachment = v12.bubbleAttachment

	if bubbleAttachment and (bubbleAttachment.Parent and v63) then
		bubbleAttachment.WorldCFrame = CFrame.new(v63.Position)
	end

	local v70 = v5

	if not v70 then
		return
	end

	local v71 = if DeepsState.oxygenCapacity > 0 then DeepsState.oxygenRemaining / DeepsState.oxygenCapacity else 0

	v70.oxygenFill.Size = UDim2.fromScale(math.clamp(v71, 0, 1), 1)
	v70.oxygenFill.BackgroundColor3 = if v71 <= Oxygen.WarnFraction then v1 else v2

	if v70.oxygenLabel then
		v70.oxygenLabel.Text = ("Oxygen: %*s"):format((math.ceil(DeepsState.oxygenRemaining)))
	end

	if v70.depthLabel then
		v70.depthLabel.Text = ("%* m"):format((math.floor(v50 + 0.5)))
	end

	if not v70.updateDepth then
		return
	end

	v70.updateDepth(v50)
end

local v21 = nil
local v22 = nil
local v23 = nil

local function destroyFailGui() --[[ destroyFailGui | Line: 1521 | Upvalues: v21 (ref), v23 (ref), v22 (ref) ]]
	local v1 = v21

	v21 = nil

	if v1 then
		v1:Destroy()
	end

	local v2 = v23

	v23 = nil

	if v2 then
		v2()
	end

	local v3 = v22

	v22 = nil

	if not v3 then
		return
	end

	v3.Visible = false
end

local function getFailFrame() --[[ getFailFrame | Line: 1542 | Upvalues: LocalPlayer (copy), DeepsConfig (copy) ]]
	local PlayerGui = LocalPlayer:FindFirstChildOfClass("PlayerGui")
	local v1 = if PlayerGui then PlayerGui:FindFirstChild("MainUI") else PlayerGui

	if not v1 then
		return nil
	end

	local RanOutOfAir = v1:FindFirstChild("RanOutOfAir")

	if not RanOutOfAir then
		local v2 = v1:FindFirstChild(DeepsConfig.UiFrameName)
		local v3 = if v2 then v2:FindFirstChild("RanOutOfAir") else v2

		if v3 then
			v3.Parent = v1
		end

		RanOutOfAir = v3
	end

	if RanOutOfAir and RanOutOfAir:IsA("Frame") then
		return RanOutOfAir
	end

	return nil
end

local function fillFailRow(p1, p2, p3, p4) --[[ fillFailRow | Line: 1561 | Upvalues: FishConfig (copy), DeepsLootConfig (copy), CashDisplay (copy), FishEarnings (copy), LocalPlayer (copy) ]]
	local v1 = if p2 == "Fish" then FishConfig[p3] else DeepsLootConfig.Items[p3]
	local DisplayName = p1:FindFirstChild("DisplayName")

	if DisplayName and DisplayName:IsA("TextLabel") then
		DisplayName.Text = v1 and v1.DisplayName or p3
	end

	local Rarity = p1:FindFirstChild("Rarity")

	if Rarity and Rarity:IsA("TextLabel") then
		Rarity.Text = v1 and v1.Rarity and v1.Rarity.displayName or ""

		if v1 and v1.Rarity then
			Rarity.TextColor3 = v1.Rarity.rarityColor
		end
	end

	local Stack = p1:FindFirstChild("Stack")

	if Stack and Stack:IsA("TextLabel") then
		Stack.Text = ("Stack x%*"):format(p4)
	end

	local SellValue = p1:FindFirstChild("SellValue")

	if SellValue and SellValue:IsA("TextLabel") then
		if p2 == "Fish" then
			CashDisplay.applyToLabel(SellValue, FishEarnings.perFish(LocalPlayer, p3), {
				Suffix = "/s",
				Compact = true
			})
		else
			local v5, v6

			if v1 then
				v5 = v1.StonesYield

				if v5 then
					v6 = SellValue
				else
					v5 = 0
					v6 = SellValue
				end
			else
				v5 = 0
				v6 = SellValue
			end

			CashDisplay.setPlainText(v6, (("%* stones"):format(v5)))
		end
	end

	local FishInfo = p1:FindFirstChild("FishInfo")
	local v7 = if FishInfo then FishInfo:FindFirstChild("Icon") else FishInfo

	if v7 and v7:IsA("ImageLabel") then
		v7.Image = if v1 then v1.Image or (v1.Icon or "") else ""
		v7.Visible = if v7.Image == "" then false else true
	end

	if not (FishInfo and (FishInfo:IsA("GuiObject") and p1:IsA("GuiObject"))) then
		return
	end

	local v10 = math.max(p1.ZIndex, FishInfo.ZIndex)
	local Frame = FishInfo:FindFirstChild("Frame")

	if Frame and Frame:IsA("GuiObject") then
		Frame.ZIndex = v10 + 1
	end

	if not (v7 and v7:IsA("GuiObject")) then
		return
	end

	v7.ZIndex = v10 + 2
end

local function showTemplateFailScreen(p1, p2) --[[ showTemplateFailScreen | Line: 1614 | Upvalues: getFailFrame (copy), fillFailRow (copy), TweenService (copy), v22 (ref), v23 (ref), ContextActionService (copy), Remotes (copy), v21 (ref), MarketplaceService (copy), LocalPlayer (copy), DeepsConfig (copy), bindToButtonPress (copy) ]]
	local v1 = getFailFrame()
	local v2 = if v1 then v1:FindFirstChild("Multiple") else v1
	local v3 = if v2 then v2:FindFirstChild("Template") else v2
	local v4 = v1 and v1:FindFirstChild("SaveButton")
	local v5 = if v1 then v1:FindFirstChild("OkayButton") else v1

	if not (v1 and (v2 and (v2:IsA("GuiObject") and (v3 and (v3:IsA("GuiObject") and (v4 and (v4:IsA("GuiButton") and (v5 and v5:IsA("GuiButton"))))))))) then
		return false
	end

	local v6

	if p2 then
		local AdButton = v4:Clone()

		AdButton.Name = "AdButton"

		local TextLabel = AdButton:FindFirstChild("TextLabel")

		if TextLabel and TextLabel:IsA("GuiObject") then
			TextLabel.Visible = false
		end

		local v7 = AdButton:FindFirstChild("Content")
		local v8 = v7 and v7:FindFirstChild("Frame")
		local v9 = if v8 then v8:FindFirstChild("TextLabel") else v8

		if v9 and v9:IsA("TextLabel") then
			v9.Text = "Watch ad"
		end

		local v10 = v8 and v8:FindFirstChild("ImageLabel")

		if v10 and v10:IsA("GuiObject") then
			v10.Visible = false
		end

		AdButton.Parent = v1
		v4.Visible = false
		v6 = AdButton
	else
		v6 = nil
	end

	local t = {}
	local t2 = {}

	for v11, v12 in p1 do
		local v13 = ("%*\0%*"):format(v12.Type, v12.Name)
		local v14 = t[v13]

		if v14 then
			v14.Count = v14.Count + 1

			continue
		end

		local t3 = {
			Count = 1,
			Type = v12.Type,
			Name = v12.Name
		}

		t[v13] = t3
		table.insert(t2, t3)
	end

	v3.Visible = false

	local FishTemplateNotAcquired = v1:FindFirstChild("FishTemplateNotAcquired")

	if FishTemplateNotAcquired and FishTemplateNotAcquired:IsA("GuiObject") then
		FishTemplateNotAcquired.Visible = false
	end

	local t3 = {}

	for v15, v16 in t2 do
		local v17 = v3:Clone()

		v17.Name = ("Row%*"):format(v15)
		v17.LayoutOrder = v15
		v17.Visible = true
		fillFailRow(v17, v16.Type, v16.Name, v16.Count)
		v17.Parent = v2
		table.insert(t3, v17)
	end

	local Bar = v1:FindFirstChild("Bar")
	local v18 = Bar and Bar:FindFirstChild("Bar")
	local v19 = Bar and Bar:FindFirstChild("TextLabel")

	if v18 and v18:IsA("GuiObject") then
		v18.Size = UDim2.fromScale(1, 1)
	end

	local Background = v1:FindFirstChild("Background")

	if Background and Background:IsA("GuiObject") then
		Background.BackgroundTransparency = 1
		TweenService:Create(Background, TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			BackgroundTransparency = 0
		}):Play()
	end

	v1.Visible = true
	v22 = v1

	local v20 = false
	local v212 = false
	local v222 = os.clock()
	local v232 = 0
	local t4 = {}

	v23 = function() --[[ Line: 1717 | Upvalues: v20 (ref), t4 (copy), ContextActionService (ref), t3 (copy), v6 (ref), v4 (copy) ]]
		v20 = true

		for v1, v2 in t4 do
			v2:Disconnect()
		end

		ContextActionService:UnbindAction("DeepsFailSave")
		ContextActionService:UnbindAction("DeepsFailOkay")

		for v3, v42 in t3 do
			v42:Destroy()
		end

		if not v6 then
			return
		end

		v6:Destroy()
		v6 = nil
		v4.Visible = true
	end

	local function finish(p1) --[[ finish | Line: 1734 | Upvalues: v20 (ref), Remotes (ref), v21 (ref), v23 (ref), v22 (ref) ]]
		if v20 then
			return
		end

		if p1 then
			Remotes.DeepsForfeitRecovery:Fire()
		end

		local v1 = v21

		v21 = nil

		if v1 then
			v1:Destroy()
		end

		local v2 = v23

		v23 = nil

		if v2 then
			v2()
		end

		local v3 = v22

		v22 = nil

		if not v3 then
			return
		end

		v3.Visible = false
	end

	local function promptRecovery() --[[ promptRecovery | Line: 1744 | Upvalues: v212 (ref), v20 (ref), v232 (ref), v222 (ref), MarketplaceService (ref), LocalPlayer (ref), DeepsConfig (ref) ]]
		if not (v212 or v20) then
			v212 = true
			v232 = os.clock() - v222
			MarketplaceService:PromptProductPurchase(LocalPlayer, DeepsConfig.RecoveryProduct)
		end
	end

	local function showRobuxButton() --[[ showRobuxButton | Line: 1755 | Upvalues: v6 (ref), v4 (copy) ]]
		local v1 = v6

		v6 = nil

		if v1 then
			v1:Destroy()
		end

		v4.Visible = true
	end

	local function watchAd() --[[ watchAd | Line: 1769 | Upvalues: v212 (ref), v20 (ref), v232 (ref), v222 (ref), Remotes (ref), v21 (ref), v23 (ref), v22 (ref), v6 (ref), v4 (copy) ]]
		if not (v212 or v20) then
			v212 = true
			v232 = os.clock() - v222
			task.spawn(function() --[[ Line: 1775 | Upvalues: Remotes (ref), v20 (ref), v21 (ref), v23 (ref), v22 (ref), v212 (ref), v6 (ref), v4 (ref) ]]
				local v1, v2 = Remotes.DeepsWatchAdForLoot:Call():Await()

				if v20 then
					return
				end

				if v1 and (type(v2) == "table" and v2.Ok) then
					if v20 then
						return
					end

					local v3 = v21

					v21 = nil

					if v3 then
						v3:Destroy()
					end

					local v42 = v23

					v23 = nil

					if v42 then
						v42()
					end

					local v5 = v22

					v22 = nil

					if not v5 then
						return
					end

					v5.Visible = false
				else
					v212 = false

					local v62 = v6

					v6 = nil

					if v62 then
						v62:Destroy()
					end

					v4.Visible = true
				end
			end)
		end
	end

	if v6 then
		table.insert(t4, v6.MouseButton1Down:Connect(watchAd))
	end

	table.insert(t4, v4.MouseButton1Down:Connect(promptRecovery))

	local function f24() --[[ Line: 1795 | Upvalues: v20 (ref), Remotes (ref), v21 (ref), v23 (ref), v22 (ref) ]]
		if v20 then
			return
		end

		Remotes.DeepsForfeitRecovery:Fire()

		local v1 = v21

		v21 = nil

		if v1 then
			v1:Destroy()
		end

		local v2 = v23

		v23 = nil

		if v2 then
			v2()
		end

		local v3 = v22

		v22 = nil

		if not v3 then
			return
		end

		v3.Visible = false
	end

	table.insert(t4, v5.MouseButton1Down:Connect(f24))

	local PromptProductPurchaseFinished = MarketplaceService.PromptProductPurchaseFinished

	local function f25(p1, p2, p3) --[[ Line: 1801 | Upvalues: LocalPlayer (ref), DeepsConfig (ref), v212 (ref), v20 (ref), v21 (ref), v23 (ref), v22 (ref) ]]
		if p1 ~= LocalPlayer.UserId or p2 ~= DeepsConfig.RecoveryProduct then
			return
		end

		v212 = false

		if not p3 then
			return
		end

		if v20 then
			return
		end

		local v1 = v21

		v21 = nil

		if v1 then
			v1:Destroy()
		end

		local v2 = v23

		v23 = nil

		if v2 then
			v2()
		end

		local v3 = v22

		v22 = nil

		if not v3 then
			return
		end

		v3.Visible = false
	end

	table.insert(t4, PromptProductPurchaseFinished:Connect(f25))
	bindToButtonPress("DeepsFailSave", Enum.KeyCode.ButtonX, function() --[[ Line: 1813 | Upvalues: v6 (ref), v212 (ref), v20 (ref), v232 (ref), v222 (ref), Remotes (ref), v21 (ref), v23 (ref), v22 (ref), v4 (copy), MarketplaceService (ref), LocalPlayer (ref), DeepsConfig (ref) ]]
		if v6 then
			if v212 then
				return
			end

			if not v20 then
				v212 = true
				v232 = os.clock() - v222
				task.spawn(function() --[[ Line: 1775 | Upvalues: Remotes (ref), v20 (ref), v21 (ref), v23 (ref), v22 (ref), v212 (ref), v6 (ref), v4 (ref) ]]
					local v1, v2 = Remotes.DeepsWatchAdForLoot:Call():Await()

					if v20 then
						return
					end

					if v1 and (type(v2) == "table" and v2.Ok) then
						if v20 then
							return
						end

						local v3 = v21

						v21 = nil

						if v3 then
							v3:Destroy()
						end

						local v42 = v23

						v23 = nil

						if v42 then
							v42()
						end

						local v5 = v22

						v22 = nil

						if not v5 then
							return
						end

						v5.Visible = false
					else
						v212 = false

						local v62 = v6

						v6 = nil

						if v62 then
							v62:Destroy()
						end

						v4.Visible = true
					end
				end)
			end

			return
		end

		if v212 then
			return
		end

		if v20 then
			return
		end

		v212 = true
		v232 = os.clock() - v222
		MarketplaceService:PromptProductPurchase(LocalPlayer, DeepsConfig.RecoveryProduct)
	end)
	bindToButtonPress("DeepsFailOkay", Enum.KeyCode.ButtonB, function() --[[ Line: 1821 | Upvalues: v20 (ref), Remotes (ref), v21 (ref), v23 (ref), v22 (ref) ]]
		if v20 then
			return
		end

		Remotes.DeepsForfeitRecovery:Fire()

		local v1 = v21

		v21 = nil

		if v1 then
			v1:Destroy()
		end

		local v2 = v23

		v23 = nil

		if v2 then
			v2()
		end

		local v3 = v22

		v22 = nil

		if not v3 then
			return
		end

		v3.Visible = false
	end)
	task.spawn(function() --[[ Line: 1825 | Upvalues: DeepsConfig (ref), v20 (ref), v22 (ref), v1 (copy), v212 (ref), v222 (ref), v232 (ref), v18 (copy), v19 (copy), Remotes (ref), v21 (ref), v23 (ref) ]]
		local FailScreenSeconds = DeepsConfig.FailScreenSeconds

		while not v20 and v22 == v1 do
			if v212 then
				v222 = os.clock() - v232
			else
				local v2 = math.max(FailScreenSeconds - (os.clock() - v222), 0)

				if v18 and v18:IsA("GuiObject") then
					v18.Size = UDim2.fromScale(if FailScreenSeconds > 0 then v2 / FailScreenSeconds else 0, 1)
				end

				if v19 and v19:IsA("TextLabel") then
					v19.Text = ("%*s"):format((math.ceil(v2)))
				end

				if v2 <= 0 then
					if v20 then
						break
					end

					Remotes.DeepsForfeitRecovery:Fire()

					local v5 = v21

					v21 = nil

					if v5 then
						v5:Destroy()
					end

					local v6 = v23

					v23 = nil

					if v6 then
						v6()
					end

					local v7 = v22

					v22 = nil

					if v7 then
						v7.Visible = false

						return
					end

					break
				end
			end

			task.wait()
		end
	end)

	return true
end

local function isRecoveryAdAvailable() --[[ isRecoveryAdAvailable | Line: 1855 | Upvalues: DeepsConfig (copy), AdService (copy) ]]
	local RecoveryAdPlacement = DeepsConfig.RecoveryAdPlacement

	if not RecoveryAdPlacement or RecoveryAdPlacement == 0 then
		return false
	end

	local v1 = nil

	task.spawn(function() --[[ Line: 1861 | Upvalues: AdService (ref), v1 (ref) ]]
		local ok, result = pcall(function() --[[ Line: 1862 | Upvalues: AdService (ref) ]]
			return AdService:GetAdAvailabilityNowAsync(Enum.AdFormat.RewardedVideo)
		end)

		v1 = if ok then if type(result) == "table" then result.AdAvailabilityResult == Enum.AdAvailabilityResult.IsAvailable else false else ok
	end)

	local v2 = os.clock() + (DeepsConfig.RecoveryAdCheckSeconds or 0)

	while v1 == nil and os.clock() < v2 do
		task.wait()
	end

	local v3 = v1 == true

	return v3
end

local function showFailScreen(p1, p2) --[[ showFailScreen | Line: 1876 | Upvalues: v21 (ref), v23 (ref), v22 (ref), showTemplateFailScreen (copy), LocalPlayer (copy), v3 (copy), TweenService (copy), FishConfig (copy), DeepsLootConfig (copy), MarketplaceService (copy), DeepsConfig (copy), Remotes (copy) ]]
	local v1 = v21

	v21 = nil

	if v1 then
		v1:Destroy()
	end

	local v2 = v23

	v23 = nil

	if v2 then
		v2()
	end

	local v32 = v22

	v22 = nil

	if v32 then
		v32.Visible = false
	end

	if #p1 > 0 and showTemplateFailScreen(p1, p2) then
		return
	end

	local DeepsFailScreen = Instance.new("ScreenGui")

	DeepsFailScreen.Name = "DeepsFailScreen"
	DeepsFailScreen.ResetOnSpawn = false
	DeepsFailScreen.DisplayOrder = 90
	DeepsFailScreen.IgnoreGuiInset = true
	DeepsFailScreen.Parent = LocalPlayer:WaitForChild("PlayerGui")
	v21 = DeepsFailScreen

	local Frame = Instance.new("Frame")

	Frame.Size = UDim2.fromScale(1, 1)
	Frame.BackgroundColor3 = v3
	Frame.BackgroundTransparency = 1
	Frame.BorderSizePixel = 0
	Frame.Parent = DeepsFailScreen
	TweenService:Create(Frame, TweenInfo.new(0.6, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
		BackgroundTransparency = 0
	}):Play()

	if #p1 == 0 then
		task.delay(1.2, function() --[[ Line: 1904 | Upvalues: v21 (ref), DeepsFailScreen (copy), TweenService (ref), Frame (copy), v23 (ref), v22 (ref) ]]
			if v21 == DeepsFailScreen then
				local v1 = TweenService:Create(Frame, TweenInfo.new(0.8), {
					BackgroundTransparency = 1
				})

				v1.Completed:Once(function() --[[ Line: 1909 | Upvalues: v21 (ref), DeepsFailScreen (ref), v23 (ref), v22 (ref) ]]
					if v21 ~= DeepsFailScreen then
						return
					end

					local v1 = v21

					v21 = nil

					if v1 then
						v1:Destroy()
					end

					local v2 = v23

					v23 = nil

					if v2 then
						v2()
					end

					local v3 = v22

					v22 = nil

					if not v3 then
						return
					end

					v3.Visible = false
				end)
				v1:Play()
			end
		end)

		return
	end

	local Frame2 = Instance.new("Frame")

	Frame2.AnchorPoint = Vector2.new(0.5, 0.5)
	Frame2.Position = UDim2.fromScale(0.5, 0.5)
	Frame2.Size = UDim2.fromOffset(340, #p1 * 22 + 190)
	Frame2.BackgroundColor3 = Color3.fromRGB(25, 25, 30)
	Frame2.BorderSizePixel = 0
	Frame2.Parent = DeepsFailScreen

	local UICorner = Instance.new("UICorner")

	UICorner.CornerRadius = UDim.new(0, 12)
	UICorner.Parent = Frame2

	local TextLabel = Instance.new("TextLabel")

	TextLabel.Size = UDim2.new(1, 0, 0, 46)
	TextLabel.BackgroundTransparency = 1
	TextLabel.Font = Enum.Font.GothamBlack
	TextLabel.TextSize = 22
	TextLabel.TextColor3 = Color3.fromRGB(255, 90, 90)
	TextLabel.Text = "You ran out of air!"
	TextLabel.Parent = Frame2

	local TextLabel2 = Instance.new("TextLabel")

	TextLabel2.Position = UDim2.fromOffset(0, 44)
	TextLabel2.Size = UDim2.new(1, 0, 0, 22)
	TextLabel2.BackgroundTransparency = 1
	TextLabel2.Font = Enum.Font.GothamBold
	TextLabel2.TextSize = 15
	TextLabel2.TextColor3 = Color3.new(255/255, 255/255, 255/255)
	TextLabel2.Text = "Your loot sank:"
	TextLabel2.Parent = Frame2

	for v6, v7 in p1 do
		local v4, v5
		local TextLabel3 = Instance.new("TextLabel")

		TextLabel3.Position = UDim2.fromOffset(0, (v6 - 1) * 22 + 66)
		TextLabel3.Size = UDim2.new(1, 0, 0, 20)
		TextLabel3.BackgroundTransparency = 1
		TextLabel3.Font = Enum.Font.GothamBold
		TextLabel3.TextSize = 15

		local v8 = if v7.Type == "Fish" then FishConfig[v7.Name] else DeepsLootConfig.Items[v7.Name]
		local v9

		if v8 and v8.Rarity then
			v4 = v8.Rarity.rarityColor

			if not v4 then
				v9 = Color3.new(255/255, 255/255, 255/255)
				v4 = v9
			end
		else
			v9 = Color3.new(255/255, 255/255, 255/255)
			v4 = v9
		end

		TextLabel3.TextColor3 = v4
		v5 = if v7.Type == "Fish" then FishConfig[v7.Name] and FishConfig[v7.Name].DisplayName or v7.Name else DeepsLootConfig.Items[v7.Name] and DeepsLootConfig.Items[v7.Name].DisplayName or v7.Name
		TextLabel3.Text = v5
		TextLabel3.Parent = Frame2
	end

	local function makeButton(p1, p2, p3) --[[ makeButton | Line: 1961 | Upvalues: Frame2 (copy) ]]
		local TextButton = Instance.new("TextButton")

		TextButton.AnchorPoint = Vector2.new(0.5, 1)
		TextButton.Position = UDim2.new(0.5, 0, 1, p3)
		TextButton.Size = UDim2.new(1, -40, 0, 40)
		TextButton.BackgroundColor3 = p2
		TextButton.Font = Enum.Font.GothamBlack
		TextButton.TextSize = 17
		TextButton.TextColor3 = Color3.new(255/255, 255/255, 255/255)
		TextButton.Text = p1
		TextButton.Parent = Frame2

		local UICorner = Instance.new("UICorner")

		UICorner.CornerRadius = UDim.new(0, 10)
		UICorner.Parent = TextButton

		return TextButton
	end

	makeButton("Get it back (R$)", Color3.fromRGB(60, 170, 90), -62).MouseButton1Click:Connect(function() --[[ Line: 1979 | Upvalues: MarketplaceService (ref), LocalPlayer (ref), DeepsConfig (ref) ]]
		MarketplaceService:PromptProductPurchase(LocalPlayer, DeepsConfig.RecoveryProduct)
	end)
	makeButton("Leave it", Color3.fromRGB(120, 60, 60), -14).MouseButton1Click:Connect(function() --[[ Line: 1983 | Upvalues: Remotes (ref), v21 (ref), v23 (ref), v22 (ref) ]]
		Remotes.DeepsForfeitRecovery:Fire()

		local v1 = v21

		v21 = nil

		if v1 then
			v1:Destroy()
		end

		local v2 = v23

		v23 = nil

		if v2 then
			v2()
		end

		local v3 = v22

		v22 = nil

		if not v3 then
			return
		end

		v3.Visible = false
	end)
end

local function showSummary(p1) --[[ showSummary | Line: 1993 | Upvalues: SFX (copy), LocalPlayer (copy), FishConfig (copy), DeepsLootConfig (copy), popInGui (copy) ]]
	if #p1 == 0 then
		return
	end

	SFX.new(SFX.Sounds.Fireworks2, 0.4)
	SFX.new(SFX.Sounds.Collect, 0.5)

	local DeepsSummary = Instance.new("ScreenGui")

	DeepsSummary.Name = "DeepsSummary"
	DeepsSummary.ResetOnSpawn = false
	DeepsSummary.DisplayOrder = 70
	DeepsSummary.Parent = LocalPlayer:WaitForChild("PlayerGui")

	local Frame = Instance.new("Frame")

	Frame.AnchorPoint = Vector2.new(0.5, 0)
	Frame.Position = UDim2.new(0.5, 0, 0, 90)
	Frame.Size = UDim2.fromOffset(300, #p1 * 22 + 64)
	Frame.BackgroundColor3 = Color3.fromRGB(25, 30, 40)
	Frame.BackgroundTransparency = 0.15
	Frame.BorderSizePixel = 0
	Frame.Parent = DeepsSummary

	local UICorner = Instance.new("UICorner")

	UICorner.CornerRadius = UDim.new(0, 12)
	UICorner.Parent = Frame

	local TextLabel = Instance.new("TextLabel")

	TextLabel.Size = UDim2.new(1, 0, 0, 40)
	TextLabel.BackgroundTransparency = 1
	TextLabel.Font = Enum.Font.GothamBlack
	TextLabel.TextSize = 20
	TextLabel.TextColor3 = Color3.fromRGB(140, 255, 170)
	TextLabel.Text = "Dive loot collected!"
	TextLabel.Parent = Frame

	for v3, v4 in p1 do
		local v1, v2
		local TextLabel2 = Instance.new("TextLabel")

		TextLabel2.Position = UDim2.fromOffset(0, (v3 - 1) * 22 + 44)
		TextLabel2.Size = UDim2.new(1, 0, 0, 20)
		TextLabel2.BackgroundTransparency = 1
		TextLabel2.Font = Enum.Font.GothamBold
		TextLabel2.TextSize = 15

		local v5 = if v4.Type == "Fish" then FishConfig[v4.Name] else DeepsLootConfig.Items[v4.Name]
		local v6

		if v5 and v5.Rarity then
			v1 = v5.Rarity.rarityColor

			if not v1 then
				v6 = Color3.new(255/255, 255/255, 255/255)
				v1 = v6
			end
		else
			v6 = Color3.new(255/255, 255/255, 255/255)
			v1 = v6
		end

		TextLabel2.TextColor3 = v1
		v2 = if v4.Type == "Fish" then FishConfig[v4.Name] and FishConfig[v4.Name].DisplayName or v4.Name else DeepsLootConfig.Items[v4.Name] and DeepsLootConfig.Items[v4.Name].DisplayName or v4.Name
		TextLabel2.Text = v2
		TextLabel2.Parent = Frame
	end

	popInGui(Frame, true)
	task.delay(4, function() --[[ Line: 2040 | Upvalues: DeepsSummary (copy) ]]
		DeepsSummary:Destroy()
	end)
end

local v24 = 0

local function refreshVolume() --[[ refreshVolume | Line: 2051 | Upvalues: Workspace (copy), DeepsConfig (copy), DeepsState (copy) ]]
	local v1 = Workspace:FindFirstChild(DeepsConfig.WaterVolumeName, true)

	DeepsState.volume = if v1 and v1:IsA("BasePart") then v1 else nil
end

function t.Init(p1) --[[ Init | Line: 2056 | Upvalues: DeepsConfig (copy), LocalPlayer (copy), DeepsLootFeed (copy), Remotes (copy), isRecoveryAdAvailable (copy), showFailScreen (copy), showSummary (copy), CollectFishUI (copy), SFX (copy), ClientPlayerData (copy), v21 (ref), v23 (ref), v22 (ref), updateBagHud (copy), RunService (copy), v24 (ref), Workspace (copy), DeepsState (copy), IsInsideVolume (copy), GetSurfaceY (copy), setUnderwaterAmbience (copy), v18 (ref), startDive (copy), endDive (copy), stepDive (copy) ]]
	if DeepsConfig.Enabled then
		task.spawn(function() --[[ Line: 2070 | Upvalues: LocalPlayer (ref), DeepsLootFeed (ref) ]]
			LocalPlayer.PlayerGui:WaitForChild("MainUI", 10)
			DeepsLootFeed.prepare()
		end)
		Remotes.DeepsFailed:On(function(p1) --[[ Line: 2075 | Upvalues: isRecoveryAdAvailable (ref), showFailScreen (ref) ]]
			local v1 = if type(p1) == "table" then if type(p1.Entries) == "table" then p1.Entries else {} else {}

			showFailScreen(v1, if #v1 > 0 then isRecoveryAdAvailable() else false)
		end)
		Remotes.DeepsBagSettled:On(function(p1) --[[ Line: 2082 | Upvalues: DeepsLootFeed (ref), showSummary (ref), CollectFishUI (ref), SFX (ref) ]]
			local v1 = if type(p1) == "table" then if type(p1.Entries) == "table" then p1.Entries else {} else {}

			if #v1 == 0 then
				return
			end

			local v2 = DeepsLootFeed.showSettled(v1)

			if not v2 then
				showSummary(v1)
			end

			local t = {}
			local t2 = {}

			for v3, v4 in v1 do
				if v4.Type == "Fish" and not t[v4.Name] then
					t[v4.Name] = true
					table.insert(t2, v4.Name)
				end
			end

			if #t2 > 0 then
				CollectFishUI.playMultiple(t2, nil)

				return
			end

			if not v2 then
				return
			end

			SFX.new(SFX.Sounds.Collect, 0.5)
		end)
		ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 2113 ]]
			return p1.deeps and p1.deeps.pendingRecovery
		end, function(p1) --[[ Line: 2115 | Upvalues: v21 (ref), v23 (ref), v22 (ref) ]]
			if p1 ~= nil then
				return
			end

			local v1 = v21

			v21 = nil

			if v1 then
				v1:Destroy()
			end

			local v2 = v23

			v23 = nil

			if v2 then
				v2()
			end

			local v3 = v22

			v22 = nil

			if not v3 then
				return
			end

			v3.Visible = false
		end)
		ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 2121 ]]
			return p1.deeps and p1.deeps.bag
		end, function(p1, p2) --[[ Line: 2123 | Upvalues: updateBagHud (ref), DeepsLootFeed (ref) ]]
			updateBagHud()

			local v1 = if type(p1) == "table" then #p1 else 0

			for i = (if type(p2) == "table" then #p2 else 0) + 1, v1 do
				DeepsLootFeed.showCollected(p1[i])
			end
		end)
		RunService.Heartbeat:Connect(function(p1) --[[ Line: 2134 | Upvalues: v24 (ref), Workspace (ref), DeepsConfig (ref), DeepsState (ref), IsInsideVolume (ref), GetSurfaceY (ref), setUnderwaterAmbience (ref), LocalPlayer (ref), v18 (ref), startDive (ref), endDive (ref), stepDive (ref) ]]
			debug.profilebegin("UECS/DeepsDiving.Step")

			if v24 <= os.clock() then
				v24 = os.clock() + 3

				local v1 = Workspace:FindFirstChild(DeepsConfig.WaterVolumeName, true)

				DeepsState.volume = if v1 and v1:IsA("BasePart") then v1 else nil
			end

			local volume = DeepsState.volume
			local CurrentCamera = Workspace.CurrentCamera
			local v4

			if volume == nil or CurrentCamera == nil then
				v4 = false
			else
				local Position = CurrentCamera.CFrame.Position

				v4 = IsInsideVolume(volume, Position) and (if GetSurfaceY(volume) - Position.Y >= DeepsConfig.Underwater.CameraSubmergeDepth then true else false)
			end

			setUnderwaterAmbience(v4)

			local Character = LocalPlayer.Character
			local v6, v7

			if Character then
				local Humanoid = Character:FindFirstChildOfClass("Humanoid")
				local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")

				if HumanoidRootPart and HumanoidRootPart:IsA("BasePart") then
					v6 = Humanoid
					v7 = HumanoidRootPart
				else
					v6 = Humanoid
					v7 = nil
				end
			else
				v6 = nil
				v7 = nil
			end

			local v8 = if volume == nil or (v6 == nil or (not (v6.Health > 0) or v7 == nil)) then false else IsInsideVolume(volume, v7.Position)

			if v8 and (not v18 and (v6 and v7)) then
				startDive(v6, v7)
			elseif not v8 and v18 then
				endDive()
			end

			if v18 and volume then
				stepDive(volume, p1)
			end

			debug.profileend()
		end)
	else
		task.spawn(function() --[[ Line: 2059 | Upvalues: LocalPlayer (ref), DeepsConfig (ref) ]]
			local MainUI = LocalPlayer.PlayerGui:WaitForChild("MainUI", 5)
			local v1 = if MainUI then MainUI:FindFirstChild(DeepsConfig.UiFrameName) else MainUI

			if not (v1 and v1:IsA("Frame")) then
				return
			end

			v1.Visible = false
		end)
	end
end

return t