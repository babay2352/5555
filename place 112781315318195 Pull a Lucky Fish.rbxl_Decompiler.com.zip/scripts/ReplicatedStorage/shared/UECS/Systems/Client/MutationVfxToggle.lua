-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local VfxTag = require(ReplicatedStorage.shared.config.MutationConfig).VfxTag
local t = {
	ParticleEmitter = true,
	Beam = true,
	Trail = true,
	Fire = true,
	Smoke = true,
	Sparkles = true,
	PointLight = true,
	SpotLight = true,
	SurfaceLight = true
}
local t2 = {
	UECS = nil
}

local function collectRestores(p1) --[[ collectRestores | Line: 55 | Upvalues: t (copy) ]]
	local t2 = {}

	local function visit(p1) --[[ visit | Line: 57 | Upvalues: t (ref), t2 (copy) ]]
		if t[p1.ClassName] then
			t2[p1] = {
				property = "Enabled",
				hidden = false,
				instance = p1,
				shown = p1.Enabled
			}

			return
		end

		if not (p1:IsA("BasePart") or p1:IsA("Decal")) then
			return
		end

		t2[p1] = {
			property = "Transparency",
			hidden = 1,
			instance = p1,
			shown = p1.Transparency
		}
	end

	visit(p1)

	for v1, v2 in p1:GetDescendants() do
		visit(v2)
	end

	return t2
end

function t2.Init(p1) --[[ Init | Line: 83 | Upvalues: collectRestores (copy), CollectionService (copy), VfxTag (copy), ClientPlayerData (copy) ]]
	local t = {}
	local v1 = true

	local function isOnBaseFish(p1) --[[ isOnBaseFish | Line: 91 ]]
		local v1 = p1.Parent

		while v1 and v1 ~= workspace do
			if v1:HasTag("IdleFishFloat") then
				return true
			end

			v1 = v1.Parent
		end

		return false
	end

	local function apply(p1) --[[ apply | Line: 102 | Upvalues: t (copy), v1 (ref), isOnBaseFish (copy), collectRestores (ref) ]]
		local v12 = t[p1]

		if not v12 then
			return
		end

		local v2 = not v1 and isOnBaseFish(p1)

		if v2 then
			for v3, v4 in collectRestores(p1) do
				if v12[v3] == nil then
					v12[v3] = v4
				end
			end
		end

		for v5, v6 in v12 do
			if v5.Parent then
				v5[v6.property] = if v2 then v6.hidden else v6.shown

				continue
			end

			v12[v5] = nil
		end
	end

	local function track(p1) --[[ track | Line: 129 | Upvalues: t (copy), collectRestores (ref), apply (copy) ]]
		if not t[p1] then
			t[p1] = collectRestores(p1)
			apply(p1)
		end
	end

	for v2, v3 in CollectionService:GetTagged(VfxTag) do
		if not t[v3] then
			t[v3] = collectRestores(v3)
			apply(v3)
		end
	end

	CollectionService:GetInstanceAddedSignal(VfxTag):Connect(track)
	CollectionService:GetInstanceRemovedSignal(VfxTag):Connect(function(p1) --[[ Line: 141 | Upvalues: t (copy) ]]
		t[p1] = nil
	end)
	CollectionService:GetInstanceAddedSignal("IdleFishFloat"):Connect(function(p1) --[[ Line: 149 | Upvalues: v1 (ref), VfxTag (ref), t (copy), collectRestores (ref), apply (copy) ]]
		if v1 then
			return
		end

		for v12, v2 in p1:GetDescendants() do
			if v2:HasTag(VfxTag) then
				if not t[v2] then
					t[v2] = collectRestores(v2)
					apply(v2)
				end

				apply(v2)
			end
		end
	end)

	local function applySetting(p1) --[[ applySetting | Line: 161 | Upvalues: v1 (ref), t (copy), apply (copy) ]]
		local v12 = if p1 then p1.baseMutationVfxEnabled else nil
		local v2 = if v12 == nil then true else v12

		if v2 == v1 then
			return
		end

		v1 = v2

		for v3 in t do
			if v3.Parent then
				apply(v3)

				continue
			end

			t[v3] = nil
		end
	end

	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 179 ]]
		return p1.settings
	end, applySetting)
	applySetting(ClientPlayerData.serverProfile:getState().settings)
end

return t2