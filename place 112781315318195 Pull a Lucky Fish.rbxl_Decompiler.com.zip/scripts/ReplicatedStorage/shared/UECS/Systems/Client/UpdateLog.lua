-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ContextActionService = game:GetService("ContextActionService")
local GamepadService = game:GetService("GamepadService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local UpdateLog = require(ReplicatedStorage.shared.UECS.Components.UpdateLog)
local bindToButtonPress = require(ReplicatedStorage.shared.util.bindToButtonPress)
local versionConfig = require(ReplicatedStorage.shared.config.versionConfig)

return {
	UECS = nil,
	Priority = 40,
	Init = function(p1) --[[ Init | Line: 21 | Upvalues: ClientPlayerData (copy), Players (copy), UpdateLog (copy), bindToButtonPress (copy), GamepadService (copy), ContextActionService (copy), versionConfig (copy) ]]
		repeat
			task.wait()
		until ClientPlayerData.isPlayerDataLoaded

		local UpdateLog2 = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI"):WaitForChild("UpdateLog")

		UpdateLog2.Visible = false

		local v1 = UpdateLog.Add(UpdateLog2)

		v1.Visible.OnChange:Connect(function(p12, p2) --[[ Line: 31 | Upvalues: UpdateLog2 (copy), bindToButtonPress (ref), p1 (copy), GamepadService (ref), ContextActionService (ref) ]]
			UpdateLog2.Visible = p12

			if p12 == p2 then
				return
			end

			if p12 then
				bindToButtonPress("UpdateLogClose", Enum.KeyCode.ButtonB, function() --[[ Line: 36 | Upvalues: p1 (ref) ]]
					p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
				end)
				GamepadService:EnableGamepadCursor(UpdateLog2)

				return
			end

			GamepadService:DisableGamepadCursor()
			ContextActionService:UnbindAction("UpdateLogClose")
		end)
		GamepadService:GetPropertyChangedSignal("GamepadCursorEnabled"):Connect(function() --[[ Line: 49 | Upvalues: GamepadService (ref), UpdateLog2 (copy) ]]
			if GamepadService.GamepadCursorEnabled or not UpdateLog2.Visible then
				return
			end

			GamepadService:EnableGamepadCursor(UpdateLog2)
		end)
		UpdateLog2.TopBar.CloseButton.MouseButton1Down:Connect(function() --[[ Line: 56 | Upvalues: p1 (copy) ]]
			p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
		end)

		local v2 = if ClientPlayerData.serverProfile:getState().tutorialInfo.tutorialStep == 1 then ClientPlayerData.serverProfile:getState().stats.fishCaught == 0 else false

		if v2 then
			ClientPlayerData.serverProfile.setVersion(versionConfig.Version)

			return
		end

		if ClientPlayerData.serverProfile:getState().version == versionConfig.Version then
			return
		end

		local v3 = false

		local function showUpdateLog() --[[ showUpdateLog | Line: 77 | Upvalues: v3 (ref), p1 (copy), v1 (copy), ClientPlayerData (ref), versionConfig (ref) ]]
			if not v3 then
				v3 = true
				task.delay(0.3, function() --[[ Line: 82 | Upvalues: p1 (ref), v1 (ref) ]]
					p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(v1)
				end)
				ClientPlayerData.serverProfile.setVersion(versionConfig.Version)
			end
		end

		local function checkDailyLoginFinished() --[[ checkDailyLoginFinished | Line: 90 | Upvalues: Players (ref), v3 (ref), p1 (copy), v1 (copy), ClientPlayerData (ref), versionConfig (ref) ]]
			if Players.LocalPlayer:GetAttribute("DailyLoginFinished") ~= true then
				return false
			end

			if v3 then
				return true
			end

			v3 = true
			task.delay(0.3, function() --[[ Line: 82 | Upvalues: p1 (ref), v1 (ref) ]]
				p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(v1)
			end)
			ClientPlayerData.serverProfile.setVersion(versionConfig.Version)

			return true
		end

		local v4

		if Players.LocalPlayer:GetAttribute("DailyLoginFinished") == true then
			if not v3 then
				v3 = true
				task.delay(0.3, function() --[[ Line: 82 | Upvalues: p1 (copy), v1 (copy) ]]
					p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(v1)
				end)
				ClientPlayerData.serverProfile.setVersion(versionConfig.Version)
			end

			v4 = true
		else
			v4 = false
		end

		if not v4 then
			local v5 = nil

			v5 = Players.LocalPlayer:GetAttributeChangedSignal("DailyLoginFinished"):Connect(function() --[[ Line: 100 | Upvalues: Players (ref), v3 (ref), p1 (copy), v1 (copy), ClientPlayerData (ref), versionConfig (ref), v5 (ref) ]]
				local v12

				if Players.LocalPlayer:GetAttribute("DailyLoginFinished") == true then
					if not v3 then
						v3 = true
						task.delay(0.3, function() --[[ Line: 82 | Upvalues: p1 (ref), v1 (ref) ]]
							p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(v1)
						end)
						ClientPlayerData.serverProfile.setVersion(versionConfig.Version)
					end

					v12 = true
				else
					v12 = false
				end

				if not v12 then
					return
				end

				v5:Disconnect()
			end)
		end
	end
}