-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ContentProvider = game:GetService("ContentProvider")
local ContextActionService = game:GetService("ContextActionService")
local GuiService = game:GetService("GuiService")
local MarketplaceService = game:GetService("MarketplaceService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local UserInputService = game:GetService("UserInputService")
local BaseSkinConfig = require(ReplicatedStorage.shared.config.BaseSkinConfig)
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local CashDisplay = require(ReplicatedStorage.shared.module.CashDisplay)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local RebirthUnlocksConfig = require(ReplicatedStorage.shared.config.RebirthUnlocksConfig)
local Remotes = require(ReplicatedStorage.shared.Remotes)

require(ReplicatedStorage.shared.UECS.Components.TycoonComponent)

local WalkableUI = require(ReplicatedStorage.shared.UECS.Components.WalkableUI)
local notifications = require(ReplicatedStorage.shared.module.notifications)
local v1 = RunService:IsStudio()
local v2 = 0

task.spawn(function() --[[ Line: 24 | Upvalues: BaseSkinConfig (copy), ContentProvider (copy) ]]
	local t = {}

	for v1, v2 in BaseSkinConfig.Config do
		table.insert(t, v2.Icon)
	end

	ContentProvider:PreloadAsync(t)
end)

local v3 = Color3.fromRGB(100, 100, 100)
local v4 = Color3.fromRGB(80, 255, 80)
local v5 = Color3.fromRGB(180, 180, 180)
local t = {}
local v6 = utf8.char(57346)
local t2 = {
	"BaseLava",
	"BaseNeon",
	"BaseJungle",
	"BaseCandy",
	"BaseHappy",
	"BaseFootball",
	"BaseMoon",
	"BaseVip",
	"CatBase",
	"BaseAlien"
}

return {
	UECS = nil,
	Priority = 30,
	Init = function(p1) --[[ Init | Line: 66 | Upvalues: Players (copy), ReplicatedStorage (copy), ClientPlayerData (copy), v2 (ref), notifications (copy), Remotes (copy), t2 (copy), BaseSkinConfig (copy), MarketplaceService (copy), v1 (copy), v3 (copy), v4 (copy), CashDisplay (copy), t (copy), v6 (copy), v5 (copy), RebirthUnlocksConfig (copy), GuiService (copy), UserInputService (copy), ContextActionService (copy), WalkableUI (copy) ]]
		local MainUI = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI")
		local PlotShop = MainUI:WaitForChild("PlotShop")
		local ScrollingFrame = PlotShop:WaitForChild("Content"):WaitForChild("ScrollingFrame")
		local TopBar = PlotShop:WaitForChild("TopBar")
		local t3 = {}

		for v12, v22 in ScrollingFrame:GetChildren() do
			if v22:IsA("Frame") and v22.Name == "Template" then
				table.insert(t3, v22)
			end
		end

		for v32, v42 in t3 do
			v42.Visible = false
		end

		local v52 = t3[1]

		if not v52 then
			return
		end

		PlotShop.Visible = false

		local PlotShop2 = require(ReplicatedStorage.shared.UECS.Components.PlotShop)
		local bindToButtonPress = require(ReplicatedStorage.shared.util.bindToButtonPress)
		local v62 = PlotShop2.Add(PlotShop)

		TopBar:WaitForChild("CloseButton").MouseButton1Down:Connect(function() --[[ Line: 94 | Upvalues: p1 (copy) ]]
			p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
		end)

		local t4 = {}
		local __Default__ = v52:Clone()

		__Default__.Name = "__Default__"
		__Default__.LayoutOrder = 0
		__Default__.Visible = true

		local PlotName = __Default__:FindFirstChild("PlotName")

		if PlotName then
			PlotName.Text = "Default Base"
		end

		local Description = __Default__:FindFirstChild("Description")

		if Description then
			Description.Text = "The original base"
		end

		local v7 = __Default__:FindFirstChild("Content")

		if v7 then
			local Icon = v7:FindFirstChild("Icon")

			if Icon then
				Icon.Image = "rbxassetid://102226675057644"
			end
		end

		local Bar = __Default__:FindFirstChild("Bar")

		if Bar then
			Bar.Visible = false
		end

		local Claimbutton = __Default__:FindFirstChild("Claimbutton")

		if Claimbutton then
			Claimbutton.MouseButton1Down:Connect(function() --[[ Line: 132 | Upvalues: ClientPlayerData (ref), v2 (ref), notifications (ref), Remotes (ref) ]]
				if ClientPlayerData.serverProfile:getState().equippedBaseSkin == "" then
					return
				end

				local v1 = os.clock()

				if v1 - v2 < 5 then
					notifications:Send((("Wait %*s to switch skin"):format((math.ceil(5 - (v1 - v2))))))
				else
					v2 = v1
					Remotes.RequestEquipBaseSkin:Fire("")
				end
			end)
		end

		__Default__.Parent = ScrollingFrame
		t4.__Default__ = __Default__

		for v8, v9 in t2 do
			local v10 = BaseSkinConfig.Config[v9]

			if v10 then
				local v11 = v52:Clone()

				v11.Name = v9
				v11.LayoutOrder = v8
				v11.Visible = not v10.HiddenUntilUnlocked

				local PlotName2 = v11:FindFirstChild("PlotName")

				if PlotName2 then
					PlotName2.Text = v10.DisplayName
				end

				local Description2 = v11:FindFirstChild("Description")

				if Description2 then
					Description2.Text = if v10.Mission then v10.Mission.Description else v10.Description or "Available in the Event Store"
				end

				local v13 = v11:FindFirstChild("Content")

				if v13 then
					local Icon = v13:FindFirstChild("Icon")

					if Icon then
						Icon.Image = v10.Icon
					end
				end

				local Claimbutton2 = v11:FindFirstChild("Claimbutton")

				if Claimbutton2 then
					Claimbutton2.MouseButton1Down:Connect(function() --[[ Line: 187 | Upvalues: ClientPlayerData (ref), v9 (copy), v2 (ref), notifications (ref), Remotes (ref), v10 (copy), MarketplaceService (ref), Players (ref), v1 (ref), BaseSkinConfig (ref) ]]
						local v12 = ClientPlayerData.serverProfile:getState()

						if if v12.equippedBaseSkin == v9 then true else false then
							return
						end

						if v12.unlockedBaseSkins and v12.unlockedBaseSkins[v9] then
							local v4 = os.clock()

							if v4 - v2 < 5 then
								notifications:Send((("Wait %*s to switch skin"):format((math.ceil(5 - (v4 - v2))))))
							else
								v2 = v4
								Remotes.RequestEquipBaseSkin:Fire(v9)
							end
						else
							if v10.DevProduct then
								MarketplaceService:PromptProductPurchase(Players.LocalPlayer, v10.DevProduct)

								return
							end

							if not v10.Mission then
								return
							end

							if v1 then
								Remotes.RequestClaimBaseSkin:Fire(v9)

								return
							end

							if BaseSkinConfig.GetMissionProgress(v12, v10.Mission) >= v10.Mission.Goal then
								Remotes.RequestClaimBaseSkin:Fire(v9)
							else
								notifications:Send("Keep going! " .. v10.Mission.Description)
							end
						end
					end)
				end

				v11.Parent = ScrollingFrame
				t4[v9] = v11
			end
		end

		local function refreshAll() --[[ refreshAll | Line: 239 | Upvalues: ClientPlayerData (ref), t4 (copy), v3 (ref), v4 (ref), BaseSkinConfig (ref), v1 (ref), CashDisplay (ref), t (ref), v6 (ref), v5 (ref) ]]
			local v12 = ClientPlayerData.serverProfile:getState()

			for v52, v62 in t4 do
				local v2, v32, v42

				if v52 == "__Default__" then
					local isEquippedBaseSkin = v12.equippedBaseSkin == ""
					local Claimbutton = v62:FindFirstChild("Claimbutton")

					if Claimbutton then
						local v7 = Claimbutton:FindFirstChild("Content")
						local v8 = if v7 then v7:FindFirstChild("Price") else v7

						if v8 then
							v8.Text = if isEquippedBaseSkin then "Equipped" else "Equip"
						end

						if v7 then
							v7.BackgroundColor3 = if isEquippedBaseSkin then v3 else v4
						end
					end

					continue
				end

				local v11 = BaseSkinConfig.Config[v52]

				if v11 then
					local v122 = v12.unlockedBaseSkins and v12.unlockedBaseSkins[v52]
					local v13 = if v12.equippedBaseSkin == v52 then true else false
					local v14, v15, v16, v17, v18, v19, v20, v21, v22, v23, v24, v25, v26

					if v11.HiddenUntilUnlocked then
						v62.Visible = if v122 == true then true else false

						if v122 then
							if v11.Mission then
								v14 = BaseSkinConfig.GetMissionProgress(v12, v11.Mission)
								v2 = v11.Mission.Goal
								v15 = v1

								if v15 then
									v32 = v14
								elseif v2 <= v14 then
									v15 = true
									v32 = v14
								else
									v15 = false
									v32 = v14
								end

								v42 = v15
							else
								v42 = true
								v2 = 0
								v32 = 0
							end

							v16 = v62:FindFirstChild("Bar")

							if v16 then
								v17 = if v11.Mission == nil then false else true
								v16.Visible = v17

								if v11.Mission then
									v18 = v16:FindFirstChild("Fill")

									if v18 then
										v19 = v32 / math.max(v2, 1)
										v20 = math.clamp(v19, 0, 1)
										v18.Size = UDim2.new(v20, 0, 1, 0)
									end

									v21 = v16:FindFirstChild("currentSpeed")

									if v21 and v11.Mission.Type == "TotalCash" then
										CashDisplay.applyParts(v21, {
											{
												Compact = true,
												Value = v32
											},
											" / ",
											{
												Compact = true,
												Value = v2
											}
										})
									elseif v21 and v11.Mission.Type == "IndexPercent" then
										CashDisplay.setPlainText(v21, (("%*%% / %*%%"):format(v32, v2)))
									elseif v21 then
										CashDisplay.setPlainText(v21, v32 .. " / " .. v2)
									end
								end
							end

							v22 = v62:FindFirstChild("Claimbutton")

							if v22 then
								v23 = v22:FindFirstChild("Content")
								v24 = if v23 then v23:FindFirstChild("Price") else v23

								if v13 then
									if v24 then
										v24.Text = "Equipped"
									end

									if v23 then
										v23.BackgroundColor3 = v3
									end

									continue
								end

								if v122 then
									if v24 then
										v24.Text = "Equip"
									end

									if v23 then
										v23.BackgroundColor3 = v4
									end

									continue
								end

								if v11.DevProduct then
									if v24 then
										v25 = t[v52]
										v26 = if v25 then v6 .. tostring(v25) else "Buy"
										v24.Text = v26
									end

									if v23 then
										v23.BackgroundColor3 = v4
									end

									continue
								end

								if v42 then
									if v24 then
										v24.Text = "Claim"
									end

									if v23 then
										v23.BackgroundColor3 = v4
									end

									continue
								end

								if v24 then
									v24.Text = "Locked"
								end

								if v23 then
									v23.BackgroundColor3 = v5
								end
							end
						end
					else
						if v11.Mission then
							v14 = BaseSkinConfig.GetMissionProgress(v12, v11.Mission)
							v2 = v11.Mission.Goal
							v15 = v1

							if v15 then
								v32 = v14
							elseif v2 <= v14 then
								v15 = true
								v32 = v14
							else
								v15 = false
								v32 = v14
							end

							v42 = v15
						else
							v42 = true
							v2 = 0
							v32 = 0
						end

						v16 = v62:FindFirstChild("Bar")

						if v16 then
							v17 = if v11.Mission == nil then false else true
							v16.Visible = v17

							if v11.Mission then
								v18 = v16:FindFirstChild("Fill")

								if v18 then
									v19 = v32 / math.max(v2, 1)
									v20 = math.clamp(v19, 0, 1)
									v18.Size = UDim2.new(v20, 0, 1, 0)
								end

								v21 = v16:FindFirstChild("currentSpeed")

								if v21 and v11.Mission.Type == "TotalCash" then
									CashDisplay.applyParts(v21, {
										{
											Compact = true,
											Value = v32
										},
										" / ",
										{
											Compact = true,
											Value = v2
										}
									})
								elseif v21 and v11.Mission.Type == "IndexPercent" then
									CashDisplay.setPlainText(v21, (("%*%% / %*%%"):format(v32, v2)))
								elseif v21 then
									CashDisplay.setPlainText(v21, v32 .. " / " .. v2)
								end
							end
						end

						v22 = v62:FindFirstChild("Claimbutton")

						if v22 then
							v23 = v22:FindFirstChild("Content")
							v24 = if v23 then v23:FindFirstChild("Price") else v23

							if v13 then
								if v24 then
									v24.Text = "Equipped"
								end

								if v23 then
									v23.BackgroundColor3 = v3
								end

								continue
							end

							if v122 then
								if v24 then
									v24.Text = "Equip"
								end

								if v23 then
									v23.BackgroundColor3 = v4
								end

								continue
							end

							if v11.DevProduct then
								if v24 then
									v25 = t[v52]
									v26 = if v25 then v6 .. tostring(v25) else "Buy"
									v24.Text = v26
								end

								if v23 then
									v23.BackgroundColor3 = v4
								end

								continue
							end

							if v42 then
								if v24 then
									v24.Text = "Claim"
								end

								if v23 then
									v23.BackgroundColor3 = v4
								end

								continue
							end

							if v24 then
								v24.Text = "Locked"
							end

							if v23 then
								v23.BackgroundColor3 = v5
							end
						end
					end
				end
			end
		end

		refreshAll()

		for v14, v15 in BaseSkinConfig.Config do
			local DevProduct = v15.DevProduct

			if DevProduct then
				task.spawn(function() --[[ Line: 359 | Upvalues: MarketplaceService (ref), DevProduct (copy), t (ref), v14 (copy), refreshAll (copy) ]]
					local ok, result = pcall(function() --[[ Line: 360 | Upvalues: MarketplaceService (ref), DevProduct (ref) ]]
						return MarketplaceService:GetProductInfo(DevProduct, Enum.InfoType.Product)
					end)

					if not (ok and (result and result.PriceInRobux)) then
						return
					end

					t[v14] = result.PriceInRobux
					refreshAll()
				end)
			end
		end

		ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 371 ]]
			return {
				p1.unlockedBaseSkins,
				p1.equippedBaseSkin,
				p1.stats,
				p1.index,
				p1.rebirthLevel
			}
		end, function() --[[ Line: 379 | Upvalues: refreshAll (copy) ]]
			refreshAll()
		end)
		v62.Visible.OnChange:Connect(function(p12, p2) --[[ Line: 383 | Upvalues: RebirthUnlocksConfig (ref), ClientPlayerData (ref), notifications (ref), v62 (copy), PlotShop (copy), MainUI (copy), refreshAll (copy), bindToButtonPress (copy), p1 (copy), GuiService (ref), ScrollingFrame (copy), BaseSkinConfig (ref), v2 (ref), Remotes (ref), MarketplaceService (ref), Players (ref), v1 (ref), UserInputService (ref), ContextActionService (ref) ]]
			local v12 = RebirthUnlocksConfig.getByUIComponentName("PlotShop")

			if p12 and (v12 and (ClientPlayerData.serverProfile:getState().rebirthLevel or 0) < v12.RebirthRequired) then
				notifications:Send(v12.LockedText)
				v62.Visible:Set(false)

				return
			end

			PlotShop.Visible = p12

			local HUD = MainUI:FindFirstChild("HUD")

			if HUD then
				HUD.Visible = not p12
			end

			if p12 then
				refreshAll()
			end

			if p12 == p2 then
				return
			end

			if p12 then
				bindToButtonPress("PlotShopClose", Enum.KeyCode.ButtonB, function() --[[ Line: 413 | Upvalues: p1 (ref) ]]
					p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
				end)
				bindToButtonPress("PlotShopEquipSkin", Enum.KeyCode.ButtonX, function() --[[ Line: 418 | Upvalues: GuiService (ref), ScrollingFrame (ref), BaseSkinConfig (ref), ClientPlayerData (ref), v2 (ref), notifications (ref), Remotes (ref), MarketplaceService (ref), Players (ref), v1 (ref) ]]
					local SelectedObject = GuiService.SelectedObject

					if not (SelectedObject and SelectedObject:IsDescendantOf(ScrollingFrame)) then
						return
					end

					local isName = SelectedObject.Name == "__Default__"
					local v12 = if isName then "" else SelectedObject.Name
					local v22 = BaseSkinConfig.Config[v12]
					local v3 = ClientPlayerData.serverProfile:getState()
					local v4 = if isName then isName else v3.unlockedBaseSkins and v3.unlockedBaseSkins[v12]

					if if v3.equippedBaseSkin == v12 then true else false then
						return
					end

					if v4 then
						local v6 = os.clock()

						if v6 - v2 < 5 then
							notifications:Send((("Wait %*s to switch skin"):format((math.ceil(5 - (v6 - v2))))))
						else
							v2 = v6
							Remotes.RequestEquipBaseSkin:Fire(v12)
						end
					else
						if not isName and (v22 and v22.DevProduct) then
							MarketplaceService:PromptProductPurchase(Players.LocalPlayer, v22.DevProduct)

							return
						end

						if not (isName or v22.Mission) then
							return
						end

						if v1 then
							Remotes.RequestClaimBaseSkin:Fire(v12)

							return
						end

						if BaseSkinConfig.GetMissionProgress(v3, v22.Mission) >= v22.Mission.Goal then
							Remotes.RequestClaimBaseSkin:Fire(v12)
						else
							notifications:Send("Keep going! " .. v22.Mission.Description)
						end
					end
				end)

				if UserInputService.PreferredInput == Enum.PreferredInput.Gamepad then
					task.defer(GuiService.Select, GuiService, ScrollingFrame)
				end
			else
				ContextActionService:UnbindAction("PlotShopClose")
				ContextActionService:UnbindAction("PlotShopEquipSkin")
				GuiService.SelectedObject = nil
			end
		end)
		GuiService:GetPropertyChangedSignal("SelectedObject"):Connect(function() --[[ Line: 483 | Upvalues: GuiService (ref), ScrollingFrame (copy), v62 (copy), UserInputService (ref) ]]
			local SelectedObject = GuiService.SelectedObject

			for v1, v2 in ScrollingFrame:QueryDescendants("ImageButton#ClaimButton") do
				v2.ClipsDescendants = not SelectedObject or not v2:IsDescendantOf(SelectedObject)
				print(v2:GetFullName(), v2.ClipsDescendants)
			end

			if SelectedObject or (not v62.Visible:Get() or UserInputService.PreferredInput ~= Enum.PreferredInput.Gamepad) then
				return
			end

			task.defer(GuiService.Select, GuiService, ScrollingFrame)
		end)

		local LocalPlayer = Players.LocalPlayer
		local v16 = nil
		local v17 = nil

		local function spawnPlotModel(p1) --[[ spawnPlotModel | Line: 503 | Upvalues: v16 (ref), ReplicatedStorage (ref), WalkableUI (ref) ]]
			if v16 then
				v16:Destroy()
				v16 = nil
			end

			local OpenPlotShopModel = ReplicatedStorage.shared.model:FindFirstChild("OpenPlotShopModel")

			if not OpenPlotShopModel then
				return
			end

			local OpenPlotShopModel2 = OpenPlotShopModel:Clone()

			OpenPlotShopModel2.Name = "OpenPlotShopModel"

			local PlayerSpawn = p1:FindFirstChild("PlayerSpawn")

			if PlayerSpawn and PlayerSpawn:IsA("BasePart") then
				local Position = (PlayerSpawn.CFrame * CFrame.new(-32, 0, -8)).Position
				local v1 = RaycastParams.new()

				v1.FilterType = Enum.RaycastFilterType.Exclude
				v1.FilterDescendantsInstances = { p1 }

				local v4 = workspace:Raycast(Vector3.new(Position.X, Position.Y + 50, Position.Z), Vector3.new(0, -100, 0), v1)
				local v5 = if v4 then v4.Position.Y else Position.Y

				OpenPlotShopModel2:PivotTo(CFrame.new(Position.X, v5 + 2, Position.Z) * PlayerSpawn.CFrame.Rotation * CFrame.Angles(0, 1.5707963267948966, 0))
			end

			OpenPlotShopModel2.Parent = workspace
			v16 = OpenPlotShopModel2

			local OpenPlotShop = OpenPlotShopModel2:FindFirstChild("OpenPlotShop")

			if not OpenPlotShop then
				return
			end

			WalkableUI.Add(OpenPlotShop).UIComponentName:Set("PlotShop")
		end

		local function destroyPlotModel() --[[ destroyPlotModel | Line: 546 | Upvalues: v16 (ref) ]]
			if not v16 then
				return
			end

			v16:Destroy()
			v16 = nil
		end

		local function watchTycoon(p1) --[[ watchTycoon | Line: 553 | Upvalues: LocalPlayer (copy), v17 (ref), spawnPlotModel (copy), v16 (ref) ]]
			p1.Owner.OnChange:Connect(function(p12) --[[ Line: 554 | Upvalues: LocalPlayer (ref), p1 (copy), v17 (ref), spawnPlotModel (ref), v16 (ref) ]]
				if p12 == LocalPlayer and p1.Entity then
					print(LocalPlayer, p1.Entity)
					v17 = p1
					spawnPlotModel(p1.Entity)

					return
				end

				if p1 ~= v17 or p12 == LocalPlayer then
					return
				end

				v17 = nil
				print(LocalPlayer, p1.Entity)

				if not v16 then
					return
				end

				v16:Destroy()
				v16 = nil
			end)

			if p1.Owner:Get() ~= LocalPlayer or not p1.Entity then
				return
			end

			v17 = p1
			print(LocalPlayer, p1.Entity)
			spawnPlotModel(p1.Entity)
		end

		for v18, v19 in p1.UECS:GetComponents("TycoonComponent") do
			watchTycoon(v19)
		end

		p1.UECS.OnComponentCreated("TycoonComponent"):Connect(watchTycoon)
	end
}