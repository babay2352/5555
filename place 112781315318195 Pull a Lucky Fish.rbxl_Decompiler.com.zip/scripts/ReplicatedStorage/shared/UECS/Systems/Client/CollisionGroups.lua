-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local PhysicsService = game:GetService("PhysicsService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local t = {
	UECS = nil,
	Players = "player",
	Npcs = "npc"
}

local function applyToDescendants(p1, p2) --[[ applyToDescendants | Line: 32 ]]
	for v1, v2 in p1:GetDescendants() do
		if v2:IsA("BasePart") then
			v2.CollisionGroup = p2
		end
	end

	p1.DescendantAdded:Connect(function(p1) --[[ Line: 38 | Upvalues: p2 (copy) ]]
		if not p1:IsA("BasePart") then
			return
		end

		p1.CollisionGroup = p2
	end)
end

function t.Init(p1) --[[ Init | Line: 45 | Upvalues: PhysicsService (copy), t (copy), CollectionService (copy), applyToDescendants (copy), Players (copy) ]]
	warn("COLLISSIONS")
	pcall(function() --[[ Line: 47 | Upvalues: PhysicsService (ref), t (ref) ]]
		PhysicsService:RegisterCollisionGroup(t.Players)
	end)
	pcall(function() --[[ Line: 50 | Upvalues: PhysicsService (ref), t (ref) ]]
		PhysicsService:RegisterCollisionGroup(t.Npcs)
	end)

	for v1, v2 in { t.Players, t.Npcs } do
		for v3, v4 in CollectionService:GetTagged(v2) do
			applyToDescendants(v4, v2)
		end

		CollectionService:GetInstanceAddedSignal(v2):Connect(function(p1) --[[ Line: 58 | Upvalues: applyToDescendants (ref), v2 (copy) ]]
			applyToDescendants(p1, v2)
		end)
	end

	local function tagCharacter(p1) --[[ tagCharacter | Line: 63 | Upvalues: CollectionService (ref), t (ref) ]]
		CollectionService:AddTag(p1, t.Players)
	end

	for v5, v6 in Players:GetPlayers() do
		if v6.Character then
			CollectionService:AddTag(v6.Character, t.Players)
		end

		v6.CharacterAdded:Connect(tagCharacter)
	end

	Players.PlayerAdded:Connect(function(p1) --[[ Line: 72 | Upvalues: tagCharacter (copy) ]]
		p1.CharacterAdded:Connect(tagCharacter)
	end)
end

return t