-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local AnimationConfig = require(ReplicatedStorage.shared.config.AnimationConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local t = {
	UECS = nil
}

local function play(p1) --[[ play | Line: 11 | Upvalues: AnimationConfig (copy) ]]
	local v1 = p1:GetAttribute("AnimationKey")
	local Animation = Instance.new("Animation")

	Animation.AnimationId = AnimationConfig[v1]

	local Humanoid = p1:FindFirstChildOfClass("Humanoid")

	if not Humanoid then
		return
	end

	local v3 = (Humanoid:FindFirstChildOfClass("Animator") or Instance.new("Animator", Humanoid)):LoadAnimation(Animation)

	v3.Looped = true
	v3.Priority = Enum.AnimationPriority.Action

	for v4, v5 in p1:QueryDescendants("BasePart") do
		if v5 ~= p1.PrimaryPart then
			v5.Anchored = false
		end
	end

	v3:Play()
end

function t.Init(p1) --[[ Init | Line: 32 | Upvalues: CollectionService (copy), play (copy) ]]
	for v1, v2 in CollectionService:GetTagged("AnimatedNpc") do
		task.spawn(play, v2)
	end

	CollectionService:GetInstanceAddedSignal("AnimatedNpc"):Connect(function(p1) --[[ Line: 36 | Upvalues: play (ref) ]]
		task.spawn(play, p1)
	end)
end

return t