-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local MarketplaceService = game:GetService("MarketplaceService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local SoundService = game:GetService("SoundService")

game:GetService("TweenService")

local BeamTo = require(ReplicatedStorage.client.BeamTo)
local FloatCrateAnimation = require(ReplicatedStorage.shared.module.FloatCrateAnimation)
local FloatLootboxConfig = require(ReplicatedStorage.shared.config.FloatLootboxConfig)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local LocalPlayer = Players.LocalPlayer
local t = {}
local t2 = {}
local t3 = {}
local t4 = {}
local t5 = {}
local t6 = {}

local function resolveHost(p1, p2) --[[ resolveHost | Line: 59 | Upvalues: t6 (copy) ]]
	for v1, v2 in p1:GetDescendants() do
		if v2:IsA("BasePart") and v2:HasTag("FloatCratePrompt") then
			return v2
		end
	end

	if not t6[p2] then
		t6[p2] = true
		warn(("[FloatLootboxPlacer] template \"%*\" has no part tagged FloatCratePrompt \226\128\148 "):format(p2) .. "falling back to PrimaryPart. Tag the part the Open/Skip prompts should sit on.")
	end

	return p1.PrimaryPart or p1:FindFirstChildWhichIsA("BasePart")
end

local gui = ReplicatedStorage.shared.model:FindFirstChild("gui")

if not gui then
	local gui2 = Instance.new("Folder")

	gui2.Name = "gui"
	gui2.Parent = ReplicatedStorage.shared.model
	gui = gui2
end

local LootboxTimerBillboard = gui:FindFirstChild("LootboxTimerBillboard")
local v1

if LootboxTimerBillboard then
	v1 = LootboxTimerBillboard
else
	local LootboxTimerBillboard2 = Instance.new("BillboardGui")

	LootboxTimerBillboard2.Name = "LootboxTimerBillboard"
	LootboxTimerBillboard2.Size = UDim2.new(5, 0, 2, 0)
	LootboxTimerBillboard2.StudsOffset = Vector3.new(0, 7, 0)
	LootboxTimerBillboard2.AlwaysOnTop = true
	LootboxTimerBillboard2.Active = true

	local Frame = Instance.new("Frame")

	Frame.Name = "Frame"
	Frame.Size = UDim2.new(1, 0, 1, 0)
	Frame.BackgroundColor3 = Color3.fromRGB(15, 15, 25)
	Frame.BackgroundTransparency = 0.25
	Frame.BorderSizePixel = 0
	Frame.Parent = LootboxTimerBillboard2
	Instance.new("UICorner", Frame).CornerRadius = UDim.new(0.1, 0)

	local TimerLabel = Instance.new("TextLabel")

	TimerLabel.Name = "TimerLabel"
	TimerLabel.Size = UDim2.new(1, 0, 0.6, 0)
	TimerLabel.BackgroundTransparency = 1
	TimerLabel.Text = "5:00"
	TimerLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
	TimerLabel.TextScaled = true
	TimerLabel.Font = Enum.Font.GothamBold
	TimerLabel.Parent = Frame

	local SkipButton = Instance.new("TextButton")

	SkipButton.Name = "SkipButton"
	SkipButton.Size = UDim2.new(0.6, 0, 0.35, 0)
	SkipButton.Position = UDim2.new(0.2, 0, 0.62, 0)
	SkipButton.BackgroundColor3 = Color3.fromRGB(0, 170, 0)
	SkipButton.Text = "\226\143\169 Skip (R$)"
	SkipButton.TextColor3 = Color3.fromRGB(255, 255, 255)
	SkipButton.TextScaled = true
	SkipButton.Font = Enum.Font.GothamBold
	SkipButton.Parent = Frame
	Instance.new("UICorner", SkipButton).CornerRadius = UDim.new(0.2, 0)
	LootboxTimerBillboard2.Parent = gui
	warn("[FloatLootboxPlacer] Created LootboxTimerBillboard template \226\128\148 copy it to shared.gui")
	v1 = LootboxTimerBillboard2
end

local function createPlacedBillboard(p1, p2) --[[ createPlacedBillboard | Line: 137 | Upvalues: t2 (copy), v1 (ref), LocalPlayer (copy) ]]
	if not t2[p2] then
		local v12 = v1:Clone()

		v12.Name = "LootboxTimer_" .. p2
		v12.Adornee = p1
		v12.Parent = LocalPlayer:WaitForChild("PlayerGui")
		t2[p2] = v12
	end
end

local function createPlacedPrompt(p1, p2, p3) --[[ createPlacedPrompt | Line: 153 | Upvalues: t3 (copy), FloatLootboxConfig (copy), LocalPlayer (copy), Remotes (copy) ]]
	if t3[p2] then
		return
	end

	local v1 = FloatLootboxConfig.Lootboxes[p3]
	local FloatCrateOpenPrompt = Instance.new("ProximityPrompt")

	FloatCrateOpenPrompt.Name = "FloatCrateOpenPrompt"
	FloatCrateOpenPrompt.Style = Enum.ProximityPromptStyle.Custom
	FloatCrateOpenPrompt.ObjectText = v1 and v1.DisplayName or "Float Crate"
	FloatCrateOpenPrompt.ActionText = "Open"
	FloatCrateOpenPrompt.HoldDuration = 0.5
	FloatCrateOpenPrompt.MaxActivationDistance = 10
	FloatCrateOpenPrompt.RequiresLineOfSight = false
	FloatCrateOpenPrompt.Enabled = false
	FloatCrateOpenPrompt.Parent = p1
	FloatCrateOpenPrompt.Triggered:Connect(function(p1) --[[ Line: 174 | Upvalues: LocalPlayer (ref), Remotes (ref), p2 (copy) ]]
		if p1 == LocalPlayer then
			Remotes.OpenFloatLootbox:Fire(p2)
		end
	end)
	t3[p2] = FloatCrateOpenPrompt
end

local t7 = {}

local function getSkipPriceText(p1) --[[ getSkipPriceText | Line: 188 | Upvalues: t7 (copy), MarketplaceService (copy) ]]
	if t7[p1] then
		return t7[p1]
	end

	local ok, result = pcall(function() --[[ Line: 192 | Upvalues: MarketplaceService (ref), p1 (copy) ]]
		return MarketplaceService:GetProductInfo(p1, Enum.InfoType.Product)
	end)

	if ok and (result and result.PriceInRobux) then
		local v1 = ("Skip %* \238\128\130"):format(result.PriceInRobux)

		t7[p1] = v1

		return v1
	end

	t7[p1] = "Skip \238\128\130"

	return "Skip \238\128\130"
end

local function createSkipPrompt(p1, p2, p3) --[[ createSkipPrompt | Line: 204 | Upvalues: t4 (copy), FloatLootboxConfig (copy), t7 (copy), MarketplaceService (copy), LocalPlayer (copy), Remotes (copy) ]]
	if t4[p2] then
		return
	end

	local v1 = FloatLootboxConfig.Lootboxes[p3]
	local v2 = FloatLootboxConfig.Lootboxes[p3] and v1.SkipProductId or 0
	local FloatCrateSkipPrompt = Instance.new("ProximityPrompt")

	FloatCrateSkipPrompt.Name = "FloatCrateSkipPrompt"
	FloatCrateSkipPrompt.Style = Enum.ProximityPromptStyle.Custom
	FloatCrateSkipPrompt.ObjectText = v1 and v1.DisplayName or "Float Crate"
	FloatCrateSkipPrompt.ActionText = "Skip \238\128\130"
	FloatCrateSkipPrompt.HoldDuration = 0
	FloatCrateSkipPrompt.MaxActivationDistance = 10
	FloatCrateSkipPrompt.RequiresLineOfSight = false
	FloatCrateSkipPrompt.Enabled = true
	FloatCrateSkipPrompt.Parent = p1

	if v2 > 0 then
		task.spawn(function() --[[ Line: 225 | Upvalues: FloatCrateSkipPrompt (copy), v2 (copy), t7 (ref), MarketplaceService (ref) ]]
			local v22 = v2
			local v3

			if t7[v22] then
				v3 = t7[v22]
			else
				local ok, result = pcall(function() --[[ Line: 192 | Upvalues: MarketplaceService (ref), v22 (copy) ]]
					return MarketplaceService:GetProductInfo(v22, Enum.InfoType.Product)
				end)

				if ok and (result and result.PriceInRobux) then
					local v4 = ("Skip %* \238\128\130"):format(result.PriceInRobux)

					t7[v22] = v4
					v3 = v4
				else
					t7[v22] = "Skip \238\128\130"
					v3 = "Skip \238\128\130"
				end
			end

			FloatCrateSkipPrompt.ActionText = v3
		end)
	end

	FloatCrateSkipPrompt.Triggered:Connect(function(p1) --[[ Line: 230 | Upvalues: LocalPlayer (ref), p2 (copy), Remotes (ref) ]]
		if p1 == LocalPlayer then
			print((("[FloatLootboxPlacer] Skip prompt triggered for %*"):format(p2)))
			Remotes.SkipFloatLootboxTimer:Fire(p2)
		end
	end)
	t4[p2] = FloatCrateSkipPrompt
end

local function updatePlacedTimers() --[[ updatePlacedTimers | Line: 245 | Upvalues: t (ref), t2 (copy), t3 (copy), t4 (copy) ]]
	local v1 = workspace:GetServerTimeNow()

	for v2, v3 in t do
		local v4 = t2[v2]

		if v4 then
			local Frame = v4:FindFirstChild("Frame")

			if Frame then
				local TimerLabel = Frame:FindFirstChild("TimerLabel")
				local SkipButton = Frame:FindFirstChild("SkipButton")

				if TimerLabel then
					local v6 = v3.OpenTime - (v1 - v3.PlacedAt)

					if v6 <= 0 then
						TimerLabel.Text = "READY!"
						TimerLabel.TextColor3 = Color3.fromRGB(0, 255, 50)

						if Frame:FindFirstChild("ImageLabel") then
							Frame:FindFirstChild("ImageLabel").Visible = false
						end

						if SkipButton then
							SkipButton.Visible = false
						end

						local v7 = t3[v2]

						if v7 then
							v7.Enabled = true
						end

						local v8 = t4[v2]

						if v8 then
							v8.Enabled = false
						end

						continue
					end

					local v9 = math.floor(v6 / 3600)
					local v10 = math.floor(v6 % 3600 / 60)
					local v11 = v6 % 60

					if v9 > 0 then
						TimerLabel.Text = string.format("%d:%02d:%02d", v9, v10, v11)
					else
						TimerLabel.Text = string.format("%d:%02d", v10, v11)
					end

					TimerLabel.TextColor3 = Color3.fromRGB(255, 255, 255)

					if SkipButton then
						SkipButton.Visible = false
					end

					local v12 = t3[v2]

					if v12 then
						v12.Enabled = false
					end

					local v13 = t4[v2]

					if v13 then
						v13.Enabled = true
					end
				end
			end
		end
	end
end

local t8 = {}

local function teardownPlacement(p1) --[[ teardownPlacement | Line: 331 | Upvalues: t2 (copy), t3 (copy), t4 (copy), t8 (copy), t5 (copy) ]]
	local v1 = t2[p1]

	if v1 then
		v1:Destroy()
		t2[p1] = nil
	end

	local v2 = t3[p1]

	if v2 then
		v2:Destroy()
		t3[p1] = nil
	end

	local v3 = t4[p1]

	if v3 then
		v3:Destroy()
		t4[p1] = nil
	end

	t8[p1] = nil
	t5[p1] = nil
end

local function isPlacementStale(p1, p2) --[[ isPlacementStale | Line: 355 | Upvalues: t8 (copy), t5 (copy), t2 (copy) ]]
	local v1 = t8[p1]

	if not v1 then
		return false
	end

	if v1 ~= p2 or v1.Parent == nil then
		return true
	end

	local v2 = t5[p1]

	if v2 and (v2.Parent == nil or not v2:IsDescendantOf(v1)) then
		return true
	end

	local v3 = t2[p1]

	return v3 and (v3.Parent == nil or v3.Adornee == nil) and true or false
end

local function scanPlacedModels() --[[ scanPlacedModels | Line: 374 | Upvalues: t (ref), isPlacementStale (copy), t2 (copy), t3 (copy), t4 (copy), t8 (copy), t5 (copy), resolveHost (copy), v1 (ref), LocalPlayer (copy), createPlacedPrompt (copy), createSkipPrompt (copy) ]]
	for v12, v2 in t do
		local v3 = workspace:FindFirstChild("PlacedLootbox_" .. v12)

		if isPlacementStale(v12, v3) then
			local v4 = t2[v12]

			if v4 then
				v4:Destroy()
				t2[v12] = nil
			end

			local v5 = t3[v12]

			if v5 then
				v5:Destroy()
				t3[v12] = nil
			end

			local v6 = t4[v12]

			if v6 then
				v6:Destroy()
				t4[v12] = nil
			end

			t8[v12] = nil
			t5[v12] = nil
		end

		if v3 and not t8[v12] then
			local v7 = resolveHost(v3, v2.ConfigName)

			if v7 then
				if not t2[v12] then
					local v8 = v1:Clone()

					v8.Name = "LootboxTimer_" .. v12
					v8.Adornee = v7
					v8.Parent = LocalPlayer:WaitForChild("PlayerGui")
					t2[v12] = v8
				end

				createPlacedPrompt(v7, v12, v2.ConfigName)
				createSkipPrompt(v7, v12, v2.ConfigName)
				t8[v12] = v3
				t5[v12] = v7
			end
		end
	end

	for v9 in t8 do
		if not t[v9] then
			local v10 = t2[v9]

			if v10 then
				v10:Destroy()
				t2[v9] = nil
			end

			local v11 = t3[v9]

			if v11 then
				v11:Destroy()
				t3[v9] = nil
			end

			local v12 = t4[v9]

			if v12 then
				v12:Destroy()
				t4[v9] = nil
			end

			t8[v9] = nil
			t5[v9] = nil
		end
	end
end

return {
	Init = function(p1) --[[ Init | Line: 414 | Upvalues: FloatCrateAnimation (copy), Remotes (copy), t (ref), scanPlacedModels (copy), RunService (copy), updatePlacedTimers (copy), CollectionService (copy), LocalPlayer (copy), BeamTo (copy), ReplicatedStorage (copy), SoundService (copy), Players (copy) ]]
		FloatCrateAnimation.watchPlacedCrates()
		FloatCrateAnimation.watchCrateTools()
		Remotes.ReplicatePlacedLootboxes:On(function(p1) --[[ Line: 423 | Upvalues: t (ref), scanPlacedModels (ref) ]]
			if type(p1) ~= "table" then
				return
			end

			local count = 0

			for v1 in p1 do
				count = count + 1
			end

			print((("[FloatLootboxPlacer] Received ReplicatePlacedLootboxes: %* entries"):format(count)))
			t = p1
			task.delay(0.5, function() --[[ Line: 434 | Upvalues: scanPlacedModels (ref) ]]
				scanPlacedModels()
			end)
		end)
		RunService.Heartbeat:Connect(function() --[[ Line: 440 | Upvalues: updatePlacedTimers (ref) ]]
			debug.profilebegin("UECS/FloatLootboxPlacer.PlacedTimers")
			updatePlacedTimers()
			debug.profileend()
		end)

		local function onTaggedChanged(p1) --[[ onTaggedChanged | Line: 455 | Upvalues: scanPlacedModels (ref) ]]
			if not p1:IsDescendantOf(workspace) then
				return
			end

			scanPlacedModels()
		end

		CollectionService:GetInstanceAddedSignal("FloatCratePrompt"):Connect(onTaggedChanged)
		CollectionService:GetInstanceRemovedSignal("FloatCratePrompt"):Connect(function() --[[ Line: 461 | Upvalues: scanPlacedModels (ref) ]]
			scanPlacedModels()
		end)
		task.spawn(function() --[[ Line: 470 | Upvalues: scanPlacedModels (ref) ]]
			while true do
				task.wait(2)
				scanPlacedModels()
			end
		end)
		print("[FloatLootboxPlacer] Requesting placed lootbox data from server")
		Remotes.RequestPlacedLootboxes:Fire()

		local UECS = p1.UECS

		local function findPlayerTycoon() --[[ findPlayerTycoon | Line: 484 | Upvalues: UECS (copy), LocalPlayer (ref) ]]
			for k, v in pairs(UECS:GetComponents("TycoonComponent")) do
				if v.Owner:Get() == LocalPlayer and (v.Entity and v.Entity:IsA("Model")) then
					return v.Entity
				end
			end

			return nil
		end

		local function isInsideOwnBase() --[[ isInsideOwnBase | Line: 493 | Upvalues: LocalPlayer (ref), findPlayerTycoon (copy) ]]
			local Character = LocalPlayer.Character

			if not Character then
				return false
			end

			local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")

			if not HumanoidRootPart then
				return false
			end

			local v1 = findPlayerTycoon()

			if not v1 then
				return false
			end

			local v2, v3 = v1:GetBoundingBox()
			local v4 = v2:PointToObjectSpace(HumanoidRootPart.Position)
			local v5 = v3 * 0.5

			return if math.abs(v4.X) <= v5.X then if math.abs(v4.Z) <= v5.Z and v4.Y >= -v5.Y - 5 then v4.Y <= v5.Y + 20 else false else false
		end

		local function showBaseBeam() --[[ showBaseBeam | Line: 517 | Upvalues: findPlayerTycoon (copy), BeamTo (ref) ]]
			local v1 = findPlayerTycoon()

			if not v1 then
				return
			end

			local v2 = v1.PrimaryPart or v1:FindFirstChildWhichIsA("BasePart")

			if v2 then
				BeamTo(v2)
				task.delay(2, function() --[[ Line: 532 | Upvalues: BeamTo (ref) ]]
					BeamTo(nil)
				end)
			end
		end

		local t2 = {}

		local function hookToolActivation(p1) --[[ hookToolActivation | Line: 540 | Upvalues: t2 (copy), LocalPlayer (ref), isInsideOwnBase (copy), ReplicatedStorage (ref), showBaseBeam (copy), Remotes (ref), SoundService (ref), Players (ref) ]]
			if p1.Name ~= "FloatLootbox" and not p1:GetAttribute("IsFloatLootbox") then
				return
			end

			if not t2[p1] then
				t2[p1] = true
				p1.Activated:Connect(function() --[[ Line: 551 | Upvalues: LocalPlayer (ref), isInsideOwnBase (ref), ReplicatedStorage (ref), showBaseBeam (ref), Remotes (ref), SoundService (ref) ]]
					local Character = LocalPlayer.Character

					if not Character then
						return
					end

					local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")

					if not HumanoidRootPart then
						return
					end

					if not isInsideOwnBase() then
						require(ReplicatedStorage.client.SignalBag).Notification:Fire("Place this lootbox on your base!")
						showBaseBeam()

						return
					end

					local v1 = RaycastParams.new()

					v1.FilterType = Enum.RaycastFilterType.Exclude
					v1.FilterDescendantsInstances = { Character }

					local v2 = workspace:Raycast(HumanoidRootPart.Position, Vector3.new(0, -20, 0), v1)

					Remotes.PlaceFloatLootbox:Fire((CFrame.new(HumanoidRootPart.Position.X, if v2 then v2.Position.Y else HumanoidRootPart.Position.Y - 3, HumanoidRootPart.Position.Z)))

					local SFX = SoundService:FindFirstChild("SFX")
					local v5 = if SFX then SFX:FindFirstChild("Placement") else SFX

					if not (v5 and v5:IsA("Sound")) then
						return
					end

					local v6 = v5:Clone()

					v6.PlayOnRemove = true
					v6.Parent = SoundService
					v6:Destroy()
				end)
				p1.Destroying:Connect(function() --[[ Line: 598 | Upvalues: t2 (ref), p1 (copy) ]]
					t2[p1] = nil
				end)

				local t = {}
				local t3 = {}

				local function clearGiftPrompts() --[[ clearGiftPrompts | Line: 606 | Upvalues: t3 (copy), t (copy) ]]
					for v1, v2 in t3 do
						v2:Disconnect()
					end

					table.clear(t3)

					for v3, v4 in t do
						v4:Destroy()
						t[v3] = nil
					end
				end

				local function createGiftPromptFor(p1) --[[ createGiftPromptFor | Line: 617 | Upvalues: LocalPlayer (ref), t (copy), Remotes (ref) ]]
					if p1 == LocalPlayer or t[p1] then
						return
					end

					local Character = p1.Character

					if not Character then
						return
					end

					local v1 = Character:FindFirstChild("HumanoidRootPart") or Character.PrimaryPart

					if v1 then
						local GiftLootboxPrompt = Instance.new("ProximityPrompt")

						GiftLootboxPrompt.Name = "GiftLootboxPrompt"
						GiftLootboxPrompt.Style = Enum.ProximityPromptStyle.Custom
						GiftLootboxPrompt.ActionText = "Gift"
						GiftLootboxPrompt.ObjectText = p1.DisplayName
						GiftLootboxPrompt.HoldDuration = 0.2
						GiftLootboxPrompt.RequiresLineOfSight = false
						GiftLootboxPrompt.MaxActivationDistance = 12
						GiftLootboxPrompt.Parent = v1
						GiftLootboxPrompt.Triggered:Connect(function() --[[ Line: 638 | Upvalues: Remotes (ref), p1 (copy) ]]
							Remotes.RequestGiftLootbox:Fire(p1)
						end)
						t[p1] = GiftLootboxPrompt
					end
				end

				local function watchRespawns(p1) --[[ watchRespawns | Line: 644 | Upvalues: t3 (copy), t (copy), createGiftPromptFor (copy) ]]
					local function f2(p13) --[[ Line: 647 | Upvalues: t (ref), p1 (copy), createGiftPromptFor (ref) ]]
						t[p1] = nil
						task.spawn(function() --[[ Line: 649 | Upvalues: p13 (copy), createGiftPromptFor (ref), p1 (ref) ]]
							p13:WaitForChild("HumanoidRootPart", 10)
							createGiftPromptFor(p1)
						end)
					end

					table.insert(t3, p1.CharacterAdded:Connect(f2))
				end

				local function startGifting() --[[ startGifting | Line: 657 | Upvalues: Players (ref), createGiftPromptFor (copy), t3 (copy), t (copy) ]]
					for v1, v2 in Players:GetPlayers() do
						createGiftPromptFor(v2)

						local function f4(p13) --[[ Line: 647 | Upvalues: t (ref), v2 (copy), createGiftPromptFor (ref) ]]
							t[v2] = nil
							task.spawn(function() --[[ Line: 649 | Upvalues: p13 (copy), createGiftPromptFor (ref), v2 (ref) ]]
								p13:WaitForChild("HumanoidRootPart", 10)
								createGiftPromptFor(p1)
							end)
						end

						table.insert(t3, v2.CharacterAdded:Connect(f4))
					end

					local v5 = t3

					local function f6(p1) --[[ Line: 664 | Upvalues: createGiftPromptFor (ref), t3 (ref), t (ref) ]]
						createGiftPromptFor(p1)

						local function f2(p13) --[[ Line: 647 | Upvalues: t (ref), p1 (copy), createGiftPromptFor (ref) ]]
							t[p1] = nil
							task.spawn(function() --[[ Line: 649 | Upvalues: p13 (copy), createGiftPromptFor (ref), p1 (ref) ]]
								p13:WaitForChild("HumanoidRootPart", 10)
								createGiftPromptFor(p1)
							end)
						end

						table.insert(t3, p1.CharacterAdded:Connect(f2))
					end

					table.insert(v5, Players.PlayerAdded:Connect(f6))

					local v7 = t3

					local function f8(p1) --[[ Line: 671 | Upvalues: t (ref) ]]
						local v1 = t[p1]

						if not v1 then
							return
						end

						v1:Destroy()
						t[p1] = nil
					end

					table.insert(v7, Players.PlayerRemoving:Connect(f8))
				end

				p1.Equipped:Connect(function() --[[ Line: 681 | Upvalues: startGifting (copy) ]]
					startGifting()
				end)
				p1.Unequipped:Connect(clearGiftPrompts)
				p1.Destroying:Connect(clearGiftPrompts)
			end
		end

		local function scanAndHook(p1) --[[ scanAndHook | Line: 689 | Upvalues: hookToolActivation (copy) ]]
			for v1, v2 in p1:GetChildren() do
				if v2:IsA("Tool") then
					hookToolActivation(v2)
				end
			end

			p1.ChildAdded:Connect(function(p1) --[[ Line: 695 | Upvalues: hookToolActivation (ref) ]]
				if not p1:IsA("Tool") then
					return
				end

				hookToolActivation(p1)
			end)
		end

		local Character = LocalPlayer.Character

		if Character then
			scanAndHook(Character)
		end

		LocalPlayer.CharacterAdded:Connect(function(p1) --[[ Line: 707 | Upvalues: scanAndHook (copy) ]]
			scanAndHook(p1)
		end)

		local Backpack = LocalPlayer:WaitForChild("Backpack", 10)

		if not Backpack then
			return
		end

		scanAndHook(Backpack)
	end
}