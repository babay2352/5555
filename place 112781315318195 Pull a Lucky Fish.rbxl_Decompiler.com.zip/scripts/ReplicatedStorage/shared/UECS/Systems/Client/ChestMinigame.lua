-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ContentProvider = game:GetService("ContentProvider")
local ContextActionService = game:GetService("ContextActionService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local SoundService = game:GetService("SoundService")
local UserInputService = game:GetService("UserInputService")
local ChestMinigame = require(ReplicatedStorage.shared.UECS.Components.ChestMinigame)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Remotes = require(ReplicatedStorage.shared.Remotes)
local SignalBag = require(ReplicatedStorage.client.SignalBag)
local bindToButtonPress = require(ReplicatedStorage.shared.util.bindToButtonPress)
local t = {
	UECS = nil
}
local t2 = {
	MinigamesEnabled = true,
	PromptTag = "OpenChest",
	PromptActionText = "Open",
	PromptObjectText = "Chest",
	PromptHoldDuration = 0.3,
	PromptDistance = 10,
	Sounds = {
		Success = "SuccessSfx",
		Fail = "Error",
		Click = "Keyboard Click",
		Unlock = "Poppy Playtime keypad unlock"
	},
	SkillCheck = {
		MinZoneGap = 60,
		FlashTime = 0.25,
		Stages = {
			{
				zone = "GoodZoneEasy",
				sweep = 170,
				speed = 150
			},
			{
				zone = "GoodZoneMedium",
				sweep = 115,
				speed = 210
			},
			{
				zone = "GoodZoneHard",
				sweep = 90,
				speed = 270
			}
		},
		SuccessColor = Color3.fromRGB(120, 255, 120),
		FailColor = Color3.fromRGB(255, 80, 80)
	},
	SimonSays = {
		Rounds = 3,
		StartLength = 3,
		ShowTime = 0.4,
		GapTime = 0.15,
		RoundPause = 0.8,
		ButtonColor = Color3.fromRGB(55, 60, 80),
		LitColor = Color3.fromRGB(255, 220, 90),
		WrongColor = Color3.fromRGB(255, 70, 70),
		DiodeOffColor = Color3.fromRGB(45, 45, 55),
		DiodeOnColor = Color3.fromRGB(90, 255, 100)
	}
}
local v1 = setmetatable({}, {
	__mode = "k"
})
local v2 = nil

local function getControls() --[[ getControls | Line: 108 | Upvalues: v2 (ref), Players (copy) ]]
	if v2 then
		return v2
	end

	local PlayerScripts = Players.LocalPlayer:FindFirstChild("PlayerScripts")
	local v1 = PlayerScripts and PlayerScripts:FindFirstChild("PlayerModule")

	if not (v1 and v1:IsA("ModuleScript")) then
		return nil
	end

	local ok, result = pcall(function() --[[ Line: 117 | Upvalues: v1 (copy) ]]
		return require(v1):GetControls()
	end)

	if ok then
		v2 = result

		return result
	end

	warn("[ChestMinigame] PlayerModule controls failed:", result)

	return nil
end

local function setControlsEnabled(p1) --[[ setControlsEnabled | Line: 128 | Upvalues: getControls (copy) ]]
	local v1 = getControls()

	if not v1 then
		return
	end

	if p1 then
		v1:Enable()
	else
		v1:Disable()
	end
end

local function playUISound(p1) --[[ playUISound | Line: 142 | Upvalues: ReplicatedStorage (copy), SoundService (copy) ]]
	local SFX = ReplicatedStorage.shared.model:FindFirstChild("SFX")
	local v1 = if SFX then SFX:FindFirstChild(p1) else SFX

	if v1 and v1:IsA("Sound") then
		local v2 = v1:Clone()

		v2.PlayOnRemove = true
		v2.Parent = SoundService
		v2:Destroy()
	else
		warn((("[ChestMinigame] SFX \"%*\" not found in ReplicatedStorage.shared.model.SFX"):format(p1)))
	end
end

function t.Init(p1) --[[ Init | Line: 155 | Upvalues: Players (copy), ChestMinigame (copy), ContentProvider (copy), getControls (copy), bindToButtonPress (copy), ContextActionService (copy), CollectionService (copy), Remotes (copy), SignalBag (copy), t2 (copy), playUISound (copy), RunService (copy), UserInputService (copy), v1 (copy) ]]
	local OpenChestMinigame = Players.LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("MainUI"):WaitForChild("OpenChestMinigame")

	OpenChestMinigame.Visible = false

	local SkillCheck = OpenChestMinigame:WaitForChild("SkillCheck")
	local SimonSays = OpenChestMinigame:WaitForChild("SimonSays")

	SkillCheck.Visible = false
	SimonSays.Visible = false

	local v12 = ChestMinigame.Add(OpenChestMinigame)

	task.spawn(function() --[[ Line: 171 | Upvalues: SkillCheck (copy), ContentProvider (ref) ]]
		local t = {}

		for v1, v2 in SkillCheck:GetDescendants() do
			if (v2:IsA("ImageLabel") or v2:IsA("ImageButton")) and v2.Image ~= "" then
				table.insert(t, v2)
			end
		end

		if not (#t > 0) then
			return
		end

		pcall(function() --[[ Line: 179 | Upvalues: ContentProvider (ref), t (copy) ]]
			ContentProvider:PreloadAsync(t)
		end)
	end)

	local v2 = nil
	local v3 = nil

	local function stopActive() --[[ stopActive | Line: 192 | Upvalues: v2 (ref), SkillCheck (copy), SimonSays (copy) ]]
		if not v2 then
			SkillCheck.Visible = false
			SimonSays.Visible = false

			return
		end

		local v1 = v2

		v2 = nil
		v1()
		SkillCheck.Visible = false
		SimonSays.Visible = false
	end

	local function close() --[[ close | Line: 202 | Upvalues: p1 (copy), v12 (copy) ]]
		local v1 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

		if v1.OpenedUIComponent:Get() ~= v12 then
			return
		end

		v1.OpenedUIComponent:Set(nil)
	end

	v12.Visible.OnChange:Connect(function(p1, p2) --[[ Line: 212 | Upvalues: OpenChestMinigame (copy), getControls (ref), bindToButtonPress (ref), close (copy), ContextActionService (ref), v2 (ref), SkillCheck (copy), SimonSays (copy), v3 (ref) ]]
		OpenChestMinigame.Visible = p1

		if p1 == p2 then
			return
		end

		if p1 then
			local v1 = getControls()

			if v1 then
				v1:Disable()
			end

			bindToButtonPress("ChestMinigameClose", Enum.KeyCode.ButtonB, close)
		else
			ContextActionService:UnbindAction("ChestMinigameClose")

			local v22 = getControls()

			if v22 then
				v22:Enable()
			end

			if v2 then
				local v32 = v2

				v2 = nil
				v32()
			end

			SkillCheck.Visible = false
			SimonSays.Visible = false
			v3 = nil
		end
	end)

	for v4, v5 in { SkillCheck, SimonSays } do
		local CloseButton = v5:WaitForChild("CloseButton")

		CollectionService:AddTag(CloseButton, "VFX_ClickBounce")
		CollectionService:AddTag(CloseButton, "VFX_UIClickButton")
		CloseButton.Activated:Connect(close)
	end

	local function complete(p12) --[[ complete | Line: 237 | Upvalues: Remotes (ref), SignalBag (ref), p1 (copy), v12 (copy) ]]
		Remotes.ChestMinigameCompleted:Fire({
			minigame = p12
		})
		SignalBag.ChestClaimed:Fire()

		local v1 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

		if v1.OpenedUIComponent:Get() ~= v12 then
			return
		end

		v1.OpenedUIComponent:Set(nil)
	end

	local function startSkillCheck() --[[ startSkillCheck | Line: 248 | Upvalues: t2 (ref), SkillCheck (copy), playUISound (ref), Remotes (ref), SignalBag (ref), p1 (copy), v12 (copy), RunService (ref), UserInputService (ref) ]]
		local SkillCheck2 = t2.SkillCheck
		local Needle = SkillCheck:WaitForChild("Needle")
		local t = {}

		for v1, v2 in SkillCheck2.Stages do
			t[v1] = SkillCheck:WaitForChild(v2.zone)
		end

		local v3 = 1
		local v4 = 1
		local v5 = 0
		local v6 = 0
		local v7 = 0
		local v8 = false

		local function insideZone() --[[ insideZone | Line: 269 | Upvalues: v5 (ref), v6 (ref), SkillCheck2 (copy), v3 (ref) ]]
			return math.abs((v5 - v6 + 180) % 360 - 180) <= SkillCheck2.Stages[v3].sweep / 2
		end

		local function showStage() --[[ showStage | Line: 275 | Upvalues: t (copy), v3 (ref) ]]
			for v1, v2 in t do
				v2.Visible = v1 == v3
			end
		end

		local function flash(p1) --[[ flash | Line: 282 | Upvalues: v7 (ref), Needle (copy), SkillCheck2 (copy) ]]
			v7 = v7 + 1

			local v1 = v7

			Needle.ImageColor3 = p1
			task.delay(SkillCheck2.FlashTime, function() --[[ Line: 286 | Upvalues: v7 (ref), v1 (copy), Needle (ref) ]]
				if v7 ~= v1 then
					return
				end

				Needle.ImageColor3 = Color3.new(255/255, 255/255, 255/255)
			end)
		end

		local function rollZone() --[[ rollZone | Line: 294 | Upvalues: SkillCheck2 (copy), v3 (ref), v5 (ref), v4 (ref), v6 (ref), t (copy) ]]
			local sweep = SkillCheck2.Stages[v3].sweep

			v6 = ((v5 + v4 * math.random(SkillCheck2.MinZoneGap, (math.max(360 - sweep - SkillCheck2.MinZoneGap, SkillCheck2.MinZoneGap + 1)))) % 360 + v4 * sweep / 2) % 360
			t[v3].Rotation = v6
		end

		local function fail() --[[ fail | Line: 303 | Upvalues: playUISound (ref), t2 (ref), SkillCheck2 (copy), v7 (ref), Needle (copy), v3 (ref), t (copy), v5 (ref), v4 (ref), v6 (ref) ]]
			playUISound(t2.Sounds.Fail)
			v7 = v7 + 1

			local v1 = v7

			Needle.ImageColor3 = SkillCheck2.FailColor
			task.delay(SkillCheck2.FlashTime, function() --[[ Line: 286 | Upvalues: v7 (ref), v1 (copy), Needle (ref) ]]
				if v7 ~= v1 then
					return
				end

				Needle.ImageColor3 = Color3.new(255/255, 255/255, 255/255)
			end)
			v3 = math.max(1, v3 - 1)

			for v32, v42 in t do
				v42.Visible = v32 == v3
			end

			local sweep = SkillCheck2.Stages[v3].sweep

			v6 = ((v5 + v4 * math.random(SkillCheck2.MinZoneGap, (math.max(360 - sweep - SkillCheck2.MinZoneGap, SkillCheck2.MinZoneGap + 1)))) % 360 + v4 * sweep / 2) % 360
			t[v3].Rotation = v6
		end

		local function succeed() --[[ succeed | Line: 311 | Upvalues: playUISound (ref), t2 (ref), SkillCheck2 (copy), v7 (ref), Needle (copy), v3 (ref), v8 (ref), Remotes (ref), SignalBag (ref), p1 (ref), v12 (ref), v4 (ref), t (copy), v5 (ref), v6 (ref) ]]
			playUISound(t2.Sounds.Success)
			v7 = v7 + 1

			local v1 = v7

			Needle.ImageColor3 = SkillCheck2.SuccessColor
			task.delay(SkillCheck2.FlashTime, function() --[[ Line: 286 | Upvalues: v7 (ref), v1 (copy), Needle (ref) ]]
				if v7 ~= v1 then
					return
				end

				Needle.ImageColor3 = Color3.new(255/255, 255/255, 255/255)
			end)
			v3 = v3 + 1

			if v3 > #SkillCheck2.Stages then
				v8 = true
				Remotes.ChestMinigameCompleted:Fire({
					minigame = "SkillCheck"
				})
				SignalBag.ChestClaimed:Fire()

				local v2 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

				if v2.OpenedUIComponent:Get() ~= v12 then
					return
				end

				v2.OpenedUIComponent:Set(nil)
			else
				v4 = -v4

				for v32, v42 in t do
					v42.Visible = v32 == v3
				end

				local sweep = SkillCheck2.Stages[v3].sweep

				v6 = ((v5 + v4 * math.random(SkillCheck2.MinZoneGap, (math.max(360 - sweep - SkillCheck2.MinZoneGap, SkillCheck2.MinZoneGap + 1)))) % 360 + v4 * sweep / 2) % 360
				t[v3].Rotation = v6
			end
		end

		Needle.ImageColor3 = Color3.new(255/255, 255/255, 255/255)

		for v9, v10 in t do
			v10.Visible = v9 == v3
		end

		local sweep = SkillCheck2.Stages[v3].sweep

		v6 = ((v5 + v4 * math.random(SkillCheck2.MinZoneGap, (math.max(360 - sweep - SkillCheck2.MinZoneGap, SkillCheck2.MinZoneGap + 1)))) % 360 + v4 * sweep / 2) % 360
		t[v3].Rotation = v6
		SkillCheck.Visible = true

		local v15 = RunService.RenderStepped:Connect(function(p1) --[[ Line: 332 | Upvalues: v8 (ref), v5 (ref), v4 (ref), SkillCheck2 (copy), v3 (ref), Needle (copy) ]]
			if not v8 then
				v5 = (v5 + v4 * SkillCheck2.Stages[v3].speed * p1) % 360
				Needle.Rotation = v5
			end
		end)
		local t3 = {
			[Enum.KeyCode.Space] = true,
			[Enum.KeyCode.ButtonA] = true
		}
		local v16 = UserInputService.InputBegan:Connect(function(p12, p2) --[[ Line: 342 | Upvalues: v8 (ref), t3 (copy), v5 (ref), v6 (ref), SkillCheck2 (copy), v3 (ref), playUISound (ref), t2 (ref), v7 (ref), Needle (copy), Remotes (ref), SignalBag (ref), p1 (ref), v12 (ref), v4 (ref), t (copy) ]]
			if v8 or p2 then
				return
			end

			if not (t3[p12.KeyCode] or (if p12.UserInputType == Enum.UserInputType.MouseButton1 then true else p12.UserInputType == Enum.UserInputType.Touch)) then
				return
			end

			v7 = v7 + 1

			if math.abs((v5 - v6 + 180) % 360 - 180) <= SkillCheck2.Stages[v3].sweep / 2 then
				playUISound(t2.Sounds.Success)

				local v42 = v7

				Needle.ImageColor3 = SkillCheck2.SuccessColor
				task.delay(SkillCheck2.FlashTime, function() --[[ Line: 286 | Upvalues: v7 (ref), v42 (copy), Needle (ref) ]]
					if v7 ~= v42 then
						return
					end

					Needle.ImageColor3 = Color3.new(255/255, 255/255, 255/255)
				end)
				v3 = v3 + 1

				if v3 > #SkillCheck2.Stages then
					v8 = true
					Remotes.ChestMinigameCompleted:Fire({
						minigame = "SkillCheck"
					})
					SignalBag.ChestClaimed:Fire()

					local v52 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

					if v52.OpenedUIComponent:Get() == v12 then
						v52.OpenedUIComponent:Set(nil)
					end
				else
					v4 = -v4

					for v62, v72 in t do
						v72.Visible = v62 == v3
					end

					local sweep = SkillCheck2.Stages[v3].sweep

					v6 = ((v5 + v4 * math.random(SkillCheck2.MinZoneGap, (math.max(360 - sweep - SkillCheck2.MinZoneGap, SkillCheck2.MinZoneGap + 1)))) % 360 + v4 * sweep / 2) % 360
					t[v3].Rotation = v6
				end
			else
				playUISound(t2.Sounds.Fail)

				local v122 = v7

				Needle.ImageColor3 = SkillCheck2.FailColor
				task.delay(SkillCheck2.FlashTime, function() --[[ Line: 286 | Upvalues: v7 (ref), v122 (copy), Needle (ref) ]]
					if v7 ~= v122 then
						return
					end

					Needle.ImageColor3 = Color3.new(255/255, 255/255, 255/255)
				end)
				v3 = math.max(1, v3 - 1)

				for v14, v15 in t do
					v15.Visible = v14 == v3
				end

				local sweep = SkillCheck2.Stages[v3].sweep

				v6 = ((v5 + v4 * math.random(SkillCheck2.MinZoneGap, (math.max(360 - sweep - SkillCheck2.MinZoneGap, SkillCheck2.MinZoneGap + 1)))) % 360 + v4 * sweep / 2) % 360
				t[v3].Rotation = v6
			end
		end)

		return function() --[[ Line: 359 | Upvalues: v15 (copy), v16 (copy), v7 (ref), Needle (copy) ]]
			v15:Disconnect()
			v16:Disconnect()
			v7 = v7 + 1
			Needle.ImageColor3 = Color3.new(255/255, 255/255, 255/255)
		end
	end

	local function startSimon() --[[ startSimon | Line: 370 | Upvalues: t2 (ref), SimonSays (copy), playUISound (ref), Remotes (ref), SignalBag (ref), p1 (copy), v12 (copy) ]]
		local SimonSays2 = t2.SimonSays
		local Board = SimonSays:WaitForChild("Board")
		local Diodes = SimonSays:WaitForChild("Diodes")
		local t = {}

		for i = 1, 9 do
			t[i] = Board:WaitForChild("Button" .. i)
		end

		local t3 = {}

		for j = 1, SimonSays2.Rounds do
			t3[j] = Diodes:WaitForChild("Diode" .. j)
			t3[j].Visible = true
		end

		local count = SimonSays2.Rounds + 1

		while true do
			local v1 = Diodes:FindFirstChild("Diode" .. count)

			if not (v1 and v1:IsA("GuiObject")) then
				break
			end

			v1.Visible = false
			count = count + 1
		end

		local v2 = 0
		local t4 = {}
		local t5 = {}
		local v3 = 1
		local v4 = 1
		local v5 = false

		local function resetDiodes() --[[ resetDiodes | Line: 405 | Upvalues: t3 (copy), SimonSays2 (copy) ]]
			for v1, v2 in t3 do
				v2.BackgroundColor3 = SimonSays2.DiodeOffColor
			end
		end

		local function lightButton(p1, p2, p3, p4) --[[ lightButton | Line: 411 | Upvalues: t (copy), v2 (ref), SimonSays2 (copy) ]]
			t[p1].BackgroundColor3 = p2
			task.delay(p3, function() --[[ Line: 413 | Upvalues: v2 (ref), p4 (copy), t (ref), p1 (copy), SimonSays2 (ref) ]]
				if v2 ~= p4 then
					return
				end

				t[p1].BackgroundColor3 = SimonSays2.ButtonColor
			end)
		end

		local function extendSequence(p1) --[[ extendSequence | Line: 422 | Upvalues: t5 (copy) ]]
			for i = 1, p1 do
				local v1 = math.random(1, 9)

				if t5[#t5] == v1 then
					v1 = v1 % 9 + 1
				end

				table.insert(t5, v1)
			end
		end

		local function playRound() --[[ playRound | Line: 433 | Upvalues: v5 (ref), v4 (ref), v2 (ref), SimonSays2 (copy), t5 (copy), playUISound (ref), t2 (ref), t (copy) ]]
			v5 = false
			v4 = 1

			local v1 = v2

			task.spawn(function() --[[ Line: 437 | Upvalues: SimonSays2 (ref), v2 (ref), v1 (copy), t5 (ref), playUISound (ref), t2 (ref), t (ref), v5 (ref) ]]
				task.wait(SimonSays2.RoundPause)

				if v2 ~= v1 then
					return
				end

				for v12, v22 in t5 do
					playUISound(t2.Sounds.Click)

					local LitColor = SimonSays2.LitColor
					local ShowTime = SimonSays2.ShowTime
					local v32 = v1

					t[v22].BackgroundColor3 = LitColor
					task.delay(ShowTime, function() --[[ Line: 413 | Upvalues: v2 (ref), v32 (copy), t (ref), v22 (copy), SimonSays2 (ref) ]]
						if v2 ~= v32 then
							return
						end

						t[v22].BackgroundColor3 = SimonSays2.ButtonColor
					end)
					task.wait(SimonSays2.ShowTime + SimonSays2.GapTime)

					if v2 ~= v1 then
						return
					end
				end

				v5 = true
			end)
		end

		local function failGame() --[[ failGame | Line: 454 | Upvalues: playUISound (ref), t2 (ref), v5 (ref), v2 (ref), t (copy), SimonSays2 (copy), t3 (copy), v3 (ref), t5 (copy), extendSequence (copy), v4 (ref) ]]
			playUISound(t2.Sounds.Fail)
			v5 = false
			v2 = v2 + 1

			for v1, v22 in t do
				v22.BackgroundColor3 = SimonSays2.WrongColor
			end

			for v32, v42 in t3 do
				v42.BackgroundColor3 = SimonSays2.DiodeOffColor
			end

			v3 = 1
			table.clear(t5)
			extendSequence(SimonSays2.StartLength)

			local v52 = v2

			task.delay(SimonSays2.RoundPause, function() --[[ Line: 468 | Upvalues: v2 (ref), v52 (copy), t (ref), SimonSays2 (ref), v5 (ref), v4 (ref), t5 (ref), playUISound (ref), t2 (ref) ]]
				if v2 ~= v52 then
					return
				end

				for v1, v22 in t do
					v22.BackgroundColor3 = SimonSays2.ButtonColor
				end

				v5 = false
				v4 = 1

				local v3 = v2

				task.spawn(function() --[[ Line: 437 | Upvalues: SimonSays2 (ref), v2 (ref), v3 (copy), t5 (ref), playUISound (ref), t2 (ref), t (ref), v5 (ref) ]]
					task.wait(SimonSays2.RoundPause)

					if v2 ~= v3 then
						return
					end

					for v12, v22 in t5 do
						playUISound(t2.Sounds.Click)

						local LitColor = SimonSays2.LitColor
						local ShowTime = SimonSays2.ShowTime
						local v32 = v3

						t[v22].BackgroundColor3 = LitColor
						task.delay(ShowTime, function() --[[ Line: 413 | Upvalues: v2 (ref), v32 (copy), t (ref), v22 (copy), SimonSays2 (ref) ]]
							if v2 ~= v32 then
								return
							end

							t[v22].BackgroundColor3 = SimonSays2.ButtonColor
						end)
						task.wait(SimonSays2.ShowTime + SimonSays2.GapTime)

						if v2 ~= v3 then
							return
						end
					end

					v5 = true
				end)
			end)
		end

		local function onButton(p12) --[[ onButton | Line: 479 | Upvalues: v5 (ref), t5 (copy), v4 (ref), failGame (copy), playUISound (ref), t2 (ref), SimonSays2 (copy), v2 (ref), t (copy), t3 (copy), v3 (ref), Remotes (ref), SignalBag (ref), p1 (ref), v12 (ref) ]]
			if not v5 then
				return
			end

			if p12 ~= t5[v4] then
				failGame()

				return
			end

			playUISound(t2.Sounds.Click)

			local LitColor = SimonSays2.LitColor
			local v1 = SimonSays2.ShowTime * 0.5
			local v22 = v2

			t[p12].BackgroundColor3 = LitColor
			task.delay(v1, function() --[[ Line: 413 | Upvalues: v2 (ref), v22 (copy), t (ref), p12 (copy), SimonSays2 (ref) ]]
				if v2 ~= v22 then
					return
				end

				t[p12].BackgroundColor3 = SimonSays2.ButtonColor
			end)
			v4 = v4 + 1

			if v4 <= #t5 then
				return
			end

			v5 = false
			t3[v3].BackgroundColor3 = SimonSays2.DiodeOnColor

			if v3 >= SimonSays2.Rounds then
				playUISound(t2.Sounds.Unlock)
				Remotes.ChestMinigameCompleted:Fire({
					minigame = "SimonSays"
				})
				SignalBag.ChestClaimed:Fire()

				local v32 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

				if v32.OpenedUIComponent:Get() ~= v12 then
					return
				end

				v32.OpenedUIComponent:Set(nil)
			else
				playUISound(t2.Sounds.Success)
				v3 = v3 + 1

				local v42 = math.random(1, 9)

				if t5[#t5] == v42 then
					v42 = v42 % 9 + 1
				end

				local v52 = t5

				table.insert(v52, v42)
				v5 = false
				v4 = 1

				local v6 = v2

				task.spawn(function() --[[ Line: 437 | Upvalues: SimonSays2 (ref), v2 (ref), v6 (copy), t5 (ref), playUISound (ref), t2 (ref), t (ref), v5 (ref) ]]
					task.wait(SimonSays2.RoundPause)

					if v2 ~= v6 then
						return
					end

					for v12, v22 in t5 do
						playUISound(t2.Sounds.Click)

						local LitColor = SimonSays2.LitColor
						local ShowTime = SimonSays2.ShowTime
						local v32 = v6

						t[v22].BackgroundColor3 = LitColor
						task.delay(ShowTime, function() --[[ Line: 413 | Upvalues: v2 (ref), v32 (copy), t (ref), v22 (copy), SimonSays2 (ref) ]]
							if v2 ~= v32 then
								return
							end

							t[v22].BackgroundColor3 = SimonSays2.ButtonColor
						end)
						task.wait(SimonSays2.ShowTime + SimonSays2.GapTime)

						if v2 ~= v6 then
							return
						end
					end

					v5 = true
				end)
			end
		end

		for v6, v7 in t do
			v7.BackgroundColor3 = SimonSays2.ButtonColor
			table.insert(t4, v7.Activated:Connect(function() --[[ Line: 512 | Upvalues: onButton (copy), v6 (copy) ]]
				onButton(v6)
			end))
		end

		for v8, v9 in t3 do
			v9.BackgroundColor3 = SimonSays2.DiodeOffColor
		end

		extendSequence(SimonSays2.StartLength)
		SimonSays.Visible = true
		v5 = false
		v4 = 1

		local v10 = v2

		task.spawn(function() --[[ Line: 437 | Upvalues: SimonSays2 (copy), v2 (ref), v10 (copy), t5 (copy), playUISound (ref), t2 (ref), t (copy), v5 (ref) ]]
			task.wait(SimonSays2.RoundPause)

			if v2 ~= v10 then
				return
			end

			for v12, v22 in t5 do
				playUISound(t2.Sounds.Click)

				local LitColor = SimonSays2.LitColor
				local ShowTime = SimonSays2.ShowTime
				local v32 = v10

				t[v22].BackgroundColor3 = LitColor
				task.delay(ShowTime, function() --[[ Line: 413 | Upvalues: v2 (ref), v32 (copy), t (ref), v22 (copy), SimonSays2 (ref) ]]
					if v2 ~= v32 then
						return
					end

					t[v22].BackgroundColor3 = SimonSays2.ButtonColor
				end)
				task.wait(SimonSays2.ShowTime + SimonSays2.GapTime)

				if v2 ~= v10 then
					return
				end
			end

			v5 = true
		end)

		return function() --[[ Line: 522 | Upvalues: v2 (ref), t4 (copy) ]]
			v2 = v2 + 1

			for v1, v22 in t4 do
				v22:Disconnect()
			end
		end
	end

	local function startMinigame(p12) --[[ startMinigame | Line: 533 | Upvalues: v2 (ref), SkillCheck (copy), SimonSays (copy), v3 (ref), p1 (copy), v12 (copy), startSkillCheck (copy), startSimon (copy) ]]
		if v2 then
			local v1 = v2

			v2 = nil
			v1()
		end

		SkillCheck.Visible = false
		SimonSays.Visible = false
		v3 = p12
		p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(v12)
		v2 = if math.random(2) == 1 then startSkillCheck() else startSimon()
	end

	local function setupPrompt(p1) --[[ setupPrompt | Line: 545 | Upvalues: t2 (ref), Players (ref), v12 (copy), Remotes (ref), SignalBag (ref), startMinigame (copy) ]]
		local v1 = t2
		local v2 = p1:FindFirstChildWhichIsA("ProximityPrompt")
		local OpenChestPrompt = if v2 then v2 else Instance.new("ProximityPrompt")

		OpenChestPrompt.Parent = p1
		OpenChestPrompt.Name = "OpenChestPrompt"
		OpenChestPrompt.Style = Enum.ProximityPromptStyle.Custom
		OpenChestPrompt.ActionText = v1.PromptActionText
		OpenChestPrompt.ObjectText = v1.PromptObjectText
		OpenChestPrompt.HoldDuration = v1.PromptHoldDuration
		OpenChestPrompt.MaxActivationDistance = v1.PromptDistance
		OpenChestPrompt.RequiresLineOfSight = false
		OpenChestPrompt.Triggered:Connect(function(p12) --[[ Line: 558 | Upvalues: Players (ref), v12 (ref), t2 (ref), Remotes (ref), SignalBag (ref), startMinigame (ref), p1 (copy) ]]
			if p12 ~= Players.LocalPlayer then
				return
			end

			if v12.Visible:Get() then
				return
			end

			if t2.MinigamesEnabled then
				startMinigame(p1)
			else
				Remotes.ChestMinigameCompleted:Fire({
					minigame = "Direct"
				})
				SignalBag.ChestClaimed:Fire()
			end
		end)
	end

	local function onTagged(p1) --[[ onTagged | Line: 576 | Upvalues: t2 (ref), v1 (ref), setupPrompt (copy) ]]
		if not p1:IsA("BasePart") then
			warn((("[ChestMinigame] \"%*\" tag is on a %* (%*) \226\128\148 needs a BasePart"):format(t2.PromptTag, p1.ClassName, (p1:GetFullName()))))

			return
		end

		if not v1[p1] then
			v1[p1] = true
			setupPrompt(p1)
		end
	end

	for v6, v7 in CollectionService:GetTagged(t2.PromptTag) do
		if v7:IsA("BasePart") then
			if not v1[v7] then
				v1[v7] = true
				setupPrompt(v7)
			end

			continue
		end

		warn((("[ChestMinigame] \"%*\" tag is on a %* (%*) \226\128\148 needs a BasePart"):format(t2.PromptTag, v7.ClassName, (v7:GetFullName()))))
	end

	CollectionService:GetInstanceAddedSignal(t2.PromptTag):Connect(onTagged)
	CollectionService:GetInstanceRemovedSignal(t2.PromptTag):Connect(function(p12) --[[ Line: 597 | Upvalues: v1 (ref), v3 (ref), v12 (copy), p1 (copy) ]]
		if not p12:IsA("BasePart") then
			return
		end

		v1[p12] = nil

		local OpenChestPrompt = p12:FindFirstChild("OpenChestPrompt")

		if OpenChestPrompt then
			OpenChestPrompt:Destroy()
		end

		if p12 ~= v3 or not v12.Visible:Get() then
			return
		end

		local v13 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

		if v13.OpenedUIComponent:Get() ~= v12 then
			return
		end

		v13.OpenedUIComponent:Set(nil)
	end)
end

return t