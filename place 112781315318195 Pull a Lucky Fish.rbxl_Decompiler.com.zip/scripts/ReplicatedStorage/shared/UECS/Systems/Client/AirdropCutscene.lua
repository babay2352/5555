-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local Workspace = game:GetService("Workspace")
local AirdropConfig = require(ReplicatedStorage.shared.config.AirdropConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Remotes = require(ReplicatedStorage.shared.Remotes)
local SignalBag = require(ReplicatedStorage.client.SignalBag)
local t = {
	UECS = nil
}
local v1 = false
local v2 = 0
local v3 = nil

local function ensureFade() --[[ ensureFade | Line: 62 | Upvalues: v3 (ref), Players (copy) ]]
	if v3 and v3.Parent then
		return v3
	end

	local AirdropFade = Instance.new("ScreenGui")

	AirdropFade.Name = "AirdropFade"
	AirdropFade.IgnoreGuiInset = true
	AirdropFade.DisplayOrder = 100
	AirdropFade.ResetOnSpawn = false

	local Frame = Instance.new("Frame")

	Frame.Size = UDim2.fromScale(1, 1)
	Frame.BackgroundColor3 = Color3.new(0/255, 0/255, 0/255)
	Frame.BackgroundTransparency = 1
	Frame.BorderSizePixel = 0
	Frame.Parent = AirdropFade
	AirdropFade.Parent = Players.LocalPlayer:WaitForChild("PlayerGui")
	v3 = Frame

	return Frame
end

local function fadeTo(p1, p2) --[[ fadeTo | Line: 83 | Upvalues: ensureFade (copy), TweenService (copy) ]]
	local v1 = TweenService:Create(ensureFade(), TweenInfo.new(p2, Enum.EasingStyle.Quad), {
		BackgroundTransparency = p1
	})

	v1:Play()
	v1.Completed:Wait()
end

local function loadTrack(p1, p2) --[[ loadTrack | Line: 95 ]]
	local AnimationController = p1:FindFirstChildOfClass("AnimationController")

	if not AnimationController then
		return nil
	end

	local Animator = AnimationController:FindFirstChildOfClass("Animator")

	if not Animator then
		Animator = Instance.new("Animator")
		Animator.Parent = AnimationController
	end

	local Animation = Instance.new("Animation")

	Animation.AnimationId = p2

	local ok, result = pcall(function() --[[ Line: 107 | Upvalues: Animator (ref), Animation (copy) ]]
		return Animator:LoadAnimation(Animation)
	end)

	return if ok then result else nil
end

local function playOnceFrozen(p1) --[[ playOnceFrozen | Line: 119 ]]
	p1.Looped = true
	p1:Play()
	task.spawn(function() --[[ Line: 122 | Upvalues: p1 (copy) ]]
		for i = 1, 50 do
			if p1.Length > 0 then
				break
			end

			task.wait(0.1)
		end

		if p1.Length <= 0 then
			return
		end

		local v1 = false
		local v2 = p1.DidLoop:Connect(function() --[[ Line: 135 | Upvalues: v1 (ref) ]]
			v1 = true
		end)

		while not v1 and p1.TimePosition < p1.Length - 0.05 do
			task.wait()
		end

		v2:Disconnect()
		p1.TimePosition = math.max(p1.Length - 0.005, 0)
		p1:AdjustSpeed(0)
	end)
end

local function playSFX(p1, p2, p3) --[[ playSFX | Line: 153 | Upvalues: ReplicatedStorage (copy) ]]
	local SFX = ReplicatedStorage.shared.model:FindFirstChild("SFX")
	local v1 = if SFX then SFX:FindFirstChild(p1) else SFX

	if not (v1 and v1:IsA("Sound")) then
		warn((("[AirdropCutscene] SFX \"%*\" not found in ReplicatedStorage.shared.model.SFX"):format(p1)))

		return nil
	end

	local v2 = v1:Clone()

	if p3 ~= nil then
		v2.Looped = p3
	end

	v2.Parent = p2
	v2:Play()

	return v2
end

local function shrinkAndDestroy(p1) --[[ shrinkAndDestroy | Line: 169 | Upvalues: AirdropConfig (copy), RunService (copy) ]]
	task.spawn(function() --[[ Line: 170 | Upvalues: p1 (copy), AirdropConfig (ref), RunService (ref) ]]
		local v1 = p1:GetScale()
		local v2 = os.clock()

		while p1.Parent do
			local v3 = (os.clock() - v2) / AirdropConfig.Drop.ShrinkTime

			if v3 >= 1 then
				break
			end

			p1:ScaleTo((math.max(v1 * (1 - v3), 0.01)))
			RunService.RenderStepped:Wait()
		end

		p1:Destroy()
	end)
end

local function buildTimeline(p1, p2) --[[ buildTimeline | Line: 197 | Upvalues: AirdropConfig (copy) ]]
	local Flight = AirdropConfig.Flight
	local LookVector = CFrame.Angles(0, math.rad(Flight.Heading), 0).LookVector
	local t = {
		startAt = p1,
		dropTop = p2
	}

	t.overhead = p2 + Vector3.new(0, Flight.Height, 0)
	t.direction = LookVector
	t.dropAt = Flight.Time / 2
	t.landAt = Flight.Time / 2 + AirdropConfig.Drop.FallTime

	return t
end

local function timelineNow(p1) --[[ timelineNow | Line: 210 | Upvalues: Workspace (copy) ]]
	return Workspace:GetServerTimeNow() - p1.startAt
end

local function planeCFrameAt(p1, p2) --[[ planeCFrameAt | Line: 217 | Upvalues: AirdropConfig (copy) ]]
	local Flight = AirdropConfig.Flight
	local v3 = p1.overhead - p1.direction * Flight.HalfDistance + p1.direction * (2 * Flight.HalfDistance * math.clamp(p2 / Flight.Time, 0, 1))

	return CFrame.lookAt(v3, v3 + p1.direction)
end

local function modelCFrameAt(p1, p2) --[[ modelCFrameAt | Line: 225 | Upvalues: AirdropConfig (copy) ]]
	local Flight = AirdropConfig.Flight
	local v3 = p1.overhead - p1.direction * Flight.HalfDistance + p1.direction * (2 * Flight.HalfDistance * math.clamp(p2 / Flight.Time, 0, 1))
	local v4 = CFrame.lookAt(v3, v3 + p1.direction)

	return v4 * CFrame.Angles(0, math.rad(AirdropConfig.Flight.ModelYawOffset), 0)
end

local function chestYawCFrame() --[[ chestYawCFrame | Line: 229 | Upvalues: AirdropConfig (copy) ]]
	local Angles = CFrame.Angles

	return Angles(0, math.rad(AirdropConfig.Drop.ChestYaw), 0)
end

local function chestPositionAt(p1, p2) --[[ chestPositionAt | Line: 235 | Upvalues: AirdropConfig (copy) ]]
	local Drop = AirdropConfig.Drop
	local v2 = math.clamp((p2 - p1.dropAt) / Drop.FallTime, 0, 1)
	local v3 = p1.overhead.Y - Drop.BellyDrop

	return Vector3.new(p1.dropTop.X, v3 - (v3 - p1.dropTop.Y) * v2, p1.dropTop.Z)
end

local function formatTimer(p1) --[[ formatTimer | Line: 244 ]]
	if p1 >= 60 then
		return string.format("%d:%02ds", p1 // 60, p1 % 60)
	end

	return string.format("%ds", p1)
end

local function setupLandedChest(p1, p2, p3) --[[ setupLandedChest | Line: 254 | Upvalues: CollectionService (copy), AirdropConfig (copy), RunService (copy), SignalBag (copy), v2 (ref), Workspace (copy) ]]
	local RootPart = p1:FindFirstChild("RootPart")

	if RootPart and RootPart:IsA("BasePart") then
		CollectionService:AddTag(RootPart, "OpenChest")

		local AirdropTimer = Instance.new("BillboardGui")

		AirdropTimer.Name = "AirdropTimer"
		AirdropTimer.Size = UDim2.fromOffset(200, 50)
		AirdropTimer.StudsOffsetWorldSpace = Vector3.new(0, 7, 0)
		AirdropTimer.AlwaysOnTop = true
		AirdropTimer.MaxDistance = 200

		local TimeLeft = Instance.new("TextLabel")

		TimeLeft.Name = "TimeLeft"
		TimeLeft.Size = UDim2.fromScale(1, 1)
		TimeLeft.BackgroundTransparency = 1
		TimeLeft.Font = Enum.Font.GothamBold
		TimeLeft.TextScaled = true
		TimeLeft.TextColor3 = Color3.new(255/255, 255/255, 255/255)

		local UIStroke = Instance.new("UIStroke")

		UIStroke.Color = Color3.new(0/255, 0/255, 0/255)
		UIStroke.Thickness = 2
		UIStroke.Parent = TimeLeft
		TimeLeft.Parent = AirdropTimer
		AirdropTimer.Parent = RootPart

		local v1 = nil
		local v22 = false

		local function despawn() --[[ despawn | Line: 287 | Upvalues: v22 (ref), v1 (ref), CollectionService (ref), RootPart (copy), AirdropTimer (copy), p1 (copy), AirdropConfig (ref), RunService (ref) ]]
			if v22 then
				return
			end

			v22 = true

			local v12

			if v1 then
				v1:Disconnect()
				v1 = nil
			end

			CollectionService:RemoveTag(RootPart, "OpenChest")
			AirdropTimer:Destroy()
			v12 = p1
			task.spawn(function() --[[ Line: 170 | Upvalues: v12 (copy), AirdropConfig (ref), RunService (ref) ]]
				local v1 = v12:GetScale()
				local v2 = os.clock()

				while v12.Parent do
					local v3 = (os.clock() - v2) / AirdropConfig.Drop.ShrinkTime

					if v3 >= 1 then
						break
					end

					v12:ScaleTo((math.max(v1 * (1 - v3), 0.01)))
					RunService.RenderStepped:Wait()
				end

				v12:Destroy()
			end)
		end

		v1 = SignalBag.ChestClaimed:Connect(despawn)

		local v3 = p2.startAt + p2.landAt + AirdropConfig.Drop.Lifetime

		task.spawn(function() --[[ Line: 312 | Upvalues: p1 (copy), v22 (ref), p3 (copy), v2 (ref), v1 (ref), v3 (copy), Workspace (ref), CollectionService (ref), RootPart (copy), AirdropTimer (copy), AirdropConfig (ref), RunService (ref), TimeLeft (copy) ]]
			local v12 = ""

			while p1.Parent and not v22 do
				if p3 == v2 then
					local v32 = math.ceil(v3 - Workspace:GetServerTimeNow())

					if v32 <= 0 then
						if v22 then
							break
						end

						v22 = true

						local v4

						if not v1 then
							CollectionService:RemoveTag(RootPart, "OpenChest")
							AirdropTimer:Destroy()
							v4 = p1
							task.spawn(function() --[[ Line: 170 | Upvalues: v4 (copy), AirdropConfig (ref), RunService (ref) ]]
								local v1 = v4:GetScale()
								local v2 = os.clock()

								while v4.Parent do
									local v3 = (os.clock() - v2) / AirdropConfig.Drop.ShrinkTime

									if v3 >= 1 then
										break
									end

									v4:ScaleTo((math.max(v1 * (1 - v3), 0.01)))
									RunService.RenderStepped:Wait()
								end

								v4:Destroy()
							end)

							return
						end

						v1:Disconnect()
						v1 = nil
						CollectionService:RemoveTag(RootPart, "OpenChest")
						AirdropTimer:Destroy()
						v4 = p1
						task.spawn(function() --[[ Line: 170 | Upvalues: v4 (copy), AirdropConfig (ref), RunService (ref) ]]
							local v1 = v4:GetScale()
							local v2 = os.clock()

							while v4.Parent do
								local v3 = (os.clock() - v2) / AirdropConfig.Drop.ShrinkTime

								if v3 >= 1 then
									break
								end

								v4:ScaleTo((math.max(v1 * (1 - v3), 0.01)))
								RunService.RenderStepped:Wait()
							end

							v4:Destroy()
						end)

						return
					end

					local v5 = if v32 >= 60 then string.format("%d:%02ds", v32 // 60, v32 % 60) else string.format("%ds", v32)

					if v5 ~= v12 then
						TimeLeft.Text = v5
						v12 = v5
					end

					task.wait(0.1)
				else
					v22 = true

					if not v1 then
						p1:Destroy()

						return
					end

					v1:Disconnect()
					v1 = nil
					p1:Destroy()

					return
				end
			end
		end)
	else
		warn("[AirdropCutscene] local chest has no RootPart \226\128\148 no prompt/timer")
	end
end

local function runVisuals(p1, p2) --[[ runVisuals | Line: 342 | Upvalues: ReplicatedStorage (copy), Workspace (copy), AirdropConfig (copy), loadTrack (copy), playSFX (copy), RunService (copy), v2 (ref), setupLandedChest (copy) ]]
	local model = ReplicatedStorage.shared.model
	local Plane = model:FindFirstChild("Plane")
	local Airdrop = model:FindFirstChild("Airdrop")

	if not (Plane and (Plane:IsA("Model") and (Airdrop and Airdrop:IsA("Model")))) then
		warn("[AirdropCutscene] Plane/Airdrop model missing in ReplicatedStorage.shared.model")

		return
	end

	local AirdropPlaneFX = Plane:Clone()

	for v1, v22 in AirdropPlaneFX:GetDescendants() do
		if v22:IsA("BasePart") then
			v22.Anchored = v22 == AirdropPlaneFX.PrimaryPart
			v22.CanCollide = false
			v22.CanQuery = false
		end
	end

	AirdropPlaneFX.Name = "AirdropPlaneFX"

	local v3 = Workspace:GetServerTimeNow() - p1.startAt
	local Flight = AirdropConfig.Flight
	local v6 = p1.overhead - p1.direction * Flight.HalfDistance + p1.direction * (2 * Flight.HalfDistance * math.clamp(v3 / Flight.Time, 0, 1))
	local v7 = CFrame.lookAt(v6, v6 + p1.direction)
	local Angles = CFrame.Angles
	local ModelYawOffset = AirdropConfig.Flight.ModelYawOffset

	AirdropPlaneFX:PivotTo(v7 * Angles(0, math.rad(ModelYawOffset), 0))
	AirdropPlaneFX.Parent = Workspace

	local v8 = loadTrack(AirdropPlaneFX, AirdropConfig.Animations.PlaneIdle)

	if v8 then
		v8.Looped = true
		v8:Play()
	end

	if AirdropPlaneFX.PrimaryPart then
		playSFX(AirdropConfig.Sounds.PlaneLoop, AirdropPlaneFX.PrimaryPart, true)
	end

	local v9 = nil
	local v10 = nil
	local v11 = false
	local v12 = false
	local v13 = nil

	v13 = RunService.RenderStepped:Connect(function() --[[ Line: 381 | Upvalues: p1 (copy), Workspace (ref), p2 (copy), v2 (ref), v13 (ref), AirdropPlaneFX (copy), v9 (ref), v11 (ref), AirdropConfig (ref), v12 (ref), loadTrack (ref), playSFX (ref), Airdrop (copy), v10 (ref), setupLandedChest (ref) ]]
		local v22 = Workspace:GetServerTimeNow() - p1.startAt

		if p2 == v2 then
			if AirdropConfig.Flight.Time <= v22 then
				v13:Disconnect()
				AirdropPlaneFX:Destroy()

				return
			end

			local v4 = p1
			local Flight = AirdropConfig.Flight
			local v7 = v4.overhead - v4.direction * Flight.HalfDistance + v4.direction * (2 * Flight.HalfDistance * math.clamp(v22 / Flight.Time, 0, 1))
			local v8 = CFrame.lookAt(v7, v7 + v4.direction)

			AirdropPlaneFX:PivotTo(v8 * CFrame.Angles(0, math.rad(AirdropConfig.Flight.ModelYawOffset), 0))

			if not v12 and p1.dropAt - AirdropConfig.Flight.DoorOpenLead <= v22 then
				v12 = true

				local v92 = loadTrack(AirdropPlaneFX, AirdropConfig.Animations.PlaneDoorOpen)

				if v92 then
					v92:Play()
				end

				if AirdropPlaneFX.PrimaryPart then
					playSFX(AirdropConfig.Sounds.DoorOpen, AirdropPlaneFX.PrimaryPart)
				end
			end

			if p1.dropAt <= v22 and v22 < p1.landAt then
				if not v9 then
					local AirdropChest = Airdrop:Clone()

					for v102, v112 in AirdropChest:GetDescendants() do
						if v112:IsA("BasePart") then
							v112.Anchored = v112 == AirdropChest.PrimaryPart
						end
					end

					AirdropChest.Name = "AirdropChest"

					local v122 = CFrame.new
					local v132 = p1
					local Drop = AirdropConfig.Drop
					local v15 = math.clamp((v22 - v132.dropAt) / Drop.FallTime, 0, 1)
					local v16 = v132.overhead.Y - Drop.BellyDrop
					local v18 = v122((Vector3.new(v132.dropTop.X, v16 - (v16 - v132.dropTop.Y) * v15, v132.dropTop.Z)))

					AirdropChest:PivotTo(v18 * CFrame.Angles(0, math.rad(AirdropConfig.Drop.ChestYaw), 0))
					AirdropChest.Parent = Workspace
					v10 = loadTrack(AirdropChest, AirdropConfig.Animations.AirdropFalling)

					if v10 then
						v10:Play()
					end

					if AirdropChest.PrimaryPart then
						playSFX(AirdropConfig.Sounds.ParachuteDrop, AirdropChest.PrimaryPart)
					end

					v9 = AirdropChest
				end

				local v20 = CFrame.new
				local v21 = p1
				local Drop = AirdropConfig.Drop
				local v23 = math.clamp((v22 - v21.dropAt) / Drop.FallTime, 0, 1)
				local v24 = v21.overhead.Y - Drop.BellyDrop
				local v26 = v20((Vector3.new(v21.dropTop.X, v24 - (v24 - v21.dropTop.Y) * v23, v21.dropTop.Z)))

				v9:PivotTo(v26 * CFrame.Angles(0, math.rad(AirdropConfig.Drop.ChestYaw), 0))
			else
				if not (p1.landAt <= v22) or (not v9 or v11) then
					return
				end

				v11 = true

				local v27 = v9
				local v28 = CFrame.new(p1.dropTop)
				local Angles2 = CFrame.Angles

				v27:PivotTo(v28 * Angles2(0, math.rad(AirdropConfig.Drop.ChestYaw), 0))

				if v10 then
					v10:Stop(0.2)
					v10 = nil
				end

				local v29 = loadTrack(v27, AirdropConfig.Animations.AirdropClosing)

				if v29 then
					v29.Looped = true
					v29:Play()
					task.spawn(function() --[[ Line: 122 | Upvalues: v29 (copy) ]]
						for i = 1, 50 do
							if v29.Length > 0 then
								break
							end

							task.wait(0.1)
						end

						if v29.Length <= 0 then
							return
						end

						local v1 = false
						local v2 = v29.DidLoop:Connect(function() --[[ Line: 135 | Upvalues: v1 (ref) ]]
							v1 = true
						end)

						while not v1 and v29.TimePosition < v29.Length - 0.05 do
							task.wait()
						end

						v2:Disconnect()
						v29.TimePosition = math.max(v29.Length - 0.005, 0)
						v29:AdjustSpeed(0)
					end)
				end

				setupLandedChest(v27, p1, p2)
			end
		else
			v13:Disconnect()
			AirdropPlaneFX:Destroy()

			if not v9 or v11 then
				return
			end

			v9:Destroy()
		end
	end)
end

local function isFishing() --[[ isFishing | Line: 457 | Upvalues: Players (copy), ReplicatedStorage (copy) ]]
	if Players.LocalPlayer:GetAttribute("IsFishing") then
		return true
	end

	local ok, result = pcall(function() --[[ Line: 461 | Upvalues: ReplicatedStorage (ref) ]]
		return require(ReplicatedStorage.shared.UECS.Systems.Client.ThrowSystem)
	end)

	if ok and (result and result.IsAutoFishing) then
		return result:IsAutoFishing()
	end

	return false
end

local function runCutscene(p1) --[[ runCutscene | Line: 470 | Upvalues: Workspace (copy), AirdropConfig (copy), Players (copy), ReplicatedStorage (copy), RunService (copy), TweenService (copy), fadeTo (copy) ]]
	local CurrentCamera = Workspace.CurrentCamera

	if not CurrentCamera then
		return
	end

	local Cutscene = AirdropConfig.Cutscene
	local Character = Players.LocalPlayer.Character
	local v1 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character
	local v2 = if v1 then v1.Anchored else false

	if v1 then
		v1.Anchored = true
	end

	local v3 = CurrentCamera.CFrame

	CurrentCamera.CameraType = Enum.CameraType.Scriptable

	local Satchel = require(ReplicatedStorage.client.Satchel)
	local topbarplus = require(ReplicatedStorage.client.Satchel.Package.topbarplus)

	pcall(function() --[[ Line: 492 | Upvalues: Satchel (copy), topbarplus (copy) ]]
		Satchel.SetEnabled(false)
		topbarplus.setTopbarEnabled(false)
	end)

	local function playUntil(p12, p2) --[[ playUntil | Line: 499 | Upvalues: p1 (copy), Workspace (ref), RunService (ref) ]]
		while true do
			local v2 = Workspace:GetServerTimeNow() - p1.startAt

			if p12 <= v2 then
				break
			end

			p2(v2)
			RunService.RenderStepped:Wait()
		end
	end

	local ok, result = pcall(function() --[[ Line: 510 | Upvalues: p1 (copy), Workspace (ref), v3 (copy), playUntil (copy), Cutscene (copy), TweenService (ref), AirdropConfig (ref), CurrentCamera (copy), fadeTo (ref) ]]
		local v1 = p1
		local v2 = Workspace:GetServerTimeNow() - v1.startAt
		local LookVector = v3.LookVector

		playUntil(v2 + Cutscene.LookTurnTime, function(p12) --[[ Line: 514 | Upvalues: v2 (copy), Cutscene (ref), TweenService (ref), p1 (ref), AirdropConfig (ref), v3 (ref), LookVector (copy), CurrentCamera (ref) ]]
			local v22 = TweenService:GetValue(math.clamp((p12 - v2) / Cutscene.LookTurnTime, 0, 1), Enum.EasingStyle.Sine, Enum.EasingDirection.InOut)
			local v32 = p1
			local Flight = AirdropConfig.Flight
			local v6 = v32.overhead - v32.direction * Flight.HalfDistance + v32.direction * (2 * Flight.HalfDistance * math.clamp(p12 / Flight.Time, 0, 1))

			CurrentCamera.CFrame = CFrame.lookAt(v3.Position, v3.Position + LookVector:Lerp((CFrame.lookAt(v6, v6 + v32.direction).Position - v3.Position).Unit, v22))
		end)
		fadeTo(0, Cutscene.FadeTime)

		local v32 = p1.dropAt - AirdropConfig.Flight.DoorOpenLead
		local v4 = CurrentCamera
		local lookAt = CFrame.lookAt
		local v5 = p1
		local v6 = p1
		local v7 = Workspace:GetServerTimeNow() - v6.startAt
		local Flight = AirdropConfig.Flight
		local v10 = v5.overhead - v5.direction * Flight.HalfDistance + v5.direction * (2 * Flight.HalfDistance * math.clamp(v7 / Flight.Time, 0, 1))
		local v11 = CFrame.lookAt(v10, v10 + v5.direction):PointToWorldSpace(Cutscene.FrontOffset)
		local v12 = p1
		local v13 = p1
		local v14 = Workspace:GetServerTimeNow() - v13.startAt
		local Flight2 = AirdropConfig.Flight
		local v17 = v12.overhead - v12.direction * Flight2.HalfDistance + v12.direction * (2 * Flight2.HalfDistance * math.clamp(v14 / Flight2.Time, 0, 1))

		v4.CFrame = lookAt(v11, CFrame.lookAt(v17, v17 + v12.direction).Position)
		fadeTo(1, Cutscene.FadeTime)
		playUntil(v32 - Cutscene.HatchCamLead, function(p12) --[[ Line: 530 | Upvalues: p1 (ref), AirdropConfig (ref), CurrentCamera (ref), Cutscene (ref) ]]
			local v1 = p1
			local Flight = AirdropConfig.Flight
			local v4 = v1.overhead - v1.direction * Flight.HalfDistance + v1.direction * (2 * Flight.HalfDistance * math.clamp(p12 / Flight.Time, 0, 1))
			local v5 = CFrame.lookAt(v4, v4 + v1.direction)

			CurrentCamera.CFrame = CFrame.lookAt(v5:PointToWorldSpace(Cutscene.FrontOffset), v5.Position)
		end)
		playUntil(p1.dropAt, function(p12) --[[ Line: 537 | Upvalues: p1 (ref), AirdropConfig (ref), CurrentCamera (ref), Cutscene (ref) ]]
			local v1 = p1
			local Flight = AirdropConfig.Flight
			local v4 = v1.overhead - v1.direction * Flight.HalfDistance + v1.direction * (2 * Flight.HalfDistance * math.clamp(p12 / Flight.Time, 0, 1))
			local v5 = CFrame.lookAt(v4, v4 + v1.direction)

			CurrentCamera.CFrame = CFrame.lookAt(v5:PointToWorldSpace(Cutscene.BellyOffset), v5:PointToWorldSpace(Cutscene.BellyLookOffset))
		end)

		local Position = CurrentCamera.CFrame.Position

		playUntil(p1.dropAt + Cutscene.FocusHold, function(p12) --[[ Line: 550 | Upvalues: p1 (ref), Cutscene (ref), TweenService (ref), AirdropConfig (ref), Position (copy), CurrentCamera (ref) ]]
			local v2 = TweenService:GetValue(math.clamp((p12 - p1.dropAt) / Cutscene.FocusHold, 0, 1), Enum.EasingStyle.Sine, Enum.EasingDirection.InOut)
			local v3 = p1
			local Flight = AirdropConfig.Flight
			local v6 = v3.overhead - v3.direction * Flight.HalfDistance + v3.direction * (2 * Flight.HalfDistance * math.clamp(p12 / Flight.Time, 0, 1))
			local v7 = CFrame.lookAt(v6, v6 + v3.direction)
			local v8 = v7:PointToWorldSpace(Cutscene.BellyOffset):Lerp(Position, v2)
			local v9 = v7:PointToWorldSpace(Cutscene.BellyLookOffset)
			local v10 = p1
			local Drop = AirdropConfig.Drop
			local v12 = math.clamp((p12 - v10.dropAt) / Drop.FallTime, 0, 1)
			local v13 = v10.overhead.Y - Drop.BellyDrop

			CurrentCamera.CFrame = CFrame.lookAt(v8, (v9:Lerp(Vector3.new(v10.dropTop.X, v13 - (v13 - v10.dropTop.Y) * v12, v10.dropTop.Z) + Vector3.new(0, 2, 0), v2)))
		end)

		local v18 = p1
		local v19 = Workspace:GetServerTimeNow() - v18.startAt
		local Position2 = CurrentCamera.CFrame.Position
		local v20 = p1
		local Drop = AirdropConfig.Drop
		local v22 = math.clamp((v19 - v20.dropAt) / Drop.FallTime, 0, 1)
		local v23 = v20.overhead.Y - Drop.BellyDrop
		local v25 = Position2 - Vector3.new(v20.dropTop.X, v23 - (v23 - v20.dropTop.Y) * v22, v20.dropTop.Z)
		local v26 = v25 * Vector3.new(1, 0, 1)
		local v27 = math.atan2(v26.X, v26.Z)
		local Magnitude = v26.Magnitude
		local Y = v25.Y

		playUntil(v19 + Cutscene.OrbitTime, function(p12) --[[ Line: 571 | Upvalues: v19 (copy), Cutscene (ref), TweenService (ref), v27 (copy), Magnitude (copy), Y (copy), p1 (ref), AirdropConfig (ref), CurrentCamera (ref) ]]
			local v2 = TweenService:GetValue(math.clamp((p12 - v19) / Cutscene.OrbitTime, 0, 1), Enum.EasingStyle.Sine, Enum.EasingDirection.InOut)
			local v4 = v27 + math.rad(Cutscene.OrbitDegrees) * v2
			local v7 = p1
			local Drop = AirdropConfig.Drop
			local v9 = math.clamp((p12 - v7.dropAt) / Drop.FallTime, 0, 1)
			local v10 = v7.overhead.Y - Drop.BellyDrop
			local v12 = Vector3.new(v7.dropTop.X, v10 - (v10 - v7.dropTop.Y) * v9, v7.dropTop.Z)
			local v13 = math.sin(v4)
			local v14 = math.cos(v4)

			CurrentCamera.CFrame = CFrame.lookAt(v12 + (Vector3.new(v13, 0, v14) * (Magnitude + (Cutscene.OrbitRadius - Magnitude) * v2) + Vector3.new(0, Y + (Cutscene.OrbitHeight - Y) * v2, 0)), v12 + Vector3.new(0, 2, 0))
		end)

		local v28 = p1
		local v29 = Workspace:GetServerTimeNow() - v28.startAt
		local v30 = CurrentCamera.CFrame
		local v31 = false

		playUntil(v29 + Cutscene.ReturnTime, function(p1) --[[ Line: 586 | Upvalues: v29 (copy), Cutscene (ref), TweenService (ref), CurrentCamera (ref), v30 (copy), v3 (ref), v31 (ref), fadeTo (ref) ]]
			local v2 = math.clamp((p1 - v29) / Cutscene.ReturnTime, 0, 1)

			CurrentCamera.CFrame = v30:Lerp(v3, (TweenService:GetValue(v2, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut)))

			if v31 or not (1 - Cutscene.FadeTime / Cutscene.ReturnTime <= v2) then
				return
			end

			v31 = true
			task.spawn(fadeTo, 0, Cutscene.FadeTime)
		end)

		if not v31 then
			fadeTo(0, Cutscene.FadeTime)
		end
	end)

	pcall(function() --[[ Line: 602 | Upvalues: Satchel (copy), topbarplus (copy) ]]
		Satchel.SetEnabled(true)
		topbarplus.setTopbarEnabled(true)
	end)
	CurrentCamera.CameraType = Enum.CameraType.Custom

	if v1 and v1.Parent then
		v1.Anchored = v2
	end

	fadeTo(1, Cutscene.FadeTime)

	if ok then
		return
	end

	warn((("[AirdropCutscene] cutscene aborted: %*"):format(result)))
end

function t.Init(p1) --[[ Init | Line: 617 | Upvalues: Remotes (copy), v2 (ref), buildTimeline (copy), runVisuals (copy), v1 (ref), isFishing (copy), Workspace (copy), runCutscene (copy) ]]
	Remotes.AirdropStarted:On(function(p1) --[[ Line: 618 | Upvalues: v2 (ref), buildTimeline (ref), runVisuals (ref), v1 (ref), isFishing (ref), Workspace (ref), runCutscene (ref) ]]
		v2 = v2 + 1

		local v3 = buildTimeline(p1.startAt, (Vector3.new(p1.dropX, p1.dropY, p1.dropZ)))

		task.spawn(runVisuals, v3, v2)

		if v1 or isFishing() then
			return
		end

		local CurrentCamera = Workspace.CurrentCamera

		if not CurrentCamera or CurrentCamera.CameraType ~= Enum.CameraType.Scriptable then
			v1 = true
			task.spawn(function() --[[ Line: 636 | Upvalues: runCutscene (ref), v3 (copy), v1 (ref) ]]
				runCutscene(v3)
				v1 = false
			end)
		end
	end)
	Remotes.AirdropCleared:On(function() --[[ Line: 644 | Upvalues: v2 (ref) ]]
		v2 = v2 + 1
	end)
end

return t