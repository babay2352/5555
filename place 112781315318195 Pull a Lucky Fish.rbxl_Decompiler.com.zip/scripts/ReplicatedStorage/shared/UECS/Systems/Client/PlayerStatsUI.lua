-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local CashFormat = require(ReplicatedStorage.shared.util.CashFormat)
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local ConvertValue = require(ReplicatedStorage.shared.util.ConvertValue)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local topbarplus = require(ReplicatedStorage.client.Satchel.Package.topbarplus)
local PlayerStatsUI = require(ReplicatedStorage.shared.UECS.Components.PlayerStatsUI)
local t = {
	UECS = nil
}
local t2 = {
	Cash = Color3.fromRGB(28, 231, 9),
	Gems = Color3.fromRGB(80, 220, 255),
	Power = Color3.fromRGB(251, 255, 0),
	Neutral = Color3.fromRGB(160, 200, 235)
}

local function GetStats(p1) --[[ GetStats | Line: 32 | Upvalues: CashFormat (copy), t2 (copy), ConvertValue (copy) ]]
	local totalPlayTime = p1.totalPlayTime
	local v1 = math.floor(totalPlayTime / 3600)
	local v2 = math.floor(totalPlayTime % 3600 / 60)

	return {
		{
			name = "Earned Cash",
			value = CashFormat.suffixSegment(p1.stats.totalCash).Text,
			color = t2.Cash
		},
		{
			name = "Earned Gems",
			value = ConvertValue.suffixformat(p1.stats.gemsEarned or 0),
			color = t2.Gems
		},
		{
			name = "Total Power",
			value = ConvertValue.suffixformat(p1.strength or 0),
			color = t2.Power
		},
		{
			name = "Total Play Time",
			value = string.format("%02dh:%02dm", v1, v2),
			color = t2.Neutral
		}
	}
end

local function RefreshUI(p1) --[[ RefreshUI | Line: 65 | Upvalues: ClientPlayerData (copy), GetStats (copy) ]]
	local v1 = ClientPlayerData.serverProfile:getState()
	local v2 = p1.Content.Template:Clone()

	for v3, v4 in p1.Content:GetChildren() do
		if v4:IsA("Frame") and v4.Name ~= "Template" then
			v4:Destroy()
		end
	end

	for v5, v6 in GetStats(v1) do
		local v7 = v2:Clone()

		v7.Visible = true
		v7.Name = v6.name
		v7.LayoutOrder = v5
		v7.StatName.Text = v6.name
		v7.StatValue.Text = v6.value
		v7.StatValue.TextColor3 = v6.color
		v7.Parent = p1.Content
	end
end

function t.Init(p1) --[[ Init | Line: 89 | Upvalues: Players (copy), PlayerStatsUI (copy), RefreshUI (copy), topbarplus (copy) ]]
	local PlayerStatsUI2 = Players.LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("MainUI"):WaitForChild("PlayerStatsUI")
	local v1 = PlayerStatsUI.Add(PlayerStatsUI2)

	warn("STATS INIT")
	RefreshUI(PlayerStatsUI2)
	v1.Visible.OnChange:Connect(function(p1) --[[ Line: 96 | Upvalues: PlayerStatsUI2 (copy), RefreshUI (ref) ]]
		PlayerStatsUI2.Visible = p1

		if p1 ~= true then
			return
		end

		RefreshUI(PlayerStatsUI2)
	end)

	local function closePanel() --[[ closePanel | Line: 105 | Upvalues: p1 (copy), v1 (copy) ]]
		local v12 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

		if not v12 or v12.OpenedUIComponent:Get() ~= v1 then
			return
		end

		v12.OpenedUIComponent:Set(nil)
	end

	local TopBar = PlayerStatsUI2:FindFirstChild("TopBar")
	local v2 = TopBar and TopBar:FindFirstChild("CloseButton") or PlayerStatsUI2:FindFirstChild("CloseButton", true)

	if v2 and v2:IsA("GuiButton") then
		v2.MouseButton1Down:Connect(closePanel)
	else
		warn("[PlayerStatsUI] no CloseButton found under the stats frame \226\128\148 panel can only be closed from the topbar icon")
	end

	local v3 = topbarplus.new()

	v3:setImage(136522052561512)
	v3:setRight()
	v3:setName("Stats")
	v3:setCaption("Stats")
	v3:bindEvent("selected", function() --[[ Line: 133 | Upvalues: v3 (copy), p1 (copy), v1 (copy) ]]
		v3:deselect()

		local v12 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

		if v12.OpenedUIComponent:Get() == v1 then
			v12.OpenedUIComponent:Set(nil)
		else
			v12.OpenedUIComponent:Set(v1)
		end
	end)
end

return t