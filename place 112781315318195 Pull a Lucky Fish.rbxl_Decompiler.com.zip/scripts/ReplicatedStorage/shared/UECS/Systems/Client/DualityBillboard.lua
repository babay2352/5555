-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Maid = require(ReplicatedStorage.shared.class.Maid)
local getGuiObjectVisibilityDepedencies = require(ReplicatedStorage.shared.util.getGuiObjectVisibilityDepedencies)
local isObjectRenderable = require(ReplicatedStorage.shared.util.isObjectRenderable)
local v1 = Color3.fromRGB(255, 40, 32)
local v2 = Color3.fromRGB(48, 0, 4)
local v3 = Color3.fromRGB(255, 250, 224)
local v4 = Color3.fromRGB(255, 205, 92)
local v5 = Color3.fromRGB(255, 150, 40)
local t = {
	text = v1,
	stroke = v2
}
local t2 = {
	text = v3,
	stroke = v4
}
local t3 = {
	UECS = nil
}
local t4 = {}

local function hex(p1) --[[ hex | Line: 79 ]]
	return "#" .. p1:ToHex()
end

local function randGlyph() --[[ randGlyph | Line: 83 ]]
	local v1 = math.random(1, 47)

	return ("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789#@%*+=?/$\194\167"):sub(v1, v1)
end

local function fontWrap(p1, p2) --[[ fontWrap | Line: 88 ]]
	return ("<font color=\"%*\">%*</font>"):format("#" .. p2:ToHex(), p1)
end

local function findNameLabel(p1) --[[ findNameLabel | Line: 95 ]]
	local v1 = p1:FindFirstChild("Frame") or p1
	local v2 = v1:FindFirstChild("DisplayName") or v1:FindFirstChild("TextLabel")

	if v2 and v2:IsA("TextLabel") then
		return v2
	end

	return v1:FindFirstChildWhichIsA("TextLabel")
end

local function buildWord(p1, p2, p3) --[[ buildWord | Line: 106 ]]
	local t = {}

	for i = 1, #p1 do
		local v1 = (math.sin(p3 * 3 - i * 0.6) * 0.5 + 0.5) * 0.12
		local v2 = p1:sub(i, i)

		t[i] = ("<font color=\"%*\">%*</font>"):format("#" .. p2.text:Lerp(Color3.new(255/255, 255/255, 255/255), v1):ToHex(), v2)
	end

	return table.concat(t)
end

local function buildTransition(p1, p2, p3, p4, p5) --[[ buildTransition | Line: 116 | Upvalues: v5 (copy) ]]
	local t = {}

	for i = 1, math.max(#p1, #p2) do
		local v1, v2
		local v3 = math.clamp((p5 - (i - 1) * 0.1) / 0.55, 0, 1)

		if v3 <= 0 then
			local v4 = p1:sub(i, i)

			if v4 == "" then
				local v52 = math.random(1, 47)
				local v6 = ("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789#@%*+=?/$\194\167"):sub(v52, v52)

				v1 = ("<font color=\"%*\">%*</font>"):format("#" .. v5:ToHex(), v6)
			else
				v1 = ("<font color=\"%*\">%*</font>"):format("#" .. p3.text:ToHex(), v4)
			end

			t[i] = v1

			continue
		end

		if v3 >= 1 then
			local v9 = p2:sub(i, i)

			v2 = if v9 == "" then "" else ("<font color=\"%*\">%*</font>"):format("#" .. p4.text:ToHex(), v9)
			t[i] = v2

			continue
		end

		local v11 = if v3 <= 0.5 then p3.text:Lerp(v5, v3 * 2) else v5:Lerp(p4.text, (v3 - 0.5) * 2)
		local v12 = math.random(1, 47)
		local v13 = ("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789#@%*+=?/$\194\167"):sub(v12, v12)

		t[i] = ("<font color=\"%*\">%*</font>"):format("#" .. v11:ToHex(), v13)
	end

	return table.concat(t)
end

local function buildSign(p1, p2, p3) --[[ buildSign | Line: 146 | Upvalues: buildWord (copy), t (copy), buildTransition (copy), t2 (copy) ]]
	local v1 = p1 % 5.300000000000001

	if v1 < 1.5 then
		return buildWord(p2, t, p1), t.stroke
	end

	if v1 < 2.65 then
		local v2 = (v1 - 1.5) / 1.15

		return buildTransition(p2, p3, t, t2, v2), t.stroke:Lerp(t2.stroke, v2)
	end

	if v1 < 4.15 then
		return buildWord(p3, t2, p1), t2.stroke
	end

	local v3 = (v1 - 4.15) / 1.15

	return buildTransition(p3, p2, t2, t, v3), t2.stroke:Lerp(t.stroke, v3)
end

local function buildWave(p1, p2) --[[ buildWave | Line: 163 | Upvalues: v1 (copy), v3 (copy), v2 (copy), v4 (copy) ]]
	local count = 0
	local t = {}

	for v12, v22 in utf8.graphemes(p1) do
		count = count + 1

		local v32 = p1:sub(v12, v22)

		if v32 == " " then
			t[count] = " "

			continue
		end

		if v32 == "<" then
			v32 = "&lt;"
		elseif v32 == ">" then
			v32 = "&gt;"
		elseif v32 == "&" then
			v32 = "&amp;"
		end

		t[count] = ("<font color=\"%*\">%*</font>"):format("#" .. v1:Lerp(v3, math.sin(p2 * 2.4 - count * 0.6) * 0.5 + 0.5):ToHex(), v32)
	end

	local v42 = math.sin(p2 * 0.7) * 0.5 + 0.5

	return table.concat(t), v2:Lerp(v4, v42)
end

local function startFor(p1) --[[ startFor | Line: 187 | Upvalues: t4 (copy), findNameLabel (copy), buildSign (copy), buildWave (copy), Maid (copy), isObjectRenderable (copy), RunService (copy), getGuiObjectVisibilityDepedencies (copy) ]]
	if not p1:IsA("BillboardGui") or t4[p1] then
		return
	end

	if not p1:IsDescendantOf(workspace) then
		return
	end

	local v1 = findNameLabel(p1)

	if not v1 then
		warn("[DualityBillboard] No text label in", p1:GetFullName())

		return
	end

	local v2 = p1:GetAttribute("DualityWordA")
	local v3 = p1:GetAttribute("DualityWordB")
	local v4 = if v2 == nil then false elseif v3 == nil then false else true
	local v5 = tostring(v2)
	local v6 = tostring(v3)
	local Text = v1.Text

	v1.RichText = true

	local v7 = v1:FindFirstChildWhichIsA("UIStroke")

	if not v7 then
		local UIStroke = Instance.new("UIStroke")

		UIStroke.Thickness = 0.2
		UIStroke.Parent = v1
		v7 = UIStroke
	end

	local v8 = v7
	local v9 = 0
	local v10 = 0.045

	local function step(p1) --[[ step | Line: 227 | Upvalues: v9 (ref), v10 (ref), v4 (copy), buildSign (ref), v5 (copy), v6 (copy), buildWave (ref), Text (copy), v1 (copy), v8 (copy) ]]
		debug.profilebegin("UECS/DualityBillboard.Morph")
		v9 = v9 + p1
		v10 = v10 + p1

		if v10 < 0.045 then
			debug.profileend()

			return
		end

		v10 = 0

		local v12, v2

		if v4 then
			local v3, v42 = buildSign(v9, v5, v6)

			v12 = v3
			v2 = v42
		else
			local v52, v62 = buildWave(Text, v9)

			v12 = v52
			v2 = v62
		end

		v1.Text = v12
		v8.Color = v2
		v8.Thickness = (math.sin(v9 * 4) * 0.5 + 0.5) * 0.18 + 0.2
		debug.profileend()
	end

	local t = {
		connection = nil,
		destroying = nil,
		watcher = Maid.new()
	}

	local function refresh() --[[ refresh | Line: 257 | Upvalues: isObjectRenderable (ref), v1 (copy), t (copy), v10 (ref), RunService (ref), step (copy) ]]
		local v12 = isObjectRenderable(v1)

		if v12 == (t.connection ~= nil) then
			return
		end

		if v12 then
			v10 = 0.045
			t.connection = RunService.RenderStepped:Connect(step)

			return
		end

		if not t.connection then
			return
		end

		t.connection:Disconnect()
		t.connection = nil
	end

	for v11, v12 in getGuiObjectVisibilityDepedencies(v1) do
		if v12:IsA("GuiObject") then
			t.watcher:GiveTask(v12:GetPropertyChangedSignal("Visible"):Connect(refresh))

			continue
		end

		if v12:IsA("LayerCollector") then
			t.watcher:GiveTask(v12:GetPropertyChangedSignal("Enabled"):Connect(refresh))

			if v12:IsA("BillboardGui") then
				v12.DistanceStep = 1
				t.watcher:GiveTask(v12:GetPropertyChangedSignal("CurrentDistance"):Connect(refresh))
			end
		end
	end

	t.destroying = p1.Destroying:Connect(function() --[[ Line: 285 | Upvalues: t4 (ref), p1 (copy), t (copy) ]]
		if t4[p1] ~= t then
			return
		end

		if not t.connection then
			t.watcher:Destroy()
			t4[p1] = nil

			return
		end

		t.connection:Disconnect()
		t.connection = nil
		t.watcher:Destroy()
		t4[p1] = nil
	end)
	t4[p1] = t

	local v13 = isObjectRenderable(v1)

	if v13 == (if t.connection == nil then false else true) then
		return
	end

	if v13 then
		v10 = 0.045
		t.connection = RunService.RenderStepped:Connect(step)
	else
		if not t.connection then
			return
		end

		t.connection:Disconnect()
		t.connection = nil
	end
end

local function stopFor(p1) --[[ stopFor | Line: 301 | Upvalues: t4 (copy) ]]
	if not p1:IsA("BillboardGui") then
		return
	end

	local v1 = t4[p1]

	if not v1 then
		return
	end

	if v1.connection then
		v1.connection:Disconnect()
	end

	if v1.destroying then
		v1.destroying:Disconnect()
	end

	v1.watcher:Destroy()
	t4[p1] = nil
end

function t3.Init(p1) --[[ Init | Line: 318 | Upvalues: CollectionService (copy), startFor (copy), stopFor (copy) ]]
	for v1, v2 in CollectionService:GetTagged("DualityBillboard") do
		startFor(v2)
	end

	CollectionService:GetInstanceAddedSignal("DualityBillboard"):Connect(startFor)
	CollectionService:GetInstanceRemovedSignal("DualityBillboard"):Connect(stopFor)
end

return t3