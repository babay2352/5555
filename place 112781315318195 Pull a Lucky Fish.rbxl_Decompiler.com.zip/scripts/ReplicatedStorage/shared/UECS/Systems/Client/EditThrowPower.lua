-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ContextActionService = game:GetService("ContextActionService")
local GuiService = game:GetService("GuiService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local ConvertValue = require(ReplicatedStorage.shared.util.ConvertValue)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local bindToButtonPress = require(ReplicatedStorage.shared.util.bindToButtonPress)
local notifications = require(ReplicatedStorage.shared.module.notifications)
local t = {
	UECS = nil,
	Priority = 35
}

local function getLimit() --[[ getLimit | Line: 37 | Upvalues: Players (copy) ]]
	local v1 = Players.LocalPlayer:GetAttribute("CustomThrowPowerLimit")

	if typeof(v1) == "number" and v1 > 0 then
		return v1
	end

	return nil
end

local function setLimit(p1) --[[ setLimit | Line: 45 | Upvalues: Players (copy) ]]
	if p1 and p1 > 0 then
		Players.LocalPlayer:SetAttribute("CustomThrowPowerLimit", p1)
	else
		Players.LocalPlayer:SetAttribute("CustomThrowPowerLimit", nil)
	end
end

function t.Init(p1) --[[ Init | Line: 53 | Upvalues: Players (copy), ConvertValue (copy), notifications (copy), ClientPlayerData (copy), ContextActionService (copy), GuiService (copy), bindToButtonPress (copy) ]]
	local MainUI = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI")
	local EditThrowPower = MainUI:WaitForChild("EditThrowPower")
	local Edit = MainUI:WaitForChild("HUD").Counters.Strength.Edit
	local v1 = EditThrowPower.Content.Value
	local Set = EditThrowPower.Content.Set
	local Max = EditThrowPower.Content.Max
	local CloseButton = EditThrowPower.TopBar.CloseButton

	EditThrowPower.Visible = false
	v1.ClearTextOnFocus = false

	local function refreshTextBoxDisplay() --[[ refreshTextBoxDisplay | Line: 68 | Upvalues: Players (ref), v1 (copy), ConvertValue (ref) ]]
		local v12 = Players.LocalPlayer:GetAttribute("CustomThrowPowerLimit")
		local v2 = if typeof(v12) == "number" and v12 > 0 then v12 else nil

		if v2 then
			v1.Text = tostring(ConvertValue.suffixformat(v2))
		else
			v1.Text = ""
		end
	end

	local function setStrength() --[[ setStrength | Line: 77 | Upvalues: ConvertValue (ref), v1 (copy), notifications (ref), ClientPlayerData (ref), Players (ref) ]]
		local v12 = ConvertValue.parseSuffix(v1.Text)

		if not v12 or v12 <= 0 then
			notifications:Send("Invalid throw power value")

			return
		end

		local v2 = ClientPlayerData.serverProfile:getState().strength or 0

		if v2 < v12 then
			Players.LocalPlayer:SetAttribute("CustomThrowPowerLimit", nil)
			v1.Text = ""
			notifications:Send((("Value exceeds your strength (%*) \226\128\148 using %* power"):format(ConvertValue.suffixformat(v2), (notifications.ColorText("MAX", Color3.fromRGB(251, 255, 0))))))

			return
		end

		if v12 and v12 > 0 then
			Players.LocalPlayer:SetAttribute("CustomThrowPowerLimit", v12)
		else
			Players.LocalPlayer:SetAttribute("CustomThrowPowerLimit", nil)
		end

		v1.Text = tostring(ConvertValue.suffixformat(v12))
		notifications:Send((("Throw power set to %*"):format((notifications.ColorText(ConvertValue.suffixformat(v12), Color3.fromRGB(251, 255, 0))))))
	end

	local function closeFrame() --[[ closeFrame | Line: 104 | Upvalues: EditThrowPower (copy), ContextActionService (ref), GuiService (ref) ]]
		EditThrowPower.Visible = false
		ContextActionService:UnbindAction("CloseEditAction")
		ContextActionService:UnbindAction("MaxEditAction")
		ContextActionService:UnbindAction("SetEditAction")
		ContextActionService:UnbindAction("FocusEditAction")
		GuiService.SelectedObject = nil
	end

	local function openFrame() --[[ openFrame | Line: 113 | Upvalues: GuiService (ref), Players (ref), v1 (copy), ConvertValue (ref), EditThrowPower (copy), bindToButtonPress (ref), closeFrame (copy), setStrength (copy) ]]
		GuiService.SelectedObject = nil

		local v12 = Players.LocalPlayer:GetAttribute("CustomThrowPowerLimit")
		local v2 = if typeof(v12) == "number" and v12 > 0 then v12 else nil

		if v2 then
			v1.Text = tostring(ConvertValue.suffixformat(v2))
		else
			v1.Text = ""
		end

		EditThrowPower.Visible = true
		bindToButtonPress("CloseEditAction", Enum.KeyCode.ButtonB, closeFrame, 1500)
		bindToButtonPress("MaxEditAction", Enum.KeyCode.ButtonY, function() --[[ Line: 122 | Upvalues: Players (ref) ]]
			Players.LocalPlayer:SetAttribute("CustomThrowPowerLimit", nil)
		end)
		bindToButtonPress("SetEditAction", Enum.KeyCode.ButtonX, setStrength)
		bindToButtonPress("FocusEditAction", Enum.KeyCode.ButtonR3, function() --[[ Line: 126 | Upvalues: GuiService (ref), v1 (ref) ]]
			GuiService.SelectedObject = v1
			v1:CaptureFocus()
		end)
	end

	Edit.MouseButton1Click:Connect(function() --[[ Line: 132 | Upvalues: EditThrowPower (copy), ContextActionService (ref), GuiService (ref), openFrame (copy) ]]
		if EditThrowPower.Visible then
			EditThrowPower.Visible = false
			ContextActionService:UnbindAction("CloseEditAction")
			ContextActionService:UnbindAction("MaxEditAction")
			ContextActionService:UnbindAction("SetEditAction")
			ContextActionService:UnbindAction("FocusEditAction")
			GuiService.SelectedObject = nil
		else
			openFrame()
		end
	end)
	CloseButton.MouseButton1Click:Connect(closeFrame)
	v1.Focused:Connect(function() --[[ Line: 151 | Upvalues: Players (ref), v1 (copy) ]]
		local v12 = Players.LocalPlayer:GetAttribute("CustomThrowPowerLimit")
		local v2 = if typeof(v12) == "number" and v12 > 0 then v12 else nil

		if not v2 then
			return
		end

		v1.Text = tostring((math.floor(v2)))
	end)
	v1.FocusLost:Connect(function() --[[ Line: 158 | Upvalues: v1 (copy), ConvertValue (ref) ]]
		local Text = v1.Text

		if Text == "" then
			return
		end

		local v12 = ConvertValue.parseSuffix(Text)

		if not (v12 and v12 > 0) then
			return
		end

		v1.Text = tostring(ConvertValue.suffixformat(v12))
	end)
	Set.MouseButton1Click:Connect(setStrength)
	Max.MouseButton1Click:Connect(function() --[[ Line: 171 | Upvalues: Players (ref), v1 (copy), notifications (ref) ]]
		Players.LocalPlayer:SetAttribute("CustomThrowPowerLimit", nil)
		v1.Text = ""
		notifications:Send((("Using %* throw power"):format((notifications.ColorText("MAX", Color3.fromRGB(251, 255, 0))))))
	end)
end

return t