-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ContextActionService = game:GetService("ContextActionService")
local GuiService = game:GetService("GuiService")
local MarketplaceService = game:GetService("MarketplaceService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local FishConfig = require(ReplicatedStorage.shared.config.FishConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local MonetizationConfig = require(ReplicatedStorage.shared.config.MonetizationConfig)
local RebirthUnlocksConfig = require(ReplicatedStorage.shared.config.RebirthUnlocksConfig)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local WeatherMachine = require(ReplicatedStorage.shared.UECS.Components.WeatherMachine)
local WeatherRegistry = require(ReplicatedStorage.shared.weather.WeatherRegistry)
local bindToButtonPress = require(ReplicatedStorage.shared.util.bindToButtonPress)
local fetchRobuxPriceInto = require(ReplicatedStorage.shared.util.fetchRobuxPriceInto)
local notifications = require(ReplicatedStorage.shared.module.notifications)
local rarityConfig = require(ReplicatedStorage.shared.config.rarityConfig)
local t = {}
local t2 = {
	UECS = nil,
	Priority = 30
}

for v1, v2 in MonetizationConfig.DevProducts do
	if v2.EventName then
		t[v2.EventName] = v2.ProductId
	end
end

local v3 = Color3.fromRGB(126, 255, 143)
local v4 = Color3.fromRGB(180, 180, 180)
local v5 = TweenInfo.new(0.25, Enum.EasingStyle.Back, Enum.EasingDirection.In)
local v6 = TweenInfo.new(0.25, Enum.EasingStyle.Back, Enum.EasingDirection.Out)

local function formatDuration(p1) --[[ formatDuration | Line: 42 ]]
	return string.format("+%d:%02d m", math.floor(p1 / 60), p1 % 60)
end

local t3 = {}

for v7, v8 in FishConfig do
	local id = v8.Rarity.id

	if not t3[id] then
		t3[id] = {}
	end

	table.insert(t3[id], v8)
end

local function countOwnedByRarity(p1, p2) --[[ countOwnedByRarity | Line: 57 | Upvalues: FishConfig (copy) ]]
	local sum = 0

	for v1, v2 in p1 do
		if v2.Category == "Fish" then
			local v3 = FishConfig[v2.ConfigName]

			if v3 and v3.Rarity.id == p2 then
				sum = sum + (v2.Stack or 1)
			end
		end
	end

	return sum
end

function t2.Init(p1) --[[ Init | Line: 71 | Upvalues: Players (copy), WeatherMachine (copy), RebirthUnlocksConfig (copy), ClientPlayerData (copy), notifications (copy), bindToButtonPress (copy), Remotes (copy), t (copy), MarketplaceService (copy), UserInputService (copy), GuiService (copy), ContextActionService (copy), WeatherRegistry (copy), v3 (copy), v4 (copy), TweenService (copy), v5 (copy), v6 (copy), fetchRobuxPriceInto (copy), rarityConfig (copy), countOwnedByRarity (copy), t3 (copy) ]]
	local LocalPlayer = Players.LocalPlayer
	local MainUI = LocalPlayer.PlayerGui:WaitForChild("MainUI")
	local WeatherMachine2 = MainUI:WaitForChild("WeatherMachine")
	local t2 = {}
	local v1 = nil
	local t4 = {}
	local v2 = false
	local v32 = WeatherMachine2:WaitForChild("Content")
	local Left = v32:WaitForChild("Left")
	local Right = v32:WaitForChild("Right")
	local Frame = Left:WaitForChild("Frame")
	local Info = Right:WaitForChild("Info")
	local Requirements = Right:WaitForChild("Requirements")

	WeatherMachine2.Visible = false

	local v42 = WeatherMachine.Add(WeatherMachine2)

	v42.Visible.OnChange:Connect(function(p12, p2) --[[ Line: 92 | Upvalues: RebirthUnlocksConfig (ref), ClientPlayerData (ref), notifications (ref), v42 (copy), WeatherMachine2 (copy), MainUI (copy), bindToButtonPress (ref), p1 (copy), v1 (ref), v2 (ref), Remotes (ref), t (ref), MarketplaceService (ref), LocalPlayer (copy), UserInputService (ref), GuiService (ref), Left (copy), ContextActionService (ref) ]]
		local v12 = RebirthUnlocksConfig.getByUIComponentName("WeatherMachine")

		if p12 and (v12 and (ClientPlayerData.serverProfile:getState().rebirthLevel or 0) < v12.RebirthRequired) then
			notifications:Send(v12.LockedText)
			v42.Visible:Set(false)

			return
		end

		WeatherMachine2.Visible = p12

		local HUD = MainUI:FindFirstChild("HUD")

		if HUD then
			HUD.Visible = not p12
		end

		if p12 == p2 then
			return
		end

		if p12 then
			bindToButtonPress("MachineCloseAction", Enum.KeyCode.ButtonB, function() --[[ Line: 114 | Upvalues: p1 (ref) ]]
				p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
			end)
			bindToButtonPress("SummonWeatherAction", Enum.KeyCode.ButtonX, function() --[[ Line: 119 | Upvalues: v1 (ref), v2 (ref), Remotes (ref) ]]
				if v1 and v2 then
					Remotes.RequestSummonWeather:Fire(v1.Name)
				end
			end)
			bindToButtonPress("SummonPremiumWeatherAction", Enum.KeyCode.ButtonY, function() --[[ Line: 126 | Upvalues: v1 (ref), t (ref), MarketplaceService (ref), LocalPlayer (ref) ]]
				if not v1 then
					return
				end

				local v12 = t[v1.Name]

				if not v12 then
					return
				end

				MarketplaceService:PromptProductPurchase(LocalPlayer, v12)
			end)

			if UserInputService.PreferredInput == Enum.PreferredInput.Gamepad then
				GuiService:Select(Left)
			end
		else
			ContextActionService:UnbindAction("SummonWeatherAction")
			ContextActionService:UnbindAction("SummonPremiumWeatherAction")
			ContextActionService:UnbindAction("MachineCloseAction")
			GuiService.SelectedObject = nil
		end
	end)

	local function onSelectionChange() --[[ onSelectionChange | Line: 148 | Upvalues: UserInputService (ref), GuiService (ref), v42 (copy), WeatherMachine2 (copy), Left (copy) ]]
		if UserInputService.PreferredInput ~= Enum.PreferredInput.Gamepad then
			return
		end

		local SelectedObject = GuiService.SelectedObject

		if not v42.Visible:Get() or SelectedObject and SelectedObject:IsDescendantOf(WeatherMachine2) then
			return
		end

		GuiService:Select(Left)
	end

	GuiService:GetPropertyChangedSignal("SelectedObject"):Connect(onSelectionChange)
	WeatherMachine2:WaitForChild("TopBar"):WaitForChild("CloseButton").MouseButton1Down:Connect(function() --[[ Line: 162 | Upvalues: p1 (copy) ]]
		p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
	end)

	local WeatherName = Info:WaitForChild("WeatherName")
	local WeatherDescription = Info:WaitForChild("WeatherDescription")
	local RequiredFish = Requirements:WaitForChild("RequiredFish")
	local SummonButton = Requirements:WaitForChild("SummonButton")
	local BuyButtonRobux = Requirements:WaitForChild("BuyButtonRobux")
	local v52 = nil
	local t5 = {}

	for v62, v7 in Frame:GetChildren() do
		if v7:IsA("ImageButton") and v7.Name == "WeatherButton" then
			v52 = v7

			break
		end
	end

	if not v52 then
		return
	end

	v52.Visible = false

	local FishTemplateNotAcquired = RequiredFish:FindFirstChild("FishTemplateNotAcquired", true)

	if not FishTemplateNotAcquired then
		return
	end

	FishTemplateNotAcquired.Visible = false

	for v8, v9 in Frame:GetChildren() do
		if v9:IsA("ImageButton") and v9 ~= v52 then
			v9:Destroy()
		end
	end

	for v10, v11 in RequiredFish:GetChildren() do
		if v11:IsA("ImageLabel") and v11 ~= FishTemplateNotAcquired then
			v11:Destroy()
		end
	end

	local count = 0

	for v12, v13 in WeatherRegistry.Modules do
		local Config = v13.Config

		if Config.WeatherMachineRequirements then
			count = count + 1

			local v14 = v52:Clone()

			v14.LayoutOrder = count
			v14.Visible = true

			local v15 = v14:FindFirstChild("Content")

			if v15 then
				local BackGround = v15:FindFirstChild("BackGround")

				if BackGround and Config.WeatherMachineBackground then
					BackGround.Image = Config.WeatherMachineBackground
				end

				local WeatherName2 = v15:FindFirstChild("WeatherName")

				if WeatherName2 then
					WeatherName2.Text = Config.DisplayName
				end

				local Duration = v15:FindFirstChild("Duration")

				if Duration then
					Duration.Text = string.format("+%d:%02d m", 10, 0)
				end
			end

			local Frame2 = v14:FindFirstChild("Frame")

			if Frame2 and Config.WeatherMachineColor then
				Frame2.BackgroundColor3 = Config.WeatherMachineColor
			end

			v14.Parent = Frame
			table.insert(t2, {
				config = Config,
				button = v14
			})
		end
	end

	local function getInventory() --[[ getInventory | Line: 250 | Upvalues: ClientPlayerData (ref) ]]
		return ClientPlayerData.serverProfile:getState().inventory or {}
	end

	local function updateSummonButton() --[[ updateSummonButton | Line: 255 | Upvalues: SummonButton (copy), v2 (ref), v3 (ref), v4 (ref) ]]
		SummonButton.BackgroundColor3 = if v2 then v3 else v4
		SummonButton.AutoButtonColor = v2
	end

	local function stopCycleAnimations() --[[ stopCycleAnimations | Line: 260 | Upvalues: t5 (copy) ]]
		for v1, v2 in t5 do
			v2:Disconnect()
		end

		table.clear(t5)
	end

	local function startIconCycle(p1, p2) --[[ startIconCycle | Line: 267 | Upvalues: TweenService (ref), v5 (ref), v6 (ref), t5 (copy) ]]
		if not (#p2 <= 1) then
			local v1 = 1
			local v2 = true

			local function cycleNext() --[[ cycleNext | Line: 275 | Upvalues: v2 (ref), p1 (copy), TweenService (ref), v5 (ref), v1 (ref), p2 (copy), v6 (ref) ]]
				if v2 and p1.Parent then
					local v12 = TweenService:Create(p1, v5, {
						Size = UDim2.fromScale(0, 0)
					})

					v12:Play()
					v12.Completed:Once(function() --[[ Line: 282 | Upvalues: v2 (ref), p1 (ref), v1 (ref), p2 (ref), TweenService (ref), v6 (ref) ]]
						if v2 and p1.Parent then
							v1 = v1 % #p2 + 1
							p1.Image = p2[v1].Image
							TweenService:Create(p1, v6, {
								Size = UDim2.fromScale(1, 1)
							}):Play()
						end
					end)
				end
			end

			local v3 = 0
			local v4 = nil

			v4 = game:GetService("RunService").Heartbeat:Connect(function(p12) --[[ Line: 295 | Upvalues: p1 (copy), v4 (ref), v2 (ref), v3 (ref), cycleNext (copy) ]]
				if not p1.Parent then
					v4:Disconnect()
					v2 = false

					return
				end

				v3 = v3 + p12

				if not (v3 >= 3) then
					return
				end

				v3 = 0
				cycleNext()
			end)

			local v62 = v4

			table.insert(t5, v62)
		end
	end

	local function selectWeather(p1) --[[ selectWeather | Line: 311 | Upvalues: v1 (ref), WeatherName (copy), WeatherDescription (copy), t (ref), BuyButtonRobux (copy), fetchRobuxPriceInto (ref), t5 (copy), t4 (copy), v2 (ref), SummonButton (copy), v3 (ref), v4 (ref), ClientPlayerData (ref), rarityConfig (ref), countOwnedByRarity (ref), FishTemplateNotAcquired (copy), t3 (ref), startIconCycle (copy), RequiredFish (copy) ]]
		v1 = p1
		WeatherName.Text = p1.DisplayName
		WeatherDescription.Text = p1.Desc

		local v12 = t[p1.Name]
		local v22 = BuyButtonRobux:FindFirstChild("Content", true) and BuyButtonRobux.Content:WaitForChild("Frame"):FindFirstChild("TextLabel")

		if v22 and v12 then
			v22.Text = "..."
			fetchRobuxPriceInto(v22, v12)
		end

		for v32, v42 in t5 do
			v42:Disconnect()
		end

		table.clear(t5)

		for v5, v6 in t4 do
			v6:Destroy()
		end

		table.clear(t4)

		local WeatherMachineRequirements = p1.WeatherMachineRequirements

		if WeatherMachineRequirements then
			local v7 = ClientPlayerData.serverProfile:getState().inventory or {}
			local v8 = true

			for v9, v10 in WeatherMachineRequirements do
				local Rarity = v10.Rarity
				local Amount = v10.Amount
				local v11 = rarityConfig[Rarity]
				local v122 = countOwnedByRarity(v7, Rarity)
				local v13 = Amount <= v122

				if not v13 then
					v8 = false
				end

				local v14 = FishTemplateNotAcquired:Clone()

				v14.LayoutOrder = v9
				v14.Visible = true

				local Frame = v14:FindFirstChild("Frame")

				if Frame and v11 then
					Frame.BackgroundColor3 = v11.rarityColor

					local UIGradient = Frame:FindFirstChild("UIGradient")

					if UIGradient then
						UIGradient.Color = ColorSequence.new(v11.rarityColor, Color3.fromRGB(255, 255, 255))
					end
				end

				local Icon = v14:FindFirstChild("Icon")
				local DisplayName = v14:FindFirstChild("DisplayName")
				local Earnings = v14:FindFirstChild("Earnings")

				if DisplayName then
					DisplayName.Text = ("%*/%*"):format(math.min(v122, Amount), Amount)
					DisplayName.TextColor3 = if v13 then Color3.fromRGB(80, 220, 80) else Color3.fromRGB(220, 50, 50)
				end

				if Earnings then
					Earnings.Text = if v11 then v11.displayName else Rarity

					if v11 then
						Earnings.TextColor3 = v11.rarityColor
					end
				end

				local v17 = t3[Rarity] or {}

				if Icon then
					if v13 then
						Icon.ImageColor3 = Color3.new(255/255, 255/255, 255/255)
					else
						Icon.ImageColor3 = Color3.fromRGB(0, 0, 0)
					end

					if #v17 > 0 then
						Icon.Image = v17[1].Image
						startIconCycle(Icon, v17)
					end
				end

				v14.Parent = RequiredFish
				table.insert(t4, v14)
			end

			v2 = v8
			SummonButton.BackgroundColor3 = if v8 then v3 else v4
		else
			v2 = false
			SummonButton.BackgroundColor3 = if v2 then v3 else v4
		end

		SummonButton.AutoButtonColor = v2
	end

	for v16, v17 in t2 do
		v17.button.MouseButton1Down:Connect(function() --[[ Line: 406 | Upvalues: selectWeather (copy), v17 (copy) ]]
			selectWeather(v17.config)
		end)
	end

	if #t2 > 0 then
		selectWeather(t2[1].config)
	end

	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 415 ]]
		return p1.inventory
	end, function() --[[ Line: 417 | Upvalues: v1 (ref), selectWeather (copy) ]]
		if not v1 then
			return
		end

		selectWeather(v1)
	end)
	SummonButton.MouseButton1Down:Connect(function() --[[ Line: 423 | Upvalues: v1 (ref), v2 (ref), Remotes (ref) ]]
		if v1 and v2 then
			Remotes.RequestSummonWeather:Fire(v1.Name)
		end
	end)
	BuyButtonRobux.MouseButton1Down:Connect(function() --[[ Line: 430 | Upvalues: v1 (ref), t (ref), MarketplaceService (ref), LocalPlayer (copy) ]]
		if not v1 then
			return
		end

		local v12 = t[v1.Name]

		if not v12 then
			return
		end

		MarketplaceService:PromptProductPurchase(LocalPlayer, v12)
	end)
end

return t2