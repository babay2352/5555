-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local MarketplaceService = game:GetService("MarketplaceService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")
local CashDisplay = require(ReplicatedStorage.shared.module.CashDisplay)
local FishConfig = require(ReplicatedStorage.shared.config.FishConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local LimitedShopConfig = require(ReplicatedStorage.shared.config.LimitedShopConfig)
local buildFishModel = require(ReplicatedStorage.shared.util.buildFishModel)
local computeWorldAABB = require(ReplicatedStorage.shared.util.computeWorldAABB)
local fetchRobuxPriceInto = require(ReplicatedStorage.shared.util.fetchRobuxPriceInto)
local t = {
	UECS = nil
}
local t2 = {}

local function offerEnded() --[[ offerEnded | Line: 76 | Upvalues: LimitedShopConfig (copy) ]]
	return if LimitedShopConfig.EndTimestamp > 0 then os.time() > LimitedShopConfig.EndTimestamp else false
end

local function applyBonus(p1, p2) --[[ applyBonus | Line: 82 | Upvalues: CashDisplay (copy) ]]
	if p2.EarningsPercent then
		CashDisplay.setPlainText(p1, (("%*%%"):format((math.floor(p2.EarningsPercent * 100 + 0.5)))))
	else
		CashDisplay.applyToLabel(p1, p2.Earnings or 0, {
			Suffix = "/s",
			Compact = true
		})
	end
end

local function setupStand(p1, p2, p3, p4) --[[ setupStand | Line: 93 | Upvalues: FishConfig (copy), LimitedShopConfig (copy), buildFishModel (copy), computeWorldAABB (copy), CollectionService (copy), ReplicatedStorage (copy), applyBonus (copy), fetchRobuxPriceInto (copy), t2 (copy), MarketplaceService (copy) ]]
	local v1 = FishConfig[p4.FishConfigName]

	if not v1 then
		return
	end

	local v2 = LimitedShopConfig.stockAttribute(p4.Id)
	local v3 = p3.Position.Y + p3.Size.Y * 0.5
	local v4 = Vector3.new(p3.Position.X, v3 + 1.5, p3.Position.Z)
	local v5 = buildFishModel.clone(p4.FishConfigName, 1, nil)

	if v5 and v5.PrimaryPart then
		local PrimaryPart = v5.PrimaryPart

		PrimaryPart.Anchored = true

		local v6 = p4.ShowcaseScale or 1

		if v6 ~= 1 then
			v5:ScaleTo(v5:GetScale() * v6)
		end

		local LookVector = p3.CFrame.LookVector
		local v7 = Vector3.new(LookVector.X, 0, LookVector.Z)

		if v7.Magnitude < 0.0001 then
			v7 = Vector3.new(0, 0, 1)
		end

		v5.Parent = p2

		local v8 = CFrame.lookAt(p3.Position, p3.Position + v7.Unit)

		PrimaryPart.CFrame = v8 * CFrame.Angles(0, math.rad(p4.YawDeg or 180), 0)

		local v10, v11 = computeWorldAABB(v5)
		local v13 = Vector3.new(p3.Position.X, v3 + 1.5 + v11.Y * 0.5, p3.Position.Z)

		PrimaryPart.CFrame = PrimaryPart.CFrame + (v13 - v10)
		v5:SetAttribute("IdleAnchor", PrimaryPart.CFrame)
		CollectionService:AddTag(v5, "IdleFishFloat")

		if v1.Anim then
			v5:SetAttribute("Anim", v1.Anim)
			CollectionService:AddTag(v5, "AnimAnimationController")
		end

		v4 = v13 + Vector3.new(0, v11.Y * 0.5, 0)
	else
		warn((("[LimitedShop] buildFishModel returned nil for \"%*\" \226\128\148 billboard hangs over Main"):format(p4.FishConfigName)))
	end

	local BGUIAnchor = Instance.new("Part")

	BGUIAnchor.Name = "BGUIAnchor"
	BGUIAnchor.Size = Vector3.new(1, 1, 1)
	BGUIAnchor.Transparency = 1
	BGUIAnchor.Anchored = true
	BGUIAnchor.CanCollide = false
	BGUIAnchor.CanQuery = false
	BGUIAnchor.CanTouch = false
	BGUIAnchor.CastShadow = false
	BGUIAnchor.Position = v4
	BGUIAnchor.Parent = if v5 and v5.PrimaryPart then v5 else p2

	local v16 = ReplicatedStorage.shared.model.LimitedFishBGUI:Clone()

	v16.Parent = BGUIAnchor
	v16.Adornee = BGUIAnchor

	local Frame = v16:FindFirstChild("Frame")

	if not Frame then
		warn("[LimitedShop] LimitedFishBGUI template has no Frame")

		return
	end

	local NameLabel = Frame:FindFirstChild("NameLabel")
	local PriceLabel = Frame:FindFirstChild("PriceLabel")
	local StockLabel = Frame:FindFirstChild("StockLabel")
	local BonusText = Frame:FindFirstChild("BonusText")
	local v17 = if BonusText then BonusText:FindFirstChild("TextLabel") else BonusText

	if NameLabel then
		NameLabel.Text = v1.DisplayName

		local UIGradient = NameLabel:FindFirstChild("UIGradient")

		if UIGradient and v1.Rarity then
			UIGradient.Color = ColorSequence.new(v1.Rarity.rarityColor)
			NameLabel:SetAttribute("RarityId", v1.Rarity.id)
			CollectionService:AddTag(NameLabel, "AnimatedRarity")
		end
	end

	if v17 then
		applyBonus(v17, v1)
	end

	if PriceLabel and p4.ProductId > 0 then
		PriceLabel.Text = "..."
		fetchRobuxPriceInto(PriceLabel, p4.ProductId)
	elseif PriceLabel then
		PriceLabel.Text = "Soon"
	end

	v16.Enabled = true

	local BuyLimitedFish = Instance.new("ProximityPrompt")

	BuyLimitedFish.Name = "BuyLimitedFish"
	BuyLimitedFish.Style = Enum.ProximityPromptStyle.Custom
	BuyLimitedFish.ActionText = "Buy"
	BuyLimitedFish.ObjectText = v1.DisplayName
	BuyLimitedFish.HoldDuration = 0.3
	BuyLimitedFish.MaxActivationDistance = 12
	BuyLimitedFish.RequiresLineOfSight = false
	BuyLimitedFish.Parent = p3

	local function refresh() --[[ refresh | Line: 240 | Upvalues: p1 (copy), v2 (copy), StockLabel (copy), p4 (copy), PriceLabel (copy), LimitedShopConfig (ref), BuyLimitedFish (copy) ]]
		local v1 = if p1 then p1:GetAttribute(v2) else nil
		local v22 = if typeof(v1) == "number" then if v1 <= 0 then true else false else false

		if StockLabel and typeof(v1) == "number" then
			if v22 then
				StockLabel.Text = "SOLD OUT"
			else
				StockLabel.Text = ("%*/%* left"):format(v1, p4.MaxStock)
			end
		elseif StockLabel then
			StockLabel.Text = ""
		end

		if PriceLabel and (if LimitedShopConfig.EndTimestamp > 0 then os.time() > LimitedShopConfig.EndTimestamp else false) then
			PriceLabel.Text = "Ended"
		end

		local v5 = not v22

		if v5 then
			v5 = not (if LimitedShopConfig.EndTimestamp > 0 then os.time() > LimitedShopConfig.EndTimestamp else false) and (if p4.ProductId > 0 then true else false)
		end

		BuyLimitedFish.Enabled = v5
	end

	refresh()

	local t = { BGUIAnchor, BuyLimitedFish }

	if v5 then
		table.insert(t, v5)
	end

	t2[p3] = {
		refresh = refresh,
		connection = if p1 then p1:GetAttributeChangedSignal(v2):Connect(refresh) else nil,
		created = t
	}
	BuyLimitedFish.Triggered:Connect(function(p12) --[[ Line: 275 | Upvalues: p1 (copy), v2 (copy), LimitedShopConfig (ref), p4 (copy), MarketplaceService (ref) ]]
		local v1 = if p1 then p1:GetAttribute(v2) else nil

		if typeof(v1) == "number" and v1 <= 0 then
			return
		end

		if not ((if LimitedShopConfig.EndTimestamp > 0 then os.time() > LimitedShopConfig.EndTimestamp else false) or p4.ProductId <= 0) then
			MarketplaceService:PromptProductPurchase(p12, p4.ProductId)
		end
	end)
end

local function resolveMain(p1) --[[ resolveMain | Line: 289 ]]
	if p1:IsA("BasePart") then
		return p1
	end

	local Main = p1:FindFirstChild("Main")

	if Main and Main:IsA("BasePart") then
		return Main
	end

	return nil
end

local function addStand(p1, p2) --[[ addStand | Line: 300 | Upvalues: t2 (copy), Workspace (copy), setupStand (copy) ]]
	local v1

	if p1:IsA("BasePart") then
		v1 = p1
	else
		local Main = p1:FindFirstChild("Main")

		v1 = if Main and Main:IsA("BasePart") then Main else nil
	end

	if not v1 then
		warn((("[LimitedShop] \"%*\" tag on %* \226\128\148 needs a BasePart or a Model with a Main"):format(p2.Id, (p1:GetFullName()))))

		return
	end

	if t2[v1] then
		return
	end

	setupStand(v1:FindFirstAncestor("LimitedFishStands") or Workspace:FindFirstChild("LimitedFishStands"), v1.Parent or v1, v1, p2)
end

local function removeStand(p1) --[[ removeStand | Line: 316 | Upvalues: t2 (copy) ]]
	local v1

	if p1:IsA("BasePart") then
		v1 = p1
	else
		local Main = p1:FindFirstChild("Main")

		v1 = if Main and Main:IsA("BasePart") then Main else nil
	end

	if not v1 then
		return
	end

	local v2 = t2[v1]

	if not v2 then
		return
	end

	if v2.connection then
		v2.connection:Disconnect()
	end

	t2[v1] = nil

	for v3, v4 in v2.created do
		v4:Destroy()
	end
end

function t.Init(p1) --[[ Init | Line: 336 | Upvalues: Players (copy), LimitedShopConfig (copy), CollectionService (copy), addStand (copy), removeStand (copy), t2 (copy) ]]
	local LocalPlayer = Players.LocalPlayer

	for v1, v2 in LimitedShopConfig.Items do
		for v3, v4 in CollectionService:GetTagged(v1) do
			addStand(v4, v2)
		end

		CollectionService:GetInstanceAddedSignal(v1):Connect(function(p1) --[[ Line: 346 | Upvalues: addStand (ref), v2 (copy) ]]
			addStand(p1, v2)
		end)
		CollectionService:GetInstanceRemovedSignal(v1):Connect(removeStand)
	end

	if not (LimitedShopConfig.EndTimestamp > 0) then
		return
	end

	local v5 = LimitedShopConfig.EndTimestamp - os.time()

	if not (v5 > 0) then
		return
	end

	task.delay(v5, function() --[[ Line: 356 | Upvalues: t2 (ref) ]]
		for v1, v2 in t2 do
			v2.refresh()
		end
	end)
end

return t