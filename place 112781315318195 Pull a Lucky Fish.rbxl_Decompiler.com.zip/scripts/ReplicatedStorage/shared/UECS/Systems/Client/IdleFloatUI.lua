-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local StarterGui = game:GetService("StarterGui")
local TweenService = game:GetService("TweenService")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Maid = require(ReplicatedStorage.shared.class.Maid)
local getGuiObjectVisibilityDepedencies = require(ReplicatedStorage.shared.util.getGuiObjectVisibilityDepedencies)
local isObjectRenderable = require(ReplicatedStorage.shared.util.isObjectRenderable)
local Sine = Enum.EasingStyle.Sine
local t = {
	UECS = nil
}
local t2 = {}

local function startFor(p1) --[[ startFor | Line: 28 | Upvalues: t2 (copy), StarterGui (copy), Sine (copy), TweenService (copy), Maid (copy), isObjectRenderable (copy), getGuiObjectVisibilityDepedencies (copy) ]]
	if not p1:IsA("GuiObject") or (t2[p1] or p1:IsDescendantOf(StarterGui)) then
		return
	end

	local v1 = p1:GetAttribute("IdleFloatAmplitude") or 6
	local v2 = p1:GetAttribute("IdleFloatDuration") or 1.5
	local v3 = p1:GetAttribute("IdleFloatEasing")
	local v4 = Sine

	if typeof(v3) == "string" then
		local ok, result = pcall(function() --[[ Line: 39 | Upvalues: v3 (copy) ]]
			return Enum.EasingStyle[v3]
		end)

		if ok and result then
			v4 = result
		end
	end

	local Position = p1.Position
	local v5 = math.random() * v2

	p1.Position = UDim2.new(Position.X.Scale, Position.X.Offset, Position.Y.Scale, Position.Y.Offset - v1)

	local v6 = TweenService:Create(p1, TweenInfo.new(v2 / 2, v4, Enum.EasingDirection.InOut, -1, true), {
		Position = UDim2.new(Position.X.Scale, Position.X.Offset, Position.Y.Scale, Position.Y.Offset + v1)
	})

	t2[p1] = {
		tween = v6,
		origin = Position
	}

	local v7 = Maid.new()

	v6.Completed:Once(function() --[[ Line: 64 | Upvalues: v7 (copy) ]]
		v7:Destroy()
	end)

	local function onVisibleStateChange() --[[ onVisibleStateChange | Line: 68 | Upvalues: isObjectRenderable (ref), p1 (copy), v6 (copy) ]]
		if isObjectRenderable(p1) then
			v6:Play()
		else
			v6:Pause()
		end
	end

	task.delay(v5, function() --[[ Line: 76 | Upvalues: t2 (ref), p1 (copy), v6 (copy), getGuiObjectVisibilityDepedencies (ref), v7 (copy), onVisibleStateChange (copy), isObjectRenderable (ref) ]]
		if t2[p1] then
			v6:Play()
		end

		for v1, v2 in getGuiObjectVisibilityDepedencies(p1) do
			if v2:IsA("GuiObject") then
				v7:GiveTask(v2:GetPropertyChangedSignal("Visible"):Connect(onVisibleStateChange))

				continue
			end

			if v2:IsA("LayerCollector") then
				v7:GiveTask(v2:GetPropertyChangedSignal("Enabled"):Connect(onVisibleStateChange))
			end
		end

		if isObjectRenderable(p1) then
			v6:Play()
		else
			v6:Pause()
		end
	end)
end

local function stopFor(p1) --[[ stopFor | Line: 93 | Upvalues: t2 (copy) ]]
	if not p1:IsA("GuiObject") then
		return
	end

	local v1 = t2[p1]

	if not v1 then
		return
	end

	v1.tween:Cancel()
	p1.Position = v1.origin
	t2[p1] = nil
end

function t.Init(p1) --[[ Init | Line: 105 | Upvalues: CollectionService (copy), startFor (copy), stopFor (copy) ]]
	for v1, v2 in CollectionService:GetTagged("IdleFloat") do
		startFor(v2)
	end

	CollectionService:GetInstanceAddedSignal("IdleFloat"):Connect(startFor)
	CollectionService:GetInstanceRemovedSignal("IdleFloat"):Connect(stopFor)
end

return t