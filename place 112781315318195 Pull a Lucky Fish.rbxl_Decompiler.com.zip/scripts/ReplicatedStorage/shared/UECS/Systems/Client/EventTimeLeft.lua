-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local EventConfig = require(ReplicatedStorage.shared.config.EventConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local TimeLeft = EventConfig.Tags.TimeLeft
local t = {
	UECS = nil
}
local t2 = {}
local v1 = nil

local function formatCountdown(p1) --[[ formatCountdown | Line: 42 ]]
	if p1 <= 0 then
		return "Event ended!"
	end

	local v1 = math.floor(p1 / 86400)
	local v2 = math.floor(p1 % 86400 / 3600)
	local v3 = math.floor(p1 % 3600 / 60)
	local v4 = math.floor(p1 % 60)

	if v1 > 0 then
		return string.format("Ends in: %dd %dh %02dm %02ds", v1, v2, v3, v4)
	end

	if v2 > 0 then
		return string.format("Ends in: %dh %02dm %02ds", v2, v3, v4)
	end

	return string.format("Ends in: %02dm %02ds", v3, v4)
end

local function startFor(p1) --[[ startFor | Line: 61 | Upvalues: t2 (copy), v1 (ref), EventConfig (copy), formatCountdown (copy), RunService (copy) ]]
	if t2[p1] then
		return
	end

	if not p1:IsA("BasePart") then
		return
	end

	if not v1 then
		return
	end

	local EndTimestamp = EventConfig.Event.EndTimestamp
	local v12 = v1:Clone()

	v12.Adornee = p1
	v12.Parent = p1

	local Restock = v12:FindFirstChild("Restock")

	if Restock and Restock:IsA("TextLabel") then
		Restock.Text = formatCountdown(EndTimestamp - workspace:GetServerTimeNow())

		local v2 = 0

		t2[p1] = {
			billboard = v12,
			connection = RunService.RenderStepped:Connect(function(p1) --[[ Line: 93 | Upvalues: v2 (ref), EndTimestamp (copy), Restock (copy), formatCountdown (ref) ]]
				debug.profilebegin("UECS/EventTimeLeft.RenderStepped")
				v2 = v2 + p1

				if not (v2 < 1) then
					v2 = 0
					Restock.Text = formatCountdown(EndTimestamp - workspace:GetServerTimeNow())
				end

				debug.profileend()
			end),
			destroying = p1.Destroying:Connect(function() --[[ Line: 108 | Upvalues: t2 (ref), p1 (copy) ]]
				local v1 = t2[p1]

				if not v1 then
					return
				end

				v1.connection:Disconnect()
				v1.billboard:Destroy()
				t2[p1] = nil
			end)
		}
	else
		warn((("[EventTimeLeft] No Restock TextLabel found in %* template"):format(EventConfig.Ui.TimerTemplateName)))
		v12:Destroy()
	end
end

local function stopFor(p1) --[[ stopFor | Line: 124 | Upvalues: t2 (copy) ]]
	local v1 = t2[p1]

	if not v1 then
		return
	end

	v1.connection:Disconnect()

	if v1.destroying then
		v1.destroying:Disconnect()
	end

	v1.billboard:Destroy()
	t2[p1] = nil
end

function t.Init(p1) --[[ Init | Line: 137 | Upvalues: EventConfig (copy), ReplicatedStorage (copy), v1 (ref), CollectionService (copy), TimeLeft (copy), startFor (copy), stopFor (copy) ]]
	if not EventConfig.Event.TimerEnabled then
		return
	end

	local v12 = ReplicatedStorage:FindFirstChild("shared")
	local v2 = if v12 then v12:FindFirstChild("model") else v12
	local v3 = if v2 then v2:FindFirstChild(EventConfig.Ui.TimerTemplateName) else v2

	if not (v3 and v3:IsA("BillboardGui")) then
		warn((("[EventTimeLeft] %* template not found in ReplicatedStorage.shared.model"):format(EventConfig.Ui.TimerTemplateName)))

		return
	end

	v1 = v3

	for v4, v5 in CollectionService:GetTagged(TimeLeft) do
		startFor(v5)
	end

	CollectionService:GetInstanceAddedSignal(TimeLeft):Connect(startFor)
	CollectionService:GetInstanceRemovedSignal(TimeLeft):Connect(stopFor)
end

return t