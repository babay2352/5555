-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local t = {
	TemplateName = "IndicatorDotBgui",
	IconName = "IndicatorDot",
	HideDistance = 7,
	FullSizeDistance = 25,
	Indicators = {
		{
			PartName = "OpenDecorationsShop"
		},
		{
			PartName = "AuctionHousePart",
			Image = "rbxassetid://132321049409082"
		}
	}
}

return {
	UECS = nil,
	Init = function(p1) --[[ Init | Line: 39 | Upvalues: Players (copy), ReplicatedStorage (copy), t (copy), RunService (copy) ]]
		local LocalPlayer = Players.LocalPlayer
		local PlayerGui = LocalPlayer:WaitForChild("PlayerGui")
		local v1 = ReplicatedStorage:WaitForChild("shared"):WaitForChild("model"):WaitForChild(t.TemplateName, 10)

		if not (v1 and v1:IsA("BillboardGui")) then
			warn((("[WalkInIndicator] shared.model.%* (BillboardGui) not found \226\128\148 indicators disabled"):format(t.TemplateName)))

			return
		end

		local t2 = {}

		for v2, v3 in t.Indicators do
			local v4 = v1:Clone()

			v4.Name = ("%*_%*"):format(t.TemplateName, v3.PartName)
			v4.Enabled = false

			if v3.Image then
				local v5 = v4:FindFirstChild(t.IconName)

				if v5 and v5:IsA("ImageLabel") then
					v5.Image = v3.Image
				else
					warn((("[WalkInIndicator] %* (ImageLabel) missing in template \226\128\148 %* keeps the default icon"):format(t.IconName, v3.PartName)))
				end
			end

			v4.Parent = PlayerGui
			table.insert(t2, {
				part = nil,
				entry = v3,
				billboard = v4,
				fullSize = v4.Size
			})
		end

		local function scaledSize(p1, p2) --[[ scaledSize | Line: 77 ]]
			return UDim2.new(p1.X.Scale * p2, p1.X.Offset * p2, p1.Y.Scale * p2, p1.Y.Offset * p2)
		end

		local function resolvePart(p1) --[[ resolvePart | Line: 88 ]]
			local part = p1.part

			if part and part:IsDescendantOf(workspace) then
				return part
			end

			local v1 = workspace:FindFirstChild(p1.entry.PartName)

			p1.part = if v1 and v1:IsA("BasePart") then v1 else nil

			return p1.part
		end

		local function updateIndicator(p1, p2) --[[ updateIndicator | Line: 98 | Upvalues: t (ref) ]]
			local billboard = p1.billboard
			local part = p1.part
			local v1

			if part and part:IsDescendantOf(workspace) then
				v1 = part
			else
				local v2 = workspace:FindFirstChild(p1.entry.PartName)

				p1.part = if v2 and v2:IsA("BasePart") then v2 else nil
				v1 = p1.part
			end

			if v1 and p2 then
				if billboard.Adornee ~= v1 then
					billboard.Adornee = v1
				end

				local Magnitude = (p2.Position - v1.Position).Magnitude

				if Magnitude <= t.HideDistance then
					billboard.Enabled = false
				else
					local v5 = math.clamp((Magnitude - t.HideDistance) / (t.FullSizeDistance - t.HideDistance), 0, 1)
					local fullSize = p1.fullSize

					billboard.Size = UDim2.new(fullSize.X.Scale * v5, fullSize.X.Offset * v5, fullSize.Y.Scale * v5, fullSize.Y.Offset * v5)
					billboard.Enabled = true
				end
			else
				billboard.Enabled = false
			end
		end

		RunService.Heartbeat:Connect(function() --[[ Line: 126 | Upvalues: LocalPlayer (copy), t2 (copy), updateIndicator (copy) ]]
			debug.profilebegin("UECS/WalkInIndicator.Heartbeat")

			local Character = LocalPlayer.Character
			local v1 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character
			local v2 = if v1 and v1:IsA("BasePart") then v1 else nil

			for v3, v4 in t2 do
				updateIndicator(v4, v2)
			end

			debug.profileend()
		end)
	end
}