-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local t = {
	H = { "H", "#", "|-|", "}{" },
	A = { "A", "4", "@", "/\\" },
	C = { "C", "(", "[", "{" },
	K = { "K", "|<", "X", "|{" },
	E = {
		"E",
		"3",
		"&",
		utf8.char(8364)
	},
	D = { "D", "|)", "])", "0" }
}
local t2 = {
	utf8.char(821),
	utf8.char(822),
	utf8.char(823),
	utf8.char(824),
	utf8.char(820),
	utf8.char(781),
	utf8.char(782),
	utf8.char(784)
}
local t3 = {
	UECS = nil
}
local t4 = {}

local function findMainText(p1) --[[ findMainText | Line: 55 ]]
	local v1 = p1:FindFirstChild("Frame") or p1

	for v2, v3 in v1:GetChildren() do
		if v3:IsA("TextLabel") and v3.Name == "TextLabel" then
			return v3
		end
	end

	return v1:FindFirstChildWhichIsA("TextLabel")
end

local function buildGlitchRichText(p1, p2) --[[ buildGlitchRichText | Line: 70 | Upvalues: t (copy), t2 (copy) ]]
	local t3 = {}

	for i = 1, 6 do
		local v1 = ("HACKED"):sub(i, i)
		local v2 = t[v1]
		local v3 = if v2 and math.random() < 0.3 then v2[math.random(1, #v2)] else v1

		if math.random() < 0.4 then
			v3 = v3 .. t2[math.random(1, #t2)]
		end

		if math.random() < 0.25 then
			table.insert(t3, (("<font color=\"%*\">%*</font>"):format(p2, v3)))

			continue
		end

		table.insert(t3, (("<font color=\"%*\">%*</font>"):format(p1, v3)))
	end

	return table.concat(t3)
end

local function startFor(p1) --[[ startFor | Line: 97 | Upvalues: t4 (copy), findMainText (copy), buildGlitchRichText (copy), RunService (copy) ]]
	if not p1:IsA("BillboardGui") or t4[p1] then
		return
	end

	local v1 = findMainText(p1)

	if not v1 then
		warn("[GlitchBillboard] No TextLabel found in", p1:GetFullName())

		return
	end

	local v2 = p1:FindFirstChild("Frame") or p1
	local v3 = Color3.new(0/255, 0/255, 0/255)
	local v4 = v1:FindFirstChildWhichIsA("UIStroke")

	if v4 then
		v3 = v4.Color
	end

	local v5 = "#" .. v1.TextColor3:ToHex()
	local v6 = "#" .. v3:ToHex()

	v1.RichText = true
	v1.Text = buildGlitchRichText(v5, v6)

	local GlitchRed = v1:Clone()

	GlitchRed.Name = "GlitchRed"
	GlitchRed.RichText = false
	GlitchRed.Text = "HACKED"
	GlitchRed.TextColor3 = Color3.fromRGB(255, 0, 50)
	GlitchRed.TextTransparency = 0.55
	GlitchRed.ZIndex = v1.ZIndex - 1

	local v7 = GlitchRed:FindFirstChildWhichIsA("UIStroke")

	if v7 then
		v7:Destroy()
	end

	GlitchRed.Parent = v2

	local GlitchCyan = v1:Clone()

	GlitchCyan.Name = "GlitchCyan"
	GlitchCyan.RichText = false
	GlitchCyan.Text = "HACKED"
	GlitchCyan.TextColor3 = Color3.fromRGB(0, 200, 255)
	GlitchCyan.TextTransparency = 0.55
	GlitchCyan.ZIndex = v1.ZIndex - 1

	local v8 = GlitchCyan:FindFirstChildWhichIsA("UIStroke")
	local v9, v10

	if not v8 then
		GlitchCyan.Parent = v2
		v9 = 0
		v10 = workspace.CurrentCamera
		t4[p1] = {
			connection = RunService.RenderStepped:Connect(function(p13) --[[ Line: 159 | Upvalues: v10 (copy), p1 (copy), v9 (ref), v1 (copy), buildGlitchRichText (ref), v5 (copy), v6 (copy), GlitchRed (copy), GlitchCyan (copy) ]]
				debug.profilebegin("UECS/GlitchBillboard.Jitter")

				if (v10.CFrame.Position - p1.Parent.PrimaryPart.CFrame.Position).Magnitude > 400 then
					debug.profileend()

					return
				end

				v9 = v9 + p13

				if v9 < 0.04 then
					debug.profileend()

					return
				end

				v9 = 0
				v1.Text = buildGlitchRichText(v5, v6)

				local v12 = (math.random() - 0.5) * 2 * 0.03
				local v2 = (math.random() - 0.5) * 2 * 0.03

				GlitchRed.Position = UDim2.fromScale(-0.01 + v12, -0.06 + v2)
				GlitchCyan.Position = UDim2.fromScale(0.01 - v12, 0.06 - v2)

				if not (math.random() < 0.08) then
					debug.profileend()

					return
				end

				local v3 = (math.random() - 0.5) * 0.12
				local v4 = (math.random() - 0.5) * 0.15

				GlitchRed.Position = UDim2.fromScale(v3, v4)
				GlitchCyan.Position = UDim2.fromScale(-v3, -v4)
				debug.profileend()
			end),
			redGhost = GlitchRed,
			cyanGhost = GlitchCyan,
			destroying = p1.Destroying:Connect(function() --[[ Line: 193 | Upvalues: t4 (ref), p1 (copy) ]]
				local v1 = t4[p1]

				if not v1 then
					return
				end

				v1.connection:Disconnect()
				t4[p1] = nil
			end)
		}

		return
	end

	v8:Destroy()
	GlitchCyan.Parent = v2
	v9 = 0
	v10 = workspace.CurrentCamera
	t4[p1] = {
		connection = RunService.RenderStepped:Connect(function(p13) --[[ Line: 159 | Upvalues: v10 (copy), p1 (copy), v9 (ref), v1 (copy), buildGlitchRichText (ref), v5 (copy), v6 (copy), GlitchRed (copy), GlitchCyan (copy) ]]
			debug.profilebegin("UECS/GlitchBillboard.Jitter")

			if (v10.CFrame.Position - p1.Parent.PrimaryPart.CFrame.Position).Magnitude > 400 then
				debug.profileend()

				return
			end

			v9 = v9 + p13

			if v9 < 0.04 then
				debug.profileend()

				return
			end

			v9 = 0
			v1.Text = buildGlitchRichText(v5, v6)

			local v12 = (math.random() - 0.5) * 2 * 0.03
			local v2 = (math.random() - 0.5) * 2 * 0.03

			GlitchRed.Position = UDim2.fromScale(-0.01 + v12, -0.06 + v2)
			GlitchCyan.Position = UDim2.fromScale(0.01 - v12, 0.06 - v2)

			if not (math.random() < 0.08) then
				debug.profileend()

				return
			end

			local v3 = (math.random() - 0.5) * 0.12
			local v4 = (math.random() - 0.5) * 0.15

			GlitchRed.Position = UDim2.fromScale(v3, v4)
			GlitchCyan.Position = UDim2.fromScale(-v3, -v4)
			debug.profileend()
		end),
		redGhost = GlitchRed,
		cyanGhost = GlitchCyan,
		destroying = p1.Destroying:Connect(function() --[[ Line: 193 | Upvalues: t4 (ref), p1 (copy) ]]
			local v1 = t4[p1]

			if not v1 then
				return
			end

			v1.connection:Disconnect()
			t4[p1] = nil
		end)
	}
end

local function stopFor(p1) --[[ stopFor | Line: 209 | Upvalues: t4 (copy) ]]
	if not p1:IsA("BillboardGui") then
		return
	end

	local v1 = t4[p1]

	if not v1 then
		return
	end

	v1.connection:Disconnect()

	if v1.destroying then
		v1.destroying:Disconnect()
	end

	if v1.redGhost.Parent then
		v1.redGhost:Destroy()
	end

	if v1.cyanGhost.Parent then
		v1.cyanGhost:Destroy()
	end

	t4[p1] = nil
end

function t3.Init(p1) --[[ Init | Line: 229 | Upvalues: CollectionService (copy), startFor (copy), stopFor (copy) ]]
	for v1, v2 in CollectionService:GetTagged("GlitchBillboard") do
		startFor(v2)
	end

	CollectionService:GetInstanceAddedSignal("GlitchBillboard"):Connect(startFor)
	CollectionService:GetInstanceRemovedSignal("GlitchBillboard"):Connect(stopFor)
end

return t3