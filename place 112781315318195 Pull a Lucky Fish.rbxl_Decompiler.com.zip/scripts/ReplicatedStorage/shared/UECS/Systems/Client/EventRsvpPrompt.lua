-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local SocialService = game:GetService("SocialService")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local EventId = require(ReplicatedStorage.shared.config.TeaserConfig).EventId
local t = {
	UECS = nil
}
local t2 = {}

local function startFor(p1) --[[ startFor | Line: 29 | Upvalues: t2 (copy), SocialService (copy), EventId (copy), RunService (copy) ]]
	local v1 = if p1:IsA("ProximityPrompt") then p1 else p1:FindFirstChildWhichIsA("ProximityPrompt")

	if v1 and not t2[v1] then
		v1.Style = Enum.ProximityPromptStyle.Custom
		v1.ActionText = "Join"
		v1.ObjectText = "Event"
		v1.Enabled = false
		task.spawn(function() --[[ Line: 51 | Upvalues: SocialService (ref), EventId (ref), RunService (ref), v1 (ref), t2 (ref) ]]
			local v12 = nil
			local ok, result = pcall(function() --[[ Line: 54 | Upvalues: v12 (ref), SocialService (ref), EventId (ref) ]]
				v12 = SocialService:GetExperienceEventAsync(EventId)
			end)

			if ok then
				if v12 and not v12.HasEnded then
					v1.Enabled = true
					t2[v1] = v1.Triggered:Connect(function(p1) --[[ Line: 89 | Upvalues: SocialService (ref), EventId (ref) ]]
						pcall(function() --[[ Line: 90 | Upvalues: SocialService (ref), EventId (ref) ]]
							SocialService:PromptRsvpToEventAsync(EventId)
						end)
					end)
					v1.Destroying:Connect(function() --[[ Line: 98 | Upvalues: t2 (ref), v1 (ref) ]]
						local v12 = t2[v1]

						if not v12 then
							return
						end

						v12:Disconnect()
						t2[v1] = nil
					end)
				elseif RunService:IsStudio() then
					v1.Enabled = true
					t2[v1] = v1.Triggered:Connect(function(p1) --[[ Line: 76 | Upvalues: SocialService (ref), EventId (ref) ]]
						pcall(function() --[[ Line: 77 | Upvalues: SocialService (ref), EventId (ref) ]]
							SocialService:PromptRsvpToEventAsync(EventId)
						end)
					end)
				end
			else
				warn("[EventRsvpPrompt] Failed to fetch event:", result)

				if RunService:IsStudio() then
					v1.Enabled = true
					t2[v1] = v1.Triggered:Connect(function(p1) --[[ Line: 62 | Upvalues: SocialService (ref), EventId (ref) ]]
						pcall(function() --[[ Line: 63 | Upvalues: SocialService (ref), EventId (ref) ]]
							SocialService:PromptRsvpToEventAsync(EventId)
						end)
					end)
				end
			end
		end)
	end
end

local function stopFor(p1) --[[ stopFor | Line: 108 | Upvalues: t2 (copy) ]]
	if not p1:IsA("ProximityPrompt") then
		return
	end

	local v1 = t2[p1]

	if not v1 then
		return
	end

	v1:Disconnect()
	t2[p1] = nil
end

function t.Init(p1) --[[ Init | Line: 119 | Upvalues: CollectionService (copy), startFor (copy), stopFor (copy) ]]
	for v1, v2 in CollectionService:GetTagged("UpdatePrompt") do
		startFor(v2)
	end

	CollectionService:GetInstanceAddedSignal("UpdatePrompt"):Connect(startFor)
	CollectionService:GetInstanceRemovedSignal("UpdatePrompt"):Connect(stopFor)

	local UpdatePrompt = workspace:FindFirstChild("UpdatePrompt", true)

	if not UpdatePrompt then
		return
	end

	if not UpdatePrompt:FindFirstChildWhichIsA("ProximityPrompt") then
		local EventRsvp = Instance.new("ProximityPrompt")

		EventRsvp.Name = "EventRsvp"
		EventRsvp.Style = Enum.ProximityPromptStyle.Custom
		EventRsvp.ActionText = "Join"
		EventRsvp.ObjectText = "Event"
		EventRsvp.HoldDuration = 0
		EventRsvp.MaxActivationDistance = 10
		EventRsvp.Parent = UpdatePrompt
	end

	startFor(UpdatePrompt)
end

return t