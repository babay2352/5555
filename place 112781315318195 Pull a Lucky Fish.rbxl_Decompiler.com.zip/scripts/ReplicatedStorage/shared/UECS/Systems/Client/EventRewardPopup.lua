-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local EventConfig = require(ReplicatedStorage.shared.config.EventConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Remotes = require(ReplicatedStorage.shared.Remotes)
local SFX = require(ReplicatedStorage.client.SFX)
local t = {
	UECS = nil,
	Priority = 33
}

local function findTierByLabel(p1) --[[ findTierByLabel | Line: 27 | Upvalues: EventConfig (copy) ]]
	for v1, v2 in EventConfig.Tiers do
		if v2.Label == p1 then
			return v2
		end
	end

	return nil
end

local function waitForPopupsClosed(p1) --[[ waitForPopupsClosed | Line: 36 ]]
	local OfflineEarnings = p1:FindFirstChild("OfflineEarnings")
	local UpdateLog = p1:FindFirstChild("UpdateLog")
	local DailyLoginNew = p1:FindFirstChild("DailyLoginNew")

	if OfflineEarnings and OfflineEarnings.Visible then
		repeat
			task.wait(0.2)
		until not OfflineEarnings.Visible

		task.wait(0.4)
	end

	if UpdateLog and UpdateLog.Visible then
		repeat
			task.wait(0.2)
		until not UpdateLog.Visible

		task.wait(0.4)
	end

	if not (DailyLoginNew and DailyLoginNew.Visible) then
		return
	end

	repeat
		task.wait(0.2)
	until not DailyLoginNew.Visible

	task.wait(0.4)
end

local function animateCardAppear(p1, p2) --[[ animateCardAppear | Line: 63 | Upvalues: TweenService (copy) ]]
	local Container = p1:FindFirstChild("Container")

	if Container then
		Container.Size = UDim2.new(0.6, 0, 0.6, 0)
		Container.Rotation = math.random(-8, 8)
		task.delay(p2, function() --[[ Line: 72 | Upvalues: p1 (copy), TweenService (ref), Container (copy) ]]
			p1.Visible = true
			TweenService:Create(Container, TweenInfo.new(0.25, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
				Rotation = 0,
				Size = UDim2.new(1, 0, 1, 0)
			}):Play()
			task.delay(0.35, function() --[[ Line: 80 | Upvalues: Container (ref), TweenService (ref) ]]
				local v1 = math.random(-10, 10)

				Container.Rotation = v1

				local v3 = TweenService:Create(Container, TweenInfo.new(math.max(math.abs(10 - v1) / 20 * 1.2, 0.1), Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
					Rotation = 10
				})

				v3:Play()
				v3.Completed:Once(function() --[[ Line: 91 | Upvalues: TweenService (ref), Container (ref) ]]
					TweenService:Create(Container, TweenInfo.new(1.2, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true), {
						Rotation = -10
					}):Play()
				end)
			end)
		end)
	end
end

function t.Init(p1) --[[ Init | Line: 100 | Upvalues: Players (copy), EventConfig (copy), SFX (copy), TweenService (copy), waitForPopupsClosed (copy), animateCardAppear (copy), Remotes (copy) ]]
	local MainUI = Players.LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("MainUI")
	local v1 = MainUI:WaitForChild(EventConfig.Ui.RewardPopupFrameName)
	local v2 = v1:WaitForChild("Content")
	local TopBar = v1:WaitForChild("TopBar")
	local Day7 = v2:WaitForChild("Day7")
	local RewardsContainer = v2:WaitForChild("RewardsContainer")
	local CardTemplate = RewardsContainer:WaitForChild("CardTemplate")
	local ClaimBtn = v2:WaitForChild("ClaimBtn")
	local CloseButton = TopBar:WaitForChild("CloseButton")

	CloseButton.ZIndex = 10
	CloseButton.Active = true
	SFX.PlaySoundWithRandomPitch(SFX.Sounds.EggReward, 0.001, 1, 1)

	local Size = v1.Size
	local v3 = false

	local function showPopup() --[[ showPopup | Line: 121 | Upvalues: v1 (copy), TweenService (ref), Size (copy) ]]
		v1.Size = UDim2.new(0, 0, 0, 0)
		v1.Visible = true
		TweenService:Create(v1, TweenInfo.new(0.35, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
			Size = Size
		}):Play()
	end

	local function closePopup() --[[ closePopup | Line: 129 | Upvalues: v3 (ref), TweenService (ref), v1 (copy), Size (copy) ]]
		if not v3 then
			v3 = true

			local v12 = TweenService:Create(v1, TweenInfo.new(0.25, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
				Size = UDim2.new(0, 0, 0, 0)
			})

			v12:Play()
			v12.Completed:Once(function() --[[ Line: 138 | Upvalues: v1 (ref), Size (ref), v3 (ref) ]]
				v1.Visible = false
				v1.Size = Size
				v3 = false
			end)
		end
	end

	local Size2 = ClaimBtn.Size

	local function pressButton() --[[ pressButton | Line: 146 | Upvalues: TweenService (ref), ClaimBtn (copy), Size2 (copy) ]]
		local v1 = TweenService:Create(ClaimBtn, TweenInfo.new(0.08, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			Size = UDim2.new(Size2.X.Scale * 0.9, Size2.X.Offset, Size2.Y.Scale * 0.9, Size2.Y.Offset)
		})

		v1:Play()
		v1.Completed:Once(function() --[[ Line: 154 | Upvalues: TweenService (ref), ClaimBtn (ref), Size2 (ref) ]]
			TweenService:Create(ClaimBtn, TweenInfo.new(0.15, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
				Size = Size2
			}):Play()
		end)
	end

	ClaimBtn.Activated:Connect(function() --[[ Line: 161 | Upvalues: SFX (ref), EventConfig (ref), pressButton (copy), closePopup (copy) ]]
		local v1 = SFX.Sounds[EventConfig.Theme.RewardClaimSfx]

		if v1 then
			SFX.PlaySoundWithRandomPitch(v1, 0.8, 0.95, 1.05)
		end

		pressButton()
		task.delay(0.15, closePopup)
	end)
	CloseButton.Activated:Connect(closePopup)

	local function handleRewardPopup(p1) --[[ handleRewardPopup | Line: 171 | Upvalues: EventConfig (ref), waitForPopupsClosed (ref), MainUI (copy), Day7 (copy), RewardsContainer (copy), CardTemplate (copy), showPopup (copy), SFX (ref), animateCardAppear (ref) ]]
		if not p1 then
			warn("[EventRewardPopup] Invalid data received")

			return
		end

		if type(p1.Label) ~= "string" then
			warn("[EventRewardPopup] Invalid data received")

			return
		end

		local Rank = p1.Rank
		local Label2 = p1.Label
		local v1 = nil

		for v2, v3 in EventConfig.Tiers do
			if v3.Label == Label2 then
				v1 = v3

				break
			end
		end

		if v1 then
			task.spawn(function() --[[ Line: 184 | Upvalues: waitForPopupsClosed (ref), MainUI (ref), Day7 (ref), Rank (copy), EventConfig (ref), RewardsContainer (ref), v1 (copy), CardTemplate (ref), showPopup (ref), SFX (ref), animateCardAppear (ref) ]]
				waitForPopupsClosed(MainUI)
				Day7.Text = if Rank then "Good job! You placed #" .. Rank .. " in the " .. EventConfig.Event.DisplayName .. "!" else "Good job! You did great in the " .. EventConfig.Event.DisplayName .. "!"

				for v3, v4 in RewardsContainer:GetChildren() do
					if v4:IsA("Frame") and v4.Name ~= "CardTemplate" then
						v4:Destroy()
					end
				end

				local t = {}

				for v5, v6 in v1.Items do
					local v7 = CardTemplate:Clone()

					v7.Name = "Card" .. v5
					v7.LayoutOrder = v5
					v7.Visible = false

					local Container = v7:FindFirstChild("Container")

					if Container then
						local Icon = Container:FindFirstChild("Icon")

						if Icon then
							Icon.Image = v6.Image
						end

						local RewardName = Container:FindFirstChild("RewardName")

						if RewardName then
							RewardName.Text = v6.ShortLabel
						end

						local RewardAmount = Container:FindFirstChild("RewardAmount")

						if RewardAmount then
							RewardAmount.Text = if v6.Amount > 1 then "x" .. v6.Amount else ""
						end

						v7.Parent = RewardsContainer
						table.insert(t, v7)

						continue
					end

					warn("[EventRewardPopup] CardTemplate missing Container")
				end

				showPopup()
				SFX.PlaySoundWithRandomPitch(SFX.Sounds.EggReward, 0.8, 0.95, 1.05)

				for v9, v10 in t do
					animateCardAppear(v10, (v9 - 1) * 0.12)
				end
			end)
		else
			warn("[EventRewardPopup] No matching tier for label", p1.Label)
		end
	end

	Remotes.EventRewardPopup:On(handleRewardPopup)
end

return t