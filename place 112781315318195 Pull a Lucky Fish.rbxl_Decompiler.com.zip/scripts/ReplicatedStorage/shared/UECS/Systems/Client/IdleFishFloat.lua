-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

require(game:GetService("ReplicatedStorage").shared.UECS.GlobalTypes)
require(ReplicatedStorage.shared.util.isMobile)

local t = {
	UECS = nil
}

local function setAnimationsPlaying(p1, p2) --[[ setAnimationsPlaying | Line: 63 ]]
	for v1, v2 in p1:GetDescendants() do
		if v2:IsA("Animator") or v2:IsA("AnimationController") then
			local ok, result = pcall(function() --[[ Line: 66 | Upvalues: v2 (copy) ]]
				return v2:GetPlayingAnimationTracks()
			end)

			if ok and result then
				for v3, v4 in result do
					v4:AdjustSpeed(if p2 then 1 else 0)
				end
			end
		end
	end
end

local function resolveRarityLabel(p1, p2) --[[ resolveRarityLabel | Line: 81 ]]
	if p2.rarityLabel then
		return
	end

	local RarityLabel = p1:FindFirstChild("RarityLabel")
	local v1 = if RarityLabel then RarityLabel:FindFirstChild("Frame") else RarityLabel
	local v2 = if v1 then v1:FindFirstChild("Rarity") else v1

	if not (v2 and v2:IsA("TextLabel")) then
		return
	end

	p2.rarityLabel = v2
end

local function setRarityAnimated(p1, p2) --[[ setRarityAnimated | Line: 95 | Upvalues: CollectionService (copy) ]]
	local rarityLabel = p1.rarityLabel

	if not (rarityLabel and rarityLabel.Parent) then
		return
	end

	if rarityLabel:HasTag("AnimatedRarity") == p2 then
		return
	end

	if p2 then
		CollectionService:AddTag(rarityLabel, "AnimatedRarity")
	else
		CollectionService:RemoveTag(rarityLabel, "AnimatedRarity")
	end
end

function t.Init(p1) --[[ Init | Line: 110 | Upvalues: CollectionService (copy), RunService (copy), Players (copy), setAnimationsPlaying (copy) ]]
	local t = {}

	local function readAnchor(p1) --[[ readAnchor | Line: 113 ]]
		local v1 = p1:GetAttribute("IdleAnchor")

		if typeof(v1) == "CFrame" then
			return v1
		end

		return p1:GetPivot()
	end

	local function resolveBaseAnchor(p1) --[[ resolveBaseAnchor | Line: 125 ]]
		local v1 = p1.Parent

		while v1 and v1 ~= workspace do
			local FloorSpawn = v1:FindFirstChild("FloorSpawn")

			if FloorSpawn and FloorSpawn:IsA("BasePart") then
				return FloorSpawn
			end

			v1 = v1.Parent
		end

		return nil
	end

	local function startFor(p1) --[[ startFor | Line: 137 | Upvalues: t (copy), resolveBaseAnchor (copy) ]]
		if not p1:IsA("Model") or t[p1] then
			return
		end

		local v1 = p1:GetAttributeChangedSignal("IdleAnchor"):Connect(function() --[[ Line: 144 | Upvalues: t (ref), p1 (copy) ]]
			local v1 = t[p1]

			if not v1 then
				return
			end

			local v2 = p1
			local v3 = v2:GetAttribute("IdleAnchor")

			v1.anchor = if typeof(v3) == "CFrame" then v3 else v2:GetPivot()
		end)
		local v2 = t
		local t2 = {
			resting = false,
			rarityLabel = nil,
			rarityTagged = true
		}
		local v3 = p1:GetAttribute("IdleAnchor")

		t2.anchor = if typeof(v3) == "CFrame" then v3 else p1:GetPivot()
		t2.phase = math.random() * math.pi * 2
		t2.attrConn = v1
		t2.baseAnchor = resolveBaseAnchor(p1)
		v2[p1] = t2
	end

	local function stopFor(p1) --[[ stopFor | Line: 163 | Upvalues: t (copy) ]]
		if not p1:IsA("Model") then
			return
		end

		local v1 = t[p1]

		if not v1 then
			return
		end

		v1.attrConn:Disconnect()
		t[p1] = nil
	end

	for v1, v2 in CollectionService:GetTagged("IdleFishFloat") do
		startFor(v2)
	end

	CollectionService:GetInstanceAddedSignal("IdleFishFloat"):Connect(startFor)
	CollectionService:GetInstanceRemovedSignal("IdleFishFloat"):Connect(stopFor)

	local t2 = {}
	local t3 = {}

	RunService.Heartbeat:Connect(function() --[[ Line: 186 | Upvalues: t2 (copy), t3 (copy), Players (ref), t (copy), setAnimationsPlaying (ref), CollectionService (ref) ]]
		debug.profilebegin("UECS/IdleFishFloat.Heartbeat")

		local v1 = workspace:GetServerTimeNow()

		table.clear(t2)
		table.clear(t3)

		local Character = Players.LocalPlayer.Character
		local v2 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character
		local v3 = if v2 then v2.Position else v2
		local CurrentCamera = workspace.CurrentCamera

		for v5, v6 in t do
			local v4

			if v5.Parent then
				local PrimaryPart = v5.PrimaryPart

				if PrimaryPart then
					if v3 then
						local baseAnchor = v6.baseAnchor
						local v7 = if baseAnchor then baseAnchor.Position else v6.anchor.Position
						local v8 = v7.X - v3.X
						local v9 = v7.Z - v3.Z

						if v8 * v8 + v9 * v9 > 2500 then
							if not v6.resting then
								v6.resting = true
								PrimaryPart.CFrame = v6.anchor
								v5:SetAttribute("IdleResting", true)
								setAnimationsPlaying(v5, false)
							end

							local rarityLabel = v6.rarityLabel

							if rarityLabel and (rarityLabel.Parent and rarityLabel:HasTag("AnimatedRarity") ~= false) then
								CollectionService:RemoveTag(rarityLabel, "AnimatedRarity")
							end

							continue
						end
					end

					if CurrentCamera then
						if not v6.rarityLabel then
							local RarityLabel = v5:FindFirstChild("RarityLabel")
							local v10 = if RarityLabel then RarityLabel:FindFirstChild("Frame") else RarityLabel
							local v11 = if v10 then v10:FindFirstChild("Rarity") else v10

							if v11 and v11:IsA("TextLabel") then
								v6.rarityLabel = v11
							end
						end

						local _, v12 = CurrentCamera:WorldToViewportPoint(PrimaryPart.Position)
						local v13 = if v12 then (PrimaryPart.CFrame.Position - CurrentCamera.CFrame.Position).Magnitude <= 70 else v12
						local rarityLabel = v6.rarityLabel

						if rarityLabel and (rarityLabel.Parent and rarityLabel:HasTag("AnimatedRarity") ~= v13) then
							if v13 then
								CollectionService:AddTag(rarityLabel, "AnimatedRarity")
							else
								CollectionService:RemoveTag(rarityLabel, "AnimatedRarity")
							end
						end

						v4 = v13
					else
						v4 = false
					end

					if v4 then
						if v6.resting then
							v6.resting = false
							v5:SetAttribute("IdleResting", nil)
							setAnimationsPlaying(v5, true)
						end

						local phase = v6.phase
						local v14 = math.sin(v1 * math.pi + phase) * 0.25
						local v15 = math.sin(v1 * 1.8849555921538759 + phase + 1) * math.rad(4)
						local v16 = math.sin(v1 * 2.5132741228718345 + phase + 2) * 0.05235987755982989
						local v17 = CFrame.new(0, v14, 0) * CFrame.Angles(v16, v15, 0)

						table.insert(t2, PrimaryPart)
						table.insert(t3, v6.anchor * v17)

						continue
					end

					if not v6.resting then
						v6.resting = true
						PrimaryPart.CFrame = v6.anchor
						v5:SetAttribute("IdleResting", true)
						setAnimationsPlaying(v5, false)
					end
				end

				continue
			end

			if v5:IsA("Model") then
				local v21 = t[v5]

				if v21 then
					v21.attrConn:Disconnect()
					t[v5] = nil
				end
			end
		end

		if not (#t2 > 0) then
			debug.profileend()

			return
		end

		workspace:BulkMoveTo(t2, t3, Enum.BulkMoveMode.FireCFrameChanged)
		debug.profileend()
	end)
end

return t