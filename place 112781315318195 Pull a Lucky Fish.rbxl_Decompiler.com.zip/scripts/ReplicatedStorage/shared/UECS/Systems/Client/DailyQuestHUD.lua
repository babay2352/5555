-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ContentProvider = game:GetService("ContentProvider")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local QuestConfig = require(ReplicatedStorage.shared.config.QuestConfig)
local QuestView = require(ReplicatedStorage.shared.util.QuestView)
local ThrowZoneState = require(ReplicatedStorage.client.ThrowZoneState)
local TutorialConfig = require(ReplicatedStorage.shared.config.TutorialConfig)
local bindToButtonPress = require(ReplicatedStorage.shared.util.bindToButtonPress)
local v1 = #TutorialConfig + 1
local t = {
	UECS = nil,
	Priority = 30
}

task.spawn(function() --[[ Line: 48 | Upvalues: ContentProvider (copy) ]]
	ContentProvider:PreloadAsync({ "rbxassetid://76399520426482", "rbxassetid://83214330341659" })
end)

local t2 = {
	RevealDelay = 5,
	Slide = TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut),
	BarTween = TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
}

function t.Init(p1) --[[ Init | Line: 61 | Upvalues: ClientPlayerData (copy), Players (copy), TweenService (copy), t2 (copy), ThrowZoneState (copy), bindToButtonPress (copy), v1 (copy), QuestView (copy), QuestConfig (copy) ]]
	repeat
		task.wait()
	until ClientPlayerData.isPlayerDataLoaded

	local LocalPlayer = Players.LocalPlayer
	local DailyQuest = LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("MainUI"):WaitForChild("HUD"):WaitForChild("DailyQuest")

	if not DailyQuest.Visible then
		return
	end

	local Frame = DailyQuest:WaitForChild("Frame")
	local ArrowButton = DailyQuest:WaitForChild("ArrowButton")
	local QuestTemplateNew = Frame:WaitForChild("UIListLayout"):WaitForChild("QuestTemplateNew")
	local QuestTemplateNew2 = Frame:FindFirstChild("QuestTemplateNew")

	if QuestTemplateNew2 and QuestTemplateNew2:IsA("GuiObject") then
		QuestTemplateNew2.Visible = false
	end

	local function getState() --[[ getState | Line: 88 | Upvalues: ClientPlayerData (ref) ]]
		return ClientPlayerData.serverProfile:getState()
	end

	local v12 = false
	local Position = DailyQuest.Position
	local v2 = UDim2.new(Position.X.Scale + DailyQuest.Size.X.Scale, Position.X.Offset + DailyQuest.Size.X.Offset, Position.Y.Scale, Position.Y.Offset)

	DailyQuest.Position = v2
	DailyQuest.Visible = false
	ArrowButton.Image = "rbxassetid://83214330341659"

	local function setShown(p1) --[[ setShown | Line: 107 | Upvalues: v12 (ref), ArrowButton (copy), TweenService (ref), DailyQuest (copy), t2 (ref), Position (copy), v2 (copy) ]]
		v12 = p1
		ArrowButton.Image = if p1 then "rbxassetid://76399520426482" else "rbxassetid://83214330341659"

		local t = {}

		t.Position = if p1 then Position else v2
		TweenService:Create(DailyQuest, t2.Slide, t):Play()
	end

	local InZone = ThrowZoneState.InZone
	local v3 = false

	ThrowZoneState.OnChanged:Connect(function(p1) --[[ Line: 120 | Upvalues: InZone (ref), v3 (ref), v12 (ref), ArrowButton (copy), TweenService (ref), DailyQuest (copy), t2 (ref), v2 (copy), Position (copy) ]]
		if p1 == InZone then
			return
		end

		InZone = p1

		if p1 then
			v3 = v12

			if v12 then
				v12 = false
				ArrowButton.Image = "rbxassetid://83214330341659"
				TweenService:Create(DailyQuest, t2.Slide, {
					Position = v2
				}):Play()
			end
		else
			if not v3 or (v12 or not DailyQuest.Visible) then
				return
			end

			v12 = true
			ArrowButton.Image = "rbxassetid://76399520426482"
			TweenService:Create(DailyQuest, t2.Slide, {
				Position = Position
			}):Play()
		end
	end)
	bindToButtonPress("DailyQuestTrackerToggle", Enum.KeyCode.DPadRight, function() --[[ Line: 135 | Upvalues: v12 (ref), ArrowButton (copy), TweenService (ref), DailyQuest (copy), t2 (ref), Position (copy), v2 (copy) ]]
		local v1 = not v12

		v12 = v1
		ArrowButton.Image = if v1 then "rbxassetid://76399520426482" else "rbxassetid://83214330341659"

		local t = {}

		t.Position = if v1 then Position else v2
		TweenService:Create(DailyQuest, t2.Slide, t):Play()
	end, 1000)
	ArrowButton.MouseButton1Down:Connect(function() --[[ Line: 139 | Upvalues: v12 (ref), ArrowButton (copy), TweenService (ref), DailyQuest (copy), t2 (ref), Position (copy), v2 (copy) ]]
		local v1 = not v12

		v12 = v1
		ArrowButton.Image = if v1 then "rbxassetid://76399520426482" else "rbxassetid://83214330341659"

		local t = {}

		t.Position = if v1 then Position else v2
		TweenService:Create(DailyQuest, t2.Slide, t):Play()
	end)

	local function isTutorialActive() --[[ isTutorialActive | Line: 145 | Upvalues: ClientPlayerData (ref), v1 (ref) ]]
		local tutorialInfo = ClientPlayerData.serverProfile:getState().tutorialInfo

		return if tutorialInfo == nil then false else (tutorialInfo.tutorialStep or v1) < v1
	end

	local function revealQuestUI() --[[ revealQuestUI | Line: 150 | Upvalues: ClientPlayerData (ref), v1 (ref), DailyQuest (copy), ArrowButton (copy), InZone (ref), v3 (ref), v12 (ref), TweenService (ref), t2 (ref), Position (copy) ]]
		local tutorialInfo = ClientPlayerData.serverProfile:getState().tutorialInfo

		if if tutorialInfo == nil then false else (tutorialInfo.tutorialStep or v1) < v1 then
			return
		end

		DailyQuest.Visible = true
		ArrowButton.Visible = true

		if InZone then
			v3 = true
		else
			v12 = true
			ArrowButton.Image = "rbxassetid://76399520426482"
			TweenService:Create(DailyQuest, t2.Slide, {
				Position = Position
			}):Play()
		end
	end

	local function hideTracker() --[[ hideTracker | Line: 165 | Upvalues: v12 (ref), ArrowButton (copy), TweenService (ref), DailyQuest (copy), t2 (ref), v2 (copy) ]]
		if not v12 then
			task.delay(t2.Slide.Time, function() --[[ Line: 169 | Upvalues: v12 (ref), DailyQuest (ref) ]]
				if v12 then
					return
				end

				DailyQuest.Visible = false
			end)

			return
		end

		v12 = false
		ArrowButton.Image = "rbxassetid://83214330341659"
		TweenService:Create(DailyQuest, t2.Slide, {
			Position = v2
		}):Play()
		task.delay(t2.Slide.Time, function() --[[ Line: 169 | Upvalues: v12 (ref), DailyQuest (ref) ]]
			if v12 then
				return
			end

			DailyQuest.Visible = false
		end)
	end

	local TeleportToGemsShop = DailyQuest:FindFirstChild("TeleportToGemsShop")
	local v4, v5, v6, v7, v8, v9, v10, v11, v122, v13, v14

	if not TeleportToGemsShop then
		v4 = {}
		v5 = function() --[[ openQuestsWindow | Line: 202 | Upvalues: ClientPlayerData (ref), v1 (ref), p1 (copy) ]]
			local tutorialInfo = ClientPlayerData.serverProfile:getState().tutorialInfo

			if not (if tutorialInfo == nil then false else (tutorialInfo.tutorialStep or v1) < v1) then
				p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(p1.UECS:WaitForAnyComponent("QuestsUI"))
			end
		end
		v6 = function(p13, p23, p33) --[[ refreshCard | Line: 212 | Upvalues: TweenService (ref), t2 (ref), QuestView (ref) ]]
			local v2 = math.min(if p33 then p33 else p23.Progress, p23.Def.Goal)

			if p13.Fill then
				TweenService:Create(p13.Fill, t2.BarTween, {
					Size = UDim2.fromScale(QuestView.ProgressFraction(p23.Def, v2), 1)
				}):Play()
			end

			if not p13.Progress then
				return
			end

			p13.Progress.Text = if p23.Done then "Claim!" else QuestView.FormatProgress(p23.Def, v2)
		end
		v7 = function(p13) --[[ buildCard | Line: 226 | Upvalues: QuestTemplateNew (copy), QuestView (ref), v5 (copy), Frame (copy) ]]
			local v1 = QuestTemplateNew:Clone()

			v1.Name = p13.Def.Id
			v1.LayoutOrder = p13.Slot
			v1.Visible = true

			local Bar = v1:FindFirstChild("Bar")
			local t2 = {
				Root = v1,
				Title = v1:FindFirstChild("Title")
			}

			t2.Fill = if Bar then Bar:FindFirstChild("Frame") else nil
			t2.Progress = if Bar then Bar:FindFirstChild("Title") else nil

			if t2.Title then
				t2.Title.Text = p13.Def.DisplayText
			end

			if t2.Fill then
				t2.Fill.Size = UDim2.fromScale(QuestView.ProgressFraction(p13.Def, p13.Progress), 1)
			end

			v1.MouseButton1Click:Connect(v5)
			v1.Parent = Frame

			return t2
		end
		v8 = function() --[[ unclaimedActive | Line: 256 | Upvalues: QuestView (ref), getState (copy) ]]
			local t2 = {}

			for v1, v2 in QuestView.GetActive(getState()) do
				if not v2.Claimed then
					table.insert(t2, v2)
				end
			end

			return t2
		end
		v9 = function() --[[ rebuildCards | Line: 266 | Upvalues: v4 (copy), v8 (copy), v7 (copy), v6 (copy) ]]
			for v1, v2 in v4 do
				v2.Root:Destroy()
			end

			table.clear(v4)

			for v3, v42 in v8() do
				local v5 = v7(v42)

				v6(v5, v42)
				v4[v42.Def.Id] = v5
			end
		end
		v10 = 0
		v11 = os.clock()
		v122 = function() --[[ refreshAll | Line: 285 | Upvalues: v8 (copy), v4 (copy), QuestConfig (ref), v10 (ref), v6 (copy) ]]
			for v2, v3 in v8() do
				local v42 = v4[v3.Def.Id]

				if v42 then
					local v1
					local v5 = QuestConfig.Trackers[v3.Def.TrackerType]

					v1 = if (if v5 == nil then false else v5.Kind == "Timer") and not v3.Done then v3.Progress + v10 else nil
					v6(v42, v3, v1)
				end
			end
		end
		v13 = function(p13) --[[ cardSetMatches | Line: 298 | Upvalues: v4 (copy) ]]
			local count2 = 0

			for v1, v2 in p13 do
				if not v4[v2.Def.Id] then
					return false
				end

				count2 = count2 + 1
			end

			for v3 in v4 do
				count2 = count2 - 1
			end

			return count2 == 0
		end
		v14 = function() --[[ onQuestsChanged | Line: 312 | Upvalues: v10 (ref), v11 (ref), v8 (copy), v13 (copy), v9 (copy), v122 (copy), v12 (ref), ArrowButton (copy), TweenService (ref), DailyQuest (copy), t2 (ref), v2 (copy), ClientPlayerData (ref), v1 (ref), InZone (ref), v3 (ref), Position (copy) ]]
			v10 = 0
			v11 = os.clock()

			local v14 = v8()

			if not v13(v14) then
				v9()
			end

			v122()

			if #v14 == 0 then
				if not v12 then
					task.delay(t2.Slide.Time, function() --[[ Line: 169 | Upvalues: v12 (ref), DailyQuest (ref) ]]
						if v12 then
							return
						end

						DailyQuest.Visible = false
					end)

					return
				end

				v12 = false
				ArrowButton.Image = "rbxassetid://83214330341659"
				TweenService:Create(DailyQuest, t2.Slide, {
					Position = v2
				}):Play()
				task.delay(t2.Slide.Time, function() --[[ Line: 169 | Upvalues: v12 (ref), DailyQuest (ref) ]]
					if v12 then
						return
					end

					DailyQuest.Visible = false
				end)
			else
				if DailyQuest.Visible then
					return
				end

				local tutorialInfo = ClientPlayerData.serverProfile:getState().tutorialInfo

				if if tutorialInfo == nil then false else (tutorialInfo.tutorialStep or v1) < v1 then
					return
				end

				DailyQuest.Visible = true
				ArrowButton.Visible = true

				if InZone then
					v3 = true

					return
				end

				v12 = true
				ArrowButton.Image = "rbxassetid://76399520426482"
				TweenService:Create(DailyQuest, t2.Slide, {
					Position = Position
				}):Play()
			end
		end
		v9()
		ClientPlayerData.serverProfile:subscribe(function(p13) --[[ Line: 331 ]]
			return p13.quests
		end, v14)
		ClientPlayerData.serverProfile:subscribe(function(p13) --[[ Line: 336 ]]
			return p13.tutorialInfo.tutorialStep
		end, function(p13) --[[ Line: 338 | Upvalues: v1 (ref), v8 (copy), DailyQuest (copy), v9 (copy), v122 (copy), ClientPlayerData (ref), ArrowButton (copy), InZone (ref), v3 (ref), v12 (ref), TweenService (ref), t2 (ref), Position (copy) ]]
			if not (v1 <= p13) or (not (#v8() > 0) or DailyQuest.Visible) then
				return
			end

			v9()
			v122()

			local tutorialInfo = ClientPlayerData.serverProfile:getState().tutorialInfo

			if if tutorialInfo == nil then false else (tutorialInfo.tutorialStep or v1) < v1 then
				return
			end

			DailyQuest.Visible = true
			ArrowButton.Visible = true

			if InZone then
				v3 = true

				return
			end

			v12 = true
			ArrowButton.Image = "rbxassetid://76399520426482"
			TweenService:Create(DailyQuest, t2.Slide, {
				Position = Position
			}):Play()
		end)
		task.delay(t2.RevealDelay, function() --[[ Line: 346 | Upvalues: v8 (copy), ClientPlayerData (ref), v1 (ref), DailyQuest (copy), ArrowButton (copy), InZone (ref), v3 (ref), v12 (ref), TweenService (ref), t2 (ref), Position (copy) ]]
			if not (#v8() > 0) then
				return
			end

			local tutorialInfo = ClientPlayerData.serverProfile:getState().tutorialInfo

			if if tutorialInfo == nil then false else (tutorialInfo.tutorialStep or v1) < v1 then
				return
			end

			DailyQuest.Visible = true
			ArrowButton.Visible = true

			if InZone then
				v3 = true

				return
			end

			v12 = true
			ArrowButton.Image = "rbxassetid://76399520426482"
			TweenService:Create(DailyQuest, t2.Slide, {
				Position = Position
			}):Play()
		end)
		task.spawn(function() --[[ Line: 354 | Upvalues: DailyQuest (copy), v11 (ref), v10 (ref), v122 (copy) ]]
			while true do
				while true do
					task.wait(1)

					if DailyQuest.Visible then
						break
					end

					v11 = os.clock()
				end

				local v1 = os.clock()

				v10 = v10 + math.floor(v1 - v11)
				v11 = v1
				v122()
			end
		end)

		return
	end

	TeleportToGemsShop.MouseButton1Down:Connect(function() --[[ Line: 180 | Upvalues: LocalPlayer (copy) ]]
		local OpenGemsShop = workspace:FindFirstChild("OpenGemsShop")
		local Character = LocalPlayer.Character
		local v1 = if Character then Character:FindFirstChild("HumanoidRootPart") else nil

		if OpenGemsShop and v1 then
			v1.CFrame = OpenGemsShop.CFrame * CFrame.new(0, 3, 5)
		end
	end)
	v4 = {}
	v5 = function() --[[ openQuestsWindow | Line: 202 | Upvalues: ClientPlayerData (ref), v1 (ref), p1 (copy) ]]
		local tutorialInfo = ClientPlayerData.serverProfile:getState().tutorialInfo

		if not (if tutorialInfo == nil then false else (tutorialInfo.tutorialStep or v1) < v1) then
			p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(p1.UECS:WaitForAnyComponent("QuestsUI"))
		end
	end
	v6 = function(p13, p23, p33) --[[ refreshCard | Line: 212 | Upvalues: TweenService (ref), t2 (ref), QuestView (ref) ]]
		local v2 = math.min(if p33 then p33 else p23.Progress, p23.Def.Goal)

		if p13.Fill then
			TweenService:Create(p13.Fill, t2.BarTween, {
				Size = UDim2.fromScale(QuestView.ProgressFraction(p23.Def, v2), 1)
			}):Play()
		end

		if not p13.Progress then
			return
		end

		p13.Progress.Text = if p23.Done then "Claim!" else QuestView.FormatProgress(p23.Def, v2)
	end
	v7 = function(p13) --[[ buildCard | Line: 226 | Upvalues: QuestTemplateNew (copy), QuestView (ref), v5 (copy), Frame (copy) ]]
		local v1 = QuestTemplateNew:Clone()

		v1.Name = p13.Def.Id
		v1.LayoutOrder = p13.Slot
		v1.Visible = true

		local Bar = v1:FindFirstChild("Bar")
		local t2 = {
			Root = v1,
			Title = v1:FindFirstChild("Title")
		}

		t2.Fill = if Bar then Bar:FindFirstChild("Frame") else nil
		t2.Progress = if Bar then Bar:FindFirstChild("Title") else nil

		if t2.Title then
			t2.Title.Text = p13.Def.DisplayText
		end

		if t2.Fill then
			t2.Fill.Size = UDim2.fromScale(QuestView.ProgressFraction(p13.Def, p13.Progress), 1)
		end

		v1.MouseButton1Click:Connect(v5)
		v1.Parent = Frame

		return t2
	end
	v8 = function() --[[ unclaimedActive | Line: 256 | Upvalues: QuestView (ref), getState (copy) ]]
		local t2 = {}

		for v1, v2 in QuestView.GetActive(getState()) do
			if not v2.Claimed then
				table.insert(t2, v2)
			end
		end

		return t2
	end
	v9 = function() --[[ rebuildCards | Line: 266 | Upvalues: v4 (copy), v8 (copy), v7 (copy), v6 (copy) ]]
		for v1, v2 in v4 do
			v2.Root:Destroy()
		end

		table.clear(v4)

		for v3, v42 in v8() do
			local v5 = v7(v42)

			v6(v5, v42)
			v4[v42.Def.Id] = v5
		end
	end
	v10 = 0
	v11 = os.clock()
	v122 = function() --[[ refreshAll | Line: 285 | Upvalues: v8 (copy), v4 (copy), QuestConfig (ref), v10 (ref), v6 (copy) ]]
		for v2, v3 in v8() do
			local v42 = v4[v3.Def.Id]

			if v42 then
				local v1
				local v5 = QuestConfig.Trackers[v3.Def.TrackerType]

				v1 = if (if v5 == nil then false else v5.Kind == "Timer") and not v3.Done then v3.Progress + v10 else nil
				v6(v42, v3, v1)
			end
		end
	end
	v13 = function(p13) --[[ cardSetMatches | Line: 298 | Upvalues: v4 (copy) ]]
		local count2 = 0

		for v1, v2 in p13 do
			if not v4[v2.Def.Id] then
				return false
			end

			count2 = count2 + 1
		end

		for v3 in v4 do
			count2 = count2 - 1
		end

		return count2 == 0
	end
	v14 = function() --[[ onQuestsChanged | Line: 312 | Upvalues: v10 (ref), v11 (ref), v8 (copy), v13 (copy), v9 (copy), v122 (copy), v12 (ref), ArrowButton (copy), TweenService (ref), DailyQuest (copy), t2 (ref), v2 (copy), ClientPlayerData (ref), v1 (ref), InZone (ref), v3 (ref), Position (copy) ]]
		v10 = 0
		v11 = os.clock()

		local v14 = v8()

		if not v13(v14) then
			v9()
		end

		v122()

		if #v14 == 0 then
			if not v12 then
				task.delay(t2.Slide.Time, function() --[[ Line: 169 | Upvalues: v12 (ref), DailyQuest (ref) ]]
					if v12 then
						return
					end

					DailyQuest.Visible = false
				end)

				return
			end

			v12 = false
			ArrowButton.Image = "rbxassetid://83214330341659"
			TweenService:Create(DailyQuest, t2.Slide, {
				Position = v2
			}):Play()
			task.delay(t2.Slide.Time, function() --[[ Line: 169 | Upvalues: v12 (ref), DailyQuest (ref) ]]
				if v12 then
					return
				end

				DailyQuest.Visible = false
			end)
		else
			if DailyQuest.Visible then
				return
			end

			local tutorialInfo = ClientPlayerData.serverProfile:getState().tutorialInfo

			if if tutorialInfo == nil then false else (tutorialInfo.tutorialStep or v1) < v1 then
				return
			end

			DailyQuest.Visible = true
			ArrowButton.Visible = true

			if InZone then
				v3 = true

				return
			end

			v12 = true
			ArrowButton.Image = "rbxassetid://76399520426482"
			TweenService:Create(DailyQuest, t2.Slide, {
				Position = Position
			}):Play()
		end
	end
	v9()
	ClientPlayerData.serverProfile:subscribe(function(p13) --[[ Line: 331 ]]
		return p13.quests
	end, v14)
	ClientPlayerData.serverProfile:subscribe(function(p13) --[[ Line: 336 ]]
		return p13.tutorialInfo.tutorialStep
	end, function(p13) --[[ Line: 338 | Upvalues: v1 (ref), v8 (copy), DailyQuest (copy), v9 (copy), v122 (copy), ClientPlayerData (ref), ArrowButton (copy), InZone (ref), v3 (ref), v12 (ref), TweenService (ref), t2 (ref), Position (copy) ]]
		if not (v1 <= p13) or (not (#v8() > 0) or DailyQuest.Visible) then
			return
		end

		v9()
		v122()

		local tutorialInfo = ClientPlayerData.serverProfile:getState().tutorialInfo

		if if tutorialInfo == nil then false else (tutorialInfo.tutorialStep or v1) < v1 then
			return
		end

		DailyQuest.Visible = true
		ArrowButton.Visible = true

		if InZone then
			v3 = true

			return
		end

		v12 = true
		ArrowButton.Image = "rbxassetid://76399520426482"
		TweenService:Create(DailyQuest, t2.Slide, {
			Position = Position
		}):Play()
	end)
	task.delay(t2.RevealDelay, function() --[[ Line: 346 | Upvalues: v8 (copy), ClientPlayerData (ref), v1 (ref), DailyQuest (copy), ArrowButton (copy), InZone (ref), v3 (ref), v12 (ref), TweenService (ref), t2 (ref), Position (copy) ]]
		if not (#v8() > 0) then
			return
		end

		local tutorialInfo = ClientPlayerData.serverProfile:getState().tutorialInfo

		if if tutorialInfo == nil then false else (tutorialInfo.tutorialStep or v1) < v1 then
			return
		end

		DailyQuest.Visible = true
		ArrowButton.Visible = true

		if InZone then
			v3 = true

			return
		end

		v12 = true
		ArrowButton.Image = "rbxassetid://76399520426482"
		TweenService:Create(DailyQuest, t2.Slide, {
			Position = Position
		}):Play()
	end)
	task.spawn(function() --[[ Line: 354 | Upvalues: DailyQuest (copy), v11 (ref), v10 (ref), v122 (copy) ]]
		while true do
			while true do
				task.wait(1)

				if DailyQuest.Visible then
					break
				end

				v11 = os.clock()
			end

			local v1 = os.clock()

			v10 = v10 + math.floor(v1 - v11)
			v11 = v1
			v122()
		end
	end)
end

return t