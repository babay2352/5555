-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ContextActionService = game:GetService("ContextActionService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local Billboard = require(ReplicatedStorage.client.NPCtrade.Billboard)
local ControlHint = require(ReplicatedStorage.client.ControlHint)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local NPCTradePopup = require(ReplicatedStorage.shared.UECS.Components.NPCTradePopup)
local NPCtradesConfig = require(ReplicatedStorage.shared.config.NPCtradesConfig)
local Npc = require(ReplicatedStorage.client.NPCtrade.Npc)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local SFX = require(ReplicatedStorage.client.SFX)
local SignalBag = require(ReplicatedStorage.client.SignalBag)
local LocalPlayer = Players.LocalPlayer
local Spawning = NPCtradesConfig.NPCtrades.Spawning
local MaxConcurrent = Spawning.MaxConcurrent
local SlotSpacing = Spawning.SlotSpacing
local LeaveDistance = Spawning.LeaveDistance
local LeaveLingerSeconds = Spawning.LeaveLingerSeconds
local EntranceOffset = Spawning.EntranceOffset
local Sounds = NPCtradesConfig.NPCtrades.Sounds
local Enabled = NPCtradesConfig.NPCtrades.Enabled
local t = {
	UECS = nil
}
local v1 = nil

local function slotGroundPoint(p1, p2) --[[ slotGroundPoint | Line: 123 | Upvalues: SlotSpacing (copy) ]]
	return p1.Position + p1.CFrame.LookVector * (-(p2 - 1) * SlotSpacing)
end

local function makeTradeButton(p1, p2) --[[ makeTradeButton | Line: 132 | Upvalues: LocalPlayer (copy) ]]
	if not p1 then
		return nil
	end

	local t = {
		enabled = false,
		instance = p1
	}

	local function gated() --[[ gated | Line: 137 | Upvalues: t (copy), p2 (copy) ]]
		if not t.enabled then
			return
		end

		p2()
	end

	if p1:IsA("GuiButton") then
		p1.Activated:Connect(gated)

		return t
	end

	local ClickDetector = p1:FindFirstChildOfClass("ClickDetector")

	if not ClickDetector and p1:IsA("BasePart") then
		local ClickDetector2 = Instance.new("ClickDetector")

		ClickDetector2.Parent = p1
		ClickDetector = ClickDetector2
	end

	if ClickDetector then
		ClickDetector.MouseClick:Connect(function(p1) --[[ Line: 155 | Upvalues: LocalPlayer (ref), t (copy), p2 (copy) ]]
			if p1 ~= LocalPlayer or not t.enabled then
				return
			end

			p2()
		end)
	end

	return t
end

local function setButtonInteractable(p1, p2) --[[ setButtonInteractable | Line: 164 ]]
	if not p1 then
		return
	end

	p1.enabled = p2

	if not p1.instance:IsA("GuiButton") then
		return
	end

	local instance = p1.instance

	instance.Active = p2
	instance.AutoButtonColor = p2
end

local function bumpButton(p1) --[[ bumpButton | Line: 177 | Upvalues: SFX (copy), Sounds (copy), TweenService (copy) ]]
	if p1:IsA("BasePart") then
		SFX.PlaySoundWithRandomPitchAtPart(Sounds.ButtonClick, p1, 0.5, 1, 1)

		local v1 = p1.CFrame
		local v2 = TweenService:Create(p1, TweenInfo.new(0.4), {
			CFrame = v1 + v1.UpVector * -0.2
		})

		v2.Completed:Once(function() --[[ Line: 185 | Upvalues: TweenService (ref), p1 (copy), v1 (copy) ]]
			TweenService:Create(p1, TweenInfo.new(0.4), {
				CFrame = v1
			}):Play()
		end)
		v2:Play()
	else
		SFX.PlaySoundWithRandomPitch(Sounds.ButtonClick, 0.5, 1, 1)
	end
end

local function findNpcById(p1, p2) --[[ findNpcById | Line: 193 ]]
	for v1, v2 in p1.npcs do
		if v2.id == p2 then
			return v2, v1
		end
	end

	return nil, nil
end

local function refreshPanel(p1) --[[ refreshPanel | Line: 209 | Upvalues: Billboard (copy) ]]
	for v1, v2 in p1.npcs do
		local v3 = if v1 == 1 and v2.state == "ready" then v2.reachedFront else false

		if v2.billboard then
			v2.billboard.Enabled = v3

			if v3 then
				Billboard.render(v2.billboard, p1.currentOffer, v2.userId)
			end
		end
	end

	local v4 = p1.npcs[1]
	local v5 = if v4 == nil then false else v4.state == "ready"
	local acceptButton = p1.acceptButton

	if acceptButton then
		acceptButton.enabled = v5

		if acceptButton.instance:IsA("GuiButton") then
			local instance = acceptButton.instance

			instance.Active = v5
			instance.AutoButtonColor = v5
		end
	end

	local declineButton = p1.declineButton

	if not declineButton then
		return
	end

	declineButton.enabled = v5

	if not declineButton.instance:IsA("GuiButton") then
		return
	end

	local instance = declineButton.instance

	instance.Active = v5
	instance.AutoButtonColor = v5
end

local function onArrived(p1, p2) --[[ onArrived | Line: 234 | Upvalues: Npc (copy), refreshPanel (copy) ]]
	if p2.state == "walkingIn" then
		p2.state = "ready"
	end

	if p2.state ~= "leaving" then
		Npc.setMoving(p2, false)
	end

	if p1.npcs[1] ~= p2 or p2.reachedFront then
		refreshPanel(p1)

		return
	end

	p2.reachedFront = true
	Npc.greet(p2)
	refreshPanel(p1)
end

local function advanceQueue(p1) --[[ advanceQueue | Line: 255 | Upvalues: Npc (copy), SlotSpacing (copy), onArrived (copy) ]]
	for v1, v2 in p1.npcs do
		if v2.state ~= "leaving" then
			local target = p1.target

			Npc.walkTo(v2, target.Position + target.CFrame.LookVector * (-(v1 - 1) * SlotSpacing)):andThen(function() --[[ Line: 258 | Upvalues: onArrived (ref), p1 (copy), v2 (copy) ]]
				onArrived(p1, v2)
			end)
		end
	end
end

local function buildAndInsertNpc(p1, p2) --[[ buildAndInsertNpc | Line: 271 | Upvalues: Npc (copy), SlotSpacing (copy), EntranceOffset (copy), onArrived (copy) ]]
	local v1 = Npc.build(p2)

	if not v1 then
		return
	end

	if p1.model.Parent then
		local v2 = nil

		for v3, v4 in p1.npcs do
			if v4.id == p2 then
				v2 = v4

				break
			end
		end

		if not v2 then
			table.insert(p1.npcs, v1)

			local target = p1.target
			local v6 = target.Position + target.CFrame.LookVector * (-(#p1.npcs - 1) * SlotSpacing)

			v1.model:PivotTo(CFrame.lookAt(v6 + p1.target.CFrame.LookVector * -EntranceOffset + Vector3.new(0, 3, 0), v6 + Vector3.new(0, 3, 0)))
			v1.model.Parent = workspace
			Npc.walkTo(v1, v6):andThen(function() --[[ Line: 290 | Upvalues: onArrived (ref), p1 (copy), v1 (copy) ]]
				onArrived(p1, v1)
			end)

			return
		end
	end

	v1.model:Destroy()
end

local function processSpawnQueue(p1) --[[ processSpawnQueue | Line: 299 | Upvalues: MaxConcurrent (copy), buildAndInsertNpc (copy) ]]
	if not p1.spawnWorkerRunning then
		p1.spawnWorkerRunning = true
		task.spawn(function() --[[ Line: 304 | Upvalues: p1 (copy), MaxConcurrent (ref), buildAndInsertNpc (ref) ]]
			while #p1.spawnQueue > 0 and (not (MaxConcurrent <= #p1.npcs) and p1.model.Parent) do
				local v12 = table.remove(p1.spawnQueue, 1)

				if not v12 then
					continue
				end

				local v2 = nil

				for v3, v4 in p1.npcs do
					if v4.id == v12 then
						v2 = v4

						break
					end
				end

				if v2 then
					continue
				end

				buildAndInsertNpc(p1, v12)
			end

			p1.spawnWorkerRunning = false
		end)
	end
end

local function spawnNpc(p1, p2) --[[ spawnNpc | Line: 325 | Upvalues: MaxConcurrent (copy), buildAndInsertNpc (copy) ]]
	local v1 = nil

	for v2, v3 in p1.npcs do
		if v3.id == p2 then
			v1 = v3

			break
		end
	end

	if v1 or table.find(p1.spawnQueue, p2) then
		return
	end

	table.insert(p1.spawnQueue, p2)

	if not p1.spawnWorkerRunning then
		p1.spawnWorkerRunning = true
		task.spawn(function() --[[ Line: 304 | Upvalues: p1 (copy), MaxConcurrent (ref), buildAndInsertNpc (ref) ]]
			while #p1.spawnQueue > 0 and (not (MaxConcurrent <= #p1.npcs) and p1.model.Parent) do
				local v12 = table.remove(p1.spawnQueue, 1)

				if not v12 then
					continue
				end

				local v2 = nil

				for v3, v4 in p1.npcs do
					if v4.id == v12 then
						v2 = v4

						break
					end
				end

				if v2 then
					continue
				end

				buildAndInsertNpc(p1, v12)
			end

			p1.spawnWorkerRunning = false
		end)
	end
end

local function dismissById(p1, p2) --[[ dismissById | Line: 338 | Upvalues: refreshPanel (copy), MaxConcurrent (copy), buildAndInsertNpc (copy), Npc (copy), LeaveLingerSeconds (copy), advanceQueue (copy), LeaveDistance (copy) ]]
	local v1 = nil
	local v2 = nil

	for v3, v4 in p1.npcs do
		if v4.id == p2 then
			v1 = v4
			v2 = v3

			break
		end
	end

	if not (v1 and v2) then
		return
	end

	table.remove(p1.npcs, v2)
	v1.state = "leaving"
	p1.awaitingResponse = false
	p1.respondCooldownUntil = os.clock() + 4

	if v1.billboard then
		v1.billboard.Enabled = false
	end

	refreshPanel(p1)

	if not p1.spawnWorkerRunning then
		p1.spawnWorkerRunning = true
		task.spawn(function() --[[ Line: 304 | Upvalues: p1 (copy), MaxConcurrent (ref), buildAndInsertNpc (ref) ]]
			while #p1.spawnQueue > 0 and (not (MaxConcurrent <= #p1.npcs) and p1.model.Parent) do
				local v12 = table.remove(p1.spawnQueue, 1)

				if not v12 then
					continue
				end

				local v2 = nil

				for v3, v4 in p1.npcs do
					if v4.id == v12 then
						v2 = v4

						break
					end
				end

				if v2 then
					continue
				end

				buildAndInsertNpc(p1, v12)
			end

			p1.spawnWorkerRunning = false
		end)
	end

	task.spawn(function() --[[ Line: 354 | Upvalues: Npc (ref), v1 (copy), LeaveLingerSeconds (ref), advanceQueue (ref), p1 (copy), LeaveDistance (ref) ]]
		Npc.waitForReaction(v1)
		task.wait(LeaveLingerSeconds)

		if v1.model.Parent then
			local v12 = false

			local function settle() --[[ settle | Line: 366 | Upvalues: v12 (ref), advanceQueue (ref), p1 (ref) ]]
				if not v12 then
					v12 = true
					advanceQueue(p1)
				end
			end

			local v2 = v1.model:GetPivot().Position - p1.target.CFrame.RightVector * LeaveDistance

			Npc.walkTo(v1, v2):andThen(function() --[[ Line: 375 | Upvalues: v1 (ref), v12 (ref), advanceQueue (ref), p1 (ref) ]]
				v1.model:Destroy()

				if not v12 then
					v12 = true
					advanceQueue(p1)
				end
			end)
			task.delay(6, function() --[[ Line: 379 | Upvalues: v1 (ref), v12 (ref), advanceQueue (ref), p1 (ref) ]]
				if v1.model.Parent then
					v1.model:Destroy()
				end

				if not v12 then
					v12 = true
					advanceQueue(p1)
				end
			end)
		else
			advanceQueue(p1)
		end
	end)
end

local function setupPanel(p1) --[[ setupPanel | Line: 389 | Upvalues: Npc (copy), Billboard (copy), bumpButton (copy), Remotes (copy), SignalBag (copy), makeTradeButton (copy), v1 (ref), MaxConcurrent (copy), buildAndInsertNpc (copy), dismissById (copy), refreshPanel (copy) ]]
	if not p1:IsA("Model") then
		return
	end

	local Target = p1:FindFirstChild("Target", true)

	if not (Target and Target:IsA("BasePart")) then
		warn("[NPCtradeClient] NPCtradePanel has no Target BasePart:", p1:GetFullName())

		return
	end

	local Panel = p1:FindFirstChild("Panel")

	if Panel then
		Npc.preload()
		Billboard.preload()

		local t = {
			spawnWorkerRunning = false,
			awaitingResponse = false,
			respondCooldownUntil = 0,
			currentOffer = nil,
			model = p1,
			target = Target,
			npcs = {},
			spawnQueue = {}
		}

		local function respond(p1, p2) --[[ respond | Line: 431 | Upvalues: t (copy), bumpButton (ref), Remotes (ref), SignalBag (ref), Npc (ref) ]]
			local v1 = t.npcs[1]

			if not v1 or v1.state ~= "ready" then
				return
			end

			if not (t.awaitingResponse or os.clock() < t.respondCooldownUntil) then
				t.awaitingResponse = true
				bumpButton(p2)
				task.spawn(function() --[[ Line: 441 | Upvalues: Remotes (ref), p1 (copy), t (ref), SignalBag (ref), Npc (ref), v1 (copy) ]]
					local v12, v2 = Remotes.NPCTradeRespond:Call({
						Accept = p1
					}):Await()

					if not v12 or (typeof(v2) ~= "table" or v2.Ok ~= false) then
						Npc.react(v1, p1)

						return
					end

					t.awaitingResponse = false

					if typeof(v2.Message) ~= "string" then
						return
					end

					SignalBag.Notification:Fire(v2.Message)
				end)
				task.delay(3, function() --[[ Line: 455 | Upvalues: t (ref) ]]
					t.awaitingResponse = false
				end)
			end
		end

		local Accept = Panel:FindFirstChild("Accept", true)
		local Decline = Panel:FindFirstChild("Decline", true)

		t.acceptButton = makeTradeButton(Accept, function() --[[ Line: 465 | Upvalues: v1 (ref), respond (copy), Accept (copy) ]]
			if not v1 then
				return
			end

			v1(function() --[[ Line: 467 | Upvalues: respond (ref), Accept (ref) ]]
				respond(true, Accept)
			end)
		end)
		t.declineButton = makeTradeButton(Decline, function() --[[ Line: 472 | Upvalues: respond (copy), Decline (copy) ]]
			respond(false, Decline)
		end)
		Remotes.NPCTradeSpawn:On(function(p1) --[[ Line: 478 | Upvalues: t (copy), MaxConcurrent (ref), buildAndInsertNpc (ref) ]]
			if typeof(p1) ~= "table" then
				return
			end

			if typeof(p1.Id) ~= "string" then
				return
			end

			local v1 = t
			local Id2 = p1.Id
			local v2 = nil

			for v3, v4 in v1.npcs do
				if v4.id == Id2 then
					v2 = v4

					break
				end
			end

			if v2 then
				return
			end

			if table.find(v1.spawnQueue, Id2) then
				return
			end

			table.insert(v1.spawnQueue, Id2)

			if v1.spawnWorkerRunning then
				return
			end

			v1.spawnWorkerRunning = true
			task.spawn(function() --[[ Line: 304 | Upvalues: v1 (copy), MaxConcurrent (ref), buildAndInsertNpc (ref) ]]
				while #v1.spawnQueue > 0 and (not (MaxConcurrent <= #v1.npcs) and v1.model.Parent) do
					local v12 = table.remove(v1.spawnQueue, 1)

					if not v12 then
						continue
					end

					local v2 = nil

					for v3, v4 in v1.npcs do
						if v4.id == v12 then
							v2 = v4

							break
						end
					end

					if v2 then
						continue
					end

					buildAndInsertNpc(v1, v12)
				end

				v1.spawnWorkerRunning = false
			end)
		end)
		Remotes.NPCTradeRemove:On(function(p1) --[[ Line: 483 | Upvalues: t (copy), dismissById (ref) ]]
			if typeof(p1) ~= "table" then
				return
			end

			if typeof(p1.Id) ~= "string" then
				return
			end

			local v1 = table.find(t.spawnQueue, p1.Id)

			if v1 then
				table.remove(t.spawnQueue, v1)
			end

			dismissById(t, p1.Id)
		end)
		Remotes.NPCTradeOfferChanged:On(function(p1) --[[ Line: 500 | Upvalues: t (copy), refreshPanel (ref) ]]
			t.currentOffer = p1
			refreshPanel(t)
		end)
		Remotes.RequestNPCTradeQueue:Fire()
		Remotes.RequestNPCTradeOffer:Fire()
	else
		warn("[NPCtradeClient] NPCtradePanel has no Panel child:", p1:GetFullName())
	end
end

local function setupConfirmPopup(p1) --[[ setupConfirmPopup | Line: 518 | Upvalues: LocalPlayer (copy), NPCTradePopup (copy), ControlHint (copy), ContextActionService (copy), v1 (ref) ]]
	local NPCTradePopup2 = LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("MainUI"):WaitForChild("NPCTradePopup")
	local v12 = NPCTradePopup2:WaitForChild("Content")
	local Yes = v12:WaitForChild("Yes")
	local No = v12:WaitForChild("No")
	local CloseButton = NPCTradePopup2:WaitForChild("TopBar"):WaitForChild("CloseButton")

	NPCTradePopup2.Visible = false

	local v2 = NPCTradePopup.Add(NPCTradePopup2)
	local v3 = nil

	local function closePopup() --[[ closePopup | Line: 534 | Upvalues: v3 (ref), p1 (copy), v2 (copy) ]]
		v3 = nil

		local v1 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

		if v1.OpenedUIComponent:Get() ~= v2 then
			return
		end

		v1.OpenedUIComponent:Set(nil)
	end

	local function confirmPopup() --[[ confirmPopup | Line: 542 | Upvalues: v3 (ref), p1 (copy), v2 (copy) ]]
		local v1 = v3

		v3 = nil

		local v22 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

		if v22.OpenedUIComponent:Get() == v2 then
			v22.OpenedUIComponent:Set(nil)
		end

		if not v1 then
			return
		end

		v1()
	end

	local v4 = ControlHint.new({
		label = "Accept",
		anchorTo = Yes,
		keyCode = Enum.KeyCode.ButtonA
	})
	local v5 = ControlHint.new({
		label = "Decline",
		anchorTo = No,
		keyCode = Enum.KeyCode.ButtonB
	})

	local function bindGamepad() --[[ bindGamepad | Line: 560 | Upvalues: ContextActionService (ref), v3 (ref), p1 (copy), v2 (copy), v4 (copy), v5 (copy) ]]
		ContextActionService:BindActionAtPriority("NPCTradePopup_Yes", function(p12, p2) --[[ Line: 561 | Upvalues: v3 (ref), p1 (ref), v2 (ref) ]]
			if p2 ~= Enum.UserInputState.Begin then
				return Enum.ContextActionResult.Sink
			end

			local v1 = v3

			v3 = nil

			local v22 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

			if v22.OpenedUIComponent:Get() == v2 then
				v22.OpenedUIComponent:Set(nil)
			end

			if not v1 then
				return Enum.ContextActionResult.Sink
			end

			v1()

			return Enum.ContextActionResult.Sink
		end, false, 10000, Enum.KeyCode.ButtonA)
		ContextActionService:BindActionAtPriority("NPCTradePopup_No", function(p12, p2) --[[ Line: 567 | Upvalues: v3 (ref), p1 (ref), v2 (ref) ]]
			if p2 ~= Enum.UserInputState.Begin then
				return Enum.ContextActionResult.Sink
			end

			v3 = nil

			local v1 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

			if v1.OpenedUIComponent:Get() ~= v2 then
				return Enum.ContextActionResult.Sink
			end

			v1.OpenedUIComponent:Set(nil)

			return Enum.ContextActionResult.Sink
		end, false, 10000, Enum.KeyCode.ButtonB)
		v4:Show()
		v5:Show()
	end

	local function unbindGamepad() --[[ unbindGamepad | Line: 577 | Upvalues: ContextActionService (ref), v4 (copy), v5 (copy) ]]
		ContextActionService:UnbindAction("NPCTradePopup_Yes")
		ContextActionService:UnbindAction("NPCTradePopup_No")
		v4:Hide()
		v5:Hide()
	end

	v2.Visible.OnChange:Connect(function(p1) --[[ Line: 584 | Upvalues: NPCTradePopup2 (copy), bindGamepad (copy), ContextActionService (ref), v4 (copy), v5 (copy) ]]
		NPCTradePopup2.Visible = p1

		if p1 then
			bindGamepad()
		else
			ContextActionService:UnbindAction("NPCTradePopup_Yes")
			ContextActionService:UnbindAction("NPCTradePopup_No")
			v4:Hide()
			v5:Hide()
		end
	end)
	Yes.MouseButton1Click:Connect(confirmPopup)
	No.MouseButton1Click:Connect(closePopup)
	CloseButton.MouseButton1Click:Connect(closePopup)
	v1 = function(p12) --[[ Line: 597 | Upvalues: v3 (ref), p1 (copy), v2 (copy) ]]
		v3 = p12
		p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(v2)
	end
end

function t.Init(p1) --[[ Init | Line: 604 | Upvalues: Enabled (copy), Npc (copy), setupConfirmPopup (copy), CollectionService (copy), setupPanel (copy) ]]
	if not Enabled then
		return
	end

	task.spawn(Npc.loadFriends)
	task.spawn(setupConfirmPopup, p1)

	for v1, v2 in CollectionService:GetTagged("NPCtradePanel") do
		setupPanel(v2)
	end

	CollectionService:GetInstanceAddedSignal("NPCtradePanel"):Connect(setupPanel)
end

return t