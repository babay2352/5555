-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local GymEventConfig = require(ReplicatedStorage.shared.config.GymEventConfig)
local GymEventState = require(ReplicatedStorage.client.GymEventState)
local t = {
	UECS = nil
}
local Hatch = GymEventConfig.Tags.Hatch
local Sine = Enum.EasingStyle.Sine
local Quad = Enum.EasingStyle.Quad
local t2 = {}
local v1 = nil

local function findTemplate(p1) --[[ findTemplate | Line: 83 | Upvalues: v1 (ref) ]]
	local v12 = v1

	if not v12 then
		return nil
	end

	local v2 = v12:FindFirstChild(p1)

	if v2 and v2:IsA("Model") then
		return v2
	end

	return nil
end

local function restPose(p1) --[[ restPose | Line: 98 | Upvalues: GymEventConfig (copy) ]]
	return p1.CFrame + Vector3.new(0, GymEventConfig.Hatch.Clearance, 0)
end

local function hatchPoses(p1) --[[ hatchPoses | Line: 104 | Upvalues: GymEventConfig (copy) ]]
	local v2 = p1.CFrame + Vector3.new(0, GymEventConfig.Hatch.Clearance, 0)

	return v2, v2 + Vector3.new(0, -GymEventConfig.Hatch.SpawnDepth, 0)
end

local function ensureSounds(p1) --[[ ensureSounds | Line: 114 | Upvalues: GymEventConfig (copy) ]]
	local Sounds = GymEventConfig.Hatch.Sounds

	if not (p1.moveSound and p1.moveSound.Parent) then
		local GymHatchMove = Instance.new("Sound")

		GymHatchMove.Name = "GymHatchMove"
		GymHatchMove.SoundId = Sounds.Move
		GymHatchMove.Looped = true
		GymHatchMove.Volume = Sounds.Volume
		GymHatchMove.RollOffMaxDistance = Sounds.RollOffMaxDistance
		GymHatchMove.Parent = p1.part
		p1.moveSound = GymHatchMove
	end

	if p1.arriveSound and p1.arriveSound.Parent then
		return
	end

	local GymHatchArrive = Instance.new("Sound")

	GymHatchArrive.Name = "GymHatchArrive"
	GymHatchArrive.SoundId = Sounds.Arrive
	GymHatchArrive.Volume = Sounds.Volume
	GymHatchArrive.RollOffMaxDistance = Sounds.RollOffMaxDistance
	GymHatchArrive.Parent = p1.part
	p1.arriveSound = GymHatchArrive
end

local function setParticlesEnabled(p1) --[[ setParticlesEnabled | Line: 146 | Upvalues: CollectionService (copy), GymEventConfig (copy) ]]
	for v1, v2 in CollectionService:GetTagged(GymEventConfig.Tags.Particles) do
		for v3, v4 in v2:GetDescendants() do
			if v4:IsA("ParticleEmitter") then
				v4.Enabled = p1
			end
		end
	end
end

local function stopMoveSound(p1) --[[ stopMoveSound | Line: 156 ]]
	if not p1.moveSound then
		return
	end

	p1.moveSound:Stop()
end

local function stopAnimation(p1) --[[ stopAnimation | Line: 162 ]]
	if not p1.animation then
		return
	end

	p1.animation:Disconnect()
	p1.animation = nil
end

local function animate(p1, p2, p3, p4, p5, p6, p7, p8) --[[ animate | Line: 175 | Upvalues: ensureSounds (copy), RunService (copy), TweenService (copy), setParticlesEnabled (copy) ]]
	if p1.animation then
		p1.animation:Disconnect()
		p1.animation = nil
	end

	p2:PivotTo(p3)
	ensureSounds(p1)

	if p1.moveSound then
		p1.moveSound:Play()
	end

	local v1 = 0
	local v2 = false

	p1.animation = RunService.RenderStepped:Connect(function(p12) --[[ Line: 197 | Upvalues: v1 (ref), p5 (copy), TweenService (ref), p6 (copy), p2 (copy), p3 (copy), p4 (copy), v2 (ref), p7 (copy), setParticlesEnabled (ref), p1 (copy), p8 (copy) ]]
		debug.profilebegin("UECS/GymHatch.Rise")
		v1 = v1 + p12

		local v12 = if p5 > 0 then math.clamp(v1 / p5, 0, 1) else 1

		p2:PivotTo(p3:Lerp(p4, (TweenService:GetValue(v12, p6, Enum.EasingDirection.Out))))

		if not v2 and p7 <= v1 then
			v2 = true
			setParticlesEnabled(true)
		end

		if not (v12 >= 1) then
			debug.profileend()

			return
		end

		local v3 = p1

		if v3.animation then
			v3.animation:Disconnect()
			v3.animation = nil
		end

		local v4 = p1

		if v4.moveSound then
			v4.moveSound:Stop()
		end

		setParticlesEnabled(false)

		if not p8 then
			debug.profileend()

			return
		end

		p8()
		debug.profileend()
	end)
end

local function clearHatch(p1, p2) --[[ clearHatch | Line: 223 | Upvalues: setParticlesEnabled (copy), GymEventConfig (copy), animate (copy), Quad (copy) ]]
	local model = p1.model

	p1.model = nil
	p1.tierId = nil

	if model then
		if not p2 and p1.part.Parent then
			local v2 = p1.part.CFrame + Vector3.new(0, GymEventConfig.Hatch.Clearance, 0)

			animate(p1, model, v2, v2 + Vector3.new(0, -GymEventConfig.Hatch.SpawnDepth, 0), GymEventConfig.Hatch.SinkDuration, Quad, 0, function() --[[ Line: 248 | Upvalues: model (copy) ]]
				model:Destroy()
			end)

			return
		end

		if p1.animation then
			p1.animation:Disconnect()
			p1.animation = nil
		end

		if not p1.moveSound then
			setParticlesEnabled(false)
			model:Destroy()

			return
		end

		p1.moveSound:Stop()
		setParticlesEnabled(false)
		model:Destroy()
	else
		if p1.animation then
			p1.animation:Disconnect()
			p1.animation = nil
		end

		if not p1.moveSound then
			setParticlesEnabled(false)

			return
		end

		p1.moveSound:Stop()
		setParticlesEnabled(false)
	end
end

local function raiseHatch(p1, p2) --[[ raiseHatch | Line: 253 | Upvalues: v1 (ref), GymEventConfig (copy), animate (copy), Sine (copy) ]]
	local ModelName = p2.ModelName
	local v12 = v1
	local v2

	if v12 then
		local v3 = v12:FindFirstChild(ModelName)

		v2 = if v3 and v3:IsA("Model") then v3 else nil
	else
		v2 = nil
	end

	if not v2 then
		return
	end

	local v4 = v2:Clone()

	p1.model = v4
	p1.tierId = p2.Id

	for v5, v6 in v4:GetDescendants() do
		if v6:IsA("BasePart") then
			v6.Anchored = true
		end
	end

	local v8 = p1.part.CFrame + Vector3.new(0, GymEventConfig.Hatch.Clearance, 0)
	local v10 = v8 + Vector3.new(0, -GymEventConfig.Hatch.SpawnDepth, 0)

	v4:PivotTo(v10)
	v4.Parent = workspace

	local RiseDuration = GymEventConfig.Hatch.RiseDuration

	animate(p1, v4, v10, v8, RiseDuration, Sine, math.max(0, RiseDuration - GymEventConfig.Hatch.ParticleLeadIn), function() --[[ Line: 283 | Upvalues: p1 (copy) ]]
		if not p1.arriveSound then
			return
		end

		p1.arriveSound:Play()
	end)
end

local function syncHatch(p1) --[[ syncHatch | Line: 293 | Upvalues: GymEventState (copy), clearHatch (copy), GymEventConfig (copy), raiseHatch (copy) ]]
	local v1 = GymEventState.Get()
	local v2 = if v1 then v1.buff else v1
	local v3 = v2 and v2.tierId or nil

	if v3 == p1.tierId then
		return
	end

	clearHatch(p1, v3 ~= nil)

	if not v3 then
		return
	end

	for v6, v7 in GymEventConfig.Outcomes do
		if v7.Id == v3 then
			raiseHatch(p1, v7)

			return
		end
	end
end

local function startFor(p1) --[[ startFor | Line: 314 | Upvalues: t2 (copy), syncHatch (copy) ]]
	if p1:IsA("BasePart") and not t2[p1] then
		local t = {
			model = nil,
			tierId = nil,
			animation = nil,
			moveSound = nil,
			arriveSound = nil,
			part = p1
		}

		t2[p1] = t
		syncHatch(t)
	end
end

local function stopFor(p1) --[[ stopFor | Line: 330 | Upvalues: t2 (copy), setParticlesEnabled (copy) ]]
	local v1 = t2[p1]

	if not v1 then
		return
	end

	local model = v1.model

	v1.model = nil
	v1.tierId = nil

	if model then
		if v1.animation then
			v1.animation:Disconnect()
			v1.animation = nil
		end

		if v1.moveSound then
			v1.moveSound:Stop()
		end

		setParticlesEnabled(false)
		model:Destroy()
	else
		if v1.animation then
			v1.animation:Disconnect()
			v1.animation = nil
		end

		if v1.moveSound then
			v1.moveSound:Stop()
		end

		setParticlesEnabled(false)
	end

	if v1.moveSound then
		v1.moveSound:Destroy()
		v1.moveSound = nil
	end

	if not v1.arriveSound then
		t2[p1] = nil

		return
	end

	v1.arriveSound:Destroy()
	v1.arriveSound = nil
	t2[p1] = nil
end

function t.Init(p1) --[[ Init | Line: 349 | Upvalues: GymEventConfig (copy), ReplicatedStorage (copy), v1 (ref), GymEventState (copy), t2 (copy), syncHatch (copy), setParticlesEnabled (copy), CollectionService (copy), Hatch (copy), startFor (copy), stopFor (copy) ]]
	if not GymEventConfig.Enabled then
		return
	end

	local v12 = ReplicatedStorage:FindFirstChild("shared")
	local v2 = if v12 then v12:FindFirstChild("model") else v12
	local v3 = if v2 then v2:FindFirstChild(GymEventConfig.Hatch.ModelFolder) else v2

	v1 = if v3 then v3:FindFirstChild(GymEventConfig.Hatch.ModelSubFolder) or nil else nil

	if not v1 then
		return
	end

	GymEventState.Start()
	GymEventState.Changed:Connect(function() --[[ Line: 366 | Upvalues: t2 (ref), syncHatch (ref) ]]
		for v1, v2 in t2 do
			local ok, result = pcall(syncHatch, v2)

			if not ok then
				warn((("[GymHatch] sync failed: %*"):format(result)))
			end
		end
	end)
	setParticlesEnabled(false)
	CollectionService:GetInstanceAddedSignal(GymEventConfig.Tags.Particles):Connect(function() --[[ Line: 379 | Upvalues: setParticlesEnabled (ref) ]]
		setParticlesEnabled(false)
	end)

	for v5, v6 in CollectionService:GetTagged(Hatch) do
		startFor(v6)
	end

	CollectionService:GetInstanceAddedSignal(Hatch):Connect(startFor)
	CollectionService:GetInstanceRemovedSignal(Hatch):Connect(stopFor)
end

return t