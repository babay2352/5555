-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local Workspace = game:GetService("Workspace")
local AlienEventConfig = require(ReplicatedStorage.shared.config.AlienEventConfig)
local BeamTo = require(ReplicatedStorage.client.BeamTo)
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Remotes = require(ReplicatedStorage.shared.Remotes)
local TutorialGate = require(ReplicatedStorage.client.TutorialGate)
local TutorialPointer = require(ReplicatedStorage.client.TutorialPointer)
local t = {
	UECS = nil
}
local ShipFuelTank = AlienEventConfig.ShipFuelTank
local Ride = AlienEventConfig.Ship.Ride
local EventId = AlienEventConfig.EventId
local v1 = Vector2.new(0, -35)
local t2 = {}
local t3 = {}
local v2 = false
local t4 = {}
local t5 = {}
local t6 = {}
local v3 = Vector3.new(0, ShipFuelTank.FullArrowHeight, 0)

local function fuelAndCapacity() --[[ fuelAndCapacity | Line: 105 | Upvalues: ClientPlayerData (copy), EventId (copy), AlienEventConfig (copy) ]]
	local v1 = ClientPlayerData.serverProfile:getState()
	local v2 = v1.events and v1.events[EventId]

	return if type(v2) == "table" then if type(v2.fuel) == "number" then v2.fuel else 0 else 0, AlienEventConfig.GetUpgradeValue("FuelCapacity", (AlienEventConfig.GetPlayerStage(v1, "FuelCapacity"))) or 0
end

local function applyGauge(p1, p2) --[[ applyGauge | Line: 116 | Upvalues: fuelAndCapacity (copy), ShipFuelTank (copy), TweenService (copy) ]]
	local v1, v2 = fuelAndCapacity()
	local v5 = math.max((if v2 > 0 then math.clamp(v1 / v2, 0, 1) else 0) * ShipFuelTank.GaugeMaxHeight, 0.001)
	local v6 = Vector3.new(p1.width, v5, p1.depth)
	local v7 = p1.anchor * CFrame.new(0, v5 * 0.5, 0)
	local Position = (p1.anchor * CFrame.new(0, v5 + ShipFuelTank.EffectHeightOffset, 0)).Position

	if p2 then
		local v8 = TweenInfo.new(ShipFuelTank.GaugeTweenTime, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

		TweenService:Create(p1.part, v8, {
			Size = v6,
			CFrame = v7
		}):Play()

		if not p1.effect then
			return
		end

		TweenService:Create(p1.effect, v8, {
			Position = Position
		}):Play()
	else
		p1.part.Size = v6
		p1.part.CFrame = v7

		if not p1.effect then
			return
		end

		p1.effect.Position = Position
	end
end

local v4 = 0

local function setEmitters(p1) --[[ setEmitters | Line: 149 | Upvalues: t3 (copy) ]]
	for v1 in t3 do
		if v1:IsDescendantOf(game) then
			v1.Enabled = p1

			continue
		end

		t3[v1] = nil
	end
end

local function playEffectSound(p1) --[[ playEffectSound | Line: 160 ]]
	local Sound = Instance.new("Sound")

	Sound.SoundId = "rbxassetid://9118859779"
	Sound.Volume = 1
	Sound.Parent = p1
	Sound.Ended:Connect(function() --[[ Line: 165 | Upvalues: Sound (copy) ]]
		Sound:Destroy()
	end)
	Sound:Play()
	task.delay(10, function() --[[ Line: 170 | Upvalues: Sound (copy) ]]
		Sound:Destroy()
	end)
end

local function pulseEmitters() --[[ pulseEmitters | Line: 175 | Upvalues: v4 (ref), setEmitters (copy), Players (copy), t2 (copy), playEffectSound (copy), ShipFuelTank (copy) ]]
	v4 = v4 + 1

	local v1 = v4

	setEmitters(true)

	local Character = Players.LocalPlayer.Character
	local v2 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character
	local v3 = (1 / 0)
	local v42 = nil

	for v5, v6 in t2 do
		local v7 = v6.effect or v6.part

		if v7:IsDescendantOf(game) then
			local v8 = if v2 then (v7.Position - v2.Position).Magnitude else 0

			if v8 < v3 then
				v3 = v8
				v42 = v7
			end
		end
	end

	if v42 then
		playEffectSound(v42)
	end

	task.delay(ShipFuelTank.EffectBurstTime, function() --[[ Line: 198 | Upvalues: v1 (copy), v4 (ref), setEmitters (ref) ]]
		if v1 ~= v4 then
			return
		end

		setEmitters(false)
	end)
end

local function refreshLabels() --[[ refreshLabels | Line: 208 | Upvalues: fuelAndCapacity (copy), ShipFuelTank (copy), t4 (copy) ]]
	local v1, v2 = fuelAndCapacity()
	local v3 = ShipFuelTank.ProgressText(math.floor(v1), v2)

	for v4 in t4 do
		if v4:IsDescendantOf(game) then
			v4.Text = v3

			continue
		end

		t4[v4] = nil
	end
end

local function refreshGauges(p1) --[[ refreshGauges | Line: 220 | Upvalues: t2 (copy), applyGauge (copy), refreshLabels (copy) ]]
	for v1, v2 in t2 do
		if v1:IsDescendantOf(game) then
			applyGauge(v2, p1)

			continue
		end

		t2[v1] = nil
	end

	refreshLabels()
end

local function trackGauge(p1, p2) --[[ trackGauge | Line: 233 | Upvalues: t2 (copy), fuelAndCapacity (copy), ShipFuelTank (copy) ]]
	if t2[p1] then
		return
	end

	t2[p1] = {
		part = p1,
		anchor = p1.CFrame * CFrame.new(0, -p1.Size.Y * 0.5, 0),
		width = p1.Size.X,
		depth = p1.Size.Z,
		effect = p2
	}

	local v1 = t2[p1]
	local v2, v3 = fuelAndCapacity()
	local v6 = math.max((if v3 > 0 then math.clamp(v2 / v3, 0, 1) else 0) * ShipFuelTank.GaugeMaxHeight, 0.001)
	local v7 = Vector3.new(v1.width, v6, v1.depth)
	local v8 = v1.anchor * CFrame.new(0, v6 * 0.5, 0)
	local Position = (v1.anchor * CFrame.new(0, v6 + ShipFuelTank.EffectHeightOffset, 0)).Position

	v1.part.Size = v7
	v1.part.CFrame = v8

	if not v1.effect then
		return
	end

	v1.effect.Position = Position
end

local function trackEffect(p1) --[[ trackEffect | Line: 249 | Upvalues: t3 (copy) ]]
	p1.Anchored = true
	p1.CanCollide = false

	for v1, v2 in p1:GetDescendants() do
		if v2:IsA("ParticleEmitter") then
			v2.Enabled = false
			t3[v2] = true
		end
	end
end

local function isHoldingTank() --[[ isHoldingTank | Line: 266 | Upvalues: Players (copy) ]]
	local Character = Players.LocalPlayer.Character

	if not Character then
		return false
	end

	local Tool = Character:FindFirstChildOfClass("Tool")

	return if Tool == nil then false else Tool:GetAttribute("IsFuelTank") == true
end

local function playPour(p1) --[[ playPour | Line: 277 | Upvalues: TweenService (copy) ]]
	local Sound = Instance.new("Sound")

	Sound.SoundId = "rbxassetid://2347247867"
	Sound.Volume = 1
	Sound.Parent = p1
	Sound:Play()
	task.delay(1, function() --[[ Line: 283 | Upvalues: Sound (copy), TweenService (ref) ]]
		if Sound.Parent then
			TweenService:Create(Sound, TweenInfo.new(0.5), {
				Volume = 0
			}):Play()
			task.delay(0.6, function() --[[ Line: 288 | Upvalues: Sound (ref) ]]
				Sound:Destroy()
			end)
		end
	end)
end

local function hasRefueled() --[[ hasRefueled | Line: 296 | Upvalues: ClientPlayerData (copy), EventId (copy) ]]
	local v1 = ClientPlayerData.serverProfile:getState()
	local v2 = v1.events and v1.events[EventId]

	return if type(v2) == "table" then v2.refueledShipAtLeastOnce == true else false
end

local function nearestBeamTarget() --[[ nearestBeamTarget | Line: 304 | Upvalues: Players (copy), t6 (copy) ]]
	local Character = Players.LocalPlayer.Character
	local v1 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character

	if not v1 then
		return nil
	end

	local v2 = (1 / 0)
	local v3 = nil

	for v4 in t6 do
		if v4:IsDescendantOf(game) then
			local Magnitude = (v4.Position - v1.Position).Magnitude

			if Magnitude < v2 then
				v2 = Magnitude
				v3 = v4
			end

			continue
		end

		t6[v4] = nil
	end

	return v3
end

local function promptAllowed() --[[ promptAllowed | Line: 326 | Upvalues: Players (copy), TutorialGate (copy) ]]
	local Character = Players.LocalPlayer.Character
	local v1

	if Character then
		local Tool = Character:FindFirstChildOfClass("Tool")

		v1 = if Tool == nil then false else Tool:GetAttribute("IsFuelTank") == true
	else
		v1 = false
	end

	if v1 then
		v1 = not TutorialGate.active()
	end

	return v1
end

local function canLaunch() --[[ canLaunch | Line: 339 | Upvalues: fuelAndCapacity (copy), AlienEventConfig (copy) ]]
	local v1, v2 = fuelAndCapacity()

	return if v2 > 0 then AlienEventConfig.Ship.MinFlightFuel <= v1 else false
end

local function shipSpawnPart() --[[ shipSpawnPart | Line: 347 | Upvalues: CollectionService (copy), Ride (copy), Workspace (copy) ]]
	for v1, v2 in CollectionService:GetTagged(Ride.SpawnTag) do
		if v2:IsA("BasePart") and v2:IsDescendantOf(Workspace) then
			return v2
		end
	end

	return nil
end

local function isFlying() --[[ isFlying | Line: 359 | Upvalues: Players (copy), CollectionService (copy), Ride (copy) ]]
	local Character = Players.LocalPlayer.Character

	return if Character == nil then false else CollectionService:HasTag(Character, Ride.FlyingTag)
end

local function hasFlown() --[[ hasFlown | Line: 370 | Upvalues: ClientPlayerData (copy), EventId (copy) ]]
	local v1 = ClientPlayerData.serverProfile:getState()
	local v2 = v1.events and v1.events[EventId]

	return if type(v2) == "table" then v2.flewShipAtLeastOnce == true else false
end

local function shipArrowWanted() --[[ shipArrowWanted | Line: 376 | Upvalues: fuelAndCapacity (copy), AlienEventConfig (copy), ClientPlayerData (copy), EventId (copy), Players (copy), CollectionService (copy), Ride (copy), TutorialGate (copy) ]]
	local v1, v2 = fuelAndCapacity()
	local v3 = if v2 > 0 then AlienEventConfig.Ship.MinFlightFuel <= v1 else false

	if v3 then
		local v4 = ClientPlayerData.serverProfile:getState()
		local v5 = v4.events and v4.events[EventId]

		v3 = not (if type(v5) == "table" then v5.flewShipAtLeastOnce == true else false)

		if v3 then
			local Character = Players.LocalPlayer.Character
			local v7 = if Character == nil then false else CollectionService:HasTag(Character, Ride.FlyingTag)

			v3 = not v7 and not TutorialGate.active()
		end
	end

	return v3
end

local function refreshPrompts() --[[ refreshPrompts | Line: 380 | Upvalues: Players (copy), TutorialGate (copy), t5 (copy) ]]
	local Character = Players.LocalPlayer.Character
	local v1

	if Character then
		local Tool = Character:FindFirstChildOfClass("Tool")

		v1 = if Tool == nil then false else Tool:GetAttribute("IsFuelTank") == true
	else
		v1 = false
	end

	if v1 then
		v1 = not TutorialGate.active()
	end

	for v2 in t5 do
		if v2:IsDescendantOf(game) then
			v2.Enabled = v1

			continue
		end

		t5[v2] = nil
	end
end

local function attachPrompt(p1) --[[ attachPrompt | Line: 391 | Upvalues: ShipFuelTank (copy), v1 (copy), Players (copy), TutorialGate (copy), t5 (copy), t6 (copy), playPour (copy), Remotes (copy) ]]
	local ProximityPrompt = Instance.new("ProximityPrompt")

	ProximityPrompt.Style = Enum.ProximityPromptStyle.Custom
	ProximityPrompt.ActionText = ShipFuelTank.PromptActionText
	ProximityPrompt.ObjectText = ShipFuelTank.PromptObjectText
	ProximityPrompt.HoldDuration = 0
	ProximityPrompt.MaxActivationDistance = ShipFuelTank.PromptMaxDistance
	ProximityPrompt.RequiresLineOfSight = false
	ProximityPrompt.KeyboardKeyCode = Enum.KeyCode.E
	ProximityPrompt.UIOffset = v1
	ProximityPrompt.Exclusivity = Enum.ProximityPromptExclusivity.AlwaysShow
	ProximityPrompt:AddTag("NoFade")

	local Character = Players.LocalPlayer.Character
	local v12

	if Character then
		local Tool = Character:FindFirstChildOfClass("Tool")

		v12 = if Tool == nil then false elseif Tool:GetAttribute("IsFuelTank") == true then true else false
	else
		v12 = false
	end

	if v12 then
		v12 = not TutorialGate.active()
	end

	ProximityPrompt.Enabled = v12
	ProximityPrompt.Parent = p1
	t5[ProximityPrompt] = true
	t6[p1] = true
	ProximityPrompt.Triggered:Connect(function() --[[ Line: 408 | Upvalues: playPour (ref), p1 (copy), Remotes (ref) ]]
		playPour(p1)
		task.spawn(function() --[[ Line: 412 | Upvalues: Remotes (ref) ]]
			Remotes.AlienDepositFuelTank:Call():Await()
		end)
	end)
end

local function anchorPartOf(p1) --[[ anchorPartOf | Line: 420 ]]
	if p1:IsA("BasePart") then
		return p1
	end

	if not p1:IsA("Model") then
		return nil
	end

	return p1:FindFirstChild("PromptPart") or (p1.PrimaryPart or p1:FindFirstChildWhichIsA("BasePart", true))
end

local t7 = {}

local function ensureProp(p1) --[[ ensureProp | Line: 437 | Upvalues: t7 (copy), attachPrompt (copy), ShipFuelTank (copy), trackEffect (copy), trackGauge (copy), t4 (copy), refreshLabels (copy) ]]
	if not t7[p1] then
		t7[p1] = true
		task.spawn(function() --[[ Line: 442 | Upvalues: p1 (copy), attachPrompt (ref), ShipFuelTank (ref), trackEffect (ref), trackGauge (ref), t4 (ref), refreshLabels (ref), t7 (ref) ]]
			while p1:IsDescendantOf(game) do
				local v1
				local v2 = p1

				if v2:IsA("BasePart") then
					v1 = v2
				elseif v2:IsA("Model") then
					local PromptPart = v2:FindFirstChild("PromptPart")

					v1 = PromptPart or (v2.PrimaryPart or v2:FindFirstChildWhichIsA("BasePart", true))
				else
					v1 = nil
				end

				if v1 then
					attachPrompt(v1)

					local v4 = p1:FindFirstChild(ShipFuelTank.FuelPartName, true)

					if v4 and v4:IsA("BasePart") then
						v4.Anchored = true
						v4.CanCollide = false

						local v5 = p1:FindFirstChild(ShipFuelTank.EffectPartName, true)

						if v5 and v5:IsA("BasePart") then
							trackEffect(v5)
							trackGauge(v4, v5)
						else
							trackGauge(v4, nil)
						end
					else
						warn((("[AlienShipFuelTank] \'%*\' has no \'%*\' part; no gauge"):format(p1.Name, ShipFuelTank.FuelPartName)))
					end

					local v6 = p1:FindFirstChild(ShipFuelTank.ProgressLabelName, true)

					if v6 and v6:IsA("TextLabel") then
						t4[v6] = true
						refreshLabels()
					else
						warn((("[AlienShipFuelTank] \'%*\' has no \'%*\' TextLabel"):format(p1.Name, ShipFuelTank.ProgressLabelName)))
					end

					while p1:IsDescendantOf(game) and v1:IsDescendantOf(game) do
						task.wait(1)
					end

					continue
				end

				task.wait(0.5)
			end

			t7[p1] = nil
		end)
	end
end

function t.Init(p1) --[[ Init | Line: 489 | Upvalues: AlienEventConfig (copy), CollectionService (copy), ShipFuelTank (copy), t7 (copy), attachPrompt (copy), trackEffect (copy), trackGauge (copy), t4 (copy), refreshLabels (copy), ensureProp (copy), ClientPlayerData (copy), EventId (copy), refreshGauges (copy), v2 (ref), pulseEmitters (copy), Players (copy), nearestBeamTarget (copy), BeamTo (copy), fuelAndCapacity (copy), Ride (copy), TutorialGate (copy), shipSpawnPart (copy), TutorialPointer (copy), v3 (copy), refreshPrompts (copy) ]]
	if not AlienEventConfig.Enabled then
		return
	end

	for v1, v22 in CollectionService:GetTagged(ShipFuelTank.Tag) do
		if not t7[v22] then
			t7[v22] = true
			task.spawn(function() --[[ Line: 442 | Upvalues: v22 (copy), attachPrompt (ref), ShipFuelTank (ref), trackEffect (ref), trackGauge (ref), t4 (ref), refreshLabels (ref), t7 (ref) ]]
				while v22:IsDescendantOf(game) do
					local v1
					local v2 = v22

					if v2:IsA("BasePart") then
						v1 = v2
					elseif v2:IsA("Model") then
						local PromptPart = v2:FindFirstChild("PromptPart")

						v1 = PromptPart or (v2.PrimaryPart or v2:FindFirstChildWhichIsA("BasePart", true))
					else
						v1 = nil
					end

					if v1 then
						attachPrompt(v1)

						local v4 = v22:FindFirstChild(ShipFuelTank.FuelPartName, true)

						if v4 and v4:IsA("BasePart") then
							v4.Anchored = true
							v4.CanCollide = false

							local v5 = v22:FindFirstChild(ShipFuelTank.EffectPartName, true)

							if v5 and v5:IsA("BasePart") then
								trackEffect(v5)
								trackGauge(v4, v5)
							else
								trackGauge(v4, nil)
							end
						else
							warn((("[AlienShipFuelTank] \'%*\' has no \'%*\' part; no gauge"):format(v22.Name, ShipFuelTank.FuelPartName)))
						end

						local v6 = v22:FindFirstChild(ShipFuelTank.ProgressLabelName, true)

						if v6 and v6:IsA("TextLabel") then
							t4[v6] = true
							refreshLabels()
						else
							warn((("[AlienShipFuelTank] \'%*\' has no \'%*\' TextLabel"):format(v22.Name, ShipFuelTank.ProgressLabelName)))
						end

						while v22:IsDescendantOf(game) and v1:IsDescendantOf(game) do
							task.wait(1)
						end

						continue
					end

					task.wait(0.5)
				end

				t7[v22] = nil
			end)
		end
	end

	CollectionService:GetInstanceAddedSignal(ShipFuelTank.Tag):Connect(ensureProp)
	task.spawn(function() --[[ Line: 505 | Upvalues: ClientPlayerData (ref), EventId (ref), refreshGauges (ref), v2 (ref) ]]
		local v1 = os.clock() + 30

		repeat
			local v22 = ClientPlayerData.serverProfile:getState()

			if v22.events and v22.events[EventId] then
				break
			end

			task.wait(0.25)
		until v1 < os.clock()

		refreshGauges(false)
		v2 = true
	end)
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 520 | Upvalues: EventId (ref) ]]
		local v1 = p1.events and p1.events[EventId]

		return if v1 then v1.fuel or 0 else 0
	end, function(p1, p2) --[[ Line: 523 | Upvalues: refreshGauges (ref), v2 (ref), pulseEmitters (ref) ]]
		refreshGauges(true)

		if not (v2 and p2 < p1) then
			return
		end

		pulseEmitters()
	end)
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 533 | Upvalues: AlienEventConfig (ref) ]]
		return AlienEventConfig.GetPlayerStage(p1, "FuelCapacity")
	end, function() --[[ Line: 535 | Upvalues: refreshGauges (ref) ]]
		refreshGauges(true)
	end)
	task.spawn(function() --[[ Line: 549 | Upvalues: Players (ref), ClientPlayerData (ref), EventId (ref), nearestBeamTarget (ref), BeamTo (ref), fuelAndCapacity (ref), AlienEventConfig (ref), CollectionService (ref), Ride (ref), TutorialGate (ref), shipSpawnPart (ref), TutorialPointer (ref), v3 (ref) ]]
		local v1 = false
		local v2 = false

		repeat
			local v32, v4

			debug.profilebegin("UECS/AlienShipFuelTank.Guide")

			local Character = Players.LocalPlayer.Character

			if Character then
				local Tool = Character:FindFirstChildOfClass("Tool")

				v32 = if Tool == nil then false elseif Tool:GetAttribute("IsFuelTank") == true then true else false
			else
				v32 = false
			end

			if v32 then
				local v5 = ClientPlayerData.serverProfile:getState()
				local v6 = v5.events and v5.events[EventId]

				v32 = not (if type(v6) == "table" then v6.refueledShipAtLeastOnce == true else false)
			end

			local v8 = if v32 then nearestBeamTarget() else nil

			if v8 then
				BeamTo(v8)
				v1 = true
			elseif v1 then
				BeamTo(nil)
				v1 = false
			end

			local v9, v10 = fuelAndCapacity()
			local v11 = if v10 > 0 then AlienEventConfig.Ship.MinFlightFuel <= v9 else false

			if v11 then
				local v12 = ClientPlayerData.serverProfile:getState()
				local v13 = v12.events and v12.events[EventId]

				v11 = not (if type(v13) == "table" then v13.flewShipAtLeastOnce == true else false)

				if v11 then
					local Character2 = Players.LocalPlayer.Character

					v4 = if Character2 == nil then false else CollectionService:HasTag(Character2, Ride.FlyingTag)
					v11 = not v4 and not TutorialGate.active()
				end
			end

			local v16 = if v11 then shipSpawnPart() else nil

			if v16 then
				TutorialPointer.guide(v16, false, v3)
				v2 = true
			elseif v2 then
				TutorialPointer.guide(nil)
				v2 = false
			end

			debug.profileend()
			task.wait(0.25)
		until not v11
	end)

	local function watchCharacter(p1) --[[ watchCharacter | Line: 581 | Upvalues: refreshPrompts (ref) ]]
		p1.ChildAdded:Connect(refreshPrompts)
		p1.ChildRemoved:Connect(refreshPrompts)
		refreshPrompts()
	end

	if Players.LocalPlayer.Character then
		local Character = Players.LocalPlayer.Character

		Character.ChildAdded:Connect(refreshPrompts)
		Character.ChildRemoved:Connect(refreshPrompts)
		refreshPrompts()
	end

	Players.LocalPlayer.CharacterAdded:Connect(watchCharacter)
	TutorialGate.onChanged(refreshPrompts)
end

return t