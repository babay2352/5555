-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ContextActionService = game:GetService("ContextActionService")
local GamepadService = game:GetService("GamepadService")
local GuiService = game:GetService("GuiService")
local MarketplaceService = game:GetService("MarketplaceService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local ActiveEffects = require(ReplicatedStorage.shared.effects.ActiveEffects)
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local CashDisplay = require(ReplicatedStorage.shared.module.CashDisplay)
local ControlHint = require(ReplicatedStorage.client.ControlHint)
local FishEarnings = require(ReplicatedStorage.shared.util.FishEarnings)
local FishRodConfig = require(ReplicatedStorage.shared.config.FishRodConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local LuckyblockDropReel = require(ReplicatedStorage.shared.module.LuckyblockDropReel)
local Maid = require(ReplicatedStorage.shared.class.Maid)
local MonetizationConfig = require(ReplicatedStorage.shared.config.MonetizationConfig)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local Store = require(ReplicatedStorage.shared.UECS.Components.Store)
local bindToButtonPress = require(ReplicatedStorage.shared.util.bindToButtonPress)
local fetchRobuxPriceInto = require(ReplicatedStorage.shared.util.fetchRobuxPriceInto)
local getLocalPolicyInfo = require(ReplicatedStorage.shared.util.getLocalPolicyInfo)
local notifications = require(ReplicatedStorage.shared.module.notifications)

require(ReplicatedStorage.shared.reflex.serverProfile)

local t = {
	UECS = nil,
	Priority = 30
}

local function luckyblockCards() --[[ luckyblockCards | Line: 37 | Upvalues: MonetizationConfig (copy) ]]
	local t = {}
	local t2 = {}

	for v1, v2 in MonetizationConfig.DevProducts do
		local StoreEntry = v2.StoreEntry
		local LuckyblockConfigName = v2.LuckyblockConfigName

		if StoreEntry and (LuckyblockConfigName and not t[StoreEntry]) then
			t[StoreEntry] = true
			table.insert(t2, {
				frameName = StoreEntry,
				configName = LuckyblockConfigName
			})
		end
	end

	return t2
end

function t.Init(p1) --[[ Init | Line: 51 | Upvalues: Players (copy), Store (copy), Maid (copy), luckyblockCards (copy), LuckyblockDropReel (copy), bindToButtonPress (copy), GamepadService (copy), ContextActionService (copy), GuiService (copy), MonetizationConfig (copy), ActiveEffects (copy), MarketplaceService (copy), fetchRobuxPriceInto (copy), ClientPlayerData (copy), getLocalPolicyInfo (copy), FishEarnings (copy), CashDisplay (copy), FishRodConfig (copy), RunService (copy), TweenService (copy), ControlHint (copy), notifications (copy), Remotes (copy) ]]
	local LocalPlayer = Players.LocalPlayer
	local MainUI = LocalPlayer.PlayerGui:WaitForChild("MainUI")
	local Store2 = MainUI:WaitForChild("Store")
	local ScrollingFrame = Store2:WaitForChild("Content"):WaitForChild("ScrollingFrame")

	Store2.Visible = false

	local v1 = Store.Add(Store2)
	local v2 = nil

	v1.Visible.OnChange:Connect(function(p12, p2) --[[ Line: 69 | Upvalues: Store2 (copy), MainUI (copy), v2 (ref), Maid (ref), luckyblockCards (ref), LuckyblockDropReel (ref), ScrollingFrame (copy), bindToButtonPress (ref), p1 (copy), GamepadService (ref), ContextActionService (ref), GuiService (ref) ]]
		Store2.Visible = p12

		local HUD = MainUI:FindFirstChild("HUD")

		if HUD then
			HUD.Visible = not p12
		end

		if p12 then
			if not v2 then
				local v1 = Maid.new()
				local count = 0

				for v22, v3 in luckyblockCards() do
					local v4 = LuckyblockDropReel.start(ScrollingFrame, v3.frameName, v3.configName)

					if v4 then
						v1:GiveTask(v4)
						count = count + 1

						continue
					end

					warn(("[Store] no drop reel for \"%*\" \226\128\148 needs a FishList frame"):format(v3.frameName) .. " holding at least one ImageLabel slot, and a non-empty Drops table" .. (" on \"%*\""):format(v3.configName))
				end

				v2 = if count > 0 then v1 else nil
			end
		elseif v2 then
			v2:Destroy()
			v2 = nil
		end

		if p12 == p2 then
			return
		end

		if p12 then
			bindToButtonPress("StoreCloseAction", Enum.KeyCode.ButtonB, function() --[[ Line: 107 | Upvalues: p1 (ref) ]]
				p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
			end)
			GamepadService:EnableGamepadCursor(ScrollingFrame)

			return
		end

		ContextActionService:UnbindAction("StoreCloseAction")
		GamepadService:DisableGamepadCursor()
		GuiService.SelectedObject = nil
	end)
	GamepadService:GetPropertyChangedSignal("GamepadCursorEnabled"):Connect(function() --[[ Line: 120 | Upvalues: GamepadService (ref), Store2 (copy), ScrollingFrame (copy) ]]
		if GamepadService.GamepadCursorEnabled or not Store2.Visible then
			return
		end

		GamepadService:EnableGamepadCursor(ScrollingFrame)
	end)
	Store2:WaitForChild("TopBar"):WaitForChild("CloseButton").MouseButton1Down:Connect(function() --[[ Line: 128 | Upvalues: p1 (copy) ]]
		p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
	end)

	local t = {
		[0] = MonetizationConfig.DevProducts.X2ServerLuck.ProductId,
		[2] = MonetizationConfig.DevProducts.X4ServerLuck.ProductId,
		[4] = MonetizationConfig.DevProducts.X8ServerLuck.ProductId,
		[8] = MonetizationConfig.DevProducts.X16ServerLuck.ProductId,
		[16] = MonetizationConfig.DevProducts.X16ServerLuck.ProductId
	}
	local t2 = {}
	local t3 = {}
	local t4 = { 2, 4, 8, 16 }

	for v3, v4 in ScrollingFrame:GetChildren() do
		if v4.Name == "ServerLuck" then
			local v5 = v4:FindFirstChild("Content")
			local v6 = v5 and v5:FindFirstChild("Buy1")

			if v6 then
				v6.Activated:Connect(function() --[[ Line: 155 | Upvalues: ActiveEffects (ref), t (copy), MarketplaceService (ref), LocalPlayer (copy) ]]
					local v1 = 0

					for v2, v3 in ActiveEffects.GetActive() do
						if v3.Name == "X2Luck" then
							v1 = if v3.EffectOverrides then v3.EffectOverrides.Luck or 2 else 2

							break
						end
					end

					MarketplaceService:PromptProductPurchase(LocalPlayer, t[v1] or t[0])
				end)

				local v7 = v6:FindFirstChild("Content")
				local v8 = if v7 then v7:FindFirstChild("TextLabel") else v7

				if v8 then
					table.insert(t2, v8)
				end

				local v9 = if v5 then v5:FindFirstChild("TimeAward") else v5

				if v9 then
					table.insert(t3, v9)
				end
			end
		end
	end

	local function refreshServerLuckLabel() --[[ refreshServerLuckLabel | Line: 177 | Upvalues: ActiveEffects (ref), t4 (copy), t3 (copy), t (copy), t2 (copy), fetchRobuxPriceInto (ref) ]]
		local v1 = 0

		for v2, v3 in ActiveEffects.GetActive() do
			if v3.Name == "X2Luck" then
				v1 = if v3.EffectOverrides and v3.EffectOverrides.Luck then v3.EffectOverrides.Luck else 2

				break
			end
		end

		local v4

		if v1 == 0 then
			v4 = "x2 + 15 minutes!"
		elseif t4[#t4] <= v1 then
			v4 = "+15 minutes!"
		else
			local v5 = t4[#t4]

			for v6, v7 in t4 do
				if v1 < v7 then
					v5 = v7

					break
				end
			end

			v4 = ("x%* + 15 minutes!"):format(v5)
		end

		for v9, v10 in t3 do
			v10.Text = v4
		end

		local v11 = t[v1] or t[0]

		for v12, v13 in t2 do
			fetchRobuxPriceInto(v13, v11, Enum.InfoType.Product)
		end
	end

	ActiveEffects.Changed:Connect(refreshServerLuckLabel)
	refreshServerLuckLabel()

	local Gamepasses = ScrollingFrame:FindFirstChild("Gamepasses")

	if Gamepasses then
		for v10, v11 in MonetizationConfig.Gamepasses do
			local v12 = Gamepasses:FindFirstChild(v11.StoreEntry) or ScrollingFrame:FindFirstChild(v11.StoreEntry)
			local v13 = if v12 then v12:FindFirstChild("Content") else v12
			local v14 = if v13 then v13:FindFirstChild("Buy1") else v13

			if v14 then
				local function isOwned() --[[ isOwned | Line: 231 | Upvalues: LocalPlayer (copy), v11 (copy), ClientPlayerData (ref) ]]
					local v1 = LocalPlayer:GetAttribute(v11.Attribute)
					local v2 = ClientPlayerData.serverProfile:getState()
					local v3

					if typeof(v1) == "number" and v1 > 1 then
						v3 = true
					else
						if v11.ConflictsWith then
							return v2.claimedDailyRewards[v11.ConflictsWith]
						end

						v3 = false
					end

					return v3
				end

				v14.Activated:Connect(function() --[[ Line: 238 | Upvalues: LocalPlayer (copy), v11 (copy), ClientPlayerData (ref), MarketplaceService (ref) ]]
					local v1 = LocalPlayer:GetAttribute(v11.Attribute)
					local v2 = ClientPlayerData.serverProfile:getState()

					if not (if typeof(v1) == "number" and v1 > 1 then true elseif v11.ConflictsWith then v2.claimedDailyRewards[v11.ConflictsWith] else false) then
						MarketplaceService:PromptGamePassPurchase(LocalPlayer, v11.GamepassId)
					end
				end)

				local v15 = v14:FindFirstChild("Content")
				local v16 = v15 and v15:FindFirstChild("TextLabel")

				if v16 then
					local function refreshLabel() --[[ refreshLabel | Line: 252 | Upvalues: LocalPlayer (copy), v11 (copy), ClientPlayerData (ref), v16 (copy), fetchRobuxPriceInto (ref) ]]
						local v1 = LocalPlayer:GetAttribute(v11.Attribute)
						local v2 = ClientPlayerData.serverProfile:getState()

						if if typeof(v1) == "number" and v1 > 1 then true elseif v11.ConflictsWith then v2.claimedDailyRewards[v11.ConflictsWith] else false then
							v16.Text = "OWNED"
						else
							fetchRobuxPriceInto(v16, v11.GamepassId, Enum.InfoType.GamePass)
						end
					end

					local v17 = LocalPlayer:GetAttribute(v11.Attribute)
					local v18 = ClientPlayerData.serverProfile:getState()

					if if typeof(v17) == "number" and v17 > 1 then true elseif v11.ConflictsWith then v18.claimedDailyRewards[v11.ConflictsWith] else false then
						v16.Text = "OWNED"
					else
						fetchRobuxPriceInto(v16, v11.GamepassId, Enum.InfoType.GamePass)
					end

					LocalPlayer:GetAttributeChangedSignal(v11.Attribute):Connect(refreshLabel)
					ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 262 ]]
						return p1.claimedDailyRewards
					end, refreshLabel)
				end
			end
		end
	end

	local t5 = {}
	local t6 = {}

	for v20, v21 in MonetizationConfig.DevProducts do
		if v21.StoreEntry then
			local v22 = ScrollingFrame:FindFirstChild(v21.StoreEntry, true)

			if v22 then
				local v23 = v22:FindFirstChild("Content")

				if v23 then
					local v24 = v21.BuyButton or "Buy1"
					local v25 = v23:FindFirstChild(v24)

					if v25 then
						if v25:IsA("GuiButton") then
							local v26 = if v21.LuckyblockConfigName == nil then false else true

							if v26 and getLocalPolicyInfo().ArePaidRandomItemsRestricted then
								if v22 and v22:IsA("GuiObject") then
									v22.Visible = false
									t5[v22] = true
								end

								continue
							end

							local ProductId = v21.ProductId

							v25.Activated:Connect(function() --[[ Line: 319 | Upvalues: MarketplaceService (ref), LocalPlayer (copy), ProductId (copy) ]]
								MarketplaceService:PromptProductPurchase(LocalPlayer, ProductId)
							end)

							local v27 = v25:FindFirstChild("Content")
							local v28 = v27 and v27:FindFirstChild("TextLabel")

							if v28 then
								fetchRobuxPriceInto(v28, ProductId, Enum.InfoType.Product)
							end

							if v21.SkipSeconds then
								local Counter = v22:FindFirstChild("Counter", true)

								if Counter then
									table.insert(t6, {
										entry = v21,
										counter = Counter
									})
								end
							end

							continue
						end

						warn((("[Store] \"%*\".Content.%* is a %*, not a button"):format(v21.StoreEntry, v24, v25.ClassName)))

						continue
					end

					warn((("[Store] \"%*\".Content has no \"%*\" button"):format(v21.StoreEntry, v24)))

					continue
				end

				warn((("[Store] \"%*\" has no Content child"):format(v21.StoreEntry)))

				continue
			end

			warn((("[Store] no frame named \"%*\" under the store\'s ScrollingFrame"):format(v21.StoreEntry)))
		end
	end

	local function refreshSkipCounters() --[[ refreshSkipCounters | Line: 339 | Upvalues: FishEarnings (ref), LocalPlayer (copy), t6 (copy), CashDisplay (ref) ]]
		local v1 = FishEarnings.perSecond(LocalPlayer)

		for v2, v3 in t6 do
			CashDisplay.applyToLabel(v3.counter, v1 * v3.entry.SkipSeconds, {
				Prefix = "+",
				Compact = true
			})
		end
	end

	refreshSkipCounters()
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 347 ]]
		return p1.baseSlots
	end, refreshSkipCounters)
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 350 ]]
		return p1.rebirthLevel
	end, refreshSkipCounters)
	LocalPlayer:GetAttributeChangedSignal("CashMultiplier"):Connect(refreshSkipCounters)
	LocalPlayer:GetAttributeChangedSignal("FriendMultiplier"):Connect(refreshSkipCounters)

	local ExclusiveRod = ScrollingFrame:FindFirstChild("ExclusiveRod")

	if ExclusiveRod then
		local FISHROD_Trident = FishRodConfig.FISHROD_Trident

		if FISHROD_Trident and FISHROD_Trident.DevProduct then
			local DevProduct = FISHROD_Trident.DevProduct
			local v29 = ExclusiveRod:FindFirstChild("Content")
			local v30 = if v29 then v29:FindFirstChild("Buy1") else v29

			if v30 then
				v30.Activated:Connect(function() --[[ Line: 369 | Upvalues: ClientPlayerData (ref), MarketplaceService (ref), LocalPlayer (copy), DevProduct (copy) ]]
					local v1 = ClientPlayerData.serverProfile:getState()

					if not (if v1.inventory.FISHROD_Trident == nil then v1.fishRod == "FISHROD_Trident" else true) then
						MarketplaceService:PromptProductPurchase(LocalPlayer, DevProduct)
					end
				end)

				local v31 = v30:FindFirstChild("Content")
				local v32 = v31 and v31:FindFirstChild("TextLabel")

				local function refreshExclusiveRod() --[[ refreshExclusiveRod | Line: 381 | Upvalues: ClientPlayerData (ref), v32 (copy), fetchRobuxPriceInto (ref), DevProduct (copy) ]]
					local v1 = ClientPlayerData.serverProfile:getState()
					local v2 = if v1.inventory.FISHROD_Trident == nil then v1.fishRod == "FISHROD_Trident" else true

					if not v32 then
						return
					end

					if v2 then
						v32.Text = "OWNED"

						return
					end

					fetchRobuxPriceInto(v32, DevProduct, Enum.InfoType.Product)
				end

				local v33 = ClientPlayerData.serverProfile:getState()

				if v32 and (if v33.inventory.FISHROD_Trident == nil then v33.fishRod == "FISHROD_Trident" else true) then
					v32.Text = "OWNED"
				elseif v32 then
					fetchRobuxPriceInto(v32, DevProduct, Enum.InfoType.Product)
				end

				ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 394 ]]
					return p1.inventory
				end, refreshExclusiveRod)
				ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 397 ]]
					return p1.fishRod
				end, refreshExclusiveRod)
			end
		end
	end

	local t7 = {
		Chests = { "LuckyBlcok", "MountLuckyblock", "MythicalCreate" },
		Exclusives = { "PremiumFish", "ExclusiveRod" },
		Boosts = { "ServerLuck", "Skip24h", "SkipCash" },
		Passes = { "x2Mutationluck", "Gamepasses" }
	}

	local function isExclusiveCard(p1) --[[ isExclusiveCard | Line: 446 | Upvalues: t7 (copy) ]]
		for v1, v2 in t7.Exclusives do
			if p1:FindFirstAncestor(v2) then
				return true
			end
		end

		return false
	end

	local t8 = {
		LuckyBlockImg = true,
		GPIcon = true,
		Icon = true
	}
	local t9 = { "Chests", "Exclusives", "Boosts", "Passes" }

	for v35, v36 in ScrollingFrame:GetDescendants() do
		if v36:IsA("ImageLabel") then
			if v36.Name == "Shine" then
				v36:AddTag("VFX_PatternScroll")

				continue
			end

			if t8[v36.Name] then
				v36:AddTag("VFX_IconFloat")

				local v37 = false

				for v38, v39 in t7.Exclusives do
					if v36:FindFirstAncestor(v39) then
						v37 = true

						break
					end
				end

				if not v37 then
					v36:AddTag("VFX_IconHoverWiggle")
				end
			end
		end
	end

	local t10 = { "FreeGift", "PromocodeEntry", "Space" }
	local v40 = ColorSequence.new(Color3.fromRGB(117, 227, 0), Color3.fromRGB(31, 219, 0))
	local v41 = Color3.fromRGB(14, 136, 0)
	local Categories = Store2:FindFirstChild("Categories")

	if Categories then
		local t11 = {}
		local count = 0

		for v42, v43 in t9 do
			if t7[v43] then
				if not t11[v43] then
					count = count + 1
					t11[v43] = count
				end

				continue
			end

			warn((("[Store] CATEGORY_ORDER names \"%*\", which has no CATEGORY_CARDS entry"):format(v43)))
		end

		local t12 = {}

		for v44 in t7 do
			if not t11[v44] then
				table.insert(t12, v44)
				warn((("[Store] category \"%*\" is missing from CATEGORY_ORDER \226\128\148 placed after the ordered groups"):format(v44)))
			end
		end

		table.sort(t12)

		for v45, v46 in t12 do
			count = count + 1
			t11[v46] = count
		end

		local t13 = {}

		for v47 in t11 do
			table.insert(t13, v47)
		end

		table.sort(t13, function(p1, p2) --[[ Line: 543 | Upvalues: t11 (copy) ]]
			return t11[p1] < t11[p2]
		end)

		local t14 = {}
		local t15 = {}

		for v48, v49 in t7 do
			for v50, v51 in v49 do
				local v52 = ScrollingFrame:FindFirstChild(v51)

				if v52 and v52:IsA("GuiObject") then
					t15[v52] = v48
					v52.LayoutOrder = t11[v48] * 1000 + v50

					if not t5[v52] then
						local v53 = t14[v48]

						if not v53 then
							v53 = {}
							t14[v48] = v53
						end

						table.insert(v53, v52)
					end

					continue
				end

				warn(("[Store] category \"%*\" lists \"%*\", which is not a direct"):format(v48, v51) .. " child of the store\'s ScrollingFrame")
			end
		end

		local t16 = {}

		for v54, v55 in t10 do
			t16[v55] = true
		end

		for v56, v57 in ScrollingFrame:GetChildren() do
			if v57:IsA("GuiObject") and not t15[v57] then
				v57.LayoutOrder = v57.LayoutOrder + 100000

				if not t16[v57.Name] then
					warn(("[Store] \"%*\" is in no category \226\128\148 it sits below the last group, where no"):format(v57.Name) .. " tab reaches. Add it to CATEGORY_CARDS in Store.luau.")
				end
			end
		end

		local t17 = {}
		local t18 = {}
		local v58 = nil
		local t19 = {}
		local t20 = {}
		local t21 = {}
		local t22 = {}
		local t23 = {}
		local t24 = {}
		local v59 = nil
		local v60 = v40
		local v61 = v41
		local Buy1 = ScrollingFrame:FindFirstChild("Buy1", true)
		local v62 = if Buy1 then Buy1:FindFirstChild("Content") else Buy1
		local v63 = if v62 then v62:FindFirstChildOfClass("UIGradient") else v62
		local v64 = if Buy1 then Buy1:FindFirstChild("Frame") else Buy1

		if v63 and (v64 and v64:IsA("GuiObject")) then
			v60 = v63.Color
			v61 = v64.BackgroundColor3
		else
			warn("[Store] couldn\'t read a buy button\'s green \226\128\148 category tabs fall back to built-in colours")
		end

		local function sampleSequence(p1, p2) --[[ sampleSequence | Line: 625 ]]
			local Keypoints = p1.Keypoints

			if p2 <= Keypoints[1].Time then
				return Keypoints[1].Value
			end

			for i = 1, #Keypoints - 1 do
				local v1 = Keypoints[i]
				local v2 = Keypoints[i + 1]

				if p2 <= v2.Time then
					local v3 = v2.Time - v1.Time

					return v1.Value:Lerp(v2.Value, if v3 > 0 then (p2 - v1.Time) / v3 else 0)
				end
			end

			return Keypoints[#Keypoints].Value
		end

		local function blendSequence(p1, p2, p3) --[[ blendSequence | Line: 645 | Upvalues: sampleSequence (copy) ]]
			local t = {}
			local t2 = {}

			for v1, v2 in { p1, p2 } do
				for v3, v4 in v2.Keypoints do
					if not t[v4.Time] then
						t[v4.Time] = true
						table.insert(t2, v4.Time)
					end
				end
			end

			table.sort(t2)

			local v5 = table.create(#t2)

			for v6, v7 in t2 do
				v5[v6] = ColorSequenceKeypoint.new(v7, sampleSequence(p1, v7):Lerp(sampleSequence(p2, v7), p3))
			end

			return ColorSequence.new(v5)
		end

		local function applyAlpha(p1) --[[ applyAlpha | Line: 666 | Upvalues: t23 (copy), t19 (copy), t21 (copy), v60 (ref), blendSequence (copy), t20 (copy), t22 (copy), v61 (ref) ]]
			local v1 = t23[p1]
			local v2 = t19[p1]

			if v2 and v1 <= 0 then
				v2.Color = t21[p1]
			elseif v2 and v1 >= 1 then
				v2.Color = v60
			elseif v2 then
				v2.Color = blendSequence(t21[p1], v60, v1)
			end

			local v3 = t20[p1]

			if not v3 then
				return
			end

			v3.BackgroundColor3 = t22[p1]:Lerp(v61, v1)
		end

		local function startFade() --[[ startFade | Line: 690 | Upvalues: v59 (ref), RunService (ref), t23 (copy), t24 (copy), applyAlpha (copy) ]]
			if not v59 then
				v59 = RunService.Heartbeat:Connect(function(p13) --[[ Line: 694 | Upvalues: t23 (ref), t24 (ref), applyAlpha (ref), v59 (ref) ]]
					local v1 = p13 / 0.15
					local v2 = false

					for v4, v5 in t23 do
						local v3
						local v6 = t24[v4]

						if v5 ~= v6 then
							if math.abs(v6 - v5) <= v1 then
								v3 = v6
							else
								v3 = v5 + (if v5 < v6 then v1 else -v1)
								v2 = true
							end

							t23[v4] = v3
							applyAlpha(v4)
						end
					end

					if v2 or not v59 then
						return
					end

					v59:Disconnect()
					v59 = nil
				end)
			end
		end

		local function canvasTopOf(p1) --[[ canvasTopOf | Line: 724 | Upvalues: ScrollingFrame (copy) ]]
			return p1.AbsolutePosition.Y - ScrollingFrame.AbsolutePosition.Y + ScrollingFrame.CanvasPosition.Y
		end

		local UIPadding = ScrollingFrame:FindFirstChildOfClass("UIPadding")

		local function topPadding() --[[ topPadding | Line: 732 | Upvalues: UIPadding (copy), ScrollingFrame (copy) ]]
			if UIPadding then
				return UIPadding.PaddingTop.Offset + UIPadding.PaddingTop.Scale * ScrollingFrame.AbsoluteSize.Y
			end

			return 0
		end

		local function maxScrollY() --[[ maxScrollY | Line: 739 | Upvalues: ScrollingFrame (copy) ]]
			return math.max(0, ScrollingFrame.AbsoluteCanvasSize.Y - ScrollingFrame.AbsoluteWindowSize.Y)
		end

		local function anchorCard(p1) --[[ anchorCard | Line: 746 | Upvalues: t14 (copy) ]]
			local v1 = nil

			for v3, v4 in t14[p1] or {} do
				if v4.Visible and (v1 == nil or v4.AbsolutePosition.Y < v1.AbsolutePosition.Y) then
					v1 = v4
				end
			end

			return v1
		end

		local function categoryAtScroll() --[[ categoryAtScroll | Line: 760 | Upvalues: ScrollingFrame (copy), t18 (copy), anchorCard (copy), UIPadding (copy) ]]
			local Y = ScrollingFrame.CanvasPosition.Y
			local v2 = math.max(0, ScrollingFrame.AbsoluteCanvasSize.Y - ScrollingFrame.AbsoluteWindowSize.Y)

			if v2 > 0 and v2 - 4 <= Y then
				for i = #t18, 1, -1 do
					if anchorCard(t18[i]) then
						return t18[i]
					end
				end

				return nil
			end

			local v3 = (-1 / 0)
			local v4 = nil

			for v5, v6 in t18 do
				local v7 = anchorCard(v6)

				if v7 then
					local v10 = v7.AbsolutePosition.Y - ScrollingFrame.AbsolutePosition.Y + ScrollingFrame.CanvasPosition.Y - (if UIPadding then UIPadding.PaddingTop.Offset + UIPadding.PaddingTop.Scale * ScrollingFrame.AbsoluteSize.Y else 0)

					if v10 <= Y + 4 and v3 < v10 then
						v3 = v10
						v4 = v6
					end
				end
			end

			return if v4 then v4 else t18[1]
		end

		local function highlightTab(p1, p2) --[[ highlightTab | Line: 789 | Upvalues: v58 (ref), t17 (copy), t24 (copy), t23 (copy), applyAlpha (copy), v59 (ref), RunService (ref) ]]
			if p1 == nil or v58 == p1 and not p2 then
				return
			end

			v58 = p1

			local v1 = false

			for v2, v3 in t17 do
				local v4 = if v2 == p1 then 1 else 0

				t24[v3] = v4

				if p2 then
					t23[v3] = v4
					applyAlpha(v3)

					continue
				end

				if t23[v3] ~= v4 then
					v1 = true
				end
			end

			if not v1 then
				return
			end

			if v59 then
				return
			end

			v59 = RunService.Heartbeat:Connect(function(p13) --[[ Line: 694 | Upvalues: t23 (ref), t24 (ref), applyAlpha (ref), v59 (ref) ]]
				local v1 = p13 / 0.15
				local v2 = false

				for v4, v5 in t23 do
					local v3
					local v6 = t24[v4]

					if v5 ~= v6 then
						if math.abs(v6 - v5) <= v1 then
							v3 = v6
						else
							v3 = v5 + (if v5 < v6 then v1 else -v1)
							v2 = true
						end

						t23[v4] = v3
						applyAlpha(v4)
					end
				end

				if v2 or not v59 then
					return
				end

				v59:Disconnect()
				v59 = nil
			end)
		end

		local v65 = nil
		local v66 = false

		local function jumpToCategory(p1) --[[ jumpToCategory | Line: 821 | Upvalues: anchorCard (copy), v58 (ref), t17 (copy), t24 (copy), t23 (copy), v59 (ref), RunService (ref), applyAlpha (copy), v65 (ref), ScrollingFrame (copy), UIPadding (copy), v66 (ref), TweenService (ref) ]]
			local v1 = anchorCard(p1)

			if not v1 then
				return
			end

			if p1 ~= nil and v58 ~= p1 then
				v58 = p1

				local v2 = false

				for v3, v4 in t17 do
					local v5 = if v3 == p1 then 1 else 0

					t24[v4] = v5

					if t23[v4] ~= v5 then
						v2 = true
					end
				end

				if v2 and not v59 then
					v59 = RunService.Heartbeat:Connect(function(p13) --[[ Line: 694 | Upvalues: t23 (ref), t24 (ref), applyAlpha (ref), v59 (ref) ]]
						local v1 = p13 / 0.15
						local v2 = false

						for v4, v5 in t23 do
							local v3
							local v6 = t24[v4]

							if v5 ~= v6 then
								if math.abs(v6 - v5) <= v1 then
									v3 = v6
								else
									v3 = v5 + (if v5 < v6 then v1 else -v1)
									v2 = true
								end

								t23[v4] = v3
								applyAlpha(v4)
							end
						end

						if v2 or not v59 then
							return
						end

						v59:Disconnect()
						v59 = nil
					end)
				end
			end

			if v65 then
				v65:Cancel()
			end

			local v12 = Vector2.new(ScrollingFrame.CanvasPosition.X, (math.clamp(v1.AbsolutePosition.Y - ScrollingFrame.AbsolutePosition.Y + ScrollingFrame.CanvasPosition.Y - (if UIPadding then UIPadding.PaddingTop.Offset + UIPadding.PaddingTop.Scale * ScrollingFrame.AbsoluteSize.Y else 0), 0, (math.max(0, ScrollingFrame.AbsoluteCanvasSize.Y - ScrollingFrame.AbsoluteWindowSize.Y)))))

			v66 = true

			local v13 = TweenService:Create(ScrollingFrame, TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				CanvasPosition = v12
			})

			v65 = v13
			v13.Completed:Once(function() --[[ Line: 842 | Upvalues: v65 (ref), v13 (copy), v66 (ref) ]]
				if v65 ~= v13 then
					return
				end

				v65 = nil
				v66 = false
			end)
			v13:Play()
		end

		ScrollingFrame:GetPropertyChangedSignal("CanvasPosition"):Connect(function() --[[ Line: 856 | Upvalues: v66 (ref), categoryAtScroll (copy), v58 (ref), t17 (copy), t24 (copy), t23 (copy), v59 (ref), RunService (ref), applyAlpha (copy) ]]
			if v66 then
				return
			end

			local v1 = categoryAtScroll()

			if v1 == nil then
				return
			end

			if v58 == v1 then
				return
			end

			v58 = v1

			local v2 = false

			for v3, v4 in t17 do
				local v5 = if v3 == v1 then 1 else 0

				t24[v4] = v5

				if t23[v4] ~= v5 then
					v2 = true
				end
			end

			if not v2 then
				return
			end

			if v59 then
				return
			end

			v59 = RunService.Heartbeat:Connect(function(p13) --[[ Line: 694 | Upvalues: t23 (ref), t24 (ref), applyAlpha (ref), v59 (ref) ]]
				local v1 = p13 / 0.15
				local v2 = false

				for v4, v5 in t23 do
					local v3
					local v6 = t24[v4]

					if v5 ~= v6 then
						if math.abs(v6 - v5) <= v1 then
							v3 = v6
						else
							v3 = v5 + (if v5 < v6 then v1 else -v1)
							v2 = true
						end

						t23[v4] = v3
						applyAlpha(v4)
					end
				end

				if v2 or not v59 then
					return
				end

				v59:Disconnect()
				v59 = nil
			end)
		end)

		for v67, v68 in Categories:GetChildren() do
			if v68:IsA("GuiButton") and not t7[v68.Name] then
				warn((("[Store] category button \"%*\" has no entry in CATEGORY_CARDS in Store.luau"):format(v68.Name)))
			end
		end

		for v69, v70 in t13 do
			local v71 = Categories:FindFirstChild(v70)

			if v71 and v71:IsA("GuiButton") then
				v71.LayoutOrder = t11[v70]

				if t14[v70] then
					t17[v70] = v71
					table.insert(t18, v70)
					t23[v71] = 0
					t24[v71] = 0

					local UIGradient = v71:FindFirstChildOfClass("UIGradient")

					if UIGradient then
						t19[v71] = UIGradient
						t21[v71] = UIGradient.Color
					end

					local DesignLine = v71:FindFirstChild("DesignLine")

					if DesignLine and DesignLine:IsA("Frame") then
						t20[v71] = DesignLine
						t22[v71] = DesignLine.BackgroundColor3
					end

					if not (UIGradient or t20[v71]) then
						warn(("[Store] category button \"%*\" has neither a UIGradient nor a DesignLine"):format(v70) .. " \226\128\148 it won\'t show a selected state")
					end

					v71:AddTag("VFX_HoverSound")
					v71:AddTag("VFX_UIClickButton")
					v71.Activated:Connect(function() --[[ Line: 919 | Upvalues: jumpToCategory (copy), v70 (copy) ]]
						jumpToCategory(v70)
					end)

					continue
				end

				v71.Visible = false
			end
		end

		if t18[1] then
			highlightTab(t18[1], true)
		end

		local function cycleCategory(p1) --[[ cycleCategory | Line: 942 | Upvalues: t18 (copy), v58 (ref), jumpToCategory (copy) ]]
			if #t18 <= 1 then
				return
			end

			local v1 = if v58 then table.find(t18, v58) else nil

			jumpToCategory(t18[if v1 then (v1 - 1 + p1) % #t18 + 1 else 1])
		end

		local v72 = nil
		local v73 = if #t18 > 0 then t17[t18[#t18]] else nil

		if v73 then
			v72 = ControlHint.new({
				label = "Switch",
				below = true,
				anchorTo = v73,
				keyCode = Enum.KeyCode.ButtonR1
			})
		end

		v1.Visible.OnChange:Connect(function(p1) --[[ Line: 969 | Upvalues: bindToButtonPress (ref), t18 (copy), v58 (ref), jumpToCategory (copy), v72 (ref), ContextActionService (ref) ]]
			if p1 then
				bindToButtonPress("StoreCategoryPrev", Enum.KeyCode.ButtonL1, function() --[[ Line: 971 | Upvalues: t18 (ref), v58 (ref), jumpToCategory (ref) ]]
					if #t18 <= 1 then
						return
					end

					local v1 = if v58 then table.find(t18, v58) else nil

					jumpToCategory(t18[if v1 then (v1 - 1 + -1) % #t18 + 1 else 1])
				end)
				bindToButtonPress("StoreCategoryNext", Enum.KeyCode.ButtonR1, function() --[[ Line: 974 | Upvalues: t18 (ref), v58 (ref), jumpToCategory (ref) ]]
					if #t18 <= 1 then
						return
					end

					local v1 = if v58 then table.find(t18, v58) else nil

					jumpToCategory(t18[if v1 then (v1 - 1 + 1) % #t18 + 1 else 1])
				end)

				if v72 then
					v72:Show()
				end
			else
				ContextActionService:UnbindAction("StoreCategoryPrev")
				ContextActionService:UnbindAction("StoreCategoryNext")

				if not v72 then
					return
				end

				v72:Hide()
			end
		end)
	else
		warn("[Store] no \"Categories\" frame under the Store \226\128\148 the list still shows every card, there are just no jump buttons")
	end

	local v74 = ScrollingFrame:QueryDescendants("ImageLabel#PromocodeEntry >> TextBox#CodeBox")[1]
	local v75 = ScrollingFrame:QueryDescendants("ImageLabel#PromocodeEntry >> ImageButton#Redeem")[1]

	if v74 and v75 then
		local v76 = false

		v75.Activated:Connect(function() --[[ Line: 1000 | Upvalues: v76 (ref), v74 (copy), notifications (ref), Remotes (ref) ]]
			if not v76 and v74.Text ~= "" then
				v76 = true
				task.delay(2, function() --[[ Line: 1009 | Upvalues: v76 (ref) ]]
					v76 = false
				end)
				Remotes.RequestCodeRedeem:Fire(v74.Text)

				return
			end

			if not v76 then
				return
			end

			notifications:Send("You are clicking too fast! Try again in a few seconds.")
		end)

		local function updateStorePity() --[[ updateStorePity | Line: 1018 | Upvalues: ClientPlayerData (ref), luckyblockCards (ref), ScrollingFrame (copy) ]]
			local v1 = ClientPlayerData.serverProfile:getState()

			for v2, v3 in luckyblockCards() do
				local v4 = ScrollingFrame:FindFirstChild(v3.frameName, true)

				if v4 then
					local v5 = v1.luckyblockPity and v1.luckyblockPity[v3.configName] or 0
					local v6 = v4:FindFirstChild("PityLabel", true) or (v4:FindFirstChild("PityText", true) or v4:FindFirstChild("Pity", true))

					if v6 then
						v6.Text = ("%*/20"):format(v5)
					end

					local v7 = v4:FindFirstChild("PityBar", true) or (v4:FindFirstChild("PityProgress", true) or v4:FindFirstChild("ProgressBar", true))

					if v7 then
						local v8 = v7:FindFirstChild("Fill", true) or (v7:FindFirstChild("Progress", true) or v7:FindFirstChild("Bar", true))

						if v8 then
							v8.Size = UDim2.fromScale(math.clamp(v5 / 20, 0, 1), 1)

							continue
						end

						v7.Size = UDim2.new(math.clamp(v5 / 20, 0, 1), 0, v7.Size.Y.Scale, v7.Size.Y.Offset)
					end
				end
			end
		end

		updateStorePity()
		ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 1055 ]]
			return p1.luckyblockPity
		end, updateStorePity)
	end
end

return t