-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local Debris = game:GetService("Debris")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

game:GetService("ServerScriptService")

local SoundService = game:GetService("SoundService")
local TweenService = game:GetService("TweenService")
local ActiveEffects = require(ReplicatedStorage.shared.effects.ActiveEffects)
local AnimationConfig = require(ReplicatedStorage.shared.config.AnimationConfig)

require(ReplicatedStorage.shared.UECS.Components.Animator)

local ConvertValue = require(ReplicatedStorage.shared.util.ConvertValue)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local GymEventConfig = require(ReplicatedStorage.shared.config.GymEventConfig)
local GymEventState = require(ReplicatedStorage.client.GymEventState)
local Remotes = require(ReplicatedStorage.shared.Remotes)

require(ReplicatedStorage.client.SFX)
require(ReplicatedStorage.shared.UECS.Components.TrainToolComponent)

local UECS = require(ReplicatedStorage.shared.UECS.UECS)
local VFX = require(ReplicatedStorage.client.VFX)
local getGardenDecorationEffects = require(ReplicatedStorage.shared.util.getGardenDecorationEffects)
local getPotionMultiplier = require(ReplicatedStorage.shared.util.getPotionMultiplier)
local getRebirthStrengthMultiplier = require(ReplicatedStorage.shared.util.getRebirthStrengthMultiplier)
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local EnchantConfig = require(ReplicatedStorage.shared.config.EnchantConfig)
local getRodEnchantBonus = require(ReplicatedStorage.shared.util.getRodEnchantBonus)
local notifications = require(ReplicatedStorage.shared.module.notifications)
local v1 = NumberRange.new(4, 10)
local v2 = NumberRange.new(0.3, 1)
local v3 = UDim2.fromScale(2, 2)

local function randomInRange(p1) --[[ randomInRange | Line: 46 ]]
	return p1.Min + math.random() * (p1.Max - p1.Min)
end

local function isTrainingCharacter(p1) --[[ isTrainingCharacter | Line: 54 ]]
	if not p1 then
		return false
	end

	for v1, v2 in p1:GetChildren() do
		if v2:IsA("Tool") and v2:GetAttribute("IsTrainingTool") then
			return true
		end
	end

	return false
end

local function estimateGymBuddyBonus() --[[ estimateGymBuddyBonus | Line: 69 | Upvalues: Players (copy), getRodEnchantBonus (copy), EnchantConfig (copy), ClientPlayerData (copy), isTrainingCharacter (copy) ]]
	local LocalPlayer = Players.LocalPlayer
	local v1 = getRodEnchantBonus(LocalPlayer, "GymBuddy")
	local v2 = EnchantConfig.GetRodBonusSecondary(ClientPlayerData.serverProfile:getState(), "GymBuddy")

	if v1 <= 0 or v2 <= 0 then
		return 0
	end

	local Character = LocalPlayer.Character
	local v3 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character

	if not v3 then
		return 0
	end

	local sum = 0

	for v4, v5 in Players:GetPlayers() do
		if v5 ~= LocalPlayer then
			local v6 = v5.Character and v5.Character:FindFirstChild("HumanoidRootPart")

			if v6 and ((v6.Position - v3.Position).Magnitude <= v1 and isTrainingCharacter(v5.Character)) then
				sum = sum + v2 / 100
			end
		end
	end

	return sum
end

local function spawnFloatingTrainingImage(p1, p2, p3) --[[ spawnFloatingTrainingImage | Line: 105 | Upvalues: v3 (copy), TweenService (copy), Debris (copy) ]]
	local v1 = Vector3.new(p1.LookVector.X, 0, p1.LookVector.Z)
	local v2 = if v1.Magnitude > 0.01 then v1.Unit else Vector3.new(0, 0, -1)
	local v4 = Vector3.new(-v2.Z, 0, v2.X)
	local v5 = 0.75 + math.random() * 0.25
	local v6 = math.cos(p3) * v5 * 7
	local v7 = math.sin(p3) * v5 * 7
	local v9 = v4 * v6 + v2 * v7 + Vector3.new(0, (math.random() * 2 - 1) * 3, 0)
	local Position = p1.Position
	local v10 = Position + v9
	local v11 = v10 + Vector3.new(0, 3, 0)
	local Part = Instance.new("Part")

	Part.Anchored = true
	Part.CanCollide = false
	Part.CanQuery = false
	Part.CanTouch = false
	Part.Transparency = 1
	Part.Size = Vector3.new(0.1, 0.1, 0.1)
	Part.CFrame = CFrame.new(Position)
	Part.Parent = workspace

	local BillboardGui = Instance.new("BillboardGui")

	BillboardGui.Size = UDim2.fromScale(v3.X.Scale * p2, v3.Y.Scale * p2)
	BillboardGui.Adornee = Part
	BillboardGui.LightInfluence = 0
	BillboardGui.Parent = Part

	local ImageLabel = Instance.new("ImageLabel")

	ImageLabel.BackgroundTransparency = 1
	ImageLabel.Size = UDim2.fromScale(1, 1)
	ImageLabel.Image = "rbxassetid://74296054673146"

	local v12 = (math.random() * 2 - 1) * 45

	ImageLabel.Rotation = v12
	ImageLabel.Parent = BillboardGui

	local v13 = TweenInfo.new(0.6, Enum.EasingStyle.Quint, Enum.EasingDirection.Out)
	local v14 = TweenInfo.new(1.2000000000000002, Enum.EasingStyle.Linear)

	TweenService:Create(ImageLabel, TweenInfo.new(1.8, Enum.EasingStyle.Linear), {
		Rotation = v12 + (math.random() * 2 - 1) * 50
	}):Play()

	local v15 = TweenService:Create(Part, v13, {
		CFrame = CFrame.new(v10)
	})

	v15.Completed:Connect(function(p1) --[[ Line: 160 | Upvalues: Part (copy), TweenService (ref), v14 (copy), v11 (copy) ]]
		if p1 == Enum.PlaybackState.Completed and Part.Parent then
			TweenService:Create(Part, v14, {
				CFrame = CFrame.new(v11)
			}):Play()
		end
	end)
	v15:Play()
	task.delay(1.2, function() --[[ Line: 168 | Upvalues: TweenService (ref), ImageLabel (copy) ]]
		TweenService:Create(ImageLabel, TweenInfo.new(0.6000000000000001, Enum.EasingStyle.Linear), {
			ImageTransparency = 1
		}):Play()
	end)
	Debris:AddItem(Part, 2.3)
end

local function playTrainingFloatingImages(p1) --[[ playTrainingFloatingImages | Line: 179 | Upvalues: v1 (copy), spawnFloatingTrainingImage (copy), v2 (copy) ]]
	local v12 = math.random(v1.Min, v1.Max)
	local v22 = math.random() * 2 * math.pi
	local v3 = 6.283185307179586 / v12

	for i = 0, v12 - 1 do
		local v4 = v2

		spawnFloatingTrainingImage(p1.CFrame, v4.Min + math.random() * (v4.Max - v4.Min), v22 + i * v3 + 0)
	end
end

local function getEmitDelay(p1) --[[ getEmitDelay | Line: 192 ]]
	local v1 = string.match(p1, "^Fire(%d+)$")

	if not v1 then
		return 0
	end

	local v2 = tonumber(v1) or 1

	if v2 < 2 then
		return 0
	end

	return (v2 - 1) * 0.1
end

local function playTrainingVFX(p1) --[[ playTrainingVFX | Line: 207 | Upvalues: VFX (copy), Debris (copy) ]]
	local v1 = VFX.Attach("Training_fx", p1)

	if not v1 then
		return
	end

	local v2 = 0
	local v3 = 0

	for v5, v6 in v1:GetDescendants() do
		local v4

		if v6:IsA("ParticleEmitter") then
			if v2 < v6.Lifetime.Max then
				v2 = v6.Lifetime.Max
			end

			local v7 = v6:GetAttribute("EmitCount")
			local v8 = if typeof(v7) == "number" then v7 else 1
			local v10 = string.match(v6.Name, "^Fire(%d+)$")

			if v10 then
				local v11 = tonumber(v10) or 1

				v4 = if v11 < 2 then 0 else (v11 - 1) * 0.1
			else
				v4 = 0
			end

			if v3 < v4 then
				v3 = v4
			end

			if v4 > 0 then
				task.delay(v4, function() --[[ Line: 228 | Upvalues: v6 (copy), v8 (copy) ]]
					if not v6.Parent then
						return
					end

					v6:Emit(v8)
				end)

				continue
			end

			v6:Emit(v8)

			continue
		end

		if v6:IsA("Trail") and v2 < v6.Lifetime then
			v2 = v6.Lifetime
		end
	end

	Debris:AddItem(v1, v3 + v2 + 0.5)
end

local function playTrainingSFX() --[[ playTrainingSFX | Line: 244 | Upvalues: SoundService (copy) ]]
	local SFX = SoundService:FindFirstChild("SFX")
	local v1 = if SFX then SFX:FindFirstChild("Training") else SFX

	if v1 and v1:IsA("Sound") then
		local v2 = v1:Clone()

		v2.Volume = 0.5
		v2.PlayOnRemove = true
		v2.Parent = SoundService
		v2:Destroy()
	end
end

local Base = ReplicatedStorage.shared.model.Tycoon.Base
local v4 = TweenInfo.new(0.3, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
local v5 = TweenInfo.new(0.18, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
local v6 = TweenInfo.new(1.1, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true)
local v7 = Color3.fromRGB(180, 100, 255)
local v8 = Color3.fromRGB(255, 196, 60)
local v9 = TweenInfo.new(1.4, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true)
local v10 = TweenInfo.new(0.32, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
local v11 = TweenInfo.new(0.45, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
local v12 = Color3.fromRGB(255, 70, 70)
local v13 = Color3.fromRGB(150, 0, 0)

local function estimateGymMultiplier() --[[ estimateGymMultiplier | Line: 291 | Upvalues: GymEventState (copy), Players (copy), GymEventConfig (copy), CollectionService (copy) ]]
	local v1 = GymEventState.Get()

	if not v1 then
		return 1
	end

	local v2 = Players.LocalPlayer and Players.LocalPlayer.Character
	local v3 = if v2 then v2:FindFirstChild("HumanoidRootPart") else v2

	if not v3 then
		return 1
	end

	local buff = v1.buff

	if buff then
		local Radius = GymEventConfig.TrainingZone.Radius

		for v4, v5 in CollectionService:GetTagged(GymEventConfig.Tags.TrainingZone) do
			if v5:IsA("BasePart") and (v3.Position - v5.Position).Magnitude <= Radius then
				return buff.multiplier
			end
		end

		return 1
	end

	local miniGym = v1.miniGym

	if miniGym and (miniGym.pivot and (v3.Position - miniGym.pivot.Position).Magnitude <= GymEventConfig.MiniGym.Radius) then
		return miniGym.multiplier
	end

	return 1
end

local t = {
	UECS = nil
}

function t.Init(p1) --[[ Init | Line: 329 | Upvalues: GymEventState (copy), Players (copy), CollectionService (copy), TweenService (copy), v9 (copy), v10 (copy), v12 (copy), v13 (copy), v11 (copy), v8 (copy), v7 (copy), ConvertValue (copy), v5 (copy), v4 (copy), v6 (copy), Remotes (copy), playTrainingSFX (copy), playTrainingVFX (copy), playTrainingFloatingImages (copy), t (copy), estimateGymMultiplier (copy), ActiveEffects (copy), getPotionMultiplier (copy), getRebirthStrengthMultiplier (copy), getGardenDecorationEffects (copy), getRodEnchantBonus (copy), estimateGymBuddyBonus (copy), notifications (copy), ReplicatedStorage (copy), isTrainingCharacter (copy), AnimationConfig (copy), UECS (copy) ]]
	GymEventState.Start()

	local LocalPlayer = Players.LocalPlayer
	local MainUI = LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("MainUI")
	local HUD = MainUI:WaitForChild("HUD")
	local Effects = MainUI:WaitForChild("Effects")
	local Templates = Effects:WaitForChild("Templates")
	local ClickBonus = Templates:WaitForChild("ClickBonus")
	local ClickBonusExtra = Templates:WaitForChild("ClickBonusExtra")
	local StrengthGain = HUD.Effects.StrengthGain
	local v1 = nil
	local v2 = nil
	local v3 = nil
	local Streak = Effects:WaitForChild("Streak")
	local UIStroke = Streak:FindFirstChildOfClass("UIStroke")
	local ComboText = Streak:FindFirstChild("ComboText")
	local TextColor3 = Streak.TextColor3
	local v42 = UIStroke and UIStroke.Color or Color3.new()
	local TextTransparency = Streak.TextTransparency
	local v52 = UIStroke and UIStroke.Transparency or 0

	local function setComboTextRainbow(p1) --[[ setComboTextRainbow | Line: 368 | Upvalues: ComboText (copy), CollectionService (ref) ]]
		if not ComboText then
			return
		end

		if p1 then
			ComboText.Visible = true
			CollectionService:AddTag(ComboText, "VFX_RainbowText")
		else
			ComboText.Visible = false
			CollectionService:RemoveTag(ComboText, "VFX_RainbowText")
		end
	end

	Streak.Visible = false
	Streak.Rotation = 0

	local UIScale = Streak:FindFirstChildOfClass("UIScale")

	if not UIScale then
		UIScale = Instance.new("UIScale")
		UIScale.Scale = 1
		UIScale.Parent = Streak
	end

	local v62 = nil

	local function startStreakIdle() --[[ startStreakIdle | Line: 395 | Upvalues: v62 (ref), Streak (copy), TweenService (ref), v9 (ref) ]]
		if not v62 then
			Streak.Rotation = -4
			v62 = TweenService:Create(Streak, v9, {
				Rotation = 4
			})
			v62:Play()
		end
	end

	local function stopStreakIdle() --[[ stopStreakIdle | Line: 404 | Upvalues: v62 (ref) ]]
		if not v62 then
			return
		end

		v62:Cancel()
		v62 = nil
	end

	local function resetStreakLabelStyle() --[[ resetStreakLabelStyle | Line: 411 | Upvalues: Streak (copy), TextColor3 (copy), TextTransparency (copy), UIStroke (copy), v42 (copy), v52 (copy), UIScale (ref) ]]
		Streak.TextColor3 = TextColor3
		Streak.TextTransparency = TextTransparency

		if not UIStroke then
			Streak.Rotation = 0
			UIScale.Scale = 1

			return
		end

		UIStroke.Color = v42
		UIStroke.Transparency = v52
		Streak.Rotation = 0
		UIScale.Scale = 1
	end

	local function playStreakGrow() --[[ playStreakGrow | Line: 422 | Upvalues: UIScale (ref), TweenService (ref), v10 (ref) ]]
		UIScale.Scale = 1.55
		TweenService:Create(UIScale, v10, {
			Scale = 1
		}):Play()
	end

	local v72 = 0

	local function playStreakFail() --[[ playStreakFail | Line: 431 | Upvalues: v62 (ref), v72 (ref), Streak (copy), v12 (ref), UIStroke (copy), v13 (ref), TweenService (ref), v11 (ref), TextColor3 (copy), TextTransparency (copy), v42 (copy), v52 (copy), UIScale (ref) ]]
		if v62 then
			v62:Cancel()
			v62 = nil
		end

		v72 = v72 + 1

		local v1 = v72

		Streak.TextColor3 = v12

		if UIStroke then
			UIStroke.Color = v13
		end

		TweenService:Create(Streak, v11, {
			TextTransparency = 1,
			Rotation = Streak.Rotation + math.random(-25, 25)
		}):Play()

		if not UIStroke then
			task.delay(v11.Time + 0.05, function() --[[ Line: 447 | Upvalues: v72 (ref), v1 (copy), Streak (ref), TextColor3 (ref), TextTransparency (ref), UIStroke (ref), v42 (ref), v52 (ref), UIScale (ref) ]]
				if v72 ~= v1 then
					return
				end

				Streak.Visible = false
				Streak.TextColor3 = TextColor3
				Streak.TextTransparency = TextTransparency

				if UIStroke then
					UIStroke.Color = v42
					UIStroke.Transparency = v52
				end

				Streak.Rotation = 0
				UIScale.Scale = 1
			end)

			return
		end

		TweenService:Create(UIStroke, v11, {
			Transparency = 1
		}):Play()
		task.delay(v11.Time + 0.05, function() --[[ Line: 447 | Upvalues: v72 (ref), v1 (copy), Streak (ref), TextColor3 (ref), TextTransparency (ref), UIStroke (ref), v42 (ref), v52 (ref), UIScale (ref) ]]
			if v72 ~= v1 then
				return
			end

			Streak.Visible = false
			Streak.TextColor3 = TextColor3
			Streak.TextTransparency = TextTransparency

			if UIStroke then
				UIStroke.Color = v42
				UIStroke.Transparency = v52
			end

			Streak.Rotation = 0
			UIScale.Scale = 1
		end)
	end

	local v82 = 0

	local function setStreak(p1, p2) --[[ setStreak | Line: 457 | Upvalues: v82 (ref), ComboText (copy), CollectionService (ref), playStreakFail (copy), Streak (copy), TextColor3 (copy), TextTransparency (copy), UIStroke (copy), v42 (copy), v52 (copy), UIScale (ref), v72 (ref), v62 (ref), TweenService (ref), v9 (ref), v10 (ref) ]]
		local v1 = v82

		v82 = p1

		if p2 == "miss" then
			if ComboText then
				ComboText.Visible = false
				CollectionService:RemoveTag(ComboText, "VFX_RainbowText")
			end

			if v1 >= 2 then
				playStreakFail()

				return
			end

			Streak.Visible = false
			Streak.TextColor3 = TextColor3
			Streak.TextTransparency = TextTransparency

			if UIStroke then
				UIStroke.Color = v42
				UIStroke.Transparency = v52
			end

			Streak.Rotation = 0
			UIScale.Scale = 1
		elseif p1 < 2 then
			if ComboText then
				ComboText.Visible = false
				CollectionService:RemoveTag(ComboText, "VFX_RainbowText")
			end

			Streak.Visible = false
			Streak.TextColor3 = TextColor3
			Streak.TextTransparency = TextTransparency

			if UIStroke then
				UIStroke.Color = v42
				UIStroke.Transparency = v52
			end

			Streak.Rotation = 0
			UIScale.Scale = 1
		else
			v72 = v72 + 1
			Streak.TextColor3 = TextColor3
			Streak.TextTransparency = TextTransparency

			if UIStroke then
				UIStroke.Color = v42
				UIStroke.Transparency = v52
			end

			Streak.Rotation = 0
			UIScale.Scale = 1
			Streak.Text = ("x%*"):format(p1)
			Streak.Visible = true

			if ComboText then
				ComboText.Visible = true
				CollectionService:AddTag(ComboText, "VFX_RainbowText")
			end

			if not v62 then
				Streak.Rotation = -4
				v62 = TweenService:Create(Streak, v9, {
					Rotation = 4
				})
				v62:Play()
			end

			UIScale.Scale = 1.55
			TweenService:Create(UIScale, v10, {
				Scale = 1
			}):Play()
		end
	end

	local function pickButtonPosition() --[[ pickButtonPosition | Line: 497 | Upvalues: MainUI (copy) ]]
		local AbsoluteSize = MainUI.AbsoluteSize
		local v1 = AbsoluteSize.X * 0.2
		local v2 = AbsoluteSize.Y * 0.2
		local v3 = v1 + math.random() * (AbsoluteSize.X - v1 * 2)

		return UDim2.fromOffset(v3, v2 + math.random() * (AbsoluteSize.Y - v2 * 2))
	end

	local function recolorGradients(p1, p2) --[[ recolorGradients | Line: 506 ]]
		local v1 = p2:Lerp(Color3.new(255/255, 255/255, 255/255), 0.35)
		local v2 = p2:Lerp(Color3.new(0/255, 0/255, 0/255), 0.25)
		local v3 = ColorSequence.new({ ColorSequenceKeypoint.new(0, v1), ColorSequenceKeypoint.new(1, v2) })

		for v4, v5 in p1:GetDescendants() do
			if v5:IsA("UIGradient") then
				v5.Color = v3
			end
		end
	end

	local function playStrengthGainAt(p1, p2, p3) --[[ playStrengthGainAt | Line: 524 | Upvalues: StrengthGain (copy), v8 (ref), v7 (ref), ConvertValue (ref), recolorGradients (copy), HUD (copy), TweenService (ref) ]]
		local v1 = StrengthGain:Clone()

		v1.Parent = StrengthGain.Parent

		local v2 = if p3 then v8 else v7

		v1.Increase.Text = ("+%* Throw"):format((ConvertValue.suffixformat(p2)))
		v1.Increase.TextColor3 = v2
		v1.Icon.Image = "rbxassetid://105498481785805"

		local UIScale = Instance.new("UIScale")

		UIScale.Scale = 1.5
		UIScale.Parent = v1.Icon
		recolorGradients(v1, v2)

		local AbsolutePosition = HUD.AbsolutePosition
		local AbsoluteSize = v1.AbsoluteSize

		v1.Position = UDim2.fromOffset(p1.X - AbsolutePosition.X - AbsoluteSize.X / 2, p1.Y - AbsolutePosition.Y - AbsoluteSize.Y / 2)
		v1.Rotation = math.random(-20, 20)
		v1.Visible = true
		task.delay(0.45, function() --[[ Line: 543 | Upvalues: HUD (ref), AbsoluteSize (copy), TweenService (ref), v1 (copy), AbsolutePosition (copy) ]]
			local Strength = HUD.Counters.Strength
			local v12 = Strength.AbsolutePosition + Strength.AbsoluteSize / 2
			local v2 = AbsoluteSize * 0.4
			local v3 = TweenService:Create(v1, TweenInfo.new(0.55, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
				Rotation = 0,
				Position = UDim2.fromOffset(v12.X - AbsolutePosition.X - v2.X / 2, v12.Y - AbsolutePosition.Y - v2.Y / 2),
				Size = UDim2.fromOffset(v2.X, v2.Y)
			})

			v3:Play()
			v3.Completed:Connect(function() --[[ Line: 560 | Upvalues: v1 (ref) ]]
				v1:Destroy()
			end)
		end)
	end

	local function clearCurrentButton() --[[ clearCurrentButton | Line: 566 | Upvalues: v3 (ref), v2 (ref) ]]
		if v3 then
			task.cancel(v3)
			v3 = nil
		end

		local v1 = v2

		v2 = nil

		if not v1 then
			return
		end

		v1:Destroy()
	end

	local function findClickTarget(p1) --[[ findClickTarget | Line: 578 ]]
		if p1:IsA("GuiButton") then
			return p1
		end

		for v1, v2 in p1:GetDescendants() do
			if v2:IsA("GuiButton") then
				return v2
			end
		end

		error((("ClickBonus template \'%*\' has no GuiButton (ImageButton/TextButton) descendant"):format((p1:GetFullName()))))
	end

	local function animateButtonOut(p1, p2, p3) --[[ animateButtonOut | Line: 590 | Upvalues: TweenService (ref), v5 (ref) ]]
		TweenService:Create(p2, v5, {
			Scale = 0
		}):Play()
		task.delay(v5.Time, function() --[[ Line: 592 | Upvalues: p1 (copy), p3 (copy) ]]
			p1:Destroy()

			if not p3 then
				return
			end

			p3()
		end)
	end

	local function showClickBonus(p1, p2, p3, p4, p5) --[[ showClickBonus | Line: 603 | Upvalues: v3 (ref), v2 (ref), ClickBonusExtra (copy), ClickBonus (copy), pickButtonPosition (copy), MainUI (copy), findClickTarget (copy), TweenService (ref), v4 (ref), v6 (ref), animateButtonOut (copy), Remotes (ref), playTrainingSFX (ref), LocalPlayer (copy), playTrainingVFX (ref), playTrainingFloatingImages (ref), v1 (ref), t (ref), estimateGymMultiplier (ref), ActiveEffects (ref), getPotionMultiplier (ref), getRebirthStrengthMultiplier (ref), getGardenDecorationEffects (ref), getRodEnchantBonus (ref), estimateGymBuddyBonus (ref), playStrengthGainAt (copy) ]]
		if v3 then
			task.cancel(v3)
			v3 = nil
		end

		local v12 = v2

		v2 = nil

		if v12 then
			v12:Destroy()
		end

		local v22 = if p3 == "extra" then true else p5 == true
		local v42 = if p4 then p4 elseif v22 then 4 else 2
		local v5 = (if v22 then ClickBonusExtra else ClickBonus):Clone()

		v5.Name = if v22 then "ClickBonusExtra" else "ClickBonus"
		v5.AnchorPoint = Vector2.new(0.5, 0.5)
		v5.Position = pickButtonPosition()

		local IncreaseNumber = v5:FindFirstChild("IncreaseNumber")

		if IncreaseNumber then
			IncreaseNumber.Text = ("x%*"):format(v42)
		end

		v5.Rotation = -6
		v5.Visible = true
		v5.Parent = MainUI

		local v7 = findClickTarget(v5)

		for v8, v9 in v5:GetChildren() do
			if v9:IsA("UIScale") then
				v9:Destroy()
			end
		end

		local UIScale = Instance.new("UIScale")

		UIScale.Scale = 0
		UIScale.Parent = v5
		v2 = v5
		TweenService:Create(UIScale, v4, {
			Scale = 1
		}):Play()
		TweenService:Create(v5, v6, {
			Rotation = 6
		}):Play()
		v3 = task.delay(p2, function() --[[ Line: 642 | Upvalues: v3 (ref), v2 (ref), v5 (copy), animateButtonOut (ref), UIScale (copy) ]]
			v3 = nil

			if v2 ~= v5 then
				return
			end

			v2 = nil
			animateButtonOut(v5, UIScale)
		end)
		v7.Activated:Connect(function() --[[ Line: 650 | Upvalues: v2 (ref), v5 (copy), v3 (ref), Remotes (ref), p1 (copy), playTrainingSFX (ref), LocalPlayer (ref), playTrainingVFX (ref), playTrainingFloatingImages (ref), p4 (copy), v22 (copy), v1 (ref), t (ref), estimateGymMultiplier (ref), ActiveEffects (ref), getPotionMultiplier (ref), getRebirthStrengthMultiplier (ref), getGardenDecorationEffects (ref), getRodEnchantBonus (ref), estimateGymBuddyBonus (ref), animateButtonOut (ref), UIScale (copy), playStrengthGainAt (ref) ]]
			if v2 ~= v5 then
				return
			end

			v2 = nil

			if v3 then
				task.cancel(v3)
				v3 = nil
			end

			Remotes.ClaimClickBonus:Fire(p1)
			playTrainingSFX()

			local Character = LocalPlayer.Character

			if Character then
				local v12 = Character:FindFirstChild("UpperTorso") or (Character:FindFirstChild("Torso") or Character:FindFirstChild("HumanoidRootPart"))

				if v12 and v12:IsA("BasePart") then
					playTrainingVFX(v12)
					playTrainingFloatingImages(v12)
				end
			end

			local v23 = p4 or (if v22 then 4 else 2)
			local v32 = 1
			local v4 = v1

			if v4 then
				local v52 = t.UECS:GetComponent(v4, "TrainToolComponent")

				if v52 then
					local v6 = LocalPlayer:GetAttribute("PullPowerMultiplier") or 1

					v32 = v52.AddStrength:Get() * v6 * v23 * estimateGymMultiplier() * ActiveEffects.GetMultiplier("TrainingValue") * getPotionMultiplier(LocalPlayer, "TrainingValue") * (getRebirthStrengthMultiplier(LocalPlayer) + getGardenDecorationEffects(LocalPlayer).StrengthBonus) * (1 + getRodEnchantBonus(LocalPlayer, "Heavy") / 100 + estimateGymBuddyBonus())
				end
			end

			LocalPlayer:SetAttribute("SuppressStrengthGainUntil", workspace:GetServerTimeNow() + 1)
			animateButtonOut(v5, UIScale)
			playStrengthGainAt(v5.AbsolutePosition + v5.AbsoluteSize / 2, v32, v22)
		end)
	end

	Remotes.ShowClickBonus:On(function(p1) --[[ Line: 717 | Upvalues: showClickBonus (copy) ]]
		if typeof(p1) ~= "table" then
			return
		end

		local id = p1.id
		local lifetime = p1.lifetime

		if typeof(id) ~= "string" or typeof(lifetime) ~= "number" then
			return
		end

		showClickBonus(id, lifetime, if typeof(p1.kind) == "string" then p1.kind else "normal", if typeof(p1.multiplier) == "number" then p1.multiplier else nil, p1.boosted == true)
	end)
	Remotes.StreakChanged:On(function(p1) --[[ Line: 731 | Upvalues: setStreak (copy) ]]
		if typeof(p1) ~= "table" then
			return
		end

		local streak = p1.streak
		local event = p1.event

		if typeof(streak) == "number" and typeof(event) == "string" then
			setStreak(streak, event)
		end
	end)

	local function chestPartOf(p1) --[[ chestPartOf | Line: 744 ]]
		if not p1 then
			return nil
		end

		local v1 = p1:FindFirstChild("UpperTorso") or (p1:FindFirstChild("Torso") or p1:FindFirstChild("HumanoidRootPart"))

		if v1 and v1:IsA("BasePart") then
			return v1
		end

		return nil
	end

	Remotes.EnchantTrainingProc:On(function(p1) --[[ Line: 754 | Upvalues: LocalPlayer (copy), v2 (ref), v3 (ref), playTrainingSFX (ref), playTrainingVFX (ref), playTrainingFloatingImages (ref), animateButtonOut (copy), playStrengthGainAt (copy), notifications (ref), UIScale (ref), TweenService (ref), v10 (ref) ]]
		if typeof(p1) ~= "table" then
			return
		end

		local Kind = p1.Kind
		local Character = LocalPlayer.Character
		local v1

		if Character then
			local v22 = Character:FindFirstChild("UpperTorso") or (Character:FindFirstChild("Torso") or Character:FindFirstChild("HumanoidRootPart"))

			v1 = if v22 and v22:IsA("BasePart") then v22 else nil
		else
			v1 = nil
		end

		if Kind == "AutoClick" then
			local v32 = v2

			v2 = nil

			if v3 then
				task.cancel(v3)
				v3 = nil
			end

			playTrainingSFX()

			if v1 then
				playTrainingVFX(v1)
				playTrainingFloatingImages(v1)
			end

			local v4 = tonumber(p1.Amount)
			local v5 = if p1.BonusKind == "extra" then true else false
			local v6 = nil

			if v32 then
				v6 = v32.AbsolutePosition + v32.AbsoluteSize / 2

				local UIScale2 = v32:FindFirstChildOfClass("UIScale")

				if UIScale2 then
					animateButtonOut(v32, UIScale2)
				else
					v32:Destroy()
				end
			elseif v1 then
				local CurrentCamera = workspace.CurrentCamera

				if CurrentCamera then
					local v7 = CurrentCamera:WorldToViewportPoint(v1.Position)

					v6 = Vector2.new(v7.X, v7.Y)
				end
			end

			if v4 and v6 then
				LocalPlayer:SetAttribute("SuppressStrengthGainUntil", workspace:GetServerTimeNow() + 1)
				playStrengthGainAt(v6, v4, v5)
			end
		else
			if Kind == "ComboMaster" then
				local v9 = tonumber(p1.Multiplier) or 0

				notifications:Send((("COMBO MASTER! Bonus buttons pay x%* for %*s!"):format(v9, tonumber(p1.Duration) or 0)))

				if not v1 then
					UIScale.Scale = 1.55
					TweenService:Create(UIScale, v10, {
						Scale = 1
					}):Play()

					return
				end

				playTrainingVFX(v1)
				playTrainingFloatingImages(v1)
				UIScale.Scale = 1.55
				TweenService:Create(UIScale, v10, {
					Scale = 1
				}):Play()

				return
			end

			if Kind ~= "Explosive" then
				return
			end

			local v102 = tonumber(p1.Amount)

			playTrainingSFX()

			if v1 then
				playTrainingVFX(v1)
				playTrainingFloatingImages(v1)
			end

			local CurrentCamera = workspace.CurrentCamera

			if not (v102 and (v1 and CurrentCamera)) then
				return
			end

			local v11 = CurrentCamera:WorldToViewportPoint(v1.Position)

			LocalPlayer:SetAttribute("SuppressStrengthGainUntil", workspace:GetServerTimeNow() + 1)
			playStrengthGainAt(Vector2.new(v11.X, v11.Y), v102, true)
		end
	end)

	local t2 = {}

	local function clearBuddyBeams() --[[ clearBuddyBeams | Line: 837 | Upvalues: t2 (copy) ]]
		for v1, v2 in t2 do
			v2:Destroy()
		end

		table.clear(t2)
	end

	local function makeBuddyBeam(p1, p2) --[[ makeBuddyBeam | Line: 844 | Upvalues: ReplicatedStorage (ref) ]]
		local TutorialBeam = ReplicatedStorage.shared.model:FindFirstChild("TutorialBeam")
		local v1

		if TutorialBeam and TutorialBeam:IsA("Beam") then
			v1 = TutorialBeam:Clone()
		else
			local Beam = Instance.new("Beam")

			Beam.Width0 = 0.4
			Beam.Width1 = 0.4
			Beam.FaceCamera = true
			Beam.LightEmission = 1
			Beam.Color = ColorSequence.new(Color3.fromRGB(255, 170, 60))
			Beam.Transparency = NumberSequence.new(0.3)
			v1 = Beam
		end

		v1.Attachment0 = p1
		v1.Attachment1 = p2
		v1.Parent = p1.Parent

		return v1
	end

	task.spawn(function() --[[ Line: 864 | Upvalues: getRodEnchantBonus (ref), LocalPlayer (copy), isTrainingCharacter (ref), t2 (copy), Players (ref), makeBuddyBeam (copy) ]]
		while true do
			local v1, v2, v3, v4, v5, v6, v7

			while true do
				while true do
					task.wait(0.5)
					v1 = getRodEnchantBonus(LocalPlayer, "GymBuddy")

					local Character = LocalPlayer.Character

					v2 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character
					v3 = if v2 then v2:FindFirstChild("RootAttachment") else v2

					if v1 <= 0 or not (v3 and isTrainingCharacter(Character)) then
						if next(t2) then
							break
						end
					else
						v4 = {}

						for v8, v9 in Players:GetPlayers() do
							if v9 ~= LocalPlayer then
								v5 = v9.Character and v9.Character:FindFirstChild("HumanoidRootPart")
								v6 = if v5 then v5:FindFirstChild("RootAttachment") else v5

								if v6 and ((v5.Position - v2.Position).Magnitude <= v1 and isTrainingCharacter(v9.Character)) then
									v4[v9] = true
									v7 = t2[v9]

									if not v7 or (v7.Parent == nil or v7.Attachment1 ~= v6) then
										if v7 then
											v7:Destroy()
										end

										t2[v9] = makeBuddyBeam(v3, v6)
									end
								end
							end
						end

						for v10, v11 in t2 do
							if not v4[v10] then
								v11:Destroy()
								t2[v10] = nil
							end
						end
					end
				end

				for v12, v13 in t2 do
					v13:Destroy()
				end

				table.clear(t2)
			end

			v4 = {}

			for v8, v9 in Players:GetPlayers() do
				if v9 ~= LocalPlayer then
					v5 = v9.Character and v9.Character:FindFirstChild("HumanoidRootPart")
					v6 = if v5 then v5:FindFirstChild("RootAttachment") else v5

					if v6 and ((v5.Position - v2.Position).Magnitude <= v1 and isTrainingCharacter(v9.Character)) then
						v4[v9] = true
						v7 = t2[v9]

						if not v7 or (v7.Parent == nil or v7.Attachment1 ~= v6) then
							if v7 then
								v7:Destroy()
							end

							t2[v9] = makeBuddyBeam(v3, v6)
						end
					end
				end
			end

			for v10, v11 in t2 do
				if not v4[v10] then
					v11:Destroy()
					t2[v10] = nil
				end
			end
		end
	end)
	p1.UECS.OnComponentCreated("TrainToolComponent"):Connect(function(p1) --[[ Line: 909 | Upvalues: LocalPlayer (copy), v1 (ref), t (ref), AnimationConfig (ref), Remotes (ref), v3 (ref), v2 (ref), v82 (ref), ComboText (copy), CollectionService (ref), playStreakFail (copy), Streak (copy), TextColor3 (copy), TextTransparency (copy), UIStroke (copy), v42 (copy), v52 (copy), UIScale (ref), UECS (ref) ]]
		if p1.Entity:IsA("Tool") then
			local Entity = p1.Entity
			local v12 = nil

			Entity.Equipped:Connect(function() --[[ Line: 915 | Upvalues: LocalPlayer (ref), Entity (copy), v1 (ref), t (ref), AnimationConfig (ref), v12 (ref), Remotes (ref) ]]
				local Character = LocalPlayer.Character

				if not Character then
					return
				end

				if Entity.Parent ~= Character then
					return
				end

				local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")

				if HumanoidRootPart and HumanoidRootPart:IsA("BasePart") then
					HumanoidRootPart.Anchored = true
				end

				v1 = Entity

				local v13 = t.UECS:WaitForComponent(Character, "Animator", 5)

				if v13 then
					v13.AnimationId:Set(AnimationConfig.TrainAnimation)
				end

				if v12 then
					task.cancel(v12)
					v12 = nil
				end

				v12 = task.spawn(function() --[[ Line: 948 | Upvalues: Entity (ref), Character (copy), LocalPlayer (ref), Remotes (ref) ]]
					while Entity.Parent == Character do
						task.wait()

						local Character2 = LocalPlayer.Character

						if Character2 ~= Character or not Character2 then
							break
						end

						if Character2:GetAttribute("LastTrained") and Character2:GetAttribute("LastTrained") > workspace:GetServerTimeNow() then
							continue
						end

						Remotes.Train:Fire()
					end
				end)
			end)
			Entity.Unequipped:Connect(function() --[[ Line: 965 | Upvalues: v1 (ref), Entity (copy), v12 (ref), v3 (ref), v2 (ref), v82 (ref), ComboText (ref), CollectionService (ref), playStreakFail (ref), Streak (ref), TextColor3 (ref), TextTransparency (ref), UIStroke (ref), v42 (ref), v52 (ref), UIScale (ref), LocalPlayer (ref), t (ref), UECS (ref) ]]
				if v1 ~= Entity then
					return
				end

				if v12 then
					task.cancel(v12)
					v12 = nil
				end

				v1 = nil

				if v3 then
					task.cancel(v3)
					v3 = nil
				end

				local v13 = v2

				v2 = nil

				if v13 then
					v13:Destroy()
				end

				local v22 = v82

				v82 = 0

				if ComboText then
					ComboText.Visible = false
					CollectionService:RemoveTag(ComboText, "VFX_RainbowText")
				end

				if v22 >= 2 then
					playStreakFail()
				else
					Streak.Visible = false
					Streak.TextColor3 = TextColor3
					Streak.TextTransparency = TextTransparency

					if UIStroke then
						UIStroke.Color = v42
						UIStroke.Transparency = v52
					end

					Streak.Rotation = 0
					UIScale.Scale = 1
				end

				local Character = LocalPlayer.Character

				if not Character then
					return
				end

				local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")

				if HumanoidRootPart and HumanoidRootPart:IsA("BasePart") then
					HumanoidRootPart.Anchored = false
				end

				local v32 = t.UECS:GetComponent(Character, "Animator")

				if not v32 then
					return
				end

				v32.AnimationId:Set(UECS.Nil)
			end)
		end
	end)
end

return t