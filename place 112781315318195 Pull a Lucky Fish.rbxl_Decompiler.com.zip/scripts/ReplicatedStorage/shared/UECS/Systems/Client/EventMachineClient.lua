-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local Debris = game:GetService("Debris")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local SoundService = game:GetService("SoundService")
local TweenService = game:GetService("TweenService")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local EventConfig = require(ReplicatedStorage.shared.config.EventConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Remotes = require(ReplicatedStorage.shared.Remotes)
local t = {
	UECS = nil
}
local MachineModel = EventConfig.Tags.MachineModel
local RequiredFish = EventConfig.Machine.RequiredFish
local Theme = EventConfig.Theme
local WorkspaceNames = EventConfig.WorkspaceNames
local CurrencyIcon = Theme.CurrencyIcon
local v1 = NumberRange.new(4, 7)
local v2 = UDim2.fromScale(2, 2)
local v3 = NumberRange.new(2, 5)
local v4 = Color3.fromRGB(255, 220, 100)
local CurrencyIcon2 = Theme.CurrencyIcon
local v5 = NumberRange.new(4, 10)
local v6 = NumberRange.new(0.3, 1)
local LocalPlayer = Players.LocalPlayer
local t2 = {}

local function getSavedFedCount() --[[ getSavedFedCount | Line: 109 | Upvalues: ClientPlayerData (copy), EventConfig (copy) ]]
	if not ClientPlayerData.serverProfile then
		return 0
	end

	local v1 = ClientPlayerData.serverProfile:getState()
	local v2 = v1.events and v1.events[EventConfig.Event.Id]

	return if v2 then v2.machineFedCount or 0 else 0
end

local function playSound(p1, p2, p3, p4) --[[ playSound | Line: 118 ]]
	local Sound = Instance.new("Sound")

	Sound.SoundId = p2
	Sound.Volume = p3 or 0.5
	Sound.Looped = p4 or false
	Sound.Parent = p1
	Sound:Play()

	if not p4 then
		Sound.Ended:Once(function() --[[ Line: 126 | Upvalues: Sound (copy) ]]
			Sound:Destroy()
		end)
	end

	return Sound
end

local function playSFXSound(p1) --[[ playSFXSound | Line: 134 | Upvalues: SoundService (copy) ]]
	local SFX = SoundService:FindFirstChild("SFX")
	local v1 = if SFX then SFX:FindFirstChild(p1) else SFX

	if v1 and v1:IsA("Sound") then
		local v2 = v1:Clone()

		v2.PlaybackSpeed = v2.PlaybackSpeed * (1.05 + math.random() * 0.1)
		v2.PlayOnRemove = true
		v2.Parent = SoundService
		v2:Destroy()
	end
end

local function randomInRange(p1) --[[ randomInRange | Line: 147 ]]
	return p1.Min + math.random() * (p1.Max - p1.Min)
end

local function createFollowHost(p1) --[[ createFollowHost | Line: 152 ]]
	local Part = Instance.new("Part")

	Part.Anchored = true
	Part.CanCollide = false
	Part.CanQuery = false
	Part.CanTouch = false
	Part.Transparency = 1
	Part.Size = Vector3.new(0.1, 0.1, 0.1)
	Part.CFrame = CFrame.new(p1.Position)
	Part.Parent = workspace

	return Part
end

local function spawnFlyingImage(p1) --[[ spawnFlyingImage | Line: 166 | Upvalues: v2 (copy), CurrencyIcon (copy), v4 (copy), v3 (copy), RunService (copy), LocalPlayer (copy), TweenService (copy) ]]
	local Attachment = Instance.new("Attachment")

	Attachment.Parent = p1

	local Attachment2 = Instance.new("Attachment")

	Attachment2.Position = Vector3.new(0, 0.5, 0)
	Attachment2.Parent = p1

	local BillboardGui = Instance.new("BillboardGui")

	BillboardGui.Size = v2
	BillboardGui.Adornee = Attachment
	BillboardGui.LightInfluence = 0
	BillboardGui.Parent = Attachment

	local ImageLabel = Instance.new("ImageLabel")

	ImageLabel.BackgroundTransparency = 1
	ImageLabel.Size = UDim2.fromScale(1, 1)
	ImageLabel.Image = CurrencyIcon
	ImageLabel.Parent = BillboardGui

	local Trail = Instance.new("Trail")

	Trail.Attachment0 = Attachment
	Trail.Attachment1 = Attachment2
	Trail.Lifetime = 0.2
	Trail.MinLength = 0
	Trail.Color = ColorSequence.new(v4)
	Trail.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.2), NumberSequenceKeypoint.new(1, 1) })
	Trail.LightEmission = 0.5
	Trail.Parent = p1

	local v1 = v3
	local v22 = v1.Min + math.random() * (v1.Max - v1.Min)
	local v32 = (math.random() * 2 - 1) * 2
	local v42 = (math.random() * 2 - 1) * 2

	task.spawn(function() --[[ Line: 204 | Upvalues: Attachment (copy), RunService (ref), LocalPlayer (ref), p1 (copy), v32 (copy), v22 (copy), v42 (copy), Attachment2 (copy), TweenService (ref), ImageLabel (copy), Trail (copy) ]]
		local v1 = Instance.new("NumberValue")

		v1.Parent = Attachment

		local v2 = nil

		v2 = RunService.Heartbeat:Connect(function() --[[ Line: 209 | Upvalues: Attachment (ref), v2 (ref), LocalPlayer (ref), p1 (ref), v32 (ref), v22 (ref), v42 (ref), v1 (copy), Attachment2 (ref) ]]
			debug.profilebegin("UECS/EventMachineClient.CoinFlyArc")

			if not Attachment.Parent then
				v2:Disconnect()
				debug.profileend()

				return
			end

			local Character = LocalPlayer.Character
			local v12 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character

			if v12 then
				local v23 = v12.Position - p1.Position
				local v6 = v23 * 0.5 + Vector3.new(v32, v22, v42)
				local v7 = v1.Value
				local v8 = 1 - v7
				local v9 = v8 * v8 * Vector3.new(0, 0, 0) + 2 * v8 * v7 * v6 + v7 * v7 * v23

				Attachment.Position = v9
				Attachment2.Position = v9 + Vector3.new(0, 0.5, 0)
			end

			debug.profileend()
		end)
		TweenService:Create(v1, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
			Value = 1
		}):Play()
		task.delay(0.3, function() --[[ Line: 241 | Upvalues: TweenService (ref), ImageLabel (ref) ]]
			TweenService:Create(ImageLabel, TweenInfo.new(0.2), {
				ImageTransparency = 1
			}):Play()
		end)
		task.wait(0.5)
		v2:Disconnect()
		Trail.Enabled = false
		task.wait(0.2)
		Attachment:Destroy()
		Attachment2:Destroy()
		Trail:Destroy()
	end)
end

local function spawnFloatingImage(p1, p2) --[[ spawnFloatingImage | Line: 256 | Upvalues: v2 (copy), CurrencyIcon2 (copy), TweenService (copy), Debris (copy) ]]
	local v1 = math.random() * 2 * math.pi
	local v3 = math.sqrt((math.random()))
	local v7 = Vector3.new(math.cos(v1) * v3 * 7, (math.random() * 2 - 1) * 3, math.sin(v1) * v3 * 1)
	local Attachment = Instance.new("Attachment")

	Attachment.Position = v7
	Attachment.Parent = p1

	local BillboardGui = Instance.new("BillboardGui")

	BillboardGui.Size = UDim2.fromScale(v2.X.Scale * p2, v2.Y.Scale * p2)
	BillboardGui.Adornee = Attachment
	BillboardGui.LightInfluence = 0
	BillboardGui.Parent = Attachment

	local ImageLabel = Instance.new("ImageLabel")

	ImageLabel.BackgroundTransparency = 1
	ImageLabel.Size = UDim2.fromScale(1, 1)
	ImageLabel.Image = CurrencyIcon2

	local v8 = (math.random() * 2 - 1) * 45

	ImageLabel.Rotation = v8
	ImageLabel.Parent = BillboardGui

	local v9 = TweenInfo.new(1.8, Enum.EasingStyle.Linear)

	TweenService:Create(Attachment, v9, {
		Position = v7 + Vector3.new(0, 6, 0)
	}):Play()
	TweenService:Create(ImageLabel, v9, {
		Rotation = v8 + (math.random() * 2 - 1) * 50
	}):Play()
	task.delay(1.2, function() --[[ Line: 289 | Upvalues: TweenService (ref), ImageLabel (copy) ]]
		TweenService:Create(ImageLabel, TweenInfo.new(0.6000000000000001, Enum.EasingStyle.Linear), {
			ImageTransparency = 1
		}):Play()
	end)
	Debris:AddItem(Attachment, 2.3)
end

local function createParticleEmitter(p1, p2, p3, p4, p5) --[[ createParticleEmitter | Line: 300 ]]
	local ParticleEmitter = Instance.new("ParticleEmitter")

	ParticleEmitter.Color = ColorSequence.new(p2)
	ParticleEmitter.Rate = p3
	ParticleEmitter.Speed = NumberRange.new(p4 * 0.5, p4)
	ParticleEmitter.Lifetime = NumberRange.new(p5 * 0.5, p5)
	ParticleEmitter.Size = NumberSequence.new(0.3, 0)
	ParticleEmitter.LightEmission = 0.5
	ParticleEmitter.SpreadAngle = Vector2.new(30, 30)
	ParticleEmitter.Parent = p1

	return ParticleEmitter
end

local function shakeMachine(p1, p2, p3) --[[ shakeMachine | Line: 321 | Upvalues: RunService (copy) ]]
	if p1.shakeConn then
		p1.shakeConn:Disconnect()
	end

	local t = {}
	local t2 = {}

	for v1, v2 in p1.model:GetDescendants() do
		if v2:IsA("BasePart") and (v2.Anchored and v2 ~= p1.inputPart) then
			table.insert(t, v2)
			table.insert(t2, v2.CFrame)
		end
	end

	local v4 = 0

	p1.shakeConn = RunService.Heartbeat:Connect(function(p12) --[[ Line: 335 | Upvalues: v4 (ref), p2 (copy), t (copy), t2 (copy), p1 (copy), p3 (copy) ]]
		debug.profilebegin("UECS/EventMachineClient.MachineShake")
		v4 = v4 + p12

		if p2 <= v4 then
			for v1, v2 in t do
				if v2.Parent then
					v2.CFrame = t2[v1]
				end
			end

			if p1.shakeConn then
				p1.shakeConn:Disconnect()
				p1.shakeConn = nil
			end
		else
			local v6 = Vector3.new(math.random() * p3 * 2 - p3, math.random() * p3 * 2 - p3, math.random() * p3 * 2 - p3)

			for v7, v8 in t do
				if v8.Parent then
					v8.CFrame = t2[v7] + v6
				end
			end
		end

		debug.profileend()
	end)
end

local function wobbleMachineHead(p1, p2) --[[ wobbleMachineHead | Line: 375 | Upvalues: RunService (copy) ]]
	local machineHead = p1.machineHead
	local machineHeadRestCFrame = p1.machineHeadRestCFrame

	if not (machineHead and machineHeadRestCFrame) then
		return
	end

	if p1.machineHeadWobbleConn then
		p1.machineHeadWobbleConn:Disconnect()
		p1.machineHeadWobbleConn = nil
	end

	local v1 = 0

	p1.machineHeadWobbleConn = RunService.Heartbeat:Connect(function(p12) --[[ Line: 388 | Upvalues: v1 (ref), machineHead (copy), machineHeadRestCFrame (copy), p1 (copy), p2 (copy) ]]
		debug.profilebegin("UECS/EventMachineClient.HeadWobble")
		v1 = v1 + p12

		if v1 >= 0.5 then
			if machineHead.Parent then
				machineHead:SetPrimaryPartCFrame(machineHeadRestCFrame)
			end

			if not p1.machineHeadWobbleConn then
				debug.profileend()

				return
			end

			p1.machineHeadWobbleConn:Disconnect()
			p1.machineHeadWobbleConn = nil
		else
			if not machineHead.Parent then
				debug.profileend()

				return
			end

			local v2 = math.sin(math.pi * (v1 / 0.5))
			local v4 = math.sin(v1 * 10) * 0.3141592653589793 * v2

			machineHead:SetPrimaryPartCFrame(machineHeadRestCFrame * (if p2 == "UpDown" then CFrame.Angles(v4, 0, 0) else CFrame.Angles(0, v4, 0)))
		end

		debug.profileend()
	end)
end

local function playFeedReactionSound(p1) --[[ playFeedReactionSound | Line: 416 | Upvalues: Theme (copy) ]]
	if #Theme.FeedReactionSounds == 0 then
		return
	end

	local v2 = Theme.FeedReactionSounds[math.random(1, #Theme.FeedReactionSounds)]
	local Sound = Instance.new("Sound")

	Sound.SoundId = v2
	Sound.Volume = 0.8
	Sound.Looped = false
	Sound.Parent = p1.machineHead and p1.machineHead.PrimaryPart or p1.inputPart
	Sound:Play()
	Sound.Ended:Once(function() --[[ Line: 126 | Upvalues: Sound (copy) ]]
		Sound:Destroy()
	end)
end

local function toggleDoor(p1, p2) --[[ toggleDoor | Line: 427 | Upvalues: WorkspaceNames (copy), TweenService (copy) ]]
	local v1 = p1.model:FindFirstChild(WorkspaceNames.MachineDoor)

	if not v1 then
		return
	end

	local v2 = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut)
	local v4 = if p2 then TweenService:Create(v1, v2, {
	CFrame = p1.doorStartingCFrame
}) else TweenService:Create(v1, v2, {
	CFrame = p1.doorStartingCFrame + p1.doorStartingCFrame.RightVector * -5.5
})

	v4:Play()
	v4.Completed:Wait()
end

local function animateFishFeed(p1, p2) --[[ animateFishFeed | Line: 448 | Upvalues: TweenService (copy), createParticleEmitter (copy), shakeMachine (copy) ]]
	if p2 then
		local v1 = p1.inputPart.CFrame
		local Model = Instance.new("Model")

		p2.Anchored = true
		p2.CanCollide = false
		p2.Parent = Model
		Model.PrimaryPart = p2
		Model.Parent = workspace
		p2.CFrame = v1 + v1.LookVector * -4

		local v3 = Model:GetScale()
		local v4 = Instance.new("NumberValue")

		v4.Value = 1
		v4.Parent = Model
		v4.Changed:Connect(function(p1) --[[ Line: 474 | Upvalues: Model (copy), v3 (copy) ]]
			if not Model.Parent then
				return
			end

			Model:ScaleTo(v3 * p1)
		end)

		local v5 = TweenService:Create(p2, TweenInfo.new(0.4, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
			CFrame = v1
		})
		local v6 = TweenService:Create(v4, TweenInfo.new(0.4, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
			Value = 0.05
		})

		v5:Play()
		v6:Play()
		v5.Completed:Once(function() --[[ Line: 489 | Upvalues: Model (copy), p1 (copy), createParticleEmitter (ref), shakeMachine (ref) ]]
			Model:Destroy()

			local Sound = Instance.new("Sound")

			Sound.SoundId = "rbxassetid://9125402735"
			Sound.Volume = 0.7
			Sound.Looped = false
			Sound.Parent = p1.inputPart
			Sound:Play()
			Sound.Ended:Once(function() --[[ Line: 126 | Upvalues: Sound (copy) ]]
				Sound:Destroy()
			end)

			local Sound2 = Instance.new("Sound")

			Sound2.SoundId = "rbxassetid://315912428"
			Sound2.Volume = 0.7
			Sound2.Looped = false
			Sound2.Parent = p1.inputPart
			Sound2:Play()
			Sound2.Ended:Once(function() --[[ Line: 126 | Upvalues: Sound2 (copy) ]]
				Sound2:Destroy()
			end)

			local v1 = createParticleEmitter(p1.inputPart, Color3.fromRGB(255, 230, 150), 0, 6, 0.5)

			v1.SpreadAngle = Vector2.new(180, 180)
			v1:Emit(25)
			task.delay(1, function() --[[ Line: 498 | Upvalues: v1 (copy) ]]
				v1:Destroy()
			end)

			if p1.currentState == "processing" then
				return
			end

			shakeMachine(p1, 0.3, 0.05)
		end)
	end
end

local function startProcessingVFX(p1) --[[ startProcessingVFX | Line: 510 | Upvalues: WorkspaceNames (copy), createParticleEmitter (copy), shakeMachine (copy), RunService (copy), EventConfig (copy) ]]
	local v1 = p1.model:FindFirstChild(WorkspaceNames.MachineSmokeEmitter)
	local v2 = if v1 then v1:FindFirstChildOfClass("ParticleEmitter") else v1

	if v2 then
		v2.Enabled = true
		p1.smokeEmitter = v2
	end

	p1.sparkEmitter = createParticleEmitter(p1.outputPart, Color3.fromRGB(255, 200, 50), 10, 4, 0.8)

	local Sound = Instance.new("Sound")

	Sound.SoundId = "rbxassetid://132041354023896"
	Sound.Volume = 0.4
	Sound.Looped = true
	Sound.Parent = p1.model.PrimaryPart or p1.inputPart
	Sound:Play()
	p1.rumbleSound = Sound
	shakeMachine(p1, 30, 0.075)

	if p1.billboardGui then
		p1.billboardGui.Enabled = true
	end

	local v4 = os.clock()

	if p1.timerConn then
		p1.timerConn:Disconnect()
	end

	p1.timerConn = RunService.Heartbeat:Connect(function() --[[ Line: 534 | Upvalues: v4 (copy), EventConfig (ref), p1 (copy) ]]
		debug.profilebegin("UECS/EventMachineClient.ProcessingTimer")

		local v42 = math.max(0, (math.ceil(EventConfig.Machine.ProcessingTime - (os.clock() - v4))))

		if p1.timerLabel then
			p1.timerLabel.Text = tostring(v42) .. "s"
		end

		if v42 <= 0 and p1.timerConn then
			p1.timerConn:Disconnect()
			p1.timerConn = nil
		end

		debug.profileend()
	end)
end

local function stopProcessingVFX(p1) --[[ stopProcessingVFX | Line: 549 ]]
	if p1.smokeEmitter then
		p1.smokeEmitter.Enabled = false
	end

	if p1.sparkEmitter then
		p1.sparkEmitter:Destroy()
		p1.sparkEmitter = nil
	end

	if p1.rumbleSound then
		p1.rumbleSound:Stop()
		p1.rumbleSound:Destroy()
		p1.rumbleSound = nil
	end

	if p1.shakeConn then
		p1.shakeConn:Disconnect()
		p1.shakeConn = nil
	end

	if p1.billboardGui then
		p1.billboardGui.Enabled = false
	end

	if not p1.timerConn then
		return
	end

	p1.timerConn:Disconnect()
	p1.timerConn = nil
end

local function setFireEnabled(p1, p2) --[[ setFireEnabled | Line: 577 | Upvalues: WorkspaceNames (copy) ]]
	local v1 = p1.model:FindFirstChild(WorkspaceNames.MachineFire)
	local v2 = if v1 then v1:FindFirstChildOfClass("ParticleEmitter") else v1

	if not v2 then
		return
	end

	v2.Enabled = p2
end

local function playCompletionSequence(p1) --[[ playCompletionSequence | Line: 586 | Upvalues: stopProcessingVFX (copy), ReplicatedStorage (copy), Theme (copy), WorkspaceNames (copy), TweenService (copy), v4 (copy), RunService (copy) ]]
	stopProcessingVFX(p1)

	local Sound = Instance.new("Sound")

	Sound.SoundId = "rbxassetid://128829553647714"
	Sound.Volume = 1
	Sound.Looped = false
	Sound.Parent = p1.outputPart
	Sound:Play()
	Sound.Ended:Once(function() --[[ Line: 126 | Upvalues: Sound (copy) ]]
		Sound:Destroy()
	end)

	local Sound2 = Instance.new("Sound")

	Sound2.SoundId = "rbxassetid://9125516236"
	Sound2.Volume = 0.8
	Sound2.Looped = false
	Sound2.Parent = p1.outputPart
	Sound2:Play()
	Sound2.Ended:Once(function() --[[ Line: 126 | Upvalues: Sound2 (copy) ]]
		Sound2:Destroy()
	end)
	task.wait(0.5)

	local v1 = ReplicatedStorage.shared.model:FindFirstChild(Theme.MascotModelName)
	local spawnPart = p1.spawnPart

	if not (v1 and (v1:IsA("Model") and spawnPart)) then
		return
	end

	local v2 = v1:Clone()

	v2.Parent = workspace

	for v3, v42 in v2:GetDescendants() do
		if v42:IsA("BasePart") then
			v42.Anchored = true
			v42.CanCollide = false
		end
	end

	local v5 = spawnPart.CFrame

	v2:PivotTo(v5)

	local v6 = p1.model:FindFirstChild(WorkspaceNames.MachineFire)
	local v7 = if v6 then v6:FindFirstChildOfClass("ParticleEmitter") else v6

	if v7 then
		v7.Enabled = true
	end

	p1.mascotModel = v2

	local v8 = v5 * CFrame.Angles(1.5707963267948966, 0, 0) + v5.LookVector * 5 + Vector3.new(0, 0.9, 0)
	local CFrameValue = Instance.new("CFrameValue")

	CFrameValue.Value = v5
	CFrameValue.Parent = v2
	CFrameValue.Changed:Connect(function(p1) --[[ Line: 624 | Upvalues: v2 (copy) ]]
		if not v2.Parent then
			return
		end

		v2:PivotTo(p1)
	end)

	local v9 = TweenService:Create(CFrameValue, TweenInfo.new(1, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
		Value = v8
	})

	v9:Play()
	v9.Completed:Once(function() --[[ Line: 634 | Upvalues: p1 (copy), WorkspaceNames (ref), v2 (copy), Theme (ref) ]]
		local v1 = p1.model:FindFirstChild(WorkspaceNames.MachineFire)
		local v22 = v1 and v1:FindFirstChildOfClass("ParticleEmitter")

		if v22 then
			v22.Enabled = false
		end

		local v3 = v2:FindFirstChildWhichIsA("BasePart")

		if not v3 then
			return
		end

		local Sound = Instance.new("Sound")

		Sound.SoundId = Theme.MascotEmergeSound
		Sound.Volume = 0.9
		Sound.Looped = false
		Sound.Parent = v3
		Sound:Play()
		Sound.Ended:Once(function() --[[ Line: 126 | Upvalues: Sound (copy) ]]
			Sound:Destroy()
		end)
	end)
	task.wait(0.5)

	local v10 = workspace:FindFirstChild(Theme.CoinModelName)

	if not v10 then
		return
	end

	local v11 = p1.model:FindFirstChild(WorkspaceNames.MachineCoinTargets)
	local t = {}

	if v11 then
		for v12, v13 in v11:GetChildren() do
			if v13:IsA("BasePart") then
				table.insert(t, v13)
			end
		end
	end

	if #t == 0 then
		return
	end

	local v14 = p1.outputPart.CFrame
	local Position = v14.Position

	p1.coinModels = {}

	for v15, v16 in t do
		local v17 = v10:Clone()
		local v18 = nil

		for v19, v20 in v17:GetDescendants() do
			if v20:IsA("BasePart") then
				v20.Anchored = true
				v20.CanCollide = false

				if not v18 then
					v18 = v20
				end
			end
		end

		if v18 then
			v17:PivotTo(v14)
			v17.Parent = workspace

			local Position2 = v16.CFrame.Position
			local v21 = CFrame.new(Position2) * v16.CFrame.Rotation
			local v25 = Vector3.new((Position.X + Position2.X) / 2, (Position.Y + Position2.Y) / 2 + 5, (Position.Z + Position2.Z) / 2)
			local CFrameValue2 = Instance.new("CFrameValue")

			CFrameValue2.Value = v14
			CFrameValue2.Parent = v17
			CFrameValue2.Changed:Connect(function(p1) --[[ Line: 703 | Upvalues: v17 (copy) ]]
				if not v17.Parent then
					return
				end

				v17:PivotTo(p1)
			end)
			table.insert(p1.coinModels, v18)

			local Attachment = Instance.new("Attachment")

			Attachment.Parent = v18

			local Attachment2 = Instance.new("Attachment")

			Attachment2.Position = Vector3.new(0, 0.5, 0)
			Attachment2.Parent = v18

			local Trail = Instance.new("Trail")

			Trail.Attachment0 = Attachment
			Trail.Attachment1 = Attachment2
			Trail.Lifetime = 0.2
			Trail.MinLength = 0
			Trail.Color = ColorSequence.new(v4)
			Trail.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.2), NumberSequenceKeypoint.new(1, 1) })
			Trail.LightEmission = 0.5
			Trail.Parent = v18
			task.delay(v15 * 0.08, function() --[[ Line: 732 | Upvalues: v17 (copy), RunService (ref), Position (copy), v25 (copy), Position2 (copy), CFrameValue2 (copy), v21 (copy), TweenService (ref), Trail (copy) ]]
				local v1 = Instance.new("NumberValue")

				v1.Value = 0
				v1.Parent = v17

				local v2 = nil

				v2 = RunService.Heartbeat:Connect(function() --[[ Line: 738 | Upvalues: v17 (ref), v2 (ref), v1 (copy), Position (ref), v25 (ref), Position2 (ref), CFrameValue2 (ref), v21 (ref) ]]
					debug.profilebegin("UECS/EventMachineClient.CoinArcBezier")

					if v17.Parent then
						local v12 = v1.Value
						local v22 = 1 - v12

						CFrameValue2.Value = CFrame.new(v22 * v22 * Position + 2 * v22 * v12 * v25 + v12 * v12 * Position2) * v21.Rotation
					else
						v2:Disconnect()
					end

					debug.profileend()
				end)

				local v3 = TweenService:Create(v1, TweenInfo.new(0.6, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					Value = 1
				})

				v3:Play()
				v3.Completed:Once(function() --[[ Line: 761 | Upvalues: v2 (ref), CFrameValue2 (ref), v21 (ref), Trail (ref), v1 (copy) ]]
					v2:Disconnect()
					CFrameValue2.Value = v21
					Trail.Enabled = false
					v1:Destroy()
				end)
			end)

			continue
		end

		v17:Destroy()
	end
end

local function playClaimAnimation(p1) --[[ playClaimAnimation | Line: 773 | Upvalues: Debris (copy), playSFXSound (copy), v1 (copy), spawnFlyingImage (copy), v5 (copy), spawnFloatingImage (copy), v6 (copy), LocalPlayer (copy), TweenService (copy) ]]
	local Part = Instance.new("Part")

	Part.Anchored = true
	Part.CanCollide = false
	Part.CanQuery = false
	Part.CanTouch = false
	Part.Transparency = 1
	Part.Size = Vector3.new(0.1, 0.1, 0.1)
	Part.CFrame = CFrame.new((p1.outputPart.CFrame + Vector3.new(0, 3, 0)).Position)
	Part.Parent = workspace

	local v2 = Part

	Debris:AddItem(v2, 5)
	playSFXSound("CashPickup")

	for i = 1, math.random(v1.Min, v1.Max) do
		spawnFlyingImage(v2)
	end

	task.delay(0.2, function() --[[ Line: 788 | Upvalues: v2 (copy), v5 (ref), spawnFloatingImage (ref), v6 (ref) ]]
		if not v2.Parent then
			return
		end

		for i = 1, math.random(v5.Min, v5.Max) do
			task.delay(math.random() * 0.5, function() --[[ Line: 793 | Upvalues: v2 (ref), spawnFloatingImage (ref), v6 (ref) ]]
				if not v2.Parent then
					return
				end

				local v1 = v6

				spawnFloatingImage(v2, v1.Min + math.random() * (v1.Max - v1.Min))
			end)
		end
	end)
	task.delay(0.25, function() --[[ Line: 802 | Upvalues: playSFXSound (ref) ]]
		playSFXSound("CashCollect")
	end)
	task.delay(0.5, function() --[[ Line: 805 | Upvalues: playSFXSound (ref) ]]
		playSFXSound("CashPickupEnd")
	end)

	local Character = LocalPlayer.Character
	local v3 = if Character and Character:FindFirstChild("HumanoidRootPart") then Character.HumanoidRootPart.Position else p1.outputPart.CFrame.Position

	for v4, v52 in p1.coinModels do
		task.delay((v4 - 1) * 0.05, function() --[[ Line: 816 | Upvalues: v52 (copy), TweenService (ref), v3 (copy) ]]
			local v1 = v52.Parent

			if not (v1 and v1.Parent) then
				return
			end

			local v2 = v1:FindFirstChildWhichIsA("CFrameValue")

			if v2 then
				local v32 = TweenService:Create(v2, TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
					Value = CFrame.new(v3)
				})

				v32:Play()
				v32.Completed:Once(function() --[[ Line: 832 | Upvalues: v1 (copy) ]]
					v1:Destroy()
				end)
			else
				v1:Destroy()
			end
		end)
	end

	if p1.mascotModel and p1.mascotModel.Parent then
		local mascotModel = p1.mascotModel

		for v62, v7 in mascotModel:GetDescendants() do
			if v7:IsA("BasePart") then
				TweenService:Create(v7, TweenInfo.new(1, Enum.EasingStyle.Quad), {
					Transparency = 1
				}):Play()
			end
		end

		local v8 = mascotModel:GetScale()
		local v9 = Instance.new("NumberValue")

		v9.Value = 1
		v9.Parent = mascotModel
		v9.Changed:Connect(function(p1) --[[ Line: 854 | Upvalues: mascotModel (copy), v8 (copy) ]]
			if not mascotModel.Parent then
				return
			end

			mascotModel:ScaleTo(v8 * p1)
		end)

		local v10 = TweenService:Create(v9, TweenInfo.new(1, Enum.EasingStyle.Quad), {
			Value = 0.05
		})

		v10:Play()
		v10.Completed:Once(function() --[[ Line: 863 | Upvalues: p1 (copy) ]]
			if not p1.mascotModel then
				return
			end

			p1.mascotModel:Destroy()
			p1.mascotModel = nil
		end)
	end

	p1.coinModels = {}
end

local function updatePrompts(p1) --[[ updatePrompts | Line: 874 | Upvalues: LocalPlayer (copy), Theme (copy), RequiredFish (copy) ]]
	local v1 = if p1.ownerId == nil then true elseif p1.ownerId == LocalPlayer.UserId then true else false

	if p1.currentState == "idle" or p1.currentState == "feeding" and v1 then
		if p1.feedPrompt then
			p1.feedPrompt.Enabled = true
			p1.feedPrompt.ObjectText = Theme.MachineName
			p1.feedPrompt.ActionText = ("Feed %* (%*/%*)"):format(Theme.MachineFoodLabel, p1.fedCount, RequiredFish)
		end

		if p1.claimPrompt then
			p1.claimPrompt.Enabled = false
		end
	elseif p1.currentState == "done" and v1 then
		if p1.feedPrompt then
			p1.feedPrompt.Enabled = false
		end

		if p1.claimPrompt then
			p1.claimPrompt.Enabled = true
		end
	else
		if p1.feedPrompt then
			p1.feedPrompt.Enabled = false
		end

		if not p1.claimPrompt then
			return
		end

		p1.claimPrompt.Enabled = false
	end
end

function t.Init(p1) --[[ Init | Line: 906 | Upvalues: CollectionService (copy), WorkspaceNames (copy), ClientPlayerData (copy), EventConfig (copy), RequiredFish (copy), Theme (copy), t2 (copy), LocalPlayer (copy), Remotes (copy), playClaimAnimation (copy), MachineModel (copy), wobbleMachineHead (copy), animateFishFeed (copy), toggleDoor (copy), startProcessingVFX (copy), playCompletionSequence (copy), stopProcessingVFX (copy), updatePrompts (copy) ]]
	local function findTaggedPart(p1, p2) --[[ findTaggedPart | Line: 915 | Upvalues: CollectionService (ref) ]]
		local v1 = nil

		for v2, v3 in p1:GetDescendants() do
			if v3:IsA("BasePart") and CollectionService:HasTag(v3, p2) then
				v1 = v3
			end
		end

		return v1
	end

	local function setupMachine(p1, p2, p3, p4) --[[ setupMachine | Line: 925 | Upvalues: WorkspaceNames (ref), ClientPlayerData (ref), EventConfig (ref), RequiredFish (ref), Theme (ref), t2 (ref), LocalPlayer (ref), Remotes (ref), playClaimAnimation (ref) ]]
		local v1 = p1:FindFirstChild(WorkspaceNames.MachineWalkway)
		local v2 = p1:FindFirstChild(WorkspaceNames.MachineSpawn)
		local v3 = p1:FindFirstChild(WorkspaceNames.MachineBillboard)
		local v4 = nil
		local v5

		if v3 then
			local BillboardGui = v3:FindFirstChildOfClass("BillboardGui")

			if BillboardGui then
				BillboardGui.Enabled = false

				local TextUp = BillboardGui:FindFirstChild("TextUp")

				v5 = BillboardGui
				v4 = TextUp
			else
				v5 = BillboardGui
			end
		else
			v5 = nil
		end

		local v6

		if ClientPlayerData.serverProfile then
			local v7 = ClientPlayerData.serverProfile:getState()
			local v8 = v7.events and v7.events[EventConfig.Event.Id]

			v6 = v8 and v8.machineFedCount or 0
		else
			v6 = 0
		end

		if RequiredFish <= v6 then
			v6 = 0
		end

		local ProximityPrompt = Instance.new("ProximityPrompt")

		ProximityPrompt.Style = Enum.ProximityPromptStyle.Custom
		ProximityPrompt.ActionText = ("Feed %* (%*/%*)"):format(Theme.MachineFoodLabel, v6, RequiredFish)
		ProximityPrompt.ObjectText = Theme.MachineName
		ProximityPrompt.MaxActivationDistance = 10
		ProximityPrompt.RequiresLineOfSight = false
		ProximityPrompt:AddTag("NoFade")
		ProximityPrompt.Parent = p2

		local ProximityPrompt2 = Instance.new("ProximityPrompt")

		ProximityPrompt2.Style = Enum.ProximityPromptStyle.Custom
		ProximityPrompt2.ActionText = ("Claim %* %*"):format(EventConfig.Machine.RewardCoins, Theme.CurrencyName)
		ProximityPrompt2.ObjectText = Theme.MachineName
		ProximityPrompt2.MaxActivationDistance = 10
		ProximityPrompt2.RequiresLineOfSight = false
		ProximityPrompt2:AddTag("NoFade")
		ProximityPrompt2.Enabled = false
		ProximityPrompt2.Parent = p3

		local v9 = p1:FindFirstChild(Theme.MachineHeadModelName, true)
		local v10 = nil

		if v9 and not v9.PrimaryPart then
			warn("[EventMachineClient] Head model has no PrimaryPart set \226\128\148 wobble disabled:", p1:GetFullName())
			v9 = nil
		elseif v9 then
			v10 = v9:GetPivot()
		end

		local t = {
			currentState = "idle",
			ownerId = nil,
			model = p1,
			doorStartingCFrame = p4.CFrame,
			inputPart = p2,
			outputPart = p3,
			spawnPart = v2,
			walkway = v1,
			feedPrompt = ProximityPrompt,
			claimPrompt = ProximityPrompt2,
			fedCount = v6,
			coinModels = {},
			billboardGui = v5,
			timerLabel = v4,
			machineHead = v9,
			machineHeadRestCFrame = v10
		}

		table.insert(t2, t)

		local v13 = 0

		ProximityPrompt.Triggered:Connect(function(p1) --[[ Line: 1004 | Upvalues: v13 (ref), LocalPlayer (ref), t (copy), Remotes (ref) ]]
			local v1 = os.clock()

			if v1 - v13 < 0.5 then
				return
			end

			v13 = v1

			local Character = LocalPlayer.Character

			if not Character then
				Remotes.FeedEventMachine:Fire()

				return
			end

			for v2, v3 in Character:GetChildren() do
				if v3:IsA("Tool") then
					local Handle = v3:FindFirstChild("Handle")

					if not Handle then
						break
					end

					t.pendingFishClone = Handle:Clone()

					break
				end
			end

			Remotes.FeedEventMachine:Fire()
		end)
		ProximityPrompt2.Triggered:Connect(function(p1) --[[ Line: 1030 | Upvalues: Remotes (ref), playClaimAnimation (ref), t (copy) ]]
			Remotes.ClaimEventMachineReward:Fire()
			playClaimAnimation(t)
		end)

		return t
	end

	local function teardownMachine(p1) --[[ teardownMachine | Line: 1041 | Upvalues: t2 (ref) ]]
		for v1, v2 in t2 do
			if v2 == p1 then
				table.remove(t2, v1)

				break
			end
		end

		if p1.shakeConn then
			p1.shakeConn:Disconnect()
		end

		if p1.timerConn then
			p1.timerConn:Disconnect()
		end

		if p1.machineHeadWobbleConn then
			p1.machineHeadWobbleConn:Disconnect()
		end

		if p1.rumbleSound then
			p1.rumbleSound:Destroy()
		end

		if p1.feedPrompt then
			p1.feedPrompt:Destroy()
		end

		if not p1.claimPrompt then
			return
		end

		p1.claimPrompt:Destroy()
	end

	local t = {}

	local function ensureMachine(p1) --[[ ensureMachine | Line: 1073 | Upvalues: t (copy), findTaggedPart (copy), EventConfig (ref), WorkspaceNames (ref), setupMachine (copy), teardownMachine (copy) ]]
		if not t[p1] then
			t[p1] = true
			task.spawn(function() --[[ Line: 1078 | Upvalues: p1 (copy), findTaggedPart (ref), EventConfig (ref), WorkspaceNames (ref), setupMachine (ref), teardownMachine (ref), t (ref) ]]
				while p1:IsDescendantOf(game) do
					local v1 = findTaggedPart(p1, EventConfig.Tags.MachineInput)
					local v22 = findTaggedPart(p1, EventConfig.Tags.MachineOutput)
					local v3 = p1:FindFirstChild(WorkspaceNames.MachineDoor)

					if v1 and (v22 and (v3 and v3:IsA("BasePart"))) then
						local v4 = setupMachine(p1, v1, v22, v3)

						while p1:IsDescendantOf(game) and (v1:IsDescendantOf(game) and v22:IsDescendantOf(game)) do
							task.wait(1)
						end

						teardownMachine(v4)

						continue
					end

					task.wait(0.5)
				end

				t[p1] = nil
			end)
		end
	end

	for v1, v2 in CollectionService:GetTagged(MachineModel) do
		if v2:IsA("Model") and not t[v2] then
			t[v2] = true
			task.spawn(function() --[[ Line: 1078 | Upvalues: v2 (copy), findTaggedPart (copy), EventConfig (ref), WorkspaceNames (ref), setupMachine (copy), teardownMachine (copy), t (copy) ]]
				while v2:IsDescendantOf(game) do
					local v1 = findTaggedPart(v2, EventConfig.Tags.MachineInput)
					local v22 = findTaggedPart(v2, EventConfig.Tags.MachineOutput)
					local v3 = v2:FindFirstChild(WorkspaceNames.MachineDoor)

					if v1 and (v22 and (v3 and v3:IsA("BasePart"))) then
						local v4 = setupMachine(v2, v1, v22, v3)

						while v2:IsDescendantOf(game) and (v1:IsDescendantOf(game) and v22:IsDescendantOf(game)) do
							task.wait(1)
						end

						teardownMachine(v4)

						continue
					end

					task.wait(0.5)
				end

				t[v2] = nil
			end)
		end
	end

	CollectionService:GetInstanceAddedSignal(MachineModel):Connect(function(p1) --[[ Line: 1106 | Upvalues: t (copy), findTaggedPart (copy), EventConfig (ref), WorkspaceNames (ref), setupMachine (copy), teardownMachine (copy) ]]
		if not p1:IsA("Model") then
			return
		end

		if t[p1] then
			return
		end

		t[p1] = true
		task.spawn(function() --[[ Line: 1078 | Upvalues: p1 (copy), findTaggedPart (ref), EventConfig (ref), WorkspaceNames (ref), setupMachine (ref), teardownMachine (ref), t (ref) ]]
			while p1:IsDescendantOf(game) do
				local v1 = findTaggedPart(p1, EventConfig.Tags.MachineInput)
				local v22 = findTaggedPart(p1, EventConfig.Tags.MachineOutput)
				local v3 = p1:FindFirstChild(WorkspaceNames.MachineDoor)

				if v1 and (v22 and (v3 and v3:IsA("BasePart"))) then
					local v4 = setupMachine(p1, v1, v22, v3)

					while p1:IsDescendantOf(game) and (v1:IsDescendantOf(game) and v22:IsDescendantOf(game)) do
						task.wait(1)
					end

					teardownMachine(v4)

					continue
				end

				task.wait(0.5)
			end

			t[p1] = nil
		end)
	end)
	Remotes.EventMachineFeedResult:On(function(p1) --[[ Line: 1115 | Upvalues: t2 (ref), Theme (ref), wobbleMachineHead (ref) ]]
		if typeof(p1) ~= "table" then
			return
		end

		local isSuccess = p1.Success == true

		for v1, v2 in t2 do
			if #Theme.FeedReactionSounds ~= 0 then
				local v4 = Theme.FeedReactionSounds[math.random(1, #Theme.FeedReactionSounds)]
				local Sound = Instance.new("Sound")

				Sound.SoundId = v4
				Sound.Volume = 0.8
				Sound.Looped = false
				Sound.Parent = v2.machineHead and v2.machineHead.PrimaryPart or v2.inputPart
				Sound:Play()
				Sound.Ended:Once(function() --[[ Line: 126 | Upvalues: Sound (copy) ]]
					Sound:Destroy()
				end)
			end

			task.wait(0.2)
			wobbleMachineHead(v2, if isSuccess then "UpDown" else "LeftRight")
		end
	end)
	Remotes.EventMachineStateChanged:On(function(p1) --[[ Line: 1128 | Upvalues: t2 (ref), LocalPlayer (ref), animateFishFeed (ref), toggleDoor (ref), startProcessingVFX (ref), playCompletionSequence (ref), stopProcessingVFX (ref), updatePrompts (ref) ]]
		if typeof(p1) ~= "table" then
			return
		end

		local State = p1.State
		local FedCount = p1.FedCount
		local OwnerId = p1.OwnerId

		for v1, v2 in t2 do
			local currentState = v2.currentState
			local fedCount = v2.fedCount

			v2.currentState = State
			v2.fedCount = FedCount
			v2.ownerId = OwnerId

			if State == "feeding" and (OwnerId == LocalPlayer.UserId and fedCount < FedCount) then
				local pendingFishClone = v2.pendingFishClone

				v2.pendingFishClone = nil
				animateFishFeed(v2, pendingFishClone)
			elseif State == "processing" and currentState ~= "processing" then
				toggleDoor(v2, false)
				startProcessingVFX(v2)
			elseif State == "done" and currentState ~= "done" then
				toggleDoor(v2, true)
				task.spawn(playCompletionSequence, v2)
			elseif State == "idle" and currentState ~= "idle" then
				toggleDoor(v2, true)
				stopProcessingVFX(v2)

				for v3, v4 in v2.coinModels do
					v4:Destroy()
				end

				v2.coinModels = {}

				if v2.mascotModel then
					v2.mascotModel:Destroy()
					v2.mascotModel = nil
				end
			end

			updatePrompts(v2)
		end
	end)
	Remotes.RequestEventMachineState:Fire()
end

return t