-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ContextActionService = game:GetService("ContextActionService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local CashDisplay = require(ReplicatedStorage.shared.module.CashDisplay)
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local FishConfig = require(ReplicatedStorage.shared.config.FishConfig)
local FishEarnings = require(ReplicatedStorage.shared.util.FishEarnings)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local MutationList = require(ReplicatedStorage.shared.util.MutationList)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local Sell = require(ReplicatedStorage.shared.UECS.Components.Sell)
local t = {
	UECS = nil,
	Priority = 30
}
local GuiService = game:GetService("GuiService")
local UserInputService = game:GetService("UserInputService")
local bindToButtonPress = require(ReplicatedStorage.shared.util.bindToButtonPress)
local favoriteCount = require(ReplicatedStorage.shared.util.favoriteCount)
local playSellSound = require(ReplicatedStorage.shared.util.playSellSound)

function t.Init(p1) --[[ Init | Line: 30 | Upvalues: Players (copy), Sell (copy), bindToButtonPress (copy), playSellSound (copy), Remotes (copy), GuiService (copy), UserInputService (copy), ContextActionService (copy), FishConfig (copy), MutationList (copy), CashDisplay (copy), ClientPlayerData (copy), favoriteCount (copy), FishEarnings (copy) ]]
	local MainUI = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI")
	local Sell2 = MainUI.Sell
	local v1 = Sell2.Content
	local ScrollingFrame = v1.ScrollingFrame
	local Template = ScrollingFrame.Template

	Template.Visible = false

	local t = {}

	Sell2.Visible = false

	local v2 = Sell.Add(Sell2)

	v2.Visible.OnChange:Connect(function(p12, p2) --[[ Line: 43 | Upvalues: Sell2 (copy), MainUI (copy), bindToButtonPress (ref), p1 (copy), playSellSound (ref), Remotes (ref), t (copy), GuiService (ref), UserInputService (ref), ScrollingFrame (copy), ContextActionService (ref) ]]
		Sell2.Visible = p12

		local HUD = MainUI:FindFirstChild("HUD")

		if HUD then
			HUD.Visible = not p12
		end

		if p12 == p2 then
			return
		end

		if p12 then
			bindToButtonPress("SellFishCloseAction", Enum.KeyCode.ButtonB, function() --[[ Line: 55 | Upvalues: p1 (ref) ]]
				p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
			end)
			bindToButtonPress("SellAllAction", Enum.KeyCode.ButtonY, function() --[[ Line: 60 | Upvalues: playSellSound (ref), Remotes (ref) ]]
				playSellSound()
				Remotes.SellAllFish:Fire()
			end)
			bindToButtonPress("SellAction", Enum.KeyCode.ButtonX, function() --[[ Line: 65 | Upvalues: t (ref), GuiService (ref), playSellSound (ref), Remotes (ref) ]]
				for v1, v2 in t do
					if GuiService.SelectedObject == v2 then
						playSellSound()
						Remotes.SellFish:Fire(v1)

						return
					end
				end
			end)

			if UserInputService.PreferredInput == Enum.PreferredInput.Gamepad then
				GuiService:Select(ScrollingFrame)
			end
		else
			ContextActionService:UnbindAction("SellAction")
			ContextActionService:UnbindAction("SellFishCloseAction")
			ContextActionService:UnbindAction("SellAllAction")
			GuiService.SelectedObject = nil
		end
	end)

	local function onSelectionChange() --[[ onSelectionChange | Line: 87 | Upvalues: UserInputService (ref), GuiService (ref), v2 (copy), Sell2 (copy), ScrollingFrame (copy) ]]
		if UserInputService.PreferredInput ~= Enum.PreferredInput.Gamepad then
			return
		end

		local SelectedObject = GuiService.SelectedObject

		if v2.Visible:Get() and not (SelectedObject and SelectedObject:IsDescendantOf(Sell2)) then
			GuiService:Select(ScrollingFrame)
		end

		for v1, v22 in ScrollingFrame:QueryDescendants("ImageLabel.GamepadControl") do
			v22.Visible = if SelectedObject then v22:IsDescendantOf(SelectedObject) else SelectedObject
		end
	end

	GuiService:GetPropertyChangedSignal("SelectedObject"):Connect(onSelectionChange)
	Sell2.TopBar.CloseButton.MouseButton1Down:Connect(function() --[[ Line: 105 | Upvalues: p1 (copy) ]]
		p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
	end)

	local Counter = v1.Counter

	v1.SellAll.MouseButton1Down:Connect(function() --[[ Line: 112 | Upvalues: playSellSound (ref), Remotes (ref) ]]
		playSellSound()
		Remotes.SellAllFish:Fire()
	end)

	local function ensureEntry(p1, p2) --[[ ensureEntry | Line: 120 | Upvalues: FishConfig (ref), t (copy), Template (copy), playSellSound (ref), Remotes (ref), ScrollingFrame (copy) ]]
		local v1 = FishConfig[p2]

		if not v1 then
			return nil
		end

		local v2 = t[p1]

		if v2 then
			return v2
		end

		local v3 = Template:Clone()

		v3.Name = p1
		v3.Visible = true
		v3.FishInfo.Icon.Image = v1.Image
		v3.DisplayName.Text = v1.DisplayName

		local Rarity = v3.Rarity

		Rarity.Text = v1.Rarity.displayName
		Rarity.TextColor3 = v1.Rarity.rarityColor
		v3.SellButton.MouseButton1Down:Connect(function() --[[ Line: 145 | Upvalues: playSellSound (ref), Remotes (ref), p1 (copy) ]]
			playSellSound()
			Remotes.SellFish:Fire(p1)
		end)
		v3.Parent = ScrollingFrame
		t[p1] = v3

		return v3
	end

	local function updateEntry(p1, p2, p3, p4, p5) --[[ updateEntry | Line: 155 | Upvalues: t (copy), MutationList (ref), CashDisplay (ref) ]]
		local v1 = t[p1]

		if not v1 then
			return
		end

		local v2 = MutationList.displayLabel(MutationList.parse(p3))

		v1.Stack.Text = ("Lvl %*%* \194\183 Stack x%*"):format(p2, if v2 == "" then "" else (" \194\183 %*"):format(v2), p4)
		CashDisplay.applyToLabel(v1.SellValue, p5)
	end

	local function destroyEntry(p1) --[[ destroyEntry | Line: 168 | Upvalues: t (copy) ]]
		local v1 = t[p1]

		if not v1 then
			return
		end

		v1:Destroy()
		t[p1] = nil
	end

	local function refresh() --[[ refresh | Line: 176 | Upvalues: ClientPlayerData (ref), FishConfig (ref), favoriteCount (ref), FishEarnings (ref), ensureEntry (copy), updateEntry (copy), t (copy), CashDisplay (ref), Counter (copy) ]]
		local v1 = ClientPlayerData.serverProfile:getState()
		local sum = 0
		local t2 = {}

		for k, v in pairs(v1.inventory or {}) do
			if v.Category == "Fish" then
				local v3 = FishConfig[v.ConfigName]

				if v3 then
					local v4 = (v.Stack or 1) - favoriteCount(v1.favorites, k)

					if not (v4 <= 0) then
						local v5 = v.ExtraInfo and v.ExtraInfo.Level or 1
						local v6 = v.ExtraInfo and v.ExtraInfo.Mutation
						local v8 = math.floor(v3.Earnings * FishEarnings.levelMultiplier(v5) * FishEarnings.mutationMultiplier(v6)) * v4

						sum = sum + v8

						if ensureEntry(k, v.ConfigName) then
							updateEntry(k, v5, v6, v4, v8)
							t2[k] = true
						end
					end
				end
			end
		end

		for k in pairs(t) do
			if not t2[k] then
				local v9 = t[k]

				if v9 then
					v9:Destroy()
					t[k] = nil
				end
			end
		end

		CashDisplay.applyToLabel(Counter, sum, {
			Prefix = "Total Value: "
		})
	end

	refresh()
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 221 ]]
		return p1.inventory
	end, refresh)
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 225 ]]
		return p1.favorites
	end, refresh)
end

return t