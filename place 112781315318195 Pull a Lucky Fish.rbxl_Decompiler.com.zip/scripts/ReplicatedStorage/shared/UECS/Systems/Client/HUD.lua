-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ContextActionService = game:GetService("ContextActionService")
local GuiService = game:GetService("GuiService")
local HttpService = game:GetService("HttpService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local StarterGui = game:GetService("StarterGui")
local TweenService = game:GetService("TweenService")
local BuildModeState = require(ReplicatedStorage.client.BuildModeState)
local CashDisplay = require(ReplicatedStorage.shared.module.CashDisplay)
local CashFormat = require(ReplicatedStorage.shared.util.CashFormat)
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local ConvertValue = require(ReplicatedStorage.shared.util.ConvertValue)
local FishEarnings = require(ReplicatedStorage.shared.util.FishEarnings)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local HUD = require(ReplicatedStorage.shared.UECS.Components.HUD)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local GymEventConfig = require(ReplicatedStorage.shared.config.GymEventConfig)
local TweenNumber = require(ReplicatedStorage.shared.util.TweenNumber)

require(ReplicatedStorage.shared.UECS.UECS)

local calculateFriendBonus = require(ReplicatedStorage.shared.util.calculateFriendBonus)
local SocialService = game:GetService("SocialService")
local topbarplus = require(ReplicatedStorage.client.Satchel.Package.topbarplus)
local notifications = require(ReplicatedStorage.shared.module.notifications)
local SFX = require(ReplicatedStorage.client.SFX)
local TutorialConfig = require(ReplicatedStorage.shared.config.TutorialConfig)
local UIVFX = require(ReplicatedStorage.shared.module.UIVFX)
local bindToButtonPress = require(ReplicatedStorage.shared.util.bindToButtonPress)
local v1 = #TutorialConfig + 1

local function blockedDuringTutorial() --[[ blockedDuringTutorial | Line: 35 | Upvalues: ClientPlayerData (copy), v1 (copy), notifications (copy) ]]
	if ClientPlayerData.serverProfile:getState().tutorialInfo.tutorialStep < v1 then
		notifications:Send("Finish the tutorial first!")

		return true
	end

	return false
end

local Base = ReplicatedStorage.shared.model.Tycoon.Base
local t = {
	UECS = nil,
	Priority = 40
}

function t.Init(p1) --[[ Init | Line: 90 | Upvalues: ReplicatedStorage (copy), Players (copy), HUD (copy), CashDisplay (copy), CollectionService (copy), ClientPlayerData (copy), FishEarnings (copy), BuildModeState (copy), TweenNumber (copy), ConvertValue (copy), SFX (copy), TweenService (copy), CashFormat (copy), t (copy), UIVFX (copy), topbarplus (copy), ContextActionService (copy), calculateFriendBonus (copy), SocialService (copy), HttpService (copy), StarterGui (copy), Remotes (copy), GymEventConfig (copy), v1 (copy), notifications (copy), GuiService (copy), bindToButtonPress (copy) ]]
	require(ReplicatedStorage.client.Satchel)

	local HUD2 = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI").HUD

	HUD.Add(HUD2)
	CashDisplay.attachTierTooltip(HUD2.Counters.Cash)

	local FriendBoost = HUD2.Counters:FindFirstChild("FriendBoost")

	if FriendBoost and FriendBoost:IsA("GuiObject") then
		FriendBoost.Visible = false
	end

	for v12, v2 in HUD2.Buttons:GetChildren() do
		if v2:IsA("GuiButton") then
			CollectionService:AddTag(v2, "VFX_HoverIconBounce")
			CollectionService:AddTag(v2, "VFX_HoverShine")
		end
	end

	local Frame = HUD2.Buttons.Shop:FindFirstChild("Frame")

	if Frame then
		CollectionService:AddTag(Frame, "VFX_GradientScroll")
	end

	local v3 = ClientPlayerData.serverProfile:getState()
	local LocalPlayer = Players.LocalPlayer
	local FishOfflineEarnings = HUD2:FindFirstChild("FishOfflineEarnings")

	if FishOfflineEarnings then
		FishOfflineEarnings.Visible = false

		local function getOwnTycoonModel() --[[ getOwnTycoonModel | Line: 130 | Upvalues: p1 (copy), LocalPlayer (copy) ]]
			for v1, v2 in p1.UECS:GetComponents("TycoonComponent") do
				if v2.Owner:Get() == LocalPlayer and typeof(v2.Entity) == "Instance" then
					return v2.Entity
				end
			end

			return nil
		end

		local function computeDailyOfflineIncome() --[[ computeDailyOfflineIncome | Line: 140 | Upvalues: FishEarnings (ref), LocalPlayer (copy) ]]
			return FishEarnings.perSecond(LocalPlayer, true) * 43200
		end

		task.spawn(function() --[[ Line: 144 | Upvalues: FishOfflineEarnings (copy), getOwnTycoonModel (copy), LocalPlayer (copy), BuildModeState (ref), CashDisplay (ref), FishEarnings (ref) ]]
			while FishOfflineEarnings.Parent do
				local v1, v2
				local v3 = getOwnTycoonModel()
				local Character = LocalPlayer.Character
				local v4 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character

				if v3 and v4 then
					local v5, v6 = v3:GetBoundingBox()
					local v7 = v5:PointToObjectSpace(v4.Position)

					v1 = if math.abs(v7.X) <= v6.X / 2 then math.abs(v7.Z) <= v6.Z / 2 else false
					v2 = v1
				else
					v2 = false
				end

				if v2 and not BuildModeState.InGarden then
					CashDisplay.applyParts(FishOfflineEarnings, {
						"Your fishes earn ",
						{
							Compact = true,
							Value = FishEarnings.perSecond(LocalPlayer, true) * 43200
						},
						"/Day offline! "
					}, {
						AmountColor = Color3.fromRGB(28, 231, 9)
					})
					FishOfflineEarnings.Visible = true
				else
					FishOfflineEarnings.Visible = false
				end

				task.wait(0.5)
			end
		end)
	end

	local v4 = TweenNumber.new(0.35, v3.money)

	v4:OnChange(function(p1) --[[ Line: 174 | Upvalues: HUD2 (copy), CashDisplay (ref) ]]
		if HUD2.Parent then
			CashDisplay.render(HUD2.Counters.Cash, p1, {
				SuffixIcon = true
			})
		end
	end)

	local strength = v3.strength

	local function renderStrengthCounter() --[[ renderStrengthCounter | Line: 184 | Upvalues: HUD2 (copy), ConvertValue (ref), strength (ref), LocalPlayer (copy) ]]
		if not HUD2.Parent then
			return
		end

		local v1 = ("%* Throw Power"):format((ConvertValue.suffixformat(strength)))
		local v2 = LocalPlayer:GetAttribute("CustomThrowPowerLimit")

		if typeof(v2) == "number" and v2 > 0 then
			v1 = v1 .. (" (%*)"):format((ConvertValue.suffixformat((math.min(v2, strength)))))
		end

		HUD2.Counters.Strength.Counter.Text = v1
	end

	local v5 = TweenNumber.new(0.35, v3.strength)

	v5:OnChange(function(p1) --[[ Line: 198 | Upvalues: strength (ref), renderStrengthCounter (copy) ]]
		strength = p1
		renderStrengthCounter()
	end)

	local function setCashLabel(p1) --[[ setCashLabel | Line: 203 | Upvalues: v4 (copy) ]]
		v4:Set(p1, function() --[[ Line: 204 ]] end)
	end

	CashDisplay.render(HUD2.Counters.Cash, v3.money, {
		SuffixIcon = true
	})
	renderStrengthCounter()
	LocalPlayer:GetAttributeChangedSignal("CustomThrowPowerLimit"):Connect(renderStrengthCounter)
	LocalPlayer:GetAttributeChangedSignal("CashMultiplier"):Connect(function() --[[ Line: 212 | Upvalues: ClientPlayerData (ref), v4 (copy) ]]
		v4:Set(ClientPlayerData.serverProfile:getState().money, function() --[[ Line: 204 ]] end)
	end)

	local StrengthGain = HUD2.Effects.StrengthGain

	StrengthGain.Visible = false

	local CashGain = HUD2.Effects.CashGain

	CashGain.Visible = false

	local function PlayStrengthGain(p1) --[[ PlayStrengthGain | Line: 222 | Upvalues: SFX (ref), StrengthGain (copy), ConvertValue (ref), HUD2 (copy), TweenService (ref) ]]
		SFX.new(SFX.Sounds.Training, 0.4)

		local v1 = StrengthGain:Clone()

		v1.Parent = StrengthGain.Parent
		v1.Increase.Text = ("+%* Throw"):format((ConvertValue.suffixformat(p1)))

		local AbsolutePosition = HUD2.AbsolutePosition
		local AbsoluteSize = HUD2.AbsoluteSize
		local AbsoluteSize2 = v1.AbsoluteSize
		local v2 = AbsolutePosition.X + AbsoluteSize.X * (0.2 + math.random() * 0.6)

		v1.Position = UDim2.fromOffset(v2 - AbsolutePosition.X - AbsoluteSize2.X / 2, AbsolutePosition.Y + AbsoluteSize.Y * (0.2 + math.random() * 0.6) - AbsolutePosition.Y - AbsoluteSize2.Y / 2)
		v1.Rotation = math.random(-20, 20)
		v1.Visible = true
		task.delay(0.45, function() --[[ Line: 242 | Upvalues: HUD2 (ref), AbsoluteSize2 (copy), TweenService (ref), v1 (copy), AbsolutePosition (copy) ]]
			local Strength = HUD2.Counters.Strength
			local v12 = Strength.AbsolutePosition + Strength.AbsoluteSize / 2
			local v2 = AbsoluteSize2 * 0.4
			local v3 = TweenService:Create(v1, TweenInfo.new(0.55, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
				Rotation = 0,
				Position = UDim2.fromOffset(v12.X - AbsolutePosition.X - v2.X / 2, v12.Y - AbsolutePosition.Y - v2.Y / 2),
				Size = UDim2.fromOffset(v2.X, v2.Y)
			})

			v3:Play()
			v3.Completed:Connect(function() --[[ Line: 260 | Upvalues: v1 (ref) ]]
				v1:Destroy()
			end)
		end)
	end

	local v6 = 0

	function t.PlayCashGain(p1, p2) --[[ PlayCashGain | Line: 267 | Upvalues: v6 (ref), SFX (ref), CashGain (copy), CashFormat (ref), HUD2 (copy), TweenService (ref) ]]
		v6 = os.clock() + 0.5
		SFX.new(SFX.Sounds.CashCollect, 0.4)

		local v1 = CashGain:Clone()

		v1.Parent = CashGain.Parent

		local v2 = CashFormat.compact(p2)

		v1.Increase.Text = ("+%*"):format(v2.Text)
		v1.Icon.Image = v2.Icon
		v1.Icon.Visible = v2.Icon ~= ""

		local AbsolutePosition = HUD2.AbsolutePosition
		local AbsoluteSize = HUD2.AbsoluteSize
		local AbsoluteSize2 = v1.AbsoluteSize

		v1.Position = UDim2.fromOffset(AbsolutePosition.X + AbsoluteSize.X * (0.2 + math.random() * 0.6) - AbsolutePosition.X - AbsoluteSize2.X / 2, AbsolutePosition.Y + AbsoluteSize.Y * (0.2 + math.random() * 0.6) - AbsolutePosition.Y - AbsoluteSize2.Y / 2)
		v1.Rotation = math.random(-20, 20)
		v1.Visible = true
		task.delay(0.45, function() --[[ Line: 294 | Upvalues: HUD2 (ref), AbsoluteSize2 (copy), TweenService (ref), v1 (copy), AbsolutePosition (copy) ]]
			local Cash = HUD2.Counters.Cash
			local v12 = Cash.AbsolutePosition + Cash.AbsoluteSize / 2
			local v2 = AbsoluteSize2 * 0.4
			local v3 = TweenService:Create(v1, TweenInfo.new(0.55, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
				Rotation = 0,
				Position = UDim2.fromOffset(v12.X - AbsolutePosition.X - v2.X / 2, v12.Y - AbsolutePosition.Y - v2.Y / 2),
				Size = UDim2.fromOffset(v2.X, v2.Y)
			})

			v3:Play()
			v3.Completed:Connect(function() --[[ Line: 312 | Upvalues: v1 (ref) ]]
				v1:Destroy()
			end)
		end)
	end
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 318 ]]
		return p1.strength
	end, function(p1, p2) --[[ Line: 320 | Upvalues: v5 (copy), UIVFX (ref), HUD2 (copy), LocalPlayer (copy), PlayStrengthGain (copy) ]]
		v5:Set(p1, function() --[[ Line: 321 ]] end)

		local v1 = p1 - p2

		if not (v1 > 0) then
			return
		end

		UIVFX.PulseScale.Pulse(HUD2.Counters.Strength)

		local v2 = LocalPlayer:GetAttribute("SuppressStrengthGainUntil")

		if typeof(v2) == "number" and workspace:GetServerTimeNow() < v2 then
			return
		end

		task.spawn(PlayStrengthGain, v1)
	end)
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 336 ]]
		return p1.money
	end, function(p1, p2) --[[ Line: 338 | Upvalues: v4 (copy), UIVFX (ref), HUD2 (copy), v6 (ref), t (ref) ]]
		v4:Set(p1, function() --[[ Line: 204 ]] end)

		if not p2 then
			return
		end

		local v1 = p1 - p2

		if not (v1 > 0) then
			return
		end

		UIVFX.PulseScale.Pulse(HUD2.Counters.Cash)

		if not (v6 <= os.clock()) then
			return
		end

		task.spawn(t.PlayCashGain, t, v1)
	end)

	local v7 = false
	local v8 = topbarplus.new()

	v8:setName("FriendBoost")
	v8:setLeft()
	v8:setImage("rbxassetid://90980290694239")
	v8:setLabel("Boost")
	v8:setCaption("Invite friends for more Coins")

	local v9 = nil

	local function currentFriendBonus() --[[ currentFriendBonus | Line: 379 | Upvalues: Players (ref) ]]
		local v1 = Players.LocalPlayer:GetAttribute("FriendMultiplier")

		if typeof(v1) == "number" then
			return math.round((v1 - 1) * 100)
		end

		return 0
	end

	local function UpdateFriendBoost() --[[ UpdateFriendBoost | Line: 389 | Upvalues: v9 (ref), Players (ref), v8 (copy) ]]
		local v1 = v9

		if not v1 then
			local v2 = Players.LocalPlayer:GetAttribute("FriendMultiplier")

			v1 = if typeof(v2) == "number" then math.round((v2 - 1) * 100) else 0
		end

		v8:setLabel(if v1 > 0 then ("+%*%%"):format(v1) else "Boost")
		v8:setCaption(if v1 > 0 then ("Friend Boost: +%*%% Coins"):format(v1) else "Invite friends for more Coins")
	end

	ContextActionService:BindAction("FriendBoostPreview", function(p1, p2) --[[ Line: 402 | Upvalues: v9 (ref), calculateFriendBonus (ref), UpdateFriendBoost (copy) ]]
		if p2 ~= Enum.UserInputState.Begin then
			return Enum.ContextActionResult.Pass
		end

		local v1 = if v9 then v9 / 10 + 1 else 1

		v9 = if v1 > 3 then nil else calculateFriendBonus(v1)
		task.spawn(UpdateFriendBoost)

		return Enum.ContextActionResult.Sink
	end, false, Enum.KeyCode.N)
	Players.LocalPlayer:GetAttributeChangedSignal("FriendMultiplier"):Connect(UpdateFriendBoost)

	local function promptGameInvite() --[[ promptGameInvite | Line: 426 | Upvalues: SocialService (ref), LocalPlayer (copy), HttpService (ref) ]]
		local ok, result = pcall(function() --[[ Line: 427 | Upvalues: SocialService (ref), LocalPlayer (ref) ]]
			return SocialService:CanSendGameInviteAsync(LocalPlayer)
		end)

		if not ok then
			warn((("[Invite] CanSendGameInviteAsync errored: %*"):format(result)))

			return
		end

		if not result then
			warn("[Invite] CanSendGameInviteAsync = false \226\128\148 this player cannot invite here")

			return
		end

		local ok2, result2 = pcall(function() --[[ Line: 442 | Upvalues: HttpService (ref), LocalPlayer (ref), SocialService (ref) ]]
			local ExperienceInviteOptions = Instance.new("ExperienceInviteOptions")

			ExperienceInviteOptions.PromptMessage = "Invite a friend"
			ExperienceInviteOptions.LaunchData = HttpService:JSONEncode({
				ref = LocalPlayer.UserId
			})
			SocialService:PromptGameInvite(LocalPlayer, ExperienceInviteOptions)
		end)

		if ok2 then
			return
		end

		warn((("[Invite] tagged prompt failed, falling back to an untagged one: %*"):format(result2)))

		local ok3, result3 = pcall(function() --[[ Line: 453 | Upvalues: SocialService (ref), LocalPlayer (ref) ]]
			SocialService:PromptGameInvite(LocalPlayer)
		end)

		if ok3 then
			return
		end

		warn((("[Invite] PromptGameInvite failed entirely: %*"):format(result3)))
	end

	local v10 = StarterGui:GetCore("PlayerFriendedEvent")
	local v11 = StarterGui:GetCore("PlayerUnfriendedEvent")

	v10.Event:Connect(function() --[[ Line: 464 | Upvalues: UpdateFriendBoost (copy), Remotes (ref) ]]
		task.spawn(UpdateFriendBoost)
		Remotes.FriendBoostRecalculate:Fire()
	end)
	v11.Event:Connect(function() --[[ Line: 468 | Upvalues: UpdateFriendBoost (copy), Remotes (ref) ]]
		task.spawn(UpdateFriendBoost)
		Remotes.FriendBoostRecalculate:Fire()
	end)
	task.spawn(UpdateFriendBoost)
	v8:bindEvent("selected", function() --[[ Line: 473 | Upvalues: v8 (copy), v7 (ref), GymEventConfig (ref), Players (ref), LocalPlayer (copy), StarterGui (ref), promptGameInvite (copy) ]]
		v8:deselect()

		if not v7 then
			v7 = true
			task.spawn(function() --[[ Line: 480 | Upvalues: GymEventConfig (ref), Players (ref), LocalPlayer (ref), StarterGui (ref), promptGameInvite (ref), v7 (ref) ]]
				local v1 = nil

				if not GymEventConfig.Enabled then
					local t = {}

					for v2, v3 in Players:GetPlayers() do
						if v3 ~= LocalPlayer then
							local ok, result = pcall(function() --[[ Line: 496 | Upvalues: v3 (copy), LocalPlayer (ref) ]]
								return v3:IsFriendsWithAsync(LocalPlayer.UserId)
							end)

							if ok and not result then
								table.insert(t, v3)
							end
						end
					end

					if #t > 0 then
						v1 = t[math.random(#t)]
					end
				end

				if v1 then
					StarterGui:SetCore("PromptSendFriendRequest", v1)
				else
					promptGameInvite()
				end

				v7 = false
			end)
		end
	end)
	HUD2.Buttons.FishingFloat.MouseButton1Down:Connect(function() --[[ Line: 518 | Upvalues: ClientPlayerData (ref), v1 (ref), notifications (ref), p1 (copy) ]]
		local v12

		if ClientPlayerData.serverProfile:getState().tutorialInfo.tutorialStep < v1 then
			notifications:Send("Finish the tutorial first!")
			v12 = true
		else
			v12 = false
		end

		if v12 then
			return
		end

		local v2 = p1.UECS:WaitForAnyComponent("UIFrameOpener")
		local v3 = p1.UECS:WaitForAnyComponent("FishingFloats")

		if v2.OpenedUIComponent:Get() == v3 then
			v2.OpenedUIComponent:Set(nil)
		else
			v2.OpenedUIComponent:Set(v3)
		end
	end)
	HUD2.Buttons.Index.MouseButton1Down:Connect(function() --[[ Line: 531 | Upvalues: ClientPlayerData (ref), v1 (ref), notifications (ref), p1 (copy) ]]
		local v12

		if ClientPlayerData.serverProfile:getState().tutorialInfo.tutorialStep < v1 then
			notifications:Send("Finish the tutorial first!")
			v12 = true
		else
			v12 = false
		end

		if v12 then
			return
		end

		local v2 = p1.UECS:WaitForAnyComponent("UIFrameOpener")
		local v3 = p1.UECS:WaitForAnyComponent("Index")

		if v2.OpenedUIComponent:Get() == v3 then
			v2.OpenedUIComponent:Set(nil)
		else
			v2.OpenedUIComponent:Set(v3)
		end
	end)

	local ButtonsRightSide = HUD2:FindFirstChild("ButtonsRightSide")
	local v12 = if ButtonsRightSide then ButtonsRightSide:FindFirstChild("Quest") else HUD2.Buttons:FindFirstChild("Quest")

	if v12 then
		v12.Activated:Connect(function() --[[ Line: 554 | Upvalues: ClientPlayerData (ref), v1 (ref), notifications (ref), p1 (copy) ]]
			local v12

			if ClientPlayerData.serverProfile:getState().tutorialInfo.tutorialStep < v1 then
				notifications:Send("Finish the tutorial first!")
				v12 = true
			else
				v12 = false
			end

			if v12 then
				return
			end

			local v2 = p1.UECS:WaitForAnyComponent("UIFrameOpener")
			local v3 = p1.UECS:WaitForAnyComponent("QuestsUI")

			if v2.OpenedUIComponent:Get() == v3 then
				v2.OpenedUIComponent:Set(nil)
			else
				v2.OpenedUIComponent:Set(v3)
			end
		end)
	end

	local Milestones = HUD2.Buttons:FindFirstChild("Milestones")

	if Milestones then
		Milestones.Activated:Connect(function() --[[ Line: 570 | Upvalues: ClientPlayerData (ref), v1 (ref), notifications (ref), p1 (copy) ]]
			local v12

			if ClientPlayerData.serverProfile:getState().tutorialInfo.tutorialStep < v1 then
				notifications:Send("Finish the tutorial first!")
				v12 = true
			else
				v12 = false
			end

			if v12 then
				return
			end

			local v2 = p1.UECS:WaitForAnyComponent("UIFrameOpener")
			local v3 = p1.UECS:WaitForAnyComponent("MilestonesUI")

			if v2.OpenedUIComponent:Get() == v3 then
				v2.OpenedUIComponent:Set(nil)
			else
				v2.OpenedUIComponent:Set(v3)
			end
		end)
	end

	HUD2.Buttons.Rebirth.MouseButton1Down:Connect(function() --[[ Line: 584 | Upvalues: ClientPlayerData (ref), v1 (ref), notifications (ref), p1 (copy) ]]
		local v12

		if ClientPlayerData.serverProfile:getState().tutorialInfo.tutorialStep < v1 then
			notifications:Send("Finish the tutorial first!")
			v12 = true
		else
			v12 = false
		end

		if v12 then
			return
		end

		local v2 = p1.UECS:WaitForAnyComponent("UIFrameOpener")
		local v3 = p1.UECS:WaitForAnyComponent("Rebirth")

		if v2.OpenedUIComponent:Get() == v3 then
			v2.OpenedUIComponent:Set(nil)
		else
			v2.OpenedUIComponent:Set(v3)
		end
	end)
	HUD2.Buttons.Shop.MouseButton1Down:Connect(function() --[[ Line: 597 | Upvalues: p1 (copy) ]]
		local v1 = p1.UECS:WaitForAnyComponent("UIFrameOpener")
		local v2 = p1.UECS:WaitForAnyComponent("Store")

		if v1.OpenedUIComponent:Get() == v2 then
			v1.OpenedUIComponent:Set(nil)
		else
			v1.OpenedUIComponent:Set(v2)
		end
	end)

	local Alert = HUD2.Buttons.Shop:FindFirstChild("Alert")

	if Alert then
		Alert.Visible = true
		task.spawn(function() --[[ Line: 615 | Upvalues: p1 (copy), Alert (copy) ]]
			local v1 = p1.UECS:WaitForAnyComponent("Store")

			local function hideOnOpen(p1) --[[ hideOnOpen | Line: 617 | Upvalues: Alert (ref) ]]
				if not (p1 and Alert.Visible) then
					return
				end

				Alert.Visible = false
			end

			v1.Visible.OnChange:Connect(hideOnOpen)

			if not (v1.Visible:Get() and Alert.Visible) then
				return
			end

			Alert.Visible = false
		end)
	end

	local GemsShop = HUD2.Buttons:FindFirstChild("GemsShop")
	local v13, v14, _, v15, v16, v17

	if GemsShop then
		GemsShop.MouseButton1Down:Connect(function() --[[ Line: 629 | Upvalues: p1 (copy) ]]
			local v1 = p1.UECS:WaitForAnyComponent("UIFrameOpener")
			local v2 = p1.UECS:WaitForAnyComponent("GemsShop")

			if v1.OpenedUIComponent:Get() == v2 then
				v1.OpenedUIComponent:Set(nil)
			else
				v1.OpenedUIComponent:Set(v2)
			end
		end)
	end

	v13 = { "Buttons", "ButtonsRightSide", "MountKeybind" }
	v14 = function() --[[ collectSelectableButtons | Line: 664 | Upvalues: v13 (copy), HUD2 (copy) ]]
		local t = {}

		for v1, v2 in v13 do
			local v3 = HUD2:FindFirstChild(v2)

			if v3 then
				for v4, v5 in v3:GetChildren() do
					if v5:IsA("GuiButton") and (v5.Visible and v5.AbsoluteSize.X > 0) then
						v5.Selectable = true
						table.insert(t, v5)
					end
				end
			end
		end

		return t
	end
	_ = function(p1) --[[ centerOf | Line: 683 ]]
		return p1.AbsolutePosition.X + p1.AbsoluteSize.X / 2, p1.AbsolutePosition.Y + p1.AbsoluteSize.Y / 2
	end
	v15 = function(p1, p2) --[[ nearestInColumn | Line: 690 ]]
		if not p1 then
			return nil
		end

		local _ = p2.AbsolutePosition.X + p2.AbsoluteSize.X / 2
		local v1 = p2.AbsolutePosition.Y + p2.AbsoluteSize.Y / 2
		local v2 = (1 / 0)
		local v3 = nil

		for v4, v5 in p1 do
			local _2 = v5.AbsolutePosition.X + v5.AbsoluteSize.X / 2
			local v7 = math.abs(v5.AbsolutePosition.Y + v5.AbsoluteSize.Y / 2 - v1)

			if v7 < v2 then
				v2 = v7
				v3 = v5
			end
		end

		return v3
	end
	v16 = function() --[[ wireSelectionGraph | Line: 708 | Upvalues: v14 (copy), HUD2 (copy), v15 (copy) ]]
		local v1 = v14()

		if #v1 == 0 then
			return
		end

		table.sort(v1, function(p1, p2) --[[ Line: 714 ]]
			local _ = p1.AbsolutePosition.Y + p1.AbsoluteSize.Y / 2
			local _2 = p2.AbsolutePosition.Y + p2.AbsoluteSize.Y / 2

			return p1.AbsolutePosition.X + p1.AbsoluteSize.X / 2 < p2.AbsolutePosition.X + p2.AbsoluteSize.X / 2
		end)

		local v2 = nil
		local t = {}
		local t2 = {}

		for v3, v4 in v1 do
			local v5 = v4.AbsolutePosition.X + v4.AbsoluteSize.X / 2
			local _ = v4.AbsolutePosition.Y + v4.AbsoluteSize.Y / 2

			if v2 then
				local v6 = math.abs(v5 - v2)

				if math.max(v4.AbsoluteSize.X * 0.6, 1) < v6 then
					table.insert(t, t2)
					t2 = {}
				end
			end

			table.insert(t2, v4)
			v2 = v5
		end

		table.insert(t, t2)

		local Counters = HUD2:FindFirstChild("Counters")
		local v8 = if Counters then Counters:FindFirstChild("Strength") else Counters
		local v9 = if v8 then v8:FindFirstChild("Edit") else v8

		if v9 and (v9:IsA("GuiButton") and (v9.Visible and v9.AbsoluteSize.X > 0)) then
			v9.Selectable = true
			table.insert(t[1], v9)
		end

		for v11, v12 in t do
			table.sort(v12, function(p1, p2) --[[ Line: 754 ]]
				local _ = p1.AbsolutePosition.X + p1.AbsoluteSize.X / 2
				local _2 = p2.AbsolutePosition.X + p2.AbsoluteSize.X / 2

				return p1.AbsolutePosition.Y + p1.AbsoluteSize.Y / 2 < p2.AbsolutePosition.Y + p2.AbsoluteSize.Y / 2
			end)
		end

		for v13, v142 in t do
			for v152, v16 in v142 do
				v16.NextSelectionUp = v142[v152 - 1] or v142[#v142]
				v16.NextSelectionDown = v142[v152 + 1] or v142[1]
				v16.NextSelectionLeft = v15(t[v13 - 1], v16)
				v16.NextSelectionRight = v15(t[v13 + 1], v16)
			end
		end
	end
	GuiService:GetPropertyChangedSignal("SelectedObject"):Connect(function() --[[ Line: 781 | Upvalues: GuiService (ref), ContextActionService (ref) ]]
		if GuiService.SelectedObject then
			return
		end

		ContextActionService:UnbindAction("HudDefocusAction")
	end)
	bindToButtonPress("HudFocusAction", Enum.KeyCode.DPadLeft, function() --[[ Line: 787 | Upvalues: v16 (copy), GuiService (ref), HUD2 (copy), bindToButtonPress (ref) ]]
		v16()
		GuiService:Select(HUD2.Buttons)
		bindToButtonPress("HudDefocusAction", Enum.KeyCode.ButtonB, function() --[[ Line: 790 | Upvalues: GuiService (ref) ]]
			GuiService.SelectedObject = nil
		end, 7500)
	end, 1000)
	v17 = game:GetService("GamepadService")
	bindToButtonPress("HudGamepadCursorToggle", Enum.KeyCode.ButtonSelect, function() --[[ Line: 801 | Upvalues: v17 (copy) ]]
		if v17.GamepadCursorEnabled then
			v17:DisableGamepadCursor()
		else
			v17:EnableGamepadCursor(nil)
		end
	end, 1000)
end

return t