-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local CashDisplay = require(ReplicatedStorage.shared.module.CashDisplay)
local CashFormat = require(ReplicatedStorage.shared.util.CashFormat)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Remotes = require(ReplicatedStorage.shared.Remotes)
local SFX = require(ReplicatedStorage.client.SFX)
local SignalBag = require(ReplicatedStorage.client.SignalBag)
local t = {
	UECS = nil
}
local HeadShot = Enum.ThumbnailType.HeadShot
local Size150x150 = Enum.ThumbnailSize.Size150x150

function t.Init(p1) --[[ Init | Line: 25 | Upvalues: Players (copy), CashFormat (copy), CashDisplay (copy), SFX (copy), TweenService (copy), HeadShot (copy), Size150x150 (copy), SignalBag (copy), Remotes (copy) ]]
	local Notifications = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI"):WaitForChild("Notifications")
	local Template = Notifications:WaitForChild("Template")

	Template.Visible = false

	local AdminMessageTemplate = Notifications:WaitForChild("AdminMessageTemplate")

	AdminMessageTemplate.Visible = false

	local v1 = 0

	local function spawnToast(p1, p2) --[[ spawnToast | Line: 41 | Upvalues: Template (copy), v1 (ref), CashFormat (ref), CashDisplay (ref), SFX (ref), Notifications (copy), TweenService (ref) ]]
		local v12 = if typeof(p2) == "number" and p2 > 0 then p2 else 3.5
		local Notification = Template:Clone()

		Notification.Name = "Notification"
		Notification.RichText = true
		v1 = v1 - 1
		Notification.LayoutOrder = v1

		local t = {}

		if CashFormat.hasToken(p1) then
			CashDisplay.applyTokens(Notification, p1)

			local CashSegments = Notification:FindFirstChild("CashSegments")

			if CashSegments then
				for v2, v3 in CashSegments:GetDescendants() do
					if v3:IsA("TextLabel") then
						table.insert(t, {
							property = "TextTransparency",
							shown = 0,
							object = v3
						})
						v3.TextTransparency = 1

						continue
					end

					if v3:IsA("ImageLabel") then
						table.insert(t, {
							property = "ImageTransparency",
							shown = 0,
							object = v3
						})
						v3.ImageTransparency = 1

						continue
					end

					if v3:IsA("UIStroke") then
						table.insert(t, {
							property = "Transparency",
							object = v3,
							shown = v3.Transparency
						})
						v3.Transparency = 1
					end
				end
			end
		else
			Notification.Text = p1
		end

		Notification.TextTransparency = 1
		SFX.new(SFX.Sounds.Notify, 0.5)

		local UIStroke = Notification:FindFirstChildOfClass("UIStroke")
		local v4

		if UIStroke then
			v4 = UIStroke.Transparency
			UIStroke.Transparency = 1
		else
			v4 = nil
		end

		local UIScale = Instance.new("UIScale")

		UIScale.Scale = 0.6
		UIScale.Parent = Notification
		Notification.Visible = true
		Notification.Parent = Notifications
		TweenService:Create(UIScale, TweenInfo.new(0.25, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
			Scale = 1
		}):Play()
		TweenService:Create(Notification, TweenInfo.new(0.25), {
			TextTransparency = 0
		}):Play()

		for v5, v6 in t do
			TweenService:Create(v6.object, TweenInfo.new(0.25), {
				[v6.property] = v6.shown
			}):Play()
		end

		if UIStroke and v4 then
			TweenService:Create(UIStroke, TweenInfo.new(0.25), {
				Transparency = v4
			}):Play()
		end

		task.delay(math.max(0.4, v12 - 0.4), function() --[[ Line: 106 | Upvalues: Notification (copy), TweenService (ref), t (copy), UIScale (copy), UIStroke (copy) ]]
			if not Notification.Parent then
				return
			end

			local v1 = TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.In)

			TweenService:Create(Notification, v1, {
				TextTransparency = 1
			}):Play()

			for v2, v3 in t do
				TweenService:Create(v3.object, v1, {
					[v3.property] = 1
				}):Play()
			end

			TweenService:Create(UIScale, v1, {
				Scale = 0.85
			}):Play()

			if UIStroke then
				TweenService:Create(UIStroke, v1, {
					Transparency = 1
				}):Play()
			end

			task.delay(0.4, function() --[[ Line: 119 | Upvalues: Notification (ref) ]]
				Notification:Destroy()
			end)
		end)
	end

	local function spawnAdminMessage(p1) --[[ spawnAdminMessage | Line: 127 | Upvalues: AdminMessageTemplate (copy), v1 (ref), Players (ref), HeadShot (ref), Size150x150 (ref), SFX (ref), Notifications (copy), TweenService (ref) ]]
		local AdminMessage = AdminMessageTemplate:Clone()

		AdminMessage.Name = "AdminMessage"
		v1 = v1 - 1
		AdminMessage.LayoutOrder = v1

		local Avatar = AdminMessage:FindFirstChild("Avatar")
		local Nickname = AdminMessage:FindFirstChild("Nickname")
		local Message = AdminMessage:FindFirstChild("Message")

		if Avatar then
			task.spawn(function() --[[ Line: 139 | Upvalues: Players (ref), p1 (copy), HeadShot (ref), Size150x150 (ref), Avatar (copy) ]]
				local ok, result = pcall(function() --[[ Line: 140 | Upvalues: Players (ref), p1 (ref), HeadShot (ref), Size150x150 (ref) ]]
					return Players:GetUserThumbnailAsync(p1.AuthorId, HeadShot, Size150x150)
				end)

				if not (ok and Avatar.Parent) then
					return
				end

				Avatar.Image = result
			end)
		end

		if Nickname then
			Nickname.Text = ("%*: "):format(p1.AuthorName)
		end

		if Message then
			Message.Text = p1.Text
		end

		SFX.new(SFX.Sounds.Notify, 0.5)

		local t = {}

		local function track(p1, p2) --[[ track | Line: 161 | Upvalues: t (copy) ]]
			if not p1 or p1[p2] == nil then
				return
			end

			table.insert(t, {
				object = p1,
				property = p2,
				shown = p1[p2]
			})
			p1[p2] = 1
		end

		if Avatar and Avatar.ImageTransparency ~= nil then
			table.insert(t, {
				property = "ImageTransparency",
				object = Avatar,
				shown = Avatar.ImageTransparency
			})
			Avatar.ImageTransparency = 1
		end

		if Nickname and Nickname.TextTransparency ~= nil then
			table.insert(t, {
				property = "TextTransparency",
				object = Nickname,
				shown = Nickname.TextTransparency
			})
			Nickname.TextTransparency = 1
		end

		if Message and Message.TextTransparency ~= nil then
			table.insert(t, {
				property = "TextTransparency",
				object = Message,
				shown = Message.TextTransparency
			})
			Message.TextTransparency = 1
		end

		for v12, v2 in AdminMessage:GetDescendants() do
			if v2:IsA("UIStroke") and (v2 and v2.Transparency ~= nil) then
				table.insert(t, {
					property = "Transparency",
					object = v2,
					shown = v2.Transparency
				})
				v2.Transparency = 1
			end
		end

		local UIScale = Instance.new("UIScale")

		UIScale.Scale = 0.6
		UIScale.Parent = AdminMessage
		AdminMessage.Visible = true
		AdminMessage.Parent = Notifications
		TweenService:Create(UIScale, TweenInfo.new(0.25, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
			Scale = 1
		}):Play()

		for v3, v4 in t do
			TweenService:Create(v4.object, TweenInfo.new(0.25), {
				[v4.property] = v4.shown
			}):Play()
		end

		task.delay(6.6, function() --[[ Line: 189 | Upvalues: AdminMessage (copy), TweenService (ref), UIScale (copy), t (copy) ]]
			if not AdminMessage.Parent then
				return
			end

			local v1 = TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.In)

			TweenService:Create(UIScale, v1, {
				Scale = 0.85
			}):Play()

			for v2, v3 in t do
				TweenService:Create(v3.object, v1, {
					[v3.property] = 1
				}):Play()
			end

			task.delay(0.4, function() --[[ Line: 198 | Upvalues: AdminMessage (ref) ]]
				AdminMessage:Destroy()
			end)
		end)
	end

	SignalBag.Notification:Connect(spawnToast)
	Remotes.AdminMessage:On(function(p1) --[[ Line: 206 | Upvalues: spawnAdminMessage (copy) ]]
		spawnAdminMessage(p1)
	end)
	Remotes.Notification:On(function(p1, p2) --[[ Line: 212 | Upvalues: SignalBag (ref) ]]
		if typeof(p1) ~= "string" then
			return
		end

		SignalBag.Notification:Fire(p1, p2)
	end)
end

return t