-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ContextActionService = game:GetService("ContextActionService")
local GamepadService = game:GetService("GamepadService")
local MarketplaceService = game:GetService("MarketplaceService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

game:GetService("TweenService")

local UserInputService = game:GetService("UserInputService")
local AutoSellShop = require(ReplicatedStorage.shared.UECS.Components.AutoSellShop)
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Remotes = require(ReplicatedStorage.shared.Remotes)
local UnlockAutoSell = require(ReplicatedStorage.shared.UECS.Components.UnlockAutoSell)
local ConvertValue = require(ReplicatedStorage.shared.util.ConvertValue)
local MonetizationConfig = require(ReplicatedStorage.shared.config.MonetizationConfig)
local bindToButtonPress = require(ReplicatedStorage.shared.util.bindToButtonPress)
local rarityConfig = require(ReplicatedStorage.shared.config.rarityConfig)

local function darkenColor(p1, p2) --[[ darkenColor | Line: 28 ]]
	local v1, v2, v3 = p1:ToHSV()

	return Color3.fromHSV(v1, v2, (math.clamp(v3 * p2, 0, 1)))
end

return {
	UECS = nil,
	Init = function(p1) --[[ Init | Line: 36 | Upvalues: ReplicatedStorage (copy), Players (copy), AutoSellShop (copy), bindToButtonPress (copy), GamepadService (copy), ContextActionService (copy), UserInputService (copy), UnlockAutoSell (copy), Remotes (copy), MonetizationConfig (copy), MarketplaceService (copy), ClientPlayerData (copy), rarityConfig (copy), darkenColor (copy), CollectionService (copy), ConvertValue (copy) ]]
		require(ReplicatedStorage.client.Satchel).UECS = p1.UECS

		local PlayerGui = Players.LocalPlayer:WaitForChild("PlayerGui")
		local MainUI = PlayerGui:WaitForChild("MainUI")
		local AutoSellUiNew = MainUI:WaitForChild("AutoSellUiNew")

		AutoSellUiNew.Visible = false

		local CloseButton = AutoSellUiNew:WaitForChild("TopBar"):WaitForChild("CloseButton")
		local v1 = AutoSellUiNew:WaitForChild("Content")
		local ContentMain = AutoSellUiNew:WaitForChild("ContentMain")
		local RaritiesList = v1:WaitForChild("RaritiesList")
		local Template = RaritiesList:WaitForChild("Template")

		ContentMain.Visible = true
		v1.Visible = false

		local v2 = AutoSellShop.Add(AutoSellUiNew)

		v2.Visible.OnChange:Connect(function(p12, p2) --[[ Line: 61 | Upvalues: AutoSellUiNew (copy), ContentMain (copy), v1 (copy), bindToButtonPress (ref), p1 (copy), GamepadService (ref), ContextActionService (ref) ]]
			AutoSellUiNew.Visible = p12

			if p12 then
				ContentMain.Visible = true
				v1.Visible = false
			end

			if p12 == p2 then
				return
			end

			if p12 then
				bindToButtonPress("AutoSellClose", Enum.KeyCode.ButtonB, function() --[[ Line: 70 | Upvalues: p1 (ref) ]]
					p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
				end)
				GamepadService:EnableGamepadCursor(nil)

				return
			end

			ContextActionService:UnbindAction("AutoSellClose")
			GamepadService:DisableGamepadCursor()
		end)
		GamepadService:GetPropertyChangedSignal("GamepadCursorEnabled"):Connect(function() --[[ Line: 87 | Upvalues: v2 (copy), UserInputService (ref), GamepadService (ref) ]]
			if not v2.Visible:Get() or (UserInputService.PreferredInput ~= Enum.PreferredInput.Gamepad or GamepadService.GamepadCursorEnabled) then
				return
			end

			GamepadService:EnableGamepadCursor(nil)
		end)

		local UnlockAutoSell2 = MainUI:WaitForChild("UnlockAutoSell")

		UnlockAutoSell2.Visible = false

		local v3 = UnlockAutoSell.Add(UnlockAutoSell2)

		v3.Visible.OnChange:Connect(function(p12, p2) --[[ Line: 102 | Upvalues: UnlockAutoSell2 (copy), bindToButtonPress (ref), p1 (copy), Remotes (ref), MonetizationConfig (ref), MarketplaceService (ref), Players (ref), ContextActionService (ref) ]]
			UnlockAutoSell2.Visible = p12

			if p12 == p2 then
				return
			end

			if p12 then
				bindToButtonPress("AutoSellPurchaseClose", Enum.KeyCode.ButtonB, function() --[[ Line: 107 | Upvalues: p1 (ref) ]]
					p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
				end)
				bindToButtonPress("AutoSellBuyCrystals", Enum.KeyCode.ButtonX, function() --[[ Line: 112 | Upvalues: Remotes (ref) ]]
					Remotes.BuyAutoSellWithGems:Fire()
				end)
				bindToButtonPress("AutoSellBuyRobux", Enum.KeyCode.ButtonY, function() --[[ Line: 116 | Upvalues: MonetizationConfig (ref), MarketplaceService (ref), Players (ref) ]]
					MarketplaceService:PromptProductPurchase(Players.LocalPlayer, MonetizationConfig.DevProducts.UnlockAutoSell.ProductId)
				end)

				return
			end

			ContextActionService:UnbindAction("AutoSellBuyCrystals")
			ContextActionService:UnbindAction("AutoSellBuyRobux")
			ContextActionService:UnbindAction("AutoSellPurchaseClose")
		end)
		UnlockAutoSell2:WaitForChild("TopBar"):WaitForChild("CloseButton").MouseButton1Click:Connect(function() --[[ Line: 129 | Upvalues: p1 (copy) ]]
			p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
		end)

		local Buy = UnlockAutoSell2:WaitForChild("Content"):WaitForChild("Buy")
		local Price = Buy:FindFirstChild("Price", true)

		if Price then
			Price.Text = "60"
		end

		Buy.MouseButton1Click:Connect(function() --[[ Line: 139 | Upvalues: Remotes (ref) ]]
			Remotes.BuyAutoSellWithGems:Fire()
		end)

		local BuyRobux = UnlockAutoSell2:WaitForChild("Content"):WaitForChild("BuyRobux")
		local Price2 = BuyRobux:FindFirstChild("Price", true)

		if Price2 then
			Price2.Text = "19"
		end

		BuyRobux.MouseButton1Click:Connect(function() --[[ Line: 148 | Upvalues: MonetizationConfig (ref), MarketplaceService (ref), Players (ref) ]]
			MarketplaceService:PromptProductPurchase(Players.LocalPlayer, MonetizationConfig.DevProducts.UnlockAutoSell.ProductId)
		end)
		ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 154 ]]
			return p1.hasAutoSell
		end, function(p12) --[[ Line: 156 | Upvalues: p1 (copy), v3 (copy) ]]
			if not p12 then
				return
			end

			local v1 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

			if v1.OpenedUIComponent:Get() ~= v3 then
				return
			end

			v1.OpenedUIComponent:Set(nil)
		end)
		CloseButton.MouseButton1Click:Connect(function() --[[ Line: 166 | Upvalues: p1 (copy) ]]
			p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
		end)
		ContentMain:WaitForChild("Change").MouseButton1Click:Connect(function() --[[ Line: 173 | Upvalues: ContentMain (copy), v1 (copy) ]]
			ContentMain.Visible = false
			v1.Visible = true
		end)
		v1:WaitForChild("Back").MouseButton1Click:Connect(function() --[[ Line: 179 | Upvalues: v1 (copy), ContentMain (copy) ]]
			v1.Visible = false
			ContentMain.Visible = true
		end)

		local list = {}

		for k, v in pairs(rarityConfig) do
			table.insert(list, v)
		end

		table.sort(list, function(p1, p2) --[[ Line: 189 ]]
			return p1.power < p2.power
		end)

		local t = {}

		for i, v in ipairs(list) do
			local v4 = Template:Clone()

			v4.Name = v.id
			v4.LayoutOrder = i
			v4.Visible = true
			v4.Parent = RaritiesList

			local rarityColor = v.rarityColor

			v4.BackgroundColor3 = Color3.new(255/255, 255/255, 255/255)

			local UIGradient = Instance.new("UIGradient")
			local v6 = ColorSequence.new
			local v7, v8, v9 = (v.BackgroundColor or rarityColor):ToHSV()

			UIGradient.Color = v6(Color3.fromHSV(v7, v8, (math.clamp(v9 * 0.55, 0, 1))), darkenColor(v.raritySecondColor or rarityColor, 0.55))
			UIGradient.Rotation = 45
			UIGradient.Parent = v4

			local UIStroke = v4:FindFirstChild("UIStroke")

			if UIStroke then
				local v10, v11, v12 = rarityColor:ToHSV()

				UIStroke.Color = Color3.fromHSV(v10, v11, (math.clamp(v12 * 0.35, 0, 1)))
			end

			local Pattern = v4:FindFirstChild("Pattern")

			if Pattern then
				CollectionService:AddTag(Pattern, "AutoSellScroll")
			end

			local NameLabel = v4:FindFirstChild("NameLabel")

			if NameLabel then
				NameLabel.Text = v.displayName
				NameLabel.TextColor3 = rarityColor
				NameLabel:SetAttribute("RarityId", v.id)
				CollectionService:AddTag(NameLabel, "AnimatedRarity")
			end

			local ToggleBtn = v4:FindFirstChild("ToggleBtn")

			if ToggleBtn then
				local v13 = ToggleBtn:FindFirstChild("Content")
				local v14 = if v13 then v13:FindFirstChild("CheckMark") else v13
				local v15 = if v13 then v13:FindFirstChild("XMark") else v13

				t[v.id] = {
					Btn = ToggleBtn,
					Content = v13,
					CheckMark = v14,
					XMark = v15
				}

				local v16 = ClientPlayerData.serverProfile:getState()
				local v17 = v16.autoSellRarities and v16.autoSellRarities[v.id]

				if v14 then
					v14.Visible = v17 == true
				end

				if v15 then
					v15.Visible = not v17
				end

				if v13 then
					v13.BackgroundColor3 = if v17 then Color3.fromRGB(50, 200, 50) else Color3.new(255/255, 255/255, 255/255)
				end

				ToggleBtn.MouseButton1Click:Connect(function() --[[ Line: 259 | Upvalues: ClientPlayerData (ref), v (copy), Remotes (ref) ]]
					local v1 = ClientPlayerData.serverProfile:getState()

					Remotes.ToggleAutoSellRarity:Fire({
						rarityId = v.id,
						enabled = not (v1.autoSellRarities and v1.autoSellRarities[v.id])
					})
				end)
			end
		end

		local RaritiesSmallerList = ContentMain:WaitForChild("RaritiesSmallerList")
		local Template2 = RaritiesSmallerList:WaitForChild("Template")
		local None = RaritiesSmallerList:WaitForChild("None")

		local function clearSmallerClones() --[[ clearSmallerClones | Line: 273 | Upvalues: RaritiesSmallerList (copy), Template2 (copy), None (copy) ]]
			for i, v in ipairs(RaritiesSmallerList:GetChildren()) do
				if v ~= Template2 and (v ~= None and not (v:IsA("UIListLayout") or v:IsA("UIStroke"))) then
					v:Destroy()
				end
			end
		end

		local function updateRarities(p1) --[[ updateRarities | Line: 287 | Upvalues: t (copy), clearSmallerClones (copy), list (copy), Template2 (copy), RaritiesSmallerList (copy), darkenColor (ref), CollectionService (ref), None (copy) ]]
			local v2 = if p1 then p1 else {}

			for k, v in pairs(t) do
				if v2[k] then
					if v.CheckMark then
						v.CheckMark.Visible = true
					end

					if v.XMark then
						v.XMark.Visible = false
					end

					if v.Content then
						v.Content.BackgroundColor3 = Color3.fromRGB(50, 200, 50)
					end

					continue
				end

				if v.CheckMark then
					v.CheckMark.Visible = false
				end

				if v.XMark then
					v.XMark.Visible = true
				end

				if v.Content then
					v.Content.BackgroundColor3 = Color3.new(255/255, 255/255, 255/255)
				end
			end

			clearSmallerClones()

			local count = 0

			for i, v in ipairs(list) do
				if v2[v.id] then
					count = count + 1

					local v3 = Template2:Clone()

					v3.Name = v.id
					v3.LayoutOrder = count
					v3.Visible = true
					v3.Parent = RaritiesSmallerList

					local rarityColor = v.rarityColor

					v3.BackgroundColor3 = Color3.new(255/255, 255/255, 255/255)

					local UIGradient = Instance.new("UIGradient")
					local v5 = ColorSequence.new
					local v6, v7, v8 = (v.BackgroundColor or rarityColor):ToHSV()

					UIGradient.Color = v5(Color3.fromHSV(v6, v7, (math.clamp(v8 * 0.55, 0, 1))), darkenColor(v.raritySecondColor or rarityColor, 0.55))
					UIGradient.Rotation = 45
					UIGradient.Parent = v3

					local UIStroke = v3:FindFirstChild("UIStroke")

					if UIStroke then
						local v9, v10, v11 = rarityColor:ToHSV()

						UIStroke.Color = Color3.fromHSV(v9, v10, (math.clamp(v11 * 0.35, 0, 1)))
					end

					local NameLabel = v3:FindFirstChild("NameLabel")

					if NameLabel then
						NameLabel.Text = v.displayName
						NameLabel.TextColor3 = rarityColor
						NameLabel:SetAttribute("RarityId", v.id)
						CollectionService:AddTag(NameLabel, "AnimatedRarity")
					end
				end
			end

			None.Visible = count == 0
		end

		ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 355 ]]
			return p1.autoSellRarities
		end, updateRarities)
		updateRarities(ClientPlayerData.serverProfile:getState().autoSellRarities)

		local SetNumber = ContentMain:WaitForChild("SetNumber")
		local Max = ContentMain:WaitForChild("Max")
		local EnterNumber = ContentMain:WaitForChild("EnterNumber")
		local TextLabel = Max:FindFirstChild("TextLabel", true)

		if TextLabel then
			TextLabel.Text = "CLEAR"
		end

		local function submitMinEarnings() --[[ submitMinEarnings | Line: 373 | Upvalues: EnterNumber (copy), ConvertValue (ref), Remotes (ref), ClientPlayerData (ref) ]]
			local Text = EnterNumber.Text
			local v1 = ConvertValue.parseSuffix(Text)

			print("[AutoSellUI] submitMinEarnings called. rawText =", tostring(Text), "parsed =", (tostring(v1)))

			if v1 and v1 >= 0 then
				Remotes.SetAutoSellMinEarnings:Fire(v1)

				return
			end

			local v2 = ClientPlayerData.serverProfile:getState().autoSellMinEarnings or 0

			if v2 > 0 then
				EnterNumber.Text = tostring(ConvertValue.suffixformat(v2))
			else
				EnterNumber.Text = ""
			end
		end

		SetNumber.MouseButton1Click:Connect(function() --[[ Line: 390 | Upvalues: submitMinEarnings (copy) ]]
			print("[AutoSellUI] SetBtn MouseButton1Click triggered")
			submitMinEarnings()
		end)
		EnterNumber.FocusLost:Connect(function(p1) --[[ Line: 395 | Upvalues: submitMinEarnings (copy) ]]
			print("[AutoSellUI] TextBox FocusLost triggered. enterPressed =", (tostring(p1)))

			if not p1 then
				return
			end

			submitMinEarnings()
		end)
		Max.MouseButton1Click:Connect(function() --[[ Line: 402 | Upvalues: Remotes (ref), EnterNumber (copy) ]]
			print("[AutoSellUI] ClearBtn MouseButton1Click triggered")
			Remotes.SetAutoSellMinEarnings:Fire(0)
			EnterNumber.Text = ""
		end)

		local function updateMinEarnings(p1) --[[ updateMinEarnings | Line: 409 | Upvalues: EnterNumber (copy), ConvertValue (ref) ]]
			local v1 = p1 or 0

			print("[AutoSellUI] autoSellMinEarnings updated in state =", (tostring(v1)))

			if v1 > 0 then
				EnterNumber.Text = tostring(ConvertValue.suffixformat(v1))
			else
				EnterNumber.Text = ""
			end
		end

		ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 419 ]]
			return p1.autoSellMinEarnings
		end, updateMinEarnings)

		local v20 = ClientPlayerData.serverProfile:getState().autoSellMinEarnings or 0

		print("[AutoSellUI] autoSellMinEarnings updated in state =", (tostring(v20)))

		if v20 > 0 then
			EnterNumber.Text = tostring(ConvertValue.suffixformat(v20))
		else
			EnterNumber.Text = ""
		end

		task.spawn(function() --[[ Line: 427 | Upvalues: PlayerGui (copy), ReplicatedStorage (ref), ClientPlayerData (ref), p1 (copy), v3 (copy), v2 (copy) ]]
			local BackpackGui = PlayerGui:WaitForChild("BackpackGui", 30)

			if not BackpackGui then
				return
			end

			local Backpack = BackpackGui:WaitForChild("Backpack", 30)

			if not Backpack then
				return
			end

			local Inventory = Backpack:WaitForChild("Inventory", 30)

			if not Inventory then
				return
			end

			local AutoSellButton = Inventory:WaitForChild("AutoSellButton", 30)

			if not AutoSellButton then
				return
			end

			local function updateButtonAppearance(p1) --[[ updateButtonAppearance | Line: 437 | Upvalues: AutoSellButton (copy), ReplicatedStorage (ref) ]]
				local v1 = AutoSellButton:FindFirstChildWhichIsA("TextLabel", true)

				if not v1 then
					return
				end

				local Satchel = require(ReplicatedStorage.client.Satchel)

				if p1 then
					v1.Text = "Auto Sell"
					Satchel.ApplyButtonStyle(AutoSellButton, "Usable")

					return
				end

				v1.Text = "\240\159\148\146 Auto Sell"
				Satchel.ApplyButtonStyle(AutoSellButton, "Locked")
			end

			updateButtonAppearance(ClientPlayerData.serverProfile:getState().hasAutoSell)
			ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 454 ]]
				return p1.hasAutoSell
			end, updateButtonAppearance)
			AutoSellButton.MouseButton1Click:Connect(function() --[[ Line: 458 | Upvalues: ClientPlayerData (ref), p1 (ref), v3 (ref), ReplicatedStorage (ref), v2 (ref) ]]
				local v1 = ClientPlayerData.serverProfile:getState()
				local v22 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

				if v1.hasAutoSell then
					if v22.OpenedUIComponent:Get() == v2 then
						v22.OpenedUIComponent:Set(nil)

						return
					end

					v22.OpenedUIComponent:Set(v2)

					local Satchel = require(ReplicatedStorage.client.Satchel)

					if not Satchel.IsOpen then
						return
					end

					Satchel.OpenClose()
				else
					v22.OpenedUIComponent:Set(v3)

					local Satchel = require(ReplicatedStorage.client.Satchel)

					if not Satchel.IsOpen then
						return
					end

					Satchel.OpenClose()
				end
			end)
		end)
	end
}