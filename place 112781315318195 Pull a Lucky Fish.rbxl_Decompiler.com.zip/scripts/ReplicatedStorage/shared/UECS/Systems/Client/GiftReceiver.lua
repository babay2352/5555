-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ContextActionService = game:GetService("ContextActionService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ControlHint = require(ReplicatedStorage.client.ControlHint)
local CashDisplay = require(ReplicatedStorage.shared.module.CashDisplay)
local FishConfig = require(ReplicatedStorage.shared.config.FishConfig)
local FishEarnings = require(ReplicatedStorage.shared.util.FishEarnings)
local GiftAccept = require(ReplicatedStorage.shared.UECS.Components.GiftAccept)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local MutationList = require(ReplicatedStorage.shared.util.MutationList)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local v1 = Color3.new(255/255, 255/255, 255/255)

return {
	UECS = nil,
	Init = function(p1) --[[ Init | Line: 39 | Upvalues: Players (copy), GiftAccept (copy), Remotes (copy), ControlHint (copy), ContextActionService (copy), FishConfig (copy), v1 (copy), MutationList (copy), FishEarnings (copy), CashDisplay (copy) ]]
		local LocalPlayer = Players.LocalPlayer
		local GiftAccept2 = LocalPlayer.PlayerGui:WaitForChild("MainUI"):WaitForChild("GiftAccept")
		local v12 = GiftAccept2:WaitForChild("Content")
		local GiftText = v12:WaitForChild("GiftText")
		local FishTemplateNotAcquired = v12:WaitForChild("FishTemplateNotAcquired")
		local Accept = v12:WaitForChild("Accept")
		local Decline = v12:WaitForChild("Decline")
		local CloseButton = GiftAccept2:WaitForChild("TopBar"):WaitForChild("CloseButton")
		local Frame = FishTemplateNotAcquired:WaitForChild("Frame")
		local UIGradient = Frame:WaitForChild("UIGradient")
		local Icon = FishTemplateNotAcquired:WaitForChild("Icon")
		local DisplayName = FishTemplateNotAcquired:WaitForChild("DisplayName")
		local Earnings = FishTemplateNotAcquired:WaitForChild("Earnings")

		GiftAccept2.Visible = false

		local v2 = GiftAccept.Add(GiftAccept2)
		local v3 = nil

		local function closeViaOpener() --[[ closeViaOpener | Line: 67 | Upvalues: p1 (copy), v2 (copy) ]]
			local v1 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

			if v1.OpenedUIComponent:Get() ~= v2 then
				return
			end

			v1.OpenedUIComponent:Set(nil)
		end

		local function respond(p12) --[[ respond | Line: 78 | Upvalues: v3 (ref), Remotes (ref), p1 (copy), v2 (copy) ]]
			local v1 = v3

			if not v1 then
				return
			end

			Remotes.RespondGiftFish:Fire({
				GiftId = v1.GiftId,
				Accept = p12
			})
			v3 = nil

			local v22 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

			if v22.OpenedUIComponent:Get() ~= v2 then
				return
			end

			v22.OpenedUIComponent:Set(nil)
		end

		local v4 = ControlHint.new({
			label = "Accept",
			anchorTo = Accept,
			keyCode = Enum.KeyCode.ButtonA
		})
		local v5 = ControlHint.new({
			label = "Decline",
			anchorTo = Decline,
			keyCode = Enum.KeyCode.ButtonB
		})

		local function bindGamepad() --[[ bindGamepad | Line: 93 | Upvalues: ContextActionService (ref), v3 (ref), Remotes (ref), p1 (copy), v2 (copy), v4 (copy), v5 (copy) ]]
			ContextActionService:BindActionAtPriority("GiftAcceptConfirm", function(p12, p2) --[[ Line: 96 | Upvalues: v3 (ref), Remotes (ref), p1 (ref), v2 (ref) ]]
				if p2 ~= Enum.UserInputState.Begin then
					return Enum.ContextActionResult.Pass
				end

				local v1 = v3

				if not v1 then
					return Enum.ContextActionResult.Sink
				end

				Remotes.RespondGiftFish:Fire({
					Accept = true,
					GiftId = v1.GiftId
				})
				v3 = nil

				local v22 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

				if v22.OpenedUIComponent:Get() ~= v2 then
					return Enum.ContextActionResult.Sink
				end

				v22.OpenedUIComponent:Set(nil)

				return Enum.ContextActionResult.Sink
			end, false, 10000, Enum.KeyCode.ButtonA)
			ContextActionService:BindActionAtPriority("GiftAcceptDecline", function(p12, p2) --[[ Line: 109 | Upvalues: v3 (ref), Remotes (ref), p1 (ref), v2 (ref) ]]
				if p2 ~= Enum.UserInputState.Begin then
					return Enum.ContextActionResult.Pass
				end

				local v1 = v3

				if not v1 then
					return Enum.ContextActionResult.Sink
				end

				Remotes.RespondGiftFish:Fire({
					Accept = false,
					GiftId = v1.GiftId
				})
				v3 = nil

				local v22 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

				if v22.OpenedUIComponent:Get() ~= v2 then
					return Enum.ContextActionResult.Sink
				end

				v22.OpenedUIComponent:Set(nil)

				return Enum.ContextActionResult.Sink
			end, false, 10000, Enum.KeyCode.ButtonB)
			v4:Show()
			v5:Show()
		end

		local function unbindGamepad() --[[ unbindGamepad | Line: 124 | Upvalues: ContextActionService (ref), v4 (copy), v5 (copy) ]]
			ContextActionService:UnbindAction("GiftAcceptConfirm")
			ContextActionService:UnbindAction("GiftAcceptDecline")
			v4:Hide()
			v5:Hide()
		end

		Accept.MouseButton1Click:Connect(function() --[[ Line: 131 | Upvalues: v3 (ref), Remotes (ref), p1 (copy), v2 (copy) ]]
			local v1 = v3

			if not v1 then
				return
			end

			Remotes.RespondGiftFish:Fire({
				Accept = true,
				GiftId = v1.GiftId
			})
			v3 = nil

			local v22 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

			if v22.OpenedUIComponent:Get() ~= v2 then
				return
			end

			v22.OpenedUIComponent:Set(nil)
		end)
		Decline.MouseButton1Click:Connect(function() --[[ Line: 134 | Upvalues: v3 (ref), Remotes (ref), p1 (copy), v2 (copy) ]]
			local v1 = v3

			if not v1 then
				return
			end

			Remotes.RespondGiftFish:Fire({
				Accept = false,
				GiftId = v1.GiftId
			})
			v3 = nil

			local v22 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

			if v22.OpenedUIComponent:Get() ~= v2 then
				return
			end

			v22.OpenedUIComponent:Set(nil)
		end)
		CloseButton.MouseButton1Click:Connect(function() --[[ Line: 138 | Upvalues: v3 (ref), Remotes (ref), p1 (copy), v2 (copy) ]]
			local v1 = v3

			if not v1 then
				return
			end

			Remotes.RespondGiftFish:Fire({
				Accept = false,
				GiftId = v1.GiftId
			})
			v3 = nil

			local v22 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

			if v22.OpenedUIComponent:Get() ~= v2 then
				return
			end

			v22.OpenedUIComponent:Set(nil)
		end)
		v2.Visible.OnChange:Connect(function(p1) --[[ Line: 145 | Upvalues: GiftAccept2 (copy), bindGamepad (copy), ContextActionService (ref), v4 (copy), v5 (copy), v3 (ref), Remotes (ref) ]]
			GiftAccept2.Visible = p1

			if p1 then
				bindGamepad()
			else
				ContextActionService:UnbindAction("GiftAcceptConfirm")
				ContextActionService:UnbindAction("GiftAcceptDecline")
				v4:Hide()
				v5:Hide()
			end

			if p1 or not v3 then
				return
			end

			local v1 = v3

			v3 = nil
			Remotes.RespondGiftFish:Fire({
				Accept = false,
				GiftId = v1.GiftId
			})
		end)
		Remotes.OfferGiftFish:On(function(p12) --[[ Line: 162 | Upvalues: FishConfig (ref), v3 (ref), GiftText (copy), UIGradient (copy), Frame (copy), Icon (copy), v1 (ref), MutationList (ref), DisplayName (copy), FishEarnings (ref), LocalPlayer (copy), CashDisplay (ref), Earnings (copy), p1 (copy), v2 (copy) ]]
			if type(p12) ~= "table" then
				return
			end

			local v12 = FishConfig[p12.ConfigName]

			if type(p12.GiftId) ~= "string" or not v12 then
				return
			end

			local v22 = p12.Level or 1
			local v32 = if typeof(p12.Mutation) == "string" and p12.Mutation ~= "" then p12.Mutation else nil
			local t = {
				GiftId = p12.GiftId
			}

			t.FromName = tostring(p12.FromName)
			t.ConfigName = p12.ConfigName
			t.Level = v22
			t.Mutation = v32
			v3 = t
			GiftText.Text = ("%* wants to send you a gift"):format(p12.FromName)
			UIGradient.Color = ColorSequence.new(v12.Rarity.rarityColor, Color3.fromRGB(255, 255, 255))
			Frame.BackgroundColor3 = v12.Rarity.rarityColor
			Icon.Image = v12.Image
			Icon.ImageColor3 = v1

			local v4 = MutationList.displayLabel(MutationList.parse(v32))

			DisplayName.Text = ("%*%*"):format(if v4 == "" then "" else ("[%*] "):format(v4), v12.DisplayName)
			CashDisplay.applyToLabel(Earnings, FishEarnings.perFish(LocalPlayer, p12.ConfigName, false, v22, v32), {
				Suffix = "/s",
				Compact = true
			})
			p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(v2)
		end)
	end
}