-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local ActiveEffects = require(ReplicatedStorage.shared.effects.ActiveEffects)
local AlienEventConfig = require(ReplicatedStorage.shared.config.AlienEventConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local convertTimeMS = require(ReplicatedStorage.shared.util.convertTimeMS)
local t = {
	UECS = nil
}
local t2 = {}
local t3 = {}
local v1 = nil

local function isInvasionActive() --[[ isInvasionActive | Line: 47 | Upvalues: ActiveEffects (copy) ]]
	for v1, v2 in ActiveEffects.GetActive() do
		if v2.Name == "AlienWeather" then
			return true
		end
	end

	return false
end

local function currentText() --[[ currentText | Line: 57 | Upvalues: ActiveEffects (copy), v1 (ref), convertTimeMS (copy) ]]
	local v12 = false

	for v2, v3 in ActiveEffects.GetActive() do
		if v3.Name == "AlienWeather" then
			v12 = true

			break
		end
	end

	if v12 then
		return "Alien Invasion active!"
	end

	local v4 = v1 and v1:GetAttribute("AlienWeatherTime")

	if type(v4) == "number" then
		return "Alien Invasion in: " .. convertTimeMS(v4 - workspace:GetServerTimeNow(), false)
	end

	return ""
end

local function refresh() --[[ refresh | Line: 71 | Upvalues: ActiveEffects (copy), v1 (ref), convertTimeMS (copy), t2 (copy) ]]
	local v12 = false

	for v2, v3 in ActiveEffects.GetActive() do
		if v3.Name == "AlienWeather" then
			v12 = true

			break
		end
	end

	local v4

	if v12 then
		v4 = "Alien Invasion active!"
	else
		local v5 = v1 and v1:GetAttribute("AlienWeatherTime")

		v4 = if type(v5) == "number" then "Alien Invasion in: " .. convertTimeMS(v5 - workspace:GetServerTimeNow(), false) else ""
	end

	for v6 in t2 do
		if v6:IsDescendantOf(game) then
			v6.Text = v4

			continue
		end

		t2[v6] = nil
	end
end

local function ensureCounter(p1) --[[ ensureCounter | Line: 84 | Upvalues: t3 (copy), t2 (copy), refresh (copy) ]]
	if not t3[p1] then
		t3[p1] = true
		task.spawn(function() --[[ Line: 89 | Upvalues: p1 (copy), t2 (ref), refresh (ref), t3 (ref) ]]
			while p1:IsDescendantOf(game) do
				local TextUp = p1:FindFirstChild("TextUp", true)

				if TextUp and TextUp:IsA("TextLabel") then
					t2[TextUp] = true
					refresh()

					while p1:IsDescendantOf(game) and TextUp:IsDescendantOf(game) do
						task.wait(1)
					end

					t2[TextUp] = nil

					continue
				end

				task.wait(0.5)
			end

			t3[p1] = nil
		end)
	end
end

function t.Init(p1) --[[ Init | Line: 107 | Upvalues: AlienEventConfig (copy), CollectionService (copy), t3 (copy), t2 (copy), refresh (copy), ensureCounter (copy), ReplicatedStorage (copy), v1 (ref), ActiveEffects (copy), RunService (copy) ]]
	if not AlienEventConfig.Enabled then
		return
	end

	for v12, v2 in CollectionService:GetTagged("AlienWeatherCounter") do
		if not t3[v2] then
			t3[v2] = true
			task.spawn(function() --[[ Line: 89 | Upvalues: v2 (copy), t2 (ref), refresh (ref), t3 (ref) ]]
				while v2:IsDescendantOf(game) do
					local TextUp = v2:FindFirstChild("TextUp", true)

					if TextUp and TextUp:IsA("TextLabel") then
						t2[TextUp] = true
						refresh()

						while v2:IsDescendantOf(game) and TextUp:IsDescendantOf(game) do
							task.wait(1)
						end

						t2[TextUp] = nil

						continue
					end

					task.wait(0.5)
				end

				t3[v2] = nil
			end)
		end
	end

	CollectionService:GetInstanceAddedSignal("AlienWeatherCounter"):Connect(ensureCounter)
	task.spawn(function() --[[ Line: 123 | Upvalues: ReplicatedStorage (ref), v1 (ref), refresh (ref) ]]
		local WeatherSchedule = ReplicatedStorage:WaitForChild("WeatherSchedule", 30)

		if WeatherSchedule then
			v1 = WeatherSchedule
			WeatherSchedule:GetAttributeChangedSignal("AlienWeatherTime"):Connect(refresh)
			refresh()
		else
			warn("[AlienWeatherCounter] WeatherSchedule never replicated; the counter will stay blank")
		end
	end)
	ActiveEffects.Changed:Connect(refresh)
	task.spawn(function() --[[ Line: 137 | Upvalues: RunService (ref), t2 (ref), refresh (ref) ]]
		local v1 = 0

		RunService.Heartbeat:Connect(function(p1) --[[ Line: 139 | Upvalues: v1 (ref), t2 (ref), refresh (ref) ]]
			v1 = v1 + p1

			if v1 < 1 then
				return
			end

			v1 = 0

			if next(t2) ~= nil then
				debug.profilebegin("UECS/AlienWeatherCounter.Tick")
				refresh()
				debug.profileend()
			end
		end)
	end)
end

return t