-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Remotes = require(ReplicatedStorage.shared.Remotes)
local SFX = require(ReplicatedStorage.client.SFX)
local VFX = require(ReplicatedStorage.client.VFX)
local Back = Enum.EasingStyle.Back
local Out = Enum.EasingDirection.Out
local t = {
	UECS = nil
}

local function animateDrop(p1) --[[ animateDrop | Line: 28 | Upvalues: RunService (copy), TweenService (copy), Back (copy), Out (copy) ]]
	local v1 = p1:GetAttribute("IdleAnchor")

	if typeof(v1) == "CFrame" then
		local v2 = v1 * CFrame.new(0, 8, 0) * CFrame.Angles(0.2617993877991494, 1.0471975511965976, -0.4363323129985824)

		p1:SetAttribute("IdleAnchor", v2)

		local v3 = os.clock()
		local v4 = nil

		v4 = RunService.Heartbeat:Connect(function() --[[ Line: 45 | Upvalues: p1 (copy), v4 (ref), v3 (copy), TweenService (ref), Back (ref), Out (ref), v2 (copy), v1 (copy) ]]
			debug.profilebegin("UECS/PlaceFX.DropEase")

			if not p1.Parent then
				v4:Disconnect()
			else
				local v22 = math.min((os.clock() - v3) / 0.5, 1)

				p1:SetAttribute("IdleAnchor", v2:Lerp(v1, (TweenService:GetValue(v22, Back, Out))))

				if v22 >= 1 then
					v4:Disconnect()
					p1:SetAttribute("IdleAnchor", v1)
				end
			end

			debug.profileend()
		end)
	end
end

function t.Init(p1) --[[ Init | Line: 65 | Upvalues: Remotes (copy), VFX (copy), SFX (copy), animateDrop (copy) ]]
	Remotes.ShowPlaceFX:On(function(p1) --[[ Line: 66 | Upvalues: VFX (ref), SFX (ref), animateDrop (ref) ]]
		if typeof(p1) ~= "Instance" or not p1:IsA("Model") then
			return
		end

		if p1.PrimaryPart then
			VFX.new("Place", p1.PrimaryPart)
		end

		SFX.new(SFX.Sounds.Placement2, 0.5)
		animateDrop(p1)
	end)
end

return t