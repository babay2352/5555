-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
game:GetService("CollectionService")

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")

require(ReplicatedStorage.shared.UECS.GlobalTypes)
require(ReplicatedStorage.shared.UECS.Components.Potion)

local PotionConfig = require(ReplicatedStorage.shared.config.PotionConfig)
local rarityConfig = require(ReplicatedStorage.shared.config.rarityConfig)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local SFX = require(ReplicatedStorage.client.SFX)
local UECS = require(ReplicatedStorage.shared.UECS.UECS)

require(ReplicatedStorage.shared.module.notifications)

local LocalPlayer = Players.LocalPlayer
local t = {
	UECS = nil,
	Priority = 25
}
local v1 = 0

local function setupRarityLabel(p1, p2) --[[ setupRarityLabel | Line: 40 | Upvalues: ReplicatedStorage (copy), rarityConfig (copy) ]]
	local v1 = ReplicatedStorage.shared.model.RarityLabel:Clone()

	v1.Parent = p1
	p1.ChildAdded:Connect(function(p1) --[[ Line: 45 | Upvalues: v1 (copy) ]]
		if p1.Name ~= "Handle" or not p1:IsA("BasePart") then
			return
		end

		v1.Adornee = p1
	end)

	local Handle = p1:FindFirstChild("Handle")

	if Handle and Handle:IsA("BasePart") then
		v1.Adornee = Handle
	end

	local id = p2.Rarity.id

	v1.Frame.DisplayName.Text = p2.DisplayName
	v1.Frame.Rarity.Text = rarityConfig[id].displayName

	local UIGradient = v1.Frame.Rarity:FindFirstChild("UIGradient")

	if UIGradient and UIGradient:IsA("UIGradient") then
		UIGradient.Color = ColorSequence.new(rarityConfig[id].rarityColor)
	end

	v1.Frame.Rarity:SetAttribute("RarityId", id)
	v1.Frame.Counter.Text = p2.EffectDescription

	local MutationList = v1.Frame:FindFirstChild("MutationList")

	if MutationList then
		MutationList.Visible = false
	end

	v1.Enabled = true
end

local function buildPotionHandle(p1, p2) --[[ buildPotionHandle | Line: 83 | Upvalues: ReplicatedStorage (copy) ]]
	local PotionModels = ReplicatedStorage.shared.model:FindFirstChild("PotionModels")
	local v1 = if PotionModels then PotionModels:FindFirstChild(p2) else PotionModels

	if not v1 then
		return false
	end

	if v1:IsA("BasePart") then
		local Handle = v1:Clone()

		Handle.Name = "Handle"
		Handle.Parent = p1
		p1.RequiresHandle = true

		return true
	end

	if not v1:IsA("Model") then
		return false
	end

	local v2 = v1:Clone()

	if not v2.PrimaryPart then
		v2:Destroy()

		return false
	end

	local Handle = v2.PrimaryPart

	Handle.Name = "Handle"

	for v3, v4 in v2:GetDescendants() do
		if v4:IsA("BasePart") and v4 ~= Handle then
			v4.Anchored = false
			v4.CanCollide = false
			v4.Massless = true

			local WeldConstraint = Instance.new("WeldConstraint")

			WeldConstraint.Part0 = Handle
			WeldConstraint.Part1 = v4
			WeldConstraint.Parent = v4
		end
	end

	Handle.Anchored = false
	Handle.CanCollide = false
	Handle.Massless = true
	Handle.Parent = p1

	for v5, v6 in v2:GetChildren() do
		v6.Parent = Handle
	end

	v2:Destroy()
	p1.RequiresHandle = true

	return true
end

local function playDrinkVFX(p1, p2) --[[ playDrinkVFX | Line: 133 | Upvalues: ReplicatedStorage (copy), TweenService (copy) ]]
	local HumanoidRootPart = p1:FindFirstChild("HumanoidRootPart")

	if not HumanoidRootPart then
		return
	end

	local PotionModels = ReplicatedStorage.shared.model:FindFirstChild("PotionModels")
	local v1 = if PotionModels then PotionModels:FindFirstChild(p2) else PotionModels

	if not v1 then
		return
	end

	local v2 = p1:FindFirstChild("RightUpperArm") or p1:FindFirstChild("Right Arm")
	local v3 = if v2 and v2:IsA("BasePart") then v2.CFrame * CFrame.new(0, 1.5, 0) else HumanoidRootPart.CFrame * CFrame.new(1.5, 2.5, 0)
	local v4 = v1:Clone()
	local ThrownPotion = nil

	if v4:IsA("BasePart") then
		ThrownPotion = v4
	elseif v4:IsA("Model") then
		local v5 = v4.PrimaryPart or v4:FindFirstChildWhichIsA("BasePart")

		if not v5 then
			v4:Destroy()
		else
			ThrownPotion = v5

			for v6, v7 in v4:GetDescendants() do
				if v7:IsA("BasePart") and v7 ~= v5 then
					v7.Anchored = false
					v7.CanCollide = false
					v7.Massless = true

					local WeldConstraint = Instance.new("WeldConstraint")

					WeldConstraint.Part0 = v5
					WeldConstraint.Part1 = v7
					WeldConstraint.Parent = v7
				end
			end

			v5.Parent = workspace

			for v8, v9 in v4:GetChildren() do
				if v9 ~= v5 then
					v9.Parent = v5
				end
			end

			v4:Destroy()
			v4 = nil
		end
	end

	ThrownPotion.Name = "ThrownPotion"
	ThrownPotion.CFrame = v3
	ThrownPotion.Anchored = false
	ThrownPotion.CanCollide = true
	ThrownPotion.Massless = false

	if v4 then
		ThrownPotion.Parent = workspace
	end

	local Attachment = Instance.new("Attachment")

	Attachment.Parent = ThrownPotion

	local VectorForce = Instance.new("VectorForce")

	VectorForce.Attachment0 = Attachment
	VectorForce.RelativeTo = Enum.ActuatorRelativeTo.World
	VectorForce.Force = (-HumanoidRootPart.CFrame.LookVector * 0.4 + Vector3.new(0, 1, 0)).Unit * 55
	VectorForce.ApplyAtCenterOfMass = true
	VectorForce.Parent = ThrownPotion
	ThrownPotion.AssemblyAngularVelocity = Vector3.new(math.random() * 8 - 4, math.random() * 6 - 3, math.random() * 8 - 4)
	task.delay(0.15, function() --[[ Line: 224 | Upvalues: VectorForce (copy) ]]
		if not (VectorForce and VectorForce.Parent) then
			return
		end

		VectorForce:Destroy()
	end)
	task.spawn(function() --[[ Line: 231 | Upvalues: ThrownPotion (ref), TweenService (ref) ]]
		task.wait(1.2)

		local t = { ThrownPotion }

		for v1, v2 in ThrownPotion:GetDescendants() do
			if v2:IsA("BasePart") then
				table.insert(t, v2)
			end
		end

		for v3, v4 in t do
			TweenService:Create(v4, TweenInfo.new(2, Enum.EasingStyle.Linear), {
				Transparency = 1
			}):Play()
		end

		task.wait(2)
		ThrownPotion:Destroy()
	end)
end

function t.Init(p1) --[[ Init | Line: 259 | Upvalues: UECS (copy), PotionConfig (copy), buildPotionHandle (copy), setupRarityLabel (copy), LocalPlayer (copy), Remotes (copy), Players (copy), v1 (ref), SFX (copy), ReplicatedStorage (copy), playDrinkVFX (copy) ]]
	UECS.OnComponentCreated("Potion"):Connect(function(p1) --[[ Line: 264 | Upvalues: PotionConfig (ref), buildPotionHandle (ref), setupRarityLabel (ref), LocalPlayer (ref), Remotes (ref), Players (ref) ]]
		local Entity = p1.Entity

		if not Entity:IsA("Tool") then
			return
		end

		local v1 = p1.ConfigName:Get()

		if type(v1) ~= "string" or v1 == "" then
			local v2 = nil

			v2 = p1.ConfigName.OnChange:Connect(function(p1) --[[ Line: 274 | Upvalues: v2 (ref), PotionConfig (ref), Entity (copy), buildPotionHandle (ref), setupRarityLabel (ref) ]]
				if v2 then
					v2:Disconnect()
					v2 = nil
				end

				if type(p1) ~= "string" or p1 == "" then
					return
				end

				local v1 = PotionConfig.Potions[p1]

				if v1 then
					Entity.Name = v1.DisplayName
					Entity.TextureId = v1.Icon
					Entity.CanBeDropped = false
					Entity.RequiresHandle = false
					buildPotionHandle(Entity, p1)
					setupRarityLabel(Entity, v1)
				end
			end)

			return
		end

		local v3 = PotionConfig.Potions[v1]

		if v3 then
			Entity.Name = v3.DisplayName
			Entity.TextureId = v3.Icon
			Entity.CanBeDropped = false
			Entity.RequiresHandle = false
			buildPotionHandle(Entity, v1)
			setupRarityLabel(Entity, v3)

			local t = {}
			local t2 = {}

			local function clearGiftPrompts() --[[ clearGiftPrompts | Line: 318 | Upvalues: t2 (copy), t (copy) ]]
				for v1, v2 in t2 do
					v2:Disconnect()
				end

				table.clear(t2)

				for v3, v4 in t do
					v4:Destroy()
					t[v3] = nil
				end
			end

			local function createGiftPromptFor(p1) --[[ createGiftPromptFor | Line: 329 | Upvalues: LocalPlayer (ref), t (copy), Remotes (ref) ]]
				if p1 == LocalPlayer or t[p1] then
					return
				end

				local Character = p1.Character

				if not Character then
					return
				end

				local v1 = Character:FindFirstChild("HumanoidRootPart") or Character.PrimaryPart

				if v1 then
					local GiftPotionPrompt = Instance.new("ProximityPrompt")

					GiftPotionPrompt.Name = "GiftPotionPrompt"
					GiftPotionPrompt.Style = Enum.ProximityPromptStyle.Custom
					GiftPotionPrompt.ActionText = "Gift"
					GiftPotionPrompt.ObjectText = p1.DisplayName
					GiftPotionPrompt.HoldDuration = 0.2
					GiftPotionPrompt.RequiresLineOfSight = false
					GiftPotionPrompt.MaxActivationDistance = 12
					GiftPotionPrompt.Parent = v1
					GiftPotionPrompt.Triggered:Connect(function() --[[ Line: 350 | Upvalues: Remotes (ref), p1 (copy) ]]
						Remotes.RequestGiftPotion:Fire(p1)
					end)
					t[p1] = GiftPotionPrompt
				end
			end

			local function watchRespawns(p1) --[[ watchRespawns | Line: 356 | Upvalues: t2 (copy), t (copy), createGiftPromptFor (copy) ]]
				local function f2(p13) --[[ Line: 359 | Upvalues: t (ref), p1 (copy), createGiftPromptFor (ref) ]]
					t[p1] = nil
					task.spawn(function() --[[ Line: 361 | Upvalues: p13 (copy), createGiftPromptFor (ref), p1 (ref) ]]
						p13:WaitForChild("HumanoidRootPart", 10)
						createGiftPromptFor(p1)
					end)
				end

				table.insert(t2, p1.CharacterAdded:Connect(f2))
			end

			local function startGifting() --[[ startGifting | Line: 369 | Upvalues: Players (ref), createGiftPromptFor (copy), t2 (copy), t (copy) ]]
				for v1, v2 in Players:GetPlayers() do
					createGiftPromptFor(v2)

					local function f4(p13) --[[ Line: 359 | Upvalues: t (ref), v2 (copy), createGiftPromptFor (ref) ]]
						t[v2] = nil
						task.spawn(function() --[[ Line: 361 | Upvalues: p13 (copy), createGiftPromptFor (ref), v2 (ref) ]]
							p13:WaitForChild("HumanoidRootPart", 10)
							createGiftPromptFor(p1)
						end)
					end

					table.insert(t2, v2.CharacterAdded:Connect(f4))
				end

				local v5 = t2

				local function f6(p1) --[[ Line: 376 | Upvalues: createGiftPromptFor (ref), t2 (ref), t (ref) ]]
					createGiftPromptFor(p1)

					local function f2(p13) --[[ Line: 359 | Upvalues: t (ref), p1 (copy), createGiftPromptFor (ref) ]]
						t[p1] = nil
						task.spawn(function() --[[ Line: 361 | Upvalues: p13 (copy), createGiftPromptFor (ref), p1 (ref) ]]
							p13:WaitForChild("HumanoidRootPart", 10)
							createGiftPromptFor(p1)
						end)
					end

					table.insert(t2, p1.CharacterAdded:Connect(f2))
				end

				table.insert(v5, Players.PlayerAdded:Connect(f6))

				local v7 = t2

				local function f8(p1) --[[ Line: 383 | Upvalues: t (ref) ]]
					local v1 = t[p1]

					if not v1 then
						return
					end

					v1:Destroy()
					t[p1] = nil
				end

				table.insert(v7, Players.PlayerRemoving:Connect(f8))
			end

			Entity.Equipped:Connect(function() --[[ Line: 393 | Upvalues: p1 (copy), LocalPlayer (ref), startGifting (copy) ]]
				if p1.Owner:Get() ~= LocalPlayer then
					return
				end

				startGifting()
			end)
			Entity.Unequipped:Connect(clearGiftPrompts)
			Entity.Destroying:Connect(clearGiftPrompts)
		end
	end)

	local function onToolActivated(p12) --[[ onToolActivated | Line: 406 | Upvalues: v1 (ref), p1 (copy), LocalPlayer (ref), Remotes (ref) ]]
		if p12.Name == "FloatLootbox" or p12:GetAttribute("IsFloatLootbox") then
			return
		end

		print("[PotionHandler] Tool activated:", p12.Name)

		local v12 = os.clock()

		if v12 - v1 < 2 then
			print("[PotionHandler] On cooldown")

			return
		end

		local v2 = p1.UECS:GetComponent(p12, "Potion")

		if v2 then
			if v2.Owner:Get() == LocalPlayer then
				v1 = v12
				print("[PotionHandler] Firing RequestUsePotion")
				Remotes.RequestUsePotion:Fire()
			else
				print("[PotionHandler] Not our potion")
			end
		else
			local t = {}

			for v3, v4 in p12:GetAttributes() do
				table.insert(t, v3 .. "=" .. tostring(v4))
			end

			local t2 = {}

			for v6, v7 in p12:GetChildren() do
				table.insert(t2, v7.Name .. "(" .. v7.ClassName .. ")")
			end

			print("[PotionHandler] No Potion component on tool. Attrs:", table.concat(t, ", "), "Children:", table.concat(t2, ", "))
		end
	end

	local function setupCharacter(p1) --[[ setupCharacter | Line: 448 | Upvalues: onToolActivated (copy) ]]
		p1.ChildAdded:Connect(function(p1) --[[ Line: 449 | Upvalues: onToolActivated (ref) ]]
			if not p1:IsA("Tool") then
				return
			end

			p1.Activated:Connect(function() --[[ Line: 451 | Upvalues: onToolActivated (ref), p1 (copy) ]]
				onToolActivated(p1)
			end)
		end)

		for v1, v2 in p1:GetChildren() do
			if v2:IsA("Tool") then
				v2.Activated:Connect(function() --[[ Line: 459 | Upvalues: onToolActivated (ref), v2 (copy) ]]
					onToolActivated(v2)
				end)
			end
		end
	end

	if LocalPlayer.Character then
		setupCharacter(LocalPlayer.Character)
	end

	LocalPlayer.CharacterAdded:Connect(setupCharacter)
	Remotes.PotionDrunk:On(function(p1) --[[ Line: 472 | Upvalues: PotionConfig (ref), LocalPlayer (ref), SFX (ref), ReplicatedStorage (ref), playDrinkVFX (ref) ]]
		if type(p1) ~= "table" then
			return
		end

		local ConfigName = p1.ConfigName

		if not PotionConfig.Potions[ConfigName] then
			return
		end

		local Character = LocalPlayer.Character

		if not Character then
			return
		end

		SFX.PlaySoundWithRandomPitch(SFX.Sounds.Pop, 0.8, 0.9, 1.1)

		local Humanoid = Character:FindFirstChildOfClass("Humanoid")

		if Humanoid then
			local Animator = Humanoid:FindFirstChildOfClass("Animator")

			if Animator then
				local PotionAnimations = ReplicatedStorage:FindFirstChild("PotionAnimations")
				local v1 = if PotionAnimations then PotionAnimations:FindFirstChild("Drink") else PotionAnimations

				if v1 and v1:IsA("Animation") then
					local v2 = Animator:LoadAnimation(v1)

					v2:Play()
					v2.Stopped:Wait()
				end
			end
		end

		playDrinkVFX(Character, ConfigName)
	end)
	Remotes.PotionDowngradeWarning:On(function(p1) --[[ Line: 511 | Upvalues: PotionConfig (ref), LocalPlayer (ref), Remotes (ref) ]]
		if type(p1) ~= "table" then
			return
		end

		local v1 = PotionConfig.Potions[p1.CurrentConfigName]
		local v2 = PotionConfig.Potions[p1.NewConfigName]

		if not (v1 and v2) then
			return
		end

		local MainUI = LocalPlayer:WaitForChild("PlayerGui"):FindFirstChild("MainUI")

		if MainUI then
			local PotionDowngradePopup = Instance.new("Frame")

			PotionDowngradePopup.Name = "PotionDowngradePopup"
			PotionDowngradePopup.Size = UDim2.fromOffset(400, 200)
			PotionDowngradePopup.Position = UDim2.new(0.5, -200, 0.5, -100)
			PotionDowngradePopup.BackgroundColor3 = Color3.fromRGB(30, 30, 40)
			PotionDowngradePopup.BorderSizePixel = 0
			PotionDowngradePopup.ZIndex = 100
			PotionDowngradePopup.Parent = MainUI

			local UICorner = Instance.new("UICorner")

			UICorner.CornerRadius = UDim.new(0, 12)
			UICorner.Parent = PotionDowngradePopup

			local TextLabel = Instance.new("TextLabel")

			TextLabel.Size = UDim2.new(1, -20, 0, 30)
			TextLabel.Position = UDim2.fromOffset(10, 10)
			TextLabel.BackgroundTransparency = 1
			TextLabel.Text = "\226\154\160\239\184\143 Downgrade Warning"
			TextLabel.TextColor3 = Color3.fromRGB(255, 200, 50)
			TextLabel.TextScaled = true
			TextLabel.Font = Enum.Font.GothamBold
			TextLabel.ZIndex = 101
			TextLabel.Parent = PotionDowngradePopup

			local TextLabel2 = Instance.new("TextLabel")

			TextLabel2.Size = UDim2.new(1, -20, 0, 60)
			TextLabel2.Position = UDim2.fromOffset(10, 45)
			TextLabel2.BackgroundTransparency = 1
			TextLabel2.Text = ("You currently have %* active.\nUsing %* will DOWNGRADE your effect!"):format(v1.DisplayName, v2.DisplayName)
			TextLabel2.TextColor3 = Color3.new(255/255, 255/255, 255/255)
			TextLabel2.TextScaled = true
			TextLabel2.TextWrapped = true
			TextLabel2.Font = Enum.Font.Gotham
			TextLabel2.ZIndex = 101
			TextLabel2.Parent = PotionDowngradePopup

			local TextButton = Instance.new("TextButton")

			TextButton.Size = UDim2.fromOffset(150, 40)
			TextButton.Position = UDim2.new(0.25, -75, 1, -55)
			TextButton.BackgroundColor3 = Color3.fromRGB(255, 80, 80)
			TextButton.Text = "Downgrade"
			TextButton.TextColor3 = Color3.new(255/255, 255/255, 255/255)
			TextButton.TextScaled = true
			TextButton.Font = Enum.Font.GothamBold
			TextButton.ZIndex = 101
			TextButton.Parent = PotionDowngradePopup

			local UICorner2 = Instance.new("UICorner")

			UICorner2.CornerRadius = UDim.new(0, 8)
			UICorner2.Parent = TextButton

			local TextButton2 = Instance.new("TextButton")

			TextButton2.Size = UDim2.fromOffset(150, 40)
			TextButton2.Position = UDim2.new(0.75, -75, 1, -55)
			TextButton2.BackgroundColor3 = Color3.fromRGB(80, 80, 80)
			TextButton2.Text = "Cancel"
			TextButton2.TextColor3 = Color3.new(255/255, 255/255, 255/255)
			TextButton2.TextScaled = true
			TextButton2.Font = Enum.Font.GothamBold
			TextButton2.ZIndex = 101
			TextButton2.Parent = PotionDowngradePopup

			local UICorner3 = Instance.new("UICorner")

			UICorner3.CornerRadius = UDim.new(0, 8)
			UICorner3.Parent = TextButton2

			local function cleanup() --[[ cleanup | Line: 594 | Upvalues: PotionDowngradePopup (copy) ]]
				PotionDowngradePopup:Destroy()
			end

			TextButton.MouseButton1Down:Connect(function() --[[ Line: 598 | Upvalues: Remotes (ref), p1 (copy), PotionDowngradePopup (copy) ]]
				Remotes.ConfirmPotionDowngrade:Fire({
					Confirmed = true,
					ConfigName = p1.NewConfigName
				})
				PotionDowngradePopup:Destroy()
			end)
			TextButton2.MouseButton1Down:Connect(function() --[[ Line: 606 | Upvalues: Remotes (ref), p1 (copy), PotionDowngradePopup (copy) ]]
				Remotes.ConfirmPotionDowngrade:Fire({
					Confirmed = false,
					ConfigName = p1.NewConfigName
				})
				PotionDowngradePopup:Destroy()
			end)
			task.delay(15, function() --[[ Line: 615 | Upvalues: PotionDowngradePopup (copy), Remotes (ref), p1 (copy) ]]
				if not PotionDowngradePopup.Parent then
					return
				end

				Remotes.ConfirmPotionDowngrade:Fire({
					Confirmed = false,
					ConfigName = p1.NewConfigName
				})
				PotionDowngradePopup:Destroy()
			end)
		end
	end)
end

return t