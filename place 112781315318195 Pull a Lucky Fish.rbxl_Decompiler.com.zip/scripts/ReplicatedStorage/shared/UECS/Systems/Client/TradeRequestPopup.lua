-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ContextActionService = game:GetService("ContextActionService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local RBXThumbModule = require(ReplicatedStorage.shared.module.RBXThumbModule)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local TradeRequestPopup = require(ReplicatedStorage.shared.UECS.Components.TradeRequestPopup)
local bindToButtonPress = require(ReplicatedStorage.shared.util.bindToButtonPress)
local t = {
	UECS = nil,
	Priority = 30
}
local v1 = ""

function t.Init(p1) --[[ Init | Line: 28 | Upvalues: Players (copy), TradeRequestPopup (copy), v1 (ref), Remotes (copy), bindToButtonPress (copy), ContextActionService (copy), RBXThumbModule (copy) ]]
	local TradeRequestPopup2 = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI").TradeRequestPopup
	local v12 = TradeRequestPopup.Add(TradeRequestPopup2)
	local v2 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

	v12.Visible.OnChange:Connect(function(p1, p2) --[[ Line: 35 | Upvalues: TradeRequestPopup2 (copy), v1 (ref), Remotes (ref), bindToButtonPress (ref), v2 (copy), ContextActionService (ref) ]]
		TradeRequestPopup2.Visible = p1

		if not p1 and v1 ~= "" then
			Remotes.OnTradeInviteResponse:Client():Fire(v1, false)
			v1 = ""
		end

		if p1 == p2 then
			return
		end

		if p1 then
			bindToButtonPress("TradeAcceptAction", Enum.KeyCode.ButtonX, function() --[[ Line: 45 | Upvalues: v1 (ref), Remotes (ref), v2 (ref) ]]
				if v1 ~= "" then
					Remotes.OnTradeInviteResponse:Client():Fire(v1, true)
					v1 = ""
				end

				v2.OpenedUIComponent:Set(nil)
			end)
			bindToButtonPress("TradeDeclineAction", Enum.KeyCode.ButtonB, function() --[[ Line: 54 | Upvalues: v1 (ref), Remotes (ref), v2 (ref) ]]
				if v1 ~= "" then
					Remotes.OnTradeInviteResponse:Client():Fire(v1, false)
					v1 = ""
				end

				v2.OpenedUIComponent:Set(nil)
			end)

			return
		end

		ContextActionService:UnbindAction("TradeAcceptAction")
		ContextActionService:UnbindAction("TradeDeclineAction")
	end)
	Remotes.OnTradeInviteRecieve:Client():On(function(p1, p2) --[[ Line: 69 | Upvalues: v1 (ref), TradeRequestPopup2 (copy), RBXThumbModule (ref), v2 (copy), v12 (copy) ]]
		if p1 and (p1:IsA("Player") and v1 == "") then
			TradeRequestPopup2.Content.PlayerName.Text = p1.DisplayName
			TradeRequestPopup2.Content.PlayerIcon.Image = RBXThumbModule:GetAvatarHeadshotUri(p1.UserId)
			v1 = p2
			v2.OpenedUIComponent:Set(v12)
		end
	end)
	TradeRequestPopup2.Content.Decline.Activated:Connect(function() --[[ Line: 80 | Upvalues: v1 (ref), Remotes (ref), v2 (copy) ]]
		if v1 ~= "" then
			Remotes.OnTradeInviteResponse:Client():Fire(v1, false)
			v1 = ""
		end

		v2.OpenedUIComponent:Set(nil)
	end)
	TradeRequestPopup2.Content.Approve.Activated:Connect(function() --[[ Line: 89 | Upvalues: v1 (ref), Remotes (ref), v2 (copy) ]]
		if v1 ~= "" then
			Remotes.OnTradeInviteResponse:Client():Fire(v1, true)
			v1 = ""
		end

		v2.OpenedUIComponent:Set(nil)
	end)
end

return t