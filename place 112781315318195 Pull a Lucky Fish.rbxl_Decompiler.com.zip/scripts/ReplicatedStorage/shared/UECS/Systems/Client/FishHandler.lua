-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

game:GetService("RunService")

local AlienResearch = require(ReplicatedStorage.shared.util.AlienResearch)
local BuildModeState = require(ReplicatedStorage.client.BuildModeState)
local CashDisplay = require(ReplicatedStorage.shared.module.CashDisplay)
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local DecorationConfig = require(ReplicatedStorage.shared.config.DecorationConfig)
local FishConfig = require(ReplicatedStorage.shared.config.FishConfig)
local FishEarnings = require(ReplicatedStorage.shared.util.FishEarnings)
local GardenConfig = require(ReplicatedStorage.shared.config.GardenConfig)
local GiftConfirm = require(script.Parent.GiftConfirm)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local MutationConfig = require(ReplicatedStorage.shared.config.MutationConfig)
local MutationList = require(ReplicatedStorage.shared.util.MutationList)

require(ReplicatedStorage.shared.UECS.Components.PlaceableFish)

local rarityConfig = require(ReplicatedStorage.shared.config.rarityConfig)

require(ReplicatedStorage.shared.UECS.Components.RarityLabel)

local Remotes = require(ReplicatedStorage.shared.Remotes)

require(ReplicatedStorage.shared.UECS.Components.TycoonStand)

local UECS = require(ReplicatedStorage.shared.UECS.UECS)
local notifications = require(ReplicatedStorage.shared.module.notifications)

require(ReplicatedStorage.shared.util.CatEarsUtil)

local t = {
	UECS = nil
}

local function renderMutationIcons(p1, p2) --[[ renderMutationIcons | Line: 35 | Upvalues: MutationList (copy), MutationConfig (copy) ]]
	local Frame = p1:FindFirstChild("Frame")

	if not Frame then
		return
	end

	local MutationList2 = Frame:FindFirstChild("MutationList")

	if not MutationList2 then
		return
	end

	local Template = MutationList2:FindFirstChild("Template")

	if not Template then
		return
	end

	for v1, v2 in MutationList2:GetChildren() do
		if v2 ~= Template and not v2:IsA("UIBase") then
			v2:Destroy()
		end
	end

	Template.Visible = false

	local v3 = MutationList.parse(p2)

	MutationList2.Visible = if #v3 > 0 then true else false

	for v5, v6 in v3 do
		local v7 = MutationConfig.Mutations[v6]

		if v7 then
			local v8 = Template:Clone()

			v8.Name = v6
			v8.Image = v7.image
			v8.Visible = true
			v8.Parent = MutationList2
		end
	end
end

local function setRarityGradient(p1, p2) --[[ setRarityGradient | Line: 74 ]]
	local UIGradient = p1:FindFirstChild("UIGradient")

	if not (UIGradient and UIGradient:IsA("UIGradient")) then
		return
	end

	UIGradient.Color = ColorSequence.new(p2)
end

function t.Init(p1) --[[ Init | Line: 81 | Upvalues: UECS (copy), ReplicatedStorage (copy), CashDisplay (copy), rarityConfig (copy), CollectionService (copy), renderMutationIcons (copy), Players (copy), FishConfig (copy), FishEarnings (copy), AlienResearch (copy), ClientPlayerData (copy), Remotes (copy), BuildModeState (copy), GardenConfig (copy), DecorationConfig (copy), notifications (copy), GiftConfirm (copy) ]]
	UECS.OnComponentCreated("RarityLabel"):Connect(function(p1) --[[ Line: 82 | Upvalues: ReplicatedStorage (ref), CashDisplay (ref), rarityConfig (ref), CollectionService (ref), renderMutationIcons (ref) ]]
		local v1 = ReplicatedStorage.shared.model.RarityLabel:Clone()

		v1.Parent = p1.Entity
		v1.Adornee = p1.Entity

		local function refreshCounter() --[[ refreshCounter | Line: 90 | Upvalues: p1 (copy), CashDisplay (ref), v1 (copy) ]]
			local v12 = p1.Earnings:Get()
			local v2 = p1.EarningsPercent:Get() or 0

			CashDisplay.applyToLabel(v1.Frame.Counter, v12, {
				Compact = true,
				Suffix = ("/s%*"):format(if v2 > 0 then (" (%*%%)"):format((math.floor(v2 * 100 + 0.5))) else "")
			})
		end

		refreshCounter()
		v1.Frame.Rarity.Text = rarityConfig[p1.Rarity:Get()].displayName

		local rarityColor = rarityConfig[p1.Rarity:Get()].rarityColor
		local UIGradient = v1.Frame.Rarity:FindFirstChild("UIGradient")

		if UIGradient and UIGradient:IsA("UIGradient") then
			UIGradient.Color = ColorSequence.new(rarityColor)
		end

		v1.Frame.Rarity:SetAttribute("RarityId", p1.Rarity:Get())
		CollectionService:AddTag(v1.Frame.Rarity, "AnimatedRarity")
		v1.Frame.DisplayName.Text = ("%*"):format((p1.DisplayName:Get()))
		renderMutationIcons(v1, p1.Mutations:Get())
		p1.Earnings.OnChange:Connect(refreshCounter)
		p1.EarningsPercent.OnChange:Connect(refreshCounter)
		p1.Rarity.OnChange:Connect(function(p1) --[[ Line: 107 | Upvalues: v1 (copy), rarityConfig (ref) ]]
			v1.Frame.Rarity.Text = rarityConfig[p1].displayName

			local UIGradient = v1.Frame.Rarity:FindFirstChild("UIGradient")

			if not (UIGradient and UIGradient:IsA("UIGradient")) then
				v1.Frame.Rarity:SetAttribute("RarityId", p1)

				return
			end

			UIGradient.Color = ColorSequence.new(rarityConfig[p1].rarityColor)
			v1.Frame.Rarity:SetAttribute("RarityId", p1)
		end)
		p1.DisplayName.OnChange:Connect(function(p1) --[[ Line: 112 | Upvalues: v1 (copy) ]]
			v1.Frame.DisplayName.Text = p1
		end)
		p1.Mutations.OnChange:Connect(function(p1) --[[ Line: 115 | Upvalues: renderMutationIcons (ref), v1 (copy) ]]
			renderMutationIcons(v1, p1)
		end)

		if p1.Entity:GetAttribute("IsLuckyblock") == true then
			local Counter = v1.Frame:FindFirstChild("Counter")

			if Counter then
				Counter.Visible = false
			end

			local Rarity2 = v1.Frame:FindFirstChild("Rarity")

			if Rarity2 then
				Rarity2.Visible = false
			end
		end

		if p1.Entity:GetAttribute("IsDisplayFish") == true then
			local Counter = v1.Frame:FindFirstChild("Counter")

			if Counter then
				Counter.Visible = false
			end
		end

		v1.Enabled = true

		local function applyLabelEffect() --[[ applyLabelEffect | Line: 147 | Upvalues: p1 (copy), CollectionService (ref), v1 (copy) ]]
			if not p1.Entity or p1.Entity:GetAttribute("LabelEffect") ~= "Duality" then
				return
			end

			CollectionService:AddTag(v1, "DualityBillboard")
		end

		if p1.Entity and p1.Entity:GetAttribute("LabelEffect") == "Duality" then
			CollectionService:AddTag(v1, "DualityBillboard")
		end

		if not p1.Entity then
			return
		end

		p1.Entity:GetAttributeChangedSignal("LabelEffect"):Connect(applyLabelEffect)
	end)
	UECS.OnComponentCreated("PlaceableFish"):Connect(function(p12) --[[ Line: 158 | Upvalues: ReplicatedStorage (ref), Players (ref), CollectionService (ref), FishConfig (ref), FishEarnings (ref), AlienResearch (ref), CashDisplay (ref), rarityConfig (ref), renderMutationIcons (ref), ClientPlayerData (ref), Remotes (ref), BuildModeState (ref), GardenConfig (ref), DecorationConfig (ref), notifications (ref), p1 (copy), GiftConfirm (ref) ]]
		local Entity = p12.Entity
		local v1 = ReplicatedStorage.shared.model.RarityLabel:Clone()

		v1.Parent = Entity

		local Handle = Entity:FindFirstChild("Handle")

		if Handle and Handle:IsA("BasePart") then
			v1.Adornee = Handle
		end

		Entity.ChildAdded:Connect(function(p1) --[[ Line: 169 | Upvalues: v1 (copy) ]]
			if p1.Name ~= "Handle" or not p1:IsA("BasePart") then
				return
			end

			v1.Adornee = p1
		end)

		local LocalPlayer = Players.LocalPlayer
		local FishConfigName = p12.FishConfigName
		local Level = p12.Level
		local Mutation = p12.Mutation
		local ScanState = p12.ScanState

		local function syncAnimatedRarityTag() --[[ syncAnimatedRarityTag | Line: 184 | Upvalues: v1 (copy), LocalPlayer (copy), Entity (copy), CollectionService (ref) ]]
			local Rarity = v1.Frame:FindFirstChild("Rarity")

			if not (Rarity and Rarity:IsA("TextLabel")) then
				return
			end

			local Backpack = LocalPlayer:FindFirstChildOfClass("Backpack")
			local v12 = Entity.Parent

			if Backpack and v12 == Backpack then
				if CollectionService:HasTag(Rarity, "AnimatedRarity") then
					CollectionService:RemoveTag(Rarity, "AnimatedRarity")
				end
			else
				if v12 ~= LocalPlayer.Character or CollectionService:HasTag(Rarity, "AnimatedRarity") then
					return
				end

				CollectionService:AddTag(Rarity, "AnimatedRarity")
			end
		end

		local v2 = false

		local function syncScrambleTag() --[[ syncScrambleTag | Line: 206 | Upvalues: v2 (ref), Entity (copy), LocalPlayer (copy), CollectionService (ref), v1 (copy) ]]
			local v12 = v2 and Entity.Parent == LocalPlayer.Character

			if v12 == CollectionService:HasTag(v1, "ScrambleBillboard") then
				return
			end

			if v12 then
				CollectionService:AddTag(v1, "ScrambleBillboard")
			else
				CollectionService:RemoveTag(v1, "ScrambleBillboard")
			end
		end

		local function refreshRarityLabel() --[[ refreshRarityLabel | Line: 218 | Upvalues: FishConfigName (copy), FishConfig (ref), Level (copy), Mutation (copy), FishEarnings (ref), LocalPlayer (copy), AlienResearch (ref), ScanState (copy), CashDisplay (ref), v1 (copy), rarityConfig (ref), syncAnimatedRarityTag (copy), CollectionService (ref), v2 (ref), Entity (copy), renderMutationIcons (ref) ]]
			local v12 = FishConfigName:Get()

			if type(v12) ~= "string" then
				return
			end

			local v22 = FishConfig[v12]

			if not v22 then
				return
			end

			local v3 = Level:Get() or 1
			local v4 = Mutation:Get()
			local v5 = if typeof(v4) == "string" and v4 ~= "" then v4 else nil
			local v6 = FishEarnings.perFish(LocalPlayer, v12, false, v3, v5)
			local v7 = v22.EarningsPercent or 0
			local v8 = if v7 > 0 then (" (%*%%)"):format((math.floor(v7 * 100 + 0.5))) else ""
			local id = v22.Rarity.id
			local v9 = AlienResearch.needsScan(AlienResearch.fromProperty(ScanState:Get()))

			if v9 then
				CashDisplay.setPlainText(v1.Frame.Counter, "???/s")
			else
				CashDisplay.applyToLabel(v1.Frame.Counter, v6, {
					Compact = true,
					Suffix = ("/s%*"):format(v8)
				})
			end

			v1.Frame.Rarity.Text = rarityConfig[id].displayName

			local rarityColor = rarityConfig[id].rarityColor
			local UIGradient = v1.Frame.Rarity:FindFirstChild("UIGradient")

			if UIGradient and UIGradient:IsA("UIGradient") then
				UIGradient.Color = ColorSequence.new(rarityColor)
			end

			v1.Frame.Rarity:SetAttribute("RarityId", id)
			syncAnimatedRarityTag()

			local v10 = if v22.LabelEffect == "Duality" then true else false

			if not v10 and CollectionService:HasTag(v1, "DualityBillboard") then
				CollectionService:RemoveTag(v1, "DualityBillboard")
			end

			v2 = false

			local v11 = v2 and Entity.Parent == LocalPlayer.Character

			if v11 ~= CollectionService:HasTag(v1, "ScrambleBillboard") then
				if v11 then
					CollectionService:AddTag(v1, "ScrambleBillboard")
				else
					CollectionService:RemoveTag(v1, "ScrambleBillboard")
				end
			end

			v1.Frame.DisplayName.Text = v22.DisplayName
			v1:SetAttribute("ScrambleText", v22.DisplayName)
			v2 = v9

			local v122 = v9 and Entity.Parent == LocalPlayer.Character

			if v122 ~= CollectionService:HasTag(v1, "ScrambleBillboard") then
				if v122 then
					CollectionService:AddTag(v1, "ScrambleBillboard")
				else
					CollectionService:RemoveTag(v1, "ScrambleBillboard")
				end
			end

			if v10 and not CollectionService:HasTag(v1, "DualityBillboard") then
				CollectionService:AddTag(v1, "DualityBillboard")
			end

			renderMutationIcons(v1, v5)
		end

		refreshRarityLabel()
		FishConfigName.OnChange:Connect(refreshRarityLabel)
		Level.OnChange:Connect(refreshRarityLabel)
		Mutation.OnChange:Connect(refreshRarityLabel)
		ScanState.OnChange:Connect(refreshRarityLabel)

		local t = {
			LocalPlayer:GetAttributeChangedSignal("CashMultiplier"):Connect(refreshRarityLabel),
			LocalPlayer:GetAttributeChangedSignal("FriendMultiplier"):Connect(refreshRarityLabel),
			Entity:GetPropertyChangedSignal("Parent"):Connect(syncAnimatedRarityTag),
			Entity:GetPropertyChangedSignal("Parent"):Connect(syncScrambleTag)
		}
		local v3 = ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 293 ]]
			return p1.rebirthLevel
		end, refreshRarityLabel)
		local v4 = ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 300 ]]
			return p1.inventory
		end, refreshRarityLabel)

		Entity.Destroying:Connect(function() --[[ Line: 303 | Upvalues: t (copy), v3 (copy), v4 (copy) ]]
			for v1, v2 in t do
				v2:Disconnect()
			end

			v3()
			v4()
		end)
		v1.Enabled = true

		local t2 = {}
		local t3 = {}

		local function CreatePlacePrompt(p1, p2) --[[ CreatePlacePrompt | Line: 315 | Upvalues: t2 (copy), t3 (copy), Remotes (ref), p12 (copy) ]]
			local ProximityPrompt = Instance.new("ProximityPrompt")

			ProximityPrompt.Style = Enum.ProximityPromptStyle.Custom
			ProximityPrompt.RequiresLineOfSight = false
			ProximityPrompt.Parent = p1
			table.insert(t2, ProximityPrompt)

			local function refreshText() --[[ refreshText | Line: 326 | Upvalues: p2 (copy), ProximityPrompt (copy), p1 (copy) ]]
				local v1 = type(p2.FishStanding:Get()) == "string"

				ProximityPrompt.ActionText = if v1 then "Replace" else "Place"

				local FishPrompt = p1:FindFirstChild("FishPrompt")

				if not FishPrompt then
					return
				end

				FishPrompt.Enabled = not v1
			end

			local v2 = type(p2.FishStanding:Get()) == "string"

			ProximityPrompt.ActionText = if v2 then "Replace" else "Place"

			local FishPrompt = p1:FindFirstChild("FishPrompt")
			local v5

			if FishPrompt then
				FishPrompt.Enabled = not v2
			end

			v5 = p2.FishStanding.OnChange
			table.insert(t3, v5:Connect(refreshText))
			ProximityPrompt.Triggered:Connect(function() --[[ Line: 339 | Upvalues: Remotes (ref), p12 (ref), p2 (copy) ]]
				Remotes.RequestPlaceFish:Fire({
					ConfigName = p12.FishConfigName:Get(),
					BaseSlotIndexName = p2.BaseSlotIndexName:Get()
				})
			end)
		end

		local function CreateStatuePrompts() --[[ CreateStatuePrompts | Line: 350 | Upvalues: BuildModeState (ref), GardenConfig (ref), DecorationConfig (ref), t2 (copy), Remotes (ref), notifications (ref) ]]
			local GardenRoot = BuildModeState.GardenRoot
			local v1 = if GardenRoot then GardenRoot:FindFirstChild(GardenConfig.PlacedFolderName) else GardenRoot

			if not v1 then
				return
			end

			for v2, v3 in v1:GetChildren() do
				local v4 = v3:GetAttribute("ConfigName")
				local v5 = if typeof(v4) == "string" then DecorationConfig[v4] else nil

				if v5 and (v5.Functional == "FishDisplay" and v3:GetAttribute(GardenConfig.FishKeyAttribute) == GardenConfig.EmptyFishKey) then
					local v6 = v3:GetAttribute("PlacementId")
					local v7 = v3:FindFirstChild(GardenConfig.FishDisplayAttachmentName, true)

					if typeof(v6) == "string" and (v7 and v7:IsA("Attachment")) then
						local ProximityPrompt = Instance.new("ProximityPrompt")

						ProximityPrompt.Style = Enum.ProximityPromptStyle.Custom
						ProximityPrompt.ActionText = "Display"
						ProximityPrompt.HoldDuration = GardenConfig.PromptHoldDuration
						ProximityPrompt.MaxActivationDistance = GardenConfig.PromptDistance
						ProximityPrompt.RequiresLineOfSight = false
						ProximityPrompt.Parent = v7
						table.insert(t2, ProximityPrompt)
						ProximityPrompt.Triggered:Connect(function() --[[ Line: 380 | Upvalues: Remotes (ref), v6 (copy), notifications (ref) ]]
							local v1, v2 = Remotes.RequestDisplayGardenFish:Call(v6):Await()

							if v1 and (typeof(v2) == "table" and v2.ok) then
								return
							end

							notifications:Send((if typeof(v2) == "table" then v2.reason else nil) or "Could not display that fish.")
						end)
					end
				end
			end
		end

		Entity.Equipped:Connect(function() --[[ Line: 390 | Upvalues: p1 (ref), Players (ref), CreatePlacePrompt (copy), CreateStatuePrompts (copy) ]]
			for v1, v2 in p1.UECS:GetComponents("TycoonStand") do
				if v2.Owner:Get() == Players.LocalPlayer then
					local root = v2.Entity:FindFirstChild("root")

					if root then
						CreatePlacePrompt(root, v2)
					end
				end
			end

			CreateStatuePrompts()
		end)
		Entity.Unequipped:Connect(function() --[[ Line: 403 | Upvalues: t2 (copy), t3 (copy) ]]
			for v1, v2 in t2 do
				local v3 = v2.Parent

				if v3 then
					local FishPrompt = v3:FindFirstChild("FishPrompt")

					if FishPrompt then
						FishPrompt.Enabled = true
					end
				end

				v2:Destroy()
			end

			table.clear(t2)

			for v4, v5 in t3 do
				v5:Disconnect()
			end

			table.clear(t3)
		end)

		local t4 = {}
		local t5 = {}

		local function clearGiftPrompts() --[[ clearGiftPrompts | Line: 430 | Upvalues: t5 (copy), t4 (copy) ]]
			for v1, v2 in t5 do
				v2:Disconnect()
			end

			table.clear(t5)

			for v3, v4 in t4 do
				v4:Destroy()
				t4[v3] = nil
			end
		end

		local function createGiftPromptFor(p1) --[[ createGiftPromptFor | Line: 441 | Upvalues: Players (ref), t4 (copy), GiftConfirm (ref), FishConfigName (copy), Level (copy), Mutation (copy), Remotes (ref) ]]
			if p1 == Players.LocalPlayer or t4[p1] then
				return
			end

			local Character = p1.Character

			if not Character then
				return
			end

			local v1 = Character:FindFirstChild("HumanoidRootPart") or Character.PrimaryPart

			if v1 then
				local GiftPrompt = Instance.new("ProximityPrompt")

				GiftPrompt.Name = "GiftPrompt"
				GiftPrompt.Style = Enum.ProximityPromptStyle.Custom
				GiftPrompt.ActionText = "Gift"
				GiftPrompt.ObjectText = p1.DisplayName
				GiftPrompt.HoldDuration = 0.2
				GiftPrompt.RequiresLineOfSight = false
				GiftPrompt.MaxActivationDistance = 12
				GiftPrompt.Parent = v1
				GiftPrompt.Triggered:Connect(function() --[[ Line: 462 | Upvalues: GiftConfirm (ref), p1 (copy), FishConfigName (ref), Level (ref), Mutation (ref), Remotes (ref) ]]
					if GiftConfirm.Show(p1, {
						ConfigName = FishConfigName:Get(),
						Level = Level:Get(),
						Mutation = Mutation:Get()
					}) then
						return
					end

					Remotes.RequestGiftFish:Fire(p1)
				end)
				t4[p1] = GiftPrompt
			end
		end

		local function watchRespawns(p1) --[[ watchRespawns | Line: 479 | Upvalues: t5 (copy), t4 (copy), createGiftPromptFor (copy) ]]
			local function f2(p13) --[[ Line: 482 | Upvalues: t4 (ref), p1 (copy), createGiftPromptFor (ref) ]]
				t4[p1] = nil
				task.spawn(function() --[[ Line: 484 | Upvalues: p13 (copy), createGiftPromptFor (ref), p1 (ref) ]]
					p13:WaitForChild("HumanoidRootPart", 10)
					createGiftPromptFor(p1)
				end)
			end

			table.insert(t5, p1.CharacterAdded:Connect(f2))
		end

		local function startGifting() --[[ startGifting | Line: 492 | Upvalues: Players (ref), createGiftPromptFor (copy), t5 (copy), t4 (copy) ]]
			for v1, v2 in Players:GetPlayers() do
				createGiftPromptFor(v2)

				local function f4(p13) --[[ Line: 482 | Upvalues: t4 (ref), v2 (copy), createGiftPromptFor (ref) ]]
					t4[v2] = nil
					task.spawn(function() --[[ Line: 484 | Upvalues: p13 (copy), createGiftPromptFor (ref), v2 (ref) ]]
						p13:WaitForChild("HumanoidRootPart", 10)
						createGiftPromptFor(p1)
					end)
				end

				table.insert(t5, v2.CharacterAdded:Connect(f4))
			end

			local v5 = t5

			local function f6(p1) --[[ Line: 499 | Upvalues: createGiftPromptFor (ref), t5 (ref), t4 (ref) ]]
				createGiftPromptFor(p1)

				local function f2(p13) --[[ Line: 482 | Upvalues: t4 (ref), p1 (copy), createGiftPromptFor (ref) ]]
					t4[p1] = nil
					task.spawn(function() --[[ Line: 484 | Upvalues: p13 (copy), createGiftPromptFor (ref), p1 (ref) ]]
						p13:WaitForChild("HumanoidRootPart", 10)
						createGiftPromptFor(p1)
					end)
				end

				table.insert(t5, p1.CharacterAdded:Connect(f2))
			end

			table.insert(v5, Players.PlayerAdded:Connect(f6))

			local v7 = t5

			local function f8(p1) --[[ Line: 506 | Upvalues: t4 (ref) ]]
				local v1 = t4[p1]

				if not v1 then
					return
				end

				v1:Destroy()
				t4[p1] = nil
			end

			table.insert(v7, Players.PlayerRemoving:Connect(f8))
		end

		Entity.Equipped:Connect(function() --[[ Line: 516 | Upvalues: p12 (copy), Players (ref), startGifting (copy) ]]
			if p12.Owner:Get() ~= Players.LocalPlayer then
				return
			end

			startGifting()
		end)
		Entity.Unequipped:Connect(clearGiftPrompts)
		Entity.Destroying:Connect(clearGiftPrompts)
	end)
end

return t