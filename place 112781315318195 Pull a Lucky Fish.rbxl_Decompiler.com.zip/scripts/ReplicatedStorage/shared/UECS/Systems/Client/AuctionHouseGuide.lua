-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local AuctionHouseConfig = require(ReplicatedStorage.shared.config.AuctionHouseConfig)
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local TutorialPointer = require(ReplicatedStorage.client.TutorialPointer)
local t = {
	UECS = nil
}
local Guide = AuctionHouseConfig.Guide
local v1 = Guide.ArrivalDistance * Guide.ArrivalDistance

function t.Init(p1) --[[ Init | Line: 50 | Upvalues: Players (copy), TutorialPointer (copy), Guide (copy), ClientPlayerData (copy), v1 (copy), RunService (copy) ]]
	local LocalPlayer = Players.LocalPlayer
	local v12 = false

	local function clearArrow() --[[ clearArrow | Line: 56 | Upvalues: v12 (ref), TutorialPointer (ref) ]]
		if not v12 then
			return
		end

		TutorialPointer.guide(nil)
		v12 = false
	end

	local v2 = nil

	local function resolveTarget() --[[ resolveTarget | Line: 69 | Upvalues: v2 (ref), Guide (ref) ]]
		if v2 and v2.Parent then
			return v2
		end

		local AuctionHouseGuideAnchor = Instance.new("Part")

		AuctionHouseGuideAnchor.Name = "AuctionHouseGuideAnchor"
		AuctionHouseGuideAnchor.Anchored = true
		AuctionHouseGuideAnchor.CanCollide = false
		AuctionHouseGuideAnchor.CanQuery = false
		AuctionHouseGuideAnchor.CanTouch = false
		AuctionHouseGuideAnchor.Transparency = 1
		AuctionHouseGuideAnchor.Size = Vector3.new(1, 1, 1)
		AuctionHouseGuideAnchor.CFrame = CFrame.new(Guide.Position)
		AuctionHouseGuideAnchor.Parent = workspace
		v2 = AuctionHouseGuideAnchor

		return AuctionHouseGuideAnchor
	end

	local function shouldShow() --[[ shouldShow | Line: 87 | Upvalues: ClientPlayerData (ref) ]]
		local v1 = ClientPlayerData.serverProfile and ClientPlayerData.serverProfile:getState()

		if not v1 then
			return false
		end

		return if v1.unlockedFishingVillage == true then not v1.seenAuctionHouse else false
	end

	local function update() --[[ update | Line: 97 | Upvalues: ClientPlayerData (ref), v12 (ref), TutorialPointer (ref), LocalPlayer (copy), v2 (ref), Guide (ref), v1 (ref) ]]
		local v13 = ClientPlayerData.serverProfile and ClientPlayerData.serverProfile:getState()

		if if v13 and v13.unlockedFishingVillage == true then not v13.seenAuctionHouse else false then
			local Character = LocalPlayer.Character
			local v3 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character

			if v3 then
				local v4

				if v2 and v2.Parent then
					v4 = v2
				else
					local AuctionHouseGuideAnchor = Instance.new("Part")

					AuctionHouseGuideAnchor.Name = "AuctionHouseGuideAnchor"
					AuctionHouseGuideAnchor.Anchored = true
					AuctionHouseGuideAnchor.CanCollide = false
					AuctionHouseGuideAnchor.CanQuery = false
					AuctionHouseGuideAnchor.CanTouch = false
					AuctionHouseGuideAnchor.Transparency = 1
					AuctionHouseGuideAnchor.Size = Vector3.new(1, 1, 1)
					AuctionHouseGuideAnchor.CFrame = CFrame.new(Guide.Position)
					AuctionHouseGuideAnchor.Parent = workspace
					v2 = AuctionHouseGuideAnchor
					v4 = AuctionHouseGuideAnchor
				end

				local v5 = Guide.Position - v3.Position

				if not (v5:Dot(v5) <= v1) then
					TutorialPointer.guide(v4, false, (Vector3.new(0, Guide.PointerHeight, 0)))
					v12 = true

					return
				end
			end
		end

		if not v12 then
			return
		end

		TutorialPointer.guide(nil)
		v12 = false
	end

	LocalPlayer.CharacterRemoving:Connect(clearArrow)

	local v3 = 0

	RunService.Heartbeat:Connect(function(p1) --[[ Line: 127 | Upvalues: v3 (ref), update (copy) ]]
		debug.profilebegin("UECS/AuctionHouseGuide.Update")
		v3 = v3 + p1

		if not (v3 < 0.5) then
			v3 = 0
			update()
		end

		debug.profileend()
	end)
end

return t