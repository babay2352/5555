-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Debris = game:GetService("Debris")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local SoundService = game:GetService("SoundService")
local TweenService = game:GetService("TweenService")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Remotes = require(ReplicatedStorage.shared.Remotes)
local VFX = require(ReplicatedStorage.client.VFX)
local v1 = NumberRange.new(4, 7)
local v2 = UDim2.fromScale(2, 2)
local v3 = NumberRange.new(5, 7)
local v4 = NumberRange.new(-2, 0)
local v5 = NumberRange.new(1, 2)
local v6 = Color3.fromRGB(255, 220, 100)
local v7 = NumberRange.new(4, 10)
local v8 = NumberRange.new(0.3, 1)
local v9 = Color3.fromRGB(255, 140, 0)

local function randomInRange(p1) --[[ randomInRange | Line: 55 ]]
	return p1.Min + math.random() * (p1.Max - p1.Min)
end

local function playSound(p1) --[[ playSound | Line: 61 | Upvalues: SoundService (copy) ]]
	local SFX = SoundService:FindFirstChild("SFX")
	local v1 = if SFX then SFX:FindFirstChild(p1) else SFX

	if v1 and v1:IsA("Sound") then
		local v2 = v1:Clone()

		v2.PlaybackSpeed = v2.PlaybackSpeed * (1.05 + math.random() * 0.1)
		v2.PlayOnRemove = true
		v2.Parent = SoundService
		v2:Destroy()
	end
end

local function spawnFlyingImage(p1) --[[ spawnFlyingImage | Line: 75 | Upvalues: v2 (copy), v6 (copy), v3 (copy), v4 (copy), v5 (copy), RunService (copy), TweenService (copy) ]]
	local Attachment = Instance.new("Attachment")

	Attachment.Parent = p1

	local Attachment2 = Instance.new("Attachment")

	Attachment2.Position = Vector3.new(0, 0.5, 0)
	Attachment2.Parent = p1

	local BillboardGui = Instance.new("BillboardGui")

	BillboardGui.Size = v2
	BillboardGui.Adornee = Attachment
	BillboardGui.LightInfluence = 0
	BillboardGui.Parent = Attachment

	local ImageLabel = Instance.new("ImageLabel")

	ImageLabel.BackgroundTransparency = 1
	ImageLabel.Size = UDim2.fromScale(1, 1)
	ImageLabel.Image = "rbxassetid://93898068805552"
	ImageLabel.Parent = BillboardGui

	local Trail = Instance.new("Trail")

	Trail.Attachment0 = Attachment
	Trail.Attachment1 = Attachment2
	Trail.Lifetime = 0.2
	Trail.MinLength = 0
	Trail.Color = ColorSequence.new(v6)
	Trail.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.2), NumberSequenceKeypoint.new(1, 1) })
	Trail.LightEmission = 0.5
	Trail.Parent = p1

	local v1 = math.random() * 2 * math.pi
	local v22 = v3
	local v32 = v22.Min + math.random() * (v22.Max - v22.Min)
	local v52 = v4
	local v8 = Vector3.new(math.cos(v1) * v32, v52.Min + math.random() * (v52.Max - v52.Min), math.sin(v1) * v32)
	local v9 = v5
	local v14 = Vector3.new(v8.X * 0.5, v8.Y * 0.5 + (v9.Min + math.random() * (v9.Max - v9.Min)) * 2, v8.Z * 0.5)

	task.spawn(function() --[[ Line: 120 | Upvalues: Attachment (copy), RunService (ref), v14 (copy), v8 (copy), Attachment2 (copy), TweenService (ref), ImageLabel (copy), Trail (copy) ]]
		local v1 = Instance.new("NumberValue")

		v1.Parent = Attachment

		local v2 = nil

		v2 = RunService.Heartbeat:Connect(function() --[[ Line: 124 | Upvalues: Attachment (ref), v2 (ref), v1 (copy), v14 (ref), v8 (ref), Attachment2 (ref) ]]
			debug.profilebegin("UECS/CollectFX.FlyArc")

			if Attachment.Parent then
				local v12 = v1.Value
				local v22 = 1 - v12
				local v3 = v22 * v22 * Vector3.new(0, 0, 0) + 2 * v22 * v12 * v14 + v12 * v12 * v8

				Attachment.Position = v3
				Attachment2.Position = v3 + Vector3.new(0, 0.5, 0)
			else
				v2:Disconnect()
			end

			debug.profileend()
		end)
		TweenService:Create(v1, TweenInfo.new(0.25, Enum.EasingStyle.Linear), {
			Value = 1
		}):Play()
		task.wait(0.5)
		v2:Disconnect()

		if Attachment.Parent then
			local v3 = TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.In)

			TweenService:Create(Attachment, v3, {
				Position = Vector3.new(0, 0, 0)
			}):Play()
			TweenService:Create(Attachment2, v3, {
				Position = Vector3.new(0, 0.5, 0)
			}):Play()
			TweenService:Create(ImageLabel, TweenInfo.new(0.25), {
				ImageTransparency = 1
			}):Play()
			task.wait(0.25)
			Trail.Enabled = false
			task.wait(0.2)
			Attachment:Destroy()
			Attachment2:Destroy()
			Trail:Destroy()
		end
	end)
end

local function spawnFloatingImage(p1, p2) --[[ spawnFloatingImage | Line: 159 | Upvalues: v2 (copy), TweenService (copy), Debris (copy) ]]
	local v1 = math.random() * 2 * math.pi
	local v3 = math.sqrt((math.random()))
	local v7 = Vector3.new(math.cos(v1) * v3 * 7, (math.random() * 2 - 1) * 3, math.sin(v1) * v3 * 1)
	local Attachment = Instance.new("Attachment")

	Attachment.Position = v7
	Attachment.Parent = p1

	local BillboardGui = Instance.new("BillboardGui")

	BillboardGui.Size = UDim2.fromScale(v2.X.Scale * p2, v2.Y.Scale * p2)
	BillboardGui.Adornee = Attachment
	BillboardGui.LightInfluence = 0
	BillboardGui.Parent = Attachment

	local ImageLabel = Instance.new("ImageLabel")

	ImageLabel.BackgroundTransparency = 1
	ImageLabel.Size = UDim2.fromScale(1, 1)
	ImageLabel.Image = "rbxassetid://125914890223429"

	local v8 = (math.random() * 2 - 1) * 45

	ImageLabel.Rotation = v8
	ImageLabel.Parent = BillboardGui

	local v9 = TweenInfo.new(1.8, Enum.EasingStyle.Linear)

	TweenService:Create(Attachment, v9, {
		Position = v7 + Vector3.new(0, 6, 0)
	}):Play()
	TweenService:Create(ImageLabel, v9, {
		Rotation = v8 + (math.random() * 2 - 1) * 50
	}):Play()
	task.delay(1.2, function() --[[ Line: 194 | Upvalues: TweenService (ref), ImageLabel (copy) ]]
		TweenService:Create(ImageLabel, TweenInfo.new(0.6000000000000001, Enum.EasingStyle.Linear), {
			ImageTransparency = 1
		}):Play()
	end)
	Debris:AddItem(Attachment, 2.3)
end

local t = {}

local function blinkPart(p1) --[[ blinkPart | Line: 208 | Upvalues: t (copy), v9 (copy) ]]
	if not t[p1] then
		t[p1] = p1.Color
	end

	p1.Color = v9
	task.delay(0.25, function() --[[ Line: 213 | Upvalues: p1 (copy), t (ref) ]]
		p1.Color = t[p1]
	end)
end

local function createFollowHost(p1) --[[ createFollowHost | Line: 220 ]]
	local Part = Instance.new("Part")

	Part.Anchored = true
	Part.CanCollide = false
	Part.CanQuery = false
	Part.CanTouch = false
	Part.Transparency = 1
	Part.Size = Vector3.new(0.1, 0.1, 0.1)
	Part.CFrame = CFrame.new(p1.Position)
	Part.Parent = workspace

	return Part
end

return {
	UECS = nil,
	Init = function(p1) --[[ Init | Line: 240 | Upvalues: Remotes (copy), Debris (copy), VFX (copy), playSound (copy), v1 (copy), spawnFlyingImage (copy), v7 (copy), spawnFloatingImage (copy), v8 (copy), t (copy), v9 (copy) ]]
		Remotes.ShowCollectFX:On(function(p1) --[[ Line: 241 | Upvalues: Debris (ref), VFX (ref), playSound (ref), v1 (ref), spawnFlyingImage (ref), v7 (ref), spawnFloatingImage (ref), v8 (ref), t (ref), v9 (ref) ]]
			if typeof(p1) ~= "Instance" or not p1:IsA("BasePart") then
				return
			end

			local Part = Instance.new("Part")

			Part.Anchored = true
			Part.CanCollide = false
			Part.CanQuery = false
			Part.CanTouch = false
			Part.Transparency = 1
			Part.Size = Vector3.new(0.1, 0.1, 0.1)
			Part.CFrame = CFrame.new((p1.CFrame + Vector3.new(0, 3, 0)).Position)
			Part.Parent = workspace

			local v2 = Part

			Debris:AddItem(v2, 5)
			VFX.new("CashPickup_fx", v2)
			playSound("CashPickup")

			for i = 1, math.random(v1.Min, v1.Max) do
				spawnFlyingImage(v2)
			end

			task.delay(0.2, function() --[[ Line: 255 | Upvalues: v2 (copy), v7 (ref), spawnFloatingImage (ref), v8 (ref) ]]
				if not v2.Parent then
					return
				end

				for i = 1, math.random(v7.Min, v7.Max) do
					task.delay(math.random() * 0.5, function() --[[ Line: 260 | Upvalues: v2 (ref), spawnFloatingImage (ref), v8 (ref) ]]
						if not v2.Parent then
							return
						end

						local v1 = v8

						spawnFloatingImage(v2, v1.Min + math.random() * (v1.Max - v1.Min))
					end)
				end
			end)

			if not t[p1] then
				t[p1] = p1.Color
			end

			p1.Color = v9
			task.delay(0.25, function() --[[ Line: 213 | Upvalues: p1 (copy), t (ref) ]]
				p1.Color = t[p1]
			end)
			task.delay(0.5, function() --[[ Line: 270 | Upvalues: playSound (ref) ]]
				playSound("CashCollect")
			end)
			task.delay(0.75, function() --[[ Line: 273 | Upvalues: playSound (ref) ]]
				playSound("CashPickupEnd")
			end)
		end)
	end
}