-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

require(ReplicatedStorage.shared.UECS.GlobalTypes)
require(ReplicatedStorage.shared.Remotes)

local UIFrameOpener = require(ReplicatedStorage.shared.UECS.Components.UIFrameOpener)
local UIVFX = require(ReplicatedStorage.shared.module.UIVFX)
local Base = ReplicatedStorage.shared.model.Tycoon.Base

return {
	UECS = nil,
	Priority = 10,
	Init = function(p1) --[[ Init | Line: 14 | Upvalues: Players (copy), UIFrameOpener (copy), UIVFX (copy) ]]
		local MainUI = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI")

		UIFrameOpener.Add(MainUI).OpenedUIComponent.OnChange:Connect(function(p1, p2) --[[ Line: 18 | Upvalues: UIVFX (ref) ]]
			if p2 then
				UIVFX.FrameOpenClose.Close(p2)
			end

			if not p1 then
				return
			end

			UIVFX.FrameOpenClose.Open(p1)
		end)
	end
}