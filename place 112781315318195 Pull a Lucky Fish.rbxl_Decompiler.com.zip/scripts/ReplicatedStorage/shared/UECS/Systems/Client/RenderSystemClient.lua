-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Remotes = require(ReplicatedStorage.shared.Remotes)
local t = {
	UECS = nil,
	Priority = 30
}
local v1 = 0

function t.Init(p1) --[[ Init | Line: 14 | Upvalues: Players (copy), RunService (copy), v1 (ref), Remotes (copy) ]]
	local RenderParts = workspace:WaitForChild("RenderParts")
	local v12 = "RenderPart_" .. Players.LocalPlayer.UserId

	RunService:BindToRenderStep("snapRenderPartToCamera", Enum.RenderPriority.Camera.Value + 1, function() --[[ Line: 17 | Upvalues: RenderParts (copy), v12 (copy), v1 (ref), Remotes (ref) ]]
		local v13 = RenderParts:FindFirstChild(v12)

		if not v13 and os.time() - v1 > 1 then
			Remotes.RequestRenderPart:Fire()
			v1 = os.time()

			return
		end

		if not v13 then
			return
		end

		local AlignPosition = v13:FindFirstChildOfClass("AlignPosition")

		if not AlignPosition then
			return
		end

		AlignPosition.Position = workspace.CurrentCamera.CFrame.Position
	end)
end

return t