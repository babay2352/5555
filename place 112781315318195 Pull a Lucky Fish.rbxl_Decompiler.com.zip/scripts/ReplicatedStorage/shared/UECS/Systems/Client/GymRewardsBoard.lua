-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ConvertValue = require(ReplicatedStorage.shared.util.ConvertValue)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local GymEventConfig = require(ReplicatedStorage.shared.config.GymEventConfig)
local t = {
	UECS = nil
}
local SigmaRewards = GymEventConfig.Tags.SigmaRewards
local t2 = {}

local function buildRows(p1) --[[ buildRows | Line: 48 | Upvalues: GymEventConfig (copy), ConvertValue (copy) ]]
	local v1 = p1:FindFirstChild(GymEventConfig.Ui.RewardsRowTemplateName, true)
	local v2 = if v1 then v1.Parent else v1

	if not (v1 and (v1:IsA("GuiObject") and v2)) then
		return
	end

	for v3, v4 in v2:GetChildren() do
		if v4.Name == "GymRewardRow" then
			v4:Destroy()
		end
	end

	v1.Visible = false

	for v5, v6 in GymEventConfig.GetEarningSummary() do
		local GymRewardRow = v1:Clone()

		GymRewardRow.Name = "GymRewardRow"
		GymRewardRow.Visible = true
		GymRewardRow.LayoutOrder = v5

		local Description = GymRewardRow:FindFirstChild("Description")

		if Description and Description:IsA("TextLabel") then
			Description.Text = v6.Label
		end

		local Value = GymRewardRow:FindFirstChild("Value")

		if Value and Value:IsA("TextLabel") then
			Value.Text = v6.AmountText or ConvertValue.suffixformat(v6.Points)
		end

		local Icon = GymRewardRow:FindFirstChild("Icon")

		if Icon and Icon:IsA("ImageLabel") then
			Icon.Image = GymEventConfig.Currency.Icon
		end

		GymRewardRow.Parent = v2
	end
end

local function startFor(p1) --[[ startFor | Line: 99 | Upvalues: t2 (copy), buildRows (copy) ]]
	if p1:IsA("SurfaceGui") and not t2[p1] then
		local t = {
			connections = {}
		}

		t2[p1] = t

		local function f1() --[[ Line: 113 | Upvalues: buildRows (ref), p1 (copy) ]]
			buildRows(p1)
		end

		table.insert(t.connections, p1.ChildAdded:Connect(f1))
		buildRows(p1)
	end
end

local function stopFor(p1) --[[ stopFor | Line: 121 | Upvalues: t2 (copy) ]]
	local v1 = t2[p1]

	if not v1 then
		return
	end

	for v2, v3 in v1.connections do
		v3:Disconnect()
	end

	t2[p1] = nil
end

function t.Init(p1) --[[ Init | Line: 132 | Upvalues: GymEventConfig (copy), CollectionService (copy), SigmaRewards (copy), startFor (copy), stopFor (copy) ]]
	if not GymEventConfig.Enabled then
		return
	end

	for v1, v2 in CollectionService:GetTagged(SigmaRewards) do
		startFor(v2)
	end

	CollectionService:GetInstanceAddedSignal(SigmaRewards):Connect(startFor)
	CollectionService:GetInstanceRemovedSignal(SigmaRewards):Connect(stopFor)
end

return t