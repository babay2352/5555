-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ContextActionService = game:GetService("ContextActionService")
local Players = game:GetService("Players")
local ProximityPromptService = game:GetService("ProximityPromptService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local AuctionHouse = require(ReplicatedStorage.shared.UECS.Components.AuctionHouse)
local AuctionHouseConfig = require(ReplicatedStorage.shared.config.AuctionHouseConfig)
local AuctionRotation = require(ReplicatedStorage.shared.util.AuctionRotation)
local CashDisplay = require(ReplicatedStorage.shared.module.CashDisplay)
local CashFormat = require(ReplicatedStorage.shared.util.CashFormat)
local ControlHint = require(ReplicatedStorage.client.ControlHint)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Remotes = require(ReplicatedStorage.shared.Remotes)
local rarityConfig = require(ReplicatedStorage.shared.config.rarityConfig)
local SFX = require(ReplicatedStorage.client.SFX)
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local createGamepadListNav = require(ReplicatedStorage.shared.util.createGamepadListNav)
local notifications = require(ReplicatedStorage.shared.module.notifications)
local t = {
	UECS = nil
}
local LocalPlayer = Players.LocalPlayer
local t2 = { Enum.KeyCode.ButtonX, Enum.KeyCode.ButtonY }
local v1 = Color3.fromRGB(255, 214, 64)
local t3 = {
	Outbid = "Someone outbid you!",
	NoFunds = "Not enough cash!",
	SoldOut = "Sold out!",
	StoreBusy = "The Auction House is busy \226\128\148 try again!",
	StaleWindow = "That auction just ended!",
	Ended = "That auction has ended!",
	AlreadyWinning = "You\'re already the highest bidder!",
	AlreadyOwned = "You already own this!",
	TooFast = "You are clicking too fast!",
	Busy = "Hold on...",
	LimitReached = ("You can only buy %* of this per auction!"):format(AuctionHouseConfig.PurchaseLimitPerSlot)
}

function t.Init(p1) --[[ Init | Line: 125 | Upvalues: LocalPlayer (copy), AuctionHouseConfig (copy), CashFormat (copy), TweenService (copy), CashDisplay (copy), AuctionRotation (copy), ClientPlayerData (copy), SFX (copy), Remotes (copy), notifications (copy), t3 (copy), rarityConfig (copy), v1 (copy), AuctionHouse (copy), t2 (copy), ControlHint (copy), ContextActionService (copy), createGamepadListNav (copy), CollectionService (copy), ProximityPromptService (copy), RunService (copy) ]]
	local MainUI = LocalPlayer.PlayerGui:WaitForChild("MainUI")
	local v12 = MainUI:FindFirstChild(AuctionHouseConfig.UiName)

	if not v12 then
		return
	end

	local v2 = v12:FindFirstChild("Content")
	local v3 = v2 and v2:FindFirstChild("ScrollingFrame")
	local v4 = v3 and v3:FindFirstChild("LimitedTemplate")
	local v5 = v3 and v3:FindFirstChild("NormalTemplatesHolder")
	local v6 = if v5 then v5:FindFirstChild("NormalTemplate") else v3 and v3:FindFirstChild("NormalTemplate")

	if v3 and (v4 and v6) then
		v12.Visible = false
		v4.Visible = false
		v6.Visible = false

		if v5 then
			v5.Visible = false
		end

		local count = 0

		for v7, v8 in v3:GetChildren() do
			if v8:IsA("GuiObject") and v8.Name == "Featured" then
				count = count + 1
				v8.LayoutOrder = if count == 1 then 0 else 100
			end
		end

		local TopBar = v12:FindFirstChild("TopBar")
		local v10 = if TopBar then TopBar:FindFirstChild("Refresh") else TopBar
		local v11 = v10 and v10:FindFirstChild("Time")
		local v122 = -1
		local t = {}
		local t4 = {}
		local v13 = nil
		local v14 = false
		local v15 = nil
		local t5 = {}
		local v16 = false
		local v17 = nil
		local v18 = nil
		local v19 = nil

		local function priceSignature(p1) --[[ priceSignature | Line: 200 | Upvalues: CashFormat (ref) ]]
			local t = {}

			for v1, v2 in CashFormat.segments(p1) do
				table.insert(t, (("%*:%*"):format(v2.TierIndex, v2.Text)))
			end

			return table.concat(t, "|")
		end

		local function beatPrice(p1) --[[ beatPrice | Line: 208 | Upvalues: TweenService (ref), CashDisplay (ref), AuctionRotation (ref), v122 (ref) ]]
			local priceLabel = p1.priceLabel

			if not priceLabel then
				return
			end

			local PriceBeat = p1.priceScale

			if not PriceBeat then
				PriceBeat = Instance.new("UIScale")
				PriceBeat.Name = "PriceBeat"
				PriceBeat.Parent = priceLabel
				p1.priceScale = PriceBeat
			end

			p1.beatToken = p1.beatToken + 1

			local beatToken = p1.beatToken
			local v1 = TweenService:Create(PriceBeat, TweenInfo.new(0.08, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
				Scale = 1.12
			})

			v1:Play()
			v1.Completed:Once(function() --[[ Line: 229 | Upvalues: p1 (copy), beatToken (copy), PriceBeat (ref), TweenService (ref) ]]
				if p1.beatToken == beatToken and PriceBeat.Parent then
					TweenService:Create(PriceBeat, TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						Scale = 1
					}):Play()
				end
			end)
			task.delay(0.28, function() --[[ Line: 242 | Upvalues: p1 (copy), beatToken (copy), priceLabel (copy), CashDisplay (ref), AuctionRotation (ref), v122 (ref) ]]
				if p1.beatToken == beatToken and priceLabel.Parent then
					CashDisplay.applyToLabel(priceLabel, AuctionRotation.priceAt(p1.slot.Entry, v122, AuctionRotation.now()))
				end
			end)
		end

		local function formatClock(p1) --[[ formatClock | Line: 250 ]]
			local v2 = math.max(0, (math.floor(p1)))

			return string.format("%d:%02d", v2 // 60, v2 % 60)
		end

		local function alreadyOwns(p1) --[[ alreadyOwns | Line: 259 | Upvalues: ClientPlayerData (ref) ]]
			local v1 = ClientPlayerData.serverProfile and ClientPlayerData.serverProfile:getState()

			if not v1 then
				return false
			end

			if p1.Category == "BaseSkin" then
				return (v1.unlockedBaseSkins or {})[p1.ConfigName] == true
			end

			if p1.Category == "FishRod" then
				return if v1.inventory[p1.ConfigName] == nil then v1.fishRod == p1.ConfigName else true
			end

			if p1.Category ~= "TrainingTool" then
				return false
			end

			return if v1.inventory[p1.ConfigName] == nil then v1.trainingTool == p1.ConfigName else true
		end

		local function activeSnapshot() --[[ activeSnapshot | Line: 280 | Upvalues: v13 (ref), v122 (ref) ]]
			if v13 and v13.WindowStart == v122 then
				return v13
			end

			return nil
		end

		local function applyLimitedRow(p1) --[[ applyLimitedRow | Line: 284 | Upvalues: v13 (ref), v122 (ref), alreadyOwns (copy), AuctionRotation (ref), CashDisplay (ref), LocalPlayer (ref), AuctionHouseConfig (ref) ]]
			local v1 = if v13 and v13.WindowStart == v122 then v13 else nil
			local v2 = if v1 then v1.Bids[p1.slot.SlotId] else v1
			local Entry = p1.slot.Entry
			local v3 = alreadyOwns(Entry)
			local v4 = if AuctionRotation.now() >= AuctionRotation.limitedEndsAt(v122) then true else false

			p1.ended = v4

			if p1.blackout then
				p1.blackout.Visible = v3 or v4

				if p1.blackoutLabel then
					p1.blackoutLabel.Text = if v4 then "Ended" else "Owned"
				end
			end

			if p1.currentBid then
				CashDisplay.applyToLabel(p1.currentBid, if v2 then v2.v else Entry.StartingPrice)
			end

			if p1.currentWinner then
				if v2 then
					p1.currentWinner.Text = v2.n
					p1.currentWinner.TextColor3 = if v2.u == LocalPlayer.UserId then Color3.fromRGB(85, 255, 127) else p1.winnerDefaultColor or p1.currentWinner.TextColor3
				else
					p1.currentWinner.Text = "None"

					if p1.winnerDefaultColor then
						p1.currentWinner.TextColor3 = p1.winnerDefaultColor
					end
				end
			end

			for v8, v9 in p1.bidButtons do
				local v10 = AuctionHouseConfig.BidSteps[v8]

				if v9.label and v10 then
					CashDisplay.applyToLabel(v9.label, AuctionRotation.bidAmount(Entry, if v2 then v2.v else v2, v10.Percent))
				end
			end
		end

		local function applyClassicRow(p1) --[[ applyClassicRow | Line: 328 | Upvalues: v13 (ref), v122 (ref), AuctionRotation (ref), ClientPlayerData (ref), AuctionHouseConfig (ref) ]]
			local v1 = if v13 and v13.WindowStart == v122 then v13 else nil
			local v2 = if v1 then v1.Stock[p1.slot.SlotId] else v1
			local v3 = if v2 == nil then false elseif v2 <= 0 then true else false
			local v4 = if AuctionRotation.now() >= AuctionRotation.classicEndsAt(p1.slot.Entry, v122) then true else false

			p1.ended = v4

			local v5 = ClientPlayerData.serverProfile and ClientPlayerData.serverProfile:getState()
			local v6 = v5 and (v5.auctionPurchases or {})[AuctionRotation.auctionId(v122, p1.slot.SlotId)] or 0
			local v8 = if AuctionHouseConfig.PurchaseLimitPerSlot <= v6 then true else false

			if p1.stockLabel then
				p1.stockLabel.Text = if v2 == nil then "in stock: ..." else ("x %*  in stock"):format(v2)
			end

			if not p1.blackout then
				return
			end

			p1.blackout.Visible = if v3 then v3 elseif v4 then v4 else v8

			if not p1.blackoutLabel then
				return
			end

			p1.blackoutLabel.Text = if v3 then "Sold out" elseif v4 then "Ended" else ("Limit %*/%*"):format(v6, AuctionHouseConfig.PurchaseLimitPerSlot)
		end

		local function applySnapshotToRows() --[[ applySnapshotToRows | Line: 360 | Upvalues: t (ref), applyLimitedRow (copy), t4 (ref), applyClassicRow (copy) ]]
			for v1, v2 in t do
				applyLimitedRow(v2)
			end

			for v3, v4 in t4 do
				applyClassicRow(v4)
			end
		end

		local function callBid(p1, p2) --[[ callBid | Line: 371 | Upvalues: v14 (ref), SFX (ref), Remotes (ref), v122 (ref), notifications (ref), t3 (ref) ]]
			if not v14 then
				v14 = true
				SFX.new(SFX.Sounds.Buy, 0.5)
				task.spawn(function() --[[ Line: 377 | Upvalues: Remotes (ref), v122 (ref), p1 (copy), p2 (copy), v14 (ref), notifications (ref), t3 (ref) ]]
					local v12, v22 = Remotes.AuctionBid:Call({
						WindowStart = v122,
						Slot = p1.slot.SlotId,
						Step = p2
					}):Await()

					v14 = false

					if not v12 or typeof(v22) ~= "table" then
						notifications:Send(t3.StoreBusy)

						return
					end

					if v22.Ok or not v22.Reason then
						return
					end

					notifications:Send(t3[v22.Reason] or t3.StoreBusy)
				end)
			end
		end

		local function callBuy(p1) --[[ callBuy | Line: 395 | Upvalues: v14 (ref), SFX (ref), Remotes (ref), v122 (ref), notifications (ref), t3 (ref) ]]
			if not v14 then
				v14 = true
				SFX.new(SFX.Sounds.Buy, 0.5)
				task.spawn(function() --[[ Line: 401 | Upvalues: Remotes (ref), v122 (ref), p1 (copy), v14 (ref), notifications (ref), t3 (ref) ]]
					local v12, v2 = Remotes.AuctionBuy:Call({
						WindowStart = v122,
						Slot = p1.slot.SlotId
					}):Await()

					v14 = false

					if not v12 or typeof(v2) ~= "table" then
						notifications:Send(t3.StoreBusy)

						return
					end

					if v2.Ok or not v2.Reason then
						return
					end

					notifications:Send(t3[v2.Reason] or t3.StoreBusy)
				end)
			end
		end

		local function fillCommon(p1, p2) --[[ fillCommon | Line: 422 | Upvalues: AuctionHouseConfig (ref), rarityConfig (ref) ]]
			local v1 = AuctionHouseConfig.resolveItem(p2.Category, p2.ConfigName)
			local v2 = if p2.Category == "Float" then true else false
			local ItemName = p1:FindFirstChild("ItemName")

			if ItemName then
				local v3 = v1 and v1.DisplayName or p2.ConfigName

				ItemName.Text = if v2 and p2.Tier then ("%* (%*)"):format(v3, p2.Tier) else v3
			end

			local ToolIcon = p1:FindFirstChild("ToolIcon")

			if ToolIcon and v1 and v2 then
				local TierImages = v1.TierImages

				ToolIcon.Image = TierImages and p2.Tier and TierImages[p2.Tier] or ToolIcon.Image
			elseif ToolIcon and v1 then
				ToolIcon.Image = v1.Image or (v1.Icon or ToolIcon.Image)
			end

			local Rarity = p1:FindFirstChild("Rarity")

			if Rarity then
				local v7 = if v2 then rarityConfig[p2.Tier or ""] elseif v1 then v1.Rarity else v1

				if v7 then
					Rarity.Text = v7.displayName or (v7.id or "")
					Rarity.TextColor3 = v7.rarityColor or Rarity.TextColor3
				else
					Rarity.Text = ""
				end
			end

			local Blackout = p1:FindFirstChild("Blackout")

			if Blackout then
				Blackout.Visible = false
			end

			return Blackout
		end

		local t6 = {}

		local function buildRows() --[[ buildRows | Line: 460 | Upvalues: t (ref), t6 (ref), v5 (copy), t4 (ref), t5 (ref), AuctionRotation (ref), v122 (ref), v4 (copy), fillCommon (copy), AuctionHouseConfig (ref), v14 (ref), SFX (ref), Remotes (ref), notifications (ref), t3 (ref), v3 (copy), v6 (copy), v15 (ref), applySnapshotToRows (copy) ]]
			for v1, v2 in t do
				v2.frame:Destroy()
			end

			for v32, v42 in t6 do
				v42:Destroy()
			end

			if not v5 then
				for v52, v62 in t4 do
					v62.frame:Destroy()
				end
			end

			t = {}
			t4 = {}
			t6 = {}
			t5 = {}

			local v7 = AuctionRotation.rotationFor(v122)
			local t2 = {}

			for v8, v9 in v7.Limited do
				local v10 = v4:Clone()

				v10.Name = v9.SlotId
				v10.LayoutOrder = v8
				v10.Visible = true

				local v11 = fillCommon(v10, v9.Entry)
				local v12 = if v11 then v11:FindFirstChild("ItemName") else v11
				local Stats = v10:FindFirstChild("Stats")
				local v13 = if Stats then Stats:FindFirstChild("SubStats") or Stats else Stats
				local v142 = if v13 then v13:FindFirstChild("Stock") else v13

				if v142 then
					v142.Text = "1/1"
				end

				local v152 = if Stats then Stats:FindFirstChild("Stats") else Stats
				local v16 = if v13 then v13:FindFirstChild("CurrentWinner") else v13
				local t7 = {
					kind = "Limited",
					slot = v9,
					frame = v10
				}

				t7.currentBid = if v13 then v13:FindFirstChild("CurrentBid") else v13
				t7.currentWinner = v16
				t7.winnerDefaultColor = if v16 then v16.TextColor3 else v16
				t7.timeLabel = if v152 then v152:FindFirstChild("Time") else v152
				t7.progressBar = if v152 then v152:FindFirstChild("ProgressBar") else v152
				t7.bidButtons = {}
				t7.blackout = v11
				t7.blackoutLabel = v12

				local Buttons = v10:FindFirstChild("Buttons")
				local v21 = nil

				for v22, v23 in AuctionHouseConfig.BidSteps do
					local v24 = if Buttons then Buttons:FindFirstChild(v23.Button) else Buttons

					if v24 then
						local v25 = v24:FindFirstChild("Content")
						local t8 = {
							button = v24
						}

						t8.label = if v25 then v25:FindFirstChild("TextLabel") else v25
						t7.bidButtons[v22] = t8
						v24.MouseButton1Down:Connect(function() --[[ Line: 526 | Upvalues: t7 (copy), v22 (copy), v14 (ref), SFX (ref), Remotes (ref), v122 (ref), notifications (ref), t3 (ref) ]]
							local v1 = t7
							local v2 = v22

							if not v14 then
								v14 = true
								SFX.new(SFX.Sounds.Buy, 0.5)
								task.spawn(function() --[[ Line: 377 | Upvalues: Remotes (ref), v122 (ref), v1 (copy), v2 (copy), v14 (ref), notifications (ref), t3 (ref) ]]
									local v12, v22 = Remotes.AuctionBid:Call({
										WindowStart = v122,
										Slot = v1.slot.SlotId,
										Step = v2
									}):Await()

									v14 = false

									if not v12 or typeof(v22) ~= "table" then
										notifications:Send(t3.StoreBusy)

										return
									end

									if v22.Ok or not v22.Reason then
										return
									end

									notifications:Send(t3[v22.Reason] or t3.StoreBusy)
								end)
							end
						end)
						v21 = v21 or v24
					end
				end

				v10.Parent = v3
				table.insert(t, t7)
				t5[v10] = t7

				local t8 = {
					frame = v10,
					button = v21,
					activate = function() --[[ activate | Line: 539 | Upvalues: t7 (copy), v14 (ref), SFX (ref), Remotes (ref), v122 (ref), notifications (ref), t3 (ref) ]]
						local v1 = t7

						if not v14 then
							v14 = true
							SFX.new(SFX.Sounds.Buy, 0.5)

							local v2 = 1

							task.spawn(function() --[[ Line: 377 | Upvalues: Remotes (ref), v122 (ref), v1 (copy), v2 (copy), v14 (ref), notifications (ref), t3 (ref) ]]
								local v12, v22 = Remotes.AuctionBid:Call({
									WindowStart = v122,
									Slot = v1.slot.SlotId,
									Step = v2
								}):Await()

								v14 = false

								if not v12 or typeof(v22) ~= "table" then
									notifications:Send(t3.StoreBusy)

									return
								end

								if v22.Ok or not v22.Reason then
									return
								end

								notifications:Send(t3[v22.Reason] or t3.StoreBusy)
							end)
						end
					end
				}

				table.insert(t2, t8)
			end

			local v28 = math.max(1, AuctionHouseConfig.ClassicRowsPerHolder)
			local v29 = nil

			for v31, v32 in v7.Classic do
				local v30
				local v33 = v3

				if v5 then
					local v34 = (v31 - 1) % v28 + 1

					if v34 == 1 then
						local v35 = #t6 + 1
						local v36 = v5:Clone()

						v36.Name = ("ClassicHolder%*"):format(v35)
						v36.LayoutOrder = v35 + 100
						v36.Visible = true

						local NormalTemplate = v36:FindFirstChild("NormalTemplate")

						if NormalTemplate then
							NormalTemplate:Destroy()
						end

						v36.Parent = v3
						table.insert(t6, v36)
						v29 = v36
					end

					v30 = v34
					v33 = v29
				else
					v30 = 100 + v31
				end

				local v38 = v6:Clone()

				v38.Name = v32.SlotId
				v38.LayoutOrder = v30
				v38.Visible = true

				local v39 = fillCommon(v38, v32.Entry)
				local v40 = if v39 then v39:FindFirstChild("ItemName") else v39
				local Stats = v38:FindFirstChild("Stats")
				local v41 = Stats and Stats:FindFirstChild("Stats")
				local Buttons = v38:FindFirstChild("Buttons")
				local v42 = if Buttons then Buttons:FindFirstChild("BuyButton") else Buttons
				local v43 = if v42 then v42:FindFirstChild("Content") else v42
				local t7 = {
					kind = "Classic",
					beatToken = 0,
					slot = v32,
					frame = v38
				}

				t7.stockLabel = if Stats then Stats:FindFirstChild("Stock") else Stats
				t7.timeLabel = if v41 then v41:FindFirstChild("Time") else v41
				t7.progressBar = if v41 then v41:FindFirstChild("ProgressBar") else v41
				t7.buyButton = v42
				t7.priceLabel = if v43 then v43:FindFirstChild("TextLabel") else v43
				t7.blackout = v39
				t7.blackoutLabel = v40

				if v42 then
					v42.MouseButton1Down:Connect(function() --[[ Line: 603 | Upvalues: t7 (copy), v14 (ref), SFX (ref), Remotes (ref), v122 (ref), notifications (ref), t3 (ref) ]]
						local v1 = t7

						if not v14 then
							v14 = true
							SFX.new(SFX.Sounds.Buy, 0.5)
							task.spawn(function() --[[ Line: 401 | Upvalues: Remotes (ref), v122 (ref), v1 (copy), v14 (ref), notifications (ref), t3 (ref) ]]
								local v12, v2 = Remotes.AuctionBuy:Call({
									WindowStart = v122,
									Slot = v1.slot.SlotId
								}):Await()

								v14 = false

								if not v12 or typeof(v2) ~= "table" then
									notifications:Send(t3.StoreBusy)

									return
								end

								if v2.Ok or not v2.Reason then
									return
								end

								notifications:Send(t3[v2.Reason] or t3.StoreBusy)
							end)
						end
					end)
				end

				v38.Parent = v33
				table.insert(t4, t7)

				local t8 = {
					frame = v38,
					button = v42,
					activate = function() --[[ activate | Line: 613 | Upvalues: t7 (copy), v14 (ref), SFX (ref), Remotes (ref), v122 (ref), notifications (ref), t3 (ref) ]]
						local v1 = t7

						if not v14 then
							v14 = true
							SFX.new(SFX.Sounds.Buy, 0.5)
							task.spawn(function() --[[ Line: 401 | Upvalues: Remotes (ref), v122 (ref), v1 (copy), v14 (ref), notifications (ref), t3 (ref) ]]
								local v12, v2 = Remotes.AuctionBuy:Call({
									WindowStart = v122,
									Slot = v1.slot.SlotId
								}):Await()

								v14 = false

								if not v12 or typeof(v2) ~= "table" then
									notifications:Send(t3.StoreBusy)

									return
								end

								if v2.Ok or not v2.Reason then
									return
								end

								notifications:Send(t3[v2.Reason] or t3.StoreBusy)
							end)
						end
					end
				}

				table.insert(t2, t8)
			end

			if v15 then
				v15:SetRows(t2)
			end

			applySnapshotToRows()
		end

		local function acceptSnapshot(p1) --[[ acceptSnapshot | Line: 637 | Upvalues: v122 (ref), v13 (ref), buildRows (copy), applySnapshotToRows (copy) ]]
			if typeof(p1) ~= "table" then
				return
			end

			if typeof(p1.WindowStart) ~= "number" then
				return
			end

			if p1.WindowStart < v122 then
				return
			end

			local t = {
				WindowStart = p1.WindowStart
			}

			t.Bids = if typeof(p1.Bids) == "table" then p1.Bids else {}
			t.Stock = if typeof(p1.Stock) == "table" then p1.Stock else {}
			v13 = t

			if v122 < p1.WindowStart then
				v122 = p1.WindowStart
				buildRows()
			else
				applySnapshotToRows()
			end
		end

		Remotes.ReplicateAuctionHouse:On(acceptSnapshot)
		ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 665 ]]
			return p1.auctionPurchases
		end, function() --[[ Line: 667 | Upvalues: applySnapshotToRows (copy) ]]
			applySnapshotToRows()
		end)

		local function fetchState(p1) --[[ fetchState | Line: 671 | Upvalues: Remotes (ref), acceptSnapshot (copy) ]]
			task.spawn(function() --[[ Line: 672 | Upvalues: Remotes (ref), p1 (copy), acceptSnapshot (ref) ]]
				local v1, v22 = Remotes.GetAuctionHouseState:Call({
					UIOpen = p1
				}):Await()

				if not (v1 and p1) then
					return
				end

				acceptSnapshot(v22)
			end)
		end

		local function v() --[[ tick | Line: 682 | Upvalues: AuctionRotation (ref), v122 (ref), v13 (ref), buildRows (copy), v12 (copy), Remotes (ref), acceptSnapshot (copy), v11 (copy), t (ref), AuctionHouseConfig (ref), applyLimitedRow (copy), t4 (ref), applyClassicRow (copy), priceSignature (copy), CashDisplay (ref), v1 (ref), beatPrice (copy) ]]
			local v14 = AuctionRotation.current()

			if v122 < v14 then
				v122 = v14

				if v13 and v13.WindowStart ~= v14 then
					v13 = nil
				end

				buildRows()

				if v12.Visible then
					local v2 = true

					task.spawn(function() --[[ Line: 672 | Upvalues: Remotes (ref), v2 (copy), acceptSnapshot (ref) ]]
						local v1, v22 = Remotes.GetAuctionHouseState:Call({
							UIOpen = v2
						}):Await()

						if not (v1 and v2) then
							return
						end

						acceptSnapshot(v22)
					end)
				end
			end

			local v3 = AuctionRotation.secondsLeft()

			if v11 then
				local v6 = math.max(0, (math.floor(v3)))

				v11.Text = ("Refresh in: %*"):format((string.format("%d:%02d", v6 // 60, v6 % 60)))
			end

			local v7 = AuctionRotation.now()

			local function applyClock(p1, p2, p3, p4) --[[ applyClock | Line: 708 | Upvalues: v7 (copy) ]]
				local v1 = p3 - v7

				if p1 then
					local v2

					if v1 > 0 then
						local v4 = math.max(0, (math.floor(v1)))

						v2 = string.format("%d:%02d", v4 // 60, v4 % 60)
					else
						v2 = "Ended"
					end

					p1.Text = v2
				end

				if p2 then
					local v6 = math.clamp(1 - v1 / p4, 0, 1)
					local Size = p2.Size

					p2.Size = UDim2.new(v6, 0, Size.Y.Scale, Size.Y.Offset)

					if not p2.Visible then
						p2.Visible = true
					end
				end

				return v1 <= 0
			end

			for v8, v9 in t do
				local v10 = applyClock(v9.timeLabel, v9.progressBar, AuctionRotation.limitedEndsAt(v122), AuctionHouseConfig.LimitedDuration)

				if v10 ~= (v9.ended == true) then
					applyLimitedRow(v9)
				end
			end

			for v112, v123 in t4 do
				local Entry = v123.slot.Entry
				local v132 = applyClock(v123.timeLabel, v123.progressBar, AuctionRotation.classicEndsAt(Entry, v122), Entry.Duration)

				if v132 ~= (if v123.ended == true then true else false) then
					applyClassicRow(v123)
				end

				if v123.priceLabel and not v132 then
					local v15 = AuctionRotation.priceAt(v123.slot.Entry, v122, v7)
					local v16 = priceSignature(v15)
					local v17 = if v123.priceSignature == nil then false elseif v123.priceSignature == v16 then false else true

					v123.priceSignature = v16

					local v18 = if v17 then v12.Visible else v17

					CashDisplay.applyToLabel(v123.priceLabel, v15, if v18 then {
	AmountColor = v1
} else nil)

					if v18 then
						beatPrice(v123)
					end
				end
			end
		end

		local v20 = AuctionHouse.Add(v12)

		v20.Visible.OnChange:Connect(function(p1) --[[ Line: 771 | Upvalues: v12 (copy), MainUI (copy), v16 (ref), v15 (ref), v17 (ref), v18 (ref), v19 (ref), Remotes (ref), acceptSnapshot (copy) ]]
			v12.Visible = p1

			local HUD = MainUI:FindFirstChild("HUD")

			if HUD then
				HUD.Visible = not p1
			end

			v16 = p1

			if v15 then
				v15:SetOpen(p1)
			end

			if p1 then
				v17()
			else
				v18()
				v19(nil)
			end

			task.spawn(function() --[[ Line: 672 | Upvalues: Remotes (ref), p1 (copy), acceptSnapshot (ref) ]]
				local v1, v22 = Remotes.GetAuctionHouseState:Call({
					UIOpen = p1
				}):Await()

				if not (v1 and p1) then
					return
				end

				acceptSnapshot(v22)
			end)
		end)

		local v21 = if TopBar then TopBar:FindFirstChild("CloseButton") else TopBar

		local function closeShop() --[[ closeShop | Line: 796 | Upvalues: p1 (copy), v20 (copy) ]]
			local v1 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

			if not v1 or v1.OpenedUIComponent:Get() ~= v20 then
				return
			end

			v1.OpenedUIComponent:Set(nil)
		end

		if v21 then
			v21.MouseButton1Down:Connect(closeShop)
		end

		local t7 = {}

		for i = 2, #AuctionHouseConfig.BidSteps do
			local v22 = t2[i - 1]

			if v22 then
				local v23 = ControlHint.new({
					anchorTo = v3,
					keyCode = v22,
					label = ("Bid +%*%%"):format(AuctionHouseConfig.BidSteps[i].Percent)
				})

				v23:Hide()
				t7[i] = v23
			end
		end

		v19 = function(p1) --[[ Line: 825 | Upvalues: t5 (ref), t7 (copy), v16 (ref) ]]
			local v1 = if p1 then t5[p1.frame] else p1

			for v2, v3 in t7 do
				local v4 = if v1 then v1.bidButtons[v2] else v1

				if v16 and v4 then
					v3:SetAnchor(v4.button)
					v3:Show()

					continue
				end

				v3:Hide()
			end
		end
		v17 = function() --[[ Line: 838 | Upvalues: AuctionHouseConfig (ref), t2 (ref), ContextActionService (ref), v15 (ref), t5 (ref), v14 (ref), SFX (ref), Remotes (ref), v122 (ref), notifications (ref), t3 (ref) ]]
			for i = 2, #AuctionHouseConfig.BidSteps do
				local v1 = t2[i - 1]

				if v1 then
					ContextActionService:BindAction(("AuctionHouseRaise%*"):format(i), function(p1, p2) --[[ Line: 844 | Upvalues: v15 (ref), t5 (ref), i (copy), v14 (ref), SFX (ref), Remotes (ref), v122 (ref), notifications (ref), t3 (ref) ]]
						if p2 ~= Enum.UserInputState.Begin then
							return Enum.ContextActionResult.Sink
						end

						local v1 = v15 and v15:GetSelected()
						local v2 = v1 and t5[v1.frame]

						if not (v2 and v2.bidButtons[i]) then
							return Enum.ContextActionResult.Sink
						end

						local v3 = i

						if v14 then
							return Enum.ContextActionResult.Sink
						end

						v14 = true
						SFX.new(SFX.Sounds.Buy, 0.5)
						task.spawn(function() --[[ Line: 377 | Upvalues: Remotes (ref), v122 (ref), v2 (copy), v3 (copy), v14 (ref), notifications (ref), t3 (ref) ]]
							local v12, v22 = Remotes.AuctionBid:Call({
								WindowStart = v122,
								Slot = v2.slot.SlotId,
								Step = v3
							}):Await()

							v14 = false

							if not v12 or typeof(v22) ~= "table" then
								notifications:Send(t3.StoreBusy)

								return
							end

							if v22.Ok or not v22.Reason then
								return
							end

							notifications:Send(t3[v22.Reason] or t3.StoreBusy)
						end)

						return Enum.ContextActionResult.Sink
					end, false, v1)
				end
			end
		end
		v18 = function() --[[ Line: 859 | Upvalues: AuctionHouseConfig (ref), ContextActionService (ref) ]]
			for i = 2, #AuctionHouseConfig.BidSteps do
				ContextActionService:UnbindAction((("AuctionHouseRaise%*"):format(i)))
			end
		end
		v15 = createGamepadListNav({
			actionPrefix = "AuctionHouse",
			shop = v12,
			scroll = v3,
			closeButton = v21,
			confirmKey = Enum.KeyCode.ButtonA,
			confirmLabel = ("Bid +%*%% / Buy"):format(AuctionHouseConfig.BidSteps[1].Percent),
			onClose = closeShop,
			onSelectionChanged = v19
		})

		local function openShop() --[[ openShop | Line: 880 | Upvalues: p1 (copy), v20 (copy) ]]
			local v1 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

			if not v1 or v1.OpenedUIComponent:Get() == v20 then
				return
			end

			v1.OpenedUIComponent:Set(v20)
		end

		local Prompt = AuctionHouseConfig.Prompt

		local function attachPrompt(p1) --[[ attachPrompt | Line: 889 | Upvalues: Prompt (copy) ]]
			local v1 = if p1:IsA("Model") then p1.PrimaryPart or p1:FindFirstChildWhichIsA("BasePart") else p1

			if not (v1 and v1:IsA("BasePart")) then
				return
			end

			if not v1:FindFirstChild("AuctionHousePrompt") then
				local AuctionHousePrompt = Instance.new("ProximityPrompt")

				AuctionHousePrompt.Name = "AuctionHousePrompt"
				AuctionHousePrompt.ActionText = Prompt.ActionText
				AuctionHousePrompt.ObjectText = Prompt.ObjectText
				AuctionHousePrompt.MaxActivationDistance = Prompt.MaxDistance
				AuctionHousePrompt.RequiresLineOfSight = false
				AuctionHousePrompt.Parent = v1
			end
		end

		for v24, v25 in CollectionService:GetTagged(Prompt.Tag) do
			attachPrompt(v25)
		end

		CollectionService:GetInstanceAddedSignal(Prompt.Tag):Connect(attachPrompt)
		ProximityPromptService.PromptTriggered:Connect(function(p12, p2) --[[ Line: 916 | Upvalues: LocalPlayer (ref), p1 (copy), v20 (copy) ]]
			if p12.Name ~= "AuctionHousePrompt" or p2 ~= LocalPlayer then
				return
			end

			local v1 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

			if not v1 or v1.OpenedUIComponent:Get() == v20 then
				return
			end

			v1.OpenedUIComponent:Set(v20)
		end)
		v122 = AuctionRotation.current()
		buildRows()
		v()

		local v26 = 0

		RunService.Heartbeat:Connect(function(p1) --[[ Line: 928 | Upvalues: v26 (ref), v (copy) ]]
			v26 = v26 + p1

			if not (v26 < 1) then
				v26 = 0
				v()
			end
		end)
	else
		warn((("[AuctionHouse] %* is missing Content.ScrollingFrame.LimitedTemplate / NormalTemplatesHolder.NormalTemplate"):format((v12:GetFullName()))))
	end
end

return t