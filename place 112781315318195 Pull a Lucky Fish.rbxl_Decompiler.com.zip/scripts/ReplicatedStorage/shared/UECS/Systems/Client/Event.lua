-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
game:GetService("Players")

local ReplicatedStorage = game:GetService("ReplicatedStorage")

require(ReplicatedStorage.client.ClientPlayerData)

local EventUtils = require(ReplicatedStorage.client.EventUtils)

require(ReplicatedStorage.shared.config.FishConfig)
require(ReplicatedStorage.shared.UECS.GlobalTypes)
require(ReplicatedStorage.shared.UECS.Components.Index)

return {
	UECS = nil,
	Priority = 100,
	Init = function(p1) --[[ Init | Line: 13 | Upvalues: EventUtils (copy) ]]
		task.delay(120, function() --[[ Line: 14 | Upvalues: EventUtils (ref) ]]
			EventUtils:PromptEventRsvp()
		end)
	end
}