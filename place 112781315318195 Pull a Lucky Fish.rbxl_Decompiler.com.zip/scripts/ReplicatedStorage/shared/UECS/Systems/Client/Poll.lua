-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Poll = require(ReplicatedStorage.shared.UECS.Components.Poll)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local TweenNumber = require(ReplicatedStorage.shared.util.TweenNumber)
local notifications = require(ReplicatedStorage.shared.module.notifications)

local function fractionUDim(p1) --[[ fractionUDim | Line: 16 ]]
	return UDim2.new(math.clamp(p1, 0, 1), 0, 1, 0)
end

local function noop() --[[ noop | Line: 23 ]] end

return {
	UECS = nil,
	Init = function(p1) --[[ Init | Line: 28 | Upvalues: ReplicatedStorage (copy), Players (copy), Poll (copy), TweenNumber (copy), noop (copy), Remotes (copy), notifications (copy) ]]
		local PollState = ReplicatedStorage:WaitForChild("PollState")
		local Poll2 = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI"):WaitForChild("Poll")
		local v1 = Poll2:WaitForChild("Content")
		local Question = v1:WaitForChild("Question")
		local VoterInitatior = v1:WaitForChild("VoterInitatior")
		local Option1 = v1:WaitForChild("Option1")
		local Option2 = v1:WaitForChild("Option2")
		local ImageLabel = Option1:WaitForChild("Content"):WaitForChild("ImageLabel")
		local TextLabel = Option2:WaitForChild("Content"):WaitForChild("TextLabel")
		local CollectBar = v1:WaitForChild("CollectBar")
		local Option12 = CollectBar:WaitForChild("Option1")
		local Option22 = CollectBar:WaitForChild("Option2")
		local ValueOption1 = CollectBar:WaitForChild("ValueOption1")
		local ValueOption2 = CollectBar:WaitForChild("ValueOption2")
		local CloseButton = Poll2:WaitForChild("TopBar"):WaitForChild("CloseButton")

		Poll2.Visible = false

		local v2 = Poll.Add(Poll2)
		local v3 = TweenNumber.new(0.4, 0)
		local v4 = TweenNumber.new(0.4, 0)
		local v5 = TweenNumber.new(0.4, 0.5)
		local v6 = TweenNumber.new(0.4, 0.5)

		v3:OnChange(function(p1) --[[ Line: 67 | Upvalues: ValueOption1 (copy) ]]
			ValueOption1.Text = tostring((math.floor(p1 + 0.5)))
		end)
		v4:OnChange(function(p1) --[[ Line: 70 | Upvalues: ValueOption2 (copy) ]]
			ValueOption2.Text = tostring((math.floor(p1 + 0.5)))
		end)
		v5:OnChange(function(p1) --[[ Line: 73 | Upvalues: Option12 (copy) ]]
			Option12.Size = UDim2.new(math.clamp(p1, 0, 1), 0, 1, 0)
		end)
		v6:OnChange(function(p1) --[[ Line: 76 | Upvalues: Option22 (copy) ]]
			Option22.Size = UDim2.new(math.clamp(p1, 0, 1), 0, 1, 0)
		end)

		local v7 = ""
		local v8 = false

		local function snapToBaseline() --[[ snapToBaseline | Line: 92 | Upvalues: ValueOption1 (copy), ValueOption2 (copy), Option12 (copy), Option22 (copy), v3 (copy), v4 (copy), v5 (copy), v6 (copy) ]]
			ValueOption1.Text = "0"
			ValueOption2.Text = "0"
			Option12.Size = UDim2.new(0.5, 0, 1, 0)
			Option22.Size = UDim2.new(0.5, 0, 1, 0)
			v3:Reset(false)
			v4:Reset(false)
			v5:ResetToStarting(false)
			v6:ResetToStarting(false)
		end

		snapToBaseline()

		local function getOpener() --[[ getOpener | Line: 106 | Upvalues: p1 (copy) ]]
			return p1.UECS:WaitForAnyComponent("UIFrameOpener")
		end

		local function closeViaOpener() --[[ closeViaOpener | Line: 110 | Upvalues: p1 (copy), v2 (copy) ]]
			local v1 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

			if v1.OpenedUIComponent:Get() ~= v2 then
				return
			end

			v1.OpenedUIComponent:Set(nil)
		end

		v2.Visible.OnChange:Connect(function(p1) --[[ Line: 117 | Upvalues: snapToBaseline (copy), Poll2 (copy) ]]
			if not p1 then
				Poll2.Visible = p1

				return
			end

			snapToBaseline()
			Poll2.Visible = p1
		end)
		CloseButton.MouseButton1Click:Connect(closeViaOpener)

		local function refresh() --[[ refresh | Line: 133 | Upvalues: PollState (copy), v7 (ref), v8 (ref), snapToBaseline (copy), p1 (copy), v2 (copy), Question (copy), ImageLabel (copy), TextLabel (copy), VoterInitatior (copy), v3 (copy), noop (ref), v4 (copy), v5 (copy), v6 (copy), Option1 (copy), Option2 (copy) ]]
			local v22 = tostring(PollState:GetAttribute("VoteId") or "")
			local v42 = tostring(PollState:GetAttribute("Phase") or "idle")

			if v22 ~= v7 then
				v7 = v22
				v8 = false
				snapToBaseline()
			end

			if v22 == "" or v42 == "idle" then
				local v52 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

				if v52.OpenedUIComponent:Get() ~= v2 then
					return
				end

				v52.OpenedUIComponent:Set(nil)
			else
				Question.Text = tostring(PollState:GetAttribute("Question") or "")
				ImageLabel.Text = tostring(PollState:GetAttribute("Option1Text") or "")
				TextLabel.Text = tostring(PollState:GetAttribute("Option2Text") or "")
				VoterInitatior.Text = ("%* started an vote!%*"):format(tostring(PollState:GetAttribute("VoterInitiator") or ""), if v42 == "voting" then (" (%*s)"):format((math.max(0, (math.floor((tonumber(PollState:GetAttribute("ExpiresAt")) or 0) - os.time() + 0.5))))) else "")

				local v20 = tonumber(PollState:GetAttribute("Option1Count")) or 0
				local v222 = tonumber(PollState:GetAttribute("Option2Count")) or 0

				v3:Set(v20, noop)
				v4:Set(v222, noop)

				local v23 = v20 + v222

				if v23 > 0 then
					v5:Set(v20 / v23, noop)
					v6:Set(v222 / v23, noop)
				else
					v5:Set(0.5, noop)
					v6:Set(0.5, noop)
				end

				local v24 = if v42 == "voting" then not v8 else false

				Option1.Visible = v24
				Option2.Visible = v24

				local v25 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

				if v25.OpenedUIComponent:Get() == v2 then
					return
				end

				v25.OpenedUIComponent:Set(v2)
			end
		end

		PollState.AttributeChanged:Connect(refresh)
		refresh()
		task.spawn(function() --[[ Line: 206 | Upvalues: PollState (copy), v7 (ref), refresh (copy) ]]
			while true do
				repeat
					task.wait(1)
				until PollState:GetAttribute("Phase") == "voting" and v7 ~= ""

				refresh()
			end
		end)

		local function cast(p12) --[[ cast | Line: 215 | Upvalues: v8 (ref), v7 (ref), PollState (copy), Option1 (copy), Option2 (copy), p1 (copy), v2 (copy), Remotes (ref), notifications (ref) ]]
			if v8 or v7 == "" then
				return
			end

			local v1 = if p12 == 1 then tostring(PollState:GetAttribute("Option1Text") or "Option 1") else tostring(PollState:GetAttribute("Option2Text") or "Option 2")

			v8 = true
			Option1.Visible = false
			Option2.Visible = false

			local v4 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

			if v4.OpenedUIComponent:Get() ~= v2 then
				task.spawn(function() --[[ Line: 232 | Upvalues: Remotes (ref), v7 (ref), p12 (copy), notifications (ref), v1 (copy) ]]
					local v12, v2 = Remotes.CastVote:Call(v7, p12):Await()

					if v12 and (type(v2) == "table" and v2.ok) then
						notifications:Send((("You voted for %*"):format(v1)))

						return
					end

					notifications:Send((("Vote failed: %*"):format(type(v2) == "table" and tostring(v2.reason or "unknown") or "network error")))
				end)

				return
			end

			v4.OpenedUIComponent:Set(nil)
			task.spawn(function() --[[ Line: 232 | Upvalues: Remotes (ref), v7 (ref), p12 (copy), notifications (ref), v1 (copy) ]]
				local v12, v2 = Remotes.CastVote:Call(v7, p12):Await()

				if v12 and (type(v2) == "table" and v2.ok) then
					notifications:Send((("You voted for %*"):format(v1)))

					return
				end

				notifications:Send((("Vote failed: %*"):format(type(v2) == "table" and tostring(v2.reason or "unknown") or "network error")))
			end)
		end

		Option1.MouseButton1Click:Connect(function() --[[ Line: 244 | Upvalues: cast (copy) ]]
			cast(1)
		end)
		Option2.MouseButton1Click:Connect(function() --[[ Line: 247 | Upvalues: cast (copy) ]]
			cast(2)
		end)
	end
}