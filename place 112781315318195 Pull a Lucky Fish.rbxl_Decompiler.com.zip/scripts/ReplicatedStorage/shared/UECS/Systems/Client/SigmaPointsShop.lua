-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local MarketplaceService = game:GetService("MarketplaceService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local GymEventConfig = require(ReplicatedStorage.shared.config.GymEventConfig)
local MonetizationConfig = require(ReplicatedStorage.shared.config.MonetizationConfig)
local SFX = require(ReplicatedStorage.client.SFX)
local SigmaPointsShop = require(ReplicatedStorage.shared.UECS.Components.SigmaPointsShop)
local createGamepadListNav = require(ReplicatedStorage.shared.util.createGamepadListNav)
local fetchRobuxPriceInto = require(ReplicatedStorage.shared.util.fetchRobuxPriceInto)

return {
	UECS = nil,
	Init = function(p1) --[[ Init | Line: 45 | Upvalues: GymEventConfig (copy), Players (copy), SigmaPointsShop (copy), MonetizationConfig (copy), fetchRobuxPriceInto (copy), SFX (copy), MarketplaceService (copy), createGamepadListNav (copy) ]]
		if not GymEventConfig.Enabled then
			return
		end

		local LocalPlayer = Players.LocalPlayer
		local MainUI = LocalPlayer.PlayerGui:WaitForChild("MainUI")
		local v1 = MainUI:FindFirstChild(GymEventConfig.Shop.UiName)

		if not v1 then
			return
		end

		local v2 = v1:FindFirstChild("Content")
		local v3 = if v2 then v2:FindFirstChild("ScrollingFrame") else v2
		local v4 = if v3 then v3:FindFirstChild("Template") else v3

		if v3 and v4 then
			v1.Visible = false
			v4.Visible = false

			local v5 = SigmaPointsShop.Add(v1)
			local v6 = nil

			v5.Visible.OnChange:Connect(function(p1) --[[ Line: 74 | Upvalues: v1 (copy), MainUI (copy), v6 (ref) ]]
				v1.Visible = p1

				local HUD = MainUI:FindFirstChild("HUD")

				if HUD then
					HUD.Visible = not p1
				end

				if not v6 then
					return
				end

				v6:SetOpen(p1)
			end)

			local TopBar = v1:FindFirstChild("TopBar")
			local v7 = if TopBar then TopBar:FindFirstChild("CloseButton") else TopBar

			local function closeShop() --[[ closeShop | Line: 95 | Upvalues: p1 (copy), v5 (copy) ]]
				local v1 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

				if not v1 or v1.OpenedUIComponent:Get() ~= v5 then
					return
				end

				v1.OpenedUIComponent:Set(nil)
			end

			if v7 then
				v7.MouseButton1Down:Connect(closeShop)
			end

			local t = {}

			for v8, v9 in GymEventConfig.Shop.Packs do
				local v10 = MonetizationConfig.DevProducts[v9.DevProduct]

				if v10 then
					local v11 = v4:Clone()

					v11.Name = v9.DevProduct
					v11.LayoutOrder = v9.LayoutOrder
					v11.Visible = true

					local ItemName = v11:FindFirstChild("ItemName")

					if ItemName then
						ItemName.Text = v9.Label
					end

					local ToolIcon = v11:FindFirstChild("ToolIcon")

					if ToolIcon then
						ToolIcon.Image = GymEventConfig.Currency.Icon
					end

					local Rarity = v11:FindFirstChild("Rarity")

					if Rarity then
						Rarity.Text = ("+%*"):format(v10.SigmaPointsAmount or 0)
					end

					local Buttons = v11:FindFirstChild("Buttons")
					local v12 = if Buttons then Buttons:FindFirstChild("BuyButton") else Buttons

					if v12 then
						v12.Visible = false
					end

					local v13 = if Buttons then Buttons:FindFirstChild("BuyButtonRobux") else Buttons

					local function f14() --[[ Line: 146 ]] end

					if v13 then
						v13.Visible = true

						local v15 = v13:FindFirstChild("Content")
						local v16 = if v15 then v15:FindFirstChild("TextLabel") else v15

						if v10.ProductId > 0 then
							if v16 then
								fetchRobuxPriceInto(v16, v10.ProductId)
							end

							f14 = function() --[[ Line: 156 | Upvalues: SFX (ref), MarketplaceService (ref), LocalPlayer (copy), v10 (copy) ]]
								SFX.new(SFX.Sounds.Buy, 0.5)
								MarketplaceService:PromptProductPurchase(LocalPlayer, v10.ProductId)
							end
							v13.MouseButton1Down:Connect(f14)
						elseif v16 then
							v16.Text = GymEventConfig.Shop.UnavailableLabel
						end
					end

					v11.Parent = v3

					local t2 = {
						frame = v11
					}

					t2.button = if v10.ProductId > 0 then v13 else nil
					t2.activate = f14
					table.insert(t, t2)

					continue
				end

				warn((("[SigmaPointsShop] no DevProduct named \"%*\""):format(v9.DevProduct)))
			end

			v6 = createGamepadListNav({
				actionPrefix = "GymSigmaPointsShop",
				confirmLabel = "Buy with Robux",
				shop = v1,
				scroll = v3,
				closeButton = v7,
				confirmKey = Enum.KeyCode.ButtonA,
				onClose = closeShop
			})
			v6:SetRows(t)
		else
			warn((("[SigmaPointsShop] %* is missing Content.ScrollingFrame.Template"):format((v1:GetFullName()))))
		end
	end
}