-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Remotes = require(ReplicatedStorage.shared.Remotes)
local SFX = require(ReplicatedStorage.client.SFX)
local VFX = require(ReplicatedStorage.client.VFX)

return {
	UECS = nil,
	Init = function(p1) --[[ Init | Line: 17 | Upvalues: Remotes (copy), VFX (copy), SFX (copy) ]]
		Remotes.ShowUpgradeFX:On(function(p1) --[[ Line: 18 | Upvalues: VFX (ref), SFX (ref) ]]
			if typeof(p1) == "Instance" and p1:IsA("BasePart") then
				VFX.new("UpgradeFX", p1)
				SFX.new(SFX.Sounds.Upgrade, 0.5)
			end
		end)
	end
}