-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ContextActionService = game:GetService("ContextActionService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local UserInputService = game:GetService("UserInputService")
local BuildInBase = require(ReplicatedStorage.shared.UECS.Components.BuildInBase)
local BuildModeState = require(ReplicatedStorage.client.BuildModeState)
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local DecorationConfig = require(ReplicatedStorage.shared.config.DecorationConfig)
local GardenConfig = require(ReplicatedStorage.shared.config.GardenConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Satchel = require(ReplicatedStorage.client.Satchel)

require(ReplicatedStorage.shared.UECS.Components.TycoonComponent)

local bindToButtonPress = require(ReplicatedStorage.shared.util.bindToButtonPress)
local v1 = Color3.fromRGB(90, 255, 120)
local v2 = Color3.fromRGB(255, 90, 90)
local v3 = Color3.fromRGB(255, 255, 255)
local R = Enum.KeyCode.R
local ButtonY = Enum.KeyCode.ButtonY
local t = {
	UECS = nil
}

local function rotateTooltipText() --[[ rotateTooltipText | Line: 37 | Upvalues: UserInputService (copy), ButtonY (copy), R (copy) ]]
	local PreferredInput = UserInputService.PreferredInput
	local v1 = nil

	if PreferredInput == Enum.PreferredInput.Gamepad then
		v1 = ButtonY
	elseif PreferredInput == Enum.PreferredInput.KeyboardAndMouse then
		v1 = R
	end

	if not v1 then
		return nil
	end

	local ok, result = pcall(function() --[[ Line: 48 | Upvalues: UserInputService (ref), v1 (ref) ]]
		return UserInputService:GetStringForKeyCode(v1)
	end)

	if not ok or (typeof(result) ~= "string" or result == "") then
		result = v1.Name
	end

	return ("Press [%*] to rotate"):format(result)
end

local function setButtonText(p1, p2, p3) --[[ setButtonText | Line: 60 ]]
	if p1:IsA("TextButton") then
		p1.Text = p3

		return
	end

	if not p2 then
		return
	end

	p2.Text = p3
end

function t.Init(p1) --[[ Init | Line: 70 | Upvalues: Players (copy), BuildInBase (copy), GardenConfig (copy), ClientPlayerData (copy), Satchel (copy), BuildModeState (copy), DecorationConfig (copy), bindToButtonPress (copy), ContextActionService (copy), rotateTooltipText (copy), v2 (copy), v1 (copy), v3 (copy), UserInputService (copy) ]]
	local LocalPlayer = Players.LocalPlayer
	local PlayerGui = LocalPlayer:WaitForChild("PlayerGui")
	local BuildInBase2 = PlayerGui:WaitForChild("MainUI"):FindFirstChild("BuildInBase", true)

	if not BuildInBase2 then
		warn("[GardenBuildMode] MainUI.BuildInBase not found \226\128\148 build mode disabled")

		return
	end

	local BuildModeEnter = BuildInBase2:FindFirstChild("BuildModeEnter", true)
	local Frame = BuildInBase2:FindFirstChild("Frame")
	local v12 = Frame and Frame:FindFirstChild("Build", true)
	local v22 = Frame and Frame:FindFirstChild("Remove", true)
	local v32 = Frame and Frame:FindFirstChild("Back", true)
	local BuildStatus = BuildInBase2:FindFirstChild("BuildStatus", true)
	local RotateTooltip = BuildInBase2:FindFirstChild("RotateTooltip", true)

	if RotateTooltip then
		RotateTooltip.Visible = false
	else
		warn("[GardenBuildMode] BuildInBase.RotateTooltip not found \226\128\148 no rotation hint")
	end

	if not BuildModeEnter then
		warn("[GardenBuildMode] BuildInBase.BuildModeEnter not found \226\128\148 build mode disabled")

		return
	end

	if not (Frame and (v12 and v22)) then
		warn("[GardenBuildMode] BuildInBase.Frame is missing Build/Remove \226\128\148 only the toggle will work")
	end

	if Frame and not v32 then
		warn("[GardenBuildMode] BuildInBase.Frame.Back not found \226\128\148 there will be no way out of placing mode")
	end

	local v4 = if BuildModeEnter:IsA("TextButton") then nil else BuildModeEnter:FindFirstChildWhichIsA("TextLabel", true)
	local v5 = nil

	if BuildStatus then
		local DecorCount = BuildStatus:Clone()

		DecorCount.Name = "DecorCount"
		DecorCount.AnchorPoint = Vector2.new(0.5, 0)
		DecorCount.Position = UDim2.new(0.5, 0, 1, 6)
		DecorCount.Size = UDim2.fromScale(1, 0.9)
		DecorCount.TextScaled = true
		DecorCount.Visible = false
		DecorCount.Parent = BuildModeEnter
		v5 = DecorCount
	else
		warn("[GardenBuildMode] BuildInBase.BuildStatus not found \226\128\148 no decoration counter")
	end

	BuildInBase2.Visible = false
	BuildInBase.Add(BuildInBase2)

	local t = {}

	local function ownGardenRoot() --[[ ownGardenRoot | Line: 134 | Upvalues: p1 (copy), LocalPlayer (copy), t (copy), GardenConfig (ref) ]]
		for v1, v2 in p1.UECS:GetComponents("TycoonComponent") do
			local Entity = v2.Entity

			if v2.Owner:Get() == LocalPlayer and (typeof(Entity) == "Instance" and Entity:IsA("Model")) then
				t[Entity] = true

				local v3 = Entity:FindFirstChild(GardenConfig.RootName)

				if v3 and v3:IsA("Model") then
					return v3
				end
			end
		end

		return nil
	end

	local function isInsideGarden(p1) --[[ isInsideGarden | Line: 149 | Upvalues: LocalPlayer (copy), ClientPlayerData (ref), GardenConfig (ref) ]]
		local Character = LocalPlayer.Character
		local v1 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character

		if not v1 then
			return false
		end

		local garden = ClientPlayerData.serverProfile:getState().garden

		if not (garden and garden.bought) then
			return false
		end

		local v2 = p1:FindFirstChild(GardenConfig.BodyName)

		if not (v2 and v2:IsA("BasePart")) then
			return false
		end

		local v3 = v2.CFrame:PointToObjectSpace(v1.Position)
		local v4 = v2.Size * 0.5

		return if math.abs(v3.X) <= v4.X + 2 then if math.abs(v3.Z) <= v4.Z + 2 and v3.Y >= -v4.Y - 10 then v3.Y <= v4.Y + 25 else false else false
	end

	local function setBackpackHidden(p1) --[[ setBackpackHidden | Line: 171 | Upvalues: PlayerGui (copy), Satchel (ref) ]]
		local BackpackGui = PlayerGui:FindFirstChild("BackpackGui")

		if BackpackGui and BackpackGui:IsA("ScreenGui") then
			BackpackGui.Enabled = not p1
		end

		if p1 and Satchel.IsOpen then
			Satchel.OpenClose()
		end

		Satchel:SetBackpackEnabled(not p1)
	end

	local function isEngaged() --[[ isEngaged | Line: 182 | Upvalues: BuildModeState (ref) ]]
		return BuildModeState.Active and (if BuildModeState.Mode == "Remove" then true else BuildModeState.SelectedConfigName ~= nil)
	end

	local function placingText(p1) --[[ placingText | Line: 186 | Upvalues: DecorationConfig (ref), ClientPlayerData (ref) ]]
		local v1 = DecorationConfig[p1]

		if not v1 then
			return "Build Mode"
		end

		local v2 = ClientPlayerData.serverProfile:getState().inventory[p1]

		return ("Placing %* (x%*)"):format(v1.DisplayName, if v2 then v2.Stack or 0 else 0)
	end

	local v6 = nil
	local v7 = nil

	local function isPlacing() --[[ isPlacing | Line: 199 | Upvalues: BuildModeState (ref) ]]
		return BuildModeState.InGarden and (BuildModeState.Active and (if BuildModeState.Mode == "Build" then BuildModeState.SelectedConfigName ~= nil else false))
	end

	local function isMenuOpen() --[[ isMenuOpen | Line: 206 | Upvalues: v6 (ref) ]]
		return if v6 == nil then false else v6.OpenedUIComponent:Get() ~= nil
	end

	local function toggleBuildMode() --[[ toggleBuildMode | Line: 210 | Upvalues: BuildModeState (ref) ]]
		if BuildModeState.InGarden then
			BuildModeState.SetActive(not BuildModeState.Active)
		end
	end

	local function openPicker() --[[ openPicker | Line: 217 | Upvalues: BuildModeState (ref), v6 (ref), v7 (ref) ]]
		if not BuildModeState.Active then
			return
		end

		BuildModeState.SetMode("Build")

		if not (v6 and v7) then
			return
		end

		v6.OpenedUIComponent:Set(v7)
	end

	local function toggleRemoveMode() --[[ toggleRemoveMode | Line: 227 | Upvalues: BuildModeState (ref), v6 (ref) ]]
		if not BuildModeState.Active then
			return
		end

		if v6 then
			v6.OpenedUIComponent:Set(nil)
		end

		BuildModeState.SetMode(if BuildModeState.Mode == "Remove" then "Build" else "Remove")
	end

	local function goBack() --[[ goBack | Line: 237 | Upvalues: BuildModeState (ref) ]]
		if not BuildModeState.Active then
			return
		end

		if BuildModeState.Mode == "Remove" then
			BuildModeState.SetMode("Build")

			return
		end

		if BuildModeState.SelectedConfigName then
			BuildModeState.SetSelected(nil)
		else
			BuildModeState.SetActive(false)
		end
	end

	local t2 = {}

	local function setBinding(p1, p2, p3, p4) --[[ setBinding | Line: 252 | Upvalues: t2 (copy), bindToButtonPress (ref), ContextActionService (ref) ]]
		if t2[p1] == p2 then
			return
		end

		t2[p1] = p2

		if p2 then
			bindToButtonPress(p1, p3, p4, 9000)
		else
			ContextActionService:UnbindAction(p1)
		end
	end

	local function applyGamepadBindings(p1, p2, p3) --[[ applyGamepadBindings | Line: 264 | Upvalues: v6 (ref), BuildModeState (ref), toggleBuildMode (copy), t2 (copy), bindToButtonPress (ref), ContextActionService (ref), goBack (copy), openPicker (copy), toggleRemoveMode (copy) ]]
		local v1 = p1 and not (if v6 == nil then false else v6.OpenedUIComponent:Get() ~= nil)
		local v3 = if v1 then if p2 then not p3 else p2 else v1
		local v4 = v1 and not (BuildModeState.InGarden and (BuildModeState.Active and (if BuildModeState.Mode == "Build" then BuildModeState.SelectedConfigName ~= nil else false)))
		local ButtonY = Enum.KeyCode.ButtonY
		local v62 = toggleBuildMode

		if t2.GardenBuildToggle ~= v4 then
			t2.GardenBuildToggle = v4

			if v4 then
				bindToButtonPress("GardenBuildToggle", ButtonY, v62, 9000)
			else
				ContextActionService:UnbindAction("GardenBuildToggle")
			end
		end

		local v7 = v1 and p2
		local ButtonB = Enum.KeyCode.ButtonB
		local v8 = goBack

		if t2.GardenBuildBack ~= v7 then
			t2.GardenBuildBack = v7

			if v7 then
				bindToButtonPress("GardenBuildBack", ButtonB, v8, 9000)
			else
				ContextActionService:UnbindAction("GardenBuildBack")
			end
		end

		local ButtonA = Enum.KeyCode.ButtonA
		local v9 = openPicker

		if t2.GardenBuildOpenPicker ~= v3 then
			t2.GardenBuildOpenPicker = v3

			if v3 then
				bindToButtonPress("GardenBuildOpenPicker", ButtonA, v9, 9000)
			else
				ContextActionService:UnbindAction("GardenBuildOpenPicker")
			end
		end

		local ButtonX = Enum.KeyCode.ButtonX
		local v10 = toggleRemoveMode

		if t2.GardenBuildRemoveMode == v3 then
			return
		end

		t2.GardenBuildRemoveMode = v3

		if v3 then
			bindToButtonPress("GardenBuildRemoveMode", ButtonX, v10, 9000)
		else
			ContextActionService:UnbindAction("GardenBuildRemoveMode")
		end
	end

	local function render() --[[ render | Line: 273 | Upvalues: BuildModeState (ref), BuildInBase2 (copy), Frame (copy), v12 (copy), v22 (copy), v32 (copy), RotateTooltip (copy), rotateTooltipText (ref), BuildStatus (copy), v2 (ref), DecorationConfig (ref), ClientPlayerData (ref), v1 (ref), v5 (ref), GardenConfig (ref), v3 (ref), BuildModeEnter (copy), v4 (ref), PlayerGui (copy), Satchel (ref), applyGamepadBindings (copy) ]]
		local InGarden = BuildModeState.InGarden
		local Active = BuildModeState.Active
		local v13 = BuildModeState.Active and (if BuildModeState.Mode == "Remove" then true else BuildModeState.SelectedConfigName ~= nil)

		BuildInBase2.Visible = InGarden

		if Frame then
			Frame.Visible = InGarden and Active
		end

		if v12 then
			v12.Visible = not v13
		end

		if v22 then
			v22.Visible = not v13
		end

		if v32 then
			v32.Visible = InGarden and v13
		end

		if RotateTooltip then
			local v23 = BuildModeState.InGarden and (BuildModeState.Active and (if BuildModeState.Mode == "Build" then BuildModeState.SelectedConfigName ~= nil else false))
			local v33 = if v23 then rotateTooltipText() else nil

			RotateTooltip.Visible = if v33 == nil then false else true

			if v33 then
				RotateTooltip.Text = v33
			end
		end

		if BuildStatus then
			BuildStatus.Visible = InGarden and v13

			if BuildModeState.Mode == "Remove" then
				BuildStatus.Text = "Destroy Mode"
				BuildStatus.TextColor3 = v2
			elseif BuildModeState.SelectedConfigName then
				local SelectedConfigName = BuildModeState.SelectedConfigName
				local v7 = DecorationConfig[SelectedConfigName]
				local v8

				if v7 then
					local v9 = ClientPlayerData.serverProfile:getState().inventory[SelectedConfigName]

					v8 = ("Placing %* (x%*)"):format(v7.DisplayName, if v9 then v9.Stack or 0 else 0)
				else
					v8 = "Build Mode"
				end

				BuildStatus.Text = v8
				BuildStatus.TextColor3 = v1
			end
		end

		if v5 then
			v5.Visible = InGarden and Active

			local garden = ClientPlayerData.serverProfile:getState().garden
			local v122 = GardenConfig.CountPlacedItems(garden)
			local v132 = GardenConfig.GetMaxPlacedItems(garden)

			v5.Text = ("%*/%*"):format(v122, v132)
			v5.TextColor3 = if v132 <= v122 then v2 else v3
		end

		local v16 = BuildModeEnter
		local v17 = v4
		local v18 = if Active then "Leave Build Mode" else "Build Mode"

		if v16:IsA("TextButton") then
			v16.Text = v18
		elseif v17 then
			v17.Text = v18
		end

		local v19 = InGarden and Active
		local BackpackGui = PlayerGui:FindFirstChild("BackpackGui")

		if BackpackGui and BackpackGui:IsA("ScreenGui") then
			BackpackGui.Enabled = not v19
		end

		if v19 and Satchel.IsOpen then
			Satchel.OpenClose()
		end

		Satchel:SetBackpackEnabled(not v19)
		applyGamepadBindings(InGarden, Active, v13)
	end

	task.spawn(function() --[[ Line: 322 | Upvalues: v6 (ref), p1 (copy), render (copy), v7 (ref) ]]
		v6 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

		if v6 then
			v6.OpenedUIComponent.OnChange:Connect(render)
			render()
		end

		v7 = p1.UECS:WaitForAnyComponent("DecorationsInventory")
	end)
	BuildModeState.Changed:Connect(render)
	UserInputService:GetPropertyChangedSignal("PreferredInput"):Connect(render)
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 333 ]]
		return p1.inventory
	end, function() --[[ Line: 335 | Upvalues: BuildModeState (ref), render (copy) ]]
		if not (BuildModeState.Active and (if BuildModeState.Mode == "Remove" then true else BuildModeState.SelectedConfigName ~= nil)) then
			return
		end

		render()
	end)
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 342 ]]
		return p1.garden
	end, function() --[[ Line: 344 | Upvalues: BuildModeState (ref), render (copy) ]]
		if not BuildModeState.Active then
			return
		end

		render()
	end)
	render()
	BuildModeEnter.MouseButton1Down:Connect(toggleBuildMode)

	if v12 then
		v12.MouseButton1Down:Connect(openPicker)
	end

	if v32 then
		v32.MouseButton1Down:Connect(goBack)
	end

	if v22 then
		v22.MouseButton1Down:Connect(toggleRemoveMode)
	end

	task.spawn(function() --[[ Line: 366 | Upvalues: BuildInBase2 (copy), ownGardenRoot (copy), BuildModeState (ref), isInsideGarden (copy) ]]
		while BuildInBase2.Parent do
			local v1 = ownGardenRoot()

			BuildModeState.SetGarden(v1, if v1 == nil then false else isInsideGarden(v1))
			task.wait(0.25)
		end
	end)
end

return t