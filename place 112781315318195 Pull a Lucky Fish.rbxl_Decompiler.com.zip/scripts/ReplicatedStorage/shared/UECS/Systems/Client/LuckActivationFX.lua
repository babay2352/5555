-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Remotes = require(ReplicatedStorage.shared.Remotes)
local SFX = require(ReplicatedStorage.client.SFX)
local UIVFX = require(ReplicatedStorage.shared.module.UIVFX)
local v1 = Color3.fromRGB(80, 255, 130)

return {
	UECS = nil,
	Init = function(p1) --[[ Init | Line: 19 | Upvalues: Remotes (copy), SFX (copy), UIVFX (copy), v1 (copy) ]]
		Remotes.LuckActivatedFX:On(function(p1) --[[ Line: 20 | Upvalues: SFX (ref), UIVFX (ref), v1 (ref) ]]
			SFX.new(SFX.Sounds.Luck, 0.6)
			UIVFX.Vignette.Start(v1)
			task.delay(1.5, function() --[[ Line: 23 | Upvalues: UIVFX (ref) ]]
				UIVFX.Vignette.Stop()
			end)
		end)
	end
}