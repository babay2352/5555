-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ContentProvider = game:GetService("ContentProvider")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Remotes = require(ReplicatedStorage.shared.Remotes)
local SignalBag = require(ReplicatedStorage.client.SignalBag)
local t = {
	UECS = nil,
	Priority = 100
}
local Handshake = ReplicatedStorage.shared.model:WaitForChild("Handshake")
local Animation = Instance.new("Animation")

Animation.AnimationId = "rbxassetid://104802084955369"

local function createHand() --[[ createHand | Line: 24 | Upvalues: Handshake (copy), Animation (copy) ]]
	local v1 = Handshake:Clone()
	local v2 = Instance.new("NumberValue")

	v2.Value = v1:GetScale()
	v2.Changed:Connect(function(p1) --[[ Line: 29 | Upvalues: v1 (copy) ]]
		v1:ScaleTo(p1)
	end)
	v2.Parent = v1

	local CFrameValue = Instance.new("CFrameValue")

	CFrameValue.Value = CFrame.new()
	CFrameValue.Changed:Connect(function(p1) --[[ Line: 36 | Upvalues: v1 (copy) ]]
		v1:PivotTo(p1)
	end)
	CFrameValue.Parent = v1
	v1.Parent = workspace.CurrentCamera

	local v3 = v1:QueryDescendants("Animator")[1]

	return {
		model = v1,
		scaleValue = v2,
		pivotValue = CFrameValue,
		animTrack = if v3 then v3:LoadAnimation(Animation) else nil
	}
end

local function playHandshakeAnimation(p1) --[[ playHandshakeAnimation | Line: 52 | Upvalues: SignalBag (copy), ContentProvider (copy), Animation (copy), Players (copy), createHand (copy), TweenService (copy) ]]
	SignalBag.PlaySoundByName:Fire("TradeSuccess")
	ContentProvider:PreloadAsync({ Animation })
	print(ContentProvider:GetAssetFetchStatus(Animation.AnimationId))

	local Character = Players.LocalPlayer.Character

	if not Character then
		return
	end

	if p1:IsA("Model") then
		local v1 = Character:GetExtentsSize()
		local v2 = p1:GetExtentsSize()
		local v3 = Character:GetPivot()
		local v4 = p1:GetPivot()
		local Unit = (v4.Position - v3.Position).Unit
		local v5 = createHand()

		v5.scaleValue.Value = 0.01
		v5.pivotValue.Value = CFrame.lookAlong(v3.Position + Vector3.new(0, 1, 0) * (v1.Y * 0.75), -Unit)
		v5.model.Parent = workspace.CurrentCamera

		local v6 = createHand()

		v6.scaleValue.Value = 0.01
		v6.pivotValue.Value = CFrame.lookAlong(v4.Position + Vector3.new(0, 1, 0) * (v2.Y * 0.75), Unit)
		v6.model.Parent = workspace.CurrentCamera

		local v7 = TweenService:Create(v5.scaleValue, TweenInfo.new(1, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
			Value = 1
		})
		local v8 = TweenService:Create(v6.scaleValue, TweenInfo.new(1, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
			Value = 1
		})

		v5.animTrack:Play(0, 100)
		v6.animTrack:Play(0, 100)
		v7:Play()
		v8:Play()
		SignalBag.PlaySoundByName:Fire("HandshakeShow")
		v7.Completed:Wait()

		local Position = v5.pivotValue.Value:Lerp(v6.pivotValue.Value, 0.5).Position
		local v9 = TweenService:Create(v5.pivotValue, TweenInfo.new(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
			Value = CFrame.lookAlong(Position - Unit * Vector3.new(1, 0, 1) * 2, -Unit * Vector3.new(1, 0, 1))
		})
		local v10 = TweenService:Create(v6.pivotValue, TweenInfo.new(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
			Value = CFrame.lookAlong(Position - -Unit * Vector3.new(1, 0, 1) * 2, Unit * Vector3.new(1, 0, 1))
		})

		v9:Play()
		v10:Play()
		SignalBag.PlaySoundByName:Fire("HandshakeFly")
		v5.animTrack:GetMarkerReachedSignal("Handshake"):Once(function() --[[ Line: 125 | Upvalues: SignalBag (ref) ]]
			SignalBag.PlaySoundByName:Fire("Handshake")
		end)

		local v11 = TweenService:Create(v5.scaleValue, TweenInfo.new(0.3, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
			Value = 0.01
		})
		local v12 = TweenService:Create(v6.scaleValue, TweenInfo.new(0.3, Enum.EasingStyle.Cubic, Enum.EasingDirection.Out), {
			Value = 0.01
		})

		v5.animTrack:GetMarkerReachedSignal("Hide"):Wait()
		v11:Play()
		v12:Play()
		v11.Completed:Wait()
		v5.model:Destroy()
		v6.model:Destroy()
		v11:Destroy()
		v12:Destroy()
		v9:Destroy()
		v10:Destroy()
		v7:Destroy()
		v8:Destroy()
	end
end

function t.Init(p1) --[[ Init | Line: 156 | Upvalues: Remotes (copy), playHandshakeAnimation (copy) ]]
	Remotes.PlayTradeFinishedAnimation:Client():On(playHandshakeAnimation)
end

return t