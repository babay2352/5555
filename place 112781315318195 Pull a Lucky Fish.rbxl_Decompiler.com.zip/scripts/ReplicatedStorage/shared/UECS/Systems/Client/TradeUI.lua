-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ContentProvider = game:GetService("ContentProvider")
local ContextActionService = game:GetService("ContextActionService")
local GamepadService = game:GetService("GamepadService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local CashDisplay = require(ReplicatedStorage.shared.module.CashDisplay)
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local ConvertValue = require(ReplicatedStorage.shared.util.ConvertValue)
local CurrenciesConfig = require(ReplicatedStorage.shared.config.CurrenciesConfig)
local FishConfig = require(ReplicatedStorage.shared.config.FishConfig)
local FishEarnings = require(ReplicatedStorage.shared.util.FishEarnings)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local ItemConfigsMap = require(ReplicatedStorage.shared.config.ItemConfigsMap)
local MutationConfig = require(ReplicatedStorage.shared.config.MutationConfig)
local MutationList = require(ReplicatedStorage.shared.util.MutationList)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local SignalBag = require(ReplicatedStorage.client.SignalBag)
local TradeConfig = require(ReplicatedStorage.shared.config.TradeConfig)
local TradeUI = require(ReplicatedStorage.shared.UECS.Components.TradeUI)
local bindToButtonPress = require(ReplicatedStorage.shared.util.bindToButtonPress)
local deepClone = require(ReplicatedStorage.shared.util.deepClone)
local favoriteCount = require(ReplicatedStorage.shared.util.favoriteCount)
local paidCopyCount = require(ReplicatedStorage.shared.util.paidCopyCount)
local tradeLockCount = require(ReplicatedStorage.shared.util.tradeLockCount)
local getDictionaryLength = require(ReplicatedStorage.shared.util.getDictionaryLength)

require(ReplicatedStorage.shared.reflex.serverProfile)

local t = {
	UECS = nil,
	Priority = 30
}
local t2 = {
	sessionId = "",
	tradeCompleteAt = -1,
	paidItemTradingAllowed = false,
	partnerA = {
		approved = false,
		offer = {
			currencyAmounts = {},
			items = {}
		},
		id = Players.LocalPlayer.UserId
	},
	partnerB = {
		id = 0,
		approved = false,
		offer = {
			currencyAmounts = {},
			items = {}
		}
	}
}

table.freeze(t2)

local v1 = deepClone(t2)
local t3 = {
	All = {},
	Offer = {},
	Fish = { "Fish" },
	Lootboxes = { "FloatLootbox", "Luckyblock" },
	Potions = { "MutationJar", "Potion" },
	Misc = { "Food" },
	Currency = { "Currency" }
}
local v2 = "All"
local v3 = ""
local v4 = 0

local function OnTextBoxRelease(p1) --[[ OnTextBoxRelease | Line: 138 | Upvalues: ConvertValue (copy), v4 (ref) ]]
	local Text = p1.Text

	if Text == "" then
		return
	end

	local v1 = ConvertValue.parseSuffix(Text)

	if v1 and v1 > 0 then
		p1.Text = tostring(ConvertValue.suffixformat((math.min(v4, v1))))
	else
		p1.Text = "0"
	end
end

local function EditCurrency(p1, p2) --[[ EditCurrency | Line: 151 | Upvalues: TradeConfig (copy), Players (copy), CurrenciesConfig (copy), v3 (ref), ClientPlayerData (copy), v4 (ref) ]]
	if not TradeConfig.CURRENCY_TRADING_ENABLED then
		return
	end

	local TradeUI = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI").TradeUI
	local v1 = CurrenciesConfig[p1]

	if not v1 then
		return
	end

	local v2 = TradeUI.AdjustCurrencyModal:QueryDescendants("ImageLabel#CurrencyIcon")[1]

	if v2 then
		v2.Image = v1.icon
	end

	v3 = p1
	TradeUI.AdjustCurrencyModal.Visible = true
	v4 = v1.selector((ClientPlayerData.serverProfile:getState())) or 0
	TradeUI.AdjustCurrencyModal.Body.Content.Value.Text = tostring(p2) or "0"
end

local function SetCategory(p1) --[[ SetCategory | Line: 177 | Upvalues: Players (copy), t3 (copy), v2 (ref) ]]
	local TradeUI = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI").TradeUI
	local v1 = p1 == "All"
	local v22 = if p1 == "Offer" then true else false

	for v4, v5 in TradeUI.Content.PlayerOffer:GetChildren() do
		local v3

		if v5:IsA("Frame") then
			if v1 then
				v5.Visible = true

				continue
			end

			if v22 then
				local v6 = v5:QueryDescendants("UIStroke#SelectStroke")[1]

				v5.Visible = if v6 then v6.Enabled else v6

				continue
			end

			local v8 = v5:GetAttribute("category") or ""

			v3 = if typeof(v8) == "string" and v8 ~= "" then table.find(t3[p1], v8) ~= nil else false
			v5.Visible = v3
		end
	end

	for v9, v10 in TradeUI.CategoryPanel:GetChildren() do
		if v10:IsA("ImageButton") then
			local UIStroke = v10:FindFirstChildOfClass("UIStroke")

			if UIStroke then
				local v11 = v10.Name:split("_")[2] == p1

				UIStroke.Color = Color3.fromHex(if v11 then "#ffffff" else "#000000")
				UIStroke.Thickness = if v11 then 2 else 1
			end
		end
	end

	v2 = p1
end

local function SyncCurrencyAmounts(p1, p2, p3) --[[ SyncCurrencyAmounts | Line: 221 | Upvalues: TradeConfig (copy), CurrenciesConfig (copy), Players (copy), ClientPlayerData (copy), ConvertValue (copy), v2 (ref) ]]
	if TradeConfig.CURRENCY_TRADING_ENABLED then
		local TradeUI = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI").TradeUI
		local v1 = ClientPlayerData.serverProfile:getState()

		for v3, v4 in CurrenciesConfig do
			local v22

			if v4.untradeable then
				local v5 = p1:FindFirstChild(v3)

				if v5 then
					v5:Destroy()
				end

				continue
			end

			local v6 = p1:FindFirstChild(v3) or TradeUI.Templates.ItemContainer:Clone()
			local v7 = v4.selector(v1) or 0

			if p3 and not p2[v3] then
				v6:Destroy()

				continue
			end

			if p3 or v7 ~= 0 then
				v6.Name = v3
				v6:SetAttribute("category", "Currency")
				v6.ItemButton.Icon.Image = v4.icon
				v6.ItemButton.LevelLabel.Visible = true
				v6:SetAttribute("amount", v7)
				v22 = if p2[v3] and not p3 then ("x %*/%*"):format(ConvertValue.suffixformat(p2[v3]), (ConvertValue.suffixformat(v7))) elseif p2[v3] and p3 then ("x %*"):format((ConvertValue.suffixformat(p2[v3]))) else ("x %*"):format((ConvertValue.suffixformat(v7)))
				v6.ItemButton.LevelLabel.Text = v22

				if not p3 then
					v6.ItemButton:AddTag("TradeCurrencyAmountPicker")
				end

				v6.Visible = if p3 then p3 elseif v2 == "All" or v2 == "Currency" then true elseif v2 == "Offer" then if p2[v3] == nil then false else true else false
				v6.Parent = p1

				continue
			end

			v6:Destroy()
		end
	else
		for v9 in CurrenciesConfig do
			local v10 = p1:FindFirstChild(v9)

			if v10 then
				v10:Destroy()
			end
		end
	end
end

local function setFavoriteBadge(p1, p2) --[[ setFavoriteBadge | Line: 293 ]]
	local FavoriteIcon = p1:FindFirstChild("FavoriteIcon")

	if not FavoriteIcon then
		if not p2 then
			return
		end

		local FavoriteIcon2 = Instance.new("ImageLabel")

		FavoriteIcon2.Name = "FavoriteIcon"
		FavoriteIcon2.BackgroundTransparency = 1
		FavoriteIcon2.Image = "rbxassetid://131999210320254"
		FavoriteIcon2.Size = UDim2.fromScale(0.3, 0.3)
		FavoriteIcon2.Position = UDim2.new(1, -4, 1, -4)
		FavoriteIcon2.AnchorPoint = Vector2.new(1, 1)
		FavoriteIcon2.ZIndex = 3
		FavoriteIcon2.Parent = p1
		FavoriteIcon = FavoriteIcon2
	end

	if not FavoriteIcon then
		return
	end

	FavoriteIcon.Visible = p2
end

local function setTradeLockBadge(p1, p2) --[[ setTradeLockBadge | Line: 320 ]]
	local TradeLockIcon = p1:FindFirstChild("TradeLockIcon")

	if not TradeLockIcon then
		if not p2 then
			return
		end

		local TradeLockIcon2 = Instance.new("ImageLabel")

		TradeLockIcon2.Name = "TradeLockIcon"
		TradeLockIcon2.BackgroundTransparency = 1
		TradeLockIcon2.Image = "rbxassetid://93026180483226"
		TradeLockIcon2.ScaleType = Enum.ScaleType.Fit
		TradeLockIcon2.Size = UDim2.fromScale(0.7, 0.7)
		TradeLockIcon2.Position = UDim2.fromScale(0.5, 0.5)
		TradeLockIcon2.AnchorPoint = Vector2.new(0.5, 0.5)
		TradeLockIcon2.ZIndex = 4
		TradeLockIcon2.Parent = p1
		TradeLockIcon = TradeLockIcon2
	end

	if not TradeLockIcon then
		return
	end

	TradeLockIcon.Visible = p2
end

local function SyncInventoryFrame(p1, p2, p3) --[[ SyncInventoryFrame | Line: 343 | Upvalues: ClientPlayerData (copy), v1 (ref), Players (copy), CurrenciesConfig (copy), ItemConfigsMap (copy), MutationList (copy), MutationConfig (copy), FishEarnings (copy), FishConfig (copy), CashDisplay (copy), favoriteCount (copy), tradeLockCount (copy), paidCopyCount (copy), setFavoriteBadge (copy), setTradeLockBadge (copy) ]]
	local v12 = ClientPlayerData.serverProfile:getState().favorites or {}
	local v2 = ClientPlayerData.serverProfile:getState().tradeLocks or {}
	local v3 = ClientPlayerData.serverProfile:getState().paidCopies or {}
	local v4 = if v1.paidItemTradingAllowed == true then true else false
	local TradeUI = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI").TradeUI

	for v5, v6 in p1:GetChildren() do
		if v6:IsA("GuiObject") and not (p2[v6.Name] or CurrenciesConfig[v6.Name]) then
			v6:Destroy()
		end
	end

	for v7, v8 in p2 do
		local v9 = ItemConfigsMap.Configs[v8.Category]
		local v10 = if v9 then v9[v8.ConfigName] else v9

		if v10 and not v10.Untradeable then
			local v11 = p1:FindFirstChild(v7) or TradeUI.Templates.ItemContainer:Clone()

			v11.Name = v7
			v11.ItemButton.Icon.Image = v10.Image or v10.Icon

			local v13 = v8.ExtraInfo and v8.ExtraInfo.Level

			v11.ItemButton.LevelLabel.Visible = v13

			if v13 then
				v11.ItemButton.LevelLabel.Text = ("Lv. %*"):format(v13)
			end

			local v14 = v10.Rarity and v10.Rarity.rarityColor

			if v14 then
				v11.ItemButton.BackgroundColor3 = v14
			end

			local v15 = v8.ExtraInfo and v8.ExtraInfo.Mutation
			local v16 = if typeof(v15) == "string" then MutationList.parse(v15) else {}
			local v17 = MutationList.best(v16)

			if v17 then
				v11.ItemButton.MutationIcon.Image = MutationConfig.Mutations[v17].image
				v11.ItemButton.MutationIcon.Visible = true
				v11.ItemButton.MutationIcon.Count.Text = ("+%*"):format(#v16 - 1)
				v11.ItemButton.MutationIcon.Count.Visible = if #v16 > 1 then true else false
			else
				v11.ItemButton.MutationIcon.Visible = false
				v11.ItemButton.MutationIcon.Count.Visible = false
			end

			if not p3 then
				v11.ItemButton:AddTag("TradeSelectable")
			end

			local v19 = if v8.Category == "Fish" and v8.ExtraInfo ~= nil then if v8.ExtraInfo.Untradable == true then true else false else false
			local v20 = if v8.Category == "Fish" and v8.ExtraInfo ~= nil then if v8.ExtraInfo.Paid == true then true else false else false

			if if v8.Category == "Fish" then true else false then
				local v22 = FishEarnings.perFish(Players.LocalPlayer, v8.ConfigName, false, v13 or 1, v15 or "")
				local v23 = FishConfig[v8.ConfigName].EarningsPercent or 0

				CashDisplay.applyToLabel(v11.ItemButton.EarningsLabel, v22, {
					Compact = true,
					Suffix = ("/s%*"):format(if v23 > 0 then (" (%*%%)"):format((math.floor(v23 * 100 + 0.5))) else "")
				})
				v11.ItemButton.EarningsLabel.Visible = true
			else
				v11.ItemButton.EarningsLabel.Visible = false
			end

			v11:SetAttribute("category", v8.Category)
			v11.Visible = true
			v11.Parent = p1

			local v25 = if v8.stackIds then #v8.stackIds elseif v8.Stack then v8.Stack else 1
			local t = {}

			for v26, v27 in p1:GetChildren() do
				if v27:IsA("Frame") and v27.Name == v7 then
					table.insert(t, v27)
				end
			end

			local count = #t

			if count ~= v25 and count < v25 then
				repeat
					v11:Clone().Parent = p1
					count = count + 1
				until count == v25
			elseif count ~= v25 and v25 < count then
				repeat
					t[count]:Destroy()
					table.remove(t, count)
					count = count - 1
				until count == v25
			end

			local count2 = if p3 then 0 else favoriteCount(v12, v7)
			local count3 = if p3 then 0 elseif v19 then (1 / 0) else tradeLockCount(v2, v7)
			local count4 = if p3 or v4 then 0 elseif v20 then (1 / 0) else paidCopyCount(v3, v7)

			for v28, v29 in p1:GetChildren() do
				if v29:IsA("Frame") and v29.Name == v7 then
					local ItemButton = v29:FindFirstChild("ItemButton")

					if ItemButton then
						setFavoriteBadge(ItemButton, if count2 > 0 then true else false)
						count2 = count2 - 1

						local v32 = if count3 > 0 then true else false
						local v33 = false

						if v32 then
							count3 = count3 - 1
						elseif count4 > 0 then
							v33 = true
							count4 = count4 - 1
						end

						setTradeLockBadge(ItemButton, v32 or v33)
						v29:SetAttribute("tradeLocked", v32 or v33)
						v29:SetAttribute("paidLocked", v33)
					end
				end
			end
		end
	end
end

function t.UpdateState(p1, p2) --[[ UpdateState | Line: 505 | Upvalues: v1 (ref), Players (copy), SetCategory (copy), SyncInventoryFrame (copy), SyncCurrencyAmounts (copy) ]]
	local v12 = if v1.paidItemTradingAllowed == true then true else false

	v1 = p2

	if (if p2.paidItemTradingAllowed == true then true else false) ~= v12 then
		p1:PreparePlayerInventory()
	end

	local TradeUI = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI").TradeUI
	local v3 = p1.UECS:WaitForAnyComponent("UIFrameOpener")
	local isUserId = p2.partnerA.id == Players.LocalPlayer.UserId
	local v4 = isUserId and p2.partnerA.offer or p2.partnerB.offer
	local v5 = isUserId and p2.partnerB.offer or p2.partnerA.offer
	local v8 = Players:GetPlayerByUserId(isUserId and p2.partnerB.id or p2.partnerA.id)

	if not v8 then
		v3.OpenedUIComponent:Set(nil)

		return
	end

	local v9 = if isUserId then p2.partnerA.approved else p2.partnerB.approved

	if v9 then
		SetCategory("Offer")
	end

	TradeUI.CategoryPanel.Visible = not v9
	TradeUI.Content.PlayerOffer.ReadyStroke.Enabled = v9
	TradeUI.Content.TheirOffer.ReadyStroke.Enabled = if isUserId then p2.partnerB.approved else p2.partnerA.approved
	TradeUI.Content.TheirReadyLabel.Text = if TradeUI.Content.TheirOffer.ReadyStroke.Enabled then "READY!" else "NOT READY!"
	TradeUI.Content.TheirReadyLabel.TextColor3 = Color3.fromHex(if TradeUI.Content.TheirOffer.ReadyStroke.Enabled then "#12ff05" else "#fc1d1d")
	TradeUI.TopBar.ContentFrame.TextLabel.Text = ("Trade with %*"):format(v8.DisplayName)
	TradeUI.Content.TheirOfferLabel.Text = ("%*\'s offer"):format(v8.DisplayName)
	TradeUI.Content.Approve.Content.Frame.StatusLabel.Text = if v9 then "Unready" else "Ready"
	SyncInventoryFrame(TradeUI.Content.TheirOffer, v5.items, true)
	SyncCurrencyAmounts(TradeUI.Content.TheirOffer, v5.currencyAmounts, true)
	SyncCurrencyAmounts(TradeUI.Content.PlayerOffer, v4.currencyAmounts, false)

	for v14, v15 in TradeUI.Content.PlayerOffer:GetChildren() do
		if v15:IsA("Frame") then
			local v16 = v4.items[v15.Name] or v4.currencyAmounts[v15.Name]

			if v16 then
				if v4.currencyAmounts[v15.Name] or v16.stackIds and table.find(v16.stackIds, v15:GetAttribute("stackId") or 1) then
					v15.ItemButton.SelectStroke.Enabled = true
				end

				continue
			end

			v15.ItemButton.SelectStroke.Enabled = false
		end
	end
end
function t.PreparePlayerInventory(p1) --[[ PreparePlayerInventory | Line: 573 | Upvalues: ClientPlayerData (copy), Players (copy), SyncInventoryFrame (copy) ]]
	local inventory = ClientPlayerData.serverProfile:getState().inventory
	local TradeUI = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI").TradeUI

	SyncInventoryFrame(TradeUI.Content.PlayerOffer, inventory, false)

	local t = {}

	for v1, v2 in TradeUI.Content.PlayerOffer:GetChildren() do
		if v2:IsA("Frame") then
			if not t[v2.Name] then
				t[v2.Name] = 0
			end

			local v3 = v2.Name

			t[v3] = t[v3] + 1
			v2:SetAttribute("stackId", t[v2.Name])
		end
	end
end
function t.PrepareCurrencyAmounts(p1) --[[ PrepareCurrencyAmounts | Line: 593 | Upvalues: Players (copy), v1 (ref), SyncCurrencyAmounts (copy) ]]
	local TradeUI = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI").TradeUI

	SyncCurrencyAmounts(TradeUI.Content.PlayerOffer, v1.partnerA.id == Players.LocalPlayer.UserId and v1.partnerA.offer.currencyAmounts or v1.partnerB.offer.currencyAmounts, false)
end
function t.Init(p1) --[[ Init | Line: 605 | Upvalues: ContentProvider (copy), Players (copy), TradeUI (copy), SetCategory (copy), v1 (ref), Remotes (copy), GamepadService (copy), bindToButtonPress (copy), t (copy), ContextActionService (copy), getDictionaryLength (copy), t2 (copy), CollectionService (copy), SignalBag (copy), EditCurrency (copy), ClientPlayerData (copy), RunService (copy), t3 (copy), TradeConfig (copy), CurrenciesConfig (copy), v3 (ref), ConvertValue (copy), v4 (ref) ]]
	task.spawn(function() --[[ Line: 610 | Upvalues: ContentProvider (ref) ]]
		pcall(function() --[[ Line: 611 | Upvalues: ContentProvider (ref) ]]
			ContentProvider:PreloadAsync({ "rbxassetid://93026180483226", "rbxassetid://131999210320254" })
		end)
	end)

	local MainUI = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI")
	local TradeUI2 = MainUI.TradeUI
	local v12 = TradeUI.Add(TradeUI2)
	local v2 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

	v12.Visible.OnChange:Connect(function(p1, p2) --[[ Line: 623 | Upvalues: TradeUI2 (copy), SetCategory (ref), MainUI (copy), v1 (ref), Remotes (ref), GamepadService (ref), bindToButtonPress (ref), t (ref), ContextActionService (ref) ]]
		TradeUI2.Visible = p1

		if p1 and p1 ~= p2 then
			SetCategory("All")
		end

		local HUD = MainUI:FindFirstChild("HUD")

		if HUD then
			HUD.Visible = not p1
		end

		if not p1 and v1.sessionId ~= "" then
			Remotes.TradeStateUpdate:Call({
				command = "CANCEL_TRADE",
				sessionId = v1.sessionId
			})
		end

		if p1 then
			GamepadService:EnableGamepadCursor(TradeUI2)
		else
			GamepadService:DisableGamepadCursor()
		end

		if p1 == p2 then
			return
		end

		if p1 then
			bindToButtonPress("TradeReadyToggle", Enum.KeyCode.ButtonX, function() --[[ Line: 649 | Upvalues: v1 (ref), Remotes (ref), t (ref) ]]
				if v1.sessionId == "" then
					return
				end

				local v12, v2 = Remotes.TradeStateUpdate:Call({
					command = "TOGGLE_APPROVAL",
					sessionId = v1.sessionId
				}):Await()

				if not v12 or (not v2 or typeof(v2) ~= "table") then
					return
				end

				t:UpdateState(v2)
			end)
			bindToButtonPress("TradeBackAction", Enum.KeyCode.ButtonB, function() --[[ Line: 664 | Upvalues: TradeUI2 (ref), v1 (ref), Remotes (ref), t (ref) ]]
				if TradeUI2.AdjustCurrencyModal.Visible then
					TradeUI2.AdjustCurrencyModal.Visible = false

					return
				end

				if v1.sessionId == "" then
					return
				end

				local v12, v2 = Remotes.TradeStateUpdate:Call({
					command = "CANCEL_TRADE",
					sessionId = v1.sessionId
				}):Await()

				if not v12 or (not v2 or typeof(v2) ~= "table") then
					return
				end

				t:UpdateState(v2)
			end)

			return
		end

		ContextActionService:UnbindAction("TradeBackAction")
		ContextActionService:UnbindAction("TradeReadyToggle")
	end)
	GamepadService:GetPropertyChangedSignal("GamepadCursorEnabled"):Connect(function() --[[ Line: 690 | Upvalues: v12 (copy), GamepadService (ref), TradeUI2 (copy) ]]
		if not v12.Visible:Get() or GamepadService.GamepadCursorEnabled then
			return
		end

		GamepadService:EnableGamepadCursor(TradeUI2)
	end)
	Remotes.TradeStateReplicate:Client():On(function(p1) --[[ Line: 696 | Upvalues: getDictionaryLength (ref), v2 (copy), t (ref), t2 (ref), v12 (copy) ]]
		if typeof(p1) == "table" and getDictionaryLength(p1) ~= 0 then
			t:UpdateState(p1)
			v2.OpenedUIComponent:Set(v12)
		else
			v2.OpenedUIComponent:Set(nil)
			t:UpdateState(t2)
		end
	end)
	CollectionService:GetInstanceAddedSignal("TradeSelectable"):Connect(function(p1) --[[ Line: 707 | Upvalues: SignalBag (ref), Remotes (ref), v1 (ref), t (ref) ]]
		if not p1:IsA("TextButton") then
			return
		end

		p1.Activated:Connect(function() --[[ Line: 709 | Upvalues: p1 (copy), SignalBag (ref), Remotes (ref), v1 (ref), t (ref) ]]
			if p1.Parent:GetAttribute("paidLocked") == true then
				SignalBag.Notification:Fire("Items bought with Robux can\'t be traded in this trade.")

				return
			end

			if p1.Parent:GetAttribute("tradeLocked") == true then
				return
			end

			local v12, v2 = Remotes.TradeStateUpdate:Call({
				command = "ITEM_TOGGLE",
				sessionId = v1.sessionId,
				itemId = p1.Parent.Name,
				stackId = p1.Parent:GetAttribute("stackId") or 1
			}):Await()

			if not v12 or (not v2 or typeof(v2) ~= "table") then
				return
			end

			t:UpdateState(v2)
		end)
	end)
	CollectionService:GetInstanceAddedSignal("TradeCurrencyAmountPicker"):Connect(function(p1) --[[ Line: 737 | Upvalues: v1 (ref), Players (ref), EditCurrency (ref) ]]
		if not p1:IsA("TextButton") then
			return
		end

		p1.Activated:Connect(function() --[[ Line: 739 | Upvalues: v1 (ref), Players (ref), p1 (copy), EditCurrency (ref) ]]
			local isUserId = v1.partnerA.id == Players.LocalPlayer.UserId

			if if isUserId then v1.partnerA.approved else v1.partnerB.approved then
				return
			end

			EditCurrency(p1.Parent.Name, if isUserId then v1.partnerA.offer.currencyAmounts[p1.Parent.Name] or 0 else v1.partnerB.offer.currencyAmounts[p1.Parent.Name] or 0)
		end)
	end)
	t:PreparePlayerInventory()
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 759 ]]
		return p1.inventory
	end, function() --[[ Line: 761 | Upvalues: t (ref) ]]
		t:PreparePlayerInventory()
	end)
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 765 ]]
		return p1.favorites
	end, function() --[[ Line: 767 | Upvalues: t (ref) ]]
		t:PreparePlayerInventory()
	end)
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 773 ]]
		return p1.tradeLocks
	end, function() --[[ Line: 775 | Upvalues: t (ref) ]]
		t:PreparePlayerInventory()
	end)
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 781 ]]
		return p1.paidCopies
	end, function() --[[ Line: 783 | Upvalues: t (ref) ]]
		t:PreparePlayerInventory()
	end)
	TradeUI2.Content.Decline.Activated:Connect(function() --[[ Line: 787 | Upvalues: Remotes (ref), v1 (ref), t (ref) ]]
		local v12, v2 = Remotes.TradeStateUpdate:Call({
			command = "CANCEL_TRADE",
			sessionId = v1.sessionId
		}):Await()

		if not v12 or (not v2 or typeof(v2) ~= "table") then
			return
		end

		t:UpdateState(v2)
	end)
	TradeUI2.Content.Approve.Activated:Connect(function() --[[ Line: 800 | Upvalues: Remotes (ref), v1 (ref), t (ref) ]]
		local v12, v2 = Remotes.TradeStateUpdate:Call({
			command = "TOGGLE_APPROVAL",
			sessionId = v1.sessionId
		}):Await()

		if not v12 or (not v2 or typeof(v2) ~= "table") then
			return
		end

		t:UpdateState(v2)
	end)
	RunService:BindToRenderStep("TradeButtonUpdate", Enum.RenderPriority.Last.Value, function() --[[ Line: 813 | Upvalues: TradeUI2 (copy), v1 (ref), Players (ref) ]]
		if not TradeUI2.Visible then
			return
		end

		local v12 = if v1.partnerA.id == Players.LocalPlayer.UserId then v1.partnerA.approved else v1.partnerB.approved
		local tradeCompleteAt = v1.tradeCompleteAt

		if tradeCompleteAt < 0 then
			TradeUI2.Content.Approve.Content.Frame.StatusLabel.Text = if v12 then "Unready" else "Ready"
		else
			TradeUI2.Content.Approve.Content.Frame.StatusLabel.Text = v12 and ("Unready (%* s)"):format((math.max(0, (math.round(tradeCompleteAt - workspace:GetServerTimeNow()))))) or "Ready"
		end
	end)

	for v32, v42 in TradeUI2.CategoryPanel:GetChildren() do
		if v42:IsA("ImageButton") then
			v42.Activated:Connect(function() --[[ Line: 835 | Upvalues: v42 (copy), t3 (ref), SetCategory (ref) ]]
				local v1 = v42.Name:split("_")[2]

				if not t3[v1] then
					return
				end

				SetCategory(v1)
			end)
		end
	end

	SetCategory("All")

	if not TradeConfig.CURRENCY_TRADING_ENABLED then
		local Btn_Currency = TradeUI2.CategoryPanel:FindFirstChild("Btn_Currency")

		if Btn_Currency and Btn_Currency:IsA("GuiObject") then
			Btn_Currency.Visible = false
		end

		TradeUI2.AdjustCurrencyModal.Visible = false
	end

	t:PrepareCurrencyAmounts()

	for v5, v6 in CurrenciesConfig do
		if not v6.untradeable and TradeConfig.CURRENCY_TRADING_ENABLED then
			ClientPlayerData.serverProfile:subscribe(v6.selector, function() --[[ Line: 865 | Upvalues: t (ref) ]]
				t:PrepareCurrencyAmounts()
			end)
		end
	end

	local v7 = TradeUI2.AdjustCurrencyModal.Body.Content
	local v8 = v7.Value
	local Buttons = v7.Buttons

	local function setCurrency(p1) --[[ setCurrency | Line: 873 | Upvalues: TradeUI2 (copy), Remotes (ref), v1 (ref), v3 (ref), t (ref) ]]
		TradeUI2.AdjustCurrencyModal.Visible = false

		local v12, v2 = Remotes.TradeStateUpdate:Call({
			command = "CURRENCY_ADJUST",
			sessionId = v1.sessionId,
			currencyId = v3,
			amount = p1
		}):Await()

		if not v12 or (not v2 or typeof(v2) ~= "table") then
			return
		end

		t:UpdateState(v2)
	end

	TradeUI2.AdjustCurrencyModal.Body.TopBar.CloseButton.Activated:Connect(function() --[[ Line: 889 | Upvalues: TradeUI2 (copy) ]]
		TradeUI2.AdjustCurrencyModal.Visible = false
	end)
	Buttons.Set.Activated:Connect(function() --[[ Line: 893 | Upvalues: v8 (copy), ConvertValue (ref), v4 (ref), setCurrency (copy), SignalBag (ref) ]]
		local Text = v8.Text

		if Text == "" then
			return
		end

		local v1 = ConvertValue.parseSuffix(Text)

		if not v1 then
			SignalBag.Notification:Fire("Invalid value!")

			return
		end

		if math.clamp(v1, 0, v4) == v1 then
			setCurrency(v1)
		else
			SignalBag.Notification:Fire("Invalid value!")
		end
	end)
	Buttons.Max.Activated:Connect(function() --[[ Line: 906 | Upvalues: setCurrency (copy), v4 (ref) ]]
		setCurrency(v4)
	end)
	Buttons.Clear.Activated:Connect(function() --[[ Line: 910 | Upvalues: setCurrency (copy) ]]
		setCurrency(0)
	end)
	v8.FocusLost:Connect(function() --[[ Line: 914 | Upvalues: v8 (copy), ConvertValue (ref), v4 (ref) ]]
		local v1 = v8
		local Text = v1.Text

		if Text == "" then
			return
		end

		local v2 = ConvertValue.parseSuffix(Text)

		if v2 and v2 > 0 then
			v1.Text = tostring(ConvertValue.suffixformat((math.min(v4, v2))))
		else
			v1.Text = "0"
		end
	end)
end

return t