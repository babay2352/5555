-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ContextActionService = game:GetService("ContextActionService")
local GuiService = game:GetService("GuiService")
local MarketplaceService = game:GetService("MarketplaceService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local StarterPlayer = game:GetService("StarterPlayer")
local UserInputService = game:GetService("UserInputService")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local LuckyblockDropReel = require(ReplicatedStorage.shared.module.LuckyblockDropReel)
local MonetizationConfig = require(ReplicatedStorage.shared.config.MonetizationConfig)
local MountConfig = require(ReplicatedStorage.shared.config.MountConfig)
local MountsUI = require(ReplicatedStorage.shared.UECS.Components.MountsUI)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local bindToButtonPress = require(ReplicatedStorage.shared.util.bindToButtonPress)
local fetchRobuxPriceInto = require(ReplicatedStorage.shared.util.fetchRobuxPriceInto)
local getLocalPolicyInfo = require(ReplicatedStorage.shared.util.getLocalPolicyInfo)
local mountState = require(ReplicatedStorage.shared.util.mountState)
local t = {
	UECS = nil
}
local t2 = {
	LuckyblockConfigName = "Mount_Luckyblock",
	CardName = "MountLuckyblock",
	PityCap = 20,
	EquipText = "Equip",
	UnequipText = "Unequip"
}
local t3 = {
	Buy1 = MonetizationConfig.DevProducts.MountLuckyblockBuy1,
	Buy3 = MonetizationConfig.DevProducts.MountLuckyblockBuy3,
	Buy8 = MonetizationConfig.DevProducts.MountLuckyblockBuy8
}
local t4 = {
	Buy1 = 1,
	Buy3 = 2,
	Buy8 = 3
}

local function tagButton(p1) --[[ tagButton | Line: 91 | Upvalues: CollectionService (copy) ]]
	CollectionService:AddTag(p1, "VFX_ClickBounce")
	CollectionService:AddTag(p1, "VFX_UIClickButton")
end

local function boostText(p1) --[[ boostText | Line: 99 | Upvalues: StarterPlayer (copy) ]]
	local CharacterWalkSpeed = StarterPlayer.CharacterWalkSpeed

	if CharacterWalkSpeed <= 0 then
		CharacterWalkSpeed = 16
	end

	return ("+%*%% speed"):format((math.max(math.round((p1 / CharacterWalkSpeed - 1) * 100), 0)))
end

local function ownedMountConfigs() --[[ ownedMountConfigs | Line: 112 | Upvalues: ClientPlayerData (copy), MountConfig (copy) ]]
	local t = {}

	for v2, v3 in ClientPlayerData.serverProfile:getState().inventory or {} do
		if v3.Category == "Mount" and not ((v3.Stack or 0) <= 0) then
			local v4 = MountConfig[v3.ConfigName]

			if v4 then
				t[v3.ConfigName] = v4
			end
		end
	end

	return t
end

function t.Init(p1) --[[ Init | Line: 127 | Upvalues: ClientPlayerData (copy), Players (copy), MountsUI (copy), CollectionService (copy), mountState (copy), getLocalPolicyInfo (copy), LuckyblockDropReel (copy), UserInputService (copy), GuiService (copy), ownedMountConfigs (copy), StarterPlayer (copy), Remotes (copy), t2 (copy), bindToButtonPress (copy), ContextActionService (copy), t3 (copy), t4 (copy), MarketplaceService (copy), fetchRobuxPriceInto (copy) ]]
	repeat
		task.wait()
	until ClientPlayerData.isPlayerDataLoaded

	local LocalPlayer = Players.LocalPlayer
	local Mounts = LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("MainUI"):WaitForChild("Mounts")

	Mounts.Visible = false

	local TopBar = Mounts:WaitForChild("TopBar")
	local CloseButton = TopBar:WaitForChild("CloseButton")
	local v1 = Mounts:WaitForChild("Content")
	local ScrollingFrame = v1:WaitForChild("ScrollingFrame")
	local MountTemplate = ScrollingFrame:WaitForChild("MountTemplate")

	MountTemplate.Visible = false
	MountTemplate.Selectable = false

	local Blank = ScrollingFrame:FindFirstChild("Blank")

	if Blank then
		Blank.Selectable = false
	end

	local IfEmptyDisplayBuyMount = v1:FindFirstChild("IfEmptyDisplayBuyMount")
	local v2 = MountsUI.Add(Mounts)

	local function close() --[[ close | Line: 164 | Upvalues: p1 (copy) ]]
		p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
	end

	CollectionService:AddTag(CloseButton, "VFX_ClickBounce")
	CollectionService:AddTag(CloseButton, "VFX_UIClickButton")
	CloseButton.MouseButton1Click:Connect(close)

	local t = {}

	local function refreshEquipButtons() --[[ refreshEquipButtons | Line: 177 | Upvalues: LocalPlayer (copy), mountState (ref), t (copy) ]]
		local v1 = LocalPlayer:GetAttribute(mountState.Attribute)

		for v2, v3 in t do
			local Price = v3:FindFirstChild("Price", true)

			if Price then
				Price.Text = if v1 == v2 then "Unequip" else "Equip"
			end
		end
	end

	local v3 = nil
	local ArePaidRandomItemsRestricted = getLocalPolicyInfo().ArePaidRandomItemsRestricted

	local function refreshReel() --[[ refreshReel | Line: 197 | Upvalues: Mounts (copy), ArePaidRandomItemsRestricted (copy), IfEmptyDisplayBuyMount (copy), v3 (ref), LuckyblockDropReel (ref) ]]
		local v1 = Mounts.Visible and (not ArePaidRandomItemsRestricted and (if IfEmptyDisplayBuyMount == nil then false else IfEmptyDisplayBuyMount.Visible))

		if v1 and not v3 then
			v3 = LuckyblockDropReel.start(IfEmptyDisplayBuyMount, "MountLuckyblock", "Mount_Luckyblock")

			return
		end

		if v1 or not v3 then
			return
		end

		v3:Destroy()
		v3 = nil
	end

	local function refocus() --[[ refocus | Line: 216 | Upvalues: v2 (copy), UserInputService (ref), ScrollingFrame (copy), IfEmptyDisplayBuyMount (copy), GuiService (ref) ]]
		if not v2.Visible:Get() or UserInputService.PreferredInput ~= Enum.PreferredInput.Gamepad then
			return
		end

		local v1 = if ScrollingFrame.Visible then ScrollingFrame else IfEmptyDisplayBuyMount

		if not v1 then
			return
		end

		GuiService:Select(v1)
	end

	local function rebuildTiles() --[[ rebuildTiles | Line: 226 | Upvalues: ownedMountConfigs (ref), t (copy), MountTemplate (copy), StarterPlayer (ref), CollectionService (ref), Remotes (ref), ScrollingFrame (copy), IfEmptyDisplayBuyMount (copy), refreshEquipButtons (copy), Mounts (copy), ArePaidRandomItemsRestricted (copy), v3 (ref), LuckyblockDropReel (ref), t2 (ref), v2 (copy), UserInputService (ref), GuiService (ref) ]]
		local v1 = ownedMountConfigs()

		for v22, v32 in t do
			if not v1[v22] then
				v32:Destroy()
				t[v22] = nil
			end
		end

		local t3 = {}

		for v4, v5 in v1 do
			table.insert(t3, v5)
		end

		table.sort(t3, function(p1, p2) --[[ Line: 242 ]]
			local v1 = p1.Rarity and p1.Rarity.power or 0
			local v2 = p2.Rarity and p2.Rarity.power or 0

			if v1 == v2 then
				return p1.DisplayName < p2.DisplayName
			end

			return v2 < v1
		end)

		for v6, v7 in t3 do
			local v8 = t[v7.ConfigName]

			if not v8 then
				local v9 = MountTemplate:Clone()

				v9.Name = v7.ConfigName

				local MountName = v9:FindFirstChild("MountName")

				if MountName then
					MountName.Text = v7.DisplayName
				end

				local ImageFrame = v9:FindFirstChild("ImageFrame")
				local v10 = if ImageFrame then ImageFrame:FindFirstChild("ImageLabel") else ImageFrame

				if v10 then
					v10.Image = v7.Icon
				end

				local Boost = v9:FindFirstChild("Boost")

				if Boost then
					local CharacterWalkSpeed = StarterPlayer.CharacterWalkSpeed

					if CharacterWalkSpeed <= 0 then
						CharacterWalkSpeed = 16
					end

					Boost.Text = ("+%*%% speed"):format((math.max(math.round((v7.WalkSpeed / CharacterWalkSpeed - 1) * 100), 0)))
				end

				v8 = v9

				local EquipButton = v9:FindFirstChild("EquipButton")

				if EquipButton then
					CollectionService:AddTag(EquipButton, "VFX_ClickBounce")
					CollectionService:AddTag(EquipButton, "VFX_UIClickButton")
					EquipButton.Selectable = true
					EquipButton.Activated:Connect(function() --[[ Line: 277 | Upvalues: Remotes (ref), v7 (copy) ]]
						Remotes.RequestEquipMount:Fire(v7.ConfigName)
					end)
				end

				v9.Visible = true
				v9.Parent = ScrollingFrame
				t[v7.ConfigName] = v9
			end

			v8.LayoutOrder = v6

			local EquipButton = v8:FindFirstChild("EquipButton")

			if EquipButton then
				EquipButton.SelectionOrder = v6
			end
		end

		local v12 = next(v1) ~= nil

		ScrollingFrame.Visible = v12

		if IfEmptyDisplayBuyMount then
			IfEmptyDisplayBuyMount.Visible = not v12
		end

		refreshEquipButtons()

		local v13 = Mounts.Visible and not ArePaidRandomItemsRestricted and (if IfEmptyDisplayBuyMount == nil then false else IfEmptyDisplayBuyMount.Visible)

		if v13 and not v3 then
			v3 = LuckyblockDropReel.start(IfEmptyDisplayBuyMount, t2.CardName, t2.LuckyblockConfigName)
		elseif not v13 and v3 then
			v3:Destroy()
			v3 = nil
		end

		if not v2.Visible:Get() then
			return
		end

		if UserInputService.PreferredInput ~= Enum.PreferredInput.Gamepad then
			return
		end

		local v14 = if ScrollingFrame.Visible then ScrollingFrame else IfEmptyDisplayBuyMount

		if not v14 then
			return
		end

		GuiService:Select(v14)
	end

	rebuildTiles()
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 306 ]]
		return p1.inventory
	end, rebuildTiles)
	LocalPlayer:GetAttributeChangedSignal(mountState.Attribute):Connect(refreshEquipButtons)
	v2.Visible.OnChange:Connect(function(p1, p2) --[[ Line: 311 | Upvalues: Mounts (copy), ArePaidRandomItemsRestricted (copy), IfEmptyDisplayBuyMount (copy), v3 (ref), LuckyblockDropReel (ref), t2 (ref), bindToButtonPress (ref), close (copy), v2 (copy), UserInputService (ref), ScrollingFrame (copy), GuiService (ref), ContextActionService (ref) ]]
		Mounts.Visible = p1

		local v1 = Mounts.Visible and not ArePaidRandomItemsRestricted and (if IfEmptyDisplayBuyMount == nil then false else IfEmptyDisplayBuyMount.Visible)

		if v1 and not v3 then
			v3 = LuckyblockDropReel.start(IfEmptyDisplayBuyMount, t2.CardName, t2.LuckyblockConfigName)
		elseif not v1 and v3 then
			v3:Destroy()
			v3 = nil
		end

		if p1 == p2 then
			return
		end

		if p1 then
			bindToButtonPress("MountsClose", Enum.KeyCode.ButtonB, close)

			if not v2.Visible:Get() then
				return
			end

			if UserInputService.PreferredInput ~= Enum.PreferredInput.Gamepad then
				return
			end

			local v22 = if ScrollingFrame.Visible then ScrollingFrame else IfEmptyDisplayBuyMount

			if v22 then
				GuiService:Select(v22)
			end
		else
			ContextActionService:UnbindAction("MountsClose")

			local SelectedObject = GuiService.SelectedObject

			if not (SelectedObject and SelectedObject:IsDescendantOf(Mounts)) then
				return
			end

			GuiService.SelectedObject = nil
		end
	end)
	GuiService:GetPropertyChangedSignal("SelectedObject"):Connect(function() --[[ Line: 334 | Upvalues: v2 (copy), GuiService (ref), Mounts (copy), refocus (copy) ]]
		if not v2.Visible:Get() then
			return
		end

		local SelectedObject = GuiService.SelectedObject

		if SelectedObject and SelectedObject:IsDescendantOf(Mounts) then
			return
		end

		task.defer(refocus)
	end)

	local Shop = TopBar:FindFirstChild("Shop", true)

	if Shop then
		CollectionService:AddTag(Shop, "VFX_ClickBounce")
		CollectionService:AddTag(Shop, "VFX_UIClickButton")
		Shop.Activated:Connect(function() --[[ Line: 351 | Upvalues: p1 (copy) ]]
			p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(p1.UECS:WaitForAnyComponent("Store"))
		end)
	end

	if IfEmptyDisplayBuyMount then
		local MountLuckyblock = IfEmptyDisplayBuyMount:FindFirstChild("MountLuckyblock")
		local v4 = if MountLuckyblock then MountLuckyblock:FindFirstChild("Content") else MountLuckyblock

		if not v4 then
			warn("[MountsUI] IfEmptyDisplayBuyMount has no MountLuckyblock.Content \226\128\148 buy card left unwired")
		elseif ArePaidRandomItemsRestricted then
			if MountLuckyblock and MountLuckyblock:IsA("GuiObject") then
				MountLuckyblock.Visible = false
			end
		else
			for v5, v6 in t3 do
				local v7 = v4:FindFirstChild(v5)

				if v7 then
					CollectionService:AddTag(v7, "VFX_ClickBounce")
					CollectionService:AddTag(v7, "VFX_UIClickButton")
					v7.Selectable = true
					v7.SelectionOrder = t4[v5] or 0

					local ProductId = v6.ProductId

					v7.Activated:Connect(function() --[[ Line: 388 | Upvalues: MarketplaceService (ref), LocalPlayer (copy), ProductId (copy) ]]
						MarketplaceService:PromptProductPurchase(LocalPlayer, ProductId)
					end)

					local v8 = v7:FindFirstChild("Content")
					local v9 = if v8 then v8:FindFirstChild("TextLabel") else v8

					if v9 then
						fetchRobuxPriceInto(v9, ProductId, Enum.InfoType.Product)
					end

					continue
				end

				warn((("[MountsUI] MountLuckyblock.Content has no \"%*\" button"):format(v5)))
			end

			local PityLabel = v4:FindFirstChild("PityLabel", true)
			local PityBar = v4:FindFirstChild("PityBar", true)
			local v10 = PityBar and PityBar:FindFirstChild("Fill", true)

			local function updatePity() --[[ updatePity | Line: 403 | Upvalues: ClientPlayerData (ref), PityLabel (copy), v10 (copy) ]]
				local v1 = ClientPlayerData.serverProfile:getState()
				local v2 = if v1.luckyblockPity then v1.luckyblockPity.Mount_Luckyblock or 0 else 0

				if PityLabel then
					PityLabel.Text = ("%*/%*"):format(v2, 20)
				end

				if not v10 then
					return
				end

				v10.Size = UDim2.fromScale(math.clamp(v2 / 20, 0, 1), 1)
			end

			local v11 = ClientPlayerData.serverProfile:getState()
			local v12 = if v11.luckyblockPity then v11.luckyblockPity[t2.LuckyblockConfigName] or 0 else 0

			if PityLabel then
				PityLabel.Text = ("%*/%*"):format(v12, t2.PityCap)
			end

			if v10 then
				local fromScale = UDim2.fromScale

				v10.Size = fromScale(math.clamp(v12 / t2.PityCap, 0, 1), 1)
			end

			ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 415 ]]
				return p1.luckyblockPity
			end, updatePity)
		end
	end
end

return t