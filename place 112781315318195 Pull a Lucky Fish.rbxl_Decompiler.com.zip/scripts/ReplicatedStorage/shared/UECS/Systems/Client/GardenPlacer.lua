-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ContextActionService = game:GetService("ContextActionService")
local GuiService = game:GetService("GuiService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local UserInputService = game:GetService("UserInputService")
local BuildModeState = require(ReplicatedStorage.client.BuildModeState)
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local GardenConfig = require(ReplicatedStorage.shared.config.GardenConfig)
local GardenGridVisual = require(ReplicatedStorage.client.GardenGridVisual)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Remotes = require(ReplicatedStorage.shared.Remotes)
local SFX = require(ReplicatedStorage.client.SFX)
local VaultConfig = require(ReplicatedStorage.shared.config.VaultConfig)
local bindToButtonPress = require(ReplicatedStorage.shared.util.bindToButtonPress)
local decorationSeatPoint = require(ReplicatedStorage.shared.util.decorationSeatPoint)
local gardenGrid = require(ReplicatedStorage.shared.util.gardenGrid)
local notifications = require(ReplicatedStorage.shared.module.notifications)
local resolveDecorationModel = require(ReplicatedStorage.shared.util.resolveDecorationModel)
local v1 = Color3.fromRGB(90, 255, 120)
local v2 = Color3.fromRGB(255, 90, 90)
local t = {
	name = "GardenPlacementGrid",
	width = 0.1,
	transparency = 0.6
}

return {
	UECS = nil,
	Init = function(p1) --[[ Init | Line: 40 | Upvalues: Players (copy), BuildModeState (copy), resolveDecorationModel (copy), gardenGrid (copy), GardenConfig (copy), CollectionService (copy), ClientPlayerData (copy), GardenGridVisual (copy), t (copy), v1 (copy), v2 (copy), VaultConfig (copy), decorationSeatPoint (copy), UserInputService (copy), notifications (copy), Remotes (copy), SFX (copy), ContextActionService (copy), bindToButtonPress (copy), RunService (copy), GuiService (copy) ]]
		local PlayerGui = Players.LocalPlayer:WaitForChild("PlayerGui")
		local v12 = nil
		local v22 = nil
		local v3 = nil
		local v4 = nil
		local v5 = false
		local v6 = nil
		local v7 = nil
		local v8 = 0
		local v9 = 0
		local v10 = 0
		local v11 = false
		local v122 = 0
		local v13 = 0

		local function isPlacing() --[[ isPlacing | Line: 58 | Upvalues: BuildModeState (ref), v12 (ref) ]]
			return BuildModeState.Active and (if BuildModeState.Mode == "Build" and BuildModeState.SelectedConfigName ~= nil then v12 ~= nil else false)
		end

		local function isRemoving() --[[ isRemoving | Line: 65 | Upvalues: BuildModeState (ref) ]]
			return BuildModeState.Active and BuildModeState.Mode == "Remove"
		end

		local function destroyPreview() --[[ destroyPreview | Line: 69 | Upvalues: v12 (ref), v22 (ref), v3 (ref), v4 (ref), v5 (ref), v11 (ref) ]]
			if not v12 then
				v12 = nil
				v22 = nil
				v3 = nil
				v4 = nil
				v5 = false
				v11 = false

				return
			end

			v12:Destroy()
			v12 = nil
			v22 = nil
			v3 = nil
			v4 = nil
			v5 = false
			v11 = false
		end

		local function setPreviewShown(p1) --[[ setPreviewShown | Line: 81 | Upvalues: v5 (ref), v12 (ref) ]]
			if v5 == p1 or not v12 then
				return
			end

			v5 = p1
			v12.Parent = if p1 then workspace else nil
		end

		local function buildPreview(p1) --[[ buildPreview | Line: 89 | Upvalues: v12 (ref), v22 (ref), v3 (ref), v4 (ref), v5 (ref), v11 (ref), resolveDecorationModel (ref), gardenGrid (ref), GardenConfig (ref), CollectionService (ref), v8 (ref), v122 (ref), v13 (ref) ]]
			if v12 then
				v12:Destroy()
			end

			v12 = nil
			v22 = nil
			v3 = nil
			v4 = nil
			v5 = false
			v11 = false

			local v1 = resolveDecorationModel(p1)

			if not v1 then
				return
			end

			local GardenPlacementPreview = v1:Clone()

			GardenPlacementPreview.Name = "GardenPlacementPreview"

			for v2, v32 in GardenPlacementPreview:GetDescendants() do
				if v32:IsA("BasePart") then
					v32.Anchored = true
					v32.CanCollide = false
					v32.CanQuery = false
					v32.CanTouch = false
					v32.Massless = true
				end
			end

			local GardenPlacerHighlight = Instance.new("Highlight")

			GardenPlacerHighlight.Name = "GardenPlacerHighlight"
			GardenPlacerHighlight.DepthMode = Enum.HighlightDepthMode.Occluded
			GardenPlacerHighlight.FillTransparency = 0.65
			GardenPlacerHighlight.OutlineTransparency = 0
			GardenPlacerHighlight.Adornee = GardenPlacementPreview
			GardenPlacerHighlight.Parent = GardenPlacementPreview

			local v42, v52 = gardenGrid.footprint(p1, 0)
			local GardenPlacerFootprint = Instance.new("Part")

			GardenPlacerFootprint.Name = "GardenPlacerFootprint"
			GardenPlacerFootprint.Anchored = true
			GardenPlacerFootprint.CanCollide = false
			GardenPlacerFootprint.CanQuery = false
			GardenPlacerFootprint.CanTouch = false
			GardenPlacerFootprint.Massless = true
			GardenPlacerFootprint.Material = Enum.Material.Neon
			GardenPlacerFootprint.Transparency = 0.55
			GardenPlacerFootprint.Size = Vector3.new(v42 * GardenConfig.CellSize - 0.15, 0.12, v52 * GardenConfig.CellSize - 0.15)
			GardenPlacerFootprint.CFrame = GardenPlacementPreview:GetPivot() * CFrame.new(0, 0.1, 0)
			CollectionService:AddTag(GardenPlacerFootprint, GardenConfig.IgnoreBoundsTag)
			GardenPlacerFootprint.Parent = GardenPlacementPreview
			v12 = GardenPlacementPreview
			v22 = GardenPlacerHighlight
			v3 = GardenPlacerFootprint
			v4 = p1
			v5 = false
			v8 = 0
			v11 = false
			v122 = 0
			v13 = 0
		end

		local function groundTopLocalY(p1) --[[ groundTopLocalY | Line: 152 | Upvalues: GardenConfig (ref) ]]
			local v1 = p1:FindFirstChild(GardenConfig.BodyName)

			if v1 and v1:IsA("BasePart") then
				return p1:GetPivot():PointToObjectSpace((Vector3.new(0, v1.Position.Y + v1.Size.Y * 0.5, 0))).Y
			end

			return 0
		end

		local v14 = nil
		local v15 = nil

		local function updateGrid() --[[ updateGrid | Line: 168 | Upvalues: BuildModeState (ref), v14 (ref), v15 (ref), ClientPlayerData (ref), GardenConfig (ref), gardenGrid (ref), GardenGridVisual (ref), groundTopLocalY (copy), t (ref) ]]
			local GardenRoot = BuildModeState.GardenRoot

			if BuildModeState.Active and (BuildModeState.InGarden and GardenRoot) then
				local garden = ClientPlayerData.serverProfile:getState().garden
				local v1 = ("%*|%*"):format(GardenRoot:GetFullName(), (GardenConfig.ShapeKey(garden)))

				if v14 and (v14.Parent and v1 == v15) then
					return
				end

				if v14 then
					v14:Destroy()
					v14 = nil
				end

				v15 = nil

				local v3 = gardenGrid.boundsFromGround(GardenRoot, if garden then garden.upgrades else garden)

				if v3 then
					v14 = GardenGridVisual.draw(GardenRoot:GetPivot(), v3, groundTopLocalY(GardenRoot) + 0.08, t)
					v15 = v1
				end
			else
				if not v14 then
					return
				end

				v14:Destroy()
				v14 = nil
				v15 = nil
			end
		end

		local function cellFromViewportPoint(p1, p2, p3) --[[ cellFromViewportPoint | Line: 201 | Upvalues: groundTopLocalY (copy), gardenGrid (ref) ]]
			local CurrentCamera = workspace.CurrentCamera

			if not CurrentCamera then
				return nil, nil
			end

			local v1 = p1:GetPivot()
			local v2 = CurrentCamera:ViewportPointToRay(p2, p3)
			local UpVector = v1.UpVector
			local v3 = v2.Direction:Dot(UpVector)

			if math.abs(v3) < 0.0001 then
				return nil, nil
			end

			local v4 = (v1.Position + UpVector * groundTopLocalY(p1) - v2.Origin):Dot(UpVector) / v3

			if v4 < 0 then
				return nil, nil
			end

			local v5 = v1:PointToObjectSpace(v2.Origin + v2.Direction * v4)
			local v6, v7 = gardenGrid.cellFromLocal(v5.X, v5.Z)

			return v6, v7
		end

		local function renderPreview(p1, p2) --[[ renderPreview | Line: 223 | Upvalues: v12 (ref), v22 (ref), v3 (ref), gardenGrid (ref), v8 (ref), ClientPlayerData (ref), v9 (ref), v10 (ref), v5 (ref), v1 (ref), v2 (ref), groundTopLocalY (copy), VaultConfig (ref), decorationSeatPoint (ref) ]]
			if not (v12 and (v22 and v3)) then
				return
			end

			local v13, v23 = gardenGrid.footprint(p2, v8)
			local garden = ClientPlayerData.serverProfile:getState().garden
			local v4 = gardenGrid.boundsFromGround(p1, if garden then garden.upgrades else garden)
			local v52 = if v4 == nil then false else gardenGrid.isInBounds(v4, v9, v10, v13, v23)

			if v5 ~= v52 and v12 then
				v5 = v52
				v12.Parent = if v52 then workspace else nil
			end

			if not v52 then
				return
			end

			local v82 = if gardenGrid.canPlace(garden, p2, v9, v10, v8) then v1 else v2
			local v92 = v22

			v92.FillColor = v82
			v92.OutlineColor = v82
			v3.Color = v82

			local v102 = gardenGrid.localCFrame(v9, v10, v13, v23, v8, (groundTopLocalY(p1)))
			local v11 = v12
			local v122 = p1:GetPivot() * v102

			v11:PivotTo(v122)

			if VaultConfig.isVault(p2) then
				local v132 = v122.Position - decorationSeatPoint(v11)

				if v132.Magnitude > 0.001 then
					v11:PivotTo(v11:GetPivot() + v132)
				end
			end

			v3.CFrame = v122 * CFrame.new(0, 0.1, 0)
		end

		local function updatePreview(p1, p2) --[[ updatePreview | Line: 269 | Upvalues: BuildModeState (ref), v4 (ref), v12 (ref), cellFromViewportPoint (copy), v5 (ref), gardenGrid (ref), v8 (ref), v9 (ref), v122 (ref), v10 (ref), v13 (ref), v11 (ref), renderPreview (copy) ]]
			local GardenRoot = BuildModeState.GardenRoot
			local v1 = v4

			if not (GardenRoot and (v1 and v12)) then
				return
			end

			local v2, v3 = cellFromViewportPoint(GardenRoot, p1, p2)

			if v2 and v3 then
				local v42, v52 = gardenGrid.footprint(v1, v8)

				v9 = v2 + v122 - math.floor((v42 - 1) / 2)
				v10 = v3 + v13 - math.floor((v52 - 1) / 2)
				v11 = true
				renderPreview(GardenRoot, v1)

				return
			end

			if v5 == false then
				return
			end

			if not v12 then
				return
			end

			v5 = false
			v12.Parent = nil
		end

		local function updateFromCursor() --[[ updateFromCursor | Line: 287 | Upvalues: UserInputService (ref), updatePreview (copy) ]]
			local v1 = UserInputService:GetMouseLocation()

			updatePreview(v1.X, v1.Y)
		end

		local function reticlePoint() --[[ reticlePoint | Line: 292 ]]
			local CurrentCamera = workspace.CurrentCamera

			if CurrentCamera then
				local v1 = CurrentCamera.ViewportSize / 2

				return v1.X, v1.Y
			end

			return nil, nil
		end

		local function updateFromReticle() --[[ updateFromReticle | Line: 301 | Upvalues: updatePreview (copy) ]]
			local CurrentCamera = workspace.CurrentCamera
			local v1, v2

			if CurrentCamera then
				local v3 = CurrentCamera.ViewportSize / 2

				v1 = v3.X
				v2 = v3.Y
			else
				v1 = nil
				v2 = nil
			end

			if not (v1 and v2) then
				return
			end

			updatePreview(v1, v2)
		end

		local function commitPlace() --[[ commitPlace | Line: 308 | Upvalues: v4 (ref), BuildModeState (ref), v11 (ref), ClientPlayerData (ref), GardenConfig (ref), notifications (ref), VaultConfig (ref), gardenGrid (ref), v9 (ref), v10 (ref), v8 (ref), Remotes (ref), SFX (ref) ]]
			local v1 = v4
			local GardenRoot = BuildModeState.GardenRoot

			if not (v1 and (v11 and GardenRoot)) then
				return
			end

			local garden = ClientPlayerData.serverProfile:getState().garden
			local v2 = GardenConfig.CountPlacedItems(garden)
			local v3 = GardenConfig.GetMaxPlacedItems(garden)

			if v3 <= v2 then
				notifications:Send(GardenConfig.GardenFullText(v2, v3))

				return
			end

			if VaultConfig.isVault(v1) and VaultConfig.countPlaced(garden) >= VaultConfig.MaxPlaced then
				notifications:Send(VaultConfig.AlreadyPlacedText)

				return
			end

			if not gardenGrid.canPlaceAt(garden, GardenRoot, v1, v9, v10, v8) then
				notifications:Send("You can\'t build there.")

				return
			end

			local v42, v5 = Remotes.RequestPlaceGardenItem:Call({
				configName = v1,
				cellX = v9,
				cellZ = v10,
				rot = v8
			}):Await()

			if v42 and (typeof(v5) == "table" and v5.ok) then
				SFX.new(SFX.Sounds.GardenPlace, 0.5)

				local v6 = ClientPlayerData.serverProfile:getState().inventory[v1]

				if v6 and not ((v6.Stack or 0) <= 0) then
					return
				end

				BuildModeState.SetSelected(nil)
			else
				notifications:Send((if typeof(v5) == "table" then v5.reason else nil) or "Could not place that decoration.")
			end
		end

		local function clearRemoveTarget() --[[ clearRemoveTarget | Line: 354 | Upvalues: v6 (ref), v7 (ref) ]]
			if not v6 then
				v6 = nil
				v7 = nil

				return
			end

			v6:Destroy()
			v6 = nil
			v7 = nil
		end

		local function placedFolder() --[[ placedFolder | Line: 362 | Upvalues: BuildModeState (ref), GardenConfig (ref) ]]
			local GardenRoot = BuildModeState.GardenRoot
			local v1 = if GardenRoot then GardenRoot:FindFirstChild(GardenConfig.PlacedFolderName) else GardenRoot

			if v1 and v1:IsA("Folder") then
				return v1
			end

			return nil
		end

		local function updateRemoveTarget(p1, p2) --[[ updateRemoveTarget | Line: 371 | Upvalues: BuildModeState (ref), GardenConfig (ref), v6 (ref), v7 (ref), v2 (ref) ]]
			local GardenRoot = BuildModeState.GardenRoot
			local v1 = if GardenRoot then GardenRoot:FindFirstChild(GardenConfig.PlacedFolderName) else GardenRoot
			local v22 = if v1 and v1:IsA("Folder") then v1 else nil
			local CurrentCamera = workspace.CurrentCamera

			if v22 and CurrentCamera then
				local v3 = CurrentCamera:ViewportPointToRay(p1, p2)
				local v4 = RaycastParams.new()

				v4.FilterType = Enum.RaycastFilterType.Include
				v4.FilterDescendantsInstances = { v22 }

				local v5 = workspace:Raycast(v3.Origin, v3.Direction * 500, v4)
				local v62 = nil

				if v5 then
					local v72 = v5.Instance

					while true do
						if not v72 or v72 == v22 then
							break
						end

						if v72:IsA("Model") and v72:GetAttribute("PlacementId") then
							v62 = v72

							break
						end

						v72 = v72.Parent
					end
				end

				if v62 == v7 then
					return
				end

				if v6 then
					v6:Destroy()
				end

				v6 = nil
				v7 = nil

				if v62 then
					local GardenRemoveSelection = Instance.new("SelectionBox")

					GardenRemoveSelection.Name = "GardenRemoveSelection"
					GardenRemoveSelection.Adornee = v62
					GardenRemoveSelection.Color3 = v2
					GardenRemoveSelection.SurfaceColor3 = v2
					GardenRemoveSelection.LineThickness = 0.05
					GardenRemoveSelection.SurfaceTransparency = 0.7
					GardenRemoveSelection.Transparency = 0
					GardenRemoveSelection.Parent = v62
					v6 = GardenRemoveSelection
					v7 = v62
				end
			else
				if v6 then
					v6:Destroy()
				end

				v6 = nil
				v7 = nil
			end
		end

		local function commitRemove() --[[ commitRemove | Line: 414 | Upvalues: v7 (ref), v6 (ref), Remotes (ref), notifications (ref), SFX (ref) ]]
			local v1 = v7

			if not v1 then
				return
			end

			local v2 = v1:GetAttribute("PlacementId")

			if typeof(v2) ~= "string" then
				return
			end

			if v6 then
				v6:Destroy()
			end

			v6 = nil
			v7 = nil

			local v3, v4 = Remotes.RequestRemoveGardenItem:Call(v2):Await()

			if v3 and (typeof(v4) == "table" and v4.ok) then
				SFX.new(SFX.Sounds.GardenRemove, 0.5)

				return
			end

			notifications:Send((if typeof(v4) == "table" then v4.reason else nil) or "Could not remove that decoration.")
		end

		local function rotatePreview() --[[ rotatePreview | Line: 433 | Upvalues: BuildModeState (ref), v12 (ref), v8 (ref), UserInputService (ref), updatePreview (copy), v4 (ref), v11 (ref), renderPreview (copy) ]]
			if not (BuildModeState.Active and (if BuildModeState.Mode == "Build" and BuildModeState.SelectedConfigName ~= nil then v12 ~= nil else false)) then
				return
			end

			v8 = (v8 + 1) % 4

			if UserInputService.PreferredInput == Enum.PreferredInput.KeyboardAndMouse then
				local v2 = UserInputService:GetMouseLocation()

				updatePreview(v2.X, v2.Y)

				return
			end

			local GardenRoot = BuildModeState.GardenRoot
			local v3 = v4

			if not (v11 and (GardenRoot and v3)) then
				return
			end

			renderPreview(GardenRoot, v3)
		end

		local function cancel() --[[ cancel | Line: 449 | Upvalues: BuildModeState (ref) ]]
			if BuildModeState.Mode == "Remove" then
				BuildModeState.SetMode("Build")
			else
				BuildModeState.SetSelected(nil)
			end
		end

		local v16 = nil
		local v17 = nil
		local t2 = {}
		local v18 = (-1 / 0)

		local function noteBillboardTouch(p1) --[[ noteBillboardTouch | Line: 463 | Upvalues: v18 (ref) ]]
			if p1.UserInputType ~= Enum.UserInputType.Touch then
				return
			end

			v18 = os.clock()
		end

		local function consumedByBillboard() --[[ consumedByBillboard | Line: 469 | Upvalues: v18 (ref) ]]
			if os.clock() - v18 > 0.6 then
				return false
			end

			v18 = (-1 / 0)

			return true
		end

		local function bindBillboard(p1) --[[ bindBillboard | Line: 477 | Upvalues: t2 (copy), commitPlace (copy), rotatePreview (copy), cancel (copy), noteBillboardTouch (copy) ]]
			for v1, v2 in t2 do
				v2:Disconnect()
			end

			table.clear(t2)

			for v3, v4 in {
				Place = commitPlace,
				Rotate = rotatePreview,
				Cancel = cancel
			} do
				local v5 = p1:FindFirstChild(v3, true)

				if v5 and v5:IsA("GuiButton") then
					table.insert(t2, v5.Activated:Connect(v4))

					continue
				end

				warn((("[GardenPlacer] BuildBillboardGUI.%* is not a GuiButton \226\128\148 that mobile action is unavailable"):format(v3)))
			end

			for v7, v8 in p1:GetDescendants() do
				if v8:IsA("GuiObject") then
					table.insert(t2, v8.InputBegan:Connect(noteBillboardTouch))
				end
			end
		end

		local function resolveBillboard() --[[ resolveBillboard | Line: 497 | Upvalues: v16 (ref), PlayerGui (copy), bindBillboard (copy) ]]
			local v1 = v16

			if v1 and v1.Parent then
				return v1
			end

			local BuildBillboardGUI = PlayerGui:FindFirstChild("BuildBillboardGUI")

			if BuildBillboardGUI and BuildBillboardGUI:IsA("BillboardGui") then
				BuildBillboardGUI.Enabled = false
				bindBillboard(BuildBillboardGUI)
				v16 = BuildBillboardGUI

				return BuildBillboardGUI
			end

			return nil
		end

		local function ensureBillboardAnchor() --[[ ensureBillboardAnchor | Line: 513 | Upvalues: v17 (ref) ]]
			local v1 = v17

			if v1 and v1.Parent then
				return v1
			end

			local GardenPlacerBillboardAnchor = Instance.new("Part")

			GardenPlacerBillboardAnchor.Name = "GardenPlacerBillboardAnchor"
			GardenPlacerBillboardAnchor.Size = Vector3.new(0.2, 0.2, 0.2)
			GardenPlacerBillboardAnchor.Transparency = 1
			GardenPlacerBillboardAnchor.Anchored = true
			GardenPlacerBillboardAnchor.CanCollide = false
			GardenPlacerBillboardAnchor.CanQuery = false
			GardenPlacerBillboardAnchor.CanTouch = false
			GardenPlacerBillboardAnchor.Locked = true
			GardenPlacerBillboardAnchor.Parent = workspace
			v17 = GardenPlacerBillboardAnchor

			return GardenPlacerBillboardAnchor
		end

		local function isTouchInput() --[[ isTouchInput | Line: 532 | Upvalues: UserInputService (ref) ]]
			return UserInputService.PreferredInput == Enum.PreferredInput.Touch
		end

		local function updateBillboard() --[[ updateBillboard | Line: 536 | Upvalues: v16 (ref), PlayerGui (copy), bindBillboard (copy), v12 (ref), UserInputService (ref), BuildModeState (ref), v5 (ref), v17 (ref) ]]
			local v1 = v16
			local v2

			if v1 and v1.Parent then
				v2 = v1
			else
				local BuildBillboardGUI = PlayerGui:FindFirstChild("BuildBillboardGUI")

				if BuildBillboardGUI and BuildBillboardGUI:IsA("BillboardGui") then
					BuildBillboardGUI.Enabled = false
					bindBillboard(BuildBillboardGUI)
					v16 = BuildBillboardGUI
					v2 = BuildBillboardGUI
				else
					v2 = nil
				end
			end

			if not v2 then
				return
			end

			local CurrentCamera = workspace.CurrentCamera
			local v3 = v12

			if UserInputService.PreferredInput == Enum.PreferredInput.Touch and (BuildModeState.Active and (if BuildModeState.Mode == "Build" and BuildModeState.SelectedConfigName ~= nil then v12 ~= nil else false) and (v5 and (CurrentCamera and v3))) then
				local v52, v6 = v3:GetBoundingBox()
				local v8 = CurrentCamera.CFrame.RightVector * (math.max(v6.X, v6.Z) * 0.5 + 2)
				local v9 = v17
				local v10

				if v9 and v9.Parent then
					v10 = v9
				else
					local GardenPlacerBillboardAnchor = Instance.new("Part")

					GardenPlacerBillboardAnchor.Name = "GardenPlacerBillboardAnchor"
					GardenPlacerBillboardAnchor.Size = Vector3.new(0.2, 0.2, 0.2)
					GardenPlacerBillboardAnchor.Transparency = 1
					GardenPlacerBillboardAnchor.Anchored = true
					GardenPlacerBillboardAnchor.CanCollide = false
					GardenPlacerBillboardAnchor.CanQuery = false
					GardenPlacerBillboardAnchor.CanTouch = false
					GardenPlacerBillboardAnchor.Locked = true
					GardenPlacerBillboardAnchor.Parent = workspace
					v17 = GardenPlacerBillboardAnchor
					v10 = GardenPlacerBillboardAnchor
				end

				v10.CFrame = CFrame.new(v52.Position + v8)
				v2.Adornee = v10
				v2.Enabled = true

				return
			end

			v2.Enabled = false
		end

		local function nudge(p1, p2) --[[ nudge | Line: 556 | Upvalues: BuildModeState (ref), v12 (ref), v122 (ref), v13 (ref), updatePreview (copy) ]]
			if not (BuildModeState.Active and (if BuildModeState.Mode == "Build" and BuildModeState.SelectedConfigName ~= nil then v12 ~= nil else false)) then
				return
			end

			v122 = v122 + p1
			v13 = v13 + p2

			local CurrentCamera = workspace.CurrentCamera
			local v2, v3

			if CurrentCamera then
				local v4 = CurrentCamera.ViewportSize / 2

				v2 = v4.X
				v3 = v4.Y
			else
				v2 = nil
				v3 = nil
			end

			if not (v2 and v3) then
				return
			end

			updatePreview(v2, v3)
		end

		local function bindGamepad(p1) --[[ bindGamepad | Line: 565 | Upvalues: ContextActionService (ref), BuildModeState (ref), v12 (ref), v122 (ref), v13 (ref), updatePreview (copy) ]]
			if p1 then
				ContextActionService:BindActionAtPriority("GardenPlacerNudge", function(p13, p23, p33) --[[ Line: 570 | Upvalues: BuildModeState (ref), v12 (ref), v122 (ref), v13 (ref), updatePreview (ref) ]]
					if p23 ~= Enum.UserInputState.Begin then
						return Enum.ContextActionResult.Pass
					end

					if p33.KeyCode == Enum.KeyCode.DPadUp then
						if not (BuildModeState.Active and (if BuildModeState.Mode == "Build" and BuildModeState.SelectedConfigName ~= nil then v12 ~= nil else false)) then
							return Enum.ContextActionResult.Sink
						end

						v122 = v122 + 0
						v13 = v13 + -1

						local CurrentCamera = workspace.CurrentCamera
						local v2, v3

						if CurrentCamera then
							local v4 = CurrentCamera.ViewportSize / 2

							v2 = v4.X
							v3 = v4.Y
						else
							v2 = nil
							v3 = nil
						end

						if not (v2 and v3) then
							return Enum.ContextActionResult.Sink
						end

						updatePreview(v2, v3)
					elseif p33.KeyCode == Enum.KeyCode.DPadDown then
						if not (BuildModeState.Active and (if BuildModeState.Mode == "Build" and BuildModeState.SelectedConfigName ~= nil then v12 ~= nil else false)) then
							return Enum.ContextActionResult.Sink
						end

						v122 = v122 + 0
						v13 = v13 + 1

						local CurrentCamera = workspace.CurrentCamera
						local v6, v7

						if CurrentCamera then
							local v8 = CurrentCamera.ViewportSize / 2

							v6 = v8.X
							v7 = v8.Y
						else
							v6 = nil
							v7 = nil
						end

						if not (v6 and v7) then
							return Enum.ContextActionResult.Sink
						end

						updatePreview(v6, v7)
					elseif p33.KeyCode == Enum.KeyCode.DPadLeft then
						if not (BuildModeState.Active and (if BuildModeState.Mode == "Build" and BuildModeState.SelectedConfigName ~= nil then v12 ~= nil else false)) then
							return Enum.ContextActionResult.Sink
						end

						v122 = v122 + -1
						v13 = v13 + 0

						local CurrentCamera = workspace.CurrentCamera
						local v10, v11

						if CurrentCamera then
							local v123 = CurrentCamera.ViewportSize / 2

							v10 = v123.X
							v11 = v123.Y
						else
							v10 = nil
							v11 = nil
						end

						if not (v10 and v11) then
							return Enum.ContextActionResult.Sink
						end

						updatePreview(v10, v11)
					else
						if p33.KeyCode ~= Enum.KeyCode.DPadRight then
							return Enum.ContextActionResult.Sink
						end

						if not (BuildModeState.Active and (if BuildModeState.Mode == "Build" and BuildModeState.SelectedConfigName ~= nil then v12 ~= nil else false)) then
							return Enum.ContextActionResult.Sink
						end

						v122 = v122 + 1
						v13 = v13 + 0

						local CurrentCamera = workspace.CurrentCamera
						local v14, v15

						if CurrentCamera then
							local v16 = CurrentCamera.ViewportSize / 2

							v14 = v16.X
							v15 = v16.Y
						else
							v14 = nil
							v15 = nil
						end

						if not (v14 and v15) then
							return Enum.ContextActionResult.Sink
						end

						updatePreview(v14, v15)
					end

					return Enum.ContextActionResult.Sink
				end, false, 9000, Enum.KeyCode.DPadUp, Enum.KeyCode.DPadDown, Enum.KeyCode.DPadLeft, Enum.KeyCode.DPadRight)
			else
				ContextActionService:UnbindAction("GardenPlacerNudge")
			end
		end

		local function onStateChanged() --[[ onStateChanged | Line: 587 | Upvalues: BuildModeState (ref), v12 (ref), v22 (ref), v3 (ref), v4 (ref), v5 (ref), v11 (ref), ContextActionService (ref), buildPreview (copy), bindToButtonPress (ref), rotatePreview (copy), v122 (ref), v13 (ref), updatePreview (copy), UserInputService (ref), v6 (ref), v7 (ref), updateGrid (copy), commitPlace (copy), commitRemove (copy), updateBillboard (copy) ]]
			local SelectedConfigName = BuildModeState.SelectedConfigName

			if BuildModeState.Active and (BuildModeState.Mode == "Build" and SelectedConfigName) then
				if SelectedConfigName ~= v4 then
					buildPreview(SelectedConfigName)

					if v12 then
						bindToButtonPress("GardenPlacerRotate", Enum.KeyCode.ButtonY, rotatePreview)
						ContextActionService:BindActionAtPriority("GardenPlacerNudge", function(p13, p23, p33) --[[ Line: 570 | Upvalues: BuildModeState (ref), v12 (ref), v122 (ref), v13 (ref), updatePreview (ref) ]]
							if p23 ~= Enum.UserInputState.Begin then
								return Enum.ContextActionResult.Pass
							end

							if p33.KeyCode == Enum.KeyCode.DPadUp then
								if not (BuildModeState.Active and (if BuildModeState.Mode == "Build" and BuildModeState.SelectedConfigName ~= nil then v12 ~= nil else false)) then
									return Enum.ContextActionResult.Sink
								end

								v122 = v122 + 0
								v13 = v13 + -1

								local CurrentCamera = workspace.CurrentCamera
								local v2, v3

								if CurrentCamera then
									local v4 = CurrentCamera.ViewportSize / 2

									v2 = v4.X
									v3 = v4.Y
								else
									v2 = nil
									v3 = nil
								end

								if not (v2 and v3) then
									return Enum.ContextActionResult.Sink
								end

								updatePreview(v2, v3)
							elseif p33.KeyCode == Enum.KeyCode.DPadDown then
								if not (BuildModeState.Active and (if BuildModeState.Mode == "Build" and BuildModeState.SelectedConfigName ~= nil then v12 ~= nil else false)) then
									return Enum.ContextActionResult.Sink
								end

								v122 = v122 + 0
								v13 = v13 + 1

								local CurrentCamera = workspace.CurrentCamera
								local v6, v7

								if CurrentCamera then
									local v8 = CurrentCamera.ViewportSize / 2

									v6 = v8.X
									v7 = v8.Y
								else
									v6 = nil
									v7 = nil
								end

								if not (v6 and v7) then
									return Enum.ContextActionResult.Sink
								end

								updatePreview(v6, v7)
							elseif p33.KeyCode == Enum.KeyCode.DPadLeft then
								if not (BuildModeState.Active and (if BuildModeState.Mode == "Build" and BuildModeState.SelectedConfigName ~= nil then v12 ~= nil else false)) then
									return Enum.ContextActionResult.Sink
								end

								v122 = v122 + -1
								v13 = v13 + 0

								local CurrentCamera = workspace.CurrentCamera
								local v10, v11

								if CurrentCamera then
									local v123 = CurrentCamera.ViewportSize / 2

									v10 = v123.X
									v11 = v123.Y
								else
									v10 = nil
									v11 = nil
								end

								if not (v10 and v11) then
									return Enum.ContextActionResult.Sink
								end

								updatePreview(v10, v11)
							else
								if p33.KeyCode ~= Enum.KeyCode.DPadRight then
									return Enum.ContextActionResult.Sink
								end

								if not (BuildModeState.Active and (if BuildModeState.Mode == "Build" and BuildModeState.SelectedConfigName ~= nil then v12 ~= nil else false)) then
									return Enum.ContextActionResult.Sink
								end

								v122 = v122 + 1
								v13 = v13 + 0

								local CurrentCamera = workspace.CurrentCamera
								local v14, v15

								if CurrentCamera then
									local v16 = CurrentCamera.ViewportSize / 2

									v14 = v16.X
									v15 = v16.Y
								else
									v14 = nil
									v15 = nil
								end

								if not (v14 and v15) then
									return Enum.ContextActionResult.Sink
								end

								updatePreview(v14, v15)
							end

							return Enum.ContextActionResult.Sink
						end, false, 9000, Enum.KeyCode.DPadUp, Enum.KeyCode.DPadDown, Enum.KeyCode.DPadLeft, Enum.KeyCode.DPadRight)

						if UserInputService.PreferredInput ~= Enum.PreferredInput.KeyboardAndMouse then
							local CurrentCamera = workspace.CurrentCamera
							local v1, v2

							if CurrentCamera then
								local v32 = CurrentCamera.ViewportSize / 2

								v1 = v32.X
								v2 = v32.Y
							else
								v1 = nil
								v2 = nil
							end

							if v1 and v2 then
								updatePreview(v1, v2)
							end
						end
					end
				end
			else
				if v12 then
					v12:Destroy()
				end

				v12 = nil
				v22 = nil
				v3 = nil
				v4 = nil
				v5 = false
				v11 = false
				ContextActionService:UnbindAction("GardenPlacerRotate")
				ContextActionService:UnbindAction("GardenPlacerNudge")
			end

			local v42 = BuildModeState.Active and BuildModeState.Mode == "Remove"

			if not v42 then
				if v6 then
					v6:Destroy()
				end

				v6 = nil
				v7 = nil
			end

			updateGrid()

			local v52 = BuildModeState.Active and (if BuildModeState.Mode == "Build" and BuildModeState.SelectedConfigName ~= nil then v12 ~= nil else false)

			if v52 then
				bindToButtonPress("GardenPlacerConfirm", Enum.KeyCode.ButtonA, function() --[[ Line: 611 | Upvalues: commitPlace (ref) ]]
					task.spawn(commitPlace)
				end)
			elseif BuildModeState.Active and BuildModeState.Mode == "Remove" then
				bindToButtonPress("GardenPlacerConfirm", Enum.KeyCode.ButtonA, function() --[[ Line: 615 | Upvalues: commitRemove (ref) ]]
					task.spawn(commitRemove)
				end)
			else
				ContextActionService:UnbindAction("GardenPlacerConfirm")
			end

			updateBillboard()
		end

		BuildModeState.Changed:Connect(onStateChanged)
		ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 630 ]]
			return p1.garden
		end, updateGrid)
		RunService.RenderStepped:Connect(function() --[[ Line: 634 | Upvalues: UserInputService (ref), BuildModeState (ref), v12 (ref), updatePreview (copy), updateRemoveTarget (copy), updateBillboard (copy) ]]
			debug.profilebegin("UECS/GardenPlacer.Update")

			local PreferredInput = UserInputService.PreferredInput

			if PreferredInput == Enum.PreferredInput.KeyboardAndMouse then
				if BuildModeState.Active and (if BuildModeState.Mode == "Build" and BuildModeState.SelectedConfigName ~= nil then v12 ~= nil else false) then
					local v2 = UserInputService:GetMouseLocation()

					updatePreview(v2.X, v2.Y)
				elseif BuildModeState.Active and BuildModeState.Mode == "Remove" then
					local v4 = UserInputService:GetMouseLocation()

					updateRemoveTarget(v4.X, v4.Y)
				end
			elseif PreferredInput == Enum.PreferredInput.Gamepad then
				if BuildModeState.Active and (if BuildModeState.Mode == "Build" and BuildModeState.SelectedConfigName ~= nil then v12 ~= nil else false) then
					local CurrentCamera = workspace.CurrentCamera
					local v6, v7

					if CurrentCamera then
						local v8 = CurrentCamera.ViewportSize / 2

						v6 = v8.X
						v7 = v8.Y
					else
						v6 = nil
						v7 = nil
					end

					if v6 and v7 then
						updatePreview(v6, v7)
					end
				elseif BuildModeState.Active and BuildModeState.Mode == "Remove" then
					local CurrentCamera = workspace.CurrentCamera
					local v10, v11

					if CurrentCamera then
						local v122 = CurrentCamera.ViewportSize / 2

						v10 = v122.X
						v11 = v122.Y
					else
						v10 = nil
						v11 = nil
					end

					if v10 and v11 then
						updateRemoveTarget(v10, v11)
					end
				end
			end

			if BuildModeState.Active then
				updateBillboard()
			end

			debug.profileend()
		end)
		UserInputService.InputBegan:Connect(function(p1, p2) --[[ Line: 660 | Upvalues: BuildModeState (ref), v12 (ref), commitPlace (copy), v8 (ref), UserInputService (ref), updatePreview (copy), v4 (ref), v11 (ref), renderPreview (copy), commitRemove (copy) ]]
			if p2 or not BuildModeState.Active then
				return
			end

			local isMouseButton1 = p1.UserInputType == Enum.UserInputType.MouseButton1

			if BuildModeState.Active and (if BuildModeState.Mode == "Build" and BuildModeState.SelectedConfigName ~= nil then v12 ~= nil else false) then
				if isMouseButton1 then
					commitPlace()

					return
				end

				if p1.KeyCode == Enum.KeyCode.R then
					if not (BuildModeState.Active and (if BuildModeState.Mode == "Build" and BuildModeState.SelectedConfigName ~= nil then v12 ~= nil else false)) then
						return
					end

					v8 = (v8 + 1) % 4

					if UserInputService.PreferredInput == Enum.PreferredInput.KeyboardAndMouse then
						local v3 = UserInputService:GetMouseLocation()

						updatePreview(v3.X, v3.Y)

						return
					end

					local GardenRoot = BuildModeState.GardenRoot
					local v42 = v4

					if v11 and (GardenRoot and v42) then
						renderPreview(GardenRoot, v42)
					end
				else
					if p1.KeyCode ~= Enum.KeyCode.Q then
						return
					end

					if BuildModeState.Mode == "Remove" then
						BuildModeState.SetMode("Build")

						return
					end

					BuildModeState.SetSelected(nil)
				end
			else
				if not (BuildModeState.Active and BuildModeState.Mode == "Remove" and isMouseButton1) then
					return
				end

				commitRemove()
			end
		end)
		UserInputService.TouchTap:Connect(function(p1, p2) --[[ Line: 682 | Upvalues: BuildModeState (ref), v18 (ref), GuiService (ref), v12 (ref), updatePreview (copy), updateBillboard (copy), v7 (ref), updateRemoveTarget (copy), commitRemove (copy) ]]
			if p2 or not BuildModeState.Active then
				return
			end

			local v1 = p1[1]

			if not v1 then
				return
			end

			local v2

			if os.clock() - v18 > 0.6 then
				v2 = false
			else
				v18 = (-1 / 0)
				v2 = true
			end

			if v2 then
				return
			end

			local v3 = GuiService:GetGuiInset()
			local v4 = v1.X + v3.X
			local v5 = v1.Y + v3.Y

			if BuildModeState.Active and (if BuildModeState.Mode == "Build" and BuildModeState.SelectedConfigName ~= nil then v12 ~= nil else false) then
				updatePreview(v4, v5)
				updateBillboard()

				return
			end

			if not (BuildModeState.Active and BuildModeState.Mode == "Remove") then
				return
			end

			updateRemoveTarget(v4, v5)

			if v7 == nil or v7 ~= v7 then
				return
			end

			commitRemove()
		end)
	end
}