-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ConvertValue = require(ReplicatedStorage.shared.util.ConvertValue)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local GymEventConfig = require(ReplicatedStorage.shared.config.GymEventConfig)
local GymEventState = require(ReplicatedStorage.client.GymEventState)
local t = {
	UECS = nil
}
local PoolBoard = GymEventConfig.Tags.PoolBoard
local t2 = {}
local v1 = nil
local v2 = 0

local function formatPool(p1) --[[ formatPool | Line: 44 | Upvalues: ConvertValue (copy) ]]
	return ConvertValue.suffixformat(p1)
end

local function startFor(p1) --[[ startFor | Line: 48 | Upvalues: t2 (copy), v1 (ref), GymEventConfig (copy), v2 (ref), ConvertValue (copy) ]]
	if t2[p1] then
		return
	end

	if not p1:IsA("BasePart") then
		return
	end

	local v12 = v1

	if not v12 then
		return
	end

	local v22 = v12:Clone()

	if not v22:IsA("LayerCollector") then
		v22:Destroy()

		return
	end

	local v3 = v22:FindFirstChild(GymEventConfig.Ui.PoolBoardValueLabelName, true)

	if not (v3 and v3:IsA("TextLabel")) then
		warn(("[GymPoolBoard] no %* TextLabel in the"):format(GymEventConfig.Ui.PoolBoardValueLabelName) .. (" %* template"):format(GymEventConfig.Ui.PoolBoardTemplateName))
		v22:Destroy()

		return
	end

	if v22:IsA("BillboardGui") then
		v22.Adornee = p1
	end

	v3.Text = ConvertValue.suffixformat(v2)
	v22.Parent = p1
	t2[p1] = {
		gui = v22,
		label = v3,
		destroying = p1.Destroying:Connect(function() --[[ Line: 82 | Upvalues: t2 (ref), p1 (copy) ]]
			local v1 = t2[p1]

			if not v1 then
				return
			end

			v1.destroying:Disconnect()
			v1.gui:Destroy()
			t2[p1] = nil
		end)
	}
end

local function stopFor(p1) --[[ stopFor | Line: 94 | Upvalues: t2 (copy) ]]
	local v1 = t2[p1]

	if v1 then
		v1.destroying:Disconnect()
		v1.gui:Destroy()
		t2[p1] = nil
	end
end

function t.Init(p1) --[[ Init | Line: 104 | Upvalues: GymEventConfig (copy), ReplicatedStorage (copy), v1 (ref), GymEventState (copy), v2 (ref), ConvertValue (copy), t2 (copy), CollectionService (copy), PoolBoard (copy), startFor (copy), stopFor (copy) ]]
	if not GymEventConfig.Enabled then
		return
	end

	local v12 = ReplicatedStorage:FindFirstChild("shared")
	local v22 = if v12 then v12:FindFirstChild("model") else v12
	local v3 = if v22 then v22:FindFirstChild(GymEventConfig.Ui.PoolBoardTemplateName) else v22

	if not v3 then
		return
	end

	v1 = v3
	GymEventState.Start()

	local function render(p1) --[[ render | Line: 124 | Upvalues: v2 (ref), ConvertValue (ref), t2 (ref) ]]
		v2 = p1.pool

		local v22 = ConvertValue.suffixformat(p1.pool)

		for v3, v4 in t2 do
			v4.label.Text = v22
		end
	end

	GymEventState.Changed:Connect(render)

	local v4 = GymEventState.Get()

	if v4 then
		v2 = v4.pool

		local v6 = ConvertValue.suffixformat(v4.pool)

		for v7, v8 in t2 do
			v8.label.Text = v6
		end
	end

	for v9, v10 in CollectionService:GetTagged(PoolBoard) do
		startFor(v10)
	end

	CollectionService:GetInstanceAddedSignal(PoolBoard):Connect(startFor)
	CollectionService:GetInstanceRemovedSignal(PoolBoard):Connect(stopFor)
end

return t