-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local CashFormat = require(ReplicatedStorage.shared.util.CashFormat)
local GardenConfig = require(ReplicatedStorage.shared.config.GardenConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Remotes = require(ReplicatedStorage.shared.Remotes)
local SFX = require(ReplicatedStorage.client.SFX)

require(ReplicatedStorage.shared.UECS.Components.TycoonComponent)

local notifications = require(ReplicatedStorage.shared.module.notifications)
local v1 = Color3.fromRGB(255, 90, 90)
local t = {
	TextName = "LockText",
	ProgressBarName = "RebirthProgress",
	BarTransparency = 0.25,
	TextPosition = UDim2.fromScale(0.5, 0.24),
	TextSize = UDim2.fromScale(0.6, 0.13),
	BarPosition = UDim2.fromScale(0.5, 0.8),
	BarSize = UDim2.fromScale(0.28, 0.09),
	BarColor = Color3.fromRGB(25, 25, 25),
	FillColor = Color3.fromRGB(126, 255, 143),
	TextColor = Color3.fromRGB(255, 255, 255),
	StrokeColor = Color3.fromRGB(0, 0, 0)
}
local t2 = {
	UECS = nil
}

local function findGui(p1) --[[ findGui | Line: 35 ]]
	if not (p1:IsA("BillboardGui") or p1:IsA("SurfaceGui")) then
		return p1:QueryDescendants("BillboardGui, SurfaceGui")[1]
	end

	return p1
end

local function findUpgradeIcon(p1) --[[ findUpgradeIcon | Line: 43 | Upvalues: GardenConfig (copy) ]]
	local v1 = p1:FindFirstChild(GardenConfig.UpgradeIconName)

	if v1 and v1:IsA("BillboardGui") then
		return v1
	end

	return nil
end

local function findFenceAttachment(p1) --[[ findFenceAttachment | Line: 51 | Upvalues: GardenConfig (copy) ]]
	for v1, v2 in p1:GetDescendants() do
		if v2:IsA("Attachment") then
			local v3 = v2:FindFirstChild(GardenConfig.UpgradeIconName)

			if if v3 and v3:IsA("BillboardGui") then v3 else nil then
				return v2
			end
		end
	end

	return p1:FindFirstChildWhichIsA("Attachment", true)
end

local function priceText(p1) --[[ priceText | Line: 60 | Upvalues: CashFormat (copy) ]]
	return CashFormat.token(p1)
end

function t2.Init(p1) --[[ Init | Line: 64 | Upvalues: Players (copy), ClientPlayerData (copy), notifications (copy), CashFormat (copy), v1 (copy), GardenConfig (copy), findFenceAttachment (copy), SFX (copy), Remotes (copy), t (copy) ]]
	local LocalPlayer = Players.LocalPlayer
	local t2 = {}
	local t3 = {}
	local t4 = {}
	local t5 = {}
	local t6 = {}

	local function state() --[[ state | Line: 73 | Upvalues: ClientPlayerData (ref) ]]
		return ClientPlayerData.serverProfile:getState()
	end

	local function insufficient(p12) --[[ insufficient | Line: 77 | Upvalues: ClientPlayerData (ref), notifications (ref), CashFormat (ref), v1 (ref), p1 (copy) ]]
		notifications:Send((("You need %* more!"):format((CashFormat.token(math.max(0, p12 - (ClientPlayerData.serverProfile:getState().money or 0)), v1)))))

		local v3 = p1.UECS:WaitForAnyComponent("UIFrameOpener")
		local v4 = p1.UECS:WaitForAnyComponent("Store")

		if not (v3 and v4) then
			return
		end

		v3.OpenedUIComponent:Set(v4)
	end

	local function clearBoards(p1) --[[ clearBoards | Line: 87 | Upvalues: t2 (copy), t3 (copy), t4 (copy) ]]
		local v1 = t2[p1]

		if v1 then
			for k, v in pairs(v1) do
				if k ~= "Rebuild" then
					v:Disconnect()
					v1[k] = nil
				end
			end
		end

		local v2 = t3[p1]

		if v2 then
			for v3, v4 in v2 do
				v4()
			end

			t3[p1] = nil
		end

		local v5 = t4[p1]

		if not v5 then
			return
		end

		for v6, v7 in v5 do
			v7:Destroy()
		end

		t4[p1] = nil
	end

	local function track(p1, p2) --[[ track | Line: 113 | Upvalues: t4 (copy) ]]
		local v1 = t4[p1]

		if not v1 then
			v1 = {}
			t4[p1] = v1
		end

		table.insert(v1, p2)
	end

	local function buildBoards(p1) --[[ buildBoards | Line: 122 | Upvalues: t5 (copy), t2 (copy), GardenConfig (ref), findFenceAttachment (ref), CashFormat (ref), t4 (copy), LocalPlayer (copy), ClientPlayerData (ref), insufficient (copy), SFX (ref), Remotes (ref), notifications (ref) ]]
		local v1 = t5[p1]

		if not (v1 and v1.Parent) then
			return
		end

		local v2 = t2[p1]

		if not v2 then
			return
		end

		if v1:FindFirstChild(GardenConfig.LockedFenceName) then
			return
		end

		local v3 = v1:FindFirstChild(GardenConfig.FencesFolderName)
		local v4 = if v3 then v3:FindFirstChild(GardenConfig.UnupgradedFolderName) else v3

		if not v4 then
			return
		end

		for v6, v7 in GardenConfig.Sections do
			local v5
			local v8 = v4:FindFirstChild(v7.ModelName)

			if v8 then
				local v9 = findFenceAttachment(v8)

				if v9 then
					local ProximityPrompt = Instance.new("ProximityPrompt")

					ProximityPrompt.Name = ("Upgrade%*"):format(v7.Id)
					ProximityPrompt.Style = Enum.ProximityPromptStyle.Custom
					ProximityPrompt.ObjectText = v7.DisplayName
					ProximityPrompt.ActionText = CashFormat.token(v7.Cost)
					ProximityPrompt.HoldDuration = GardenConfig.PromptHoldDuration
					ProximityPrompt.MaxActivationDistance = GardenConfig.PromptDistance
					ProximityPrompt.RequiresLineOfSight = false
					ProximityPrompt.Parent = v9

					local v10 = t4[p1]

					if not v10 then
						v10 = {}
						t4[p1] = v10
					end

					table.insert(v10, ProximityPrompt)

					local v11 = v9:FindFirstChild(GardenConfig.UpgradeIconName)

					v5 = if v11 and v11:IsA("BillboardGui") then v11 else nil

					if v5 then
						v5.Enabled = true
						v2[("%*IconShown"):format(v7.Id)] = ProximityPrompt.PromptShown:Connect(function() --[[ Line: 179 | Upvalues: v5 (copy) ]]
							if not v5.Parent then
								return
							end

							v5.Enabled = false
						end)
						v2[("%*IconHidden"):format(v7.Id)] = ProximityPrompt.PromptHidden:Connect(function() --[[ Line: 184 | Upvalues: v5 (copy) ]]
							if not v5.Parent then
								return
							end

							v5.Enabled = true
						end)
					end

					v2[v7.Id] = ProximityPrompt.Triggered:Connect(function(p1) --[[ Line: 191 | Upvalues: LocalPlayer (ref), ClientPlayerData (ref), v7 (copy), insufficient (ref), SFX (ref), Remotes (ref), notifications (ref) ]]
						if p1 ~= LocalPlayer then
							return
						end

						if (ClientPlayerData.serverProfile:getState().money or 0) < v7.Cost then
							insufficient(v7.Cost)

							return
						end

						SFX.new(SFX.Sounds.Buy, 0.5)

						local v1, v2 = Remotes.RequestUpgradeGardenSection:Call(v7.Id):Await()

						if v1 and (typeof(v2) == "table" and v2.ok) then
							return
						end

						local v3 = if typeof(v2) == "table" then v2.reason else nil

						notifications:Send(if v3 then v3 else ("Could not buy the %*."):format(v7.DisplayName))
					end)

					continue
				end

				warn((("[GardenBoard] %* has no Attachment \226\128\148 expansion cannot be bought"):format(v7.ModelName)))
			end
		end
	end

	local function hideAuthoredBoards(p1) --[[ hideAuthoredBoards | Line: 209 | Upvalues: t5 (copy), GardenConfig (ref) ]]
		local v1 = t5[p1]

		if not (v1 and v1.Parent) then
			return
		end

		for v2, v3 in v1:QueryDescendants((("BillboardGui#%*"):format(GardenConfig.UpgradeIconName))) do
			v3.Enabled = false
		end

		local v4 = v1:FindFirstChild(GardenConfig.BuyPadName)

		if not v4 then
			return
		end

		local v5 = if v4:IsA("BillboardGui") or v4:IsA("SurfaceGui") then v4 else v4:QueryDescendants("BillboardGui, SurfaceGui")[1]

		if not v5 then
			return
		end

		v5.Enabled = false
	end

	local function buildLockText(p1, p2) --[[ buildLockText | Line: 229 | Upvalues: t (ref) ]]
		local TextLabel = Instance.new("TextLabel")

		TextLabel.Name = t.TextName
		TextLabel.BackgroundTransparency = 1
		TextLabel.AnchorPoint = Vector2.new(0.5, 1)
		TextLabel.Position = t.TextPosition
		TextLabel.Size = t.TextSize
		TextLabel.TextScaled = true
		TextLabel.TextColor3 = t.TextColor
		TextLabel.AutoLocalize = false

		if p2 then
			TextLabel.FontFace = p2
		end

		local UIStroke = Instance.new("UIStroke")

		UIStroke.Color = t.StrokeColor
		UIStroke.Thickness = 3
		UIStroke.Parent = TextLabel
		TextLabel.Parent = p1

		return TextLabel
	end

	local function buildProgressBar(p1, p2) --[[ buildProgressBar | Line: 251 | Upvalues: t (ref) ]]
		local Frame = Instance.new("Frame")

		Frame.Name = t.ProgressBarName
		Frame.AnchorPoint = Vector2.new(0.5, 0)
		Frame.Position = t.BarPosition
		Frame.Size = t.BarSize
		Frame.BackgroundColor3 = t.BarColor
		Frame.BackgroundTransparency = t.BarTransparency
		Frame.BorderSizePixel = 0

		local UICorner = Instance.new("UICorner")

		UICorner.CornerRadius = UDim.new(0.5, 0)
		UICorner.Parent = Frame

		local Fill = Instance.new("Frame")

		Fill.Name = "Fill"
		Fill.Size = UDim2.fromScale(0, 1)
		Fill.BackgroundColor3 = t.FillColor
		Fill.BorderSizePixel = 0

		local UICorner2 = Instance.new("UICorner")

		UICorner2.CornerRadius = UDim.new(0.5, 0)
		UICorner2.Parent = Fill
		Fill.Parent = Frame

		local Counter = Instance.new("TextLabel")

		Counter.Name = "Counter"
		Counter.BackgroundTransparency = 1
		Counter.AnchorPoint = Vector2.new(0.5, 0.5)
		Counter.Position = UDim2.fromScale(0.5, 0.5)
		Counter.Size = UDim2.fromScale(1, 0.8)
		Counter.TextScaled = true
		Counter.TextColor3 = t.TextColor
		Counter.AutoLocalize = false

		if p2 then
			Counter.FontFace = p2
		end

		local UIStroke = Instance.new("UIStroke")

		UIStroke.Color = t.StrokeColor
		UIStroke.Thickness = 2
		UIStroke.Parent = Counter
		Counter.Parent = Frame
		Frame.Parent = p1

		return Fill, Counter
	end

	local function applyLockedFenceInfo(p1) --[[ applyLockedFenceInfo | Line: 302 | Upvalues: t5 (copy), t6 (copy), GardenConfig (ref), buildLockText (copy), t4 (copy), buildProgressBar (copy), ClientPlayerData (ref), t3 (copy) ]]
		local v1 = t5[p1]

		if not (v1 and v1.Parent) then
			return
		end

		local v2 = t6[p1] == true
		local v3 = v1:FindFirstChild(GardenConfig.LockedFenceName)
		local v4 = v1:FindFirstChild(GardenConfig.FencesFolderName)

		if v4 then
			local v5 = if v2 then if v3 == nil then true else false else v2

			for v6, v7 in v4:GetDescendants() do
				if v7:IsA("ParticleEmitter") then
					v7.Enabled = v5
				end
			end
		end

		if not v3 then
			return
		end

		for v8, v9 in v3:GetDescendants() do
			if v9:IsA("ParticleEmitter") then
				v9.Enabled = v2

				continue
			end

			if not v2 and (v9:IsA("BillboardGui") or v9:IsA("SurfaceGui")) then
				v9.Enabled = false
			end
		end

		if not v2 then
			return
		end

		local v10 = v3:FindFirstChild(GardenConfig.LockedSignPartName)
		local v11 = if v10 then v10:FindFirstChildWhichIsA("SurfaceGui") else v10
		local v13 = v11 or (if v10 then v10:FindFirstChildWhichIsA("BillboardGui") else v10)

		if not v13 then
			warn((("[GardenBoard] %* has no %* sign gui"):format(GardenConfig.LockedFenceName, GardenConfig.LockedSignPartName)))

			return
		end

		local RebirthLevel = GardenConfig.Unlock.RebirthLevel
		local v14 = v3:FindFirstChild(GardenConfig.LockedFenceLabelName, true)
		local v15 = if v14 and v14:IsA("TextLabel") then v14 else v3:FindFirstChildWhichIsA("TextLabel", true)
		local v16 = if v15 then v15.FontFace else nil

		if v11 then
			local v17 = buildLockText(v11, v16)

			v17.Text = GardenConfig.LockedFenceText(RebirthLevel)

			local v18 = t4[p1]

			if not v18 then
				v18 = {}
				t4[p1] = v18
			end

			table.insert(v18, v17)
		elseif v15 then
			v15.Text = GardenConfig.LockedFenceText(RebirthLevel)
		end

		local v19, v20 = buildProgressBar(v13, v16)
		local v22 = t4[p1]

		if not v22 then
			v22 = {}
			t4[p1] = v22
		end

		table.insert(v22, v19.Parent)

		local function applyProgress() --[[ applyProgress | Line: 371 | Upvalues: v13 (copy), ClientPlayerData (ref), RebirthLevel (copy), v19 (copy), v20 (copy) ]]
			if not v13.Parent then
				return
			end

			local v1 = ClientPlayerData.serverProfile:getState().rebirthLevel or 0

			v13.Enabled = v1 < RebirthLevel
			v19.Size = UDim2.fromScale(math.clamp(v1 / RebirthLevel, 0, 1), 1)
			v20.Text = ("Rebirth %* / %*"):format(math.min(v1, RebirthLevel), RebirthLevel)
		end

		if v13.Parent then
			local v23 = ClientPlayerData.serverProfile:getState().rebirthLevel or 0

			v13.Enabled = v23 < RebirthLevel
			v19.Size = UDim2.fromScale(math.clamp(v23 / RebirthLevel, 0, 1), 1)
			v20.Text = ("Rebirth %* / %*"):format(math.min(v23, RebirthLevel), RebirthLevel)
		end

		local v25 = t3[p1]

		if not v25 then
			v25 = {}
			t3[p1] = v25
		end

		local serverProfile = ClientPlayerData.serverProfile

		table.insert(v25, serverProfile:subscribe(function(p1) --[[ Line: 389 ]]
			return p1.rebirthLevel
		end, applyProgress))
	end

	local t7 = {}
	local t8 = {}

	local function refresh(p1) --[[ refresh | Line: 398 | Upvalues: t7 (copy), t8 (copy), clearBoards (copy), hideAuthoredBoards (copy), applyLockedFenceInfo (copy), t6 (copy), buildBoards (copy) ]]
		t7[p1] = nil
		t8[p1] = true
		clearBoards(p1)
		hideAuthoredBoards(p1)
		applyLockedFenceInfo(p1)

		if t6[p1] == true then
			buildBoards(p1)
		end

		t8[p1] = nil
	end

	local function queueRefresh(p1) --[[ queueRefresh | Line: 412 | Upvalues: t7 (copy), t8 (copy), refresh (copy) ]]
		if not (t7[p1] or t8[p1]) then
			t7[p1] = true
			task.defer(refresh, p1)
		end
	end

	local function bindGardenRoot(p1, p2) --[[ bindGardenRoot | Line: 420 | Upvalues: t5 (copy), t2 (copy), t7 (copy), t8 (copy), refresh (copy), clearBoards (copy), hideAuthoredBoards (copy), applyLockedFenceInfo (copy), t6 (copy), buildBoards (copy) ]]
		t5[p1] = p2

		local v1 = t2[p1]

		if not v1 then
			v1 = {}
			t2[p1] = v1
		end

		local Rebuild = v1.Rebuild

		if Rebuild then
			Rebuild:Disconnect()
		end

		v1.Rebuild = p2.DescendantAdded:Connect(function(p12) --[[ Line: 431 | Upvalues: p1 (copy), t7 (ref), t8 (ref), refresh (ref) ]]
			if not (p12:IsA("Attachment") or (p12:IsA("BillboardGui") or p12:IsA("SurfaceGui"))) then
				return
			end

			local v1 = p1

			if t7[v1] then
				return
			end

			if t8[v1] then
				return
			end

			t7[v1] = true
			task.defer(refresh, v1)
		end)
		t7[p1] = nil
		t8[p1] = true
		clearBoards(p1)
		hideAuthoredBoards(p1)
		applyLockedFenceInfo(p1)

		if t6[p1] == true then
			buildBoards(p1)
		end

		t8[p1] = nil
	end

	local function unbindGardenRoot(p1) --[[ unbindGardenRoot | Line: 439 | Upvalues: clearBoards (copy), t2 (copy), t5 (copy) ]]
		clearBoards(p1)

		local v1 = t2[p1]

		if v1 then
			for k, v in pairs(v1) do
				v:Disconnect()
			end

			t2[p1] = nil
		end

		t5[p1] = nil
	end

	local function bindTycoon(p1) --[[ bindTycoon | Line: 451 | Upvalues: t6 (copy), LocalPlayer (copy), t5 (copy), t7 (copy), t8 (copy), clearBoards (copy), hideAuthoredBoards (copy), applyLockedFenceInfo (copy), buildBoards (copy), GardenConfig (ref), bindGardenRoot (copy), unbindGardenRoot (copy) ]]
		local Entity = p1.Entity

		if typeof(Entity) ~= "Instance" or not Entity:IsA("Model") then
			return
		end

		local v1 = t6

		v1[Entity] = p1.Owner:Get() == LocalPlayer
		p1.Owner.OnChange:Connect(function(p1) --[[ Line: 459 | Upvalues: t6 (ref), Entity (copy), LocalPlayer (ref), t5 (ref), t7 (ref), t8 (ref), clearBoards (ref), hideAuthoredBoards (ref), applyLockedFenceInfo (ref), buildBoards (ref) ]]
			t6[Entity] = p1 == LocalPlayer

			if not t5[Entity] then
				return
			end

			local v4 = Entity

			t7[v4] = nil
			t8[v4] = true
			clearBoards(v4)
			hideAuthoredBoards(v4)
			applyLockedFenceInfo(v4)

			if t6[v4] == true then
				buildBoards(v4)
			end

			t8[v4] = nil
		end)
		Entity.ChildAdded:Connect(function(p1) --[[ Line: 466 | Upvalues: GardenConfig (ref), bindGardenRoot (ref), Entity (copy) ]]
			if p1.Name ~= GardenConfig.RootName then
				return
			end

			bindGardenRoot(Entity, p1)
		end)
		Entity.ChildRemoved:Connect(function(p1) --[[ Line: 471 | Upvalues: GardenConfig (ref), t5 (ref), Entity (copy), unbindGardenRoot (ref) ]]
			if p1.Name ~= GardenConfig.RootName or t5[Entity] ~= p1 then
				return
			end

			unbindGardenRoot(Entity)
		end)

		local v3 = Entity:FindFirstChild(GardenConfig.RootName)

		if not v3 then
			return
		end

		bindGardenRoot(Entity, v3)
	end

	for k, v in pairs(p1.UECS:GetComponents("TycoonComponent")) do
		bindTycoon(v)
	end

	p1.UECS.OnComponentCreated("TycoonComponent"):Connect(bindTycoon)
end

return t2