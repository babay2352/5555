-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local GymEventConfig = require(ReplicatedStorage.shared.config.GymEventConfig)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local notifications = require(ReplicatedStorage.shared.module.notifications)

return {
	UECS = nil,
	Init = function(p1) --[[ Init | Line: 24 | Upvalues: GymEventConfig (copy), Remotes (copy), notifications (copy) ]]
		if GymEventConfig.Enabled then
			Remotes.GymReferralLimitReached:On(function(p1) --[[ Line: 29 | Upvalues: notifications (ref), GymEventConfig (ref) ]]
				if type(p1) == "number" then
					notifications:Send(GymEventConfig.Earning.Referral.LimitAlert((tostring((os.date("%H:%M", p1))))))
				end
			end)
		end
	end
}