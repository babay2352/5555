-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ContentProvider = game:GetService("ContentProvider")
local GuiService = game:GetService("GuiService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local NpcDialogConfig = require(ReplicatedStorage.shared.config.NpcDialogConfig)
local SFX = require(ReplicatedStorage.client.SFX)
local characterInsidePart = require(ReplicatedStorage.shared.util.characterInsidePart)
local t = {
	UECS = nil,
	Priority = 60,
	Actions = {}
}
local t2 = {}
local v1 = TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local t3 = {
	SFX.Sounds.DialogBlip1,
	SFX.Sounds.DialogBlip2,
	SFX.Sounds.DialogBlip3,
	SFX.Sounds.DialogBlip4,
	SFX.Sounds.DialogBlip5,
	SFX.Sounds.DialogBlip6,
	SFX.Sounds.DialogBlip7
}
local LocalPlayer = Players.LocalPlayer

local function playLetterBlip() --[[ playLetterBlip | Line: 84 | Upvalues: t3 (copy), SFX (copy) ]]
	SFX.PlaySoundWithRandomPitch(t3[math.random(1, #t3)], 0.8, 0.95, 1.05)
end

local function getTemplate(p1) --[[ getTemplate | Line: 90 | Upvalues: ReplicatedStorage (copy) ]]
	local v1 = ReplicatedStorage:FindFirstChild("shared")
	local v2 = if v1 then v1:FindFirstChild("model") else v1
	local v3 = if v2 then v2:FindFirstChild(p1) else v2

	if v3 then
		return v3
	end

	warn((("[DialogController] Template \"%*\" not found in ReplicatedStorage.shared.model"):format(p1)))

	return v3
end

local v2 = nil
local v3 = nil
local v4 = nil
local v5 = nil
local v6 = nil
local v7 = nil
local v8 = nil
local v9 = nil
local t4 = {}
local v10 = nil

local function queueAction(p1) --[[ queueAction | Line: 114 | Upvalues: t (copy), t2 (copy) ]]
	if not p1 or p1 == "END_DIALOG" then
		return
	end

	local v1 = t.Actions[p1]

	if v1 then
		t2.OnClosed(function() --[[ Line: 123 | Upvalues: v1 (copy) ]]
			task.spawn(v1)
		end)
	else
		warn("[DialogController] no handler registered for dialog action:", p1)
	end
end

local function safeCancel(p1) --[[ safeCancel | Line: 128 ]]
	if p1 then
		pcall(task.cancel, p1)
	end
end

local function playReplySound() --[[ playReplySound | Line: 137 | Upvalues: v3 (ref), SFX (copy) ]]
	local v1 = v3 and v3.replySound

	if not v1 then
		return
	end

	local v2 = SFX.Sounds[v1]

	if v2 then
		SFX.PlaySoundWithRandomPitch(v2, 0.8, 0.95, 1.05)
	else
		warn("[DialogController] unknown replySound:", v1)
	end
end

local function resolveAdornee(p1) --[[ resolveAdornee | Line: 151 ]]
	return p1:FindFirstChild("Head") or (p1.PrimaryPart or p1:FindFirstChildWhichIsA("BasePart", true))
end

local t5 = {}

local function npcBodyBounds(p1) --[[ npcBodyBounds | Line: 167 ]]
	local v1 = nil
	local v2 = nil

	for v3, v4 in p1:GetDescendants() do
		if v4:IsA("BasePart") and (v4.Name ~= "WalkTrigger" and v4.Name ~= "DialogBillboardAnchor") then
			local v5 = v4.CFrame
			local Size = v4.Size
			local v6 = math.abs(v5.XVector.X) * Size.X
			local v7 = v6 + math.abs(v5.YVector.X) * Size.Y
			local v8 = v7 + math.abs(v5.ZVector.X) * Size.Z
			local v9 = math.abs(v5.XVector.Y) * Size.X
			local v10 = v9 + math.abs(v5.YVector.Y) * Size.Y
			local v11 = v10 + math.abs(v5.ZVector.Y) * Size.Z
			local v12 = math.abs(v5.XVector.Z) * Size.X
			local v13 = v12 + math.abs(v5.YVector.Z) * Size.Y
			local v15 = Vector3.new(v8, v11, v13 + math.abs(v5.ZVector.Z) * Size.Z) / 2
			local Position = v5.Position

			if v1 then
				v1 = v1:Min(Position - v15)
			else
				v1 = Position - v15
			end

			if v2 then
				v2 = v2:Max(Position + v15)

				continue
			end

			v2 = Position + v15
		end
	end

	return v1, v2
end

local function createBillboardAnchor(p1) --[[ createBillboardAnchor | Line: 189 | Upvalues: npcBodyBounds (copy) ]]
	local v1, v2 = npcBodyBounds(p1)

	if v1 and v2 then
		local DialogBillboardAnchor = Instance.new("Part")

		DialogBillboardAnchor.Name = "DialogBillboardAnchor"
		DialogBillboardAnchor.Size = Vector3.new(0.1, 0.1, 0.1)
		DialogBillboardAnchor.Transparency = 1
		DialogBillboardAnchor.CanCollide = false
		DialogBillboardAnchor.CanQuery = false
		DialogBillboardAnchor.CanTouch = false
		DialogBillboardAnchor.CastShadow = false
		DialogBillboardAnchor.Anchored = true
		DialogBillboardAnchor.CFrame = p1.Head.CFrame
		DialogBillboardAnchor.Parent = p1

		return DialogBillboardAnchor
	end

	warn("[DialogController] no body parts to anchor billboards to for", p1.Name)

	return nil
end

local function getOrCreateBillboardAnchor(p1) --[[ getOrCreateBillboardAnchor | Line: 212 | Upvalues: t5 (copy), createBillboardAnchor (copy) ]]
	local v1 = t5[p1]

	if v1 and v1.Parent then
		return v1
	end

	local DialogBillboardAnchor = p1:FindFirstChild("DialogBillboardAnchor")

	if DialogBillboardAnchor and DialogBillboardAnchor:IsA("BasePart") then
		t5[p1] = DialogBillboardAnchor

		return DialogBillboardAnchor
	end

	local v2 = createBillboardAnchor(p1)

	if v2 then
		t5[p1] = v2
	end

	return v2
end

local function zoomInForDialog() --[[ zoomInForDialog | Line: 233 | Upvalues: v7 (ref), TweenService (copy), v1 (copy) ]]
	local CurrentCamera = workspace.CurrentCamera

	if not CurrentCamera then
		return
	end

	if v7 == nil then
		v7 = CurrentCamera.FieldOfView
	end

	TweenService:Create(CurrentCamera, v1, {
		FieldOfView = 60
	}):Play()
end

local function restoreFov() --[[ restoreFov | Line: 244 | Upvalues: v7 (ref), TweenService (copy), v1 (copy) ]]
	local CurrentCamera = workspace.CurrentCamera

	if not (CurrentCamera and v7) then
		v7 = nil

		return
	end

	TweenService:Create(CurrentCamera, v1, {
		FieldOfView = v7
	}):Play()
	v7 = nil
end

local function parseSegments(p1) --[[ parseSegments | Line: 255 ]]
	local count = 1
	local v1 = ""
	local t = {}

	while count <= #p1 do
		local v2 = p1:sub(count, count)

		if v2 == "<" and p1:sub(count, count + 1) ~= "</" then
			if v1 ~= "" then
				table.insert(t, {
					prefix = "",
					suffix = "",
					text = v1
				})
				v1 = ""
			end

			local v3 = ""

			while count <= #p1 and (p1:sub(count, count) == "<" and p1:sub(count, count + 1) ~= "</") do
				local v4 = p1:find(">", count, true)

				if not v4 then
					break
				end

				v3 = v3 .. p1:sub(count, v4)
				count = v4 + 1
			end

			local v5 = ""

			while count <= #p1 and p1:sub(count, count) ~= "<" do
				v5 = v5 .. p1:sub(count, count)
				count = count + 1
			end

			local v6 = ""

			while count <= #p1 and p1:sub(count, count + 1) == "</" do
				local v7 = p1:find(">", count, true)

				if not v7 then
					break
				end

				v6 = v6 .. p1:sub(count, v7)
				count = v7 + 1
			end

			table.insert(t, {
				text = v5,
				prefix = v3,
				suffix = v6
			})
		else
			if v2 == "<" then
				local v8 = p1:find(">", count, true)

				count = p1:find(">", count, true) and v8 + 1 or count + 1

				continue
			end

			count = count + 1
			v1 = v1 .. v2
		end
	end

	if v1 ~= "" then
		table.insert(t, {
			prefix = "",
			suffix = "",
			text = v1
		})
	end

	return t
end

local function runTypewriter(p1, p2, p3) --[[ runTypewriter | Line: 314 | Upvalues: parseSegments (copy), v4 (ref), t3 (copy), SFX (copy) ]]
	p1.Text = ""

	local v1 = ""

	for v2, v3 in parseSegments(p2) do
		for i = 1, #v3.text do
			if not v4 then
				return
			end

			p1.Text = v1 .. v3.prefix .. v3.text:sub(1, i) .. v3.suffix

			if v3.text:sub(i, i) ~= " " then
				SFX.PlaySoundWithRandomPitch(t3[math.random(1, #t3)], 0.8, 0.95, 1.05)
			end

			task.wait(0.03)
		end

		v1 = v1 .. v3.prefix .. v3.text .. v3.suffix
	end

	p1.Text = p2

	if not v4 then
		return
	end

	p3()
end

local function finishTypewriter(p1, p2, p3) --[[ finishTypewriter | Line: 339 | Upvalues: v9 (ref) ]]
	local v1 = v9

	if v1 then
		pcall(task.cancel, v1)
	end

	v9 = nil
	p1.Text = p2
	p3()
end

local function startTypewriter(p1, p2, p3) --[[ startTypewriter | Line: 346 | Upvalues: v9 (ref), runTypewriter (copy) ]]
	local v1 = v9

	if v1 then
		pcall(task.cancel, v1)
	end

	v9 = nil
	v9 = task.spawn(function() --[[ Line: 349 | Upvalues: runTypewriter (ref), p1 (copy), p2 (copy), p3 (copy), v9 (ref) ]]
		runTypewriter(p1, p2, p3)
		v9 = nil
	end)
end

local function buildNpcBillboard(p1) --[[ buildNpcBillboard | Line: 356 | Upvalues: ReplicatedStorage (copy), t5 (copy), createBillboardAnchor (copy) ]]
	local v1 = ReplicatedStorage:FindFirstChild("shared")
	local v2 = if v1 then v1:FindFirstChild("model") else v1
	local v3 = if v2 then v2:FindFirstChild("NpcSpeechBillboardTemplate") else v2

	if not v3 then
		warn("[DialogController] Template \"NpcSpeechBillboardTemplate\" not found in ReplicatedStorage.shared.model")
	end

	if not v3 then
		return nil, nil
	end

	local v4 = t5[p1]
	local v5, v6

	if v4 and v4.Parent then
		v5 = v4
		v6 = v3
	else
		local DialogBillboardAnchor = p1:FindFirstChild("DialogBillboardAnchor")

		if DialogBillboardAnchor and DialogBillboardAnchor:IsA("BasePart") then
			t5[p1] = DialogBillboardAnchor
			v5 = DialogBillboardAnchor
			v6 = v3
		else
			v6 = v3

			local v7 = createBillboardAnchor(p1)

			if v7 then
				t5[p1] = v7
			end

			v5 = v7
		end
	end

	if not v5 then
		return nil, nil
	end

	local NpcSpeechBillboardTemplate = v5:FindFirstChild("NpcSpeechBillboardTemplate")

	if NpcSpeechBillboardTemplate then
		NpcSpeechBillboardTemplate:Destroy()
	end

	local v8 = v6:Clone()

	v8.Adornee = v5
	v8.Parent = v5

	local Bg = v8:FindFirstChild("Bg")

	return v8, if Bg then Bg:FindFirstChild("SpeechText") else Bg
end

local function getOptionsRowTemplate(p1) --[[ getOptionsRowTemplate | Line: 382 ]]
	local Layout = p1:FindFirstChild("Layout")

	return if Layout then Layout:FindFirstChild("RowTemplate") else Layout
end

local v11 = nil

local function hideOptionsBillboard() --[[ hideOptionsBillboard | Line: 389 | Upvalues: v5 (ref) ]]
	if not (v5 and v5.Parent) then
		v5 = nil

		return
	end

	v5:Destroy()
	v5 = nil
end

local function showOptions(p1) --[[ showOptions | Line: 396 | Upvalues: ReplicatedStorage (copy), LocalPlayer (copy), v5 (ref), queueAction (copy), t2 (copy), v3 (ref), v11 (ref), GuiService (copy) ]]
	local v1 = ReplicatedStorage:FindFirstChild("shared")
	local v2 = if v1 then v1:FindFirstChild("model") else v1
	local v32 = if v2 then v2:FindFirstChild("PlayerDialogOptionsBillboard") else v2

	if not v32 then
		warn("[DialogController] Template \"PlayerDialogOptionsBillboard\" not found in ReplicatedStorage.shared.model")
	end

	local Character = LocalPlayer.Character
	local PlayerGui = LocalPlayer:FindFirstChildOfClass("PlayerGui")

	if not (v32 and (Character and PlayerGui)) then
		return
	end

	local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")

	if not HumanoidRootPart then
		return
	end

	if v5 and v5.Parent then
		v5:Destroy()
	end

	v5 = nil

	local v4 = v32:Clone()

	v4.Adornee = HumanoidRootPart
	v4.Parent = PlayerGui
	v5 = v4

	local Layout = v4:FindFirstChild("Layout")
	local v52 = Layout and Layout:FindFirstChild("RowTemplate")
	local Layout2 = v4:FindFirstChild("Layout")

	if not (v52 and Layout2) then
		warn("[DialogController] PlayerDialogOptionsBillboard missing Layout.RowTemplate")

		return
	end

	v52.Visible = false

	for v6, v7 in p1 do
		local v8 = v52:Clone()

		v8.Name = "Row" .. v6
		v8.LayoutOrder = v6
		v8.Visible = true
		v8.Selectable = true
		v8:AddTag("VFX_HoverButtonGrow")
		v8:AddTag("VFX_UIClickButton")

		local Num = v8:FindFirstChild("Num")
		local Text = v8:FindFirstChild("Text")

		if Num then
			Num.Text = "#" .. v6
		end

		if Text then
			Text.Text = v7.text
		end

		v8.Activated:Connect(function() --[[ Line: 451 | Upvalues: v7 (copy), queueAction (ref), t2 (ref), v3 (ref), v11 (ref) ]]
			if v7.action then
				queueAction(v7.action)
				t2.CloseWithFarewell()

				return
			end

			if not (v7.nextNodeId and v3) then
				return
			end

			v11(v7.nextNodeId)
		end)
		v8.SelectionOrder = v6
		v8.Parent = Layout2
	end

	task.delay(1, function() --[[ Line: 467 | Upvalues: GuiService (ref), Layout2 (copy) ]]
		GuiService:Select(Layout2)
	end)
end

v11 = function(p1) --[[ Line: 473 | Upvalues: v3 (ref), v4 (ref), SFX (copy), v2 (ref), v5 (ref), queueAction (copy), t2 (copy), showOptions (copy), v9 (ref), runTypewriter (copy) ]]
	if not (v3 and v4) then
		return
	end

	local v1 = v3.nodes[p1]

	if not v1 then
		warn("[DialogController] unknown node:", p1)

		return
	end

	local v22 = v3 and v3.replySound

	if v22 then
		local v32 = SFX.Sounds[v22]

		if v32 then
			SFX.PlaySoundWithRandomPitch(v32, 0.8, 0.95, 1.05)
		else
			warn("[DialogController] unknown replySound:", v22)
		end
	end

	local Bg = v4:FindFirstChild("Bg")
	local v42 = if Bg then Bg:FindFirstChild("NpcName") else Bg
	local v52 = Bg and Bg:FindFirstChild("SpeechText")

	if v42 then
		v42.Text = v3.displayName or (if v2 then v2.Name or "NPC" else "NPC")
	end

	if v5 and v5.Parent then
		v5:Destroy()
	end

	v5 = nil

	local v7 = v1.options or {}
	local v8 = if #v7 == 0 then true else false

	local function onTypewriterDone() --[[ onTypewriterDone | Line: 499 | Upvalues: v8 (copy), queueAction (ref), v1 (copy), t2 (ref), showOptions (ref), v7 (copy) ]]
		if v8 then
			task.delay(0.6, function() --[[ Line: 501 | Upvalues: queueAction (ref), v1 (ref), t2 (ref) ]]
				queueAction(v1.action)
				t2.CloseWithFarewell()
			end)
		else
			showOptions(v7)
		end
	end

	if not v52 then
		return
	end

	local v92 = nil

	v92 = v52.Activated:Connect(function() --[[ Line: 512 | Upvalues: v9 (ref), v52 (copy), v1 (copy), onTypewriterDone (copy), v8 (copy), queueAction (ref), t2 (ref), showOptions (ref), v7 (copy), v92 (ref) ]]
		if v9 then
			local text = v1.text
			local v2 = v9

			if v2 then
				pcall(task.cancel, v2)
			end

			v9 = nil
			v52.Text = text

			if v8 then
				task.delay(0.6, function() --[[ Line: 501 | Upvalues: queueAction (ref), v1 (ref), t2 (ref) ]]
					queueAction(v1.action)
					t2.CloseWithFarewell()
				end)
			else
				showOptions(v7)
			end
		end

		if not v92 then
			return
		end

		v92:Disconnect()
		v92 = nil
	end)

	local text = v1.text

	local function f10() --[[ Line: 522 | Upvalues: v8 (copy), queueAction (ref), v1 (copy), t2 (ref), showOptions (ref), v7 (copy), v92 (ref) ]]
		if v8 then
			task.delay(0.6, function() --[[ Line: 501 | Upvalues: queueAction (ref), v1 (ref), t2 (ref) ]]
				queueAction(v1.action)
				t2.CloseWithFarewell()
			end)
		else
			showOptions(v7)
		end

		if not v92 then
			return
		end

		v92:Disconnect()
		v92 = nil
	end

	local v11 = v9

	if v11 then
		pcall(task.cancel, v11)
	end

	v9 = nil
	v9 = task.spawn(function() --[[ Line: 349 | Upvalues: runTypewriter (ref), v52 (copy), text (copy), f10 (copy), v9 (ref) ]]
		runTypewriter(v52, text, f10)
		v9 = nil
	end)
end

local function startDistanceCheck(p1, p2) --[[ startDistanceCheck | Line: 533 | Upvalues: v8 (ref), v2 (ref), t2 (copy), LocalPlayer (copy) ]]
	local v1 = v8

	if v1 then
		pcall(task.cancel, v1)
	end

	v8 = task.spawn(function() --[[ Line: 535 | Upvalues: v2 (ref), p1 (copy), t2 (ref), LocalPlayer (ref), p2 (copy), v8 (ref) ]]
		repeat
			if v2 ~= p1 then
				v8 = nil

				return
			end

			task.wait(0.5)

			local v1, v22

			if v2 and p1.Parent then
				local Character = LocalPlayer.Character

				v1 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character
				v22 = p1.PrimaryPart or p1:FindFirstChildWhichIsA("BasePart", true)

				if not (v1 and v22) then
					v8 = nil

					return
				end
			else
				t2.CloseWithFarewell()
				v8 = nil

				return
			end
		until p2 < (v1.Position - v22.Position).Magnitude

		t2.CloseWithFarewell()
		v8 = nil
	end)
end

function t2.Open(p1) --[[ Open | Line: 558 | Upvalues: NpcDialogConfig (copy), t2 (copy), v2 (ref), v3 (ref), t5 (copy), createBillboardAnchor (copy), v6 (ref), zoomInForDialog (copy), buildNpcBillboard (copy), v4 (ref), v10 (ref), v11 (ref), v8 (ref), LocalPlayer (copy) ]]
	local v1 = NpcDialogConfig[p1.Name]

	if not v1 then
		warn("[DialogController] no NpcDialogConfig entry for \'" .. p1.Name .. "\'")

		return
	end

	t2.Close()
	v2 = p1
	v3 = v1

	local v22 = t5[p1]
	local v32

	if v22 and v22.Parent then
		v32 = v22
	else
		local DialogBillboardAnchor = p1:FindFirstChild("DialogBillboardAnchor")

		if DialogBillboardAnchor and DialogBillboardAnchor:IsA("BasePart") then
			t5[p1] = DialogBillboardAnchor
			v32 = DialogBillboardAnchor
		else
			local v42 = createBillboardAnchor(p1)

			if v42 then
				t5[p1] = v42
			end

			v32 = v42
		end
	end

	local v5 = if v32 then v32:FindFirstChild("NpcNameplate") else v32

	if v5 then
		v5.Enabled = false
	end

	v6 = v5
	zoomInForDialog()
	v4 = buildNpcBillboard(p1)

	local AnimationController = p1:FindFirstChildOfClass("AnimationController")

	if not AnimationController then
		local Humanoid = p1:FindFirstChildOfClass("Humanoid")

		AnimationController = if Humanoid then Humanoid:FindFirstChildOfClass("Animator") else Humanoid
	end

	if AnimationController then
		local Animation = Instance.new("Animation")

		Animation.AnimationId = "rbxassetid://126510598329946"
		v10 = AnimationController:LoadAnimation(Animation)

		if v10 then
			v10:Play()
		end
	end

	v11(v1.startNodeId)

	local v7 = v1.maxDistance or 5
	local v82 = v8

	if v82 then
		pcall(task.cancel, v82)
	end

	v8 = task.spawn(function() --[[ Line: 535 | Upvalues: v2 (ref), p1 (copy), t2 (ref), LocalPlayer (ref), v7 (copy), v8 (ref) ]]
		repeat
			if v2 ~= p1 then
				v8 = nil

				return
			end

			task.wait(0.5)

			local v1, v22

			if v2 and p1.Parent then
				local Character = LocalPlayer.Character

				v1 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character
				v22 = p1.PrimaryPart or p1:FindFirstChildWhichIsA("BasePart", true)

				if not (v1 and v22) then
					v8 = nil

					return
				end
			else
				t2.CloseWithFarewell()
				v8 = nil

				return
			end
		until v7 < (v1.Position - v22.Position).Magnitude

		t2.CloseWithFarewell()
		v8 = nil
	end)
end
function t2.CloseWithFarewell() --[[ CloseWithFarewell | Line: 602 | Upvalues: v8 (ref), v9 (ref), v3 (ref), v4 (ref), v5 (ref), SFX (copy), runTypewriter (copy), t2 (copy) ]]
	local v1 = v8

	if v1 then
		pcall(task.cancel, v1)
	end

	v8 = nil

	local v2 = v9

	if v2 then
		pcall(task.cancel, v2)
	end

	v9 = nil

	local v32 = v3 and v3.farewell

	if not (v32 and (v4 and v4.Parent)) then
		t2.Close()

		return
	end

	local Bg = v4:FindFirstChild("Bg")
	local v42 = Bg and Bg:FindFirstChild("SpeechText")
	local v52 = if Bg then Bg:FindFirstChild("NpcName") else Bg

	if not v42 then
		t2.Close()

		return
	end

	if v5 and v5.Parent then
		v5:Destroy()
	end

	v5 = nil

	if v52 and v3 then
		v52.Text = v3.displayName or ""
	end

	local v6 = v3 and v3.replySound

	if v6 then
		local v7 = SFX.Sounds[v6]

		if v7 then
			SFX.PlaySoundWithRandomPitch(v7, 0.8, 0.95, 1.05)
		else
			warn("[DialogController] unknown replySound:", v6)
		end
	end

	v9 = task.spawn(function() --[[ Line: 619 | Upvalues: runTypewriter (ref), v42 (copy), v32 (copy), t2 (ref), v9 (ref) ]]
		runTypewriter(v42, v32, function() --[[ Line: 620 | Upvalues: t2 (ref) ]]
			task.wait(1.2)
			t2.Close()
		end)
		v9 = nil
	end)
end
function t2.Close() --[[ Close | Line: 632 | Upvalues: v9 (ref), v8 (ref), v10 (ref), v4 (ref), v5 (ref), v6 (ref), v7 (ref), TweenService (copy), v1 (copy), v2 (ref), v3 (ref), t4 (ref) ]]
	local v12 = v9

	if v12 then
		pcall(task.cancel, v12)
	end

	v9 = nil

	local v22 = v8

	if v22 then
		pcall(task.cancel, v22)
	end

	v8 = nil

	if v10 then
		v10:Stop()
		v10 = nil
	end

	if v4 and v4.Parent then
		v4:Destroy()
	end

	v4 = nil

	if v5 and v5.Parent then
		v5:Destroy()
	end

	v5 = nil

	if v6 then
		v6.Enabled = true
	end

	v6 = nil

	local CurrentCamera = workspace.CurrentCamera

	if CurrentCamera and v7 then
		TweenService:Create(CurrentCamera, v1, {
			FieldOfView = v7
		}):Play()
	end

	v7 = nil
	v2 = nil
	v3 = nil

	local v32 = t4

	t4 = {}

	for v42, v52 in v32 do
		task.spawn(v52)
	end
end
function t2.OnClosed(p1) --[[ OnClosed | Line: 667 | Upvalues: t4 (ref) ]]
	table.insert(t4, p1)
end

local function createNameplate(p1, p2, p3) --[[ createNameplate | Line: 673 | Upvalues: ReplicatedStorage (copy) ]]
	local v1 = ReplicatedStorage:FindFirstChild("shared")
	local v2 = if v1 then v1:FindFirstChild("model") else v1
	local v3 = if v2 then v2:FindFirstChild("NpcNameplateTemplate") else v2

	if not v3 then
		warn("[DialogController] Template \"NpcNameplateTemplate\" not found in ReplicatedStorage.shared.model")
	end

	if not v3 then
		return
	end

	local NpcNameplate = p2:FindFirstChild("NpcNameplate")

	if NpcNameplate then
		NpcNameplate:Destroy()
	end

	local NpcNameplate2 = v3:Clone()

	NpcNameplate2.Name = "NpcNameplate"
	NpcNameplate2.Adornee = p2
	NpcNameplate2.Parent = p2

	local NameLabel = NpcNameplate2:FindFirstChild("NameLabel")

	if not NameLabel then
		return
	end

	NameLabel.Text = p3 and p3.displayName or p1.Name
end

local function buildWalkTrigger(p1, p2) --[[ buildWalkTrigger | Line: 700 | Upvalues: RunService (copy), characterInsidePart (copy), v2 (ref), t2 (copy) ]]
	local v1 = false
	local v22 = RunService.Heartbeat:Connect(function() --[[ Line: 702 | Upvalues: characterInsidePart (ref), p2 (copy), v1 (ref), v2 (ref), t2 (ref), p1 (copy) ]]
		local v12 = characterInsidePart(p2)

		if v12 and (not v1 and v2 == nil) then
			t2.Open(p1)
		end

		v1 = v12
	end)

	return function() --[[ Line: 711 | Upvalues: v22 (copy) ]]
		v22:Disconnect()
	end
end

local function buildPrompt(p1, p2) --[[ buildPrompt | Line: 717 | Upvalues: NpcDialogConfig (copy), t2 (copy) ]]
	local v1 = NpcDialogConfig[p1.Name]
	local ProximityPrompt = Instance.new("ProximityPrompt")

	ProximityPrompt.Style = Enum.ProximityPromptStyle.Custom
	ProximityPrompt.ActionText = "Talk"
	ProximityPrompt.ObjectText = v1 and v1.displayName or p1.Name
	ProximityPrompt.HoldDuration = 0
	ProximityPrompt.MaxActivationDistance = v1 and v1.maxDistance or 5
	ProximityPrompt.RequiresLineOfSight = false
	ProximityPrompt.Parent = p2
	ProximityPrompt.Triggered:Connect(function() --[[ Line: 729 | Upvalues: ProximityPrompt (copy), t2 (ref), p1 (copy) ]]
		ProximityPrompt.Enabled = false
		t2.Open(p1)
		t2.OnClosed(function() --[[ Line: 732 | Upvalues: ProximityPrompt (ref) ]]
			ProximityPrompt.Enabled = true
		end)
	end)

	return function() --[[ Line: 737 | Upvalues: ProximityPrompt (copy) ]]
		ProximityPrompt:Destroy()
	end
end

local function buildNpc(p1, p2, p3) --[[ buildNpc | Line: 745 | Upvalues: NpcDialogConfig (copy), RunService (copy), characterInsidePart (copy), v2 (ref), t2 (copy), buildPrompt (copy), t5 (copy), createBillboardAnchor (copy), createNameplate (copy) ]]
	local v22

	if p3 then
		local v3 = false
		local v4 = RunService.Heartbeat:Connect(function() --[[ Line: 702 | Upvalues: characterInsidePart (ref), p3 (copy), v3 (ref), v2 (ref), t2 (ref), p1 (copy) ]]
			local v12 = characterInsidePart(p3)

			if v12 and (not v3 and v2 == nil) then
				t2.Open(p1)
			end

			v3 = v12
		end)

		v22 = function() --[[ Line: 711 | Upvalues: v4 (copy) ]]
			v4:Disconnect()
		end
	else
		v22 = buildPrompt(p1, p2)
	end

	local v5 = t5[p1]
	local v6

	if v5 and v5.Parent then
		v6 = v5
	else
		local DialogBillboardAnchor = p1:FindFirstChild("DialogBillboardAnchor")

		if DialogBillboardAnchor and DialogBillboardAnchor:IsA("BasePart") then
			t5[p1] = DialogBillboardAnchor
			v6 = DialogBillboardAnchor
		else
			local v7 = createBillboardAnchor(p1)

			if v7 then
				t5[p1] = v7
			end

			v6 = v7
		end
	end

	if not v6 then
		return v22
	end

	local ok, result = pcall(createNameplate, p1, v6, NpcDialogConfig[p1.Name])

	if ok then
		return v22
	end

	warn((("[DialogController] createNameplate failed for %*: %*"):format(p1.Name, result)))

	return v22
end

local t6 = {}

local function ensureNpc(p1) --[[ ensureNpc | Line: 767 | Upvalues: t6 (copy), NpcDialogConfig (copy), buildNpc (copy) ]]
	if p1:IsA("Model") and not t6[p1] then
		t6[p1] = true
		task.spawn(function() --[[ Line: 772 | Upvalues: NpcDialogConfig (ref), p1 (copy), buildNpc (ref), t6 (ref) ]]
			local v1 = NpcDialogConfig[p1.Name]
			local v22 = if v1 then v1.walkTrigger == true else v1

			while p1:IsDescendantOf(game) do
				local v3, v4
				local v5 = p1
				local Head = v5:FindFirstChild("Head")

				v3 = Head or (v5.PrimaryPart or v5:FindFirstChildWhichIsA("BasePart", true))

				local v7 = if v22 then p1:FindFirstChild("WalkTrigger") else nil

				v4 = if v7 and v7:IsA("BasePart") then v7 else nil

				if v3 and (not v22 or v4) then
					local v8 = buildNpc(p1, v3, v4)

					while p1:IsDescendantOf(game) and (v3:IsDescendantOf(game) and (not v4 or v4:IsDescendantOf(game))) do
						task.wait(1)
					end

					v8()
				else
					task.wait(0.5)
				end
			end

			t6[p1] = nil
		end)
	end
end

function t.Init(p1) --[[ Init | Line: 799 | Upvalues: ContentProvider (copy), CollectionService (copy), t6 (copy), NpcDialogConfig (copy), buildNpc (copy), ensureNpc (copy) ]]
	task.spawn(function() --[[ Line: 800 | Upvalues: ContentProvider (ref) ]]
		local t = {}

		for v1, v2 in { "rbxassetid://126510598329946", "rbxassetid://113230797146303" } do
			local Animation = Instance.new("Animation")

			Animation.AnimationId = v2
			table.insert(t, Animation)
		end

		ContentProvider:PreloadAsync(t)

		for v3, v4 in t do
			v4:Destroy()
		end
	end)

	for v1, v2 in CollectionService:GetTagged("DialogNpc") do
		if v2:IsA("Model") and not t6[v2] then
			t6[v2] = true
			task.spawn(function() --[[ Line: 772 | Upvalues: NpcDialogConfig (ref), v2 (copy), buildNpc (ref), t6 (ref) ]]
				local v1 = NpcDialogConfig[v2.Name]
				local v22 = if v1 then v1.walkTrigger == true else v1

				while v2:IsDescendantOf(game) do
					local v3, v4
					local v5 = v2
					local Head = v5:FindFirstChild("Head")

					v3 = Head or (v5.PrimaryPart or v5:FindFirstChildWhichIsA("BasePart", true))

					local v7 = if v22 then v2:FindFirstChild("WalkTrigger") else nil

					v4 = if v7 and v7:IsA("BasePart") then v7 else nil

					if v3 and (not v22 or v4) then
						local v8 = buildNpc(v2, v3, v4)

						while v2:IsDescendantOf(game) and (v3:IsDescendantOf(game) and (not v4 or v4:IsDescendantOf(game))) do
							task.wait(1)
						end

						v8()
					else
						task.wait(0.5)
					end
				end

				t6[v2] = nil
			end)
		end
	end

	CollectionService:GetInstanceAddedSignal("DialogNpc"):Connect(ensureNpc)
end

return t