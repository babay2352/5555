-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

require(ReplicatedStorage.shared.UECS.GlobalTypes)
require(ReplicatedStorage.shared.UECS.Components.TycoonStand)

local UECS = require(ReplicatedStorage.shared.UECS.UECS)

return {
	UECS = nil,
	Init = function(p1) --[[ Init | Line: 24 | Upvalues: Players (copy), UECS (copy) ]]
		local LocalPlayer = Players.LocalPlayer

		UECS.OnComponentCreated("TycoonStand"):Connect(function(p1) --[[ Line: 27 | Upvalues: LocalPlayer (copy) ]]
			local t = {}
			local v1 = false

			local function setSurfaceEnabled(p1, p2) --[[ setSurfaceEnabled | Line: 31 ]]
				local SurfaceGui = p1:FindFirstChild("SurfaceGui")

				if not (SurfaceGui and SurfaceGui:IsA("SurfaceGui")) then
					return
				end

				SurfaceGui.Enabled = p2
				SurfaceGui.MaxDistance = 75
			end

			local function watchButton(p1) --[[ watchButton | Line: 39 | Upvalues: t (copy) ]]
				local SurfaceGui = p1:FindFirstChild("SurfaceGui")
				local v2

				if SurfaceGui and SurfaceGui:IsA("SurfaceGui") then
					SurfaceGui.Enabled = false
					SurfaceGui.MaxDistance = 75
				end

				v2 = p1.ChildAdded
				table.insert(t, v2:Connect(function(p1) --[[ Line: 45 ]]
					if not p1:IsA("SurfaceGui") or p1.Name ~= "SurfaceGui" then
						return
					end

					p1.Enabled = false
				end))
			end

			local function hideForNonOwner() --[[ hideForNonOwner | Line: 53 | Upvalues: v1 (ref), p1 (copy), t (copy) ]]
				if v1 then
					return
				end

				local Entity = p1.Entity

				if typeof(Entity) ~= "Instance" then
					return
				end

				v1 = true

				local CollectButton = Entity:FindFirstChild("CollectButton")

				if CollectButton then
					local SurfaceGui = CollectButton:FindFirstChild("SurfaceGui")

					if SurfaceGui and SurfaceGui:IsA("SurfaceGui") then
						SurfaceGui.Enabled = false
						SurfaceGui.MaxDistance = 75
					end

					table.insert(t, CollectButton.ChildAdded:Connect(function(p1) --[[ Line: 45 ]]
						if not p1:IsA("SurfaceGui") or p1.Name ~= "SurfaceGui" then
							return
						end

						p1.Enabled = false
					end))
				end

				local v2 = t

				local function f3(p1) --[[ Line: 70 | Upvalues: t (ref) ]]
					if p1.Name ~= "CollectButton" then
						return
					end

					local SurfaceGui = p1:FindFirstChild("SurfaceGui")

					if SurfaceGui and SurfaceGui:IsA("SurfaceGui") then
						SurfaceGui.Enabled = false
						SurfaceGui.MaxDistance = 75
					end

					table.insert(t, p1.ChildAdded:Connect(function(p1) --[[ Line: 45 ]]
						if not p1:IsA("SurfaceGui") or p1.Name ~= "SurfaceGui" then
							return
						end

						p1.Enabled = false
					end))
				end

				table.insert(v2, Entity.ChildAdded:Connect(f3))
			end

			local function stopHiding() --[[ stopHiding | Line: 78 | Upvalues: v1 (ref), t (copy), p1 (copy) ]]
				v1 = false

				for v12, v2 in t do
					v2:Disconnect()
				end

				table.clear(t)

				local Entity = p1.Entity

				if typeof(Entity) ~= "Instance" then
					return
				end

				local CollectButton = Entity:FindFirstChild("CollectButton")

				if not CollectButton then
					return
				end

				local SurfaceGui = CollectButton:FindFirstChild("SurfaceGui")

				if not (SurfaceGui and SurfaceGui:IsA("SurfaceGui")) then
					return
				end

				SurfaceGui.Enabled = true
				SurfaceGui.MaxDistance = 75
			end

			if p1.Owner:Get() == LocalPlayer then
				stopHiding()
			else
				hideForNonOwner()
			end

			p1.Owner.OnChange:Connect(function(p1) --[[ Line: 101 | Upvalues: LocalPlayer (ref), stopHiding (copy), hideForNonOwner (copy) ]]
				if p1 == LocalPlayer then
					stopHiding()
				else
					hideForNonOwner()
				end
			end)
		end)
	end
}