-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local AlienEventConfig = require(ReplicatedStorage.shared.config.AlienEventConfig)
local AlienOceanConfig = require(ReplicatedStorage.shared.config.AlienOceanConfig)
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local FishConfig = require(ReplicatedStorage.shared.config.FishConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local t = {
	UECS = nil
}
local Laboratory = AlienEventConfig.Laboratory
local ScanDisplayTag = Laboratory.ScanDisplayTag
local t2 = {}

local function imageOf(p1) --[[ imageOf | Line: 58 | Upvalues: FishConfig (copy) ]]
	local v1 = FishConfig[p1]
	local v2 = if v1 then v1.Image else v1

	if type(v2) == "string" then
		return v2
	end

	return ""
end

local function roster() --[[ roster | Line: 67 | Upvalues: AlienOceanConfig (copy) ]]
	local t = {}

	for v1, v2 in AlienOceanConfig.Fish do
		local t2 = {
			kind = v2.Kind
		}

		t2.base = AlienOceanConfig.ScanCoinsByKind[v2.Kind] or v2.ScanCoins
		table.insert(t, t2)
	end

	table.sort(t, function(p1, p2) --[[ Line: 75 ]]
		if p1.base == p2.base then
			return p1.kind < p2.kind
		end

		return p1.base < p2.base
	end)

	return t
end

local function payoutStage() --[[ payoutStage | Line: 84 | Upvalues: AlienEventConfig (copy), ClientPlayerData (copy) ]]
	return AlienEventConfig.GetPlayerStage(ClientPlayerData.serverProfile:getState(), "ResearchPayout")
end

local function render(p1, p2) --[[ render | Line: 88 | Upvalues: Laboratory (copy), AlienEventConfig (copy) ]]
	for v1, v2 in p1 do
		v2.label.Text = Laboratory.ScanDisplayText(AlienEventConfig.GetResearchPayout(v2.base, p2))
	end
end

local function build(p1) --[[ build | Line: 98 | Upvalues: t2 (copy), Laboratory (copy), roster (copy), FishConfig (copy), render (copy), payoutStage (copy) ]]
	if t2[p1] then
		return
	end

	local v1 = p1:FindFirstChild(Laboratory.ScanDisplayFrameName)

	if not v1 then
		warn((("[AlienScanDisplay] \'%*\' has no \'%*\'"):format(p1:GetFullName(), Laboratory.ScanDisplayFrameName)))

		return
	end

	local v2 = v1:FindFirstChild(Laboratory.ScanDisplayTemplateName, true)

	if not (v2 and v2:IsA("GuiObject")) then
		warn((("[AlienScanDisplay] \'%*\' has no \'%*\' row"):format(p1:GetFullName(), Laboratory.ScanDisplayTemplateName)))

		return
	end

	local v3 = v2.Parent

	v2.Visible = false

	if not v2:FindFirstChild(Laboratory.ScanDisplayIconName, true) then
		warn((("[AlienScanDisplay] \'%*\' template has no \'%*\'"):format(p1:GetFullName(), Laboratory.ScanDisplayIconName)))
	end

	local v4 = v2:FindFirstChild(Laboratory.ScanDisplayTextName, true)

	if v4 and v4:IsA("TextLabel") then
		for v5, v6 in v3:GetChildren() do
			if v6 ~= v2 and v6:IsA("GuiObject") then
				v6:Destroy()
			end
		end

		local t = {}

		for v7, v8 in roster() do
			local v9 = v2:Clone()

			v9.Name = v8.kind
			v9.LayoutOrder = v7

			local v10 = v9:FindFirstChild(Laboratory.ScanDisplayTextName, true)
			local v11 = v9:FindFirstChild(Laboratory.ScanDisplayIconName, true)

			if v11 and v11:IsA("ImageLabel") then
				local v12 = FishConfig[v8.kind]
				local v13 = if v12 then v12.Image else v12

				v11.Image = if type(v13) == "string" then v13 else ""
			end

			v9.Visible = true
			v9.Parent = v3
			table.insert(t, {
				label = v10,
				base = v8.base
			})
		end

		t2[p1] = t
		render(t, payoutStage())
	else
		warn((("[AlienScanDisplay] \'%*\' template has no \'%*\' TextLabel"):format(p1:GetFullName(), Laboratory.ScanDisplayTextName)))
	end
end

function t.Init(p1) --[[ Init | Line: 163 | Upvalues: AlienEventConfig (copy), CollectionService (copy), ScanDisplayTag (copy), build (copy), t2 (copy), ClientPlayerData (copy), render (copy) ]]
	if not AlienEventConfig.Enabled then
		return
	end

	for v1, v2 in CollectionService:GetTagged(ScanDisplayTag) do
		build(v2)
	end

	CollectionService:GetInstanceAddedSignal(ScanDisplayTag):Connect(build)
	CollectionService:GetInstanceRemovedSignal(ScanDisplayTag):Connect(function(p1) --[[ Line: 176 | Upvalues: t2 (ref) ]]
		t2[p1] = nil
	end)
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 182 | Upvalues: AlienEventConfig (ref) ]]
		return AlienEventConfig.GetPlayerStage(p1, "ResearchPayout")
	end, function(p1) --[[ Line: 184 | Upvalues: t2 (ref), render (ref) ]]
		for v1, v2 in t2 do
			if v1:IsDescendantOf(game) then
				render(v2, p1)

				continue
			end

			t2[v1] = nil
		end
	end)
end

return t