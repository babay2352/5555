-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Maid = require(ReplicatedStorage.shared.class.Maid)
local getGuiObjectVisibilityDepedencies = require(ReplicatedStorage.shared.util.getGuiObjectVisibilityDepedencies)
local isObjectRenderable = require(ReplicatedStorage.shared.util.isObjectRenderable)
local t = {
	"#",
	"@",
	"%",
	"*",
	"+",
	"=",
	"?",
	"/",
	"$",
	"!",
	"~",
	"^",
	"|",
	"\\",
	"{",
	"}",
	"[",
	"]",
	"(",
	")",
	":",
	";",
	"_",
	"\194\167",
	"\194\164",
	"\194\177",
	"\195\183",
	"\195\151",
	"\194\182",
	"\226\128\160",
	"\226\128\161",
	"\226\128\162",
	"\226\151\138",
	"\226\150\145",
	"\226\150\146",
	"\226\150\147",
	"\226\150\136",
	"\226\151\152",
	"\226\151\153",
	"\226\150\178",
	"\226\150\188"
}
local t2 = {
	utf8.char(821),
	utf8.char(822),
	utf8.char(823),
	utf8.char(824),
	utf8.char(820),
	utf8.char(781),
	utf8.char(782),
	utf8.char(784)
}
local t3 = {
	UECS = nil
}
local t4 = {}

local function findNameLabel(p1) --[[ findNameLabel | Line: 122 ]]
	local v1 = p1:FindFirstChild("Frame") or p1
	local v2 = v1:FindFirstChild("DisplayName") or v1:FindFirstChild("TextLabel")

	if v2 and v2:IsA("TextLabel") then
		return v2
	end

	return v1:FindFirstChildWhichIsA("TextLabel")
end

local function declaredText(p1) --[[ declaredText | Line: 133 ]]
	local v1 = p1:GetAttribute("ScrambleText")

	if type(v1) == "string" and v1 ~= "" then
		return v1
	end

	return nil
end

local function scramble(p1) --[[ scramble | Line: 143 | Upvalues: t (copy), t2 (copy) ]]
	local count = 0
	local t3 = {}

	for v1, v2 in utf8.graphemes(p1) do
		count = count + 1

		if p1:sub(v1, v2) == " " then
			t3[count] = " "

			continue
		end

		local v3 = t[math.random(1, #t)]

		if math.random() < 0.4 then
			v3 = v3 .. t2[math.random(1, #t2)]
		end

		t3[count] = v3
	end

	return table.concat(t3)
end

local function startFor(p1) --[[ startFor | Line: 162 | Upvalues: t4 (copy), findNameLabel (copy), Maid (copy), scramble (copy), isObjectRenderable (copy), RunService (copy), getGuiObjectVisibilityDepedencies (copy) ]]
	if not p1:IsA("BillboardGui") or t4[p1] then
		return
	end

	local v1 = findNameLabel(p1)

	if not v1 then
		warn("[ScrambleBillboard] No text label in", p1:GetFullName())

		return
	end

	local v2 = p1:GetAttribute("ScrambleText")
	local v3 = (if type(v2) == "string" and v2 ~= "" then v2 else nil) or v1.Text
	local t = {
		connection = nil,
		destroying = nil,
		watcher = Maid.new(),
		label = v1,
		originalText = v1.Text
	}
	local v4 = 0

	local function step(p1) --[[ step | Line: 184 | Upvalues: v4 (ref), v1 (copy), scramble (ref), v3 (copy) ]]
		debug.profilebegin("UECS/ScrambleBillboard.Roll")
		v4 = v4 + p1

		if not (v4 < 0.12) then
			v4 = 0
			v1.Text = scramble(v3)
		end

		debug.profileend()
	end

	v1.Text = scramble(v3)

	local function refresh() --[[ refresh | Line: 199 | Upvalues: isObjectRenderable (ref), v1 (copy), t (copy), v4 (ref), RunService (ref), step (copy) ]]
		local v12 = isObjectRenderable(v1)

		if v12 == (t.connection ~= nil) then
			return
		end

		if v12 then
			v4 = 0.12
			t.connection = RunService.RenderStepped:Connect(step)

			return
		end

		if not t.connection then
			return
		end

		t.connection:Disconnect()
		t.connection = nil
	end

	for v5, v6 in getGuiObjectVisibilityDepedencies(v1) do
		if v6:IsA("GuiObject") then
			t.watcher:GiveTask(v6:GetPropertyChangedSignal("Visible"):Connect(refresh))

			continue
		end

		if v6:IsA("LayerCollector") then
			t.watcher:GiveTask(v6:GetPropertyChangedSignal("Enabled"):Connect(refresh))

			if v6:IsA("BillboardGui") then
				v6.DistanceStep = 1
				t.watcher:GiveTask(v6:GetPropertyChangedSignal("CurrentDistance"):Connect(refresh))
			end
		end
	end

	t.destroying = p1.Destroying:Connect(function() --[[ Line: 228 | Upvalues: t4 (ref), p1 (copy), t (copy) ]]
		if t4[p1] ~= t then
			return
		end

		if t.connection then
			t.connection:Disconnect()
			t.connection = nil
		end

		t.watcher:Destroy()
		t4[p1] = nil
	end)
	t4[p1] = t

	local v7 = isObjectRenderable(v1)

	if v7 == (if t.connection == nil then false else true) then
		return
	end

	if v7 then
		v4 = 0.12
		t.connection = RunService.RenderStepped:Connect(step)
	else
		if not t.connection then
			return
		end

		t.connection:Disconnect()
		t.connection = nil
	end
end

local function stopFor(p1) --[[ stopFor | Line: 244 | Upvalues: t4 (copy) ]]
	if not p1:IsA("BillboardGui") then
		return
	end

	local v1 = t4[p1]

	if not v1 then
		return
	end

	if v1.connection then
		v1.connection:Disconnect()
	end

	if v1.destroying then
		v1.destroying:Disconnect()
	end

	v1.watcher:Destroy()

	if v1.label.Parent then
		local v2 = p1:GetAttribute("ScrambleText")

		v1.label.Text = (if type(v2) == "string" and v2 ~= "" then v2 else nil) or v1.originalText
	end

	t4[p1] = nil
end

function t3.Init(p1) --[[ Init | Line: 267 | Upvalues: CollectionService (copy), startFor (copy), stopFor (copy) ]]
	for v1, v2 in CollectionService:GetTagged("ScrambleBillboard") do
		startFor(v2)
	end

	CollectionService:GetInstanceAddedSignal("ScrambleBillboard"):Connect(startFor)
	CollectionService:GetInstanceRemovedSignal("ScrambleBillboard"):Connect(stopFor)
end

return t3