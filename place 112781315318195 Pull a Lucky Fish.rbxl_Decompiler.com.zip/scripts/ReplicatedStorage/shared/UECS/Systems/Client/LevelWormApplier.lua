-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local CashDisplay = require(ReplicatedStorage.shared.module.CashDisplay)
local FishConfig = require(ReplicatedStorage.shared.config.FishConfig)
local FishEarnings = require(ReplicatedStorage.shared.util.FishEarnings)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local LevelWithWormPopup = require(ReplicatedStorage.shared.UECS.Components.LevelWithWormPopup)

require(ReplicatedStorage.shared.UECS.Components.LevelWorm)

local LevelWormConfig = require(ReplicatedStorage.shared.config.LevelWormConfig)
local MutationList = require(ReplicatedStorage.shared.util.MutationList)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local SFX = require(ReplicatedStorage.client.SFX)
local SignalBag = require(ReplicatedStorage.client.SignalBag)

require(ReplicatedStorage.shared.UECS.Components.TycoonStand)

local UECS = require(ReplicatedStorage.shared.UECS.UECS)
local v1 = Color3.new(255/255, 255/255, 255/255)
local LocalPlayer = Players.LocalPlayer
local t = {
	UECS = nil
}

local function setupRarityLabel(p1) --[[ setupRarityLabel | Line: 41 | Upvalues: ReplicatedStorage (copy), LevelWormConfig (copy) ]]
	if p1:QueryDescendants("BillboardGui#RarityLabel")[1] then
		return
	end

	local v1 = ReplicatedStorage.shared.model.RarityLabel:Clone()

	v1.Parent = p1
	p1.ChildAdded:Connect(function(p1) --[[ Line: 48 | Upvalues: v1 (copy) ]]
		if p1.Name ~= "Handle" or not p1:IsA("BasePart") then
			return
		end

		v1.Adornee = p1
	end)

	local Handle = p1:FindFirstChild("Handle")

	if Handle and Handle:IsA("BasePart") then
		v1.Adornee = Handle
	end

	v1.Frame.DisplayName.Text = LevelWormConfig.DisplayName
	v1.Frame.Rarity.Text = "Consumable"
	v1.Frame.Counter.Text = "Click on fish in your base to boost its level"

	local MutationList = v1.Frame:FindFirstChild("MutationList")

	if not MutationList then
		v1.Enabled = true

		return
	end

	MutationList.Visible = false
	v1.Enabled = true
end

function t.Init(p1) --[[ Init | Line: 70 | Upvalues: LocalPlayer (copy), LevelWithWormPopup (copy), FishConfig (copy), FishEarnings (copy), SignalBag (copy), LevelWormConfig (copy), v1 (copy), MutationList (copy), CashDisplay (copy), Remotes (copy), SFX (copy), UECS (copy), setupRarityLabel (copy) ]]
	local LevelWithWormPopup2 = LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("MainUI"):WaitForChild("LevelWithWormPopup")
	local v12 = LevelWithWormPopup2:WaitForChild("Content")
	local LevelText = v12:WaitForChild("LevelText")
	local EarningsText = v12:WaitForChild("EarningsText")
	local FishTemplateNotAcquired = v12:WaitForChild("FishTemplateNotAcquired")
	local Yes = v12:WaitForChild("Yes")
	local No = v12:WaitForChild("No")
	local CloseButton = LevelWithWormPopup2:WaitForChild("TopBar"):WaitForChild("CloseButton")
	local Frame = FishTemplateNotAcquired:WaitForChild("Frame")
	local UIGradient = Frame:FindFirstChild("UIGradient")
	local Icon = FishTemplateNotAcquired:WaitForChild("Icon")
	local DisplayName = FishTemplateNotAcquired:WaitForChild("DisplayName")
	local Earnings = FishTemplateNotAcquired:WaitForChild("Earnings")

	LevelWithWormPopup2.Visible = false

	local v2 = LevelWithWormPopup.Add(LevelWithWormPopup2)

	v2.Visible.OnChange:Connect(function(p1) --[[ Line: 90 | Upvalues: LevelWithWormPopup2 (copy) ]]
		LevelWithWormPopup2.Visible = p1
	end)

	local v3 = nil

	local function closePopup() --[[ closePopup | Line: 98 | Upvalues: v3 (ref), p1 (copy), v2 (copy) ]]
		v3 = nil

		local v1 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

		if v1.OpenedUIComponent:Get() ~= v2 then
			return
		end

		v1.OpenedUIComponent:Set(nil)
	end

	local function openConfirmPopup(p12) --[[ openConfirmPopup | Line: 106 | Upvalues: FishConfig (ref), FishEarnings (ref), SignalBag (ref), LevelWormConfig (ref), v3 (ref), UIGradient (copy), Frame (copy), Icon (copy), v1 (ref), MutationList (ref), DisplayName (copy), LocalPlayer (ref), CashDisplay (ref), Earnings (copy), LevelText (copy), EarningsText (copy), p1 (copy), v2 (copy) ]]
		local v12 = p12.FishStanding:Get()

		if typeof(v12) ~= "string" then
			return
		end

		local v22 = FishConfig[v12]

		if not v22 then
			return
		end

		local v32 = p12.BaseSlotIndexName:Get()

		if typeof(v32) ~= "string" then
			return
		end

		local v4 = p12.Level:Get() or 1

		if FishEarnings.FISH_MAX_LEVEL <= v4 then
			SignalBag.Notification:Fire("This fish is already at max level!")

			return
		end

		local v6 = math.min(v4 + LevelWormConfig.LevelBoost, FishEarnings.FISH_MAX_LEVEL)

		v3 = v32

		local v7 = p12.Mutation:Get()
		local v8 = if typeof(v7) == "string" and v7 ~= "" then v7 else nil

		if UIGradient then
			UIGradient.Color = ColorSequence.new(v22.Rarity.rarityColor, Color3.fromRGB(255, 255, 255))
		end

		Frame.BackgroundColor3 = v22.Rarity.rarityColor
		Icon.Image = v22.Image
		Icon.ImageColor3 = v1

		local v9 = MutationList.displayLabel(MutationList.parse(v8))

		DisplayName.Text = ("%*%*"):format(if v9 == "" then "" else ("[%*] "):format(v9), v22.DisplayName)

		local v11 = FishEarnings.perFish(LocalPlayer, v12, false, v4, v8)
		local v122 = FishEarnings.perFish(LocalPlayer, v12, false, v6, v8)

		CashDisplay.applyToLabel(Earnings, v11, {
			Suffix = "/s",
			Compact = true
		})
		LevelText.Text = ("lvl %* -> lvl %*"):format(v4, v6)
		CashDisplay.applyParts(EarningsText, {
			{
				Compact = true,
				Value = v11
			},
			"->",
			{
				Compact = true,
				Value = v122
			}
		})
		p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(v2)
	end

	Yes.MouseButton1Click:Connect(function() --[[ Line: 161 | Upvalues: v3 (ref), Remotes (ref), SFX (ref), p1 (copy), v2 (copy) ]]
		local v1 = v3

		if not v1 then
			return
		end

		Remotes.ApplyLevelWorm:Fire(v1)
		SFX.new("rbxassetid://127613720380706", 0.6)
		v3 = nil

		local v22 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

		if v22.OpenedUIComponent:Get() ~= v2 then
			return
		end

		v22.OpenedUIComponent:Set(nil)
	end)
	No.MouseButton1Click:Connect(closePopup)
	CloseButton.MouseButton1Click:Connect(closePopup)
	UECS.OnComponentCreated("LevelWorm"):Connect(function(p12) --[[ Line: 173 | Upvalues: openConfirmPopup (copy), p1 (copy), LocalPlayer (ref), setupRarityLabel (ref) ]]
		local Entity = p12.Entity
		local t = {}
		local t2 = {}

		local function CreateLevelUpPrompt(p1, p2) --[[ CreateLevelUpPrompt | Line: 179 | Upvalues: t (copy), t2 (copy), openConfirmPopup (ref) ]]
			local LevelUpPrompt = Instance.new("ProximityPrompt")

			LevelUpPrompt.Name = "LevelUpPrompt"
			LevelUpPrompt.Style = Enum.ProximityPromptStyle.Custom
			LevelUpPrompt.ActionText = "Level Up"
			LevelUpPrompt.RequiresLineOfSight = false
			LevelUpPrompt.Parent = p1
			table.insert(t, LevelUpPrompt)

			local function refresh() --[[ refresh | Line: 191 | Upvalues: p2 (copy), LevelUpPrompt (copy), p1 (copy) ]]
				local v1 = p2.FishStanding:Get()
				local v2 = if type(v1) == "string" then v1 ~= "" else false

				LevelUpPrompt.Enabled = v2

				local FishPrompt = p1:FindFirstChild("FishPrompt")

				if not FishPrompt then
					return
				end

				FishPrompt.Enabled = not v2
			end

			local v2 = p2.FishStanding:Get()
			local v3 = if type(v2) == "string" then v2 ~= "" else false

			LevelUpPrompt.Enabled = v3

			local FishPrompt = p1:FindFirstChild("FishPrompt")
			local v5

			if FishPrompt then
				FishPrompt.Enabled = not v3
			end

			v5 = p2.FishStanding.OnChange
			table.insert(t2, v5:Connect(refresh))
			LevelUpPrompt.Triggered:Connect(function() --[[ Line: 204 | Upvalues: openConfirmPopup (ref), p2 (copy) ]]
				openConfirmPopup(p2)
			end)
		end

		local function teardown() --[[ teardown | Line: 209 | Upvalues: t (copy), t2 (copy) ]]
			for v1, v2 in t do
				local v3 = v2.Parent

				if v3 then
					local FishPrompt = v3:FindFirstChild("FishPrompt")

					if FishPrompt then
						FishPrompt.Enabled = true
					end
				end

				v2:Destroy()
			end

			table.clear(t)

			for v4, v5 in t2 do
				v5:Disconnect()
			end

			table.clear(t2)
		end

		Entity.Equipped:Connect(function() --[[ Line: 227 | Upvalues: p1 (ref), LocalPlayer (ref), CreateLevelUpPrompt (copy), setupRarityLabel (ref), Entity (copy) ]]
			for v1, v2 in p1.UECS:GetComponents("TycoonStand") do
				if v2.Owner:Get() == LocalPlayer then
					local root = v2.Entity:FindFirstChild("root")

					if root then
						CreateLevelUpPrompt(root, v2)
					end
				end
			end

			setupRarityLabel(Entity)
		end)
		Entity.Unequipped:Connect(teardown)
		Entity.Destroying:Connect(teardown)
	end)
end

return t