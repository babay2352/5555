-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ContentProvider = game:GetService("ContentProvider")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local SoundService = game:GetService("SoundService")
local TweenService = game:GetService("TweenService")

game:GetService("UserInputService")
require(ReplicatedStorage.shared.config.BiomesConfig)

local ClientMusicController = require(ReplicatedStorage.shared.UECS.Systems.Client.ClientMusicController)
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local FishConfig = require(ReplicatedStorage.shared.config.FishConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local HookSwimmers = require(ReplicatedStorage.client.roll.HookSwimmers)
local LuckyblockConfig = require(ReplicatedStorage.shared.config.LuckyblockConfig)
local MutationConfig = require(ReplicatedStorage.shared.config.MutationConfig)
local MutationList = require(ReplicatedStorage.shared.util.MutationList)
local OddsBar = require(ReplicatedStorage.client.roll.OddsBar)
local Broadcast = require(ReplicatedStorage.client.remoteFishing.Broadcast)
local RollCameraFX = require(ReplicatedStorage.client.roll.RollCameraFX)
local RollClass = require(ReplicatedStorage.shared.util.RollClass)
local RollIntensityConfig = require(ReplicatedStorage.shared.config.RollIntensityConfig)
local RollDebug = require(ReplicatedStorage.client.roll.RollDebug)
local RollSpeedMultiplier = require(ReplicatedStorage.shared.util.RollSpeedMultiplier)
local RollWaterFX = require(ReplicatedStorage.client.roll.RollWaterFX)
local SFX = require(ReplicatedStorage.client.SFX)
local SignalBag = require(ReplicatedStorage.client.SignalBag)
local ThrowFX = require(ReplicatedStorage.client.throw.ThrowFX)
local ThrowPacingConfig = require(ReplicatedStorage.shared.config.ThrowPacingConfig)
local Shake = require(ReplicatedStorage.shared.module.UIVFX.Shake)
local WeatherRegistry = require(ReplicatedStorage.shared.weather.WeatherRegistry)
local Worlds = require(ReplicatedStorage.shared.util.Worlds)
local rarityConfig = require(ReplicatedStorage.shared.config.rarityConfig)
local rollSlotReward = require(ReplicatedStorage.shared.util.rollSlotReward)
local E = Enum.KeyCode.E
local LUCK_ICONS = rollSlotReward.LUCK_ICONS
local BEAST_ICON = rollSlotReward.BEAST_ICON
local LUCKYBLOCK_REEL_ICON = rollSlotReward.LUCKYBLOCK_REEL_ICON
local GEM_ICON = rollSlotReward.GEM_ICON

local function weatherSignalFor(p1) --[[ weatherSignalFor | Line: 107 | Upvalues: FishConfig (copy), WeatherRegistry (copy) ]]
	local v1 = FishConfig[p1]
	local v2 = if v1 then v1.Weather else v1

	if not v2 then
		return nil
	end

	local v3 = WeatherRegistry.Modules[v2]

	if not v3 then
		return nil
	end

	local t = {}

	t.icon = v3.Config.CatchIcon or v3.Config.Icon
	t.name = v3.Config.DisplayName

	return t
end

local SpinDurationMin = ThrowPacingConfig.SpinDurationMin
local SpinDurationMax = ThrowPacingConfig.SpinDurationMax
local DisappearDuration = ThrowPacingConfig.DisappearDuration
local DisappearDelay = ThrowPacingConfig.DisappearDelay
local v1 = Color3.fromRGB(255, 255, 255)
local v2 = Color3.fromRGB(47, 47, 47)
local v3 = UDim2.fromOffset(40, 40)
local v4 = UDim2.fromOffset(55, 55)
local v5 = Color3.fromRGB(220, 220, 220)
local fishReward = rollSlotReward.fishReward
local rewardFor = rollSlotReward.rewardFor
local biomeFishKeys = rollSlotReward.biomeFishKeys
local t = {}
local t2 = {
	UECS = nil,
	PlayForCatch = nil
}

for v6 in MutationConfig.Mutations do
	table.insert(t, v6)
end

function t2.Init(p1) --[[ Init | Line: 295 | Upvalues: ContentProvider (copy), LUCK_ICONS (copy), Players (copy), v3 (copy), v5 (copy), fishReward (copy), rewardFor (copy), t (copy), v1 (copy), v2 (copy), TweenService (copy), RunService (copy), SFX (copy), RollSpeedMultiplier (copy), SpinDurationMin (copy), SpinDurationMax (copy), RollCameraFX (copy), RollDebug (copy), ThrowFX (copy), RollWaterFX (copy), OddsBar (copy), HookSwimmers (copy), Shake (copy), MutationConfig (copy), RollIntensityConfig (copy), LuckyblockConfig (copy), weatherSignalFor (copy), LUCKYBLOCK_REEL_ICON (copy), BEAST_ICON (copy), GEM_ICON (copy), rarityConfig (copy), rollSlotReward (copy), v4 (copy), DisappearDuration (copy), biomeFishKeys (copy), Broadcast (copy), DisappearDelay (copy), ClientMusicController (copy), SoundService (copy), ClientPlayerData (copy), SignalBag (copy), Worlds (copy), RollClass (copy), t2 (copy), MutationList (copy) ]]
	task.spawn(function() --[[ Line: 296 | Upvalues: ContentProvider (ref), LUCK_ICONS (ref) ]]
		ContentProvider:PreloadAsync(LUCK_ICONS)
	end)

	local LocalPlayer = Players.LocalPlayer
	local RollUI = LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("RollUI")
	local Rolling = RollUI:WaitForChild("Rolling")
	local RollingSingle = RollUI:WaitForChild("RollingSingle")
	local Fade = RollUI:WaitForChild("Fade")
	local ArrowLeft = RollingSingle:WaitForChild("ArrowLeft")
	local ArrowRight = RollingSingle:WaitForChild("ArrowRight")

	p1.RollingSlots = {}

	local row = Rolling:WaitForChild("row")
	local columnWrapper = row:WaitForChild("columnWrapper")
	local RollingSlot = columnWrapper:WaitForChild("column"):WaitForChild("RollingSlot")
	local v12 = RollingSlot:FindFirstChild("2") or RollingSlot:FindFirstChildOfClass("ImageLabel")

	if not (v12 and v12:IsA("ImageLabel")) then
		warn("[RollSystem] RollingSlot item template missing")

		return
	end

	local v22 = v12:Clone()

	v22.Visible = true
	v22.AnchorPoint = Vector2.new(0, 0)
	v22.Position = UDim2.fromOffset(0, 0)
	v22.Size = UDim2.new(1, 0, 1, 0)

	local UIAspectRatioConstraint = v22:FindFirstChildOfClass("UIAspectRatioConstraint")

	if UIAspectRatioConstraint then
		UIAspectRatioConstraint:Destroy()
	end

	local v32 = columnWrapper:Clone()

	v32.Visible = true

	local v42 = v32:FindFirstChild("column") and v32.column:FindFirstChild("RollingSlot")

	if v42 then
		for v52, v6 in v42:GetChildren() do
			if v6:IsA("ImageLabel") then
				v6:Destroy()
			end
		end
	end

	local Line = row:FindFirstChild("Line")
	local v7 = if Line then Line:Clone() else nil

	local function arrowGlyph(p1) --[[ arrowGlyph | Line: 363 ]]
		if not (p1 and p1:IsA("ImageLabel")) then
			return nil
		end

		local Glyph = p1:FindFirstChild("Glyph")

		if Glyph and Glyph:IsA("ImageLabel") then
			return Glyph
		end

		local Glyph2 = Instance.new("ImageLabel")

		Glyph2.Name = "Glyph"
		Glyph2.BackgroundTransparency = 1
		Glyph2.AnchorPoint = Vector2.new(0.5, 0.5)
		Glyph2.Position = UDim2.fromScale(0.5, 0.5)
		Glyph2.Size = UDim2.fromScale(1, 1)
		Glyph2.Image = p1.Image
		Glyph2.ImageColor3 = p1.ImageColor3
		Glyph2.ZIndex = p1.ZIndex
		Glyph2.Parent = p1
		p1.ImageTransparency = 1

		return Glyph2
	end

	row:FindFirstChild("ArrowLeft")
	row:FindFirstChild("ArrowRight")

	local v8 = row:Clone()

	v8.Visible = true

	for v9, v10 in v8:GetChildren() do
		if v10:IsA("Frame") and (v10.Name == "columnWrapper" or v10.Name == "Line") then
			v10:Destroy()
		end
	end

	row:Destroy()

	local RollingSlot2 = RollingSingle:WaitForChild("RollingSlot")
	local v11 = RollingSlot2:Clone()

	v11.Visible = true

	for v122, v13 in v11:GetChildren() do
		if v13:IsA("ImageLabel") then
			v13:Destroy()
		end
	end

	RollingSlot2:Destroy()
	ArrowLeft.LayoutOrder = 0
	ArrowRight.LayoutOrder = 1000
	ArrowLeft.Size = v3
	ArrowRight.Size = v3
	ArrowLeft.ImageColor3 = v5
	ArrowRight.ImageColor3 = v5
	arrowGlyph(ArrowLeft)
	arrowGlyph(ArrowRight)
	RollingSingle.Visible = false

	local t3 = {}
	local v14 = nil
	local v15 = 1
	local v16 = 0
	local v17 = false
	local v18 = false

	local function mysteryReward() --[[ mysteryReward | Line: 438 | Upvalues: t3 (ref), fishReward (ref), v14 (ref) ]]
		local v1 = if #t3 > 0 then fishReward(t3[math.random(1, #t3)], v14) else fishReward(nil)

		return {
			name = "???",
			chanceLabel = "",
			luckLabel = "",
			silhouette = true,
			image = v1.image,
			nameColor = Color3.fromRGB(235, 235, 235)
		}
	end

	local function randomFillerReward() --[[ randomFillerReward | Line: 456 | Upvalues: rewardFor (ref), v14 (ref), t (ref), t3 (ref), fishReward (ref) ]]
		local v1 = math.random()

		if v1 < 0.015 then
			return rewardFor({
				kind = "beast"
			}, v14)
		end

		if v1 < 0.045 and #t > 0 then
			return rewardFor({
				kind = "mutation",
				mutation = t[math.random(1, #t)]
			}, v14)
		end

		if #t3 == 0 then
			return fishReward(nil)
		end

		return fishReward(t3[math.random(1, #t3)], v14)
	end

	local function fillItem(p1, p2) --[[ fillItem | Line: 473 ]]
		p1:SetAttribute("MysterySilhouette", if p2.silhouette then true else nil)
		p1.Image = p2.image

		local ItemName = p1:FindFirstChild("ItemName")
		local Weight = p1:FindFirstChild("Weight")
		local LuckValue = p1:FindFirstChild("LuckValue")

		if ItemName then
			ItemName.Text = p2.name
			ItemName.TextColor3 = p2.nameColor
		end

		if Weight then
			Weight.Text = p2.chanceLabel
		end

		if not LuckValue then
			return
		end

		LuckValue.Text = p2.luckLabel
	end

	local function buildReel(p1, p2, p3, p4) --[[ buildReel | Line: 507 | Upvalues: v22 (copy), fillItem (copy), randomFillerReward (copy) ]]
		local Reel = Instance.new("Frame")

		Reel.Name = "Reel"
		Reel.BackgroundTransparency = 1
		Reel.BorderSizePixel = 0
		Reel.AnchorPoint = Vector2.new(0, 0)
		Reel.Position = UDim2.fromOffset(0, 0)
		Reel.Size = UDim2.new(1, 0, 0, p4 * 150)
		Reel.Parent = p1

		local v1 = math.max(0, p3 - 4)
		local t = {}

		for i = v1, 149 do
			local v2 = v22:Clone()

			v2.Name = ("Item_%*"):format(i)
			v2.AnchorPoint = Vector2.new(0.5, 0)
			v2.Position = UDim2.new(0.5, 0, 0, i * p4)
			v2.Size = UDim2.fromOffset(p4, p4)

			local UIScale = Instance.new("UIScale")

			UIScale.Scale = 0.9
			UIScale.Parent = v2

			if i == p3 then
				fillItem(v2, p2)
			else
				fillItem(v2, randomFillerReward())
			end

			local t2 = {}
			local t3 = {}

			for v3, v4 in v2:GetChildren() do
				if v4:IsA("TextLabel") and v4.Name ~= "LuckValue" then
					table.insert(t2, v4)

					local UIStroke = v4:FindFirstChildOfClass("UIStroke")

					if UIStroke then
						table.insert(t3, UIStroke)
					end
				end
			end

			local t4 = {
				gui = v2,
				scaler = UIScale,
				texts = t2,
				strokes = t3
			}

			t4.silhouette = if v2:GetAttribute("MysterySilhouette") == true then true else false
			t[i] = t4
			v2.Parent = Reel
		end

		return Reel, t, v1
	end

	local function styleReelItem(p1, p2) --[[ styleReelItem | Line: 572 | Upvalues: v1 (ref), v2 (ref) ]]
		p1.scaler.Scale = p2 * 0.09999999999999998 + 0.9
		p1.gui.ImageColor3 = v2:Lerp(if p1.silhouette then Color3.fromRGB(0, 0, 0) else v1, p2)

		for v22, v3 in p1.texts do
			v3.TextTransparency = 1 - p2
		end

		for v4, v5 in p1.strokes do
			v5.Transparency = 1 - p2
		end
	end

	local function reelCenterIndex(p1, p2, p3) --[[ reelCenterIndex | Line: 585 ]]
		return (p3 / 2 - p1.Position.Y.Offset) / p2 - 0.5
	end

	local function styleAllReelItems(p1, p2, p3, p4) --[[ styleAllReelItems | Line: 591 | Upvalues: styleReelItem (copy) ]]
		local v1 = (p4 / 2 - p2.Position.Y.Offset) / p3 - 0.5

		for v2, v3 in p1 do
			local v5 = math.clamp(1 - math.abs(v2 - v1), 0, 1)

			styleReelItem(v3, v5 * v5 * (3 - v5 * 2))
		end
	end

	local function burstWinner(p1) --[[ burstWinner | Line: 604 | Upvalues: v1 (ref), TweenService (ref) ]]
		p1.ImageColor3 = if p1:GetAttribute("MysterySilhouette") then Color3.fromRGB(0, 0, 0) else v1

		for v2, v3 in p1:GetChildren() do
			if v3:IsA("TextLabel") then
				v3.TextTransparency = 0

				local UIStroke = v3:FindFirstChildOfClass("UIStroke")

				if UIStroke then
					UIStroke.Transparency = 0
				end
			end
		end

		local UIScale = p1:FindFirstChildOfClass("UIScale")

		if not UIScale then
			UIScale = Instance.new("UIScale")
			UIScale.Parent = p1
		end

		UIScale.Scale = 1

		local v4 = TweenService:Create(UIScale, TweenInfo.new(0.16, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
			Scale = 1.3
		})

		v4:Play()
		v4.Completed:Once(function() --[[ Line: 629 | Upvalues: TweenService (ref), UIScale (ref) ]]
			TweenService:Create(UIScale, TweenInfo.new(0.3, Enum.EasingStyle.Elastic, Enum.EasingDirection.Out), {
				Scale = 1.1
			}):Play()
		end)
	end

	local function spawnIconShower(p1, p2) --[[ spawnIconShower | Line: 642 | Upvalues: RollUI (copy), TweenService (ref) ]]
		local v1 = table.create(18)

		for i = 1, 18 do
			v1[i] = (i - 1) / 17 * 0.9 + 0.05 + (math.random() - 0.5) * 0.05
		end

		for j = 18, 2, -1 do
			local v2 = math.random(1, j)
			local v4 = v1[j]

			v1[j] = v1[v2]
			v1[v2] = v4
		end

		for k = 1, 18 do
			local v6 = math.clamp(v1[k], 0.03, 0.97)

			task.delay((k - 1) / 18 * 0.5, function() --[[ Line: 655 | Upvalues: p1 (copy), p2 (copy), v6 (copy), RollUI (ref), TweenService (ref) ]]
				local v1 = math.random(100, 200)
				local ImageLabel = Instance.new("ImageLabel")

				ImageLabel.Image = p1
				ImageLabel.BackgroundTransparency = 1
				ImageLabel.BorderSizePixel = 0
				ImageLabel.Size = UDim2.fromOffset(v1, v1)
				ImageLabel.AnchorPoint = Vector2.new(0.5, 0.5)
				ImageLabel.ZIndex = 100
				ImageLabel.Rotation = math.random(-360, 360)

				if p2 then
					ImageLabel.ImageColor3 = p2
				end

				ImageLabel.Position = UDim2.new(v6, 0, math.random(-15, -5) / 100, 0)
				ImageLabel.Parent = RollUI

				local v3 = 0.8 + math.random() * 0.8
				local v4 = 1.1 + math.random() * 0.2
				local v5 = ImageLabel.Rotation + math.random(-180, 180)
				local v62 = TweenService:Create(ImageLabel, TweenInfo.new(v3, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
					ImageTransparency = 0.3,
					Position = UDim2.new(v6 + (math.random() - 0.5) * 0.15, 0, v4, 0),
					Rotation = v5
				})

				v62:Play()
				v62.Completed:Once(function() --[[ Line: 687 | Upvalues: ImageLabel (copy) ]]
					ImageLabel:Destroy()
				end)
			end)
		end
	end

	local t4 = {}
	local t5 = {}

	local function spawnSlotText(p1, p2, p3) --[[ spawnSlotText | Line: 706 | Upvalues: RollUI (copy), TweenService (ref) ]]
		task.spawn(function() --[[ Line: 707 | Upvalues: p2 (copy), RollUI (ref), TweenService (ref), p1 (copy), p3 (copy) ]]
			local Frame = Instance.new("Frame")

			Frame.Size = UDim2.fromScale(1, 1)
			Frame.Position = UDim2.fromScale(0.5, 0.5)
			Frame.AnchorPoint = Vector2.new(0.5, 0.5)
			Frame.BackgroundColor3 = p2
			Frame.BackgroundTransparency = 0.8
			Frame.BorderSizePixel = 0
			Frame.ZIndex = 119
			Frame.Parent = RollUI
			TweenService:Create(Frame, TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				BackgroundTransparency = 1
			}):Play()
			task.delay(0.4, function() --[[ Line: 722 | Upvalues: Frame (copy) ]]
				Frame:Destroy()
			end)

			local TextLabel = Instance.new("TextLabel")

			TextLabel.Text = p1
			TextLabel.FontFace = Font.new("rbxasset://fonts/families/Montserrat.json", Enum.FontWeight.ExtraBold)
			TextLabel.TextScaled = true
			TextLabel.TextColor3 = p2
			TextLabel.TextStrokeTransparency = 1
			TextLabel.TextTransparency = 0
			TextLabel.BackgroundTransparency = 1
			TextLabel.Size = UDim2.fromScale(0.5, 0.5)
			TextLabel.Position = UDim2.fromScale(0.5, 0.5)
			TextLabel.AnchorPoint = Vector2.new(0.5, 0.5)
			TextLabel.ZIndex = 120

			local UIStroke = Instance.new("UIStroke")

			UIStroke.Color = p3
			UIStroke.Thickness = 3
			UIStroke.Transparency = 0
			UIStroke.Parent = TextLabel

			local UIScale = Instance.new("UIScale")

			UIScale.Scale = 0.3
			UIScale.Parent = TextLabel
			TextLabel.Parent = RollUI
			TweenService:Create(UIScale, TweenInfo.new(0.25, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
				Scale = 1.8
			}):Play()
			task.wait(0.6)
			TweenService:Create(TextLabel, TweenInfo.new(0.35), {
				TextTransparency = 1
			}):Play()
			TweenService:Create(UIStroke, TweenInfo.new(0.35), {
				Transparency = 1
			}):Play()
			task.wait(0.35)
			TextLabel:Destroy()
		end)
	end

	local function spinViewport(p1, p2, p3, p4) --[[ spinViewport | Line: 762 | Upvalues: v18 (ref), mysteryReward (copy), rewardFor (ref), v14 (ref), buildReel (copy), styleAllReelItems (copy), RollingSingle (copy), ArrowLeft (copy), ArrowRight (copy), arrowGlyph (copy), RunService (ref), styleReelItem (copy), SFX (ref), RollSpeedMultiplier (ref), Players (ref), SpinDurationMin (ref), SpinDurationMax (ref), v15 (ref), RollCameraFX (ref), RollDebug (ref), ThrowFX (ref), TweenService (ref), RollWaterFX (ref), v16 (ref), burstWinner (copy), t4 (copy), LUCK_ICONS (ref), spawnIconShower (copy), OddsBar (ref), HookSwimmers (ref), Shake (ref), Rolling (copy), RollUI (copy), MutationConfig (ref), t5 (copy), RollIntensityConfig (ref), LuckyblockConfig (ref), weatherSignalFor (ref), LUCKYBLOCK_REEL_ICON (ref), BEAST_ICON (ref), GEM_ICON (ref), rarityConfig (ref), v17 (ref) ]]
		local Y = p1.AbsoluteSize.Y
		local X = p1.AbsoluteSize.X

		if Y <= 0 or X <= 0 then
			task.wait()
			Y = p1.AbsoluteSize.Y
			X = p1.AbsoluteSize.X
		end

		if not (Y <= 0 or X <= 0) then
			local v1 = p1

			while v1 do
				local PopInScale = v1:FindFirstChild("PopInScale")

				if PopInScale and (PopInScale:IsA("UIScale") and PopInScale.Scale > 0.05) then
					Y = Y / PopInScale.Scale
					X = X / PopInScale.Scale
				end

				v1 = v1.Parent
			end

			local v2 = math.min(X, Y / 2.3)
			local v3 = math.random(120, 130)
			local v5, v6, v7 = buildReel(p1, if v18 then mysteryReward() else rewardFor(p2, v14), v3, v2)
			local v8 = (Y - v2) / 2 - v3 * v2

			v5.Position = UDim2.fromOffset(0, v8 - v2 * 100)
			styleAllReelItems(v6, v5, v2, Y)

			local v9 = p1.Parent
			local v10 = nil
			local v11 = nil

			while v9 do
				if v9 == RollingSingle then
					v11 = ArrowLeft
					v10 = ArrowRight

					break
				end

				if v9:IsA("Frame") and v9.Name:match("^Row_") then
					local ArrowLeft2 = v9:FindFirstChild("ArrowLeft")
					local ArrowRight2 = v9:FindFirstChild("ArrowRight")

					v11 = ArrowLeft2
					v10 = ArrowRight2

					break
				end

				v9 = v9.Parent
			end

			local v12 = arrowGlyph(v11)
			local v13 = arrowGlyph(v10)
			local v142 = 0
			local v152 = nil
			local v162 = 0
			local v172 = nil
			local v182 = 0
			local v19 = RunService.RenderStepped:Connect(function(p1) --[[ Line: 839 | Upvalues: v5 (copy), v2 (copy), Y (ref), v7 (copy), v172 (ref), v182 (ref), v6 (copy), styleReelItem (ref), v152 (ref), v162 (ref), SFX (ref), v142 (ref), v12 (copy), v13 (copy) ]]
				debug.profilebegin("UECS/RollSystem.SlotProximity")

				local v22 = (Y / 2 - v5.Position.Y.Offset) / v2 - 0.5
				local v52 = math.max(v7, math.floor(v22) - 2)
				local v72 = math.min(149, math.ceil(v22) + 2)

				if v172 then
					for i = v172, v182 do
						if i < v52 or v72 < i then
							local v8 = v6[i]

							if v8 then
								styleReelItem(v8, 0)
							end
						end
					end
				end

				for j = v52, v72 do
					local v9 = v6[j]

					if v9 then
						local v11 = math.clamp(1 - math.abs(j - v22), 0, 1)

						styleReelItem(v9, v11 * v11 * (3 - v11 * 2))
					end
				end

				v172 = v52
				v182 = v72

				local v14 = math.clamp(math.round(v22), v7, 149)

				if v14 ~= v152 then
					v152 = v14

					local v15 = os.clock()

					if v15 - v162 >= 0.03 then
						v162 = v15
						SFX.new("rbxassetid://9113492673", 0.8)
					end

					v142 = 28
				end

				v142 = v142 * math.exp(-4 * p1)

				if v12 then
					v12.Rotation = v142
				end

				if not v13 then
					debug.profileend()

					return
				end

				v13.Rotation = -v142
				debug.profileend()
			end)
			local v20 = RollSpeedMultiplier.GetMultiplier(Players.LocalPlayer)
			local v21 = (SpinDurationMin + math.random() * (SpinDurationMax - SpinDurationMin)) * v15 / v20

			RollCameraFX.spinCycle(v21 / v20)

			local v25, v26

			if p2.mutation then
				v25 = ("(%*)"):format(p2.mutation)

				if v25 then
					v26 = p4
				else
					v25 = ""
					v26 = p4
				end
			else
				v25 = ""
				v26 = p4
			end

			RollDebug.log("Reel", ("row %* track %* SPIN %*%*"):format(v26, p3, p2.kind, v25) .. string.format(" \226\128\148 %.2fs on screen", v21 / v20))
			ThrowFX.dismissAllMutationEffects()

			local function bounceArrow(p1) --[[ bounceArrow | Line: 911 | Upvalues: arrowGlyph (ref), TweenService (ref) ]]
				local v1 = arrowGlyph(p1)

				if not v1 then
					return
				end

				local SettleBounceScale = v1:FindFirstChild("SettleBounceScale")

				if not SettleBounceScale then
					local SettleBounceScale2 = Instance.new("UIScale")

					SettleBounceScale2.Name = "SettleBounceScale"
					SettleBounceScale2.Parent = v1
					SettleBounceScale = SettleBounceScale2
				end

				SettleBounceScale.Scale = 1.35
				TweenService:Create(SettleBounceScale, TweenInfo.new(0.4, Enum.EasingStyle.Elastic, Enum.EasingDirection.Out), {
					Scale = 1
				}):Play()
				TweenService:Create(v1, TweenInfo.new(0.8, Enum.EasingStyle.Elastic, Enum.EasingDirection.Out), {
					Rotation = 0
				}):Play()
			end

			if p2.kind == "fish" or (p2.kind == "beast" or p2.kind == "boss") then
				local v27 = v21 / v20

				RollWaterFX.lineTension(v27)
				RollCameraFX.tensionShake(v27)
			end

			local v28 = SFX.new(SFX.Sounds.Roll, 0.5)

			if v28 then
				v28.PlaybackSpeed = (p4 - 1) * 0.15 + 1
			end

			local function glideTo(p1, p2, p3, p4) --[[ glideTo | Line: 951 | Upvalues: TweenService (ref), v5 (copy), v20 (copy) ]]
				local v1 = TweenService:Create(v5, TweenInfo.new(p2 / v20, p3, p4), {
					Position = UDim2.fromOffset(0, p1)
				})

				v1:Play()
				v1.Completed:Wait()
			end

			local v29 = math.random()

			if v29 < 0.3 then
				glideTo(v8 + v2 * 0.5, v21, Enum.EasingStyle.Quint, Enum.EasingDirection.Out)
				glideTo(v8, 0.22, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
			elseif v29 < 0.55 then
				glideTo(v8 - v2 * 0.42, v21, Enum.EasingStyle.Quint, Enum.EasingDirection.Out)
				task.wait(0.3 / v20)
				glideTo(v8, 0.55, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut)
			else
				glideTo(v8, v21, Enum.EasingStyle.Quint, Enum.EasingDirection.Out)
			end

			v19:Disconnect()
			styleAllReelItems(v6, v5, v2, Y)
			bounceArrow(v11)
			bounceArrow(v10)

			local v31 = ("row %* track %* SETTLE %*"):format(p4, p3, p2.kind)
			local v32 = p2.fish and ("(%*)"):format(p2.fish) or ""

			RollDebug.log("Reel", v31 .. v32 .. (p2.mutation and ("(%*)"):format(p2.mutation) or "") .. " \226\128\148 arrows straighten + bounce")

			local v34 = v5:FindFirstChild((("Item_%*"):format(v3)))

			if v34 then
				for v35, v36 in v5:GetChildren() do
					if v36:IsA("ImageLabel") and v36 ~= v34 then
						v36:Destroy()
					end
				end

				if p2.kind == "fish" and (p3 == 1 and v16 >= 3) then
					RollDebug.log("Reel", string.format("HIT-STOP %.2fs (level %d)", 0.09, v16))
					task.wait(0.09)
				end

				burstWinner(v34)

				local v37 = SFX.new(SFX.Sounds.Poof, 0.5)

				if v37 then
					v37.PlaybackSpeed = (p4 - 1) * 0.15 + 1
				end

				if p2.kind == "luck" then
					local v38 = (t4[p3] or 0) + 1

					t4[p3] = v38

					local v40 = LUCK_ICONS[math.min(v38, #LUCK_ICONS)]

					if v34 then
						v34.Image = v40

						local v41 = if v38 <= 1 then Color3.fromRGB(80, 255, 80) elseif v38 == 2 then Color3.fromRGB(255, 230, 80) else Color3.fromRGB(200, 80, 255)

						v34.ImageColor3 = v41

						local Weight = v34:FindFirstChild("Weight")

						if Weight then
							Weight.Text = ("x%*"):format(2 ^ v38)
							Weight.TextColor3 = v41
							Weight.TextScaled = true
							Weight.TextXAlignment = Enum.TextXAlignment.Center
							Weight.TextYAlignment = Enum.TextYAlignment.Center
							Weight.Size = UDim2.fromScale(1, 0.35)
							Weight.Position = UDim2.fromScale(0.5, 0.15)
							Weight.AnchorPoint = Vector2.new(0.5, 0.5)
						end
					end

					spawnIconShower(v40)
					ThrowFX.onFloatLuck(v38)
					OddsBar.onLuckToken(p2.value or 2 ^ v38)
					HookSwimmers.onLuck()
					RollCameraFX.settleBounce()
					RollWaterFX.glowOnLuck(v38)
					Shake.Shake(if RollingSingle.Visible then RollingSingle else Rolling, 1.2, 0.35)

					local v44 = if v38 <= 1 then Color3.fromRGB(80, 255, 80) elseif v38 == 2 then Color3.fromRGB(255, 230, 80) else Color3.fromRGB(200, 80, 255)

					ThrowFX.onFloatSlotHit(v44)
					RollWaterFX.settleRing(v44)

					local v45 = if v38 <= 1 then Color3.fromRGB(0, 120, 0) elseif v38 == 2 then Color3.fromRGB(180, 120, 0) else Color3.fromRGB(80, 0, 140)
					local v46 = ("%*x LUCK"):format(2 ^ v38)

					task.spawn(function() --[[ Line: 707 | Upvalues: v44 (copy), RollUI (ref), TweenService (ref), v46 (copy), v45 (copy) ]]
						local Frame = Instance.new("Frame")

						Frame.Size = UDim2.fromScale(1, 1)
						Frame.Position = UDim2.fromScale(0.5, 0.5)
						Frame.AnchorPoint = Vector2.new(0.5, 0.5)
						Frame.BackgroundColor3 = v44
						Frame.BackgroundTransparency = 0.8
						Frame.BorderSizePixel = 0
						Frame.ZIndex = 119
						Frame.Parent = RollUI
						TweenService:Create(Frame, TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
							BackgroundTransparency = 1
						}):Play()
						task.delay(0.4, function() --[[ Line: 722 | Upvalues: Frame (copy) ]]
							Frame:Destroy()
						end)

						local TextLabel = Instance.new("TextLabel")

						TextLabel.Text = v46
						TextLabel.FontFace = Font.new("rbxasset://fonts/families/Montserrat.json", Enum.FontWeight.ExtraBold)
						TextLabel.TextScaled = true
						TextLabel.TextColor3 = v44
						TextLabel.TextStrokeTransparency = 1
						TextLabel.TextTransparency = 0
						TextLabel.BackgroundTransparency = 1
						TextLabel.Size = UDim2.fromScale(0.5, 0.5)
						TextLabel.Position = UDim2.fromScale(0.5, 0.5)
						TextLabel.AnchorPoint = Vector2.new(0.5, 0.5)
						TextLabel.ZIndex = 120

						local UIStroke = Instance.new("UIStroke")

						UIStroke.Color = v45
						UIStroke.Thickness = 3
						UIStroke.Transparency = 0
						UIStroke.Parent = TextLabel

						local UIScale = Instance.new("UIScale")

						UIScale.Scale = 0.3
						UIScale.Parent = TextLabel
						TextLabel.Parent = RollUI
						TweenService:Create(UIScale, TweenInfo.new(0.25, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
							Scale = 1.8
						}):Play()
						task.wait(0.6)
						TweenService:Create(TextLabel, TweenInfo.new(0.35), {
							TextTransparency = 1
						}):Play()
						TweenService:Create(UIStroke, TweenInfo.new(0.35), {
							Transparency = 1
						}):Play()
						task.wait(0.35)
						TextLabel:Destroy()
					end)
				elseif p2.kind == "mutation" then
					local v47 = MutationConfig.Mutations[p2.mutation or ""]
					local v48 = ("%*:%*"):format(p4, p2.mutation or "")
					local v49 = not t5[v48]

					t5[v48] = true

					if v49 and (v47 and v47.image) then
						spawnIconShower(v47.image)
					end

					local v50 = ({
						Gold = Color3.fromRGB(255, 200, 50),
						Diamond = Color3.fromRGB(80, 180, 255),
						Molten = Color3.fromRGB(255, 60, 30),
						Frozen = Color3.fromRGB(160, 220, 255),
						Bloody = Color3.fromRGB(140, 20, 20),
						Cat = Color3.fromRGB(255, 140, 20),
						Bubblegum = Color3.fromRGB(255, 152, 220)
					})[p2.mutation or ""] or Color3.fromRGB(255, 230, 80)

					ThrowFX.onFloatSlotHit(v50)
					HookSwimmers.mutationComet(p2.mutation or "", v50)
					RollCameraFX.settleBounce()
					RollCameraFX.flash(1)
					RollWaterFX.settleRing(v50)

					if v49 then
						if p2.mutation == "Frozen" then
							ThrowFX.frozenWaterEffect()
							task.spawn(function() --[[ Line: 1100 | Upvalues: TweenService (ref) ]]
								local Sound = Instance.new("Sound")

								Sound.SoundId = "rbxassetid://104438685257050"
								Sound.Volume = 0
								Sound.TimePosition = 2
								Sound.Parent = game:GetService("SoundService"):FindFirstChild("SFX") or game:GetService("SoundService")
								Sound:Play()
								TweenService:Create(Sound, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
									Volume = 0.8
								}):Play()
								task.wait(3)
								TweenService:Create(Sound, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
									Volume = 0
								}):Play()
								task.wait(0.5)
								Sound:Destroy()
							end)
						elseif p2.mutation == "Bloody" then
							ThrowFX.bloodyRevealEffect()
							ThrowFX.bloodyFloatVFX()
						elseif p2.mutation == "Diamond" then
							ThrowFX.diamondRevealEffect()
						elseif p2.mutation == "Molten" then
							ThrowFX.moltenVolcanoEffect()
							ThrowFX.moltenFloatVFX()
						elseif p2.mutation == "Bubblegum" then
							ThrowFX.bubblegumRevealEffect()
						elseif p2.mutation == "Gold" then
							ThrowFX.goldRevealEffect()
						elseif p2.mutation == "Cat" then
							ThrowFX.catRevealEffect()
						end

						if v47 then
							local displayName = v47.displayName
							local v51 = Color3.fromRGB(180, 120, 0)

							task.spawn(function() --[[ Line: 707 | Upvalues: v50 (copy), RollUI (ref), TweenService (ref), displayName (copy), v51 (copy) ]]
								local Frame = Instance.new("Frame")

								Frame.Size = UDim2.fromScale(1, 1)
								Frame.Position = UDim2.fromScale(0.5, 0.5)
								Frame.AnchorPoint = Vector2.new(0.5, 0.5)
								Frame.BackgroundColor3 = v50
								Frame.BackgroundTransparency = 0.8
								Frame.BorderSizePixel = 0
								Frame.ZIndex = 119
								Frame.Parent = RollUI
								TweenService:Create(Frame, TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
									BackgroundTransparency = 1
								}):Play()
								task.delay(0.4, function() --[[ Line: 722 | Upvalues: Frame (copy) ]]
									Frame:Destroy()
								end)

								local TextLabel = Instance.new("TextLabel")

								TextLabel.Text = displayName
								TextLabel.FontFace = Font.new("rbxasset://fonts/families/Montserrat.json", Enum.FontWeight.ExtraBold)
								TextLabel.TextScaled = true
								TextLabel.TextColor3 = v50
								TextLabel.TextStrokeTransparency = 1
								TextLabel.TextTransparency = 0
								TextLabel.BackgroundTransparency = 1
								TextLabel.Size = UDim2.fromScale(0.5, 0.5)
								TextLabel.Position = UDim2.fromScale(0.5, 0.5)
								TextLabel.AnchorPoint = Vector2.new(0.5, 0.5)
								TextLabel.ZIndex = 120

								local UIStroke = Instance.new("UIStroke")

								UIStroke.Color = v51
								UIStroke.Thickness = 3
								UIStroke.Transparency = 0
								UIStroke.Parent = TextLabel

								local UIScale = Instance.new("UIScale")

								UIScale.Scale = 0.3
								UIScale.Parent = TextLabel
								TextLabel.Parent = RollUI
								TweenService:Create(UIScale, TweenInfo.new(0.25, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
									Scale = 1.8
								}):Play()
								task.wait(0.6)
								TweenService:Create(TextLabel, TweenInfo.new(0.35), {
									TextTransparency = 1
								}):Play()
								TweenService:Create(UIStroke, TweenInfo.new(0.35), {
									Transparency = 1
								}):Play()
								task.wait(0.35)
								TextLabel:Destroy()
							end)
						end
					end

					RollDebug.log("Reel", string.format("mutation beat: silhouette dive plays, row pauses %.2fs", RollIntensityConfig.MutationRowPause))
					task.wait(RollIntensityConfig.MutationRowPause)
				elseif p2.kind == "beast" then
					HookSwimmers.onBeastIncoming()
					RollCameraFX.setBeastMood(true)
					RollCameraFX.beastShake()
					RollCameraFX.settleBounce()
					RollWaterFX.settleRing(Color3.fromRGB(255, 60, 60))
					Shake.Shake(if RollingSingle.Visible then RollingSingle else Rolling, 3.2, 0.6)

					local v53 = if p2.fish and not LuckyblockConfig[p2.fish] then weatherSignalFor(p2.fish) else nil

					if p2.fish and LuckyblockConfig[p2.fish] then
						spawnIconShower(LUCKYBLOCK_REEL_ICON)
						ThrowFX.onFloatSlotHit(Color3.fromRGB(120, 235, 120))

						local v54 = Color3.fromRGB(120, 235, 120)
						local v55 = Color3.fromRGB(20, 100, 20)
						local v56 = "LUCKY BLOCK!"

						task.spawn(function() --[[ Line: 707 | Upvalues: v54 (copy), RollUI (ref), TweenService (ref), v56 (copy), v55 (copy) ]]
							local Frame = Instance.new("Frame")

							Frame.Size = UDim2.fromScale(1, 1)
							Frame.Position = UDim2.fromScale(0.5, 0.5)
							Frame.AnchorPoint = Vector2.new(0.5, 0.5)
							Frame.BackgroundColor3 = v54
							Frame.BackgroundTransparency = 0.8
							Frame.BorderSizePixel = 0
							Frame.ZIndex = 119
							Frame.Parent = RollUI
							TweenService:Create(Frame, TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
								BackgroundTransparency = 1
							}):Play()
							task.delay(0.4, function() --[[ Line: 722 | Upvalues: Frame (copy) ]]
								Frame:Destroy()
							end)

							local TextLabel = Instance.new("TextLabel")

							TextLabel.Text = v56
							TextLabel.FontFace = Font.new("rbxasset://fonts/families/Montserrat.json", Enum.FontWeight.ExtraBold)
							TextLabel.TextScaled = true
							TextLabel.TextColor3 = v54
							TextLabel.TextStrokeTransparency = 1
							TextLabel.TextTransparency = 0
							TextLabel.BackgroundTransparency = 1
							TextLabel.Size = UDim2.fromScale(0.5, 0.5)
							TextLabel.Position = UDim2.fromScale(0.5, 0.5)
							TextLabel.AnchorPoint = Vector2.new(0.5, 0.5)
							TextLabel.ZIndex = 120

							local UIStroke = Instance.new("UIStroke")

							UIStroke.Color = v55
							UIStroke.Thickness = 3
							UIStroke.Transparency = 0
							UIStroke.Parent = TextLabel

							local UIScale = Instance.new("UIScale")

							UIScale.Scale = 0.3
							UIScale.Parent = TextLabel
							TextLabel.Parent = RollUI
							TweenService:Create(UIScale, TweenInfo.new(0.25, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
								Scale = 1.8
							}):Play()
							task.wait(0.6)
							TweenService:Create(TextLabel, TweenInfo.new(0.35), {
								TextTransparency = 1
							}):Play()
							TweenService:Create(UIStroke, TweenInfo.new(0.35), {
								Transparency = 1
							}):Play()
							task.wait(0.35)
							TextLabel:Destroy()
						end)
					elseif v53 then
						spawnIconShower(v53.icon)
						ThrowFX.onFloatSlotHit(Color3.fromRGB(140, 170, 255))

						local v57 = ("%* FISH!"):format(v53.name)
						local v58 = Color3.fromRGB(140, 170, 255)
						local v59 = Color3.fromRGB(20, 30, 90)

						task.spawn(function() --[[ Line: 707 | Upvalues: v58 (copy), RollUI (ref), TweenService (ref), v57 (copy), v59 (copy) ]]
							local Frame = Instance.new("Frame")

							Frame.Size = UDim2.fromScale(1, 1)
							Frame.Position = UDim2.fromScale(0.5, 0.5)
							Frame.AnchorPoint = Vector2.new(0.5, 0.5)
							Frame.BackgroundColor3 = v58
							Frame.BackgroundTransparency = 0.8
							Frame.BorderSizePixel = 0
							Frame.ZIndex = 119
							Frame.Parent = RollUI
							TweenService:Create(Frame, TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
								BackgroundTransparency = 1
							}):Play()
							task.delay(0.4, function() --[[ Line: 722 | Upvalues: Frame (copy) ]]
								Frame:Destroy()
							end)

							local TextLabel = Instance.new("TextLabel")

							TextLabel.Text = v57
							TextLabel.FontFace = Font.new("rbxasset://fonts/families/Montserrat.json", Enum.FontWeight.ExtraBold)
							TextLabel.TextScaled = true
							TextLabel.TextColor3 = v58
							TextLabel.TextStrokeTransparency = 1
							TextLabel.TextTransparency = 0
							TextLabel.BackgroundTransparency = 1
							TextLabel.Size = UDim2.fromScale(0.5, 0.5)
							TextLabel.Position = UDim2.fromScale(0.5, 0.5)
							TextLabel.AnchorPoint = Vector2.new(0.5, 0.5)
							TextLabel.ZIndex = 120

							local UIStroke = Instance.new("UIStroke")

							UIStroke.Color = v59
							UIStroke.Thickness = 3
							UIStroke.Transparency = 0
							UIStroke.Parent = TextLabel

							local UIScale = Instance.new("UIScale")

							UIScale.Scale = 0.3
							UIScale.Parent = TextLabel
							TextLabel.Parent = RollUI
							TweenService:Create(UIScale, TweenInfo.new(0.25, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
								Scale = 1.8
							}):Play()
							task.wait(0.6)
							TweenService:Create(TextLabel, TweenInfo.new(0.35), {
								TextTransparency = 1
							}):Play()
							TweenService:Create(UIStroke, TweenInfo.new(0.35), {
								Transparency = 1
							}):Play()
							task.wait(0.35)
							TextLabel:Destroy()
						end)
					else
						spawnIconShower(BEAST_ICON)
						ThrowFX.onFloatSlotHit(Color3.fromRGB(255, 160, 40))

						local v60 = Color3.fromRGB(255, 60, 60)
						local v61 = Color3.fromRGB(140, 0, 0)
						local v62 = "BEAST!"

						task.spawn(function() --[[ Line: 707 | Upvalues: v60 (copy), RollUI (ref), TweenService (ref), v62 (copy), v61 (copy) ]]
							local Frame = Instance.new("Frame")

							Frame.Size = UDim2.fromScale(1, 1)
							Frame.Position = UDim2.fromScale(0.5, 0.5)
							Frame.AnchorPoint = Vector2.new(0.5, 0.5)
							Frame.BackgroundColor3 = v60
							Frame.BackgroundTransparency = 0.8
							Frame.BorderSizePixel = 0
							Frame.ZIndex = 119
							Frame.Parent = RollUI
							TweenService:Create(Frame, TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
								BackgroundTransparency = 1
							}):Play()
							task.delay(0.4, function() --[[ Line: 722 | Upvalues: Frame (copy) ]]
								Frame:Destroy()
							end)

							local TextLabel = Instance.new("TextLabel")

							TextLabel.Text = v62
							TextLabel.FontFace = Font.new("rbxasset://fonts/families/Montserrat.json", Enum.FontWeight.ExtraBold)
							TextLabel.TextScaled = true
							TextLabel.TextColor3 = v60
							TextLabel.TextStrokeTransparency = 1
							TextLabel.TextTransparency = 0
							TextLabel.BackgroundTransparency = 1
							TextLabel.Size = UDim2.fromScale(0.5, 0.5)
							TextLabel.Position = UDim2.fromScale(0.5, 0.5)
							TextLabel.AnchorPoint = Vector2.new(0.5, 0.5)
							TextLabel.ZIndex = 120

							local UIStroke = Instance.new("UIStroke")

							UIStroke.Color = v61
							UIStroke.Thickness = 3
							UIStroke.Transparency = 0
							UIStroke.Parent = TextLabel

							local UIScale = Instance.new("UIScale")

							UIScale.Scale = 0.3
							UIScale.Parent = TextLabel
							TextLabel.Parent = RollUI
							TweenService:Create(UIScale, TweenInfo.new(0.25, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
								Scale = 1.8
							}):Play()
							task.wait(0.6)
							TweenService:Create(TextLabel, TweenInfo.new(0.35), {
								TextTransparency = 1
							}):Play()
							TweenService:Create(UIStroke, TweenInfo.new(0.35), {
								Transparency = 1
							}):Play()
							task.wait(0.35)
							TextLabel:Destroy()
						end)
					end
				elseif p2.kind == "gempack" then
					local v63 = Color3.fromRGB(80, 220, 255)

					spawnIconShower(GEM_ICON, v63)
					ThrowFX.onFloatSlotHit(v63)
					ThrowFX.onFloatLuck(1)
					RollCameraFX.settleBounce()
					RollWaterFX.settleRing(v63)

					local v64 = (p2.gemAmount or 25) .. " GEMS!"
					local v65 = Color3.fromRGB(20, 100, 140)

					task.spawn(function() --[[ Line: 707 | Upvalues: v63 (copy), RollUI (ref), TweenService (ref), v64 (copy), v65 (copy) ]]
						local Frame = Instance.new("Frame")

						Frame.Size = UDim2.fromScale(1, 1)
						Frame.Position = UDim2.fromScale(0.5, 0.5)
						Frame.AnchorPoint = Vector2.new(0.5, 0.5)
						Frame.BackgroundColor3 = v63
						Frame.BackgroundTransparency = 0.8
						Frame.BorderSizePixel = 0
						Frame.ZIndex = 119
						Frame.Parent = RollUI
						TweenService:Create(Frame, TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
							BackgroundTransparency = 1
						}):Play()
						task.delay(0.4, function() --[[ Line: 722 | Upvalues: Frame (copy) ]]
							Frame:Destroy()
						end)

						local TextLabel = Instance.new("TextLabel")

						TextLabel.Text = v64
						TextLabel.FontFace = Font.new("rbxasset://fonts/families/Montserrat.json", Enum.FontWeight.ExtraBold)
						TextLabel.TextScaled = true
						TextLabel.TextColor3 = v63
						TextLabel.TextStrokeTransparency = 1
						TextLabel.TextTransparency = 0
						TextLabel.BackgroundTransparency = 1
						TextLabel.Size = UDim2.fromScale(0.5, 0.5)
						TextLabel.Position = UDim2.fromScale(0.5, 0.5)
						TextLabel.AnchorPoint = Vector2.new(0.5, 0.5)
						TextLabel.ZIndex = 120

						local UIStroke = Instance.new("UIStroke")

						UIStroke.Color = v65
						UIStroke.Thickness = 3
						UIStroke.Transparency = 0
						UIStroke.Parent = TextLabel

						local UIScale = Instance.new("UIScale")

						UIScale.Scale = 0.3
						UIScale.Parent = TextLabel
						TextLabel.Parent = RollUI
						TweenService:Create(UIScale, TweenInfo.new(0.25, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
							Scale = 1.8
						}):Play()
						task.wait(0.6)
						TweenService:Create(TextLabel, TweenInfo.new(0.35), {
							TextTransparency = 1
						}):Play()
						TweenService:Create(UIStroke, TweenInfo.new(0.35), {
							Transparency = 1
						}):Play()
						task.wait(0.35)
						TextLabel:Destroy()
					end)
				elseif p2.kind == "fish" then
					RollCameraFX.settleBounce()

					if p3 == 1 and p2.fish then
						RollCameraFX.flash(v16)

						local v66 = p2.rarity and rarityConfig[p2.rarity]
						local v67 = v66 and v66.rarityColor or Color3.fromRGB(255, 255, 255)

						RollWaterFX.finalRings(v67)
						RollWaterFX.glowBurst(v67)
						Shake.Shake(if RollingSingle.Visible then RollingSingle else Rolling, RollIntensityConfig.UiShakeByLevel[v16] or 0, 0.4)

						if v17 then
							local v70 = Color3.fromRGB(120, 255, 170)
							local v71 = Color3.fromRGB(10, 90, 40)
							local v72 = "NEW FISH!"

							task.spawn(function() --[[ Line: 707 | Upvalues: v70 (copy), RollUI (ref), TweenService (ref), v72 (copy), v71 (copy) ]]
								local Frame = Instance.new("Frame")

								Frame.Size = UDim2.fromScale(1, 1)
								Frame.Position = UDim2.fromScale(0.5, 0.5)
								Frame.AnchorPoint = Vector2.new(0.5, 0.5)
								Frame.BackgroundColor3 = v70
								Frame.BackgroundTransparency = 0.8
								Frame.BorderSizePixel = 0
								Frame.ZIndex = 119
								Frame.Parent = RollUI
								TweenService:Create(Frame, TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
									BackgroundTransparency = 1
								}):Play()
								task.delay(0.4, function() --[[ Line: 722 | Upvalues: Frame (copy) ]]
									Frame:Destroy()
								end)

								local TextLabel = Instance.new("TextLabel")

								TextLabel.Text = v72
								TextLabel.FontFace = Font.new("rbxasset://fonts/families/Montserrat.json", Enum.FontWeight.ExtraBold)
								TextLabel.TextScaled = true
								TextLabel.TextColor3 = v70
								TextLabel.TextStrokeTransparency = 1
								TextLabel.TextTransparency = 0
								TextLabel.BackgroundTransparency = 1
								TextLabel.Size = UDim2.fromScale(0.5, 0.5)
								TextLabel.Position = UDim2.fromScale(0.5, 0.5)
								TextLabel.AnchorPoint = Vector2.new(0.5, 0.5)
								TextLabel.ZIndex = 120

								local UIStroke = Instance.new("UIStroke")

								UIStroke.Color = v71
								UIStroke.Thickness = 3
								UIStroke.Transparency = 0
								UIStroke.Parent = TextLabel

								local UIScale = Instance.new("UIScale")

								UIScale.Scale = 0.3
								UIScale.Parent = TextLabel
								TextLabel.Parent = RollUI
								TweenService:Create(UIScale, TweenInfo.new(0.25, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
									Scale = 1.8
								}):Play()
								task.wait(0.6)
								TweenService:Create(TextLabel, TweenInfo.new(0.35), {
									TextTransparency = 1
								}):Play()
								TweenService:Create(UIStroke, TweenInfo.new(0.35), {
									Transparency = 1
								}):Play()
								task.wait(0.35)
								TextLabel:Destroy()
							end)
						end
					end
				end
			end
		end
	end

	local t6 = {}
	local t7 = {}
	local v19 = false
	local v20 = 0
	local Position = Rolling.Position
	local t8 = {}
	local t9 = {}
	local v21 = false

	local function clearSingleColumns() --[[ clearSingleColumns | Line: 1238 | Upvalues: t9 (copy), t8 (copy), RollingSingle (copy) ]]
		for v1, v2 in t9 do
			v2:Disconnect()
		end

		table.clear(t9)

		for v3, v4 in t8 do
			v4:Destroy()
		end

		table.clear(t8)
		RollingSingle.Visible = false
	end

	local function clearGrid() --[[ clearGrid | Line: 1250 | Upvalues: t7 (copy), t6 (copy), p1 (copy), Rolling (copy), Position (copy) ]]
		for v1, v2 in t7 do
			v2:Disconnect()
		end

		table.clear(t7)

		for v3, v4 in t6 do
			v4:Destroy()
		end

		table.clear(t6)
		p1.RollingSlots = {}
		Rolling.Position = Position
	end

	local function clearAll() --[[ clearAll | Line: 1264 | Upvalues: v21 (ref), clearSingleColumns (copy), clearGrid (copy) ]]
		if v21 then
			clearSingleColumns()
		else
			clearGrid()
		end
	end

	local function buildDisplayOrder(p1, p2) --[[ buildDisplayOrder | Line: 1277 | Upvalues: rollSlotReward (ref) ]]
		local t = {}

		for v1, v2 in p1.slots do
			if v2.kind == "boss" or (v2.kind == "fish" or v2.kind == "beast") then
				if not p1.isBoss then
					table.insert(t, v2)
				end
			else
				table.insert(t, v2)
			end
		end

		local v3 = p1.isBeast or p1.isBoss

		if p2 and (not v3 and math.random() < 0.03) then
			local v4 = t[#t]

			if v4 and v4.kind == "fish" then
				t[#t] = {
					kind = "beast",
					fish = v4.fish
				}
				v3 = true
			end
		end

		local v5 = rollSlotReward.teaserCarryFish(t[#t])
		local v6 = 0

		if v3 then
			v6 = if p1.isBoss then 3 else 2
		elseif math.random() < 0.07 then
			v6 = math.random(1, 2)
		end

		for i = 1, v6 do
			table.insert(t, math.random(1, (math.max(1, #t - 1))), {
				kind = "beast",
				fish = v5
			})
		end

		return t
	end

	local function popIn(p1) --[[ popIn | Line: 1317 | Upvalues: TweenService (ref) ]]
		local PopInScale = p1:FindFirstChild("PopInScale")

		if not PopInScale then
			local PopInScale2 = Instance.new("UIScale")

			PopInScale2.Name = "PopInScale"
			PopInScale2.Parent = p1
			PopInScale = PopInScale2
		end

		PopInScale.Scale = 0.2
		TweenService:Create(PopInScale, TweenInfo.new(0.35, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
			Scale = 1
		}):Play()
	end

	local function createRow(p12, p2) --[[ createRow | Line: 1333 | Upvalues: v8 (copy), p1 (copy), Rolling (copy), popIn (copy), v3 (ref), v5 (ref), arrowGlyph (copy), v32 (copy), v7 (copy) ]]
		local v1 = v8:Clone()

		p1.RollingSlots[p12] = {}
		v1.Name = ("Row_%*"):format(p12)
		v1.LayoutOrder = p12
		v1.Visible = true
		v1.Parent = Rolling
		popIn(v1)

		local ArrowLeft = v1:FindFirstChild("ArrowLeft")
		local ArrowRight = v1:FindFirstChild("ArrowRight")

		if ArrowLeft then
			ArrowLeft.LayoutOrder = 0
			ArrowLeft.Size = v3
			ArrowLeft.ImageColor3 = v5
			ArrowLeft.Visible = false
			arrowGlyph(ArrowLeft)
		end

		if ArrowRight then
			ArrowRight.LayoutOrder = p2 * 2
			ArrowRight.Size = v3
			ArrowRight.ImageColor3 = v5
			ArrowRight.Visible = false
			arrowGlyph(ArrowRight)
		end

		local t = {}

		for i = 1, p2 do
			local v2 = v32:Clone()

			v2.Name = ("columnWrapper_%*"):format(i)
			v2.LayoutOrder = i * 2 - 1
			v2.Visible = true
			v2.Parent = v1

			local column = v2:FindFirstChild("column")
			local v33 = if column then column:FindFirstChild("RollingSlot") else column

			p1.RollingSlots[p12][i] = v2
			table.insert(t, v33)

			if v7 then
				local v4 = v7:Clone()

				v4.Name = ("Line_%*"):format(i)
				v4.LayoutOrder = i * 2
				v4.Visible = i ~= p2
				v4.Parent = v1
			end
		end

		return v1, t
	end

	local function hideAllLines() --[[ hideAllLines | Line: 1389 | Upvalues: p1 (copy) ]]
		for v1, v2 in p1.RollingSlots do
			local v3 = v2[1] and v2[1].Parent

			if v3 then
				for v4, v5 in v3:GetChildren() do
					if v5:IsA("Frame") and v5.Name:match("^Line_") then
						v5.Visible = false
					end
				end
			end
		end
	end

	local function hideRightmostLineInRow(p1) --[[ hideRightmostLineInRow | Line: 1403 ]]
		for i = 100, 1, -1 do
			local v1 = p1:FindFirstChild((("columnWrapper_%*"):format(i)))

			if v1 and v1.Visible then
				local v2 = p1:FindFirstChild((("Line_%*"):format(i)))

				if v2 then
					v2.Visible = false

					return
				end

				break
			end
		end
	end

	local function hideRightmostLineAllRows() --[[ hideRightmostLineAllRows | Line: 1417 | Upvalues: p1 (copy) ]]
		for v1, v2 in p1.RollingSlots do
			local v3 = 0

			for v4, v5 in v2 do
				if v5.Visible and v3 < v4 then
					v3 = v4
				end
			end

			if v3 > 0 then
				local v6 = v2[v3].Parent

				if v6 then
					local v7 = v6:FindFirstChild((("Line_%*"):format(v3)))

					if v7 then
						v7.Visible = false
					end
				end
			end
		end
	end

	local function setRowArrowsActive(p1, p2) --[[ setRowArrowsActive | Line: 1439 | Upvalues: v4 (ref), v3 (ref), TweenService (ref) ]]
		local v1 = TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
		local v2 = if p2 then v4 else v3
		local ArrowLeft = p1:FindFirstChild("ArrowLeft")
		local ArrowRight = p1:FindFirstChild("ArrowRight")

		if ArrowLeft and ArrowLeft:IsA("ImageLabel") then
			ArrowLeft.Visible = p2

			if p2 then
				TweenService:Create(ArrowLeft, v1, {
					Size = v2
				}):Play()
			end
		end

		if not (ArrowRight and ArrowRight:IsA("ImageLabel")) then
			return
		end

		ArrowRight.Visible = p2

		if not p2 then
			return
		end

		TweenService:Create(ArrowRight, v1, {
			Size = v2
		}):Play()
	end

	local function disappearColumnWrapper(p1) --[[ disappearColumnWrapper | Line: 1459 | Upvalues: DisappearDuration (ref), TweenService (ref) ]]
		local UIScale = p1:FindFirstChildOfClass("UIScale")

		if not UIScale then
			local UIScale2 = Instance.new("UIScale")

			UIScale2.Parent = p1
			UIScale = UIScale2
		end

		local v1 = TweenService:Create(UIScale, TweenInfo.new(DisappearDuration, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
			Scale = 0.5
		})
		local v2 = TweenInfo.new(DisappearDuration, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
		local t = {}

		for v3, v4 in p1:GetDescendants() do
			if v4:IsA("ImageLabel") then
				table.insert(t, TweenService:Create(v4, v2, {
					ImageTransparency = 1
				}))
			end

			if v4:IsA("TextLabel") then
				table.insert(t, TweenService:Create(v4, v2, {
					TextTransparency = 1
				}))

				local UIStroke = v4:FindFirstChildOfClass("UIStroke")

				if UIStroke then
					table.insert(t, TweenService:Create(UIStroke, v2, {
						Transparency = 1
					}))
				end
			end
		end

		v1:Play()

		for v8, v9 in t do
			v9:Play()
		end

		v1.Completed:Wait()
		p1.Visible = false

		local v10 = p1.Name:match("%d+$")

		if not (v10 and p1.Parent) then
			return
		end

		local v11 = p1.Parent:FindFirstChild((("Line_%*"):format(v10)))

		if not v11 then
			return
		end

		v11.Visible = false
	end

	local function disappearColumn(p12) --[[ disappearColumn | Line: 1502 | Upvalues: p1 (copy), disappearColumnWrapper (copy) ]]
		local v1 = Instance.new("BindableEvent")
		local count = 0
		local v2 = 0

		for v3, v4 in p1.RollingSlots do
			local v5 = v4[p12]

			if v5 and v5.Visible then
				count = count + 1
				task.spawn(function() --[[ Line: 1511 | Upvalues: disappearColumnWrapper (ref), v5 (copy), v2 (ref), count (ref), v1 (copy) ]]
					disappearColumnWrapper(v5)
					v2 = v2 + 1

					if not (count <= v2) then
						return
					end

					v1:Fire()
				end)
			end
		end

		if count > 0 and v2 < count then
			v1.Event:Wait()
		end

		v1:Destroy()
	end

	local function runGridCascade(p1, p2) --[[ runGridCascade | Line: 1531 | Upvalues: clearGrid (copy), v14 (ref), t3 (ref), biomeFishKeys (ref), t4 (copy), t5 (copy), Rolling (copy), t7 (copy), RunService (ref), RollUI (copy), Position (copy), createRow (copy), t6 (copy), TweenService (ref), hideAllLines (copy), hideRightmostLineInRow (copy), setRowArrowsActive (copy), Broadcast (ref), spinViewport (copy), v3 (ref), DisappearDelay (ref), disappearColumn (copy), hideRightmostLineAllRows (copy) ]]
		clearGrid()
		v14 = p2
		t3 = biomeFishKeys(p2)
		table.clear(t4)
		table.clear(t5)

		local UIListLayout = Rolling:FindFirstChildOfClass("UIListLayout")

		if UIListLayout then
			local v1 = 0

			local function f3(p1) --[[ Line: 1549 | Upvalues: RollUI (ref), Position (ref), Rolling (ref), UIListLayout (copy), v1 (ref) ]]
				local Y = RollUI.AbsoluteSize.Y

				v1 = v1 + (-math.max(0, Y * Position.Y.Scale + Position.Y.Offset - Rolling.AbsoluteSize.Y * Rolling.AnchorPoint.Y + UIListLayout.AbsoluteContentSize.Y + 16 - Y) - v1) * (1 - math.exp(-10 * p1))
				Rolling.Position = UDim2.new(Position.X.Scale, Position.X.Offset, Position.Y.Scale, Position.Y.Offset + v1)
			end

			table.insert(t7, RunService.Heartbeat:Connect(f3))
		end

		local v4 = 0

		for v5, v6 in p1 do
			if v4 < #v6 then
				v4 = #v6
			end
		end

		local v7 = #p1
		local t = {}

		for i = 1, v4 do
			local t2 = {}

			for j = 1, v7 do
				if p1[j][i] then
					table.insert(t2, j)
				end
			end

			if #t2 == 0 then
				break
			end

			local v8, v9 = createRow(i, v7)

			table.insert(t6, v8)

			for k = 1, #t6 - 1 do
				local PopInScale = t6[k]:FindFirstChild("PopInScale")

				if PopInScale and PopInScale.Scale > 0.6 then
					TweenService:Create(PopInScale, TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						Scale = 0.6
					}):Play()
				end
			end

			if #t2 == 1 then
				hideAllLines()
			end

			for n = 1, v7 do
				if not p1[n][i] or t[n] then
					local v11 = v8:FindFirstChild((("columnWrapper_%*"):format(n)))

					if v11 then
						v11.Visible = false
					end

					local v12 = v8:FindFirstChild((("Line_%*"):format(n)))

					if v12 then
						v12.Visible = false
					end
				end
			end

			hideRightmostLineInRow(v8)
			setRowArrowsActive(v8, true)
			task.wait()

			local v13 = Instance.new("BindableEvent")

			Broadcast.stage("rollRow", {
				Row = i
			})

			local v142 = #t2
			local v15 = 0

			for v16, v17 in t2 do
				local v18 = p1[v17][i]
				local v19 = v9[v17]

				task.spawn(function() --[[ Line: 1651 | Upvalues: spinViewport (ref), v19 (copy), v18 (copy), v17 (copy), i (copy), Broadcast (ref), v15 (ref), v142 (copy), v13 (copy) ]]
					spinViewport(v19, v18, v17, i)
					Broadcast.stage("rollSettle", {
						Row = i,
						Track = v17
					})
					v15 = v15 + 1

					if not (v142 <= v15) then
						return
					end

					v13:Fire()
				end)
			end

			if v15 < v142 then
				v13.Event:Wait()
			end

			v13:Destroy()
			TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

			local ArrowLeft = v8:FindFirstChild("ArrowLeft")
			local ArrowRight = v8:FindFirstChild("ArrowRight")

			if ArrowLeft and ArrowLeft:IsA("ImageLabel") then
				ArrowLeft.Visible = false
			end

			if ArrowRight and ArrowRight:IsA("ImageLabel") then
				ArrowRight.Visible = false
			end

			local t8 = {}
			local count = 0

			for v20, v21 in t2 do
				if #p1[v21] <= i then
					table.insert(t8, v21)

					continue
				end

				count = count + 1
			end

			if #t8 > 0 and count > 0 then
				task.wait(DisappearDelay)

				local v22 = Instance.new("BindableEvent")
				local v23 = 0
				local v24 = #t8

				for v25, v26 in t8 do
					t[v26] = true
					task.spawn(function() --[[ Line: 1693 | Upvalues: disappearColumn (ref), v26 (copy), v23 (ref), v24 (copy), v22 (copy) ]]
						disappearColumn(v26)
						v23 = v23 + 1

						if not (v24 <= v23) then
							return
						end

						v22:Fire()
					end)
				end

				if v23 < v24 then
					v22.Event:Wait()
				end

				v22:Destroy()
				hideRightmostLineAllRows()
			end
		end
	end

	local function closeRollUIDramatically() --[[ closeRollUIDramatically | Line: 1714 | Upvalues: v21 (ref), RollingSingle (copy), Rolling (copy), TweenService (ref), clearSingleColumns (copy), clearGrid (copy) ]]
		local v1 = if v21 then RollingSingle else Rolling
		local UIScale = v1:FindFirstChildOfClass("UIScale")

		if not UIScale then
			local UIScale2 = Instance.new("UIScale")

			UIScale2.Parent = v1
			UIScale = UIScale2
		end

		UIScale.Scale = 1

		local v2 = TweenService:Create(UIScale, TweenInfo.new(0.12, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
			Scale = 1.18
		})

		v2:Play()
		v2.Completed:Wait()

		local v3 = TweenService:Create(UIScale, TweenInfo.new(0.26, Enum.EasingStyle.Quint, Enum.EasingDirection.In), {
			Scale = 0
		})

		v3:Play()
		v3.Completed:Wait()

		if v21 then
			clearSingleColumns()
		else
			clearGrid()
		end

		UIScale.Scale = 1
	end

	local function doBossAnimation() --[[ doBossAnimation | Line: 1741 | Upvalues: ClientMusicController (ref), SoundService (ref), ClientPlayerData (ref), RollingSingle (copy), TweenService (ref), Fade (copy), SignalBag (ref), v21 (ref), BEAST_ICON (ref), Rolling (copy), RunService (ref), closeRollUIDramatically (copy) ]]
		print("boss animation here")

		local v1 = nil

		ClientMusicController.SetMuted(true)

		local v2 = SoundService:QueryDescendants("Sound#BossFightTheme")[1]

		if v2 and ClientPlayerData.serverProfile:getState().settings.musicEnabled then
			v2:Play()
		end

		local v3 = TweenInfo.new(3)
		local v4 = TweenService:Create(Fade, v3, {
			BackgroundTransparency = 0
		})
		local v5 = TweenService:Create(RollingSingle, v3, {
			Position = UDim2.fromScale(0.5, 0.5)
		})

		SignalBag.PlaySoundByName:Fire("BossEnter")
		v4:Play()
		v5:Play()
		v4.Completed:Wait()
		v4:Destroy()
		v5:Destroy()
		task.wait(1.6)

		local v6

		if v21 then
			local v7 = nil
			local v8 = 0

			for v9, v10 in RollingSingle:QueryDescendants("Frame#RollingSlot") do
				if #v10:QueryDescendants("TextLabel#ItemName[Text = BEAST]") ~= 0 then
					if not v7 then
						v7 = v10
					end

					v8 = math.max(0, v8, v10.LayoutOrder)

					break
				end
			end

			if v7 then
				local v11 = v7:Clone()

				v11.LayoutOrder = v8
				v11.Parent = RollingSingle
				v1 = v11
			end

			v6 = RollingSingle:QueryDescendants("Frame#RollingSlot > Frame#Reel > ImageLabel")

			for v12, v13 in v6 do
				if v13.Image == BEAST_ICON then
					v13.ImageRectSize = Vector2.one * 256

					continue
				end

				table.remove(v6, v12)
			end
		else
			local v14 = nil

			for v15, v16 in Rolling:GetChildren() do
				if v14 then
					break
				end

				if v16:IsA("Frame") and string.match(v16.Name, "^Row") then
					for v17, v18 in v16:QueryDescendants("Frame#columnWrapper_1 >> ImageLabel") do
						if v18.Image == BEAST_ICON then
							v14 = v16

							break
						end
					end
				end
			end

			if v14 and v14:IsA("Frame") then
				v1 = v14:Clone()

				for v19, v20 in v1:GetChildren() do
					if v20:IsA("Frame") and v20.Name ~= "columnWrapper_1" then
						for v212, v22 in v20:GetChildren() do
							if v22:IsA("GuiObject") or v22:IsA("UIStroke") then
								v22:Destroy()
							end
						end

						v20.BackgroundTransparency = 1
					end
				end

				v1.LayoutOrder = -1
				v1.Parent = Rolling
			end

			v6 = Rolling:QueryDescendants("Frame#columnWrapper_1 >> Frame#Reel > ImageLabel")

			for v23, v24 in v6 do
				if v24.Image == BEAST_ICON then
					v24.ImageRectSize = Vector2.one * 256

					continue
				end

				table.remove(v6, v23)
			end
		end

		SignalBag.PlaySoundByName:Fire("BossStarShake")

		local v25 = 0
		local v26 = RunService.PreRender:Connect(function(p1) --[[ Line: 1844 | Upvalues: v25 (ref), v6 (ref) ]]
			v25 = v25 + p1 / 10

			for v1, v2 in v6 do
				v2.ImageRectOffset = Vector2.new(math.random(-1, 1) * 51.2 * math.clamp(v25, 0, 1), math.random(-1, 1) * 51.2 * math.clamp(v25, 0, 1))
			end
		end)

		task.delay(4, function() --[[ Line: 1854 | Upvalues: v26 (copy), v6 (ref) ]]
			v26:Disconnect()

			for v1, v2 in v6 do
				v2.ImageRectOffset = Vector2.zero
			end
		end)
		task.wait(4)
		SignalBag.PlaySoundByName:Fire("BossLaugh")
		TweenService:Create(Fade, TweenInfo.new(0.5), {
			BackgroundTransparency = 1
		}):Play()
		SignalBag.PlaySoundByName:Fire("BossReveal")
		closeRollUIDramatically()
		task.delay(2, function() --[[ Line: 1868 | Upvalues: v1 (ref) ]]
			if not v1 then
				return
			end

			v1:Destroy()
		end)
		RollingSingle.Position = RollingSingle.Position
	end

	local function setSingleArrowsActive(p1) --[[ setSingleArrowsActive | Line: 1881 | Upvalues: v4 (ref), v3 (ref), TweenService (ref), ArrowLeft (copy), ArrowRight (copy) ]]
		local v1 = TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
		local v2 = if p1 then v4 else v3

		TweenService:Create(ArrowLeft, v1, {
			Size = v2
		}):Play()
		TweenService:Create(ArrowRight, v1, {
			Size = v2
		}):Play()
	end

	local function spinSingleColumn(p1, p2) --[[ spinSingleColumn | Line: 1888 | Upvalues: v11 (copy), RollingSingle (copy), popIn (copy), spinViewport (copy) ]]
		local v1 = v11:Clone()

		v1.LayoutOrder = p2
		v1.Visible = true
		v1.Parent = RollingSingle
		popIn(v1)
		spinViewport(v1, p1, 1, p2)

		return v1
	end

	local function runSingleCascade(p1, p2) --[[ runSingleCascade | Line: 1901 | Upvalues: clearSingleColumns (copy), t4 (copy), t5 (copy), v14 (ref), t3 (ref), biomeFishKeys (ref), Rolling (copy), RollingSingle (copy), setSingleArrowsActive (copy), Broadcast (ref), v11 (copy), popIn (copy), spinViewport (copy), t8 (copy) ]]
		clearSingleColumns()
		table.clear(t4)
		table.clear(t5)
		v14 = p2
		t3 = biomeFishKeys(p2)
		Rolling.Visible = false
		RollingSingle.Visible = true

		local UIScale = RollingSingle:FindFirstChildOfClass("UIScale")

		if UIScale then
			UIScale.Scale = 1
		end

		setSingleArrowsActive(true)

		for v1, v2 in p1 do
			Broadcast.stage("rollRow", {
				Row = v1
			})

			local v3 = v11:Clone()

			v3.LayoutOrder = v1
			v3.Visible = true
			v3.Parent = RollingSingle
			popIn(v3)
			spinViewport(v3, v2, 1, v1)
			Broadcast.stage("rollSettle", {
				Track = 1,
				Row = v1
			})

			if v3 then
				table.insert(t8, v3)
			end
		end

		setSingleArrowsActive(false)
	end

	local function runSingleCascadeSuspense(p1, p2, p3) --[[ runSingleCascadeSuspense | Line: 1933 | Upvalues: clearSingleColumns (copy), t4 (copy), t5 (copy), v14 (ref), t3 (ref), biomeFishKeys (ref), Rolling (copy), RollingSingle (copy), setSingleArrowsActive (copy), Broadcast (ref), v11 (copy), popIn (copy), spinViewport (copy), t8 (copy), RollDebug (ref), v18 (ref), doBossAnimation (copy), closeRollUIDramatically (copy) ]]
		clearSingleColumns()
		table.clear(t4)
		table.clear(t5)
		v14 = p2
		t3 = biomeFishKeys(p2)
		Rolling.Visible = false
		RollingSingle.Visible = true

		local UIScale = RollingSingle:FindFirstChildOfClass("UIScale")

		if UIScale then
			UIScale.Scale = 1
		end

		setSingleArrowsActive(true)

		local v1 = p1[#p1]
		local v2 = if v1 == nil then false else v1.kind == "fish"

		for v3, v4 in p1 do
			if v4.kind == "fish" then
				break
			end

			Broadcast.stage("rollRow", {
				Row = v3
			})

			local v5 = v11:Clone()

			v5.LayoutOrder = v3
			v5.Visible = true
			v5.Parent = RollingSingle
			popIn(v5)
			spinViewport(v5, v4, 1, v3)
			Broadcast.stage("rollSettle", {
				Track = 1,
				Row = v3
			})

			if v5 then
				table.insert(t8, v5)
			end
		end

		if v2 then
			RollDebug.log("Cascade", "mystery finale \226\128\148 \'???\' column spins and settles before the slam")
			Broadcast.stage("rollRow", {
				Row = #p1
			})
			v18 = true

			local v7 = #p1
			local v8 = v11:Clone()

			v8.LayoutOrder = v7
			v8.Visible = true
			v8.Parent = RollingSingle
			popIn(v8)
			spinViewport(v8, {
				kind = "fish"
			}, 1, v7)
			v18 = false

			if v8 then
				table.insert(t8, v8)
			end

			task.wait(0.55)
		else
			task.wait(0.25)
		end

		setSingleArrowsActive(false)

		if p3 then
			doBossAnimation()
		else
			closeRollUIDramatically()
		end
	end

	local function pickRandomBiome() --[[ pickRandomBiome | Line: 2089 | Upvalues: Worlds (ref) ]]
		local v1 = Worlds.GetLocalBiomes()

		return v1[math.random(1, #v1)]
	end

	local function startRoll() --[[ startRoll | Line: 2096 | Upvalues: v19 (ref), RollUI (copy), Worlds (ref), RollClass (ref), LocalPlayer (copy), v20 (ref), buildDisplayOrder (copy), v21 (ref), runSingleCascade (copy), clearSingleColumns (copy), clearGrid (copy) ]]
		if v19 then
			return
		end

		v19 = true
		RollUI.Enabled = true

		local v1 = Worlds.GetLocalBiomes()
		local v2 = v1[math.random(1, #v1)]
		local ok, result = pcall(function() --[[ Line: 2104 | Upvalues: RollClass (ref), LocalPlayer (ref), v2 (copy), v20 (ref) ]]
			return RollClass.roll({
				isGolden = false,
				player = LocalPlayer,
				biome = v2,
				rollCount = v20
			})
		end)

		if not ok then
			warn((("[RollSystem] RollClass.roll failed: %*"):format(result)))
			v19 = false

			return
		end

		v20 = result.rollCount
		v21 = true
		runSingleCascade(buildDisplayOrder(result, true), v2)
		task.wait(1.1)

		if v21 then
			clearSingleColumns()
		else
			clearGrid()
		end

		v19 = false
	end

	function t2.PlayForCatch(p12, p2) --[[ Line: 2133 | Upvalues: v19 (ref), p1 (copy), t4 (copy), t5 (copy), MutationList (ref), RollUI (copy), RollIntensityConfig (ref), v15 (ref), v17 (ref), v16 (ref), RollDebug (ref), OddsBar (ref), RollCameraFX (ref), buildDisplayOrder (copy), Broadcast (ref), v21 (ref), Rolling (copy), runSingleCascadeSuspense (copy), runSingleCascade (copy), clearSingleColumns (copy), clearGrid (copy), RollingSingle (copy), runGridCascade (copy), doBossAnimation (copy), closeRollUIDramatically (copy) ]]
		if v19 then
			return
		end

		v19 = true
		p1.RollingSlots = {}
		table.clear(t4)
		table.clear(t5)

		local v1

		if p2.slots and #p2.slots > 0 then
			v1 = p2.slots
		else
			v1 = {}

			for v2, v3 in MutationList.parse(p2.mutation) do
				table.insert(v1, {
					kind = "mutation",
					mutation = v3
				})
			end

			table.insert(v1, {
				kind = "fish",
				fish = p2.fish,
				rarity = p2.rarity
			})
		end

		local t = {
			luckTokens = 0,
			accumulatedLuck = 0,
			totalLuck = 0,
			rollCount = 0,
			fish = p2.fish,
			rarity = p2.rarity
		}

		t.isBeast = if p2.isBeast == true then true else false
		t.isBoss = if p2.isBoss == true then true else false
		t.mutation = p2.mutation
		t.slots = v1
		RollUI.Enabled = true

		local v6 = RollIntensityConfig.speedTierFor(p2.firstDiscovery, p2.rarity)

		v15 = v6.spinMult
		v17 = p2.firstDiscovery == true
		v16 = RollIntensityConfig.levelFor(p2.rarity, #MutationList.parse(p2.mutation), p2.firstDiscovery, if (p2.isBeast or p2.isBoss) == true then true else false)

		local v11 = ("start: %* (%*), level %*, spinMult %*"):format(p2.fish, p2.rarity or "?", v16, v6.spinMult)
		local v162 = (", firstDiscovery %*, golden %*"):format(tostring(if p2.firstDiscovery == true then true else false), (tostring(if p2.isGolden == true then true else false)))
		local v192 = (", suspense %*, slots %*"):format(tostring(if p2.suspense == true then true else false), #v1)

		RollDebug.log("Cascade", v11 .. v162 .. v192 .. (", bonus tracks %*"):format(p2.bonusSlots and #p2.bonusSlots or 0))

		local v22 = OddsBar.begin(p2.biome, p2.isGolden)

		RollCameraFX.begin()

		if v22 > 0 then
			RollDebug.log("Cascade", string.format("holding %.2fs for the luck intro before the reels", v22))
			task.wait(v22)
			RollDebug.log("Cascade", "luck intro done \226\128\148 reels start")
		end

		local v23 = buildDisplayOrder(t, false)
		local t2 = {}

		if p2.bonusSlots then
			for v24, v25 in p2.bonusSlots do
				local v26 = v25[#v25]
				local t3 = {
					mutation = nil,
					luckTokens = 0,
					accumulatedLuck = 0,
					totalLuck = 0,
					rollCount = 0
				}

				t3.fish = v26 and v26.fish or ""
				t3.rarity = if v26 then v26.rarity else v26
				t3.isBeast = if v26 == nil then false elseif v26.kind == "beast" then true else false
				t3.isBoss = if v26 == nil then false else v26.kind == "boss"
				t3.slots = v25
				table.insert(t2, (buildDisplayOrder(t3, false)))
			end
		end

		local t3 = { v1 }

		if p2.bonusSlots then
			for v32, v33 in p2.bonusSlots do
				table.insert(t3, v33)
			end
		end

		local t6 = { v23 }

		for v34, v35 in t2 do
			table.insert(t6, v35)
		end

		local t7 = {}

		for v36, v37 in t6 do
			local v38 = t3[v36] or {}
			local t8 = {}

			for v39, v40 in v37 do
				table.insert(t8, table.find(v38, v40) or 0)
			end

			t7[v36] = t8
		end

		Broadcast.stage("rollPlan", {
			Tracks = t7
		})

		if #t2 == 0 then
			v21 = true
			Rolling.Visible = false

			if p2.suspense then
				RollDebug.log("Cascade", "suspense close \226\128\148 UI slams shut, cutscene takes the reveal")
				runSingleCascadeSuspense(v23, p2.biome, p2.isBoss)
			else
				runSingleCascade(v23, p2.biome)
				RollDebug.log("Cascade", string.format("reveal hold %.2fs, then clear", v6.revealHold))
				task.wait(v6.revealHold)

				if v21 then
					clearSingleColumns()
				else
					clearGrid()
				end
			end
		else
			v21 = false
			Rolling.Visible = true
			RollingSingle.Visible = false

			local UIScale = Rolling:FindFirstChildOfClass("UIScale")

			if UIScale then
				UIScale.Scale = 1
			end

			local t8 = { v23 }

			for v42, v43 in t2 do
				table.insert(t8, v43)
			end

			runGridCascade(t8, p2.biome)

			if p2.suspense then
				RollDebug.log("Cascade", if p2.isBoss then "BOSS animation" else "suspense close (grid)")

				if p2.isBoss then
					doBossAnimation()
				else
					closeRollUIDramatically()
				end
			else
				RollDebug.log("Cascade", string.format("reveal hold %.2fs, then clear (grid)", v6.revealHold))
				task.wait(v6.revealHold)

				if v21 then
					clearSingleColumns()
				else
					clearGrid()
				end
			end
		end

		RollDebug.log("Cascade", "over \226\128\148 camera restores, odds bar implodes")
		RollCameraFX.finish()
		OddsBar.hide()
		v15 = 1
		v17 = false
		v16 = 0
		RollUI.Enabled = false
		v19 = false
		Broadcast.stage("rollEnd")
	end
	RollUI.Enabled = false
end

return t2