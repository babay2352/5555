-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local CashDisplay = require(ReplicatedStorage.shared.module.CashDisplay)
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local FishConfig = require(ReplicatedStorage.shared.config.FishConfig)
local FreeGiftConfig = require(ReplicatedStorage.shared.config.FreeGiftConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Remotes = require(ReplicatedStorage.shared.Remotes)

return {
	UECS = nil,
	Priority = 30,
	Init = function(p1) --[[ Init | Line: 14 | Upvalues: Players (copy), FishConfig (copy), FreeGiftConfig (copy), CashDisplay (copy), Remotes (copy), ClientPlayerData (copy) ]]
		local FreeGift = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI"):WaitForChild("Store"):WaitForChild("Content"):WaitForChild("ScrollingFrame"):WaitForChild("FreeGift")
		local RewardIcon = FreeGift:WaitForChild("RewardIcon")
		local Earnings = FreeGift:WaitForChild("Earnings")
		local Claim = FreeGift:WaitForChild("Claim")
		local v1 = FishConfig[FreeGiftConfig.FishConfigName]
		local v2, v3

		if not v1 then
			Claim.Activated:Connect(function() --[[ Line: 35 | Upvalues: Remotes (ref) ]]
				Remotes.RequestFreeGiftClaim:Fire()
			end)
			v2 = function() --[[ refresh | Line: 42 | Upvalues: ClientPlayerData (ref), FreeGift (copy), Claim (copy) ]]
				local freeGiftClaimed = ClientPlayerData.serverProfile:getState().freeGiftClaimed

				FreeGift.Visible = not freeGiftClaimed
				Claim.Active = not freeGiftClaimed
				Claim.AutoButtonColor = not freeGiftClaimed
			end
			v3 = ClientPlayerData.serverProfile:getState().freeGiftClaimed
			FreeGift.Visible = not v3
			Claim.Active = not v3
			Claim.AutoButtonColor = not v3
			ClientPlayerData.serverProfile:subscribe(function(p13) --[[ Line: 50 ]]
				return p13.freeGiftClaimed
			end, v2)

			return
		end

		RewardIcon.Image = v1.Image
		CashDisplay.applyToLabel(Earnings, v1.Earnings, {
			Suffix = "/s",
			Compact = true
		})
		Claim.Activated:Connect(function() --[[ Line: 35 | Upvalues: Remotes (ref) ]]
			Remotes.RequestFreeGiftClaim:Fire()
		end)
		v2 = function() --[[ refresh | Line: 42 | Upvalues: ClientPlayerData (ref), FreeGift (copy), Claim (copy) ]]
			local freeGiftClaimed = ClientPlayerData.serverProfile:getState().freeGiftClaimed

			FreeGift.Visible = not freeGiftClaimed
			Claim.Active = not freeGiftClaimed
			Claim.AutoButtonColor = not freeGiftClaimed
		end
		v3 = ClientPlayerData.serverProfile:getState().freeGiftClaimed
		FreeGift.Visible = not v3
		Claim.Active = not v3
		Claim.AutoButtonColor = not v3
		ClientPlayerData.serverProfile:subscribe(function(p13) --[[ Line: 50 ]]
			return p13.freeGiftClaimed
		end, v2)
	end
}