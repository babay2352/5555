-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local Debris = game:GetService("Debris")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local FishConfig = require(ReplicatedStorage.shared.config.FishConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local MutationConfig = require(ReplicatedStorage.shared.config.MutationConfig)
local MutationList = require(ReplicatedStorage.shared.util.MutationList)
local MutationMachine = require(ReplicatedStorage.shared.UECS.Components.MutationMachine)
local MutationMachineConfig = require(ReplicatedStorage.shared.config.MutationMachineConfig)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local SignalBag = require(ReplicatedStorage.client.SignalBag)
local buildFishModel = require(ReplicatedStorage.shared.util.buildFishModel)
local LocalPlayer = Players.LocalPlayer
local v1 = TweenInfo.new(0.4, Enum.EasingStyle.Back, Enum.EasingDirection.In)
local v2 = Color3.fromRGB(60, 220, 90)

local function playSound(p1, p2, p3, p4) --[[ playSound | Line: 82 ]]
	local Sound = Instance.new("Sound")

	Sound.SoundId = p2
	Sound.Volume = p3 or 0.5
	Sound.Looped = p4 or false
	Sound.Parent = p1
	Sound:Play()

	if not p4 then
		Sound.Ended:Once(function() --[[ Line: 90 | Upvalues: Sound (copy) ]]
			Sound:Destroy()
		end)
	end

	return Sound
end

local function hideJarDecoration(p1) --[[ hideJarDecoration | Line: 120 ]]
	if not p1.jarDecoration then
		return
	end

	p1.jarDecoration:Destroy()
	p1.jarDecoration = nil
end

local function showJarDecoration(p1, p2) --[[ showJarDecoration | Line: 127 | Upvalues: MutationMachineConfig (copy), ReplicatedStorage (copy) ]]
	if p1.jarDecoration then
		p1.jarDecoration:Destroy()
		p1.jarDecoration = nil
	end

	if not p2 then
		return
	end

	local v1 = MutationMachineConfig.Jars[p2]

	if not v1 then
		return
	end

	local Tools = ReplicatedStorage.shared.model:FindFirstChild("Tools")
	local v2 = if Tools then Tools:FindFirstChild("Jar") else Tools

	if not (v2 and v2:IsA("Tool")) then
		return
	end

	local v3 = v2:Clone()
	local PrimaryPart = v3.PrimaryPart

	if not PrimaryPart then
		v3:Destroy()

		return
	end

	for v4, v5 in v3:GetDescendants() do
		if v5:IsA("BasePart") then
			v5.Anchored = true
			v5.CanCollide = false
		end
	end

	local Juice = PrimaryPart:FindFirstChild("Juice", true)

	if Juice and Juice:IsA("BasePart") then
		Juice.Color = v1.Color

		for v6, v7 in Juice:GetDescendants() do
			if v7:IsA("ParticleEmitter") then
				v7.Color = ColorSequence.new(v1.Color)
			end
		end
	end

	v3:ScaleTo(v3:GetScale() * 0.75)
	v3:PivotTo(p1.promptPart.CFrame + Vector3.new(0, -0.75, 0))
	v3.Parent = workspace
	p1.jarDecoration = v3
end

local function hideFishInMachine(p1) --[[ hideFishInMachine | Line: 168 ]]
	if not p1.fishInMachine then
		return
	end

	p1.fishInMachine:Destroy()
	p1.fishInMachine = nil
end

local function buildFishHandleFromIdentity(p1, p2, p3) --[[ buildFishHandleFromIdentity | Line: 180 | Upvalues: buildFishModel (copy) ]]
	local v1 = buildFishModel.clone(p1, p2, p3)

	if not (v1 and v1.PrimaryPart) then
		return nil
	end

	local Handle = v1.PrimaryPart

	Handle.Name = "Handle"

	for v2, v3 in v1:GetDescendants() do
		if v3:IsA("BasePart") and v3 ~= Handle then
			v3.Anchored = false
			v3.CanCollide = false
			v3.Massless = true

			local WeldConstraint = Instance.new("WeldConstraint")

			WeldConstraint.Part0 = Handle
			WeldConstraint.Part1 = v3
			WeldConstraint.Parent = v3
		end
	end

	Handle.Anchored = false
	Handle.CanCollide = false
	Handle.Massless = true
	Handle.Parent = nil

	for v4, v5 in v1:GetChildren() do
		v5.Parent = Handle
	end

	v1:Destroy()

	return Handle
end

local function startRunningSound(p1) --[[ startRunningSound | Line: 211 ]]
	if not p1.runningSound then
		local Sound = Instance.new("Sound")

		Sound.SoundId = "rbxassetid://132644728084213"
		Sound.Volume = 0.4
		Sound.Looped = true
		Sound.Parent = p1.promptPart
		Sound:Play()
		p1.runningSound = Sound
	end
end

local function stopRunningSound(p1) --[[ stopRunningSound | Line: 218 ]]
	if not p1.runningSound then
		return
	end

	p1.runningSound:Stop()
	p1.runningSound:Destroy()
	p1.runningSound = nil
end

local function animateFishIntoMachine(p1, p2) --[[ animateFishIntoMachine | Line: 231 | Upvalues: TweenService (copy), v1 (copy), Debris (copy) ]]
	local promptPart = p1.promptPart
	local v12 = promptPart.CFrame * CFrame.Angles(-1.5707963267948966, 0, 0)
	local Model = Instance.new("Model")

	p2.Anchored = true
	p2.CanCollide = false
	p2.Parent = Model
	Model.PrimaryPart = p2
	Model.Parent = workspace
	p2.CFrame = v12 + v12.LookVector * -4

	local v3 = Model:GetScale()
	local v4 = Instance.new("NumberValue")

	v4.Value = 1
	v4.Parent = Model
	v4.Changed:Connect(function(p1) --[[ Line: 253 | Upvalues: Model (copy), v3 (copy) ]]
		if not Model.Parent then
			return
		end

		Model:ScaleTo(v3 * p1)
	end)

	local v5 = TweenService:Create(p2, v1, {
		CFrame = v12
	})
	local v6 = TweenService:Create(v4, v1, {
		Value = 0.75
	})

	v5:Play()
	v6:Play()
	v5.Completed:Once(function() --[[ Line: 263 | Upvalues: Model (copy), v4 (copy), promptPart (copy), Debris (ref), p1 (copy) ]]
		if Model.Parent then
			v4:Destroy()

			local Sound = Instance.new("Sound")

			Sound.SoundId = "rbxassetid://9125402735"
			Sound.Volume = 0.7
			Sound.Looped = false
			Sound.Parent = promptPart
			Sound:Play()
			Sound.Ended:Once(function() --[[ Line: 90 | Upvalues: Sound (copy) ]]
				Sound:Destroy()
			end)

			local Sound2 = Instance.new("Sound")

			Sound2.SoundId = "rbxassetid://315912428"
			Sound2.Volume = 0.7
			Sound2.Looped = false
			Sound2.Parent = promptPart
			Sound2:Play()
			Sound2.Ended:Once(function() --[[ Line: 90 | Upvalues: Sound2 (copy) ]]
				Sound2:Destroy()
			end)

			local ParticleEmitter = Instance.new("ParticleEmitter")

			ParticleEmitter.Color = ColorSequence.new(Color3.fromRGB(255, 230, 150))
			ParticleEmitter.Rate = 0
			ParticleEmitter.Speed = NumberRange.new(3, 6)
			ParticleEmitter.Lifetime = NumberRange.new(0.25, 0.5)
			ParticleEmitter.Size = NumberSequence.new(0.3, 0)
			ParticleEmitter.LightEmission = 0.5
			ParticleEmitter.SpreadAngle = Vector2.new(180, 180)
			ParticleEmitter.Parent = promptPart
			ParticleEmitter:Emit(25)
			Debris:AddItem(ParticleEmitter, 1)
			p1.fishInMachine = Model
		end
	end)
end

return {
	UECS = nil,
	Init = function(p1) --[[ Init | Line: 291 | Upvalues: LocalPlayer (copy), MutationMachine (copy), MutationMachineConfig (copy), MutationList (copy), v2 (copy), SignalBag (copy), FishConfig (copy), MutationConfig (copy), Remotes (copy), CollectionService (copy), animateFishIntoMachine (copy), buildFishHandleFromIdentity (copy), showJarDecoration (copy), RunService (copy) ]]
		local MutationMachine2 = LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("MainUI"):WaitForChild("MutationMachine")
		local v1 = MutationMachine2:WaitForChild("Content")
		local Image = v1:WaitForChild("Image")
		local Mutations = v1:WaitForChild("Mutations")
		local ImageButton = Mutations:WaitForChild("ImageButton")
		local UIStroke = ImageButton:FindFirstChildOfClass("UIStroke")
		local v22 = if UIStroke then UIStroke.Color else Color3.new(255/255, 255/255, 255/255)

		ImageButton.Visible = false

		local Buy = v1:WaitForChild("Buy")
		local Price = Buy:WaitForChild("Content"):WaitForChild("Frame"):WaitForChild("Price")
		local v3 = MutationMachine.Add(MutationMachine2)

		v3.Visible.OnChange:Connect(function(p1) --[[ Line: 306 | Upvalues: MutationMachine2 (copy) ]]
			MutationMachine2.Visible = p1
		end)

		local function closeUI() --[[ closeUI | Line: 310 | Upvalues: p1 (copy) ]]
			p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
		end

		local TopBar = MutationMachine2:FindFirstChild("TopBar")
		local v4 = if TopBar then TopBar:FindFirstChild("CloseButton") else TopBar

		if v4 then
			v4.MouseButton1Down:Connect(closeUI)
		end

		Price.Text = tostring(MutationMachineConfig.GemPrice)

		local function getEquippedMutatedFish() --[[ getEquippedMutatedFish | Line: 324 | Upvalues: LocalPlayer (ref), p1 (copy), MutationList (ref) ]]
			local Character = LocalPlayer.Character

			if not Character then
				return nil, {}
			end

			local v1 = nil

			for v2, v3 in Character:GetChildren() do
				if v3:IsA("Tool") then
					v1 = v3

					break
				end
			end

			if not v1 then
				return nil, {}
			end

			local v4 = p1.UECS:GetComponent(v1, "PlaceableFish")

			if not v4 then
				return nil, {}
			end

			local v5 = v4.FishConfigName:Get()
			local v6 = v4.Mutation and v4.Mutation:Get()

			if typeof(v5) == "string" and (typeof(v6) == "string" and v6 ~= "") then
				return v5, MutationList.parse(v6)
			end

			return nil, {}
		end

		local v5 = nil
		local t = {}

		local function selectMutation(p1) --[[ selectMutation | Line: 356 | Upvalues: v5 (ref), t (copy), v22 (copy), v2 (ref) ]]
			local v1 = if v5 then t[v5] else nil

			if v1 then
				local UIStroke = v1:FindFirstChildOfClass("UIStroke")

				if UIStroke then
					UIStroke.Color = v22
				end
			end

			v5 = p1

			local v23 = t[p1]

			if not v23 then
				return
			end

			local UIStroke = v23:FindFirstChildOfClass("UIStroke")

			if not UIStroke then
				return
			end

			UIStroke.Color = v2
		end

		local function openMachineUI() --[[ openMachineUI | Line: 374 | Upvalues: getEquippedMutatedFish (copy), SignalBag (ref), FishConfig (ref), Image (copy), t (copy), v5 (ref), MutationConfig (ref), ImageButton (copy), Mutations (copy), v22 (copy), v2 (ref), p1 (copy), v3 (copy) ]]
			local v1, v23 = getEquippedMutatedFish()

			if not (v1 and v23[1]) then
				SignalBag.Notification:Fire("You need to hold a fish with a mutation!")

				return
			end

			local v32 = FishConfig[v1]

			Image.Image = if v32 then v32.Image else ""

			for v6, v7 in t do
				v7:Destroy()
			end

			table.clear(t)
			v5 = nil

			for v8, v9 in v23 do
				local v10 = MutationConfig.Mutations[v9]

				if v10 then
					local v11 = ImageButton:Clone()

					v11.Image = v10.image
					v11.Visible = true
					v11.Parent = Mutations
					t[v9] = v11
					v11.MouseButton1Click:Connect(function() --[[ Line: 402 | Upvalues: v9 (copy), v5 (ref), t (ref), v22 (ref), v2 (ref) ]]
						local v1 = v9
						local v23 = if v5 then t[v5] else nil

						if v23 then
							local UIStroke = v23:FindFirstChildOfClass("UIStroke")

							if UIStroke then
								UIStroke.Color = v22
							end
						end

						v5 = v1

						local v3 = t[v1]

						if not v3 then
							return
						end

						local UIStroke = v3:FindFirstChildOfClass("UIStroke")

						if not UIStroke then
							return
						end

						UIStroke.Color = v2
					end)
				end
			end

			local v12 = v23[1]
			local v13 = if v5 then t[v5] else nil

			if v13 then
				local UIStroke = v13:FindFirstChildOfClass("UIStroke")

				if UIStroke then
					UIStroke.Color = v22
				end
			end

			v5 = v12

			local v14 = t[v12]

			if v14 then
				local UIStroke = v14:FindFirstChildOfClass("UIStroke")

				if UIStroke then
					UIStroke.Color = v2
				end
			end

			p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(v3)
		end

		local v6 = nil

		local function stashEquippedFishHandle() --[[ stashEquippedFishHandle | Line: 415 | Upvalues: LocalPlayer (ref), v6 (ref) ]]
			local Character = LocalPlayer.Character

			if not Character then
				return
			end

			for v1, v2 in Character:GetChildren() do
				if v2:IsA("Tool") then
					local Handle = v2:FindFirstChild("Handle")

					if Handle then
						v6 = Handle:Clone()

						return
					end

					break
				end
			end
		end

		Buy.MouseButton1Down:Connect(function() --[[ Line: 431 | Upvalues: v5 (ref), stashEquippedFishHandle (copy), Remotes (ref), p1 (copy) ]]
			if v5 then
				stashEquippedFishHandle()
				Remotes.StartMutationExtraction:Fire(v5)
				p1.UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(nil)
			end
		end)

		local t2 = {}
		local v7 = "idle"
		local v8 = nil

		local function updatePrompts() --[[ updatePrompts | Line: 445 | Upvalues: t2 (copy), v7 (ref) ]]
			for v1, v2 in t2 do
				v2.extract.Enabled = v7 == "idle"
				v2.claim.Enabled = if v7 == "done" then true else false
			end
		end

		local function updateAnimations() --[[ updateAnimations | Line: 452 | Upvalues: t2 (copy), v7 (ref) ]]
			for v1, v2 in t2 do
				local processingTrack = v2.processingTrack

				if processingTrack then
					if v7 == "processing" and v2.readyForProcessingFX then
						if not processingTrack.IsPlaying then
							processingTrack:Play()
						end

						continue
					end

					if processingTrack.IsPlaying then
						processingTrack:Stop()
					end
				end
			end
		end

		local function formatRemaining(p1) --[[ formatRemaining | Line: 468 ]]
			local v2 = math.max(0, (math.floor(p1)))

			return string.format("%d:%02d", v2 // 60, v2 % 60)
		end

		local function updateCountdownLabels() --[[ updateCountdownLabels | Line: 475 | Upvalues: t2 (copy), v7 (ref), v8 (ref) ]]
			for v1, v2 in t2 do
				local countdownLabel = v2.countdownLabel

				if countdownLabel then
					if v7 == "processing" and v8 then
						local v5 = math.max(0, (math.floor(v8 - workspace:GetServerTimeNow())))

						countdownLabel.Text = string.format("%d:%02d", v5 // 60, v5 % 60)

						continue
					end

					if v7 == "done" then
						countdownLabel.Text = "Ready!"

						continue
					end

					countdownLabel.Text = ""
				end
			end
		end

		local function setupMachine(p1) --[[ setupMachine | Line: 491 | Upvalues: t2 (copy), LocalPlayer (ref), openMachineUI (copy), Remotes (ref), CollectionService (ref), v7 (ref), updateCountdownLabels (copy), updateAnimations (copy) ]]
			if t2[p1] then
				return
			end

			local v1 = nil

			if p1:IsA("BasePart") then
				v1 = p1
			elseif p1:IsA("Model") then
				v1 = p1.PrimaryPart
			end

			if not v1 then
				return
			end

			local ExtractMutationPrompt = Instance.new("ProximityPrompt")

			ExtractMutationPrompt.Name = "ExtractMutationPrompt"
			ExtractMutationPrompt.Style = Enum.ProximityPromptStyle.Custom
			ExtractMutationPrompt.ActionText = "Extract Mutation"
			ExtractMutationPrompt.ObjectText = "Mutation Machine"
			ExtractMutationPrompt.MaxActivationDistance = 10
			ExtractMutationPrompt.RequiresLineOfSight = false
			ExtractMutationPrompt.Parent = v1
			ExtractMutationPrompt.Triggered:Connect(function(p1) --[[ Line: 513 | Upvalues: LocalPlayer (ref), openMachineUI (ref) ]]
				if p1 == LocalPlayer then
					openMachineUI()
				end
			end)

			local ClaimMutationJarPrompt = Instance.new("ProximityPrompt")

			ClaimMutationJarPrompt.Name = "ClaimMutationJarPrompt"
			ClaimMutationJarPrompt.Style = Enum.ProximityPromptStyle.Custom
			ClaimMutationJarPrompt.ActionText = "Claim Jar"
			ClaimMutationJarPrompt.ObjectText = "Mutation Machine"
			ClaimMutationJarPrompt.MaxActivationDistance = 10
			ClaimMutationJarPrompt.RequiresLineOfSight = false
			ClaimMutationJarPrompt.Enabled = false
			ClaimMutationJarPrompt.Parent = v1
			ClaimMutationJarPrompt.Triggered:Connect(function(p1) --[[ Line: 529 | Upvalues: LocalPlayer (ref), Remotes (ref) ]]
				if p1 == LocalPlayer then
					Remotes.ClaimMutationJar:Fire()
				end
			end)

			local v2 = p1:FindFirstAncestorOfClass("Model") or p1
			local v3 = nil

			for v4, v5 in CollectionService:GetTagged("MutationMachineBgui") do
				if v5:IsA("BillboardGui") and v5:IsDescendantOf(v2) then
					v3 = v5

					break
				end
			end

			local v6 = if v3 then v3:FindFirstChild("Restock", true) else v3
			local v72 = if v6 and v6:IsA("TextLabel") then v6 elseif v3 then v3:FindFirstChildWhichIsA("TextLabel", true) else v3
			local v8 = p1:FindFirstAncestorOfClass("Model")
			local v9 = nil
			local v10 = if v8 then v8:FindFirstChildWhichIsA("AnimationController", true) else v8

			if v10 then
				local Animator = v10:FindFirstChildOfClass("Animator")

				if not Animator then
					Animator = Instance.new("Animator")
					Animator.Parent = v10
				end

				local Animation = Instance.new("Animation")

				Animation.AnimationId = "rbxassetid://101177471906709"

				local ok, result = pcall(function() --[[ Line: 568 | Upvalues: Animator (ref), Animation (copy) ]]
					return Animator:LoadAnimation(Animation)
				end)

				if ok then
					result.Looped = true
					v9 = result
				end
			end

			t2[p1] = {
				jarDecoration = nil,
				runningSound = nil,
				fishInMachine = nil,
				readyForProcessingFX = false,
				extract = ExtractMutationPrompt,
				claim = ClaimMutationJarPrompt,
				countdownLabel = v72,
				processingTrack = v9,
				promptPart = v1
			}

			for v11, v12 in t2 do
				v12.extract.Enabled = v7 == "idle"
				v12.claim.Enabled = if v7 == "done" then true else false
			end

			updateCountdownLabels()
			updateAnimations()
		end

		for v9, v10 in CollectionService:GetTagged("MutationMachine") do
			setupMachine(v10)
		end

		CollectionService:GetInstanceAddedSignal("MutationMachine"):Connect(setupMachine)
		Remotes.MutationMachineStateChanged:On(function(p1) --[[ Line: 598 | Upvalues: v7 (ref), v8 (ref), t2 (copy), v6 (ref), animateFishIntoMachine (ref), buildFishHandleFromIdentity (ref), updateAnimations (copy), showJarDecoration (ref), updateCountdownLabels (copy) ]]
			if typeof(p1) ~= "table" then
				return
			end

			if typeof(p1.State) ~= "string" then
				return
			end

			local v1 = v7

			v7 = p1.State
			v8 = if typeof(p1.EndsAt) == "number" then p1.EndsAt else nil

			local v3 = if typeof(p1.MutationId) == "string" then p1.MutationId else nil
			local v4 = if typeof(p1.FishConfigName) == "string" then p1.FishConfigName else nil
			local v5 = if typeof(p1.FishLevel) == "number" then p1.FishLevel else nil
			local v62 = if typeof(p1.FishMutation) == "string" then p1.FishMutation else nil
			local v72 = if v7 == "processing" then if v1 == "processing" then false else true else false
			local v82 = if v7 == "done" then if v1 == "done" then false else true else false
			local v9 = if v7 == "idle" then v1 ~= "idle" else false

			if v72 then
				for v10, v11 in t2 do
					v11.readyForProcessingFX = false

					if v11.fishInMachine then
						v11.fishInMachine:Destroy()
						v11.fishInMachine = nil
					end

					if v6 then
						animateFishIntoMachine(v11, v6:Clone())
					elseif v4 then
						local v12 = buildFishHandleFromIdentity(v4, v5, v62)

						if v12 then
							animateFishIntoMachine(v11, v12)
						end
					end

					task.delay(1.5, function() --[[ Line: 637 | Upvalues: v7 (ref), v11 (copy), updateAnimations (ref) ]]
						if v7 ~= "processing" then
							return
						end

						v11.readyForProcessingFX = true

						local v1 = v11

						if v1.runningSound then
							updateAnimations()

							return
						end

						local Sound = Instance.new("Sound")

						Sound.SoundId = "rbxassetid://132644728084213"
						Sound.Volume = 0.4
						Sound.Looped = true
						Sound.Parent = v1.promptPart
						Sound:Play()
						v1.runningSound = Sound
						updateAnimations()
					end)
				end

				if v6 then
					v6:Destroy()
					v6 = nil
				end
			elseif v82 then
				for v13, v14 in t2 do
					v14.readyForProcessingFX = false

					if v14.runningSound then
						v14.runningSound:Stop()
						v14.runningSound:Destroy()
						v14.runningSound = nil
					end

					if v14.fishInMachine then
						v14.fishInMachine:Destroy()
						v14.fishInMachine = nil
					end

					showJarDecoration(v14, v3)
					task.delay(1, function() --[[ Line: 658 | Upvalues: v14 (copy) ]]
						local Sound = Instance.new("Sound")

						Sound.SoundId = "rbxassetid://128829553647714"
						Sound.Volume = 1
						Sound.Looped = false
						Sound.Parent = v14.promptPart
						Sound:Play()
						Sound.Ended:Once(function() --[[ Line: 90 | Upvalues: Sound (copy) ]]
							Sound:Destroy()
						end)
					end)
				end
			elseif v9 then
				for v15, v16 in t2 do
					v16.readyForProcessingFX = false

					if v16.runningSound then
						v16.runningSound:Stop()
						v16.runningSound:Destroy()
						v16.runningSound = nil
					end

					if v16.fishInMachine then
						v16.fishInMachine:Destroy()
						v16.fishInMachine = nil
					end

					if v16.jarDecoration then
						v16.jarDecoration:Destroy()
						v16.jarDecoration = nil
					end
				end
			end

			if v7 == "processing" then
				for v17, v18 in t2 do
					v18.extract.ActionText = "Processing..."
				end
			else
				for v19, v20 in t2 do
					v20.extract.ActionText = "Extract Mutation"
				end
			end

			for v21, v22 in t2 do
				v22.extract.Enabled = v7 == "idle"
				v22.claim.Enabled = if v7 == "done" then true else false
			end

			updateCountdownLabels()
			updateAnimations()
		end)

		local v11 = 0

		RunService.Heartbeat:Connect(function(p1) --[[ Line: 689 | Upvalues: v7 (ref), v11 (ref), updateCountdownLabels (copy) ]]
			debug.profilebegin("UECS/MutationMachineClient.Countdown")

			if v7 ~= "processing" then
				debug.profileend()

				return
			end

			v11 = v11 + p1

			if not (v11 < 1) then
				v11 = 0
				updateCountdownLabels()
			end

			debug.profileend()
		end)
		RunService.Heartbeat:Connect(function(p1) --[[ Line: 708 | Upvalues: LocalPlayer (ref), t2 (copy) ]]
			debug.profilebegin("UECS/MutationMachineClient.FishRotation")

			local Character = LocalPlayer.Character
			local v1 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character

			if v1 then
				for v2, v3 in t2 do
					local fishInMachine = v3.fishInMachine

					if fishInMachine and (fishInMachine.Parent and not ((v1.Position - v3.promptPart.Position).Magnitude > 60)) then
						fishInMachine:PivotTo(fishInMachine:GetPivot() * CFrame.Angles(0, 1.0471975511965976 * p1, 0))
					end
				end
			end

			debug.profileend()
		end)
		Remotes.RequestMutationMachineState:Fire()
	end
}