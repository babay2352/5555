-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ContextActionService = game:GetService("ContextActionService")
local GuiService = game:GetService("GuiService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local CashDisplay = require(ReplicatedStorage.shared.module.CashDisplay)
local ConvertValue = require(ReplicatedStorage.shared.util.ConvertValue)
local CurrenciesConfig = require(ReplicatedStorage.shared.config.CurrenciesConfig)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local ItemConfigsMap = require(ReplicatedStorage.shared.config.ItemConfigsMap)
local MilestonesConfig = require(ReplicatedStorage.shared.config.MilestonesConfig)
local MilestonesUI = require(ReplicatedStorage.shared.UECS.Components.MilestonesUI)
local MutationConfig = require(ReplicatedStorage.shared.config.MutationConfig)
local MutationList = require(ReplicatedStorage.shared.util.MutationList)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local bindToButtonPress = require(ReplicatedStorage.shared.util.bindToButtonPress)

require(ReplicatedStorage.shared.reflex.serverProfile)

local toRomanNumeral = require(ReplicatedStorage.shared.util.toRomanNumeral)
local t = {}
local t2 = {
	UECS = nil,
	Priority = 30
}

for v1 in MilestonesConfig do
	table.insert(t, v1)
end

table.sort(t)

local v2 = nil

local function getFrame() --[[ getFrame | Line: 97 | Upvalues: Players (copy) ]]
	return Players.LocalPlayer.PlayerGui:WaitForChild("MainUI").Milestones
end

local function getTrackProgress(p1, p2) --[[ getTrackProgress | Line: 103 | Upvalues: MilestonesConfig (copy) ]]
	local milestones = p2.milestones

	return MilestonesConfig[p1].selector(p2), p2.milestones and milestones.claimed[p1] or 0, milestones and milestones.maxClaimable[p1] or 0
end

local function populateRewards(p1, p2) --[[ populateRewards | Line: 110 | Upvalues: Players (copy), CurrenciesConfig (copy), ItemConfigsMap (copy), ConvertValue (copy), MutationList (copy), MutationConfig (copy) ]]
	local Milestones = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI").Milestones

	for v1, v2 in p1:GetChildren() do
		if v2:IsA("GuiObject") then
			v2:Destroy()
		end
	end

	for v4, v5 in p2 do
		local v3
		local v6 = Milestones.Templates.ItemContainer:Clone()
		local v7 = nil
		local v8 = nil

		if v5.rewardType == "currency" then
			local v9 = CurrenciesConfig[v5.rewardId]

			v3 = if v9 then v9.icon else ""
		else
			local v10 = ItemConfigsMap.resolve(v5.rewardId)

			v3 = v10 and (v10.Image or v10.Icon) or ""
			v7, v8 = v5.rewardExtraData and v5.rewardExtraData.Level, v5.rewardExtraData and v5.rewardExtraData.Mutation
		end

		v6.Name = ("Reward%*"):format(v4)
		v6.LayoutOrder = v4
		v6.ItemButton.Icon.Image = v3
		v6.ItemButton.LevelLabel.Visible = true
		v6.ItemButton.LevelLabel.Text = if v7 then ("Lv. %* x%*"):format(v7, (ConvertValue.suffixformat(v5.rewardAmount))) else ("x%*"):format((ConvertValue.suffixformat(v5.rewardAmount)))

		local v15 = if typeof(v8) == "string" then MutationList.parse(v8) else {}
		local v16 = MutationList.best(v15)

		if v16 then
			v6.ItemButton.MutationIcon.Image = MutationConfig.Mutations[v16].image
			v6.ItemButton.MutationIcon.Visible = true
			v6.ItemButton.MutationIcon.Count.Text = ("+%*"):format(#v15 - 1)
			v6.ItemButton.MutationIcon.Count.Visible = if #v15 > 1 then true else false
		else
			v6.ItemButton.MutationIcon.Visible = false
			v6.ItemButton.MutationIcon.Count.Visible = false
		end

		v6.ItemButton.EarningsLabel.Visible = false
		v6.ItemButton.SelectStroke.Enabled = false
		v6.ItemButton.Selectable = false
		v6.Visible = true
		v6.Parent = p1
	end

	p1.CanvasSize = UDim2.fromOffset(p1.UIListLayout.AbsoluteContentSize.X, 0)
end

local function populateMilestone(p1, p2, p3, p4) --[[ populateMilestone | Line: 165 | Upvalues: MilestonesConfig (copy), toRomanNumeral (copy), CashDisplay (copy), ConvertValue (copy), populateRewards (copy) ]]
	local v1 = MilestonesConfig[p2]
	local v2 = v1.milestones[p3]
	local milestones = p4.milestones
	local v4 = milestones and milestones.maxClaimable[p2] or 0
	local v5 = MilestonesConfig[p2].selector(p4)
	local v6 = if p3 <= (milestones and milestones.claimed[p2] or 0) then true else false

	p1:SetAttribute("trackId", p2)
	p1:SetAttribute("tier", p3)
	p1.MilestoneIcon.Shine.Icon.Image = v1.icon
	p1.MilestoneData.MilestoneTitle.Text = ("%* (Tier %*)"):format(v1.displayName, (toRomanNumeral(p3)))
	CashDisplay.applyTokens(p1.MilestoneData.MilestoneTarget, v1.getTierDescription(p3), {
		Compact = true
	})

	local v7, v8, v9

	if v6 then
		v7 = 1
		v8 = v5
		v9 = v4
	elseif v2.target > 0 then
		v7 = math.clamp(v5 / v2.target, 0, 1)
		v8 = v5
		v9 = v4
	else
		v7 = 0
		v8 = v5
		v9 = v4
	end

	p1.MilestoneData.ProgressBar.Progress.Size = UDim2.fromScale(v7, 1)

	local ProgressText = p1.MilestoneData.ProgressBar.ProgressText

	if v6 then
		CashDisplay.setPlainText(ProgressText, "Claimed")
	elseif v1.cashTrack then
		local t = {}
		local t2 = {
			Compact = true
		}

		t2.Value = math.min(v8, v2.target)
		t[1] = t2
		t[2] = "/"
		t[3] = {
			Compact = true,
			Value = v2.target
		}
		CashDisplay.applyParts(ProgressText, t)
	else
		CashDisplay.setPlainText(ProgressText, (("%*/%*"):format(ConvertValue.suffixformat((math.min(v8, v2.target))), (ConvertValue.suffixformat(v2.target)))))
	end

	p1.RewardFrame.ClaimButton.Visible = not v6 and (if p3 <= v9 then true else false)
	p1.RewardFrame.ClaimButton.Selectable = false

	local v12 = ("%*_%*"):format(p2, p3)

	if p1:GetAttribute("rewardsKey") ~= v12 then
		p1:SetAttribute("rewardsKey", v12)
		populateRewards(p1.RewardFrame.Rewards, v2.rewards)
	end

	p1.Visible = true
end

local v3 = nil

local function acquireRow(p1, p2) --[[ acquireRow | Line: 215 | Upvalues: Players (copy), v2 (ref), v3 (ref), Remotes (copy) ]]
	local Milestones = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI").Milestones
	local v1 = Milestones.Content:FindFirstChild(p1)

	if v1 then
		v1.LayoutOrder = p2
		v1.SelectionOrder = p2

		return v1
	end

	local v22 = Milestones.Templates.MilestoneTemplate:Clone()

	v22.Name = p1
	v22.LayoutOrder = p2
	v22.SelectionOrder = p2

	local UIListLayout = v22.RewardFrame.Rewards.UIListLayout

	UIListLayout:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(function() --[[ Line: 230 | Upvalues: v22 (copy), UIListLayout (copy) ]]
		v22.RewardFrame.Rewards.CanvasSize = UDim2.fromOffset(UIListLayout.AbsoluteContentSize.X, 0)
	end)
	v22.Activated:Connect(function() --[[ Line: 234 | Upvalues: v2 (ref), v22 (copy), v3 (ref) ]]
		if v2 then
			return
		end

		local v1 = v22:GetAttribute("trackId")

		if typeof(v1) == "string" then
			v2 = v1
			v3()
		end
	end)
	v22.RewardFrame.ClaimButton.Activated:Connect(function() --[[ Line: 246 | Upvalues: v22 (copy), Remotes (ref) ]]
		local v1 = v22:GetAttribute("trackId")

		if typeof(v1) ~= "string" then
			return
		end

		Remotes.RequestClaimMilestone:Fire(v1)
	end)
	v22.Parent = Milestones.Content

	return v22
end

local function syncSelectionVisuals() --[[ syncSelectionVisuals | Line: 257 | Upvalues: Players (copy), GuiService (copy) ]]
	local Milestones = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI").Milestones
	local SelectedObject = GuiService.SelectedObject

	for v1, v2 in Milestones.Content:GetChildren() do
		if v2:IsA("TextButton") then
			local RewardFrame = v2:FindFirstChild("RewardFrame")
			local v3 = if RewardFrame then RewardFrame:FindFirstChild("ClaimButton") else RewardFrame

			if v3 then
				v3.ClipsDescendants = SelectedObject ~= v2
			end
		end
	end
end

local function restoreSelection() --[[ restoreSelection | Line: 272 | Upvalues: Players (copy), UserInputService (copy), GuiService (copy) ]]
	local Milestones = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI").Milestones

	if not Milestones.Visible then
		return
	end

	if UserInputService.PreferredInput ~= Enum.PreferredInput.Gamepad then
		return
	end

	local SelectedObject = GuiService.SelectedObject

	if SelectedObject and SelectedObject:IsDescendantOf(Milestones) then
		return
	end

	GuiService:Select(Milestones.Content)
end

v3 = function() --[[ Line: 287 | Upvalues: Players (copy), ClientPlayerData (copy), v2 (ref), MilestonesConfig (copy), populateMilestone (copy), acquireRow (copy), t (copy), UserInputService (copy), GuiService (copy), syncSelectionVisuals (copy) ]]
	local Milestones = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI").Milestones
	local v1 = ClientPlayerData.serverProfile:getState()

	Milestones.DetailsControl.SelectTip.Visible = v2 == nil
	Milestones.DetailsControl.BackButton.Visible = if v2 == nil then false else true

	local t2 = {}

	if v2 then
		for v4 in MilestonesConfig[v2].milestones do
			local v5 = ("%*_%*"):format(v2, v4)

			t2[v5] = true
			populateMilestone(acquireRow(v5, v4), v2, v4, v1)
		end
	else
		for v6, v7 in t do
			local milestones = v1.milestones
			local _ = milestones and milestones.maxClaimable[v7]

			MilestonesConfig[v7].selector(v1)

			local v10 = math.clamp((v1.milestones and milestones.claimed[v7] or 0) + 1, 1, #MilestonesConfig[v7].milestones)

			t2[v7] = true
			populateMilestone(acquireRow(v7, v6), v7, v10, v1)
		end
	end

	for v11, v12 in Milestones.Content:GetChildren() do
		if v12:IsA("TextButton") and not t2[v12.Name] then
			v12:Destroy()
		end
	end

	local Milestones2 = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI").Milestones

	if Milestones2.Visible and UserInputService.PreferredInput == Enum.PreferredInput.Gamepad then
		local SelectedObject = GuiService.SelectedObject

		if not (SelectedObject and SelectedObject:IsDescendantOf(Milestones2)) then
			GuiService:Select(Milestones2.Content)
		end
	end

	syncSelectionVisuals()
end

local function goBack(p1) --[[ goBack | Line: 321 | Upvalues: v2 (ref), v3 (ref) ]]
	if v2 then
		v2 = nil
		v3()
	else
		p1()
	end
end

local function claimSelected() --[[ claimSelected | Line: 330 | Upvalues: GuiService (copy), Remotes (copy) ]]
	local SelectedObject = GuiService.SelectedObject

	if not SelectedObject then
		return
	end

	local v1 = SelectedObject:GetAttribute("trackId")

	if typeof(v1) ~= "string" then
		return
	end

	local RewardFrame = SelectedObject:FindFirstChild("RewardFrame")
	local v2 = if RewardFrame then RewardFrame:FindFirstChild("ClaimButton") else RewardFrame

	if not v2 or v2.Visible then
		Remotes.RequestClaimMilestone:Fire(v1)
	end
end

function t2.Init(p1) --[[ Init | Line: 347 | Upvalues: Players (copy), MilestonesUI (copy), TweenService (copy), ClientPlayerData (copy), t (copy), MilestonesConfig (copy), v3 (ref), v2 (ref), bindToButtonPress (copy), claimSelected (copy), UserInputService (copy), GuiService (copy), ContextActionService (copy), syncSelectionVisuals (copy) ]]
	local MainUI = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI")
	local Milestones = MainUI.Milestones
	local v1 = MilestonesUI.Add(Milestones)
	local v22 = p1.UECS:WaitForAnyComponent("UIFrameOpener")
	local HUD = MainUI:WaitForChild("HUD")
	local v32 = HUD:FindFirstChild("Buttons") or HUD:FindFirstChild("ButtonsRightSide")
	local v4 = if v32 then v32:FindFirstChild("Milestones") else nil
	local Quests = MainUI:FindFirstChild("Quests")
	local v5 = if Quests then Quests:FindFirstChild("TopBar") else nil
	local v6 = if v5 then v5:FindFirstChild("Milestones", true) else nil
	local t2 = {}

	local function collectAlert(p1) --[[ collectAlert | Line: 366 | Upvalues: t2 (copy) ]]
		local v1 = if p1 then p1:FindFirstChild("Alert") else nil

		if not (v1 and v1:IsA("GuiObject")) then
			return
		end

		table.insert(t2, v1)
	end

	local v7 = if v4 then v4:FindFirstChild("Alert") else nil

	if v7 and v7:IsA("GuiObject") then
		table.insert(t2, v7)
	end

	local v8 = if v6 then v6:FindFirstChild("Alert") else nil

	if v8 and v8:IsA("GuiObject") then
		table.insert(t2, v8)
	end

	local t3 = {}

	local function setAlertShown(p1, p2) --[[ setAlertShown | Line: 376 | Upvalues: t3 (copy), TweenService (ref) ]]
		if p2 then
			if p1.Visible and t3[p1] then
				return
			end

			p1.Visible = true
			p1.Rotation = -8

			local v1 = TweenService:Create(p1, TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true), {
				Rotation = 8
			})

			t3[p1] = v1
			v1:Play()
		else
			local v2 = t3[p1]

			if v2 then
				v2:Cancel()
				t3[p1] = nil
			end

			p1.Rotation = 0
			p1.Visible = false
		end
	end

	local function updateAlert() --[[ updateAlert | Line: 401 | Upvalues: t2 (copy), ClientPlayerData (ref), t (ref), MilestonesConfig (ref), setAlertShown (copy) ]]
		if #t2 == 0 then
			return
		end

		local v1 = ClientPlayerData.serverProfile:getState()
		local v2 = false

		for v3, v4 in t do
			local milestones = v1.milestones

			MilestonesConfig[v4].selector(v1)

			if (v1.milestones and milestones.claimed[v4] or 0) < (milestones and milestones.maxClaimable[v4] or 0) then
				v2 = true

				break
			end
		end

		for v7, v8 in t2 do
			setAlertShown(v8, v2)
		end
	end

	local function refresh() --[[ refresh | Line: 421 | Upvalues: v3 (ref), updateAlert (copy) ]]
		v3()
		updateAlert()
	end

	local function closePanel() --[[ closePanel | Line: 426 | Upvalues: v22 (copy) ]]
		v22.OpenedUIComponent:Set(nil)
	end

	v1.Visible.OnChange:Connect(function(p1, p2) --[[ Line: 430 | Upvalues: Milestones (copy), v2 (ref), v3 (ref), bindToButtonPress (ref), closePanel (copy), v22 (copy), claimSelected (ref), UserInputService (ref), GuiService (ref), ContextActionService (ref) ]]
		Milestones.Visible = p1

		if p1 == p2 then
			return
		end

		if p1 then
			v2 = nil
			v3()
			bindToButtonPress("MilestonesBackAction", Enum.KeyCode.ButtonB, function() --[[ Line: 440 | Upvalues: closePanel (ref), v2 (ref), v3 (ref), v22 (ref) ]]
				if v2 then
					v2 = nil
					v3()
				else
					v22.OpenedUIComponent:Set(nil)
				end
			end)
			bindToButtonPress("MilestonesClaimAction", Enum.KeyCode.ButtonX, claimSelected)

			if UserInputService.PreferredInput == Enum.PreferredInput.Gamepad then
				GuiService:Select(Milestones.Content)
			end
		else
			ContextActionService:UnbindAction("MilestonesBackAction")
			ContextActionService:UnbindAction("MilestonesClaimAction")
			GuiService.SelectedObject = nil
		end
	end)
	GuiService:GetPropertyChangedSignal("SelectedObject"):Connect(function() --[[ Line: 455 | Upvalues: syncSelectionVisuals (ref), v1 (copy), Players (ref), UserInputService (ref), GuiService (ref) ]]
		syncSelectionVisuals()

		if not v1.Visible:Get() then
			return
		end

		local Milestones = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI").Milestones

		if not Milestones.Visible then
			return
		end

		if UserInputService.PreferredInput ~= Enum.PreferredInput.Gamepad then
			return
		end

		local SelectedObject = GuiService.SelectedObject

		if SelectedObject and SelectedObject:IsDescendantOf(Milestones) then
			return
		end

		GuiService:Select(Milestones.Content)
	end)
	Milestones.TopBar.CloseButton.Activated:Connect(closePanel)
	Milestones.DetailsControl.BackButton.Activated:Connect(function() --[[ Line: 465 | Upvalues: v2 (ref), v3 (ref) ]]
		v2 = nil
		v3()
	end)
	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 470 ]]
		return p1.milestones
	end, refresh)

	for v9, v10 in t do
		ClientPlayerData.serverProfile:subscribe(MilestonesConfig[v10].selector, refresh)
	end

	v3()
	updateAlert()
end

return t2