-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local MarketplaceService = game:GetService("MarketplaceService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ActiveEffects = require(ReplicatedStorage.shared.effects.ActiveEffects)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local LuckyblockConfig = require(ReplicatedStorage.shared.config.LuckyblockConfig)
local MonetizationConfig = require(ReplicatedStorage.shared.config.MonetizationConfig)
local getLocalPolicyInfo = require(ReplicatedStorage.shared.util.getLocalPolicyInfo)
local t = {
	UECS = nil
}
local v1 = utf8.char(57346)
local DevProducts = MonetizationConfig.DevProducts
local t2 = {
	[0] = DevProducts.X2ServerLuck.ProductId,
	[2] = DevProducts.X4ServerLuck.ProductId,
	[4] = DevProducts.X8ServerLuck.ProductId,
	[8] = DevProducts.X16ServerLuck.ProductId,
	[16] = DevProducts.X16ServerLuck.ProductId
}
local t3 = {
	[0] = "x2 Server Luck",
	[2] = "x4 Server Luck",
	[4] = "x8 Server Luck",
	[8] = "x16 Server Luck",
	[16] = "x16 Server Luck +15 min"
}

local function currentLuckTier() --[[ currentLuckTier | Line: 66 | Upvalues: ActiveEffects (copy) ]]
	for v1, v2 in ActiveEffects.GetActive() do
		if v2.Name == "X2Luck" then
			return if v2.EffectOverrides then v2.EffectOverrides.Luck or 2 else 2
		end
	end

	return 0
end

local function luckyblockShopEntry(p1, p2) --[[ luckyblockShopEntry | Line: 100 | Upvalues: DevProducts (copy), LuckyblockConfig (copy) ]]
	local v1 = DevProducts[p2]

	return {
		kind = "store",
		paidRandom = true,
		promptName = p1,
		storeCard = v1.StoreEntry,
		resolve = function() --[[ resolve | Line: 107 | Upvalues: v1 (copy), LuckyblockConfig (ref) ]]
			local v12 = v1.LuckyblockConfigName or ""
			local v2 = LuckyblockConfig[v12]

			return 0, if v2 then v2.DisplayName or v12 else v12
		end
	}
end

local t4 = {}
local LuckyblockBuy1 = DevProducts.LuckyblockBuy1

t4.SpiderLuckyblock = {
	promptName = "ShopSpiderLuckyblock",
	kind = "store",
	paidRandom = true,
	storeCard = LuckyblockBuy1.StoreEntry,
	resolve = function() --[[ resolve | Line: 107 | Upvalues: LuckyblockBuy1 (copy), LuckyblockConfig (copy) ]]
		local v12 = LuckyblockBuy1.LuckyblockConfigName or ""
		local v2 = LuckyblockConfig[v12]

		return 0, if v2 then v2.DisplayName or v12 else v12
	end
}

local LuckyblockBuy12 = DevProducts.LuckyblockBuy1

t4.MapLuckyblock = {
	promptName = "ShopMapLuckyblock",
	kind = "store",
	paidRandom = true,
	storeCard = LuckyblockBuy12.StoreEntry,
	resolve = function() --[[ resolve | Line: 107 | Upvalues: LuckyblockBuy12 (copy), LuckyblockConfig (copy) ]]
		local v12 = LuckyblockBuy12.LuckyblockConfigName or ""
		local v2 = LuckyblockConfig[v12]

		return 0, if v2 then v2.DisplayName or v12 else v12
	end
}

local MountLuckyblockBuy1 = DevProducts.MountLuckyblockBuy1

t4.MountLuckyblock = {
	promptName = "ShopMountLuckyblock",
	kind = "store",
	paidRandom = true,
	storeCard = MountLuckyblockBuy1.StoreEntry,
	resolve = function() --[[ resolve | Line: 107 | Upvalues: MountLuckyblockBuy1 (copy), LuckyblockConfig (copy) ]]
		local v12 = MountLuckyblockBuy1.LuckyblockConfigName or ""
		local v2 = LuckyblockConfig[v12]

		return 0, if v2 then v2.DisplayName or v12 else v12
	end
}
t4.ServerLuck = {
	promptName = "BuyServerLuck",
	kind = "product",
	dynamic = true,
	resolve = function() --[[ resolve | Line: 128 | Upvalues: currentLuckTier (copy), t2 (copy), t3 (copy) ]]
		local v1 = currentLuckTier()

		return t2[v1] or t2[0], t3[v1] or t3[0]
	end
}

local t5 = {}
local t6 = {}

local function applyPrice(p1, p2) --[[ applyPrice | Line: 141 | Upvalues: t5 (copy), v1 (copy), t6 (copy), MarketplaceService (copy) ]]
	local v12 = t5[p2]

	if v12 then
		p1.ActionText = v12

		return
	end

	p1.ActionText = v1 .. " ..."

	if not t6[p2] then
		t6[p2] = true
		task.spawn(function() --[[ Line: 153 | Upvalues: MarketplaceService (ref), p2 (copy), t6 (ref), t5 (ref), v1 (ref) ]]
			local ok, result = pcall(function() --[[ Line: 154 | Upvalues: MarketplaceService (ref), p2 (ref) ]]
				return MarketplaceService:GetProductInfo(p2, Enum.InfoType.Product)
			end)

			t6[p2] = false

			if not (ok and (result and result.PriceInRobux)) then
				return
			end

			local v2 = p2

			t5[v2] = v1 .. " " .. tostring(result.PriceInRobux)
		end)
	end

	task.spawn(function() --[[ Line: 165 | Upvalues: t6 (ref), p2 (copy), t5 (ref), p1 (copy) ]]
		while t6[p2] do
			task.wait(0.25)
		end

		local v1 = t5[p2]

		if not (v1 and p1.Parent) then
			return
		end

		p1.ActionText = v1
	end)
end

local v2 = setmetatable({}, {
	__mode = "k"
})
local v3 = setmetatable({}, {
	__mode = "k"
})

local function refreshPrompt(p1, p2) --[[ refreshPrompt | Line: 185 | Upvalues: applyPrice (copy) ]]
	local v1, v2 = p2.resolve()

	p1.ObjectText = v2
	p1:SetAttribute("ProductId", v1)

	if p2.kind == "store" then
		p1.ActionText = "Shop"
	else
		applyPrice(p1, v1)
	end
end

local function openStoreAt(p1) --[[ openStoreAt | Line: 201 | Upvalues: t (copy), Players (copy) ]]
	local UECS = t.UECS

	if not UECS then
		return
	end

	UECS:WaitForAnyComponent("UIFrameOpener").OpenedUIComponent:Set(UECS:WaitForAnyComponent("Store"))

	if not p1 then
		return
	end

	local MainUI = Players.LocalPlayer.PlayerGui:FindFirstChild("MainUI")
	local v1 = if MainUI then MainUI:FindFirstChild("Store") else MainUI
	local v2 = if v1 then v1:FindFirstChild("Content") else v1
	local v3 = if v2 then v2:FindFirstChild("ScrollingFrame") else v2

	if not v3 then
		return
	end

	local v4 = v3:FindFirstChild(p1, true)

	if not v4 then
		warn((("[TaggedProductPrompts] no store card named \"%*\" \226\128\148 pad opens the store unscrolled"):format(p1)))

		return
	end

	task.wait()

	if v4.Parent and v3.Parent then
		v3.CanvasPosition = v4.AbsolutePosition - v3.AbsolutePosition + v3.CanvasPosition
	end
end

local function resolveHost(p1) --[[ resolveHost | Line: 237 ]]
	if p1:IsA("BasePart") then
		return p1
	end

	if not p1:IsA("Model") then
		return nil
	end

	local Main = p1:FindFirstChild("Main")

	return p1.PrimaryPart or (if Main and Main:IsA("BasePart") then Main else nil) or p1:FindFirstChildWhichIsA("BasePart", true)
end

local function setupPrompt(p1, p2, p3) --[[ setupPrompt | Line: 250 | Upvalues: resolveHost (copy), applyPrice (copy), v2 (copy), openStoreAt (copy), MarketplaceService (copy) ]]
	local v1 = resolveHost(p1)

	if not v1 then
		local v22 = os.clock() + 10

		while not v1 and (p1.Parent and os.clock() < v22) do
			task.wait(0.25)
			v1 = resolveHost(p1)
		end
	end

	if v1 then
		local v4 = v1:FindFirstChildWhichIsA("ProximityPrompt")
		local v5 = if v4 then v4 else Instance.new("ProximityPrompt")

		v5.Name = p3.promptName
		v5.Style = Enum.ProximityPromptStyle.Custom
		v5.HoldDuration = 0.3
		v5.MaxActivationDistance = 12
		v5.RequiresLineOfSight = false

		local v6, v7 = p3.resolve()

		v5.ObjectText = v7
		v5:SetAttribute("ProductId", v6)

		if p3.kind == "store" then
			v5.ActionText = "Shop"
		else
			applyPrice(v5, v6)
		end

		v5.Parent = v1

		if p3.dynamic then
			v2[v5] = p3
		end

		v5.Triggered:Connect(function(p1) --[[ Line: 286 | Upvalues: p3 (copy), openStoreAt (ref), MarketplaceService (ref) ]]
			if p3.kind == "store" then
				task.spawn(openStoreAt, p3.storeCard)

				return
			end

			local v1 = p3.resolve()

			if not (v1 <= 0) then
				MarketplaceService:PromptProductPurchase(p1, v1)
			end
		end)
	elseif p1.Parent then
		warn((("[TaggedProductPrompts] \"%*\" is on a %* (%*) with no BasePart \226\128\148 needs a part or a model containing one"):format(p2, p1.ClassName, (p1:GetFullName()))))
	end
end

local function onTagged(p1, p2, p3) --[[ onTagged | Line: 302 | Upvalues: v3 (copy), setupPrompt (copy) ]]
	if not v3[p1] then
		v3[p1] = true
		task.spawn(setupPrompt, p1, p2, p3)
	end
end

function t.Init(p1) --[[ Init | Line: 312 | Upvalues: Players (copy), getLocalPolicyInfo (copy), t4 (copy), CollectionService (copy), v3 (copy), setupPrompt (copy), ActiveEffects (copy), v2 (copy), applyPrice (copy) ]]
	local LocalPlayer = Players.LocalPlayer
	local ArePaidRandomItemsRestricted = getLocalPolicyInfo().ArePaidRandomItemsRestricted

	for v1, v22 in t4 do
		if not (v22.paidRandom and ArePaidRandomItemsRestricted) then
			for v32, v4 in CollectionService:GetTagged(v1) do
				if not v3[v4] then
					v3[v4] = true
					task.spawn(setupPrompt, v4, v1, v22)
				end
			end

			CollectionService:GetInstanceAddedSignal(v1):Connect(function(p1) --[[ Line: 327 | Upvalues: v1 (copy), v22 (copy), v3 (ref), setupPrompt (ref) ]]
				local v12 = v1
				local v2 = v22

				if not v3[p1] then
					v3[p1] = true
					task.spawn(setupPrompt, p1, v12, v2)
				end
			end)
			CollectionService:GetInstanceRemovedSignal(v1):Connect(function(p1) --[[ Line: 332 | Upvalues: v3 (ref) ]]
				v3[p1] = nil
			end)
		end
	end

	ActiveEffects.Changed:Connect(function() --[[ Line: 338 | Upvalues: v2 (ref), applyPrice (ref) ]]
		for v1, v22 in v2 do
			if v1.Parent then
				local v3, v4 = v22.resolve()

				v1.ObjectText = v4
				v1:SetAttribute("ProductId", v3)

				if v22.kind == "store" then
					v1.ActionText = "Shop"

					continue
				end

				applyPrice(v1, v3)
			end
		end
	end)
end

return t