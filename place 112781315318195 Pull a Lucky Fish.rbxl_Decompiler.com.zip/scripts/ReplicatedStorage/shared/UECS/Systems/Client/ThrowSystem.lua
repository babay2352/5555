-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ContentProvider = game:GetService("ContentProvider")
local MarketplaceService = game:GetService("MarketplaceService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local SoundService = game:GetService("SoundService")
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")
local Workspace = game:GetService("Workspace")
local ActiveEffects = require(ReplicatedStorage.shared.effects.ActiveEffects)
local ActiveFishRodRig = require(ReplicatedStorage.client.ActiveFishRodRig)
local GoldenThrow = require(ReplicatedStorage.client.throw.GoldenThrow)
local ThrowAccuracy = require(ReplicatedStorage.client.throw.ThrowAccuracy)
local ThrowAnimations = require(ReplicatedStorage.client.throw.ThrowAnimations)
local ThrowFX = require(ReplicatedStorage.client.throw.ThrowFX)
local ThrowSystemBossSequence = require(ReplicatedStorage.shared.module.ThrowSystemBossSequence)
local Worlds = require(ReplicatedStorage.shared.util.Worlds)
local getPotionMultiplier = require(ReplicatedStorage.shared.util.getPotionMultiplier)
local client = ReplicatedStorage:FindFirstChild("client")
local v1 = client and client:FindFirstChild("CatchEffects")
local v2

if v1 then
	local ok, result = pcall(require, v1)

	if ok then
		v2 = result
	else
		warn("[ThrowSystem] CatchEffects failed to load \226\128\148 catch VFX disabled:", result)
		v2 = {
			OnHookHitWater = function() --[[ OnHookHitWater | Line: 40 ]]
				return 0
			end,
			StopHookHitWater = function() --[[ StopHookHitWater | Line: 43 ]] end,
			OnFishAddedToBackpack = function() --[[ OnFishAddedToBackpack | Line: 44 ]] end,
			Routing = {
				Special = {},
				SkyDrop = {},
				DarkIntro = {},
				BeamThenVeil = {}
			},
			SkyDropFx = {}
		}
	end
else
	warn("[ThrowSystem] CatchEffects not found in ReplicatedStorage.client \226\128\148 catch VFX disabled (check Rojo sync)")
	v2 = {
		OnHookHitWater = function() --[[ OnHookHitWater | Line: 40 ]]
			return 0
		end,
		StopHookHitWater = function() --[[ StopHookHitWater | Line: 43 ]] end,
		OnFishAddedToBackpack = function() --[[ OnFishAddedToBackpack | Line: 44 ]] end,
		Routing = {
			Special = {},
			SkyDrop = {},
			DarkIntro = {},
			BeamThenVeil = {}
		},
		SkyDropFx = {}
	}
end

local v3 = nil
local ClientMusicController = require(ReplicatedStorage.shared.UECS.Systems.Client.ClientMusicController)
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local ControlHint = require(ReplicatedStorage.client.ControlHint)
local FishConfig = require(ReplicatedStorage.shared.config.FishConfig)
local FishEarnings = require(ReplicatedStorage.shared.util.FishEarnings)
local GemsRewardHelper = require(ReplicatedStorage.shared.util.GemsRewardHelper)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local LuckyblockConfig = require(ReplicatedStorage.shared.config.LuckyblockConfig)
local MonetizationConfig = require(ReplicatedStorage.shared.config.MonetizationConfig)
local MutationList = require(ReplicatedStorage.shared.util.MutationList)
local NumberSpinner = require(ReplicatedStorage.shared.NumberSpinner.NumberSpinner)
local RarityLabel = require(ReplicatedStorage.shared.UECS.Components.RarityLabel)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local RollSystem = require(ReplicatedStorage.shared.UECS.Systems.Client.RollSystem)
local SFX = require(ReplicatedStorage.client.SFX)
local Satchel = require(ReplicatedStorage.client.Satchel)
local ShowupEffects = require(ReplicatedStorage.client.ShowupEffects)
local SplawikBiomeEffects = require(ReplicatedStorage.client.SplawikBiomeEffects)
local UIVFX = require(ReplicatedStorage.shared.module.UIVFX)
local VFX = require(ReplicatedStorage.client.VFX)
local calculateClickPower = require(ReplicatedStorage.shared.util.calculateClickPower)
local isGamepadActive = require(ReplicatedStorage.shared.util.isGamepadActive)
local notifications = require(ReplicatedStorage.shared.module.notifications)
local ButtonX = Enum.KeyCode.ButtonX
local ButtonX2 = Enum.KeyCode.ButtonX
local ButtonY = Enum.KeyCode.ButtonY
local ThrowLaunchSpeedFactor = require(ReplicatedStorage.shared.config.ThrowPacingConfig).ThrowLaunchSpeedFactor
local v4 = ThrowLaunchSpeedFactor - (2 - ThrowLaunchSpeedFactor)
local SkyDropFx = v2.SkyDropFx
local DiveMinBiome = require(ReplicatedStorage.shared.config.ThrowPacingConfig).DiveMinBiome
local DiveApexP = require(ReplicatedStorage.shared.config.ThrowPacingConfig).DiveApexP
local DiveFallTime = require(ReplicatedStorage.shared.config.ThrowPacingConfig).DiveFallTime
local AutoFishing = MonetizationConfig.Gamepasses.AutoFishing

local function ownsAutoFishing() --[[ ownsAutoFishing | Line: 302 | Upvalues: v3 (ref), Players (copy), AutoFishing (copy), GemsRewardHelper (copy) ]]
	if v3._hasFakeAutoFishing then
		return true
	end

	local v1 = Players.LocalPlayer:GetAttribute(AutoFishing.Attribute)

	if typeof(v1) == "number" and v1 > 1 then
		return true
	end

	return GemsRewardHelper.HasAutoFishing(Players.LocalPlayer)
end

local function buildHookInstance() --[[ buildHookInstance | Line: 334 | Upvalues: ReplicatedStorage (copy), ClientPlayerData (copy) ]]
	return require(ReplicatedStorage.shared.util.buildHookInstance)(ClientPlayerData.serverProfile:getState().fishRod)
end

local function moveSplawik(p1, p2, p3) --[[ moveSplawik | Line: 343 ]]
	if p2 then
		p2:SetPrimaryPartCFrame(p3)
	else
		p1.CFrame = p3
	end
end

local FishLimit = require(ReplicatedStorage.shared.config.InventoryConfig).FishLimit

local function isFishInventoryFull() --[[ isFishInventoryFull | Line: 353 | Upvalues: ClientPlayerData (copy), ReplicatedStorage (copy), FishLimit (copy) ]]
	if not ClientPlayerData.isPlayerDataLoaded then
		return false
	end

	local v1 = ClientPlayerData.serverProfile:getState()

	return FishLimit <= require(ReplicatedStorage.shared.config.InventoryConfig).countFish(v1)
end

v3 = {
	UECS = nil,
	_collectCastGeneration = 0
}

local v5 = false
local v6 = false
local v7 = false
local t = {
	maid = nil,
	Maid = require(ReplicatedStorage.shared.class.Maid)
}

function t.begin() --[[ begin | Line: 445 | Upvalues: t (copy) ]]
	t.flush()
	t.maid = t.Maid.new()
end
function t.flush() --[[ flush | Line: 450 | Upvalues: t (copy), ReplicatedStorage (copy) ]]
	if t.maid then
		t.maid:Destroy()
		t.maid = nil
	end

	require(ReplicatedStorage.client.RemoteFishingState).SetCutsceneSuppressed(false)
end
function t.give(p1) --[[ give | Line: 463 | Upvalues: t (copy) ]]
	if not t.maid then
		return
	end

	t.maid:GiveTask(p1)
end

local function ThrowProgress(p1) --[[ ThrowProgress | Line: 471 | Upvalues: ThrowLaunchSpeedFactor (copy), v4 (copy) ]]
	return ThrowLaunchSpeedFactor * p1 - v4 * p1 * p1 / 2
end

function v3.ThrowingSegment(p1, p2) --[[ ThrowingSegment | Line: 485 | Upvalues: ReplicatedStorage (copy) ]]
	local ok, result = xpcall(function() --[[ Line: 486 | Upvalues: p1 (copy), p2 (copy) ]]
		p1:_ThrowingSegmentBody(p2)
	end, debug.traceback)

	if ok then
		return
	end

	require(ReplicatedStorage.shared.util.reportError)("ThrowSystem.ThrowingSegment", result)
	p1:RecoverThrow("cast start")
end
function v3._ThrowingSegmentBody(p1, p2) --[[ _ThrowingSegmentBody | Line: 495 | Upvalues: v5 (ref), Remotes (copy), t (copy), Satchel (copy), Players (copy), ThrowAnimations (copy), ReplicatedStorage (copy), ClientPlayerData (copy), ButtonX (copy), v3 (ref) ]]
	v5 = true
	Remotes.SetFishState:Fire(v5)
	p1._collectCastGeneration = (p1._collectCastGeneration or 0) + 1
	t.begin()
	Satchel.SetEnabled(false)

	if p1.ThrowBarHint then
		p1.ThrowBarHint:Show()
	end

	local Character = Players.LocalPlayer.Character
	local HumanoidRootPart = Character.HumanoidRootPart

	HumanoidRootPart.Anchored = true

	local Humanoid = Character:FindFirstChildOfClass("Humanoid")

	if Humanoid then
		local Animator = Humanoid:FindFirstChildOfClass("Animator")

		if Animator then
			for v1, v2 in Animator:GetPlayingAnimationTracks() do
				v2:Stop(0.2)
			end
		end
	end

	ThrowAnimations.playIdle(Character)
	HumanoidRootPart.CFrame = CFrame.new(HumanoidRootPart.Position, HumanoidRootPart.Position + Vector3.new(-1, 0, 0))

	local ThrowBar = require(ReplicatedStorage.client.throw.ThrowBar)
	local CurrentCamera = workspace.CurrentCamera

	ThrowBar.beginCameraBlend(CurrentCamera.CFrame, CFrame.lookAt((HumanoidRootPart.CFrame * CFrame.new(7, 4, 7)).Position, HumanoidRootPart.Position + Vector3.new(-2.5, 0, -3)), CurrentCamera.FieldOfView)
	CurrentCamera.CameraType = Enum.CameraType.Scriptable

	local v32 = ClientPlayerData.serverProfile:getState()

	ThrowBar.preloadReleaseSound(if if (if v32 then v32.fishRod else v32) == "FISHROD_Cat" then true else false then "rbxassetid://134699420140804" else "rbxassetid://119135010875996")
	ThrowBar.start({
		frame = p1.ThrowingFrame,
		autoFire = p2,
		gamepadKey = ButtonX,
		hint = p1.ThrowBarHint,
		onCommit = function(p1) --[[ onCommit | Line: 553 | Upvalues: v3 (ref) ]]
			v3:ThrowWithForce(p1)
		end,
		onTimeout = function() --[[ onTimeout | Line: 557 | Upvalues: ReplicatedStorage (ref), ThrowBar (copy), v3 (ref) ]]
			require(ReplicatedStorage.shared.util.reportError)("ThrowSystem.ThrowBarTimeout", (("throw bar ran %*s with no commit input \226\128\148 cast aborted"):format(ThrowBar.Config.BarMaxDuration)))
			v3:RecoverThrow("throw bar timeout")
		end
	})
end
function v3.RecoverThrow(p1, p2) --[[ RecoverThrow | Line: 577 | Upvalues: t (copy), ReplicatedStorage (copy), ThrowAnimations (copy), RunService (copy), Players (copy), UIVFX (copy), ClientMusicController (copy), GoldenThrow (copy), Satchel (copy), v5 (ref), Remotes (copy), notifications (copy) ]]
	warn("[ThrowSystem] Cast failed during " .. p2 .. " \226\128\148 recovering control.")
	t.flush()

	local ThrowBar = require(ReplicatedStorage.client.throw.ThrowBar)

	ThrowBar.stop()
	ThrowAnimations.stopIdle()
	ThrowAnimations.stopBack()
	pcall(function() --[[ Line: 588 | Upvalues: ReplicatedStorage (ref), RunService (ref) ]]
		require(ReplicatedStorage.client.roll.HookSwimmers).despawn()
		require(ReplicatedStorage.client.roll.OddsBar).hide()
		require(ReplicatedStorage.client.roll.RollCameraFX).finish(true)
		require(ReplicatedStorage.client.roll.RollWaterFX).detach()
		require(ReplicatedStorage.client.ShowupEffects.CinematicBars).hide(true)
		RunService:UnbindFromRenderStep("ThrowFlightCamSway")
	end)

	local Character = Players.LocalPlayer.Character
	local v1 = if Character then Character:FindFirstChildOfClass("Humanoid") else Character
	local v2 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character

	if v2 then
		v2.Anchored = false
	end

	local CurrentCamera = workspace.CurrentCamera

	CurrentCamera.CameraType = Enum.CameraType.Custom

	if v1 then
		CurrentCamera.CameraSubject = v1
	end

	CurrentCamera.FieldOfView = ThrowBar.getBaseFov()

	if p1.ThrowingFrame then
		p1.ThrowingFrame.Visible = false

		local SpeedMeter = p1.ThrowingFrame:FindFirstChild("SpeedMeter")

		if SpeedMeter then
			SpeedMeter.Visible = false
		end
	end

	if p1.Blackout then
		p1.Blackout.BackgroundTransparency = 1
	end

	if not p1.PullHint then
		UIVFX.Vignette.Stop()
		ClientMusicController.SetMuted(false)
		GoldenThrow.stopFX()
		Satchel.SetEnabled(true)
		v5 = false
		Remotes.SetFishState:Fire(v5)
		notifications:Send("That cast glitched out \226\128\148 recovered! You can fish again.")

		return
	end

	p1.PullHint:Hide()
	UIVFX.Vignette.Stop()
	ClientMusicController.SetMuted(false)
	GoldenThrow.stopFX()
	Satchel.SetEnabled(true)
	v5 = false
	Remotes.SetFishState:Fire(v5)
	notifications:Send("That cast glitched out \226\128\148 recovered! You can fish again.")
end
function v3.ThrowWithForce(p1, p2) --[[ ThrowWithForce | Line: 634 | Upvalues: ReplicatedStorage (copy) ]]
	local ok, result = xpcall(function() --[[ Line: 638 | Upvalues: p1 (copy), p2 (copy) ]]
		p1:_ThrowWithForceBody(p2)
	end, debug.traceback)

	if ok then
		return
	end

	require(ReplicatedStorage.shared.util.reportError)("ThrowSystem.ThrowWithForce", result)
	p1:RecoverThrow("throw setup/flight")
end
function v3._ThrowWithForceBody(p1, p2) --[[ _ThrowWithForceBody | Line: 649 | Upvalues: Satchel (copy), Players (copy), ActiveFishRodRig (copy), ThrowAccuracy (copy), Remotes (copy), ReplicatedStorage (copy), notifications (copy), t (copy), v5 (ref), v6 (ref), SFX (copy), VFX (copy), TweenService (copy), ClientPlayerData (copy), GoldenThrow (copy), ThrowAnimations (copy), Workspace (copy), ActiveEffects (copy), getPotionMultiplier (copy), Worlds (copy), RunService (copy), DiveMinBiome (copy), ThrowLaunchSpeedFactor (copy), v4 (copy), DiveApexP (copy), DiveFallTime (copy), SplawikBiomeEffects (copy) ]]
	Satchel.SetEnabled(false)
	Players.LocalPlayer.Character.Humanoid:UnequipTools()

	local Current = ActiveFishRodRig.Current
	local v1 = if Current then Current:QueryDescendants("#RopeAttachment")[1] else nil
	local v2 = ThrowAccuracy.rate(p2)
	local v3 = Players.LocalPlayer:GetAttribute("CustomThrowPowerLimit")

	if typeof(v3) ~= "number" or v3 <= 0 then
		v3 = nil
	end

	local v42 = nil

	for i = 1, 3 do
		local v52 = nil
		local v62 = false

		task.spawn(function() --[[ Line: 708 | Upvalues: Remotes (ref), p2 (copy), v3 (ref), v52 (ref), v62 (ref) ]]
			local v1, v2 = Remotes.ThrowData:Call(p2, v3):Await()

			v52 = if v1 and v2 then v2 else nil
			v62 = true
		end)

		local v7 = os.clock() + 5

		while not v62 and os.clock() < v7 do
			task.wait()
		end

		if v62 then
			v42 = v52

			if i > 1 then
				warn((("[ThrowSystem] ThrowData recovered on attempt %*/%*."):format(i, 3)))
			else
				break
			end

			break
		end

		warn((("[ThrowSystem] ThrowData attempt %*/%* got no reply \226\128\148 retrying..."):format(i, 3)))
	end

	if not v42 then
		require(ReplicatedStorage.shared.util.reportError)("ThrowSystem.ThrowDataTimeout", (("server did not respond after %* attempts (%*s) \226\128\148 cast aborted"):format(3, 15)))
	end

	if v42 and v42.ThrowInfo then
		p1.AutoCastFailStreak = 0

		local ThrowDistance = v42.ThrowInfo.ThrowDistance

		p1.ThrowingFrame.AccuracyText.Visible = true
		p1.ThrowingFrame.AccuracyText.Text = v2.rating
		p1.ThrowingFrame.AccuracyText.UIGradient.Color = v2.gradient
		p1.ThrowingFrame.AccuracyText.Size = UDim2.fromScale(0.157, 0.073)
		SFX.new(v2.sound, 0.5)

		if v2.rating == "PERFECT!" then
			SFX.new("rbxassetid://127613720380706", 0.5)

			local Character = Players.LocalPlayer.Character
			local v8 = Character and Character:FindFirstChild("HumanoidRootPart")

			if v8 then
				VFX.new("Perfect_fx", v8)
			end
		end

		TweenService:Create(p1.ThrowingFrame.AccuracyText, TweenInfo.new(0.2, Enum.EasingStyle.Back), {
			Size = UDim2.fromScale(0.314, 0.146)
		}):Play()

		local Character = Players.LocalPlayer.Character

		Character.HumanoidRootPart.CFrame = CFrame.new(Character.HumanoidRootPart.Position, Character.HumanoidRootPart.Position + Vector3.new(-1, 0, 0))

		local CurrentCamera = workspace.CurrentCamera

		CurrentCamera.CameraType = Enum.CameraType.Scriptable
		CurrentCamera.CFrame = CFrame.lookAt(Character.HumanoidRootPart.CFrame * CFrame.new(7, 4, 7).Position, Character.HumanoidRootPart.Position + Vector3.new(-2.5, 0, -3))

		local Highlight = Instance.new("Highlight")

		Highlight.FillColor = Color3.fromRGB(255, 255, 255)
		Highlight.OutlineColor = Color3.fromRGB(255, 255, 255)
		Highlight.FillTransparency = 0.8
		Highlight.OutlineTransparency = 1
		Highlight.Adornee = Character
		Highlight.Parent = Character

		local v9 = TweenService:Create(Highlight, TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			FillTransparency = 0,
			OutlineTransparency = 0
		})

		v9:Play()
		v9.Completed:Once(function() --[[ Line: 827 | Upvalues: Highlight (copy) ]]
			Highlight:Destroy()
		end)

		local v10, v11 = require(ReplicatedStorage.shared.util.buildHookInstance)(ClientPlayerData.serverProfile:getState().fishRod)
		local v12 = v10
		local v13 = v11

		t.give(v12)

		if v13 then
			t.give(v13)
		end

		v12.Anchored = true

		local v14 = Character.HumanoidRootPart.CFrame * CFrame.new(0, 0, -3)
		local ThrowBar = p1.ThrowingFrame.ThrowBar
		local AccuracyText = p1.ThrowingFrame.AccuracyText
		local v15 = TweenInfo.new(0.3, Enum.EasingStyle.Back, Enum.EasingDirection.In)

		task.wait(0.5)

		local v16 = TweenService:Create(AccuracyText, v15, {
			Size = UDim2.fromScale(0, 0)
		})
		local v17 = TweenService:Create(ThrowBar, v15, {
			Size = UDim2.fromScale(0, 0)
		})

		p1.ThrowingFrame.Title.Visible = false
		v16:Play()
		v17:Play()
		v16.Completed:Once(function() --[[ Line: 857 | Upvalues: AccuracyText (copy) ]]
			AccuracyText.Visible = false
		end)
		v17.Completed:Once(function() --[[ Line: 860 | Upvalues: ThrowBar (copy) ]]
			ThrowBar.Visible = false
		end)
		task.wait(0.3)
		GoldenThrow.stopFX()
		ThrowAnimations.stopIdle()
		SFX.new("rbxassetid://140530009847955", 0.7)
		task.wait((ThrowAnimations.playShot(Character, p2)))

		local v19 = require(ReplicatedStorage.client.throw.ThrowBar).takeReleaseSound()

		if v19 then
			local v20 = ClientPlayerData.serverProfile:getState()

			v19.TimePosition = if if (if v20 then v20.fishRod else v20) == "FISHROD_Cat" then true else false then 0 else 0.4
			v19:Play()
			v19.Ended:Once(function() --[[ Line: 884 | Upvalues: v19 (copy) ]]
				v19:Destroy()
			end)
		end

		ThrowAnimations.playBack(Character)

		if v13 then
			v13:SetPrimaryPartCFrame(v14)
		else
			v12.CFrame = v14
		end

		if v13 then
			v13.Parent = workspace
		else
			v12.Parent = workspace
		end

		local v24 = if v1 and v1.Parent then v1 else ActiveFishRodRig.Current and ActiveFishRodRig.Current:QueryDescendants("#RopeAttachment")[1] or nil

		if v24 then
			v12.RopeConstraint.Attachment1 = v24
		else
			warn("[ThrowSystem] No rod rig available for rope attachment \226\128\148 skipping")
		end

		local StartPointFish = Workspace.Map.StartPointFish
		local LookVector = StartPointFish.CFrame.LookVector
		local RightVector = StartPointFish.CFrame.RightVector
		local Position = v14.Position
		local v27 = StartPointFish.Position + LookVector * ThrowDistance + RightVector * (Position - StartPointFish.Position):Dot(RightVector) + Vector3.new(0, 0, 0)
		local v29 = ClientPlayerData.serverProfile:getState().throwSpeed or require(ReplicatedStorage.shared.config.ThrowPacingConfig).DefaultThrowSpeed
		local v31 = (if if ThrowDistance < 250 then true else false then 70 else v29) * ActiveEffects.GetMultiplier("ThrowSpeed") * getPotionMultiplier(Players.LocalPlayer, "ThrowSpeed") * (1 + require(ReplicatedStorage.shared.util.getFloatEffects)(Players.LocalPlayer).ThrowSpeed) * (1 + require(ReplicatedStorage.shared.util.getRodEnchantBonus)(Players.LocalPlayer, "FastHook") / 100)
		local v32 = Players.LocalPlayer:GetAttribute("DebugThrowSpeedMult")
		local v33 = if typeof(v32) == "number" and v32 > 0 then ThrowDistance / (v31 * v32) else ThrowDistance / v31
		local v34 = math.sqrt(ThrowDistance) * 1.2 + 30

		p1._remoteCastToken = require(ReplicatedStorage.client.remoteFishing.Broadcast).cast(v27, v33)

		local v37 = Vector3.new(v27.X - Position.X, 0, v27.Z - Position.Z)
		local v38 = if v37.Magnitude > 0 then Vector3.new(-v37.Unit.Z, 0, v37.Unit.X) else Vector3.new(1, 0, 0)
		local ZoneFrameComponent = p1.ZoneFrameComponent

		ZoneFrameComponent.UserProgress:Set(0)
		ZoneFrameComponent.ThrowDistance:Set(ThrowDistance)
		ZoneFrameComponent.Visible:Set(true)

		local sum = 0
		local t2 = {}

		for v40, v41 in Worlds.GetLocalBiomes() do
			sum = sum + v41.Length
			t2[v40] = sum
		end

		local v422 = 1
		local v43 = false
		local FieldOfView = CurrentCamera.FieldOfView

		TweenService:Create(CurrentCamera, TweenInfo.new(0.14, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
			FieldOfView = FieldOfView + 22
		}):Play()
		task.delay(0.14, function() --[[ Line: 1005 | Upvalues: v12 (copy), TweenService (ref), CurrentCamera (copy), v33 (ref), FieldOfView (copy) ]]
			if v12.Parent then
				TweenService:Create(CurrentCamera, TweenInfo.new(v33 * 0.7, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut), {
					FieldOfView = FieldOfView
				}):Play()
			end
		end)

		local v44 = CurrentCamera.CFrame
		local v45 = os.clock()
		local v46 = nil

		v46 = RunService.RenderStepped:Connect(function() --[[ Line: 1023 | Upvalues: v45 (copy), CurrentCamera (copy), v46 (ref), v44 (copy) ]]
			debug.profilebegin("UECS/ThrowSystem.FlightShake")

			local v1 = os.clock() - v45

			if not (v1 >= 0.28) and CurrentCamera.CameraType == Enum.CameraType.Scriptable then
				local v2 = 1 - v1 / 0.28
				local v3 = 0.6 * v2

				CurrentCamera.CFrame = v44 * CFrame.new((math.random() - 0.5) * v3, (math.random() - 0.5) * v3, 0) * CFrame.Angles(0, 0, (math.random() - 0.5) * 0.025 * v2)
			else
				v46:Disconnect()

				if CurrentCamera.CameraType == Enum.CameraType.Scriptable then
					CurrentCamera.CFrame = v44
				end
			end

			debug.profileend()
		end)

		local v47 = false
		local v48 = if DiveMinBiome <= (Worlds.GetZoneOrdinal(v42.ThrowInfo.DestinationBiom.id) or 1) then true else false
		local v49 = false
		local v50 = 0
		local v51 = false
		local equippedFloats = ClientPlayerData.serverProfile:getState().equippedFloats
		local t3 = {}

		if equippedFloats then
			for v52, v53 in equippedFloats do
				table.insert(t3, {
					name = v53.name,
					tier = v53.tier
				})
			end
		end

		local t4 = {}
		local model = ReplicatedStorage.shared.model
		local floats = model:FindFirstChild("floats")
		local FishingFloatsConfig = require(ReplicatedStorage.shared.config.FishingFloatsConfig)

		if t3 then
			for v55, v56 in t3 do
				local v54
				local v57 = FishingFloatsConfig.Floats[v56.name]

				v54 = if v57 and (v57.ModelPrefix and floats) then floats:FindFirstChild(v57.ModelPrefix .. "_" .. v56.tier) else nil

				if not v54 then
					v54 = model:FindFirstChild("float")
				end

				if v54 then
					local v59 = v54:Clone()
					local v60 = v59.PrimaryPart or v59:FindFirstChildWhichIsA("BasePart")

					if v60 then
						v59.PrimaryPart = v60

						for v61, v62 in v59:GetDescendants() do
							if v62:IsA("BasePart") and v62 ~= v60 then
								local WeldConstraint = Instance.new("WeldConstraint")

								WeldConstraint.Part0 = v60
								WeldConstraint.Part1 = v62
								WeldConstraint.Parent = v62
								v62.Anchored = false
								v62.CanCollide = false
							end
						end

						v60.Anchored = true
						v60.CanCollide = false
						v59:PivotTo(v12.CFrame)
						v59.Parent = workspace
						table.insert(t4, v59)

						continue
					end

					v59:Destroy()
				end
			end
		end

		local t5 = {}

		if #t4 > 0 then
			local v63 = #t4
			local v64 = math.pi / (v63 + 1)

			for j = 1, v63 do
				t5[j] = -1.5707963267948966 + v64 * j
			end
		end

		if #t4 > 0 then
			local FlightFloatAtt = v12:FindFirstChild("FlightFloatAtt")

			if not FlightFloatAtt then
				FlightFloatAtt = Instance.new("Attachment")
				FlightFloatAtt.Name = "FlightFloatAtt"
				FlightFloatAtt.Parent = v12
			end

			for v65, v66 in t4 do
				local PrimaryPart = v66.PrimaryPart

				if PrimaryPart then
					local Attachment = Instance.new("Attachment")

					Attachment.Parent = PrimaryPart

					local FlightRope = Instance.new("RopeConstraint")

					FlightRope.Name = "FlightRope"
					FlightRope.Attachment0 = FlightFloatAtt
					FlightRope.Attachment1 = Attachment
					FlightRope.Visible = true
					FlightRope.Thickness = 0.07
					FlightRope.Color = BrickColor.new("Brown")
					FlightRope.Length = 9
					FlightRope.Parent = v66
				end
			end
		end

		local v67 = 0

		pcall(RunService.UnbindFromRenderStep, RunService, "ThrowFlightCamSway")

		local identity = CFrame.identity

		RunService:BindToRenderStep("ThrowFlightCamSway", Enum.RenderPriority.Camera.Value + 2, function() --[[ Line: 1177 | Upvalues: CurrentCamera (copy), identity (ref) ]]
			local v1 = os.clock()
			local v2 = math.sin(v1 * 1.6) * 0.35
			local v3 = math.sin(v1 * 2.3 + 1.7) * 0.22
			local v5 = math.rad(math.sin(v1 * 1.1 + 0.5) * 1.2)
			local v6 = CFrame.new(v2, v3, 0) * CFrame.Angles(0, 0, v5)

			CurrentCamera.CFrame = CurrentCamera.CFrame * identity:Inverse() * v6
			identity = v6
		end)

		local function stopFlightSway() --[[ stopFlightSway | Line: 1187 | Upvalues: RunService (ref) ]]
			pcall(RunService.UnbindFromRenderStep, RunService, "ThrowFlightCamSway")
		end

		local v68 = false
		local v69 = nil

		v69 = RunService.Stepped:Connect(function(p12, p2) --[[ Line: 1194 | Upvalues: v12 (copy), v69 (ref), RunService (ref), ZoneFrameComponent (copy), t4 (copy), v67 (ref), v48 (copy), v49 (ref), v68 (ref), v33 (ref), Players (ref), ThrowLaunchSpeedFactor (ref), v4 (ref), v34 (copy), ThrowDistance (copy), DiveApexP (ref), v50 (ref), DiveFallTime (ref), Position (copy), v27 (copy), v38 (copy), v13 (copy), t5 (copy), v422 (ref), t2 (copy), SplawikBiomeEffects (ref), v43 (ref), CurrentCamera (copy), TweenService (ref), v47 (ref), ReplicatedStorage (ref), p1 (copy), FieldOfView (copy), v42 (ref), t3 (copy) ]]
			debug.profilebegin("UECS/ThrowSystem.Trajectory")

			if v12.Parent then
				v67 = v67 + p2

				if v48 and (not v49 and (not v68 and v67 / v33 > 0.2)) then
					local v1 = Players.LocalPlayer:GetAttribute("DebugThrowLagSpike")

					if typeof(v1) == "number" and v1 > 0 then
						v68 = true
						v67 = v67 + v1
					end
				end

				local v3 = math.min(v67 / v33, 1)
				local v44 = ThrowLaunchSpeedFactor * v3 - v4 * v3 * v3 / 2
				local v5, v6

				if v48 then
					local v8 = math.min(v34 * 2.4, 115)
					local v11 = math.max(1 - math.min(v8 * 1.9, ThrowDistance) / ThrowDistance, 0)

					if v44 <= DiveApexP then
						local v122 = v44 / DiveApexP

						v5 = v11 * v122
						v6 = v8 * (2 * v122 - v122 * v122)
					else
						if not v49 then
							v49 = true
							v50 = os.clock()
						end

						local v14 = math.min((os.clock() - v50) / DiveFallTime, 1)

						v5 = v11 + (1 - v11) * v14
						v6 = v8 * (1 - v14 * v14)
					end
				else
					v6 = v34 * 4 * v44 * (1 - v44)
					v5 = v44
				end

				local v15 = Position:Lerp(v27, v5)
				local v16 = if v49 then 0 else math.sin(math.pi * v3)
				local v18 = math.sin(v67 * 4) * 0.6 * v16
				local v22 = Vector3.new(v15.X, v15.Y + v6 + math.sin(v67 * 6 + 1.7) * 0.25 * v16, v15.Z) + v38 * v18
				local v24 = math.sin(v67 * 3 + 0.3) * 0.13962634015954636 * v16
				local v26 = math.sin(v67 * 3 * 0.7) * 0.13962634015954636 * 0.5 * v16
				local v28 = math.sin(v67 * 3 * 1.3 + 1.1) * 0.13962634015954636 * v16
				local v29 = v12
				local v30 = v13
				local v31 = CFrame.new(v22) * CFrame.Angles(v24, v26, v28)

				if v30 then
					v30:SetPrimaryPartCFrame(v31)
				else
					v29.CFrame = v31
				end

				for v32, v332 in t4 do
					local v35 = v12.CFrame * CFrame.Angles(0, t5[v32] + math.pi + 1.5707963267948966, 0)

					v332:PivotTo(CFrame.new(v35.Position + v35.LookVector * 8))
				end

				local v37 = v5 * ThrowDistance

				ZoneFrameComponent.UserProgress:Set(v37)

				while v422 < #t2 and t2[v422] <= v37 do
					v422 = v422 + 1
					SplawikBiomeEffects[v422](v12)

					if not v43 then
						v43 = true
						task.spawn(function() --[[ Line: 1300 | Upvalues: CurrentCamera (ref), TweenService (ref), v12 (ref), v47 (ref), v43 (ref) ]]
							local FieldOfView = CurrentCamera.FieldOfView
							local v1 = TweenService:Create(CurrentCamera, TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
								FieldOfView = FieldOfView + 6
							})

							v1:Play()
							v1.Completed:Wait()

							if v12.Parent and not v47 then
								local v2 = TweenService:Create(CurrentCamera, TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
									FieldOfView = FieldOfView
								})

								v2:Play()
								v2.Completed:Wait()
							end

							v43 = false
						end)
					end
				end

				if not ((if v48 then v49 and DiveFallTime <= os.clock() - v50 else v3 >= 1) and v69) then
					debug.profileend()

					return
				end

				v69:Disconnect()
				require(ReplicatedStorage.client.remoteFishing.Broadcast).stage("landed", nil, p1._remoteCastToken)

				local v40 = v12.Position.Y - v27.Y
				local v41 = v12
				local v423 = v13
				local v432 = CFrame.new(v27)

				if v423 then
					v423:SetPrimaryPartCFrame(v432)
				else
					v41.CFrame = v432
				end

				if v40 > 2 then
					warn("[ThrowSystem] safety snap corrected a mid-air stop: flight ended " .. ("%* studs above the water target"):format((string.format("%.1f", v40))))
				end

				for v442, v45 in t4 do
					v45:Destroy()
				end

				ZoneFrameComponent.UserProgress:Set(ThrowDistance)

				while v422 < #t2 and ThrowDistance >= t2[v422] do
					v422 = v422 + 1
					SplawikBiomeEffects[v422](v12)
				end

				task.spawn(function() --[[ Line: 1365 | Upvalues: TweenService (ref), CurrentCamera (ref), v12 (ref), FieldOfView (ref) ]]
					local v1 = TweenService:Create(CurrentCamera, TweenInfo.new(0.06, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
						FieldOfView = CurrentCamera.FieldOfView + 8
					})

					v1:Play()
					v1.Completed:Wait()

					if v12.Parent then
						TweenService:Create(CurrentCamera, TweenInfo.new(0.18, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
							FieldOfView = FieldOfView
						}):Play()
					end
				end)
				ZoneFrameComponent.Visible:Set(false)
				v47 = true
				pcall(RunService.UnbindFromRenderStep, RunService, "ThrowFlightCamSway")
				debug.profileend()

				local ok, result = xpcall(function() --[[ Line: 1396 | Upvalues: p1 (ref), v12 (ref), v13 (ref), v42 (ref), t3 (ref) ]]
					p1:SplawikLandedAnimation(v12, v13, v42.FishDropName, v42.ThrowInfo.DestinationBiom.id, v42.WillPortal or false, v42.Mutation, v42.SlotDrops, v42.IsBeast == true, if v42.IsBoss == true then true else false, v42.BonusSlotDrops, t3, if v42.IsGolden == true then true else false)
				end, debug.traceback)

				if ok then
					return
				end

				require(ReplicatedStorage.shared.util.reportError)("ThrowSystem.CatchCutscene", result)
				p1:RecoverThrow("the catch cutscene")
			else
				if v69 then
					v69:Disconnect()
				end

				pcall(RunService.UnbindFromRenderStep, RunService, "ThrowFlightCamSway")
				ZoneFrameComponent.Visible:Set(false)

				for v46, v472 in t4 do
					v472:Destroy()
				end

				debug.profileend()
			end
		end)

		if v48 then
			task.spawn(function() --[[ Line: 1427 | Upvalues: v34 (copy), ThrowDistance (copy), v27 (copy), LookVector (copy), v38 (copy), v12 (copy), v47 (ref), v49 (ref), RunService (ref), v51 (ref), CurrentCamera (copy) ]]
				local v2 = math.min(v34 * 2.4, 115)
				local v4 = math.min(v2 * 1.9, ThrowDistance)
				local v5 = v27.Y + v2
				local v6 = v27 - LookVector * (v4 * 0.5) + Vector3.new(0, v2 * 0.5, 0)
				local v7 = math.sqrt(v4 * v4 + v2 * v2)
				local v8 = if v38.Z >= 0 then v38 else -v38

				local function clampCamPos(p1) --[[ clampCamPos | Line: 1446 ]]
					return Vector3.new(p1.X, math.min(p1.Y, 66), (math.clamp(p1.Z, -523.333984375, -231.71475219726562)))
				end

				local function profilePose() --[[ profilePose | Line: 1457 | Upvalues: v5 (copy), v12 (ref), v2 (copy), v7 (copy), v6 (copy), v8 (copy) ]]
					local v4 = v6 + v8 * math.min(v7 * (math.clamp((v5 - v12.Position.Y) / math.max(v2, 1), 0, 1) * -0.07999999999999996 + 0.58), 220)
					local v72 = v4 + Vector3.new(0, math.min(v7 * 0.12, 60), 0)

					return CFrame.lookAt(Vector3.new(v72.X, math.min(v72.Y, 66), (math.clamp(v72.Z, -523.333984375, -231.71475219726562))), (v6:Lerp(v12.Position, 0.8)))
				end

				while v12.Parent and not (v47 or v49) do
					RunService.RenderStepped:Wait()
				end

				if not v12.Parent or v47 then
					return
				end

				v51 = true
				CurrentCamera.CameraType = Enum.CameraType.Scriptable

				local v9 = CurrentCamera.CFrame
				local v10 = os.clock()
				local v11 = false

				while v12.Parent and not v47 do
					local v122
					local v13 = RunService.RenderStepped:Wait()

					if not v12.Parent or v47 then
						break
					end

					local v14 = profilePose()

					if v11 then
						v122 = CurrentCamera.CFrame:Lerp(v14, (math.clamp(v13 * 5, 0, 1)))
					else
						local v18 = math.min((os.clock() - v10) / 0.6, 1)
						local v19 = v18 * v18 * (3 - v18 * 2)
						local v20 = v9:Lerp(v14, v19)

						if v19 >= 1 then
							v122 = v20
							v11 = true
						else
							v122 = v20
						end
					end

					local Position = v122.Position

					CurrentCamera.CFrame = v122 - v122.Position + Vector3.new(Position.X, math.min(Position.Y, 66), (math.clamp(Position.Z, -523.333984375, -231.71475219726562)))
				end
			end)
		end

		task.delay(0.35, function() --[[ Line: 1523 | Upvalues: v12 (copy), v47 (ref), CurrentCamera (copy), v38 (copy), LookVector (copy), v51 (ref), RunService (ref) ]]
			if not v12.Parent or (v47 or CurrentCamera.CameraType ~= Enum.CameraType.Scriptable) then
				return
			end

			local function posAt(p1, p2, p3) --[[ posAt | Line: 1528 | Upvalues: v12 (ref), v38 (ref), LookVector (ref) ]]
				local Position = v12.Position

				return CFrame.lookAt(Position + v38 * p1 + Vector3.new(0, p2, 0) + LookVector * p3, Position)
			end

			local function cinematicLive() --[[ cinematicLive | Line: 1534 | Upvalues: v12 (ref), v47 (ref), v51 (ref), CurrentCamera (ref) ]]
				return if v12.Parent == nil then false else not v47 and (not v51 and CurrentCamera.CameraType == Enum.CameraType.Scriptable)
			end

			local function smooth(p1) --[[ smooth | Line: 1541 ]]
				return p1 * p1 * (3 - p1 * 2)
			end

			local function lerp(p1, p2, p3) --[[ lerp | Line: 1544 ]]
				return p1 + (p2 - p1) * p3
			end

			local v1 = CurrentCamera.CFrame
			local v2 = os.clock()

			while true do
				local v3 = if v12.Parent == nil then false else not v47 and (not v51 and CurrentCamera.CameraType == Enum.CameraType.Scriptable)
				local v4, v5, v6, v7, v8, v9, v10, v11, v122, v13, v14, v15, v16, v17, v18, v19, v20, v21, v22

				if v3 and os.clock() - v2 < 0.25 then
					RunService.RenderStepped:Wait()

					if if v12.Parent == nil then false else not v47 and (not v51 and CurrentCamera.CameraType == Enum.CameraType.Scriptable) then
						local v25 = math.min((os.clock() - v2) / 0.25, 1)
						local Position = v12.Position

						CurrentCamera.CFrame = v1:Lerp(CFrame.lookAt(Position + v38 * 18 + Vector3.new(0, 10, 0) + LookVector * 16, Position), v25 * v25 * (3 - v25 * 2))
					else
						v4 = os.clock()

						while true do
							v5 = if v12.Parent == nil then false else not v47 and (not v51 and CurrentCamera.CameraType == Enum.CameraType.Scriptable)

							if v5 and os.clock() - v4 < 0.6 then
								RunService.RenderStepped:Wait()
								v6 = if v12.Parent == nil then false else not v47 and (not v51 and CurrentCamera.CameraType == Enum.CameraType.Scriptable)

								if v6 then
									v7 = (os.clock() - v4) / 0.6
									v8 = math.min(v7, 1)
									v9 = v8 * v8 * (3 - v8 * 2)
									v10 = CurrentCamera
									v11 = v12.Position
									v122 = v11 + v38 * (v9 * -7 + 18) + Vector3.new(0, v9 * -4 + 10, 0) + LookVector * (v9 * -19 + 16)
									CurrentCamera.CFrame = CFrame.lookAt(v122, v11)
								else
									v13 = os.clock()

									while true do
										v14 = if v12.Parent == nil then false else not v47 and (not v51 and CurrentCamera.CameraType == Enum.CameraType.Scriptable)

										if v14 and os.clock() - v13 < 0.45 then
											RunService.RenderStepped:Wait()
											v15 = if v12.Parent == nil then false else not v47 and (not v51 and CurrentCamera.CameraType == Enum.CameraType.Scriptable)

											if v15 then
												v16 = (os.clock() - v13) / 0.45
												v17 = math.min(v16, 1)
												v18 = v17 * v17 * (3 - v17 * 2)
												v19 = CurrentCamera
												v20 = v12.Position
												v21 = v20 + v38 * (v18 * -5 + 11) + Vector3.new(0, v18 * -1 + 6, 0) + LookVector * (v18 * -17 + -3)
												CurrentCamera.CFrame = CFrame.lookAt(v21, v20)
											else
												v22 = if v12.Parent == nil then false else not v47 and (not v51 and CurrentCamera.CameraType == Enum.CameraType.Scriptable)

												if not v22 then
													return
												end

												CurrentCamera.CameraSubject = v12
												CurrentCamera.CameraType = Enum.CameraType.Custom

												return
											end
										else
											v22 = if v12.Parent == nil then false else not v47 and (not v51 and CurrentCamera.CameraType == Enum.CameraType.Scriptable)

											if not v22 then
												return
											end

											CurrentCamera.CameraSubject = v12
											CurrentCamera.CameraType = Enum.CameraType.Custom

											return
										end
									end
								end
							else
								v13 = os.clock()

								while true do
									v14 = if v12.Parent == nil then false else not v47 and (not v51 and CurrentCamera.CameraType == Enum.CameraType.Scriptable)

									if v14 and os.clock() - v13 < 0.45 then
										RunService.RenderStepped:Wait()
										v15 = if v12.Parent == nil then false else not v47 and (not v51 and CurrentCamera.CameraType == Enum.CameraType.Scriptable)

										if v15 then
											v16 = (os.clock() - v13) / 0.45
											v17 = math.min(v16, 1)
											v18 = v17 * v17 * (3 - v17 * 2)
											v19 = CurrentCamera
											v20 = v12.Position
											v21 = v20 + v38 * (v18 * -5 + 11) + Vector3.new(0, v18 * -1 + 6, 0) + LookVector * (v18 * -17 + -3)
											CurrentCamera.CFrame = CFrame.lookAt(v21, v20)
										else
											v22 = if v12.Parent == nil then false else not v47 and (not v51 and CurrentCamera.CameraType == Enum.CameraType.Scriptable)

											if not v22 then
												return
											end

											CurrentCamera.CameraSubject = v12
											CurrentCamera.CameraType = Enum.CameraType.Custom

											return
										end
									else
										v22 = if v12.Parent == nil then false else not v47 and (not v51 and CurrentCamera.CameraType == Enum.CameraType.Scriptable)

										if not v22 then
											return
										end

										CurrentCamera.CameraSubject = v12
										CurrentCamera.CameraType = Enum.CameraType.Custom

										return
									end
								end
							end
						end
					end
				else
					v4 = os.clock()

					while true do
						v5 = if v12.Parent == nil then false else not v47 and (not v51 and CurrentCamera.CameraType == Enum.CameraType.Scriptable)

						if v5 and os.clock() - v4 < 0.6 then
							RunService.RenderStepped:Wait()
							v6 = if v12.Parent == nil then false else not v47 and (not v51 and CurrentCamera.CameraType == Enum.CameraType.Scriptable)

							if v6 then
								v7 = (os.clock() - v4) / 0.6
								v8 = math.min(v7, 1)
								v9 = v8 * v8 * (3 - v8 * 2)
								v10 = CurrentCamera
								v11 = v12.Position
								v122 = v11 + v38 * (v9 * -7 + 18) + Vector3.new(0, v9 * -4 + 10, 0) + LookVector * (v9 * -19 + 16)
								CurrentCamera.CFrame = CFrame.lookAt(v122, v11)
							else
								v13 = os.clock()

								while true do
									v14 = if v12.Parent == nil then false else not v47 and (not v51 and CurrentCamera.CameraType == Enum.CameraType.Scriptable)

									if v14 and os.clock() - v13 < 0.45 then
										RunService.RenderStepped:Wait()
										v15 = if v12.Parent == nil then false else not v47 and (not v51 and CurrentCamera.CameraType == Enum.CameraType.Scriptable)

										if v15 then
											v16 = (os.clock() - v13) / 0.45
											v17 = math.min(v16, 1)
											v18 = v17 * v17 * (3 - v17 * 2)
											v19 = CurrentCamera
											v20 = v12.Position
											v21 = v20 + v38 * (v18 * -5 + 11) + Vector3.new(0, v18 * -1 + 6, 0) + LookVector * (v18 * -17 + -3)
											CurrentCamera.CFrame = CFrame.lookAt(v21, v20)
										else
											v22 = if v12.Parent == nil then false else not v47 and (not v51 and CurrentCamera.CameraType == Enum.CameraType.Scriptable)

											if not v22 then
												return
											end

											CurrentCamera.CameraSubject = v12
											CurrentCamera.CameraType = Enum.CameraType.Custom

											return
										end
									else
										v22 = if v12.Parent == nil then false else not v47 and (not v51 and CurrentCamera.CameraType == Enum.CameraType.Scriptable)

										if not v22 then
											return
										end

										CurrentCamera.CameraSubject = v12
										CurrentCamera.CameraType = Enum.CameraType.Custom

										return
									end
								end
							end
						else
							v13 = os.clock()

							while true do
								v14 = if v12.Parent == nil then false else not v47 and (not v51 and CurrentCamera.CameraType == Enum.CameraType.Scriptable)

								if v14 and os.clock() - v13 < 0.45 then
									RunService.RenderStepped:Wait()
									v15 = if v12.Parent == nil then false else not v47 and (not v51 and CurrentCamera.CameraType == Enum.CameraType.Scriptable)

									if v15 then
										v16 = (os.clock() - v13) / 0.45
										v17 = math.min(v16, 1)
										v18 = v17 * v17 * (3 - v17 * 2)
										v19 = CurrentCamera
										v20 = v12.Position
										v21 = v20 + v38 * (v18 * -5 + 11) + Vector3.new(0, v18 * -1 + 6, 0) + LookVector * (v18 * -17 + -3)
										CurrentCamera.CFrame = CFrame.lookAt(v21, v20)
									else
										v22 = if v12.Parent == nil then false else not v47 and (not v51 and CurrentCamera.CameraType == Enum.CameraType.Scriptable)

										if not v22 then
											return
										end

										CurrentCamera.CameraSubject = v12
										CurrentCamera.CameraType = Enum.CameraType.Custom

										return
									end
								else
									v22 = if v12.Parent == nil then false else not v47 and (not v51 and CurrentCamera.CameraType == Enum.CameraType.Scriptable)

									if not v22 then
										return
									end

									CurrentCamera.CameraSubject = v12
									CurrentCamera.CameraType = Enum.CameraType.Custom

									return
								end
							end
						end
					end
				end
			end
		end)
	else
		warn("[ThrowSystem] ThrowData returned nil or invalid data. Aborting throw.")
		notifications:Send("The cast didn\'t go through \226\128\148 please try again!")
		t.flush()
		v5 = false
		Remotes.SetFishState:Fire(v5)

		if p1.ThrowBarHint then
			p1.ThrowBarHint:Hide()
		end

		local Character = Players.LocalPlayer.Character

		if Character and Character:FindFirstChild("HumanoidRootPart") then
			Character.HumanoidRootPart.Anchored = false
		end

		workspace.CurrentCamera.CameraType = Enum.CameraType.Custom
		p1.ThrowingFrame.Visible = false

		if v6 then
			p1.AutoCastFailStreak = (p1.AutoCastFailStreak or 0) + 1

			if p1.AutoCastFailStreak >= 3 then
				notifications:Send("Auto fishing stopped after repeated failed casts.")
				p1:StopAutoFishing()
			end
		end
	end
end
function v3.SplawikLandedAnimation(p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13) --[[ SplawikLandedAnimation | Line: 1610 | Upvalues: ReplicatedStorage (copy), ThrowFX (copy), LuckyblockConfig (copy), FishConfig (copy), v2 (copy), SkyDropFx (copy), SFX (copy), ClientPlayerData (copy), ShowupEffects (copy), RollSystem (copy), Worlds (copy), MutationList (copy), RarityLabel (copy), FishEarnings (copy), Players (copy), ThrowSystemBossSequence (copy), ThrowAnimations (copy), Workspace (copy), ClientMusicController (copy), Satchel (copy), GoldenThrow (copy), t (copy), v5 (ref), Remotes (copy), VFX (copy), RunService (copy) ]]
	require(ReplicatedStorage.client.RemoteFishingState).SetCutsceneSuppressed(true)

	local ThrowPacingConfig = require(ReplicatedStorage.shared.config.ThrowPacingConfig)
	local RevealGrowTime = ThrowPacingConfig.RevealGrowTime
	local RevealHoldTime = ThrowPacingConfig.RevealHoldTime
	local RevealFlyTime = ThrowPacingConfig.RevealFlyTime

	ThrowFX.dismissAllMutationEffects()

	local v1 = ThrowFX.hideGameUI()

	workspace.CurrentCamera.CameraType = Enum.CameraType.Scriptable
	workspace.CurrentCamera.CFrame = CFrame.lookAt((p2.CFrame * CFrame.new(15, 7, 0)).Position, p2.Position)

	local v3 = workspace.CurrentCamera.CFrame
	local v4 = if LuckyblockConfig[p4] == nil then FishConfig[p4] and FishConfig[p4].Rarity.id or "" else "Beast"
	local Routing = v2.Routing
	local _ = Routing.Special[v4] == true
	local _2 = Routing.SkyDrop[v4] == true
	local v52 = v4
	local v6 = SkyDropFx[v4] or SkyDropFx.Secret
	local _ = v6 and v6.darkHold
	local v7 = v4
	local _ = v6 and v6.introHold
	local _ = v6 and v6.diveTime
	local _ = v6 and v6.splashHold
	local _3 = Routing.DarkIntro[v7] == true

	if if Routing.BeamThenVeil[v7] == true then true else false then
		local Position = p2.Position
		local v9 = Position + ((CFrame.new(Position) * CFrame.Angles(0, -0.3490658503988659, 0) * CFrame.new(-Position) * v3 * CFrame.new(0, 0, 6)).Position - Position) * 4

		CFrame.lookAt(Vector3.new(v9.X, Position.Y + 1, v9.Z), Position)
	end

	ThrowFX.landingSplash(p2.CFrame)
	SFX.new("rbxassetid://83673781452193", 1)

	local v12 = if p12 then p12 else {}
	local v13, v14 = ThrowFX.spawnFloat(p2.CFrame, p2, #v12 + 1, v12)

	ThrowFX.startFloatCamera(p2.CFrame)

	local HookSwimmers = require(ReplicatedStorage.client.roll.HookSwimmers)
	local v15

	if ClientPlayerData.isPlayerDataLoaded then
		local v16 = ClientPlayerData.serverProfile:getState()

		v15 = if v16 == nil or v16.index == nil then false elseif v16.index[p4] == true then false else true
	else
		v15 = false
	end

	HookSwimmers.spawn(p2, p5)

	local RollWaterFX = require(ReplicatedStorage.client.roll.RollWaterFX)

	RollWaterFX.attach(p2)
	require(ReplicatedStorage.client.roll.RollDebug).mark()

	local t2 = {
		fishConfigName = p4,
		biomeId = p5
	}

	t2.isBeast = if p9 == true then true else false
	t2.isBoss = if p10 == true then true else false

	local v20 = ShowupEffects.decide(t2)
	local v21, v222

	if p11 and not p10 then
		local v23 = ShowupEffects.rank(v20)
		local v24 = if v20 then ShowupEffects.weight(p4, p5) else 0

		for v25, v26 in p11 do
			local t3 = {}
			local v27 = nil
			local v28 = false

			for v29, v30 in v26 do
				if v30.kind == "fish" or v30.kind == "beast" then
					v27 = v30.fish
					v28 = if v30.kind == "beast" then true else false

					continue
				end

				if v30.kind == "mutation" and v30.mutation then
					table.insert(t3, v30.mutation)
				end
			end

			local v31 = if v27 then ShowupEffects.decide({
	isBoss = false,
	fishConfigName = v27,
	biomeId = p5,
	isBeast = v28
}) else nil

			if v27 and v31 then
				local v32 = ShowupEffects.rank(v31)
				local v33 = ShowupEffects.weight(v27, p5)

				if v23 < v32 or v32 == v23 and v24 < v33 then
					if #t3 > 0 then
						v20, v21, v222, v23, v24 = v31, v27, table.concat(t3, ","), v32, v33

						continue
					end

					v20 = v31
					v21 = v27
					v222 = nil
					v23 = v32
					v24 = v33
				end
			end
		end
	end

	if p1._debugForceShowupOnce then
		p1._debugForceShowupOnce = nil

		if not (v20 or p10) then
			warn("[ThrowSystem] DEBUG M cast \226\128\148 showup forced (Legendary)")
			v20 = "Legendary"
		end

		if not p10 then
			local MutationList2 = require(ReplicatedStorage.shared.util.MutationList)
			local t3 = {}

			for v35 in require(ReplicatedStorage.shared.config.MutationConfig).Mutations do
				table.insert(t3, v35)
			end

			local v36 = MutationList2.format(t3)

			if p8 and #p8 > 0 then
				local v37

				v37 = {}
				p7 = v36

				for i = 1, #p8 - 1 do
					if p8[i].kind ~= "mutation" then
						table.insert(v37, p8[i])
					end
				end

				for v39, v40 in MutationList2.parse(p7) do
					table.insert(v37, {
						kind = "mutation",
						mutation = v40
					})
				end

				table.insert(v37, p8[#p8])
				p8 = v37
			else
				p7 = v36
			end

			warn((("[ThrowSystem] DEBUG M cast \226\128\148 display mutations: %*"):format(p7)))
		end
	end

	if RollSystem.PlayForCatch then
		local t3 = {
			biome = Worlds.GetBiomeById(p5),
			fish = p4,
			rarity = v52,
			mutation = p7,
			slots = p8
		}

		t3.isBeast = if p9 == true then true else false
		t3.isBoss = if p10 == true then true else false
		t3.suspense = if v20 == nil then p10 else true
		t3.bonusSlots = p11
		t3.isGolden = if p13 == true then true else false
		t3.firstDiscovery = v15
		RollSystem:PlayForCatch(t3)
	end

	if v20 == nil and not p10 then
		HookSwimmers.finish(p4)
	else
		HookSwimmers.despawn()
	end

	RollWaterFX.detach()

	if p10 then
		v13()
	end

	ThrowFX.stopFloatCamera()

	local function buildFishModel(p1, p2) --[[ buildFishModel | Line: 1894 | Upvalues: LuckyblockConfig (ref), ReplicatedStorage (ref), MutationList (ref), RarityLabel (ref), FishConfig (ref), FishEarnings (ref), Players (ref) ]]
		local v1 = if LuckyblockConfig[p1] == nil then false else true
		local v2

		if v1 then
			local Luckyblocks = ReplicatedStorage.shared.model.Luckyblocks
			local v4 = (Luckyblocks:FindFirstChild(p1) or Luckyblocks:GetChildren()[1]):Clone()

			if v4:IsA("Model") then
				v2 = v4
			else
				local Model = Instance.new("Model")

				Model.Name = p1
				v4.Parent = Model
				Model.PrimaryPart = v4
				v2 = Model
			end

			v2:SetAttribute("IsLuckyblock", true)
		else
			v2 = ReplicatedStorage.shared.model.FishModels[p1]:Clone()
		end

		MutationList.applyEffects(v2, MutationList.parse(p2))
		v2.PrimaryPart.Anchored = true

		local v6 = RarityLabel.Add(v2)

		if v1 then
			v6.DisplayName:Set(p1:gsub("_", " "))
			v6.Rarity:Set("Beast")
			v6.Mutations:Set(p2 or "")
			v6.Earnings:Set(0)

			return v2
		end

		local v7 = FishConfig[v2.Name]

		v6.DisplayName:Set(v7.DisplayName)
		v6.Rarity:Set(v7.Rarity.id)
		v6.Mutations:Set(p2 or "")
		v6.Earnings:Set(FishEarnings.perFish(Players.LocalPlayer, v2.Name, false, 1, p2))

		if v7.LabelEffect then
			v2:SetAttribute("LabelEffect", v7.LabelEffect)
		end

		return v2
	end

	if p10 then
		require(ReplicatedStorage.client.remoteFishing.Broadcast).stage("bossFight", nil, p1._remoteCastToken)

		local v47 = ThrowSystemBossSequence:InitBossSequence(p4, p2, p3)
		local stage = require(ReplicatedStorage.client.remoteFishing.Broadcast).stage
		local t3 = {}

		t3.Ok = if v47 == true then true else false
		stage("done", t3, p1._remoteCastToken)
		ThrowAnimations.stopBack()
		p1.ThrowingFrame.SpeedMeter.Visible = false
		Players.LocalPlayer.Character.HumanoidRootPart.Anchored = false
		Workspace.CurrentCamera.CameraType = Enum.CameraType.Custom
		Workspace.CurrentCamera.CameraSubject = Players.LocalPlayer.Character and Players.LocalPlayer.Character:FindFirstChildOfClass("Humanoid")
		v1()
		p1.LastFishMutation = p7
		v13()
		p2.Transparency = 0
		ClientMusicController.SetMuted(false)

		if v47 then
			if v47 then
				SFX.new("rbxassetid://114813573682393", 1)
				ThrowAnimations.playSuccess()
				task.wait(0.5)
				p1:_CollectCaughtFish()

				local __bossFish = Instance.new("Folder")

				__bossFish.Name = "__bossFish"
				__bossFish.Parent = workspace.CurrentCamera

				local t4 = {}

				if p11 then
					for v51, v522 in p11 do
						local t5 = {}
						local v53 = nil

						for v54, v55 in v522 do
							if v55.kind == "fish" or v55.kind == "beast" then
								v53 = v55.fish

								continue
							end

							if v55.kind == "mutation" and v55.mutation then
								table.insert(t5, v55.mutation)
							end
						end

						local v56 = if v53 == nil then false elseif LuckyblockConfig[v53] == nil then false else true

						if v53 and (v56 or FishConfig[v53] and ReplicatedStorage.shared.model.FishModels:FindFirstChild(v53)) then
							local v58 = buildFishModel(v53, if #t5 > 0 then table.concat(t5, ",") else nil)

							v58.Parent = __bossFish
							table.insert(t4, v58)
						end
					end
				end

				local v59 = buildFishModel(p4, p7)

				v59.Parent = __bossFish
				p1:CollectFishAnimation(v59, p2, p3, p5, t4)
			end
		else
			local t4 = { p4 }

			if p11 then
				for v60, v61 in p11 do
					local v62 = nil

					for v63, v64 in v61 do
						if v64.kind == "fish" or v64.kind == "beast" then
							v62 = v64.fish
						end
					end

					local v65 = if v62 == nil then false elseif LuckyblockConfig[v62] == nil then false else true

					if v62 and (v65 or FishConfig[v62] and ReplicatedStorage.shared.model.FishModels:FindFirstChild(v62)) then
						table.insert(t4, v62)
					end
				end
			end

			SFX.new("rbxassetid://138366598268192", 0.7)
			SFX.new("rbxassetid://8275897472", 0.7)
			task.wait(0.5)

			local v66 = p1:ShowFishEatenScreen(t4)

			p2:Destroy()

			if p3 then
				p3:Destroy()
			end

			if v66 then
				p1:_CollectCaughtFish()
			end

			p1.Blackout.BackgroundTransparency = 1
		end

		Satchel.SetEnabled(true)
		GoldenThrow.stopFX()
		t.flush()
		v5 = false
		Remotes.SetFishState:Fire(v5)
	else
		local v67 = if LuckyblockConfig[p4] == nil then false else true

		ThrowFX.onFloatSlotHit(if v67 then Color3.fromRGB(255, 60, 0) else FishConfig[p4] and FishConfig[p4].Rarity.rarityColor or Color3.new(255/255, 255/255, 255/255))

		local CurrentCamera = workspace.CurrentCamera
		local v69 = buildFishModel(p4, p7)
		local t3 = {}

		table.insert(t3, {
			model = v69,
			ogScale = v69:GetScale(),
			fishName = p4,
			mutation = p7
		})

		if p11 then
			for v70, v71 in p11 do
				local t5 = {}
				local v72 = nil

				for v73, v74 in v71 do
					if v74.kind == "fish" or v74.kind == "beast" then
						v72 = v74.fish

						continue
					end

					if v74.kind == "mutation" and v74.mutation then
						table.insert(t5, v74.mutation)
					end
				end

				local v75 = if v72 == nil then false elseif LuckyblockConfig[v72] == nil then false else true

				if v72 and (v75 or FishConfig[v72] and ReplicatedStorage.shared.model.FishModels:FindFirstChild(v72)) then
					local v76 = if #t5 > 0 then table.concat(t5, ",") else nil
					local v77 = buildFishModel(v72, v76)

					table.insert(t3, {
						model = v77,
						ogScale = v77:GetScale(),
						fishName = v72,
						mutation = v76
					})
				end
			end
		end

		if v20 and ShowupEffects.has(v20) then
			local v78 = v69

			for v79, v80 in t3 do
				if v80.fishName == v21 and v80.mutation == v222 then
					v78 = v80.model

					break
				end
			end

			for v81, v82 in t3 do
				if v82.model ~= v78 then
					v82.model.Parent = ReplicatedStorage
				end
			end

			ThrowFX.hideFloat()
			ThrowFX.dismissAllMutationEffects()
			require(ReplicatedStorage.client.remoteFishing.Broadcast).stage("showup", nil, p1._remoteCastToken)
			ShowupEffects.play(v20, v78, {
				hook = p2,
				biome = p5,
				fishConfigName = v21,
				rarityId = v20,
				mutation = v222,
				hookFraming = v3,
				beamFraming = v3
			})
		else
			local v84 = math.tan(math.rad(CurrentCamera.FieldOfView) / 2)
			local v85 = 0
			local v86 = 0
			local v87 = 0
			local v88 = #t3

			for v89, v90 in t3 do
				local _4, v91 = v90.model:GetBoundingBox()
				local v92 = math.max(v91.X, v91.Y, v91.Z)
				local v93 = math.max(v91.X, v91.Z)
				local Y2 = v91.Y

				if v85 < v92 then
					v85 = v92
				end

				if v86 < v93 then
					v86 = v93
				end

				if v87 < Y2 then
					v87 = Y2
				end
			end

			local v94 = v85 * 0.7
			local v95 = v86 + v94 * math.max(0, v88 - 1)
			local ViewportSize = CurrentCamera.ViewportSize
			local v97 = v84 * (if ViewportSize.X > 0 and ViewportSize.Y > 0 then ViewportSize.X / ViewportSize.Y else 1.7777777777777777)
			local v99 = math.max(v95 / (1.8 * v97), (math.max(v87 / (v84 * 1.2), v86 / (1.2 * v97))))
			local Position = CurrentCamera.CFrame.Position
			local RightVector = CurrentCamera.CFrame.RightVector

			t5 = {}
			v100 = v99

			for v101, v102 in t3 do
				local Position2 = (CurrentCamera.CFrame * CFrame.new((v101 - 1 - (v88 - 1) / 2) * v94, 0.1 * v100 * v84, -v100)).Position
				local v103 = Vector3.new(Position.X, Position2.Y, Position.Z)

				table.insert(t5, {
					lensPos = Position2,
					horizLook = v103,
					lensSpun = function(p1) --[[ lensSpun | Line: 2228 | Upvalues: Position2 (copy), v103 (copy) ]]
						return CFrame.lookAt(Position2, v103) * CFrame.Angles(0, p1, 0)
					end
				})
				v102.model:ScaleTo(v102.ogScale * 0.12)
				v102.model:PivotTo(t5[v101].lensSpun(0))
				v102.model.Parent = workspace
			end

			local _4, v104 = v69:GetBoundingBox()
			local v105 = CFrame.lookAt((p2.CFrame * CFrame.new(-v104.Z / 2, 0, 0)).Position, p2.Position)

			SFX.new("rbxassetid://117945572498547", 0.5)
			task.spawn(function() --[[ Line: 2245 | Upvalues: ThrowFX (ref) ]]
				ThrowFX.cameraImpactShake(0.3, 0.8)
			end)

			for v106, v107 in t3 do
				if v107.model.PrimaryPart then
					VFX.new("RollVFX", v107.model.PrimaryPart, RevealGrowTime + RevealHoldTime + RevealFlyTime)
				end
			end

			local v108 = os.clock()
			local sum = 0

			repeat
				local v109 = RunService.RenderStepped:Wait()
				local v111 = math.min((os.clock() - v108) / RevealGrowTime, 1)
				local v112 = (v111 - 1) ^ 3 * 2.70158 + 1 + (v111 - 1) ^ 2 * 1.70158

				sum = sum + ((1 - (1 - v111) * (1 - v111)) * -6 + 7) * v109

				for v113, v114 in t3 do
					v114.model:ScaleTo(v114.ogScale * (v112 * 0.88 + 0.12))
					v114.model:PivotTo(t5[v113].lensSpun(sum))
				end
			until v111 >= 1

			for v115, v116 in t3 do
				v116.model:ScaleTo(v116.ogScale)
			end

			local v117 = os.clock()
			local v118 = p7 and (if string.find(p7, "Bloody") == nil then false else true)
			local v119 = p7 and (if string.find(p7, "Diamond") == nil then false else true)
			local v120 = if p7 then if string.find(p7, "Molten") == nil then false else true else p7
			local v121 = if p7 then if string.find(p7, "Gold") == nil then false else true else p7
			local sum2 = if v118 then RevealHoldTime + 1.2 else RevealHoldTime

			if v119 then
				sum2 = sum2 + 0.8
			end

			if v120 then
				sum2 = sum2 + 0.6
			end

			if v121 then
				sum2 = sum2 + 0.5
			end

			while os.clock() - v117 < sum2 do
				sum = sum + 1 * RunService.RenderStepped:Wait()

				for v122, v123 in t3 do
					v123.model:PivotTo(t5[v122].lensSpun(sum))
				end
			end

			for j = 2, #t3 do
				local v124 = t3[j]
				local v125 = t5[j]
				local v126 = v14 and v14[j] or nil

				task.spawn(function() --[[ Line: 2310 | Upvalues: v124 (copy), RunService (ref), RevealFlyTime (copy), sum (ref), v126 (copy), v125 (copy) ]]
					local t = {}

					for v1, v2 in v124.model:GetDescendants() do
						if v2:IsA("BasePart") then
							t[v2] = v2.Transparency
						end
					end

					local v3 = os.clock()

					repeat
						local v4 = RunService.RenderStepped:Wait()
						local v6 = math.min((os.clock() - v3) / RevealFlyTime, 1)
						local v7 = v6 * v6 * (3 - v6 * 2)

						sum = sum + (1 - v6) * 1 * v4

						if v126 then
							v124.model:PivotTo(v125.lensSpun(sum):Lerp(v126, v7))
						else
							v124.model:ScaleTo((math.max(v124.ogScale * (1 - v7), 0.01)))
							v124.model:PivotTo(v125.lensSpun(sum))
						end

						v124.model:ScaleTo((math.max(v124.ogScale * (1 - v7 * 0.7), 0.01)))

						for v10, v11 in t do
							v10.Transparency = v11 + (1 - v11) * v7
						end
					until v6 >= 1

					v124.model:ScaleTo(v124.ogScale)

					for v12, v13 in t do
						v12.Transparency = v13
					end
				end)
			end

			local v127 = os.clock()

			repeat
				local v128 = RunService.RenderStepped:Wait()
				local v130 = math.min((os.clock() - v127) / RevealFlyTime, 1)

				sum = sum + (1 - v130) * 1 * v128
				v69:PivotTo(t5[1].lensSpun(sum):Lerp(v105, v130 * v130 * (3 - v130 * 2)))
			until v130 >= 1

			v69:PivotTo(v105)
			ThrowFX.landingSplash(p2.CFrame)
		end

		v1()
		p1.LastFishMutation = p7
		v13()
		p2.Transparency = 0

		local t5 = {}

		for k = 1, #t3 do
			local model = t3[k].model

			if model and model.Parent then
				model.Parent = workspace

				if k > 1 then
					table.insert(t5, model)
				end
			end
		end

		p1:StartChase(p2, p3, v69, p5, p6, t5)
	end
end
function v3._CollectCaughtFish(p1) --[[ _CollectCaughtFish | Line: 2410 | Upvalues: Remotes (copy), ReplicatedStorage (copy), GoldenThrow (copy) ]]
	local v1 = p1._collectCastGeneration or 0
	local v2 = false

	p1._lastDuplicatedFish = nil
	task.spawn(function() --[[ Line: 2417 | Upvalues: p1 (copy), v1 (copy), v2 (ref), Remotes (ref), ReplicatedStorage (ref), GoldenThrow (ref) ]]
		local v12 = false
		local v22 = nil

		for i = 1, 3 do
			if (p1._collectCastGeneration or 0) ~= v1 then
				warn("[ThrowSystem] GetFishToRecive retries cancelled \226\128\148 a new cast started.")
				v2 = true

				return
			end

			local v3 = nil
			local v4 = false

			task.spawn(function() --[[ Line: 2430 | Upvalues: Remotes (ref), v3 (ref), v4 (ref) ]]
				local v1, v2 = Remotes.GetFishToRecive:Call():Await()

				v3 = if v1 and v2 then v2 else nil
				v4 = true
			end)

			local v5 = os.clock() + 5

			while not v4 and os.clock() < v5 do
				task.wait()
			end

			if v4 then
				v22 = v3
				v12 = true

				if i > 1 then
					warn((("[ThrowSystem] GetFishToRecive recovered on attempt %*/%*."):format(i, 3)))
				else
					break
				end

				break
			end

			warn((("[ThrowSystem] GetFishToRecive attempt %*/%* got no reply \226\128\148 retrying..."):format(i, 3)))
		end

		v2 = true

		if not v12 then
			require(ReplicatedStorage.shared.util.reportError)("ThrowSystem.GetFishToReciveTimeout", (("server did not respond after %* attempts (%*s) \226\128\148 continuing without golden-progress update"):format(3, 15)))
		end

		if typeof(v22) == "table" and typeof(v22.GoldenProgress) == "number" then
			GoldenThrow.applyProgress(v22.GoldenProgress)
		end

		if typeof(v22) ~= "table" then
			return
		end

		if typeof(v22.DuplicatedFish) ~= "table" then
			return
		end

		local t = {}

		for v6, v7 in v22.DuplicatedFish do
			if typeof(v7) == "string" then
				t[v7] = true
			end
		end

		if not next(t) then
			return
		end

		p1._lastDuplicatedFish = t
	end)

	local v3 = os.clock() + 2

	while not v2 and os.clock() < v3 do
		task.wait()
	end
end
function v3.StartChase(p1, p2, p3, p4, p5, p6, p7) --[[ StartChase | Line: 2489 | Upvalues: Worlds (copy), ReplicatedStorage (copy), t (copy), Workspace (copy), Players (copy), SFX (copy), TweenService (copy), RunService (copy), ThrowAnimations (copy), Satchel (copy), GoldenThrow (copy), v5 (ref), Remotes (copy) ]]
	local CurrentCamera = workspace.CurrentCamera
	local v1 = Worlds.GetBiomeById(p5)
	local v2 = if v1 then ReplicatedStorage.shared.model.WallModels:FindFirstChild(v1.WallModel) else v1

	if not v2 then
		warn((("[ThrowSystem] WallModel \"%*\" missing for biome %*, falling back to Megalodon"):format(if v1 then v1.WallModel else v1, p5)))
		v2 = ReplicatedStorage.shared.model.WallModels.Megalodon
	end

	local v6 = v2:Clone()
	local v7 = if v1 then v1.WallLabel else v1

	if v7 then
		for v8, v9 in v6:GetDescendants() do
			if v9:IsA("BillboardGui") then
				v9:RemoveTag("DualityBillboard")
				v9:RemoveTag("GlitchBillboard")
				v9:SetAttribute("DualityWordA", nil)
				v9:SetAttribute("DualityWordB", nil)

				continue
			end

			if v9:IsA("TextLabel") and v9:FindFirstAncestorOfClass("BillboardGui") then
				v9.RichText = false
				v9.Text = v7
			end
		end
	end

	v6.Parent = workspace
	t.give(v6)

	local v10 = if v1 then v1.WallAnimation else v1

	if v10 then
		for v11, v12 in v6:GetDescendants() do
			if v12:IsA("BasePart") then
				v12.Anchored = v12 == v6.PrimaryPart
				v12.CanCollide = false
			end
		end

		local v13 = v6:FindFirstChildOfClass("AnimationController") or v6:FindFirstChildOfClass("Humanoid")

		if not v13 then
			local AnimationController = Instance.new("AnimationController")

			AnimationController.Parent = v6
			v13 = AnimationController
		end

		local Animator = v13:FindFirstChildOfClass("Animator")

		if not Animator then
			Animator = Instance.new("Animator")
			Animator.Parent = v13
		end

		local Animation = Instance.new("Animation")

		Animation.AnimationId = v10
		Animation.Parent = v6

		local ok, result = pcall(function() --[[ Line: 2564 | Upvalues: Animator (ref), Animation (copy) ]]
			return Animator:LoadAnimation(Animation)
		end)

		if ok and result then
			result.Looped = true
			result:Play()
		else
			warn((("[ThrowSystem] wall animation \"%*\" failed to load: %*"):format(v10, result)))
		end
	end

	local v14 = Worlds.GetWaterZoneName(p5) or tostring(p5)
	local v15 = Workspace.Map.Water:FindFirstChild(v14)
	local v16 = v15 and v15:FindFirstChild("WallSpawnPosition")

	if not v16 then
		pcall(function() --[[ Line: 2584 | Upvalues: Players (ref), p2 (copy) ]]
			Players.LocalPlayer:RequestStreamAroundAsync(p2.Position, 5)
		end)

		local v17 = Workspace.Map.Water:WaitForChild(v14, 10)

		v16 = v17 and v17:WaitForChild("WallSpawnPosition", 5)
	end

	if not v16 then
		error((("Water zone %*/WallSpawnPosition not replicated \226\128\148 cannot start the chase"):format(v14)))
	end

	local v19 = v16.CFrame
	local v20 = if (p2.Position - v19.Position).Magnitude <= 60 then v19 - v19.LookVector * 150 else v19

	v6.PrimaryPart.CFrame = v20

	local v21 = v20 * CFrame.new(0, 60, -90)

	SFX.new("rbxassetid://137989550922914", 0.7)
	TweenService:Create(CurrentCamera, TweenInfo.new(0.5), {
		CFrame = CFrame.lookAt(v21.Position, v6.PrimaryPart.Position)
	}):Play()

	local ThrowPacingConfig = require(ReplicatedStorage.shared.config.ThrowPacingConfig)
	local v22 = TweenService:Create(v6.PrimaryPart, TweenInfo.new(ThrowPacingConfig.WallRiseTweenTime), {
		CFrame = v6.PrimaryPart.CFrame * CFrame.new(0, 50, 0)
	})

	task.wait(ThrowPacingConfig.WallRiseDelay)
	v22:Play()

	local v23 = RunService.RenderStepped:Connect(function(p1) --[[ Line: 2625 | Upvalues: v6 (copy), CurrentCamera (copy), v21 (copy) ]]
		debug.profilebegin("UECS/ThrowSystem.WallCameraLookAt")
		CurrentCamera.CFrame = CurrentCamera.CFrame:Lerp(CFrame.lookAt(v21.Position, v6.PrimaryPart.Position), (math.min(p1 * 12, 1)))
		debug.profileend()
	end)

	t.give(v23)

	local _, v24 = p4:GetBoundingBox()

	p4.PrimaryPart.CFrame = CFrame.lookAt(p2.CFrame * CFrame.new(-v24.Z / 2, 0, 0).Position, p2.Position)

	for v26, v27 in p4:GetDescendants() do
		if v27:IsA("BasePart") then
			local v28 = v27:GetAttribute("OrigTransparency")

			if typeof(v28) == "number" then
				v27.Transparency = v28
				v27:SetAttribute("OrigTransparency", nil)
			end

			continue
		end

		if v27:IsA("BillboardGui") then
			local v29 = v27:GetAttribute("SunkHidden")

			if typeof(v29) == "boolean" then
				v27.Enabled = v29
				v27:SetAttribute("SunkHidden", nil)
			end
		end
	end

	local v30 = p2.Position - p4.PrimaryPart.Position

	if v30.Magnitude > 0 then
		local Unit = v30.Unit
		local v31, v32

		if p3 then
			local v33, v34 = p3:GetBoundingBox()

			v31 = v33
			v32 = v34
		else
			v31 = p2.CFrame
			v32 = p2.Size
		end

		local v36 = math.abs((Unit:Dot(v31.RightVector))) * v32.X
		local v38 = v36 + math.abs((Unit:Dot(v31.UpVector))) * v32.Y
		local v40 = Unit * (v38 + math.abs((Unit:Dot(v31.LookVector))) * v32.Z) * 0.5

		if p3 then
			p3:PivotTo(p3:GetPivot() + v40)
		else
			p2.CFrame = p2.CFrame + v40
		end
	end

	local WeldConstraint = Instance.new("WeldConstraint")

	WeldConstraint.Parent = p4
	WeldConstraint.Part0 = p4.PrimaryPart
	WeldConstraint.Part1 = p2
	p2.Anchored = false

	if p3 then
		for v41, v42 in p3:GetDescendants() do
			if v42:IsA("BasePart") and v42 ~= p2 then
				v42.Anchored = false
				v42.CanCollide = false
				v42.Massless = true

				local WeldConstraint2 = Instance.new("WeldConstraint")

				WeldConstraint2.Part0 = p2
				WeldConstraint2.Part1 = v42
				WeldConstraint2.Parent = v42
			end
		end
	end

	local v43 = if p7 then p7 else {}
	local FishGroup = Instance.new("Model")

	FishGroup.Name = "FishGroup"
	FishGroup.Parent = p4.Parent
	p4.Parent = FishGroup

	if #v43 > 0 then
		local v44 = p4.PrimaryPart.CFrame
		local _2, v45 = p4:GetBoundingBox()
		local v46 = v45.X / 2

		v47 = v46
		v48 = v46

		for v50, v51 in v43 do
			local v49

			if v51.PrimaryPart then
				local _3, v52 = v51:GetBoundingBox()
				local v53 = v52.X / 2

				if v50 % 2 == 1 then
					v49 = v48 + 1 + v53
					v48 = v49 + v53
				else
					v49 = -(v47 + 1 + v53)
					v47 = -v49 + v53
				end

				v51:PivotTo(v44 * CFrame.new(v49, 0, 0))
				v51.Parent = FishGroup
			end
		end
	end

	FishGroup.PrimaryPart = p4.PrimaryPart
	v22.Completed:Wait()
	v23:Disconnect()

	local v54 = CFrame.lookAt((p4.PrimaryPart.CFrame * CFrame.new(0, 7, 13)).Position, p4.PrimaryPart.Position)
	local Magnitude = (CurrentCamera.CFrame.Position - v54.Position).Magnitude

	TweenService:Create(CurrentCamera, TweenInfo.new(Magnitude / 200), {
		CFrame = v54
	}):Play()
	task.wait(Magnitude / 200)
	CurrentCamera.CameraType = Enum.CameraType.Custom
	CurrentCamera.CameraSubject = p4

	for v55, v56 in p2.PullingEffects:GetChildren() do
		v56.Enabled = true
	end

	for v57, v58 in p2.FishPlum:GetChildren() do
		v58.Enabled = true
	end

	require(ReplicatedStorage.client.remoteFishing.Broadcast).stage("chase", nil, p1._remoteCastToken)

	local v59 = p1:RunFishPullSequence(p4, v6, p5, p6)

	ThrowAnimations.stopBack()
	p1.ThrowingFrame.SpeedMeter.Visible = false
	v6:Destroy()
	Players.LocalPlayer.Character.HumanoidRootPart.Anchored = false
	CurrentCamera.CameraType = Enum.CameraType.Custom
	CurrentCamera.CameraSubject = Players.LocalPlayer.Character and Players.LocalPlayer.Character:FindFirstChildOfClass("Humanoid")

	if v59 == "fail" then
		local t2 = { p4.Name }

		for v61, v62 in v43 do
			if v62 and v62.Parent then
				table.insert(t2, v62.Name)
				v62:Destroy()
			end
		end

		SFX.new("rbxassetid://138366598268192", 0.7)
		SFX.new("rbxassetid://8275897472", 0.7)
		require(ReplicatedStorage.client.remoteFishing.Broadcast).stage("done", {
			Ok = false
		}, p1._remoteCastToken)
		task.wait(0.5)

		local v64 = p1:ShowFishEatenScreen(t2)

		FishGroup:Destroy()
		p2:Destroy()

		if p3 then
			p3:Destroy()
		end

		if v64 then
			p1:_CollectCaughtFish()
		end

		p1.Blackout.BackgroundTransparency = 1
	elseif v59 == "success" then
		SFX.new("rbxassetid://114813573682393", 1)
		ThrowAnimations.playSuccess()
		require(ReplicatedStorage.client.remoteFishing.Broadcast).stage("done", {
			Ok = true
		}, p1._remoteCastToken)
		task.wait(0.5)
		p1:_CollectCaughtFish()
		p1:CollectFishAnimation(p4, p2, p3, p5, v43)
	end

	Satchel.SetEnabled(true)
	GoldenThrow.stopFX()
	t.flush()
	v5 = false
	Remotes.SetFishState:Fire(v5)
end
function v3.RunFishPullSequence(p1, p2, p3, p4, p5) --[[ RunFishPullSequence | Line: 2873 | Upvalues: SFX (copy), Worlds (copy), UIVFX (copy), ClientMusicController (copy), ClientPlayerData (copy), SoundService (copy), t (copy), FishConfig (copy), Workspace (copy), calculateClickPower (copy), Players (copy), ReplicatedStorage (copy), NumberSpinner (copy), isGamepadActive (copy), UserInputService (copy), TweenService (copy), RunService (copy), v7 (ref) ]]
	SFX.new(SFX.Sounds.Alarm, 0.15)

	local v1 = Worlds.GetBiomeById(p4)
	local v2 = v1 and v1.WallForwardSpeed or 16

	UIVFX.Vignette.Start(Color3.fromRGB(255, 0, 0))

	if p1.PullHint then
		p1.PullHint:Show()
	end

	ClientMusicController.SetMuted(true)

	local v3 = if ClientPlayerData.serverProfile:getState().settings.chaseMusicEnabled == false then false else true
	local Sound = Instance.new("Sound")

	Sound.SoundId = "rbxassetid://124770950836203"
	Sound.Volume = 0.5
	Sound.Looped = true
	Sound.Parent = SoundService.SFX

	if v3 then
		Sound:Play()
	end

	t.give(Sound)

	local Sound2 = Instance.new("Sound")

	Sound2.SoundId = "rbxassetid://134896833025703"
	Sound2.Volume = 0
	Sound2.PlaybackSpeed = 1.36
	Sound2.Looped = true
	Sound2.Parent = SoundService.SFX
	Sound2:Play()
	t.give(Sound2)

	local Blackout = p1.Blackout
	local EqualizerSoundEffect = Instance.new("EqualizerSoundEffect")

	EqualizerSoundEffect.HighGain = 0
	EqualizerSoundEffect.MidGain = 0
	EqualizerSoundEffect.LowGain = 0
	EqualizerSoundEffect.Parent = Sound

	local PitchShiftSoundEffect = Instance.new("PitchShiftSoundEffect")

	PitchShiftSoundEffect.Octave = 1
	PitchShiftSoundEffect.Parent = Sound

	local SpeedMeter = p1.ThrowingFrame.SpeedMeter
	local v4 = FishConfig[p2.Name]
	local v5 = if v4 then v4.Strength else 30
	local X = p2.PrimaryPart.Position.X
	local X2 = Workspace.Map.EndFishPosition.Position.X
	local v6 = if X2 - X >= 0 then 1 else -1
	local v72 = calculateClickPower()
	local v8 = (15 + 0.9 * v72) * Players.LocalPlayer:GetAttribute("FishingSpeedMultiplier") * (1 + require(ReplicatedStorage.shared.util.getRodEnchantBonus)(Players.LocalPlayer, "QuickReel") / 100)

	p1.ThrowingFrame.CollectBar.Visible = false
	SpeedMeter.Visible = true
	SpeedMeter.MinimalSpeed.Text = "0"
	SpeedMeter.MaxSpeed.Text = tostring((math.round(v8 * 1.0080000000000002)))
	SpeedMeter.CenterPoint.Rotation = -90

	local ClickFast = SpeedMeter.ClickFast
	local Size = ClickFast.Size
	local v10 = UDim2.new(Size.X.Scale * 1.2, Size.X.Offset * 1.2, Size.Y.Scale * 1.2, Size.Y.Offset * 1.2)
	local ClickSpinner = p1.ClickSpinner

	if not ClickSpinner then
		ClickSpinner = NumberSpinner.fromGuiObject(ClickFast.Counter)
		ClickSpinner.Visible = true
		ClickSpinner.Decimals = 0
		ClickSpinner.Prefix = ""
		ClickSpinner.Suffix = ""
		ClickSpinner.Duration = 0.15
		ClickSpinner.TextSize = 24
		ClickSpinner.AutomaticSize = Enum.AutomaticSize.X
		ClickSpinner.Size = UDim2.fromScale(0, 1)
		p1.ClickSpinner = ClickSpinner
	end

	ClickSpinner.Value = 0

	local v11 = 0
	local v12 = TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

	ClickFast.Visible = not isGamepadActive()

	local v13 = true
	local v14 = "fail"

	local function wallReachedFish() --[[ wallReachedFish | Line: 2978 | Upvalues: p2 (copy), p3 (copy) ]]
		return (p2.PrimaryPart.Position - p3.PrimaryPart.Position):Dot(p3.PrimaryPart.CFrame.LookVector) <= 0
	end

	local v15 = Players.LocalPlayer.Character and Players.LocalPlayer.Character:FindFirstChildOfClass("Humanoid")
	local v16 = if v15 then v15.WalkSpeed else 16

	if v15 then
		v15.WalkSpeed = 0
	end

	t.give(function() --[[ Line: 2990 | Upvalues: v15 (copy), v16 (copy) ]]
		if not (v15 and v15.Parent) then
			return
		end

		v15.WalkSpeed = v16
	end)

	local v17 = p2.PrimaryPart.CFrame
	local v18 = v17 - v17.Position
	local Position = v17.Position
	local v19 = X
	local Z = Position.Z
	local v20 = Z
	local v21 = 0
	local v22 = 0
	local v23 = 0
	local v24 = 0
	local v25 = v8 * 1
	local v26 = v8 * 0.7

	require(ReplicatedStorage.shared.util.getFloatEffects)

	local function clonePortalRig(p1) --[[ clonePortalRig | Line: 3038 | Upvalues: ReplicatedStorage (ref), Workspace (ref), t (ref) ]]
		local Portal = ReplicatedStorage.shared.model:FindFirstChild("Portal")

		if not Portal then
			return nil, 1
		end

		local v1 = Portal:Clone()
		local v2 = v1:GetScale() * 2

		v1:ScaleTo(v2 * 0.01)

		local v3 = v1.PrimaryPart or v1:FindFirstChildWhichIsA("BasePart")

		for v4, v5 in v1:GetDescendants() do
			if v5:IsA("BasePart") then
				v5.Anchored = v5 == v3
				v5.CanCollide = false
			end
		end

		v1:PivotTo(CFrame.new(p1) * CFrame.Angles(0, 1.5707963267948966, 0))
		v1.Parent = Workspace

		local AnimationController = v1:FindFirstChildOfClass("AnimationController")
		local v7 = if AnimationController then AnimationController:FindFirstChildOfClass("Animator") else AnimationController

		if v7 then
			local Animation = Instance.new("Animation")

			Animation.AnimationId = "rbxassetid://104806551419121"
			Animation.Parent = v1

			local v8 = v7:LoadAnimation(Animation)

			v8.Looped = true
			v8:Play()
		end

		t.give(v1)

		return v1, v2
	end

	local v27 = nil
	local v28 = v20
	local v29 = false
	local v30 = 0
	local v31 = 0
	local v32, v33

	if p5 then
		local v34 = X + v6 * 300
		local v38, v39 = clonePortalRig((Vector3.new(if v6 > 0 then math.min(v34, X2 - 50) else math.max(v34, X2 + 50), Position.Y, v20)))

		v32 = v39
		v33 = v38
	else
		v33 = nil
		v32 = 1
	end

	local v41 = 0.8 * v8 / math.max(math.sqrt(v5 / v72) * 8, 0.001)
	local v42 = UserInputService.InputBegan:Connect(function(p1, p2) --[[ Line: 3100 | Upvalues: v13 (ref), v23 (ref), v41 (copy), v8 (copy), v11 (ref), ClickSpinner (ref), ClickFast (copy), v10 (copy), TweenService (ref), v12 (copy), Size (copy) ]]
		if not v13 or p2 then
			return
		end

		if p1.UserInputType ~= Enum.UserInputType.MouseButton1 and (p1.UserInputType ~= Enum.UserInputType.Touch and p1.KeyCode ~= Enum.KeyCode.ButtonX) then
			return
		end

		v23 = math.min(v23 + v41, v8)
		v11 = v11 + 1
		ClickSpinner.Value = v11
		ClickFast.Size = v10
		TweenService:Create(ClickFast, v12, {
			Size = Size
		}):Play()
	end)

	t.give(v42)

	local FieldOfView = workspace.CurrentCamera.FieldOfView
	local v43 = FieldOfView
	local v44 = RunService.Heartbeat:Connect(function(p12) --[[ Line: 3122 | Upvalues: v13 (ref), SpeedMeter (copy), p3 (copy), p2 (copy), v14 (ref), v21 (ref), ClickFast (copy), isGamepadActive (ref), v2 (copy), v15 (copy), v7 (ref), v6 (copy), v23 (ref), v25 (copy), v24 (ref), v8 (copy), v26 (copy), v19 (ref), X2 (copy), Z (ref), v20 (copy), v33 (ref), v29 (ref), Position (copy), v27 (ref), v28 (ref), v30 (ref), v31 (ref), v32 (ref), SFX (ref), clonePortalRig (copy), RunService (ref), v22 (ref), v18 (copy), X (copy), ReplicatedStorage (ref), p1 (copy), Sound2 (copy), FieldOfView (copy), v43 (ref), Blackout (copy), EqualizerSoundEffect (copy), PitchShiftSoundEffect (copy) ]]
		debug.profilebegin("UECS/ThrowSystem.PullMinigame")

		if v13 then
			if not (SpeedMeter.Parent and (p3.PrimaryPart and p2.PrimaryPart)) then
				v14 = "fail"
			else
				v21 = v21 + p12
				ClickFast.Visible = not isGamepadActive()
				p3.PrimaryPart.CFrame = p3.PrimaryPart.CFrame + p3.PrimaryPart.CFrame.LookVector * v2 * p12

				local v1 = if v15 and v15.Parent then v15.MoveDirection else Vector3.new(0, 0, 0)

				if v7 and v1.Magnitude < 0.1 then
					v1 = Vector3.new(v6, 0, 0)
				end

				local v4 = v1.X * v6
				local Z2 = v1.Z
				local v5 = if v4 > 0.15 then 1 elseif v4 < -0.15 then -1 else 0

				if v5 > 0 then
					v23 = v23 + v25 * p12
				elseif v5 < 0 then
					v23 = v23 - v25 * 0.5 * p12
				end

				v24 = v24 + (if Z2 > 0.15 then 1 elseif Z2 < -0.15 then -1 else 0) * v25 * 0.8 * p12
				v23 = v23 * math.exp(-0.8 * p12)
				v24 = v24 * math.exp(-0.8 * p12)
				v23 = math.clamp(v23, -v8 * 0.3, v8)
				v24 = math.clamp(v24, -v26, v26)

				local v132 = v19

				v19 = v19 + v23 * v6 * p12
				v19 = if v6 > 0 then math.min(v19, X2) else math.max(v19, X2)
				Z = Z + v24 * p12
				Z = math.clamp(Z, v20 - 104, v20 + 104)

				if v33 and (not v29 and v21 >= 0.7) then
					v29 = true

					local v212 = v19 + v6 * 300
					local v222 = if v6 > 0 then math.min(v212, X2 - 50) else math.max(v212, X2 + 50)

					if (v222 - v19) * v6 > 0 then
						v33:PivotTo(CFrame.new(v222, Position.Y, Z) * CFrame.Angles(0, 1.5707963267948966, 0))
						v27 = v222
						v28 = Z
						v30 = 0
						v31 = 1
					else
						v33:Destroy()
						v33 = nil
					end
				end

				if v33 and v31 ~= 0 then
					v30 = math.clamp(v30 + v31 * p12 / 0.35, 0, 1)
					v33:ScaleTo(v32 * math.max(v30 * v30 * (3 - v30 * 2), 0.01))

					if v31 > 0 and v30 >= 1 then
						v31 = 0
					elseif v31 < 0 and v30 <= 0 then
						v33:Destroy()
						v33 = nil
						v31 = 0
					end
				end

				if v27 and (v132 - v27) * (v19 - v27) <= 0 then
					if math.abs(Z - v28) <= 16 then
						v19 = X2 - v6 * 20
						v23 = 0
						v24 = 0
						SFX.new(SFX.Sounds.PortalIn, 0.6)

						local v312, v322 = clonePortalRig((Vector3.new(v19, Position.Y, Z)))

						if v312 then
							task.spawn(function() --[[ Line: 3234 | Upvalues: v312 (copy), RunService (ref), v322 (copy) ]]
								local sum = 0

								while sum < 0.35 and v312.Parent do
									sum = sum + RunService.Heartbeat:Wait()

									local v1 = math.clamp(sum / 0.35, 0, 1)

									v312:ScaleTo(v322 * math.max(v1 * v1 * (3 - v1 * 2), 0.01))
								end

								task.wait(0.15000000000000002)

								local sum2 = 0.35

								while sum2 > 0 and v312.Parent do
									sum2 = sum2 - RunService.Heartbeat:Wait()

									local v2 = math.clamp(sum2 / 0.35, 0, 1)

									v312:ScaleTo(v322 * math.max(v2 * v2 * (3 - v2 * 2), 0.01))
								end

								if not v312.Parent then
									return
								end

								v312:Destroy()
							end)
						end

						local CurrentCamera = workspace.CurrentCamera
						local v332 = CurrentCamera.CFrame

						CurrentCamera.CameraType = Enum.CameraType.Scriptable
						CurrentCamera.CFrame = v332
						task.delay(0.5, function() --[[ Line: 3263 | Upvalues: SFX (ref), v13 (ref), CurrentCamera (copy), p2 (ref) ]]
							SFX.new(SFX.Sounds.PortalOut, 0.6)

							if not v13 then
								return
							end

							CurrentCamera.CameraType = Enum.CameraType.Custom
							CurrentCamera.CameraSubject = p2
						end)
					end

					v27 = nil
					v31 = -1
				end

				local v35 = math.sin(v21 * 10 + 1.3) * 0.4
				local v37 = if math.sqrt(v23 * v23 + v24 * v24) > 0.5 then math.atan2(-v24, math.abs(v23) + 0.01) * 0.6 else 0

				v22 = v22 + (v37 - v22) * (1 - math.exp(-8 * p12))

				local v44 = Vector3.new(v19, Position.Y + v35, Z)

				p2.Parent:PivotTo(CFrame.new(v44) * v18 * CFrame.Angles(0, v22, 0))

				if X ~= X2 then
					local stage = require(ReplicatedStorage.client.remoteFishing.Broadcast).stage
					local t = {}

					t.P = math.clamp((v19 - X) / (X2 - X), 0, 1)
					stage("pull", t, p1._remoteCastToken)
				end

				local v48 = math.clamp(math.max(v23, 0) / v8, 0, 1)

				SpeedMeter.CenterPoint.Rotation = v48 * 180 + -90 + (math.sin(v21 * 13.7) * 2.5 + math.sin(v21 * 7.3 + 1.1) * 1.5) * v48
				Sound2.Volume = math.clamp(v48 / 0.5, 0, 1) * 1.5
				Sound2.PlaybackSpeed = v48 * 2.64 + 1.36
				v43 = v43 + (FieldOfView + v48 * 20 - v43) * (1 - math.exp(-6 * p12))
				workspace.CurrentCamera.FieldOfView = v43

				local v52 = (p2.PrimaryPart.Position - p3.PrimaryPart.Position):Dot(p3.PrimaryPart.CFrame.LookVector) <= 0

				if v52 then
					Blackout.BackgroundTransparency = 0
					v14 = "fail"
				else
					local v53 = (p2.PrimaryPart.Position - p3.PrimaryPart.Position):Dot(p3.PrimaryPart.CFrame.LookVector)

					if v53 <= 80 and v53 > 0 then
						local v54 = math.clamp((80 - v53) / 70, 0, 1)

						EqualizerSoundEffect.HighGain = v54 * -80
						PitchShiftSoundEffect.Octave = 1 - v54 * 0.9
						Blackout.BackgroundTransparency = 1 - v54 * 0.9
					elseif v53 > 80 then
						EqualizerSoundEffect.HighGain = 0
						PitchShiftSoundEffect.Octave = 1
						Blackout.BackgroundTransparency = 1
					end

					if v19 == X2 then
						v14 = "success"
					end
				end
			end

			v13 = false
		end

		debug.profileend()
	end)

	t.give(v44)

	while v13 do
		task.wait()
	end

	v44:Disconnect()
	v42:Disconnect()

	if v15 and v15.Parent then
		v15.WalkSpeed = v16
	end

	ClickFast.Size = Size
	ClickFast.Visible = true
	UIVFX.Vignette.Stop()
	Sound:Destroy()
	Sound2:Destroy()
	workspace.CurrentCamera.FieldOfView = FieldOfView

	if p1.PullHint then
		p1.PullHint:Hide()
	end

	ClientMusicController.SetMuted(false)

	if v14 ~= "success" then
		return v14
	end

	Blackout.BackgroundTransparency = 1

	return v14
end
function v3.CollectFishAnimation(p1, p2, p3, p4, p5, p6) --[[ CollectFishAnimation | Line: 3380 | Upvalues: ReplicatedStorage (copy), v2 (copy) ]]
	require(ReplicatedStorage.client.throw.CollectFlight).play(v2, p2, p3, p4, p5, p6, p1._lastDuplicatedFish)
end
function v3.StopAutoFishing(p1) --[[ StopAutoFishing | Line: 3408 | Upvalues: v6 (ref) ]]
	v6 = false

	if not p1.CancelAutoButton then
		return
	end

	p1.CancelAutoButton.Visible = false
end
function v3.StartAutoFishing(p1) --[[ StartAutoFishing | Line: 3418 | Upvalues: v5 (ref), v6 (ref), ClientPlayerData (copy), ReplicatedStorage (copy), FishLimit (copy), notifications (copy), ownsAutoFishing (copy), v3 (ref), Players (copy), AutoFishing (copy), GemsRewardHelper (copy), v7 (ref) ]]
	print("[ThrowSystem] StartAutoFishing called. UserFishing:", v5, "AutoFishing:", v6)

	if v5 or v6 then
		print("[ThrowSystem] StartAutoFishing returning: UserFishing/AutoFishing is active")

		return
	end

	local v1

	if ClientPlayerData.isPlayerDataLoaded then
		local v2 = ClientPlayerData.serverProfile:getState()

		v1 = if FishLimit <= require(ReplicatedStorage.shared.config.InventoryConfig).countFish(v2) then true else false
	else
		v1 = false
	end

	if v1 then
		print("[ThrowSystem] StartAutoFishing returning: Inventory full")
		notifications:Send("Your fish inventory is full! (" .. FishLimit .. "/" .. FishLimit .. ")")

		return
	end

	print("[ThrowSystem] StartAutoFishing check ownsAutoFishing:", ownsAutoFishing())

	local v32

	if v3._hasFakeAutoFishing then
		v32 = true
	else
		local v4 = Players.LocalPlayer:GetAttribute(AutoFishing.Attribute)

		v32 = if typeof(v4) == "number" and v4 > 1 then true else GemsRewardHelper.HasAutoFishing(Players.LocalPlayer)
	end

	if not v32 then
		print("[ThrowSystem] StartAutoFishing returning: Does not own auto-fishing")

		return
	end

	print("[ThrowSystem] StartAutoFishing check IsInThrowZone:", p1.IsInThrowZone and p1.IsInThrowZone())

	if p1.IsInThrowZone and not p1.IsInThrowZone() then
		print("[ThrowSystem] StartAutoFishing returning: Not in throw zone")

		return
	end

	print("[ThrowSystem] StartAutoFishing setting AutoFishing = true")
	v6 = true
	task.spawn(function() --[[ Line: 3445 | Upvalues: v6 (ref), p1 (copy), ClientPlayerData (ref), ReplicatedStorage (ref), FishLimit (ref), notifications (ref), v7 (ref), v5 (ref) ]]
		while v6 do
			local v1

			if p1.IsInThrowZone and not p1.IsInThrowZone() then
				p1:StopAutoFishing()

				break
			end

			if ClientPlayerData.isPlayerDataLoaded then
				local v2 = ClientPlayerData.serverProfile:getState()

				v1 = FishLimit <= require(ReplicatedStorage.shared.config.InventoryConfig).countFish(v2)
			else
				v1 = false
			end

			if v1 then
				notifications:Send("Your fish inventory is full! (" .. FishLimit .. "/" .. FishLimit .. ")")
				p1:StopAutoFishing()

				break
			end

			v7 = true
			p1:ThrowingSegment(true)

			repeat
				task.wait()
			until not v5

			v7 = false

			if not v6 then
				break
			end

			local sum = 0

			while true do
				if not (v6 and sum < 2) then
					continue
				end

				task.wait(0.1)

				if p1.IsInThrowZone and not p1.IsInThrowZone() then
					break
				end

				sum = sum + 0.1
			end

			p1:StopAutoFishing()
		end

		v7 = false
	end)
end
function v3.IsAutoFishing(p1) --[[ IsAutoFishing | Line: 3492 | Upvalues: v6 (ref) ]]
	return v6
end
function v3.SetFakeAutoFishing(p1, p2) --[[ SetFakeAutoFishing | Line: 3496 ]]
	p1._hasFakeAutoFishing = p2
end
function v3.ShowFishEatenScreen(p1, p2) --[[ ShowFishEatenScreen | Line: 3508 | Upvalues: ReplicatedStorage (copy) ]]
	return require(ReplicatedStorage.client.throw.FishEatenScreen).show(p1.FishEatenUI, p1.LastFishMutation, p2)
end
function v3.Init(p1) --[[ Init | Line: 3520 | Upvalues: SFX (copy), SoundService (copy), ContentProvider (copy), ReplicatedStorage (copy), Players (copy), GoldenThrow (copy), ControlHint (copy), ButtonX (copy), ButtonX2 (copy), ButtonY (copy), CollectionService (copy), RunService (copy), v5 (ref), TweenService (copy), v6 (ref), ClientPlayerData (copy), FishLimit (copy), notifications (copy), v3 (ref), AutoFishing (copy), GemsRewardHelper (copy), MarketplaceService (copy), UserInputService (copy) ]]
	task.spawn(function() --[[ Line: 3521 | Upvalues: SFX (ref), SoundService (ref), ContentProvider (ref), ReplicatedStorage (ref) ]]
		local t = {}

		for v1, v2 in {
			"rbxassetid://139733419985896",
			"rbxassetid://136515155291593",
			"rbxassetid://109081723292068",
			"rbxassetid://125585669270021",
			"rbxassetid://91024772071405",
			"rbxassetid://130249772407099",
			"rbxassetid://130990339683290",
			"rbxassetid://127613720380706",
			"rbxassetid://140530009847955",
			"rbxassetid://119135010875996",
			"rbxassetid://134699420140804",
			"rbxassetid://83673781452193",
			"rbxassetid://137989550922914",
			"rbxassetid://138366598268192",
			"rbxassetid://8275897472",
			"rbxassetid://114813573682393",
			"rbxassetid://124770950836203",
			SFX.Sounds.ProgressBarChangeDirection,
			SFX.Sounds.Alarm,
			SFX.Sounds.PortalIn,
			SFX.Sounds.PortalOut
		} do
			local Sound = Instance.new("Sound")

			Sound.SoundId = v2
			Sound.Volume = 0
			Sound.Parent = SoundService
			table.insert(t, Sound)
		end

		ContentProvider:PreloadAsync(t)

		for v3, v4 in t do
			v4:Play()
		end

		task.wait(0.5)

		for v5, v6 in t do
			v6:Stop()
			v6:Destroy()
		end

		local Animation = Instance.new("Animation")

		Animation.AnimationId = "rbxassetid://104806551419121"

		local t2 = { Animation }
		local Portal = ReplicatedStorage.shared.model:FindFirstChild("Portal")

		if Portal then
			table.insert(t2, Portal)
		end

		ContentProvider:PreloadAsync(t2)
		Animation:Destroy()
	end)

	local MainUI = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI")

	p1.FishButtonFrame = MainUI.ThrowFrame
	p1.FishButton = p1.FishButtonFrame.KickButton

	local UIScale = p1.FishButtonFrame:FindFirstChildOfClass("UIScale")

	if not UIScale then
		UIScale = Instance.new("UIScale")
		UIScale.Parent = p1.FishButtonFrame
	end

	UIScale.Scale = 0

	local v1 = false
	local v2 = nil
	local Animation = Instance.new("Animation")

	Animation.AnimationId = "rbxassetid://119527348319095"
	ContentProvider:PreloadAsync({ Animation })
	p1.ThrowingFrame = MainUI.Throwing
	p1.Blackout = MainUI.Blackout
	p1.Blackout.BackgroundTransparency = 1
	p1.FishEatenUI = MainUI.FishEaten
	p1.FishEatenUI.Visible = false
	p1.ZoneFrameComponent = p1.UECS:WaitForComponent(p1.ThrowingFrame.ZoneFrame, "ZoneFrame")
	p1.AutoFishButton = p1.FishButtonFrame:FindFirstChild("AutoFish")
	p1.CancelAutoButton = p1.ThrowingFrame:FindFirstChild("CancelAutoButton")

	if p1.CancelAutoButton then
		p1.CancelAutoButton.Visible = false
	end

	GoldenThrow.init({
		goldenThrow = p1.FishButtonFrame.Efects.GoldenThrow,
		effectsContainer = MainUI.Effects
	})
	p1.FishButtonHint = ControlHint.new({
		label = "Throw",
		anchorTo = p1.FishButton,
		keyCode = ButtonX
	})
	p1.ThrowBarHint = ControlHint.new({
		label = "Stop",
		anchorTo = p1.ThrowingFrame.ThrowBar,
		keyCode = ButtonX
	})
	p1.PullHint = ControlHint.new({
		label = "Tap to Pull",
		anchorTo = p1.ThrowingFrame.SpeedMeter,
		keyCode = ButtonX2
	})

	if p1.AutoFishButton then
		p1.AutoFishHint = ControlHint.new({
			label = "Auto Fish",
			anchorTo = p1.AutoFishButton,
			keyCode = ButtonY
		})
	end

	if p1.CancelAutoButton then
		p1.CancelAutoHint = ControlHint.new({
			label = "Stop Auto",
			anchorTo = p1.CancelAutoButton,
			keyCode = ButtonY
		})
	end

	local LocalPlayer = Players.LocalPlayer
	local v32 = nil

	local function bindCharacter(p1) --[[ bindCharacter | Line: 3661 | Upvalues: v32 (ref) ]]
		v32 = p1:WaitForChild("HumanoidRootPart")
	end

	if LocalPlayer.Character then
		v32 = LocalPlayer.Character:WaitForChild("HumanoidRootPart")
	end

	LocalPlayer.CharacterAdded:Connect(bindCharacter)

	local v4 = RaycastParams.new()

	v4.FilterType = Enum.RaycastFilterType.Include

	local function refreshThrowZoneFilter() --[[ refreshThrowZoneFilter | Line: 3675 | Upvalues: v4 (copy), CollectionService (ref) ]]
		v4.FilterDescendantsInstances = CollectionService:GetTagged("ThrowZone")
	end

	v4.FilterDescendantsInstances = CollectionService:GetTagged("ThrowZone")
	CollectionService:GetInstanceAddedSignal("ThrowZone"):Connect(refreshThrowZoneFilter)
	CollectionService:GetInstanceRemovedSignal("ThrowZone"):Connect(refreshThrowZoneFilter)
	function p1.IsInThrowZone() --[[ isInThrowZone | Line: 3685 | Upvalues: v32 (ref), v4 (copy) ]]
		if not (v32 and v32.Parent) then
			return false
		end

		return workspace:Raycast(v32.Position, Vector3.new(0, -15, 0), v4) ~= nil
	end
	RunService.RenderStepped:Connect(function() --[[ Line: 3693 | Upvalues: v32 (ref), v1 (ref), v2 (ref), UIScale (ref), p1 (copy), LocalPlayer (copy), v4 (copy), v5 (ref), TweenService (ref), Animation (copy), v6 (ref) ]]
		debug.profilebegin("UECS/ThrowSystem.FishButtonZone")

		if v32 and v32.Parent then
			local v12 = (if v32 and v32.Parent then workspace:Raycast(v32.Position, Vector3.new(0, -15, 0), v4) ~= nil else false) and not v5

			if v12 and not v1 then
				v1 = true
				p1.FishButtonFrame.Visible = true

				if v2 then
					v2:Cancel()
				end

				UIScale.Scale = 0
				v2 = TweenService:Create(UIScale, TweenInfo.new(0.35, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
					Scale = 1
				})
				v2:Play()

				local Character = LocalPlayer.Character
				local v22 = if Character then Character:FindFirstChildOfClass("Humanoid") else Character

				if v22 then
					local v42 = (v22:FindFirstChildOfClass("Animator") or Instance.new("Animator", v22)):LoadAnimation(Animation)

					v42.Looped = false
					v42:Play()
					v42.Stopped:Once(function() --[[ Line: 3739 | Upvalues: v42 (copy) ]]
						v42:Destroy()
					end)
				end
			elseif not v12 and v1 then
				v1 = false

				if v2 then
					v2:Cancel()
				end

				v2 = TweenService:Create(UIScale, TweenInfo.new(0.21, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
					Scale = 0
				})
				v2:Play()
				v2.Completed:Once(function() --[[ Line: 3754 | Upvalues: v1 (ref), p1 (ref) ]]
					if v1 then
						return
					end

					p1.FishButtonFrame.Visible = false
				end)
			end

			if v12 then
				p1.FishButtonHint:Show()
			else
				p1.FishButtonHint:Hide()
			end

			if p1.AutoFishHint then
				if v12 then
					p1.AutoFishHint:Show()
				else
					p1.AutoFishHint:Hide()
				end
			end

			if p1.CancelAutoButton then
				p1.CancelAutoButton.Visible = v6 and v5

				if p1.CancelAutoHint then
					if p1.CancelAutoButton.Visible then
						p1.CancelAutoHint:Show()
					else
						p1.CancelAutoHint:Hide()
					end
				end
			end
		else
			if v1 then
				v1 = false

				if v2 then
					v2:Cancel()
				end

				UIScale.Scale = 0
				p1.FishButtonFrame.Visible = false
			end

			p1.FishButtonHint:Hide()

			if p1.AutoFishHint then
				p1.AutoFishHint:Hide()
			end

			if p1.CancelAutoButton then
				p1.CancelAutoButton.Visible = false
			end

			if p1.CancelAutoHint then
				p1.CancelAutoHint:Hide()
			end

			v32 = LocalPlayer.Character:FindFirstChild("HumanoidRootPart")
		end

		debug.profileend()
	end)
	p1.FishButton.MouseButton1Click:Connect(function() --[[ Line: 3785 | Upvalues: v5 (ref), v6 (ref), ClientPlayerData (ref), ReplicatedStorage (ref), FishLimit (ref), notifications (ref), p1 (copy) ]]
		if v5 or v6 then
			return
		end

		local v1

		if ClientPlayerData.isPlayerDataLoaded then
			local v2 = ClientPlayerData.serverProfile:getState()

			v1 = FishLimit <= require(ReplicatedStorage.shared.config.InventoryConfig).countFish(v2)
		else
			v1 = false
		end

		if v1 then
			notifications:Send("Your fish inventory is full! (" .. FishLimit .. "/" .. FishLimit .. ")")
		else
			p1:ThrowingSegment()
		end
	end)

	local function requestAutoFishing() --[[ requestAutoFishing | Line: 3801 | Upvalues: v3 (ref), Players (ref), AutoFishing (ref), GemsRewardHelper (ref), MarketplaceService (ref), p1 (copy) ]]
		local v1

		if v3._hasFakeAutoFishing then
			v1 = true
		else
			local v2 = Players.LocalPlayer:GetAttribute(AutoFishing.Attribute)

			v1 = if typeof(v2) == "number" and v2 > 1 then true else GemsRewardHelper.HasAutoFishing(Players.LocalPlayer)
		end

		if v1 then
			p1:StartAutoFishing()
		else
			MarketplaceService:PromptGamePassPurchase(Players.LocalPlayer, AutoFishing.GamepassId)
		end
	end

	if p1.AutoFishButton then
		p1.AutoFishButton.MouseButton1Click:Connect(requestAutoFishing)
	end

	if p1.CancelAutoButton then
		p1.CancelAutoButton.MouseButton1Click:Connect(function() --[[ Line: 3812 | Upvalues: p1 (copy) ]]
			p1:StopAutoFishing()
		end)
	end

	local function isUIPanelOpen() --[[ isUIPanelOpen | Line: 3821 | Upvalues: p1 (copy) ]]
		local v1 = p1.UECS and p1.UECS:WaitForAnyComponent("UIFrameOpener")

		return if v1 == nil then false else v1.OpenedUIComponent:Get() ~= nil
	end

	UserInputService.InputBegan:Connect(function(p12, p2) --[[ Line: 3829 | Upvalues: v5 (ref), v6 (ref), ButtonX (ref), p1 (copy), ClientPlayerData (ref), ReplicatedStorage (ref), FishLimit (ref), notifications (ref) ]]
		if p2 or (v5 or v6) then
			return
		end

		if p12.UserInputType ~= Enum.UserInputType.Gamepad1 or p12.KeyCode ~= ButtonX then
			return
		end

		if not p1.FishButtonFrame.Visible then
			return
		end

		local v1 = p1.UECS and p1.UECS:WaitForAnyComponent("UIFrameOpener")

		if if v1 == nil then false else v1.OpenedUIComponent:Get() ~= nil then
			return
		end

		local v3

		if ClientPlayerData.isPlayerDataLoaded then
			local v4 = ClientPlayerData.serverProfile:getState()

			v3 = FishLimit <= require(ReplicatedStorage.shared.config.InventoryConfig).countFish(v4)
		else
			v3 = false
		end

		if v3 then
			notifications:Send("Your fish inventory is full! (" .. FishLimit .. "/" .. FishLimit .. ")")
		else
			p1:ThrowingSegment()
		end
	end)
	UserInputService.InputBegan:Connect(function(p12, p2) --[[ Line: 3851 | Upvalues: ButtonY (ref), v6 (ref), p1 (copy), v5 (ref), v3 (ref), Players (ref), AutoFishing (ref), GemsRewardHelper (ref), MarketplaceService (ref) ]]
		if p2 then
			return
		end

		if p12.UserInputType ~= Enum.UserInputType.Gamepad1 or p12.KeyCode ~= ButtonY then
			return
		end

		if v6 then
			p1:StopAutoFishing()

			return
		end

		if not p1.AutoFishButton or (not p1.AutoFishButton.Visible or (not p1.FishButtonFrame.Visible or v5)) then
			return
		end

		local v1 = p1.UECS and p1.UECS:WaitForAnyComponent("UIFrameOpener")

		if if v1 == nil then false else v1.OpenedUIComponent:Get() ~= nil then
			return
		end

		local v32

		if v3._hasFakeAutoFishing then
			v32 = true
		else
			local v4 = Players.LocalPlayer:GetAttribute(AutoFishing.Attribute)

			v32 = if typeof(v4) == "number" and v4 > 1 then true else GemsRewardHelper.HasAutoFishing(Players.LocalPlayer)
		end

		if v32 then
			p1:StartAutoFishing()
		else
			MarketplaceService:PromptGamePassPurchase(Players.LocalPlayer, AutoFishing.GamepassId)
		end
	end)
	UserInputService.InputBegan:Connect(function(p1, p2) --[[ Line: 3880 | Upvalues: RunService (ref), v5 (ref), v6 (ref), LocalPlayer (copy), ReplicatedStorage (ref), notifications (ref) ]]
		if not RunService:IsStudio() then
			return
		end

		if p2 or (v5 or v6) then
			return
		end

		if p1.KeyCode ~= Enum.KeyCode.M then
			return
		end

		local v1 = LocalPlayer.Character and LocalPlayer.Character:FindFirstChild("HumanoidRootPart")

		if not v1 then
			return
		end

		local WaterVolumeName = require(ReplicatedStorage.shared.config.DeepsConfig).WaterVolumeName
		local v2 = workspace:FindFirstChild(WaterVolumeName, true)

		if v2 and v2:IsA("BasePart") then
			v1.CFrame = CFrame.new((Vector3.new(v2.Position.X, v2.Position.Y + v2.Size.Y / 2 + 6, v2.Position.Z)))
		else
			notifications:Send("Debug teleport: " .. WaterVolumeName .. " not found.")
		end
	end)
end

return v3