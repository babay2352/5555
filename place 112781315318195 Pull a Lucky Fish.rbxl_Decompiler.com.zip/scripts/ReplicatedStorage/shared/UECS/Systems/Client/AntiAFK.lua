-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TeleportService = game:GetService("TeleportService")
local UserInputService = game:GetService("UserInputService")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local Remotes = require(ReplicatedStorage.shared.Remotes)
local notifications = require(ReplicatedStorage.shared.module.notifications)
local t = {
	UECS = nil,
	Priority = 50
}

local function restoreTraining(p1, p2) --[[ restoreTraining | Line: 35 | Upvalues: notifications (copy), ClientPlayerData (copy) ]]
	print("[Anti-AFK] Restoring training from teleport data. Tool:", (tostring(p2)))
	notifications:Send("Anti AFK: Restoring training in 5 seconds!")
	task.wait(5)

	local v1 = p1.Character or p1.CharacterAdded:Wait()
	local Backpack = p1:WaitForChild("Backpack", 15)
	local v2 = if v1 then v1:FindFirstChildOfClass("Humanoid") else v1

	if not (Backpack and v2) then
		warn("[Anti-AFK] No backpack/humanoid to restore training with.")

		return
	end

	local v3 = if p2 and p2 ~= "" then p2 else ClientPlayerData.serverProfile:getState().trainingTool

	if not v3 or v3 == "" then
		print("[Anti-AFK] No training tool to restore.")

		return
	end

	local v4 = Backpack:WaitForChild(v3, 15)

	if v4 and v4:IsA("Tool") then
		v2:EquipTool(v4)
		print("[Anti-AFK] Training tool equipped successfully.")
		notifications:Send("Anti AFK: Training restored!")
	else
		warn("[Anti-AFK] Training tool not found in backpack:", (tostring(v3)))
	end
end

local function restoreFishing(p1) --[[ restoreFishing | Line: 70 | Upvalues: notifications (copy), ReplicatedStorage (copy) ]]
	print("[Anti-AFK] Restoring auto fishing from teleport data.")
	notifications:Send("Anti AFK: Restoring Auto Fishing in 5 seconds!")
	task.wait(5)

	local HumanoidRootPart = (p1.Character or p1.CharacterAdded:Wait()):WaitForChild("HumanoidRootPart", 15)

	if not HumanoidRootPart then
		warn("[Anti-AFK] No HumanoidRootPart to restore fishing with.")

		return
	end

	local ThrowZone = workspace:WaitForChild("ThrowZone", 15)

	if ThrowZone and ThrowZone:IsA("BasePart") then
		print("[Anti-AFK] Teleporting player to ThrowZone.")
		HumanoidRootPart.CFrame = ThrowZone.CFrame * CFrame.new(0, 5, 0)
	else
		print("[Anti-AFK] ThrowZone not found, teleporting to fallback coordinates.")
		HumanoidRootPart.CFrame = CFrame.new(94, 11.5, -378)
	end

	task.wait(2)

	local ThrowSystem = require(ReplicatedStorage.shared.UECS.Systems.Client.ThrowSystem)

	if ThrowSystem.SetFakeAutoFishing then
		ThrowSystem:SetFakeAutoFishing(true)
	end

	for i = 1, 5 do
		print(string.format("[Anti-AFK] Attempt %d to restore Auto Fishing...", i))

		if ThrowSystem.IsInThrowZone and ThrowSystem.IsInThrowZone() then
			ThrowSystem:StartAutoFishing()

			if ThrowSystem.IsAutoFishing and ThrowSystem:IsAutoFishing() then
				print("[Anti-AFK] Auto Fishing successfully started.")
				notifications:Send("Anti AFK: Auto Fishing restored!")

				return
			end
		else
			print("[Anti-AFK] Player is not in throw zone yet.")
		end

		task.wait(2)
	end

	warn("[Anti-AFK] Could not restore auto fishing after multiple retries.")
	notifications:Send("Anti AFK: Failed to restore Auto Fishing!")
end

function t.Init(p1) --[[ Init | Line: 118 | Upvalues: ClientPlayerData (copy), Players (copy), UserInputService (copy), TeleportService (copy), ReplicatedStorage (copy), Remotes (copy), notifications (copy), restoreTraining (copy), restoreFishing (copy) ]]
	print("[Anti-AFK] Initializing System...")

	repeat
		task.wait()
	until ClientPlayerData.isPlayerDataLoaded

	local LocalPlayer = Players.LocalPlayer
	local v1 = os.clock()

	local function resetInputTime() --[[ resetInputTime | Line: 127 | Upvalues: v1 (ref) ]]
		v1 = os.clock()
	end

	UserInputService.InputBegan:Connect(resetInputTime)
	UserInputService.InputChanged:Connect(resetInputTime)

	local v2 = nil
	local v3 = false

	local function teleportToPlace() --[[ teleportToPlace | Line: 150 | Upvalues: v3 (ref), TeleportService (ref), LocalPlayer (copy), v2 (ref) ]]
		v3 = false
		pcall(function() --[[ Line: 152 | Upvalues: TeleportService (ref), LocalPlayer (ref), v2 (ref) ]]
			TeleportService:Teleport(game.PlaceId, LocalPlayer, v2)
		end)
	end

	local function hop(p1) --[[ hop | Line: 157 | Upvalues: v2 (ref), v3 (ref), TeleportService (ref), LocalPlayer (copy) ]]
		v2 = p1
		v3 = true

		if pcall(function() --[[ Line: 160 | Upvalues: TeleportService (ref), LocalPlayer (ref), p1 (copy) ]]
			TeleportService:TeleportToPlaceInstance(game.PlaceId, game.JobId, LocalPlayer, nil, p1)
		end) then
			return
		end

		v3 = false
		pcall(function() --[[ Line: 152 | Upvalues: TeleportService (ref), LocalPlayer (ref), v2 (ref) ]]
			TeleportService:Teleport(game.PlaceId, LocalPlayer, v2)
		end)
	end

	TeleportService.TeleportInitFailed:Connect(function(p1) --[[ Line: 171 | Upvalues: LocalPlayer (copy), v3 (ref), TeleportService (ref), v2 (ref) ]]
		if p1 == LocalPlayer and v3 then
			warn("[Anti-AFK] Same-server rejoin failed; falling back to a normal teleport.")
			v3 = false
			pcall(function() --[[ Line: 152 | Upvalues: TeleportService (ref), LocalPlayer (ref), v2 (ref) ]]
				TeleportService:Teleport(game.PlaceId, LocalPlayer, v2)
			end)
		end
	end)

	local function currentActivity() --[[ currentActivity | Line: 185 | Upvalues: LocalPlayer (copy), p1 (copy), ReplicatedStorage (ref) ]]
		local Character = LocalPlayer.Character

		if Character and (Character:FindFirstChild("Humanoid") and Character.Humanoid.Health > 0) then
			for v1, v2 in Character:GetChildren() do
				if v2:IsA("Tool") and p1.UECS:GetComponent(v2, "TrainToolComponent") then
					return "training", v2.Name
				end
			end
		end

		local ThrowSystem = require(ReplicatedStorage.shared.UECS.Systems.Client.ThrowSystem)

		if ThrowSystem.IsAutoFishing and ThrowSystem:IsAutoFishing() then
			return "fishing", ""
		end

		return nil, ""
	end

	Remotes.SimulateAntiAfkRejoin:On(function() --[[ Line: 204 | Upvalues: currentActivity (copy), notifications (ref), v2 (ref), v3 (ref), TeleportService (ref), LocalPlayer (copy) ]]
		local v1, v22 = currentActivity()

		print((("[Anti-AFK] Admin-triggered rejoin. Restoring: %*"):format(v1 or "nothing (idle)")))
		notifications:Send("Anti AFK: rejoining this server\226\128\166")
		v3 = true

		if v1 == "training" then
			local t = {
				afkRestore = "training",
				trainingTool = v22
			}

			v2 = t

			if not pcall(function() --[[ Line: 160 | Upvalues: TeleportService (ref), LocalPlayer (ref), t (copy) ]]
				TeleportService:TeleportToPlaceInstance(game.PlaceId, game.JobId, LocalPlayer, nil, t)
			end) then
				v3 = false
				pcall(function() --[[ Line: 152 | Upvalues: TeleportService (ref), LocalPlayer (ref), v2 (ref) ]]
					TeleportService:Teleport(game.PlaceId, LocalPlayer, v2)
				end)
			end
		elseif v1 == "fishing" then
			local t = {
				afkRestore = "fishing"
			}

			v2 = t

			if not pcall(function() --[[ Line: 160 | Upvalues: TeleportService (ref), LocalPlayer (ref), t (copy) ]]
				TeleportService:TeleportToPlaceInstance(game.PlaceId, game.JobId, LocalPlayer, nil, t)
			end) then
				v3 = false
				pcall(function() --[[ Line: 152 | Upvalues: TeleportService (ref), LocalPlayer (ref), v2 (ref) ]]
					TeleportService:Teleport(game.PlaceId, LocalPlayer, v2)
				end)
			end
		else
			v2 = nil

			local v32 = nil

			if pcall(function() --[[ Line: 160 | Upvalues: TeleportService (ref), LocalPlayer (ref), v32 (copy) ]]
				TeleportService:TeleportToPlaceInstance(game.PlaceId, game.JobId, LocalPlayer, nil, v32)
			end) then
				return
			end

			v3 = false
			pcall(function() --[[ Line: 152 | Upvalues: TeleportService (ref), LocalPlayer (ref), v2 (ref) ]]
				TeleportService:Teleport(game.PlaceId, LocalPlayer, v2)
			end)
		end
	end)

	local v4 = TeleportService:GetLocalPlayerTeleportData()
	local v5 = if typeof(v4) == "table" then v4.afkRestore else nil

	if v5 == "training" then
		task.spawn(restoreTraining, LocalPlayer, v4.trainingTool)
	elseif v5 == "fishing" then
		task.spawn(restoreFishing, LocalPlayer)
	else
		print("[Anti-AFK] No AFK teleport data to restore.")
	end

	local v6 = 0
	local v7 = 0

	task.spawn(function() --[[ Line: 234 | Upvalues: v1 (ref), v6 (ref), v7 (ref), currentActivity (copy), v2 (ref), v3 (ref), TeleportService (ref), LocalPlayer (copy) ]]
		while true do
			local v12

			repeat
				while true do
					task.wait(1)

					local v22 = os.clock() - v1

					if v22 < 2 then
						v6 = 0
						v7 = 0
					end

					local v32, _ = currentActivity()

					if if v32 == "training" then true else false then
						break
					end

					v6 = 0

					if if v32 == "fishing" then true else false then
						v7 = v7 + 1

						if v7 % 60 == 0 then
							print(string.format("Anti-AFK: Auto fishing active for %d min. Teleporting in %d min.", v7 / 60, (1140 - v7) / 60))
						end

						if not (v7 >= 1140) then
							continue
						end

						print("Anti-AFK: Timeout reached while auto fishing. Teleporting with restore data...")
						v12 = {
							afkRestore = "fishing"
						}
						v2 = v12
						v3 = true

						if not pcall(function() --[[ Line: 160 | Upvalues: TeleportService (ref), LocalPlayer (ref), v12 (copy) ]]
							TeleportService:TeleportToPlaceInstance(game.PlaceId, game.JobId, LocalPlayer, nil, v12)
						end) then
							v3 = false
							pcall(function() --[[ Line: 152 | Upvalues: TeleportService (ref), LocalPlayer (ref), v2 (ref) ]]
								TeleportService:Teleport(game.PlaceId, LocalPlayer, v2)
							end)
						end

						return
					end

					v7 = 0

					if v22 >= 1140 then
						print("Anti-AFK: Inactivity detected (" .. math.floor(v22) .. "s). Teleporting...")
						v2 = nil
						v3 = true

						local v62 = nil

						if not pcall(function() --[[ Line: 160 | Upvalues: TeleportService (ref), LocalPlayer (ref), v62 (copy) ]]
							TeleportService:TeleportToPlaceInstance(game.PlaceId, game.JobId, LocalPlayer, nil, v62)
						end) then
							v3 = false
							pcall(function() --[[ Line: 152 | Upvalues: TeleportService (ref), LocalPlayer (ref), v2 (ref) ]]
								TeleportService:Teleport(game.PlaceId, LocalPlayer, v2)
							end)
						end

						return
					end
				end

				v6 = v6 + 1
				v7 = 0

				if v6 % 60 ~= 0 then
					continue
				end

				print(string.format("Anti-AFK: Training active for %d min. Teleporting in %d min.", v6 / 60, (1140 - v6) / 60))
			until v6 >= 1140

			v7 = v7 + 1
			v6 = 0

			if v7 % 60 == 0 then
				print(string.format("Anti-AFK: Auto fishing active for %d min. Teleporting in %d min.", v7 / 60, (1140 - v7) / 60))
			end

			if v7 >= 1140 then
				print("Anti-AFK: Timeout reached while auto fishing. Teleporting with restore data...")
				v12 = {
					afkRestore = "fishing"
				}
				v2 = v12
				v3 = true

				if not pcall(function() --[[ Line: 160 | Upvalues: TeleportService (ref), LocalPlayer (ref), v12 (copy) ]]
					TeleportService:TeleportToPlaceInstance(game.PlaceId, game.JobId, LocalPlayer, nil, v12)
				end) then
					v3 = false
					pcall(function() --[[ Line: 152 | Upvalues: TeleportService (ref), LocalPlayer (ref), v2 (ref) ]]
						TeleportService:Teleport(game.PlaceId, LocalPlayer, v2)
					end)
				end

				return
			end
		end
	end)
end

return t