-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local Workspace = game:GetService("Workspace")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local RebirthUnlocksConfig = require(ReplicatedStorage.shared.config.RebirthUnlocksConfig)
local SFX = require(ReplicatedStorage.client.SFX)
local VFX = require(ReplicatedStorage.client.VFX)
local notifications = require(ReplicatedStorage.shared.module.notifications)
local setCharacterControlsEnabled = require(ReplicatedStorage.shared.util.setCharacterControlsEnabled)

local function waitForBannerToFinish(p1) --[[ waitForBannerToFinish | Line: 26 | Upvalues: RunService (copy) ]]
	local RebirthBanner = p1:FindFirstChild("RebirthBanner")
	local sum = 0

	while not RebirthBanner and sum < 2 do
		sum = sum + RunService.Heartbeat:Wait()
		RebirthBanner = p1:FindFirstChild("RebirthBanner")
	end

	if not RebirthBanner then
		return
	end

	local sum2 = 0

	while RebirthBanner.Parent and sum2 < 6 do
		sum2 = sum2 + RunService.Heartbeat:Wait()
	end
end

local t = {
	UECS = nil,
	Priority = 40
}

local function getRebirthLevel() --[[ getRebirthLevel | Line: 46 | Upvalues: ClientPlayerData (copy) ]]
	return ClientPlayerData.serverProfile:getState().rebirthLevel or 0
end

local function getAnchorPart(p1) --[[ getAnchorPart | Line: 51 ]]
	if p1:IsA("BasePart") then
		return p1
	end

	if not p1:IsA("Model") then
		return nil
	end

	return p1.PrimaryPart or p1:FindFirstChildWhichIsA("BasePart", true)
end

local function getFocusCFrame(p1) --[[ getFocusCFrame | Line: 60 ]]
	if p1:IsA("Model") then
		return p1:GetAttribute("OGPivot") or p1:GetPivot()
	end

	if p1:IsA("BasePart") then
		return p1.CFrame
	end

	return nil
end

local function getHeight(p1) --[[ getHeight | Line: 69 ]]
	if p1:IsA("Model") then
		return p1:GetExtentsSize().Y
	end

	if p1:IsA("BasePart") then
		return p1.Size.Y
	end

	return 4
end

function t.Init(p1) --[[ Init | Line: 78 | Upvalues: Players (copy), TweenService (copy), VFX (copy), ClientPlayerData (copy), RebirthUnlocksConfig (copy), Workspace (copy), RunService (copy), waitForBannerToFinish (copy), SFX (copy), setCharacterControlsEnabled (copy), notifications (copy) ]]
	local LocalPlayer = Players.LocalPlayer
	local MainUI = LocalPlayer.PlayerGui:WaitForChild("MainUI")
	local Rebirth = MainUI:WaitForChild("Rebirth")
	local v1 = false
	local t = {}

	local function removePadlock(p1) --[[ removePadlock | Line: 87 | Upvalues: t (copy) ]]
		local v1 = t[p1]

		if not v1 then
			return
		end

		v1:Destroy()
		t[p1] = nil
	end

	local function ensurePadlock(p1, p2) --[[ ensurePadlock | Line: 95 | Upvalues: t (copy) ]]
		local v1 = t[p1.Feature]

		if v1 then
			if v1.Parent then
				return
			end

			v1:Destroy()
			t[p1.Feature] = nil
		end

		local v2 = nil

		if p1.AnchorPartName then
			local v3 = p2:FindFirstChild(p1.AnchorPartName, true)

			if v3 and v3:IsA("BasePart") then
				v2 = v3
			end
		end

		if not v2 then
			v2 = if p2:IsA("BasePart") then p2 elseif p2:IsA("Model") then p2.PrimaryPart or p2:FindFirstChildWhichIsA("BasePart", true) else nil
		end

		if not v2 then
			return
		end

		local RebirthUnlockLock = Instance.new("BillboardGui")

		RebirthUnlockLock.Name = "RebirthUnlockLock"
		RebirthUnlockLock.Size = UDim2.fromScale(6, 2)
		RebirthUnlockLock.StudsOffset = Vector3.new(0, (if p2:IsA("Model") then p2:GetExtentsSize().Y elseif p2:IsA("BasePart") then p2.Size.Y else 4) * 0.5 + 3, 0)
		RebirthUnlockLock.AlwaysOnTop = true
		RebirthUnlockLock.MaxDistance = 120
		RebirthUnlockLock.Adornee = v2

		local TextLabel = Instance.new("TextLabel")

		TextLabel.Size = UDim2.fromScale(1, 1)
		TextLabel.BackgroundTransparency = 1
		TextLabel.Text = ("\240\159\148\146 Rebirth %*"):format(p1.RebirthRequired)
		TextLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
		TextLabel.Font = Enum.Font.GothamBlack
		TextLabel.TextScaled = true
		TextLabel.Parent = RebirthUnlockLock

		local UIStroke = Instance.new("UIStroke")

		UIStroke.Color = Color3.fromRGB(0, 0, 0)
		UIStroke.Thickness = 3
		UIStroke.Parent = TextLabel
		RebirthUnlockLock.Parent = v2
		t[p1.Feature] = RebirthUnlockLock
	end

	local t2 = {}

	local function setModelHidden(p1, p2, p3, p4) --[[ setModelHidden | Line: 154 | Upvalues: t2 (copy), TweenService (ref), VFX (ref) ]]
		local v1 = t2[p1]
		local v2 = if v1 == nil then false else true

		if not v1 then
			local v3 = p3:GetPivot()

			t2[p1] = v3
			p3:SetAttribute("OGPivot", v3)
			v1 = v3
		end

		if p4 then
			p3:PivotTo(v1 * CFrame.new(0, -p2, 0))
		else
			local v4 = if p3:GetAttribute("hidden") == nil then false else true
			local CFrameValue = Instance.new("CFrameValue")

			CFrameValue.Value = p3:GetPivot()
			CFrameValue.Changed:Connect(function() --[[ Line: 170 | Upvalues: p3 (copy), CFrameValue (copy) ]]
				p3:PivotTo(CFrameValue.Value)
			end)

			local v5 = TweenService:Create(CFrameValue, TweenInfo.new(3), {
				Value = v1
			})

			v5.Completed:Once(function() --[[ Line: 178 | Upvalues: CFrameValue (copy), v5 (copy), p3 (copy), v4 (copy), v2 (copy), VFX (ref) ]]
				CFrameValue:Destroy()
				v5:Destroy()

				if not p3:IsA("Model") or (not v4 or v2) then
					return
				end

				local v1, v22 = p3:GetBoundingBox()
				local Part = Instance.new("Part")

				Part.CanCollide = false
				Part.CanQuery = false
				Part.CanTouch = false
				Part.Anchored = true
				Part.CFrame = v1
				Part.Size = v22
				Part.Transparency = 1
				Part.Parent = workspace.CurrentCamera
				task.delay(5, function() --[[ Line: 192 | Upvalues: Part (copy) ]]
					Part:Destroy()
				end)
				VFX.new("RebirthUnlockEffect", Part)
			end)
			task.delay(3, function() --[[ Line: 199 | Upvalues: v5 (copy) ]]
				v5:Play()
			end)
		end

		p3:SetAttribute("hidden", p4)
	end

	local function applyLocks() --[[ applyLocks | Line: 208 | Upvalues: ClientPlayerData (ref), RebirthUnlocksConfig (ref), setModelHidden (copy), Workspace (ref), ensurePadlock (copy), t (copy), VFX (ref) ]]
		local v1 = ClientPlayerData.serverProfile:getState().rebirthLevel or 0

		for v2, v3 in RebirthUnlocksConfig.Unlocks do
			local v4 = v3.findModel()
			local v5 = v1 < v3.RebirthRequired
			local v6 = v3.HideStuds or 59

			if v4 then
				if v3.GateKind == "hideModel" then
					setModelHidden(v3.Feature, v6, v4, v5)

					for v8, v9 in v3.ExtraModelNames or {} do
						local v10 = Workspace:FindFirstChild(v9)

						if v10 then
							setModelHidden(("%*/%*"):format(v3.Feature, v9), v6, v10, v5)
						end
					end

					continue
				end

				if v5 then
					ensurePadlock(v3, v4)

					continue
				end

				if t[v3.Feature] then
					task.delay(3, function() --[[ Line: 230 | Upvalues: v4 (copy), VFX (ref) ]]
						local v1, v2 = v4:GetBoundingBox()
						local Part = Instance.new("Part")

						Part.CanCollide = false
						Part.CanQuery = false
						Part.CanTouch = false
						Part.Anchored = true
						Part.CFrame = v1
						Part.Size = v2
						Part.Transparency = 1
						Part.Parent = workspace.CurrentCamera
						task.delay(5, function() --[[ Line: 241 | Upvalues: Part (copy) ]]
							Part:Destroy()
						end)
						VFX.new("RebirthUnlockEffect", Part)
					end)
				end

				local Feature = v3.Feature
				local v11 = t[Feature]

				if v11 then
					v11:Destroy()
					t[Feature] = nil
				end

				continue
			end

			if not v5 then
				local Feature = v3.Feature
				local v12 = t[Feature]

				if v12 then
					v12:Destroy()
					t[Feature] = nil
				end
			end
		end
	end

	local function revealTarget(p1) --[[ revealTarget | Line: 262 | Upvalues: v1 (ref), LocalPlayer (copy), Rebirth (copy), RunService (ref), waitForBannerToFinish (ref), RebirthUnlocksConfig (ref), SFX (ref), Workspace (ref), MainUI (copy), setCharacterControlsEnabled (ref), notifications (ref), TweenService (ref) ]]
		if v1 then
			return
		end

		local v12 = p1.findModel()
		local v2 = v12 and (if v12:IsA("Model") then v12:GetAttribute("OGPivot") or v12:GetPivot() elseif v12:IsA("BasePart") then v12.CFrame else nil)

		if not (v12 and v2) then
			return
		end

		local Character = LocalPlayer.Character

		if not (Character and Character:FindFirstChildOfClass("Humanoid")) then
			return
		end

		v1 = true

		local sum = 0

		while Rebirth.Visible and sum < 5 do
			sum = sum + RunService.Heartbeat:Wait()
		end

		waitForBannerToFinish(LocalPlayer.PlayerGui)
		task.wait(RebirthUnlocksConfig.RevealDelayAfterClose)
		SFX.PlayTemplate("RebirthUnlock")

		local CurrentCamera = Workspace.CurrentCamera
		local HUD = MainUI:FindFirstChild("HUD")

		setCharacterControlsEnabled(false)

		if HUD then
			HUD.Visible = false
		end

		CurrentCamera.CameraType = Enum.CameraType.Scriptable
		notifications:Send(p1.UnlockedText)
		pcall(function() --[[ Line: 301 | Upvalues: v2 (copy), p1 (copy), TweenService (ref), CurrentCamera (copy), RebirthUnlocksConfig (ref) ]]
			local v1 = CFrame.lookAt((v2 * CFrame.new(p1.CameraOffset)).Position, v2.Position)

			TweenService:Create(CurrentCamera, TweenInfo.new(RebirthUnlocksConfig.TweenTime, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
				CFrame = v1
			}):Play()
			task.wait(RebirthUnlocksConfig.TweenTime + RebirthUnlocksConfig.HoldTime)
		end)
		CurrentCamera.CameraType = Enum.CameraType.Custom

		if HUD then
			HUD.Visible = true
		end

		setCharacterControlsEnabled(true)
		v1 = false
	end

	applyLocks()
	Workspace.ChildAdded:Connect(function(p1) --[[ Line: 323 | Upvalues: RebirthUnlocksConfig (ref), applyLocks (copy) ]]
		for v1, v2 in RebirthUnlocksConfig.Unlocks do
			if p1.Name == v2.ModelName then
				task.defer(applyLocks)

				return
			end

			local find = table.find

			if find(v2.ExtraModelNames or {}, p1.Name) then
				task.defer(applyLocks)

				return
			end
		end
	end)

	local v2 = ClientPlayerData.serverProfile:getState().rebirthLevel or 0

	ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 333 ]]
		return p1.rebirthLevel
	end, function(p1) --[[ Line: 335 | Upvalues: applyLocks (copy), v2 (ref), RebirthUnlocksConfig (ref), revealTarget (copy) ]]
		applyLocks()

		if not (v2 < p1) then
			v2 = p1

			return
		end

		v2 = p1

		for v1, v22 in RebirthUnlocksConfig.Unlocks do
			if v22.RebirthRequired == p1 then
				task.spawn(revealTarget, v22)

				return
			end
		end
	end)
end

return t