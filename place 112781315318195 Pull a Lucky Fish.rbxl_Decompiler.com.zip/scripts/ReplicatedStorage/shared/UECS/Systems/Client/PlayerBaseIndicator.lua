-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local CashDisplay = require(ReplicatedStorage.shared.module.CashDisplay)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local UECS = require(ReplicatedStorage.shared.UECS.UECS)
local PlayerBaseIndicator = ReplicatedStorage.shared.model.PlayerBaseIndicator
local HeadShot = Enum.ThumbnailType.HeadShot
local Size150x150 = Enum.ThumbnailSize.Size150x150
local v1 = TweenInfo.new(0.35, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
local v2 = TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
local t = {
	UECS = nil
}

function t.Init(p1) --[[ Init | Line: 41 | Upvalues: t (copy), Players (copy), TweenService (copy), v1 (copy), v2 (copy), CashDisplay (copy), PlayerBaseIndicator (copy), HeadShot (copy), Size150x150 (copy), UECS (copy), RunService (copy) ]]
	local v12 = assert(t.UECS, "UECS not initialized")
	local LocalPlayer = Players.LocalPlayer
	local PlayerGui = LocalPlayer:WaitForChild("PlayerGui")
	local t2 = {}

	local function setVisible(p1, p2) --[[ setVisible | Line: 49 | Upvalues: TweenService (ref), v1 (ref), v2 (ref) ]]
		if p1.visible == p2 then
			return
		end

		p1.visible = p2

		if p1.scaleTween then
			p1.scaleTween:Cancel()
		end

		if p2 then
			p1.gui.Enabled = true
			p1.scaleTween = TweenService:Create(p1.scale, v1, {
				Scale = 1
			})
			p1.scaleTween:Play()
		else
			p1.scaleTween = TweenService:Create(p1.scale, v2, {
				Scale = 0
			})
			p1.scaleTween:Play()
			p1.scaleTween.Completed:Once(function(p12) --[[ Line: 65 | Upvalues: p1 (copy) ]]
				if p12 ~= Enum.PlaybackState.Completed or p1.visible then
					return
				end

				p1.gui.Enabled = false
			end)
		end
	end

	local function refreshCash(p1) --[[ refreshCash | Line: 75 | Upvalues: CashDisplay (ref) ]]
		local v1 = p1.owner:GetAttribute("BaseEarningsPerSecond")

		if type(v1) == "number" then
			p1.cashFrame.Visible = true
			CashDisplay.applyToLabel(p1.counter, v1, {
				Suffix = "/s",
				Compact = true
			})
		else
			p1.cashFrame.Visible = false
		end
	end

	local function destroyBinding(p1) --[[ destroyBinding | Line: 85 | Upvalues: t2 (copy) ]]
		local v1 = t2[p1]

		if not v1 then
			return
		end

		t2[p1] = nil

		if v1.attrConn then
			v1.attrConn:Disconnect()
		end

		if v1.scaleTween then
			v1.scaleTween:Cancel()
		end

		v1.gui:Destroy()
	end

	local function buildBinding(p1, p2, p3) --[[ buildBinding | Line: 100 | Upvalues: PlayerBaseIndicator (ref), t2 (copy), Players (ref), HeadShot (ref), Size150x150 (ref), refreshCash (copy), PlayerGui (copy) ]]
		local PlayerBaseIndicator2 = PlayerBaseIndicator:Clone()

		PlayerBaseIndicator2.Name = "PlayerBaseIndicator"
		PlayerBaseIndicator2.Adornee = p3
		PlayerBaseIndicator2.Enabled = false

		local Size = PlayerBaseIndicator2.Size

		PlayerBaseIndicator2.Size = UDim2.new(Size.X.Scale * 2, Size.X.Offset * 2, Size.Y.Scale * 2, Size.Y.Offset * 2)

		local Frame = PlayerBaseIndicator2:FindFirstChild("Frame")
		local UIScale = Instance.new("UIScale")

		UIScale.Scale = 0
		UIScale.Parent = Frame
		Frame:FindFirstChild("Nickname").Text = p2.DisplayName

		local Cash = Frame:FindFirstChild("Cash")
		local t = {
			visible = false,
			gui = PlayerBaseIndicator2,
			scale = UIScale,
			cashFrame = Cash,
			counter = Cash:FindFirstChild("Counter"),
			anchor = p3,
			owner = p2
		}

		t2[p1] = t
		task.spawn(function() --[[ Line: 139 | Upvalues: Players (ref), p2 (copy), HeadShot (ref), Size150x150 (ref), Frame (copy), t2 (ref), p1 (copy), t (copy) ]]
			local ok, result = pcall(function() --[[ Line: 140 | Upvalues: Players (ref), p2 (ref), HeadShot (ref), Size150x150 (ref) ]]
				return Players:GetUserThumbnailAsync(p2.UserId, HeadShot, Size150x150)
			end)
			local AvatarIcon = Frame:FindFirstChild("AvatarIcon")

			if not ok or (not AvatarIcon or t2[p1] ~= t) then
				return
			end

			AvatarIcon.Image = result
		end)
		refreshCash(t)
		t.attrConn = p2:GetAttributeChangedSignal("BaseEarningsPerSecond"):Connect(function() --[[ Line: 150 | Upvalues: t2 (ref), p1 (copy), t (copy), refreshCash (ref) ]]
			if t2[p1] ~= t then
				return
			end

			refreshCash(t)
		end)
		PlayerBaseIndicator2.Parent = PlayerGui

		return t
	end

	local function resolveAnchor(p1) --[[ resolveAnchor | Line: 160 ]]
		local Entity = p1.Entity

		if typeof(Entity) ~= "Instance" then
			return nil
		end

		local FloorSpawn = Entity:FindFirstChild("FloorSpawn")

		if FloorSpawn and FloorSpawn:IsA("BasePart") then
			return FloorSpawn
		end

		return nil
	end

	local function refreshOwnership(p1) --[[ refreshOwnership | Line: 171 | Upvalues: LocalPlayer (copy), t2 (copy), buildBinding (copy) ]]
		local v1 = p1.Owner:Get()
		local v2 = if typeof(v1) == "Instance" then v1:IsA("Player") and (if v1 == LocalPlayer then false elseif v1.Parent == nil then false else true) else false
		local v3 = t2[p1]

		if v2 then
			if v3 then
				if v3.owner == v1 then
					return
				end

				local v4 = t2[p1]

				if v4 then
					t2[p1] = nil

					if v4.attrConn then
						v4.attrConn:Disconnect()
					end

					if v4.scaleTween then
						v4.scaleTween:Cancel()
					end

					v4.gui:Destroy()
				end
			end

			local Entity = p1.Entity
			local v5

			if typeof(Entity) == "Instance" then
				local FloorSpawn = Entity:FindFirstChild("FloorSpawn")

				v5 = if FloorSpawn and FloorSpawn:IsA("BasePart") then FloorSpawn else nil
			else
				v5 = nil
			end

			if v5 then
				buildBinding(p1, v1, v5)
			end
		else
			if not v3 then
				return
			end

			local v6 = t2[p1]

			if not v6 then
				return
			end

			t2[p1] = nil

			if v6.attrConn then
				v6.attrConn:Disconnect()
			end

			if v6.scaleTween then
				v6.scaleTween:Cancel()
			end

			v6.gui:Destroy()
		end
	end

	local function watch(p1) --[[ watch | Line: 198 | Upvalues: refreshOwnership (copy) ]]
		p1.Owner.OnChange:Connect(function() --[[ Line: 199 | Upvalues: refreshOwnership (ref), p1 (copy) ]]
			refreshOwnership(p1)
		end)
		refreshOwnership(p1)
	end

	for v22, v3 in v12:GetComponents("TycoonComponent") do
		v3.Owner.OnChange:Connect(function() --[[ Line: 199 | Upvalues: refreshOwnership (copy), v3 (copy) ]]
			refreshOwnership(v3)
		end)
		refreshOwnership(v3)
	end

	UECS.OnComponentCreated("TycoonComponent"):Connect(watch)
	RunService.Heartbeat:Connect(function() --[[ Line: 213 | Upvalues: LocalPlayer (copy), t2 (copy), setVisible (copy) ]]
		debug.profilebegin("UECS/PlayerBaseIndicator.Heartbeat")

		local Character = LocalPlayer.Character
		local v1 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character
		local v2 = if v1 and v1:IsA("BasePart") then v1 else nil

		for v3, v4 in t2 do
			if v4.owner.Parent == nil or v4.anchor.Parent == nil then
				local v5 = t2[v3]

				if v5 then
					t2[v3] = nil

					if v5.attrConn then
						v5.attrConn:Disconnect()
					end

					if v5.scaleTween then
						v5.scaleTween:Cancel()
					end

					v5.gui:Destroy()
				end

				continue
			end

			if v2 then
				setVisible(v4, (v2.Position - v4.anchor.Position).Magnitude > 50)

				continue
			end

			setVisible(v4, false)
		end

		debug.profileend()
	end)
end

return t