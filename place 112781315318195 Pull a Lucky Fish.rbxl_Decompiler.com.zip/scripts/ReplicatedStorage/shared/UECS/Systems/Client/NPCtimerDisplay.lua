-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)

require(ReplicatedStorage.shared.UECS.GlobalTypes)

local NPCtradesConfig = require(ReplicatedStorage.shared.config.NPCtradesConfig)
local TutorialConfig = require(ReplicatedStorage.shared.config.TutorialConfig)
local convertTimeMS = require(ReplicatedStorage.shared.util.convertTimeMS)
local Spawning = NPCtradesConfig.NPCtrades.Spawning
local MaxConcurrent = Spawning.MaxConcurrent
local IntervalSeconds = Spawning.IntervalSeconds
local Enabled = NPCtradesConfig.NPCtrades.Enabled
local v1 = #TutorialConfig + 1

local function localPlayerInTutorial() --[[ localPlayerInTutorial | Line: 36 | Upvalues: ClientPlayerData (copy), v1 (copy) ]]
	local tutorialInfo = ClientPlayerData.serverProfile:getState().tutorialInfo

	return if tutorialInfo == nil then false else tutorialInfo.tutorialStep < v1
end

local t = {
	UECS = nil
}
local t2 = {}
local v2 = 0
local v3 = 0

local function applyNpcTrade(p1) --[[ applyNpcTrade | Line: 55 | Upvalues: v2 (ref), v3 (ref) ]]
	v2 = p1 and p1.count or 0
	v3 = if p1 then p1.lastArrival or 0 else 0
end

local function setupPart(p1) --[[ setupPart | Line: 60 | Upvalues: t2 (copy) ]]
	local v1 = p1:FindFirstChildWhichIsA("BillboardGui")

	if not v1 then
		warn("[NPCtimerDisplay] No BillboardGui on", p1:GetFullName())

		return
	end

	local TextUp = v1:FindFirstChild("TextUp")

	if TextUp and TextUp:IsA("TextLabel") then
		table.insert(t2, {
			billboard = v1,
			label = TextUp
		})
	else
		warn("[NPCtimerDisplay] No TextUp TextLabel in BillboardGui on", p1:GetFullName())
	end
end

local function hidePart(p1) --[[ hidePart | Line: 78 ]]
	local v1 = p1:FindFirstChildWhichIsA("BillboardGui")

	if not v1 then
		return
	end

	v1.Enabled = false
end

function t.Init(p1) --[[ Init | Line: 85 | Upvalues: Enabled (copy), CollectionService (copy), hidePart (copy), setupPart (copy), ClientPlayerData (copy), v2 (ref), v3 (ref), applyNpcTrade (copy), RunService (copy), t2 (copy), MaxConcurrent (copy), v1 (copy), IntervalSeconds (copy), convertTimeMS (copy) ]]
	if Enabled then
		for v12, v22 in CollectionService:GetTagged("NPCtimer") do
			task.spawn(setupPart, v22)
		end

		CollectionService:GetInstanceAddedSignal("NPCtimer"):Connect(function(p1) --[[ Line: 99 | Upvalues: setupPart (ref) ]]
			task.spawn(setupPart, p1)
		end)

		local npcTrade = ClientPlayerData.serverProfile:getState().npcTrade

		v2 = npcTrade and npcTrade.count or 0
		v3 = if npcTrade then npcTrade.lastArrival or 0 else 0
		ClientPlayerData.serverProfile:subscribe(function(p1) --[[ Line: 106 ]]
			return p1.npcTrade
		end, applyNpcTrade)

		local v5 = 0

		RunService.Heartbeat:Connect(function(p1) --[[ Line: 111 | Upvalues: v5 (ref), t2 (ref), v2 (ref), MaxConcurrent (ref), ClientPlayerData (ref), v1 (ref), v3 (ref), IntervalSeconds (ref), convertTimeMS (ref) ]]
			v5 = v5 + p1

			if v5 < 1 then
				return
			end

			v5 = 0

			if #t2 == 0 then
				return
			end

			local v12

			if MaxConcurrent <= v2 then
				v12 = true
			else
				local tutorialInfo = ClientPlayerData.serverProfile:getState().tutorialInfo

				v12 = if tutorialInfo == nil then false else tutorialInfo.tutorialStep < v1
			end

			local v22 = if v12 then "" else "Next Client: " .. convertTimeMS(if v3 > 0 then math.max(0, v3 + IntervalSeconds - os.time()) else IntervalSeconds, false)

			for v52, v6 in t2 do
				if v6.billboard.Parent then
					v6.billboard.Enabled = not v12

					if not v12 then
						v6.label.Text = v22
					end
				end
			end
		end)
	else
		for v6, v7 in CollectionService:GetTagged("NPCtimer") do
			local v8 = v7:FindFirstChildWhichIsA("BillboardGui")

			if v8 then
				v8.Enabled = false
			end
		end

		CollectionService:GetInstanceAddedSignal("NPCtimer"):Connect(hidePart)
	end
end

return t