-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

require(ReplicatedStorage.shared.UECS.GlobalTypes)
require(ReplicatedStorage.shared.UECS.Components.WalkableUI)

local characterInsidePart = require(ReplicatedStorage.shared.util.characterInsidePart)

return {
	UECS = nil,
	Priority = 50,
	Init = function(p1) --[[ Init | Line: 11 | Upvalues: RunService (copy), characterInsidePart (copy) ]]
		local function HookWalkable(p12) --[[ HookWalkable | Line: 15 | Upvalues: RunService (ref), characterInsidePart (ref), p1 (copy) ]]
			if p12.Entity and p12.Entity:IsA("BasePart") then
				local Entity = p12.Entity
				local v1 = false

				RunService.Heartbeat:Connect(function() --[[ Line: 22 | Upvalues: characterInsidePart (ref), Entity (copy), v1 (ref), p12 (copy), p1 (ref) ]]
					debug.profilebegin("UECS/WalkableUI.Heartbeat")

					local v12 = characterInsidePart(Entity)

					if v12 and not v1 then
						local v22 = p12.UIComponentName:Get()

						if type(v22) == "string" then
							local v32 = p1.UECS:WaitForAnyComponent(v22, 5)

							if v32 then
								local v4 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

								if v4.OpenedUIComponent:Get() ~= v32 then
									v4.OpenedUIComponent:Set(v32)
								end
							end
						end
					elseif not v12 and v1 then
						local v5 = p12.UIComponentName:Get()

						if type(v5) == "string" then
							local v6 = p1.UECS:WaitForAnyComponent(v5, 5)

							if v6 then
								local v7 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

								if v7.OpenedUIComponent:Get() == v6 then
									v7.OpenedUIComponent:Set(nil)
								end
							end
						end
					end

					v1 = v12
					debug.profileend()
				end)
			end
		end

		for v1, v2 in p1.UECS:GetComponents("WalkableUI") do
			if v2.Entity and v2.Entity:IsA("BasePart") then
				local Entity = v2.Entity
				local v3 = false

				RunService.Heartbeat:Connect(function() --[[ Line: 22 | Upvalues: characterInsidePart (ref), Entity (copy), v3 (ref), v2 (copy), p1 (copy) ]]
					debug.profilebegin("UECS/WalkableUI.Heartbeat")

					local v12 = characterInsidePart(Entity)

					if v12 and not v3 then
						local v22 = v2.UIComponentName:Get()

						if type(v22) == "string" then
							local v32 = p1.UECS:WaitForAnyComponent(v22, 5)

							if v32 then
								local v4 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

								if v4.OpenedUIComponent:Get() ~= v32 then
									v4.OpenedUIComponent:Set(v32)
								end
							end
						end
					elseif not v12 and v3 then
						local v5 = v2.UIComponentName:Get()

						if type(v5) == "string" then
							local v6 = p1.UECS:WaitForAnyComponent(v5, 5)

							if v6 then
								local v7 = p1.UECS:WaitForAnyComponent("UIFrameOpener")

								if v7.OpenedUIComponent:Get() == v6 then
									v7.OpenedUIComponent:Set(nil)
								end
							end
						end
					end

					v3 = v12
					debug.profileend()
				end)
			end
		end

		p1.UECS.OnComponentCreated("WalkableUI"):Connect(HookWalkable)
	end
}