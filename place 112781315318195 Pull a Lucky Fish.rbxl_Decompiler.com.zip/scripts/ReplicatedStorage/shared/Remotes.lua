-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local RunService, Guard, Red, pass, t

do
	local ReplicatedStorage = game:GetService("ReplicatedStorage")

	RunService = game:GetService("RunService")
	Guard = require(ReplicatedStorage.package.Guard)
	Red = require(ReplicatedStorage.package.Red)
	pass = function(...) --[[ pass | Line: 16 ]]
		return ...
	end

	local function struct(p1) --[[ struct | Line: 22 ]]
		return function(p13) --[[ Line: 23 | Upvalues: p1 (copy) ]]
			assert(type(p13) == "table", "payload must be a table")

			for v2, v3 in p1 do
				v3(p13[v2])
			end

			return p13
		end
	end

	local function event(p1, p2) --[[ event | Line: 37 | Upvalues: Red (copy), pass (copy), RunService (copy) ]]
		local v3 = Red.Event(p1, if p2 then p2 else pass)

		if RunService:IsServer() then
			return v3:Server()
		end

		return v3:Client()
	end

	local function func(p1, p2) --[[ func | Line: 49 | Upvalues: Red (copy), pass (copy) ]]
		return Red.Function(p1, if p2 then p2 else pass, pass)
	end

	t = {}

	local v1 = Red.Event("ReplicateToClient", pass)

	t.ReplicateToClient = if RunService:IsServer() then v1:Server() else v1:Client()

	local v5 = Red.Event("ClientUECSReady", pass)

	t.ClientUECSReady = if RunService:IsServer() then v5:Server() else v5:Client()

	local v9 = Red.Event("AcceptClientChanges", (function(p1) --[[ Line: 59 | Upvalues: Guard (copy) ]]
		assert(type(p1) == "table", "payload must be a table")
		Guard.String(p1.Type)

		if p1.Type == "Create" then
			Guard.String(p1.Name)
			Guard.String(p1.EntityId)
			assert(type(p1.Properties) == "table", "Properties must be a table")
		else
			if p1.Type == "PropertyChange" then
				Guard.String(p1.PropertyName)

				return p1
			end

			assert(p1.Type == "Destroy", "unknown payload Type")
		end

		return p1
	end) or pass)

	t.AcceptClientChanges = if RunService:IsServer() then v9:Server() else v9:Client()
	t.GetPlayerData = Red.Function("GetPlayerData", pass, pass)

	local v13 = Red.Event("ReplicateStore", (function(p1) --[[ Line: 76 | Upvalues: Guard (copy) ]]
		assert(type(p1) == "table", "payload must be a table")
		Guard.String(p1.name)
		assert(type(p1.arguments) == "table", "arguments must be a table")

		return p1
	end) or pass)

	t.ReplicateStore = if RunService:IsServer() then v13:Server() else v13:Client()

	local v17 = Red.Event("Train", pass)

	t.Train = if RunService:IsServer() then v17:Server() else v17:Client()
	t.ThrowData = Red.Function("ThrowData", (function(p1, p2) --[[ Line: 85 | Upvalues: Guard (copy) ]]
		return Guard.Number(p1), Guard.Optional(Guard.Number)(p2)
	end) or pass, pass)
	t.GetFishToRecive = Red.Function("GetFishToRecive", pass, pass)
	t.UseFreeRevive = Red.Function("UseFreeRevive", pass, pass)

	local t2 = {
		ConfigName = Guard.String,
		BaseSlotIndexName = Guard.String
	}
	local v21 = Red.Event("RequestPlaceFish", (function(p13) --[[ Line: 23 | Upvalues: t2 (copy) ]]
		assert(type(p13) == "table", "payload must be a table")

		for v2, v3 in t2 do
			v3(p13[v2])
		end

		return p13
	end) or pass)

	t.RequestPlaceFish = if RunService:IsServer() then v21:Server() else v21:Client()

	local v25 = Red.Event("RequestUpgradeFish", Guard.String or pass)

	t.RequestUpgradeFish = if RunService:IsServer() then v25:Server() else v25:Client()

	local v29 = Red.Event("ClaimOfflineMoney", pass)

	t.ClaimOfflineMoney = if RunService:IsServer() then v29:Server() else v29:Client()

	local v33 = Red.Event("FriendBoostRecalculate", pass)

	t.FriendBoostRecalculate = if RunService:IsServer() then v33:Server() else v33:Client()

	local v37 = Red.Event("BuyTrainingTool", Guard.String or pass)

	t.BuyTrainingTool = if RunService:IsServer() then v37:Server() else v37:Client()

	local v41 = Red.Event("EquipTrainingTool", Guard.String or pass)

	t.EquipTrainingTool = if RunService:IsServer() then v41:Server() else v41:Client()

	local v45 = Red.Event("RequestUpgradePullSpeed", pass)

	t.RequestUpgradePullSpeed = if RunService:IsServer() then v45:Server() else v45:Client()

	local v49 = Red.Event("RequestUpgradeThrowSpeed", pass)

	t.RequestUpgradeThrowSpeed = if RunService:IsServer() then v49:Server() else v49:Client()

	local v53 = Red.Event("RequestUpgradeRollSpeed", pass)

	t.RequestUpgradeRollSpeed = if RunService:IsServer() then v53:Server() else v53:Client()

	local t3 = {
		EnchantId = Guard.String,
		Method = Guard.String,
		ExtraGems = Guard.Optional(Guard.Number)
	}

	t.RequestEnchantRoll = Red.Function("RequestEnchantRoll", (function(p13) --[[ Line: 23 | Upvalues: t3 (copy) ]]
		assert(type(p13) == "table", "payload must be a table")

		for v2, v3 in t3 do
			v3(p13[v2])
		end

		return p13
	end) or pass, pass)

	local v57 = Red.Event("EnchantRollResult", pass)

	t.EnchantRollResult = if RunService:IsServer() then v57:Server() else v57:Client()

	local v61 = Red.Event("EnchantTrainingProc", pass)

	t.EnchantTrainingProc = if RunService:IsServer() then v61:Server() else v61:Client()

	local v65 = Red.Event("RequestBuySlotUpgrade", pass)

	t.RequestBuySlotUpgrade = if RunService:IsServer() then v65:Server() else v65:Client()

	local v69 = Red.Event("SellFish", Guard.String or pass)

	t.SellFish = if RunService:IsServer() then v69:Server() else v69:Client()

	local v73 = Red.Event("SellAllFish", pass)

	t.SellAllFish = if RunService:IsServer() then v73:Server() else v73:Client()

	local v77 = Red.Event("RequestRebirth", pass)

	t.RequestRebirth = if RunService:IsServer() then v77:Server() else v77:Client()

	local v81 = Red.Event("RequestFreeGiftClaim", pass)

	t.RequestFreeGiftClaim = if RunService:IsServer() then v81:Server() else v81:Client()

	local v85 = Red.Event("Notification", pass)

	t.Notification = if RunService:IsServer() then v85:Server() else v85:Client()

	local v89 = Red.Event("SimulateAntiAfkRejoin", pass)

	t.SimulateAntiAfkRejoin = if RunService:IsServer() then v89:Server() else v89:Client()

	local v93 = Red.Event("AdminMessage", pass)

	t.AdminMessage = if RunService:IsServer() then v93:Server() else v93:Client()

	local v97 = Red.Event("ActiveEventsReplicate", pass)

	t.ActiveEventsReplicate = if RunService:IsServer() then v97:Server() else v97:Client()
	t.OpenLuckyblock = Red.Function("OpenLuckyblock", Guard.String or pass, pass)

	local v101 = Red.Event("ClaimLuckyblockFish", Guard.String or pass)

	t.ClaimLuckyblockFish = if RunService:IsServer() then v101:Server() else v101:Client()

	local v105 = Red.Event("ShowCollectFX", pass)

	t.ShowCollectFX = if RunService:IsServer() then v105:Server() else v105:Client()

	local v109 = Red.Event("RequestCollectCash", Guard.String or pass)

	t.RequestCollectCash = if RunService:IsServer() then v109:Server() else v109:Client()

	local v113 = Red.Event("ShowClickBonus", pass)

	t.ShowClickBonus = if RunService:IsServer() then v113:Server() else v113:Client()

	local v117 = Red.Event("ClaimClickBonus", Guard.String or pass)

	t.ClaimClickBonus = if RunService:IsServer() then v117:Server() else v117:Client()

	local v121 = Red.Event("StreakChanged", pass)

	t.StreakChanged = if RunService:IsServer() then v121:Server() else v121:Client()

	local v125 = Red.Event("PlaySFX", pass)

	t.PlaySFX = if RunService:IsServer() then v125:Server() else v125:Client()

	local v129 = Red.Event("PromptStealPurchase", pass)

	t.PromptStealPurchase = if RunService:IsServer() then v129:Server() else v129:Client()

	local v133 = Red.Event("ShowUpgradeFX", pass)

	t.ShowUpgradeFX = if RunService:IsServer() then v133:Server() else v133:Client()

	local v137 = Red.Event("ShowPlaceFX", pass)

	t.ShowPlaceFX = if RunService:IsServer() then v137:Server() else v137:Client()

	local v141 = Red.Event("ShowGardenBuildFX", pass)

	t.ShowGardenBuildFX = if RunService:IsServer() then v141:Server() else v141:Client()

	local v145 = Red.Event("SendFeedback", Guard.String or pass)

	t.SendFeedback = if RunService:IsServer() then v145:Server() else v145:Client()

	local v150 = Red.Event("RequestGiftFish", Guard.Instance or pass)

	t.RequestGiftFish = if RunService:IsServer() then v150:Server() else v150:Client()

	local v154 = Red.Event("OfferGiftFish", pass)

	t.OfferGiftFish = if RunService:IsServer() then v154:Server() else v154:Client()

	local t4 = {
		GiftId = Guard.String,
		Accept = Guard.Boolean
	}
	local v158 = Red.Event("RespondGiftFish", (function(p13) --[[ Line: 23 | Upvalues: t4 (copy) ]]
		assert(type(p13) == "table", "payload must be a table")

		for v2, v3 in t4 do
			v3(p13[v2])
		end

		return p13
	end) or pass)

	t.RespondGiftFish = if RunService:IsServer() then v158:Server() else v158:Client()
	t.CastVote = Red.Function("CastVote", (function(p1, p2) --[[ Line: 160 | Upvalues: Guard (copy) ]]
		return Guard.String(p1), Guard.Number(p2)
	end) or pass, pass)

	local v162 = Red.Event("LuckActivatedFX", pass)

	t.LuckActivatedFX = if RunService:IsServer() then v162:Server() else v162:Client()

	local v166 = Red.Event("MutationThrowFX", pass)

	t.MutationThrowFX = if RunService:IsServer() then v166:Server() else v166:Client()

	local v170 = Red.Event("RequestSummonWeather", Guard.String or pass)

	t.RequestSummonWeather = if RunService:IsServer() then v170:Server() else v170:Client()

	local v174 = Red.Event("RequestPurchaseDailyReward", Guard.String or pass)

	t.RequestPurchaseDailyReward = if RunService:IsServer() then v174:Server() else v174:Client()

	local v178 = Red.Event("RequestClaimIndexReward", Guard.String or pass)

	t.RequestClaimIndexReward = if RunService:IsServer() then v178:Server() else v178:Client()

	local v182 = Red.Event("RequestClaimIndexMilestone", Guard.String or pass)

	t.RequestClaimIndexMilestone = if RunService:IsServer() then v182:Server() else v182:Client()

	local v186 = Red.Event("RequestClaimMilestone", Guard.String or pass)

	t.RequestClaimMilestone = if RunService:IsServer() then v186:Server() else v186:Client()

	local v190 = Red.Event("RequestClaimQuest", Guard.String or pass)

	t.RequestClaimQuest = if RunService:IsServer() then v190:Server() else v190:Client()

	local v194 = Red.Event("RequestSkipQuest", Guard.String or pass)

	t.RequestSkipQuest = if RunService:IsServer() then v194:Server() else v194:Client()

	local v198 = Red.Event("RequestClaimQuestMilestone", Guard.Number or pass)

	t.RequestClaimQuestMilestone = if RunService:IsServer() then v198:Server() else v198:Client()

	local v202 = Red.Event("BuyFishRod", Guard.String or pass)

	t.BuyFishRod = if RunService:IsServer() then v202:Server() else v202:Client()

	local v206 = Red.Event("EquipFishRod", Guard.String or pass)

	t.EquipFishRod = if RunService:IsServer() then v206:Server() else v206:Client()

	local v210 = Red.Event("BuyDecoration", Guard.String or pass)

	t.BuyDecoration = if RunService:IsServer() then v210:Server() else v210:Client()

	local v214 = Red.Event("ReplicateDecorationsStore", pass)

	t.ReplicateDecorationsStore = if RunService:IsServer() then v214:Server() else v214:Client()

	local v218 = Red.Event("RequestDecorationsStoreState", pass)

	t.RequestDecorationsStoreState = if RunService:IsServer() then v218:Server() else v218:Client()

	local v222 = Red.Event("BuyDecorationsStoreItem", Guard.String or pass)

	t.BuyDecorationsStoreItem = if RunService:IsServer() then v222:Server() else v222:Client()

	local v226 = Red.Event("RequestClaimBaseSkin", Guard.String or pass)

	t.RequestClaimBaseSkin = if RunService:IsServer() then v226:Server() else v226:Client()

	local v230 = Red.Event("RequestEquipBaseSkin", Guard.String or pass)

	t.RequestEquipBaseSkin = if RunService:IsServer() then v230:Server() else v230:Client()

	local v234 = Red.Event("RequestToggleMount", pass)

	t.RequestToggleMount = if RunService:IsServer() then v234:Server() else v234:Client()

	local v238 = Red.Event("RequestEquipMount", Guard.String or pass)

	t.RequestEquipMount = if RunService:IsServer() then v238:Server() else v238:Client()

	local v242 = Red.Event("RequestUsePotion", pass)

	t.RequestUsePotion = if RunService:IsServer() then v242:Server() else v242:Client()

	local v246 = Red.Event("PotionDrunk", pass)

	t.PotionDrunk = if RunService:IsServer() then v246:Server() else v246:Client()

	local v250 = Red.Event("PotionDowngradeWarning", pass)

	t.PotionDowngradeWarning = if RunService:IsServer() then v250:Server() else v250:Client()

	local t5 = {
		ConfigName = Guard.String,
		Confirmed = Guard.Boolean
	}
	local v254 = Red.Event("ConfirmPotionDowngrade", (function(p13) --[[ Line: 23 | Upvalues: t5 (copy) ]]
		assert(type(p13) == "table", "payload must be a table")

		for v2, v3 in t5 do
			v3(p13[v2])
		end

		return p13
	end) or pass)

	t.ConfirmPotionDowngrade = if RunService:IsServer() then v254:Server() else v254:Client()

	local v258 = Red.Event("ReplicatePotionEffects", pass)

	t.ReplicatePotionEffects = if RunService:IsServer() then v258:Server() else v258:Client()

	local v262 = Red.Event("RequestPotionSnapshot", pass)

	t.RequestPotionSnapshot = if RunService:IsServer() then v262:Server() else v262:Client()

	local v267 = Red.Event("RequestGiftPotion", Guard.Instance or pass)

	t.RequestGiftPotion = if RunService:IsServer() then v267:Server() else v267:Client()

	local v271 = Red.Event("OfferGiftPotion", pass)

	t.OfferGiftPotion = if RunService:IsServer() then v271:Server() else v271:Client()

	local v275 = Red.Event("RespondGiftPotion", pass)

	t.RespondGiftPotion = if RunService:IsServer() then v275:Server() else v275:Client()

	local v279 = Red.Event("RequestClaimDailyLogin", pass)

	t.RequestClaimDailyLogin = if RunService:IsServer() then v279:Server() else v279:Client()

	local v283 = Red.Event("RequestUseAutoCollect", pass)

	t.RequestUseAutoCollect = if RunService:IsServer() then v283:Server() else v283:Client()

	local v287 = Red.Event("AutoCollectActivated", pass)

	t.AutoCollectActivated = if RunService:IsServer() then v287:Server() else v287:Client()

	local v291 = Red.Event("ReplicateFishDropFeed", pass)

	t.ReplicateFishDropFeed = if RunService:IsServer() then v291:Server() else v291:Client()

	local v295 = Red.Event("ReplicateHourlyBest", pass)

	t.ReplicateHourlyBest = if RunService:IsServer() then v295:Server() else v295:Client()

	local v299 = Red.Event("RequestCurrentHourlyBest", pass)

	t.RequestCurrentHourlyBest = if RunService:IsServer() then v299:Server() else v299:Client()

	local t6 = {
		FloatName = Guard.String,
		Tier = Guard.String,
		Slot = Guard.Number
	}
	local v303 = Red.Event("EquipFishingFloat", (function(p13) --[[ Line: 23 | Upvalues: t6 (copy) ]]
		assert(type(p13) == "table", "payload must be a table")

		for v2, v3 in t6 do
			v3(p13[v2])
		end

		return p13
	end) or pass)

	t.EquipFishingFloat = if RunService:IsServer() then v303:Server() else v303:Client()

	local v307 = Red.Event("UnequipFishingFloat", Guard.Number or pass)

	t.UnequipFishingFloat = if RunService:IsServer() then v307:Server() else v307:Client()

	local v311 = Red.Event("BuyFishingSlot", Guard.Number or pass)

	t.BuyFishingSlot = if RunService:IsServer() then v311:Server() else v311:Client()

	local v315 = Red.Event("BuyFishingSlotWithGems", Guard.Number or pass)

	t.BuyFishingSlotWithGems = if RunService:IsServer() then v315:Server() else v315:Client()

	local v319 = Red.Event("ReplicateFloatShop", pass)

	t.ReplicateFloatShop = if RunService:IsServer() then v319:Server() else v319:Client()

	local v323 = Red.Event("BuyFloatLootbox", Guard.Number or pass)

	t.BuyFloatLootbox = if RunService:IsServer() then v323:Server() else v323:Client()

	local v328 = Red.Event("PlaceFloatLootbox", Guard.CFrame or pass)

	t.PlaceFloatLootbox = if RunService:IsServer() then v328:Server() else v328:Client()

	local v332 = Red.Event("OpenFloatLootbox", Guard.String or pass)

	t.OpenFloatLootbox = if RunService:IsServer() then v332:Server() else v332:Client()

	local v336 = Red.Event("FloatLootboxRollResult", pass)

	t.FloatLootboxRollResult = if RunService:IsServer() then v336:Server() else v336:Client()

	local v340 = Red.Event("ClaimFloatLootboxReward", Guard.String or pass)

	t.ClaimFloatLootboxReward = if RunService:IsServer() then v340:Server() else v340:Client()

	local v344 = Red.Event("SkipFloatLootboxTimer", Guard.String or pass)

	t.SkipFloatLootboxTimer = if RunService:IsServer() then v344:Server() else v344:Client()

	local v348 = Red.Event("ReplicatePlacedLootboxes", pass)

	t.ReplicatePlacedLootboxes = if RunService:IsServer() then v348:Server() else v348:Client()

	local v352 = Red.Event("RequestPlacedLootboxes", pass)

	t.RequestPlacedLootboxes = if RunService:IsServer() then v352:Server() else v352:Client()

	local v357 = Red.Event("RequestGiftLootbox", Guard.Instance or pass)

	t.RequestGiftLootbox = if RunService:IsServer() then v357:Server() else v357:Client()

	local v361 = Red.Event("OfferGiftLootbox", pass)

	t.OfferGiftLootbox = if RunService:IsServer() then v361:Server() else v361:Client()

	local v365 = Red.Event("RespondGiftLootbox", pass)

	t.RespondGiftLootbox = if RunService:IsServer() then v365:Server() else v365:Client()

	local v369 = Red.Event("PlaySoundByName", pass)

	t.PlaySoundByName = if RunService:IsServer() then v369:Server() else v369:Client()

	local v373 = Red.Event("RequestRenderPart", pass)

	t.RequestRenderPart = if RunService:IsServer() then v373:Server() else v373:Client()

	local v377 = Red.Event("FeedEventMachine", pass)

	t.FeedEventMachine = if RunService:IsServer() then v377:Server() else v377:Client()

	local v381 = Red.Event("ClaimEventMachineReward", pass)

	t.ClaimEventMachineReward = if RunService:IsServer() then v381:Server() else v381:Client()

	local v385 = Red.Event("EventMachineStateChanged", pass)

	t.EventMachineStateChanged = if RunService:IsServer() then v385:Server() else v385:Client()

	local v389 = Red.Event("RequestEventMachineState", pass)

	t.RequestEventMachineState = if RunService:IsServer() then v389:Server() else v389:Client()

	local v393 = Red.Event("EventRewardPopup", pass)

	t.EventRewardPopup = if RunService:IsServer() then v393:Server() else v393:Client()

	local v397 = Red.Event("AdminRewardPopup", pass)

	t.AdminRewardPopup = if RunService:IsServer() then v397:Server() else v397:Client()

	local v401 = Red.Event("AdminRewardPopupReady", pass)

	t.AdminRewardPopupReady = if RunService:IsServer() then v401:Server() else v401:Client()

	local v405 = Red.Event("AuctionRewardPopup", pass)

	t.AuctionRewardPopup = if RunService:IsServer() then v405:Server() else v405:Client()

	local v409 = Red.Event("AuctionRewardPopupReady", pass)

	t.AuctionRewardPopupReady = if RunService:IsServer() then v409:Server() else v409:Client()

	local v413 = Red.Event("EventMachineFeedResult", pass)

	t.EventMachineFeedResult = if RunService:IsServer() then v413:Server() else v413:Client()

	local v418 = Red.Event("StartMutationExtraction", Guard.Optional(Guard.String) or pass)

	t.StartMutationExtraction = if RunService:IsServer() then v418:Server() else v418:Client()

	local v422 = Red.Event("ClaimMutationJar", pass)

	t.ClaimMutationJar = if RunService:IsServer() then v422:Server() else v422:Client()

	local v426 = Red.Event("MutationMachineStateChanged", pass)

	t.MutationMachineStateChanged = if RunService:IsServer() then v426:Server() else v426:Client()

	local v430 = Red.Event("RequestMutationMachineState", pass)

	t.RequestMutationMachineState = if RunService:IsServer() then v430:Server() else v430:Client()

	local v434 = Red.Event("ApplyMutationJar", Guard.String or pass)

	t.ApplyMutationJar = if RunService:IsServer() then v434:Server() else v434:Client()

	local v438 = Red.Event("ApplyLevelWorm", Guard.String or pass)

	t.ApplyLevelWorm = if RunService:IsServer() then v438:Server() else v438:Client()

	local v442 = Red.Event("ReplicateEventStore", pass)

	t.ReplicateEventStore = if RunService:IsServer() then v442:Server() else v442:Client()

	local v446 = Red.Event("BuyEventStoreItem", Guard.String or pass)

	t.BuyEventStoreItem = if RunService:IsServer() then v446:Server() else v446:Client()

	local v450 = Red.Event("RequestEventStoreState", pass)

	t.RequestEventStoreState = if RunService:IsServer() then v450:Server() else v450:Client()

	local v454 = Red.Event("DebugGiveFish", pass)

	t.DebugGiveFish = if RunService:IsServer() then v454:Server() else v454:Client()

	local v458 = Red.Event("DebugRevealIndexFish", (function(p1) --[[ Line: 361 ]]
		assert(type(p1) == "table", "payload must be a table")

		return p1
	end) or pass)

	t.DebugRevealIndexFish = if RunService:IsServer() then v458:Server() else v458:Client()

	local v462 = Red.Event("CookingInsertFish", pass)

	t.CookingInsertFish = if RunService:IsServer() then v462:Server() else v462:Client()

	local v466 = Red.Event("CookingStartCook", pass)

	t.CookingStartCook = if RunService:IsServer() then v466:Server() else v466:Client()

	local v470 = Red.Event("CookingClaim", pass)

	t.CookingClaim = if RunService:IsServer() then v470:Server() else v470:Client()

	local v475 = Red.Event("TurnInFood", Guard.Instance or pass)

	t.TurnInFood = if RunService:IsServer() then v475:Server() else v475:Client()

	local v479 = Red.Event("FoodTurnInReaction", pass)

	t.FoodTurnInReaction = if RunService:IsServer() then v479:Server() else v479:Client()

	local v483 = Red.Event("RequestCodeRedeem", Guard.String or pass)

	t.RequestCodeRedeem = if RunService:IsServer() then v483:Server() else v483:Client()

	local v487 = Red.Event("ReplicateGlobalExistCounts", pass)

	t.ReplicateGlobalExistCounts = if RunService:IsServer() then v487:Server() else v487:Client()

	local v491 = Red.Event("ReplicateGymEvent", pass)

	t.ReplicateGymEvent = if RunService:IsServer() then v491:Server() else v491:Client()

	local v495 = Red.Event("GymReferralLimitReached", pass)

	t.GymReferralLimitReached = if RunService:IsServer() then v495:Server() else v495:Client()

	local v499 = Red.Event("BuyGymPersonalReward", Guard.String or pass)

	t.BuyGymPersonalReward = if RunService:IsServer() then v499:Server() else v499:Client()

	local t7 = {
		rarityId = Guard.String,
		enabled = Guard.Boolean
	}
	local v503 = Red.Event("ToggleAutoSellRarity", (function(p13) --[[ Line: 23 | Upvalues: t7 (copy) ]]
		assert(type(p13) == "table", "payload must be a table")

		for v2, v3 in t7 do
			v3(p13[v2])
		end

		return p13
	end) or pass)

	t.ToggleAutoSellRarity = if RunService:IsServer() then v503:Server() else v503:Client()

	local v507 = Red.Event("SetAutoSellMinEarnings", Guard.Number or pass)

	t.SetAutoSellMinEarnings = if RunService:IsServer() then v507:Server() else v507:Client()

	local t8 = {
		inventoryKey = Guard.String,
		count = Guard.Number
	}
	local v511 = Red.Event("ToggleFavorite", (function(p13) --[[ Line: 23 | Upvalues: t8 (copy) ]]
		assert(type(p13) == "table", "payload must be a table")

		for v2, v3 in t8 do
			v3(p13[v2])
		end

		return p13
	end) or pass)

	t.ToggleFavorite = if RunService:IsServer() then v511:Server() else v511:Client()

	local t9 = {
		settingName = Guard.String,
		enabled = Guard.Boolean
	}
	local v515 = Red.Event("SetPlayerSetting", (function(p13) --[[ Line: 23 | Upvalues: t9 (copy) ]]
		assert(type(p13) == "table", "payload must be a table")

		for v2, v3 in t9 do
			v3(p13[v2])
		end

		return p13
	end) or pass)

	t.SetPlayerSetting = if RunService:IsServer() then v515:Server() else v515:Client()

	local t10 = {
		minigame = Guard.String
	}
	local v519 = Red.Event("ChestMinigameCompleted", (function(p13) --[[ Line: 23 | Upvalues: t10 (copy) ]]
		assert(type(p13) == "table", "payload must be a table")

		for v2, v3 in t10 do
			v3(p13[v2])
		end

		return p13
	end) or pass)

	t.ChestMinigameCompleted = if RunService:IsServer() then v519:Server() else v519:Client()

	local v523 = Red.Event("AirdropStarted", pass)

	t.AirdropStarted = if RunService:IsServer() then v523:Server() else v523:Client()

	local v527 = Red.Event("AirdropCleared", pass)

	t.AirdropCleared = if RunService:IsServer() then v527:Server() else v527:Client()
	t.TravelToWorld = Red.Function("TravelToWorld", Guard.Number or pass, pass)
	t.UnlockWorld = Red.Function("UnlockWorld", Guard.Number or pass, pass)
	t.UnlockFishingVillage = Red.Function("UnlockFishingVillage", pass, pass)

	local v531 = Red.Event("PlayVillageFlyover", pass)

	t.PlayVillageFlyover = if RunService:IsServer() then v531:Server() else v531:Client()
	t.RequestUpgradeGardenSection = Red.Function("RequestUpgradeGardenSection", Guard.String or pass, pass)

	local t11 = {
		configName = Guard.String,
		cellX = Guard.Integer,
		cellZ = Guard.Integer,
		rot = Guard.Integer
	}

	t.RequestPlaceGardenItem = Red.Function("RequestPlaceGardenItem", (function(p13) --[[ Line: 23 | Upvalues: t11 (copy) ]]
		assert(type(p13) == "table", "payload must be a table")

		for v2, v3 in t11 do
			v3(p13[v2])
		end

		return p13
	end) or pass, pass)
	t.RequestRemoveGardenItem = Red.Function("RequestRemoveGardenItem", Guard.String or pass, pass)
	t.RequestDisplayGardenFish = Red.Function("RequestDisplayGardenFish", Guard.String or pass, pass)
	t.RequestClaimGardenDrill = Red.Function("RequestClaimGardenDrill", Guard.String or pass, pass)
	t.RequestInsertAlchemyFish = Red.Function("RequestInsertAlchemyFish", Guard.String or pass, pass)

	local t12 = {
		PlacementId = Guard.String,
		Tier = Guard.String,
		Floats = Guard.Map(Guard.String, Guard.Number)
	}

	t.RequestRecycleFloats = Red.Function("RequestRecycleFloats", (function(p13) --[[ Line: 23 | Upvalues: t12 (copy) ]]
		assert(type(p13) == "table", "payload must be a table")

		for v2, v3 in t12 do
			v3(p13[v2])
		end

		return p13
	end) or pass, pass)
	t.RequestClaimAlchemyPotion = Red.Function("RequestClaimAlchemyPotion", Guard.String or pass, pass)

	local t13 = {
		InventoryKey = Guard.String,
		Amount = Guard.Number
	}

	t.RequestDepositVaultFish = Red.Function("RequestDepositVaultFish", (function(p13) --[[ Line: 23 | Upvalues: t13 (copy) ]]
		assert(type(p13) == "table", "payload must be a table")

		for v2, v3 in t13 do
			v3(p13[v2])
		end

		return p13
	end) or pass, pass)

	local t14 = {
		VaultKey = Guard.String,
		Amount = Guard.Number
	}

	t.RequestWithdrawVaultFish = Red.Function("RequestWithdrawVaultFish", (function(p13) --[[ Line: 23 | Upvalues: t14 (copy) ]]
		assert(type(p13) == "table", "payload must be a table")

		for v2, v3 in t14 do
			v3(p13[v2])
		end

		return p13
	end) or pass, pass)
	t.RequestDepositAllVaultFish = Red.Function("RequestDepositAllVaultFish", pass, pass)

	local v535 = Red.Event("BuyAutoSellWithGems", pass)

	t.BuyAutoSellWithGems = if RunService:IsServer() then v535:Server() else v535:Client()

	local v539 = Red.Event("MarkTutorialStepCompletion", Guard.Number or pass)

	t.MarkTutorialStepCompletion = if RunService:IsServer() then v539:Server() else v539:Client()

	local v543 = Red.Event("PlayTutorialCutscene", pass)

	t.PlayTutorialCutscene = if RunService:IsServer() then v543:Server() else v543:Client()

	local v547 = Red.Event("NPCTradeSpawn", pass)

	t.NPCTradeSpawn = if RunService:IsServer() then v547:Server() else v547:Client()

	local v551 = Red.Event("NPCTradeRemove", pass)

	t.NPCTradeRemove = if RunService:IsServer() then v551:Server() else v551:Client()

	local v555 = Red.Event("RequestNPCTradeQueue", pass)

	t.RequestNPCTradeQueue = if RunService:IsServer() then v555:Server() else v555:Client()

	local t15 = {
		Accept = Guard.Boolean
	}

	t.NPCTradeRespond = Red.Function("NPCTradeRespond", (function(p13) --[[ Line: 23 | Upvalues: t15 (copy) ]]
		assert(type(p13) == "table", "payload must be a table")

		for v2, v3 in t15 do
			v3(p13[v2])
		end

		return p13
	end) or pass, pass)

	local v559 = Red.Event("NPCTradeOfferChanged", pass)

	t.NPCTradeOfferChanged = if RunService:IsServer() then v559:Server() else v559:Client()

	local v563 = Red.Event("RequestNPCTradeOffer", pass)

	t.RequestNPCTradeOffer = if RunService:IsServer() then v563:Server() else v563:Client()

	local v567 = Red.Event("RequestEquipBest", Guard.String or pass)

	t.RequestEquipBest = if RunService:IsServer() then v567:Server() else v567:Client()

	local v571 = Red.Event("RequestBuyEquipBest", pass)

	t.RequestBuyEquipBest = if RunService:IsServer() then v571:Server() else v571:Client()
end

t.SendTradeRequest = Red.Function("SendTradeRequest", Guard.Instance, Guard.String)
t.OnTradeInviteRecieve = Red.Event("OnTradeInviteRecieve", function(...) --[[ Line: 545 | Upvalues: Guard (copy) ]]
	local t = { ... }

	return Guard.Instance(t[1]), Guard.String(t[2])
end)
t.OnTradeInviteResponse = Red.Event("OnTradeInviteResponse", function(...) --[[ Line: 550 | Upvalues: Guard (copy) ]]
	local t = { ... }

	return Guard.String(t[1]), Guard.Boolean(t[2])
end)
t.TradeStateReplicate = Red.Event("TradeStateReplicate", pass)

local t16 = {
	sessionId = Guard.String,
	command = Guard.String
}

t.TradeStateUpdate = Red.Function("TradeStateUpdate", function(p13) --[[ Line: 23 | Upvalues: t16 (copy) ]]
	assert(type(p13) == "table", "payload must be a table")

	for v2, v3 in t16 do
		v3(p13[v2])
	end

	return p13
end, pass)

local v575 = Red.Event("SetFishState", Guard.Boolean or pass)

t.SetFishState = if RunService:IsServer() then v575:Server() else v575:Client()
t.PlayTradeFinishedAnimation = Red.Event("PlayTradeFinishedAnimation", Guard.Instance)

local v579 = Red.Event("SetThrowZoneState", Guard.Boolean or pass)

t.SetThrowZoneState = if RunService:IsServer() then v579:Server() else v579:Client()

local t17 = {
	LandingPos = Guard.Vector3,
	FlightDuration = Guard.Number
}
local v583 = Red.Event("FishingCastBegin", (function(p13) --[[ Line: 23 | Upvalues: t17 (copy) ]]
	assert(type(p13) == "table", "payload must be a table")

	for v2, v3 in t17 do
		v3(p13[v2])
	end

	return p13
end) or pass)

t.FishingCastBegin = if RunService:IsServer() then v583:Server() else v583:Client()

local t18 = {
	Kind = Guard.String
}
local v587 = Red.Event("FishingStage", (function(p13) --[[ Line: 23 | Upvalues: t18 (copy) ]]
	assert(type(p13) == "table", "payload must be a table")

	for v2, v3 in t18 do
		v3(p13[v2])
	end

	return p13
end) or pass)

t.FishingStage = if RunService:IsServer() then v587:Server() else v587:Client()

local v591 = Red.Event("FishingRemoteCast", pass)

t.FishingRemoteCast = if RunService:IsServer() then v591:Server() else v591:Client()

local v595 = Red.Event("FishingRemoteStage", pass)

t.FishingRemoteStage = if RunService:IsServer() then v595:Server() else v595:Client()
t.AlienBuyUpgrade = Red.Function("AlienBuyUpgrade", Guard.String or pass, pass)
t.AlienFlightStart = Red.Function("AlienFlightStart", pass, pass)

local v599 = Red.Event("AlienFlightEnd", pass)

t.AlienFlightEnd = if RunService:IsServer() then v599:Server() else v599:Client()

local v603 = Red.Event("AlienFuelDrop", pass)

t.AlienFuelDrop = if RunService:IsServer() then v603:Server() else v603:Client()
t.AlienCollectFuel = Red.Function("AlienCollectFuel", Guard.String or pass, pass)
t.AlienGiveFuelFish = Red.Function("AlienGiveFuelFish", pass, pass)
t.AlienDepositFuelTank = Red.Function("AlienDepositFuelTank", pass, pass)
t.AlienResearchInsert = Red.Function("AlienResearchInsert", Guard.Number or pass, pass)
t.AlienResearchCollect = Red.Function("AlienResearchCollect", Guard.Number or pass, pass)

local v607 = Red.Event("AlienResearchGuide", pass)

t.AlienResearchGuide = if RunService:IsServer() then v607:Server() else v607:Client()

local v611 = Red.Event("AlienFishSpawn", pass)

t.AlienFishSpawn = if RunService:IsServer() then v611:Server() else v611:Client()

local v615 = Red.Event("AlienShipPose", pass)

t.AlienShipPose = if RunService:IsServer() then v615:Server() else v615:Client()
t.AlienCatchStart = Red.Function("AlienCatchStart", Guard.Number or pass, pass)

local t19 = {
	Id = Guard.Number,
	Success = Guard.Boolean,
	Rejected = Guard.Number
}

t.AlienCatchFinish = Red.Function("AlienCatchFinish", (function(p13) --[[ Line: 23 | Upvalues: t19 (copy) ]]
	assert(type(p13) == "table", "payload must be a table")

	for v2, v3 in t19 do
		v3(p13[v2])
	end

	return p13
end) or pass, pass)
t.AlienUnloadCargo = Red.Function("AlienUnloadCargo", pass, pass)

local t20 = {
	UIOpen = Guard.Boolean
}

t.GetAuctionHouseState = Red.Function("GetAuctionHouseState", (function(p13) --[[ Line: 23 | Upvalues: t20 (copy) ]]
	assert(type(p13) == "table", "payload must be a table")

	for v2, v3 in t20 do
		v3(p13[v2])
	end

	return p13
end) or pass, pass)

local v619 = Red.Event("ReplicateAuctionHouse", pass)

t.ReplicateAuctionHouse = if RunService:IsServer() then v619:Server() else v619:Client()

local t21 = {
	WindowStart = Guard.Number,
	Slot = Guard.String,
	Step = Guard.Number
}

t.AuctionBid = Red.Function("AuctionBid", (function(p13) --[[ Line: 23 | Upvalues: t21 (copy) ]]
	assert(type(p13) == "table", "payload must be a table")

	for v2, v3 in t21 do
		v3(p13[v2])
	end

	return p13
end) or pass, pass)

local t22 = {
	WindowStart = Guard.Number,
	Slot = Guard.String
}

t.AuctionBuy = Red.Function("AuctionBuy", (function(p13) --[[ Line: 23 | Upvalues: t22 (copy) ]]
	assert(type(p13) == "table", "payload must be a table")

	for v2, v3 in t22 do
		v3(p13[v2])
	end

	return p13
end) or pass, pass)

local t23 = {
	Slot = Guard.String,
	Name = Guard.String
}
local v623 = Red.Event("BuyDeepsGear", (function(p13) --[[ Line: 23 | Upvalues: t23 (copy) ]]
	assert(type(p13) == "table", "payload must be a table")

	for v2, v3 in t23 do
		v3(p13[v2])
	end

	return p13
end) or pass)

t.BuyDeepsGear = if RunService:IsServer() then v623:Server() else v623:Client()

local t24 = {
	Slot = Guard.String,
	Name = Guard.String
}
local v627 = Red.Event("EquipDeepsGear", (function(p13) --[[ Line: 23 | Upvalues: t24 (copy) ]]
	assert(type(p13) == "table", "payload must be a table")

	for v2, v3 in t24 do
		v3(p13[v2])
	end

	return p13
end) or pass)

t.EquipDeepsGear = if RunService:IsServer() then v627:Server() else v627:Client()

local v631 = Red.Event("DeepsFishSpawn", pass)

t.DeepsFishSpawn = if RunService:IsServer() then v631:Server() else v631:Client()

local v635 = Red.Event("DeepsFishRemoved", pass)

t.DeepsFishRemoved = if RunService:IsServer() then v635:Server() else v635:Client()

local v639 = Red.Event("DeepsFishBusy", pass)

t.DeepsFishBusy = if RunService:IsServer() then v639:Server() else v639:Client()
t.DeepsCatchStart = Red.Function("DeepsCatchStart", Guard.Number or pass, pass)

local t25 = {
	Id = Guard.Number,
	Success = Guard.Boolean,
	Rejected = Guard.Number
}

t.DeepsCatchFinish = Red.Function("DeepsCatchFinish", (function(p13) --[[ Line: 23 | Upvalues: t25 (copy) ]]
	assert(type(p13) == "table", "payload must be a table")

	for v2, v3 in t25 do
		v3(p13[v2])
	end

	return p13
end) or pass, pass)

local v643 = Red.Event("DeepsItemSpawn", pass)

t.DeepsItemSpawn = if RunService:IsServer() then v643:Server() else v643:Client()

local v647 = Red.Event("DeepsItemRemoved", pass)

t.DeepsItemRemoved = if RunService:IsServer() then v647:Server() else v647:Client()
t.DeepsSync = Red.Function("DeepsSync", pass, pass)
t.DeepsPickupItem = Red.Function("DeepsPickupItem", Guard.Number or pass, pass)

local v651 = Red.Event("DeepsBagSettled", pass)

t.DeepsBagSettled = if RunService:IsServer() then v651:Server() else v651:Client()

local v655 = Red.Event("DeepsFailed", pass)

t.DeepsFailed = if RunService:IsServer() then v655:Server() else v655:Client()

local v659 = Red.Event("DeepsForfeitRecovery", pass)

t.DeepsForfeitRecovery = if RunService:IsServer() then v659:Server() else v659:Client()
t.DeepsWatchAdForLoot = Red.Function("DeepsWatchAdForLoot", pass, pass)
t.DeepsProcessLoot = Red.Function("DeepsProcessLoot", pass, pass)

return t