-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Debris = game:GetService("Debris")
local Lighting = game:GetService("Lighting")
local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local SoundService = game:GetService("SoundService")
local TweenService = game:GetService("TweenService")
local Workspace = game:GetService("Workspace")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local SFX = require(ReplicatedStorage.client.SFX)
local VFX = require(ReplicatedStorage.client.VFX)

require(ReplicatedStorage.shared.weather.WeatherTypes)

local t = {
	_postFxGen = 0,
	_skyOverride = {
		active = false,
		parkedAtmosphere = nil,
		clones = {},
		parkedSkies = {},
		dimmedFx = {},
		pending = {},
		originals = {}
	},
	_skyOverrideChannels = {
		{
			name = "SetPrecip"
		},
		{
			name = "SetSceneFX"
		},
		{
			name = "SetWorldFX"
		},
		{
			name = "SetWaterFX"
		},
		{
			name = "SetWater",
			off = "RestoreWater"
		},
		{
			name = "SetAmbient",
			off = "ClearAmbient"
		},
		{
			name = "SetAmbientFX"
		},
		{
			name = "SetFallingStars"
		},
		{
			name = "SetSnowStuds"
		},
		{
			name = "SetGrassWhite"
		},
		{
			name = "SetSnowFx"
		},
		{
			name = "SetSpawnpointStars"
		},
		{
			name = "SetMovingStars"
		},
		{
			name = "SetRainbowMesh"
		},
		{
			name = "SetWorldMesh"
		},
		{
			name = "SetSnowman"
		},
		{
			name = "SetThunder"
		},
		{
			name = "SetBreath"
		},
		{
			name = "SetShiver"
		},
		{
			name = "SetIceProps"
		},
		{
			name = "SetScreenRain"
		},
		{
			name = "SetScreenSnow"
		},
		{
			name = "SetClientCloudsOverride"
		},
		{
			name = "SetFreezeScreen"
		},
		{
			name = "SetEnvironmentScale"
		},
		{
			name = "ApplyPostEffects",
			off = "ClearPostEffects"
		},
		{
			name = "ApplyLighting",
			off = "RestoreLighting"
		}
	}
}
local t2 = {
	Coverage = 250,
	RainHeight = 100,
	SnowCoverage = 140,
	SnowVolumeHeight = 150,
	SnowVolumeCenter = 45,
	GroundMargin = 20,
	MaxFallLifetime = 6,
	RainRate = 3600,
	SnowRate = 3000,
	FollowInterval = 0.1
}
local t3 = {
	Size = 60,
	RainHeight = 18,
	SnowHeight = 50,
	Forward = 8,
	RainRate = 900,
	SnowRate = 500
}

local function getWeatherTemplate() --[[ getWeatherTemplate | Line: 151 | Upvalues: ReplicatedStorage (copy) ]]
	local v1 = ReplicatedStorage:FindFirstChild("shared")
	local v2 = if v1 then v1:FindFirstChild("model") else v1
	local v3 = if v2 then v2:FindFirstChild("fx") else v2
	local v4 = v3 and v3:FindFirstChild("WeatherPart_fx") or ReplicatedStorage:FindFirstChild("WeatherPart")

	if v4 and v4:IsA("BasePart") then
		return v4
	end

	return nil
end

local v1 = nil
local v2 = nil
local v3 = nil
local v4 = nil
local v5 = nil
local v6 = nil
local v7 = nil
local v8 = nil
local v9 = nil
local v10 = nil
local v11 = nil
local v12 = nil
local v13 = nil
local v14 = nil
local v15 = nil
local v16 = nil
local v17 = nil
local v18 = nil
local v19 = false
local v20 = nil
local v21 = nil
local v22 = nil
local t4 = {}
local t5 = {}
local v23 = nil
local v24 = nil
local v25 = nil
local v26 = false
local v27 = 0
local v28 = nil
local t6 = {}
local v29 = false
local v30 = 0
local v31 = nil
local v32 = nil
local v33 = nil
local v34 = nil
local v35 = nil
local v36 = nil
local v37 = nil
local v38 = false
local v39 = 0
local v40 = nil
local v41 = false
local v42 = 0
local v43 = false
local v44 = 0

local function tween(p1, p2, p3) --[[ tween | Line: 226 | Upvalues: TweenService (copy) ]]
	TweenService:Create(p1, TweenInfo.new(p3, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), p2):Play()
end

local function getPlayerPosition() --[[ getPlayerPosition | Line: 231 | Upvalues: Players (copy), Workspace (copy) ]]
	local Character = Players.LocalPlayer.Character
	local v1 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character

	if v1 then
		return v1.Position
	end

	local CurrentCamera = Workspace.CurrentCamera

	if CurrentCamera then
		return CurrentCamera.CFrame.Position
	end

	return nil
end

local function getTerrainClouds() --[[ getTerrainClouds | Line: 244 | Upvalues: v18 (ref), Workspace (copy) ]]
	if v18 and v18.Parent then
		return v18
	end

	local Terrain = Workspace:FindFirstChildOfClass("Terrain")

	if not Terrain then
		return nil
	end

	local Clouds = Terrain:FindFirstChildOfClass("Clouds")

	if not Clouds then
		local WeatherClouds = Instance.new("Clouds")

		WeatherClouds.Name = "WeatherClouds"
		WeatherClouds.Cover = 0
		WeatherClouds.Density = 0
		WeatherClouds.Parent = Terrain
		Clouds = WeatherClouds
	end

	v18 = Clouds

	return Clouds
end

local function ensureReach(p1, p2) --[[ ensureReach | Line: 267 ]]
	local v1 = math.max(p1.Speed.Max, 0)
	local v2 = math.abs(p1.Acceleration.Y)
	local Lifetime = p1.Lifetime

	local function travel(p1) --[[ travel | Line: 271 | Upvalues: v1 (copy), v2 (copy) ]]
		return v1 * p1 + v2 * 0.5 * p1 * p1
	end

	local Max2 = Lifetime.Max

	if p2 <= v1 * Max2 + v2 * 0.5 * Max2 * Max2 then
		return
	end

	local v5 = math.min(math.max(if v2 > 0 then (-v1 + math.sqrt(v1 * v1 + v2 * 2 * p2)) / v2 elseif v1 > 0 then p2 / v1 else Lifetime.Max * 3, Lifetime.Max), 6)

	p1.Lifetime = NumberRange.new(math.min(Lifetime.Min, v5), v5)
end

local function canopySize() --[[ canopySize | Line: 291 | Upvalues: v12 (ref) ]]
	if v12 == "Snow" then
		return Vector3.new(140, 150, 140)
	end

	return Vector3.new(250, 1, 250)
end

local function canopyOffsetY() --[[ canopyOffsetY | Line: 298 | Upvalues: v12 (ref) ]]
	if v12 == "Snow" then
		return 45
	end

	return 100
end

local function cameraLayerSize() --[[ cameraLayerSize | Line: 306 | Upvalues: v12 (ref) ]]
	if v12 == "Snow" then
		return Vector3.new(60, 50, 60)
	end

	return Vector3.new(60, 1, 60)
end

local function setPrecip(p1) --[[ setPrecip | Line: 315 | Upvalues: v12 (ref), v4 (ref), t2 (copy), v5 (ref), ensureReach (copy), v6 (ref), v7 (ref), t3 (copy), v8 (ref), v9 (ref), v11 (ref), v14 (ref), v15 (ref), v16 (ref) ]]
	v12 = p1

	local v1 = v4

	if v1 then
		v1.Size = if p1 == "Snow" then Vector3.new(t2.SnowCoverage, t2.SnowVolumeHeight, t2.SnowCoverage) else Vector3.new(t2.Coverage, 1, t2.Coverage)
	end

	if v5 then
		v5.Enabled = p1 == "Rain"

		if p1 == "Rain" then
			ensureReach(v5, 120)
		end
	end

	if v6 then
		v6.Enabled = p1 == "Snow"

		if p1 == "Snow" then
			ensureReach(v6, 75)
		end
	end

	if v7 then
		v7.Size = if p1 == "Snow" then Vector3.new(t3.Size, t3.SnowHeight, t3.Size) else Vector3.new(t3.Size, 1, t3.Size)
	end

	if v8 then
		v8.Enabled = p1 == "Rain"

		if p1 == "Rain" then
			ensureReach(v8, 38)
		end
	end

	if v9 then
		v9.Enabled = p1 == "Snow"
	end

	if v11 then
		v11.Enabled = p1 == "Rain"
	end

	v14()
	v15()
	v16()
end

local function makeEmitterPart(p1, p2, p3) --[[ makeEmitterPart | Line: 361 ]]
	local v1 = p1:Clone()

	v1.Anchored = true
	v1.CanCollide = false
	v1.CanQuery = false
	v1.CanTouch = false
	v1.CastShadow = false
	v1.Transparency = 1

	for v2, v3 in v1:GetDescendants() do
		if v3:IsA("Sound") then
			v3:Destroy()

			continue
		end

		if v3:IsA("ParticleEmitter") then
			v3.Enabled = false
		end
	end

	local RainEmitter = v1:FindFirstChild("RainEmitter")
	local SnowEmitter = v1:FindFirstChild("SnowEmitter")

	if RainEmitter then
		RainEmitter.Rate = p2
	end

	if SnowEmitter then
		SnowEmitter.Rate = p3
	end

	return v1, RainEmitter, SnowEmitter
end

local function buildCanopy() --[[ buildCanopy | Line: 395 | Upvalues: v4 (ref), getWeatherTemplate (copy), Players (copy), Workspace (copy), makeEmitterPart (copy), v12 (ref), t2 (copy), v19 (ref), v5 (ref), v6 (ref) ]]
	if v4 then
		return true
	end

	local v1 = getWeatherTemplate()

	if not v1 then
		warn("[WeatherEffects] No WeatherPart_fx/WeatherPart template found; precipitation disabled")

		return false
	end

	local Character = Players.LocalPlayer.Character
	local v2 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character
	local v3

	if v2 then
		v3 = v2.Position
	else
		local CurrentCamera = Workspace.CurrentCamera

		v3 = if CurrentCamera then CurrentCamera.CFrame.Position else nil
	end

	if not v3 then
		return false
	end

	local v42, v52, v62 = makeEmitterPart(v1, 3600, 3000)

	v42.Size = if v12 == "Snow" then Vector3.new(t2.SnowCoverage, t2.SnowVolumeHeight, t2.SnowCoverage) else Vector3.new(t2.Coverage, 1, t2.Coverage)
	v42.CFrame = CFrame.new(v3.X, v3.Y + (if v12 == "Snow" then t2.SnowVolumeCenter else t2.RainHeight), v3.Z)

	if not (v52 or (v62 or v19)) then
		v19 = true
		warn("[WeatherEffects] Weather template has no RainEmitter/SnowEmitter children; nothing will render")
	end

	v42.Parent = Workspace
	v4 = v42
	v5 = v52
	v6 = v62

	return true
end

local function buildCameraLayer() --[[ buildCameraLayer | Line: 428 | Upvalues: v7 (ref), getWeatherTemplate (copy), Workspace (copy), makeEmitterPart (copy), v12 (ref), t3 (copy), v8 (ref), v9 (ref), v15 (ref) ]]
	if v7 then
		return true
	end

	local v1 = getWeatherTemplate()

	if not (v1 and Workspace.CurrentCamera) then
		return false
	end

	local v2, v3, v4 = makeEmitterPart(v1, 900, 500)

	v2.Size = if v12 == "Snow" then Vector3.new(t3.Size, t3.SnowHeight, t3.Size) else Vector3.new(t3.Size, 1, t3.Size)
	v2.Parent = Workspace
	v7 = v2
	v8 = v3
	v9 = v4
	v15()

	return true
end

local function buildGroundLayer() --[[ buildGroundLayer | Line: 449 | Upvalues: v10 (ref), getWeatherTemplate (copy), Players (copy), Workspace (copy), makeEmitterPart (copy), v19 (ref), v11 (ref), v16 (ref) ]]
	if v10 then
		return true
	end

	local v1 = getWeatherTemplate()

	if not v1 then
		return false
	end

	local Character = Players.LocalPlayer.Character
	local v2 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character
	local v3

	if v2 then
		v3 = v2.Position
	else
		local CurrentCamera = Workspace.CurrentCamera

		v3 = if CurrentCamera then CurrentCamera.CFrame.Position else nil
	end

	if not v3 then
		return false
	end

	local v4 = makeEmitterPart(v1, 0, 0)
	local Splashes = v4:FindFirstChild("Splashes")

	if Splashes then
		Splashes.Enabled = false
	elseif not v19 then
		warn("[WeatherEffects] Template has no \'Splashes\' emitter; ground splashes disabled")
	end

	v4.Size = Vector3.new(80, 1, 80)
	v4.Parent = Workspace
	v10 = v4
	v11 = Splashes
	v16()

	return true
end

v14 = function() --[[ repositionCanopy | Line: 479 | Upvalues: v4 (ref), Players (copy), Workspace (copy), v12 (ref), t2 (copy) ]]
	local v1 = v4

	if not v1 then
		return
	end

	local Character = Players.LocalPlayer.Character
	local v2 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character
	local v3

	if v2 then
		v3 = v2.Position
	else
		local CurrentCamera = Workspace.CurrentCamera

		v3 = if CurrentCamera then CurrentCamera.CFrame.Position else nil
	end

	if not v3 then
		return
	end

	v1.CFrame = CFrame.new(v3.X, v3.Y + (if v12 == "Snow" then t2.SnowVolumeCenter else t2.RainHeight), v3.Z)
end
v15 = function() --[[ repositionCameraLayer | Line: 493 | Upvalues: v7 (ref), Workspace (copy), v12 (ref) ]]
	local v1 = v7

	if not v1 then
		return
	end

	local CurrentCamera = Workspace.CurrentCamera

	if not CurrentCamera then
		return
	end

	local LookVector = CurrentCamera.CFrame.LookVector
	local v2 = Vector3.new(LookVector.X, 0, LookVector.Z)
	local v3 = if v2.Magnitude > 0.01 then v2.Unit else Vector3.new(0, 0, 0)

	v1.CFrame = CFrame.new(CurrentCamera.CFrame.Position + v3 * 8 + Vector3.new(0, if v12 == "Snow" then 0 else 18, 0))
end
v16 = function() --[[ repositionGroundLayer | Line: 512 | Upvalues: v10 (ref), Players (copy), Workspace (copy) ]]
	local v1 = v10

	if not v1 then
		return
	end

	local Character = Players.LocalPlayer.Character
	local v2 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character
	local v3

	if v2 then
		v3 = v2.Position
	else
		local CurrentCamera = Workspace.CurrentCamera

		v3 = if CurrentCamera then CurrentCamera.CFrame.Position else nil
	end

	if v3 then
		v1.CFrame = CFrame.new(v3.X, v3.Y - 2.8, v3.Z)
	end
end

local function startFollow() --[[ startFollow | Line: 525 | Upvalues: v13 (ref), RunService (copy), v15 (ref), v14 (ref), v16 (ref) ]]
	if not v13 then
		local v1 = 0

		v13 = RunService.RenderStepped:Connect(function(p13) --[[ Line: 532 | Upvalues: v15 (ref), v1 (ref), v14 (ref), v16 (ref) ]]
			debug.profilebegin("UECS/WeatherEffects.RainFollow")
			v15()
			v1 = v1 + p13

			if not (v1 >= 0.1) then
				debug.profileend()

				return
			end

			v1 = 0
			v14()
			v16()
			debug.profileend()
		end)
	end
end

local function stopFollow() --[[ stopFollow | Line: 545 | Upvalues: v13 (ref) ]]
	if not v13 then
		return
	end

	v13:Disconnect()
	v13 = nil
end

local function destroyCanopy() --[[ destroyCanopy | Line: 552 | Upvalues: v13 (ref), v4 (ref), v7 (ref), v10 (ref), v5 (ref), v6 (ref), v8 (ref), v9 (ref), v11 (ref), v12 (ref) ]]
	if v13 then
		v13:Disconnect()
		v13 = nil
	end

	if v4 then
		v4:Destroy()
		v4 = nil
	end

	if v7 then
		v7:Destroy()
		v7 = nil
	end

	if v10 then
		v10:Destroy()
		v10 = nil
	end

	v5 = nil
	v6 = nil
	v8 = nil
	v9 = nil
	v11 = nil
	v12 = nil
end

local function startRainSound() --[[ startRainSound | Line: 574 | Upvalues: v17 (ref), SFX (copy) ]]
	if not v17 then
		v17 = SFX.PlayLooped(SFX.Sounds.Rain, 0.5)
	end
end

local function stopRainSound() --[[ stopRainSound | Line: 581 | Upvalues: v17 (ref), SoundService (copy), SFX (copy) ]]
	if v17 then
		v17()
		v17 = nil
	end

	local SFX2 = SoundService:FindFirstChild("SFX")

	if not SFX2 then
		return
	end

	for v1, v2 in SFX2:GetChildren() do
		if v2:IsA("Sound") and v2.SoundId == SFX.Sounds.Rain then
			v2.PlayOnRemove = false
			v2:Stop()
			v2:Destroy()
		end
	end
end

local function v45(p1) --[[ applyPrecip | Line: 601 | Upvalues: v3 (ref), v4 (ref), buildCanopy (copy), v45 (copy), v7 (ref), getWeatherTemplate (copy), Workspace (copy), makeEmitterPart (copy), t3 (copy), v12 (ref), v8 (ref), v9 (ref), v15 (ref), buildGroundLayer (copy), setPrecip (copy), v13 (ref), RunService (copy), v14 (ref), v16 (ref), v17 (ref), SFX (copy), stopRainSound (copy), v10 (ref), v5 (ref), v6 (ref), v11 (ref) ]]
	v3 = p1

	if p1 == "Rain" or p1 == "Snow" then
		if not (v4 or buildCanopy()) then
			task.delay(0.5, function() --[[ Line: 608 | Upvalues: v3 (ref), p1 (copy), v45 (ref) ]]
				if v3 ~= p1 then
					return
				end

				v45(p1)
			end)

			return
		end

		if not v7 then
			local v1 = getWeatherTemplate()

			if v1 and Workspace.CurrentCamera then
				local v2, v32, v42 = makeEmitterPart(v1, t3.RainRate, t3.SnowRate)

				v2.Size = if v12 == "Snow" then Vector3.new(t3.Size, t3.SnowHeight, t3.Size) else Vector3.new(t3.Size, 1, t3.Size)
				v2.Parent = Workspace
				v7 = v2
				v8 = v32
				v9 = v42
				v15()
			end
		end

		buildGroundLayer()
		setPrecip(p1)

		if not v13 then
			local v62 = 0

			v13 = RunService.RenderStepped:Connect(function(p13) --[[ Line: 532 | Upvalues: v15 (ref), v62 (ref), v14 (ref), v16 (ref) ]]
				debug.profilebegin("UECS/WeatherEffects.RainFollow")
				v15()
				v62 = v62 + p13

				if not (v62 >= 0.1) then
					debug.profileend()

					return
				end

				v62 = 0
				v14()
				v16()
				debug.profileend()
			end)
		end

		if p1 ~= "Rain" then
			stopRainSound()

			return
		end

		if not v17 then
			v17 = SFX.PlayLooped(SFX.Sounds.Rain, 0.5)
		end
	else
		if v13 then
			v13:Disconnect()
			v13 = nil
		end

		if v4 then
			v4:Destroy()
			v4 = nil
		end

		if v7 then
			v7:Destroy()
			v7 = nil
		end

		if not v10 then
			v5 = nil
			v6 = nil
			v8 = nil
			v9 = nil
			v11 = nil
			v12 = nil
			stopRainSound()

			return
		end

		v10:Destroy()
		v10 = nil
		v5 = nil
		v6 = nil
		v8 = nil
		v9 = nil
		v11 = nil
		v12 = nil
		stopRainSound()
	end
end

local function ensureColorCorrection() --[[ ensureColorCorrection | Line: 663 | Upvalues: v20 (ref), Lighting (copy) ]]
	if v20 then
		return v20
	end

	local WeatherColorCorrection = Instance.new("ColorCorrectionEffect")

	WeatherColorCorrection.Name = "WeatherColorCorrection"
	WeatherColorCorrection.Parent = Lighting
	v20 = WeatherColorCorrection

	return WeatherColorCorrection
end

local function ensureBloom() --[[ ensureBloom | Line: 673 | Upvalues: v21 (ref), Lighting (copy) ]]
	if v21 then
		return v21
	end

	local WeatherBloom = Instance.new("BloomEffect")

	WeatherBloom.Name = "WeatherBloom"
	WeatherBloom.Intensity = 0
	WeatherBloom.Parent = Lighting
	v21 = WeatherBloom

	return WeatherBloom
end

local function ensureSunRays() --[[ ensureSunRays | Line: 684 | Upvalues: v22 (ref), Lighting (copy) ]]
	if v22 then
		return v22
	end

	local WeatherSunRays = Instance.new("SunRaysEffect")

	WeatherSunRays.Name = "WeatherSunRays"
	WeatherSunRays.Intensity = 0
	WeatherSunRays.Parent = Lighting
	v22 = WeatherSunRays

	return WeatherSunRays
end

local function stopHueCycle() --[[ stopHueCycle | Line: 695 | Upvalues: v31 (ref) ]]
	if not v31 then
		return
	end

	v31:Disconnect()
	v31 = nil
end

local function startHueCycle() --[[ startHueCycle | Line: 702 | Upvalues: v31 (ref), RunService (copy), v20 (ref) ]]
	if not v31 then
		local v1 = 0

		v31 = RunService.RenderStepped:Connect(function(p13) --[[ Line: 707 | Upvalues: v20 (ref), v1 (ref) ]]
			debug.profilebegin("UECS/WeatherEffects.HueCycle")

			local v12 = v20

			if v12 then
				v1 = v1 + p13 * 0.08
				v12.TintColor = Color3.fromHSV(v1 % 1, 0.25, 1)
			end

			debug.profileend()
		end)
	end
end

local function applyPostEffects(p1) --[[ applyPostEffects | Line: 721 | Upvalues: t (copy), v20 (ref), Lighting (copy), TweenService (copy), v31 (ref), RunService (copy), v21 (ref), v22 (ref) ]]
	local v1 = t

	v1._postFxGen = v1._postFxGen + 1

	if not v20 then
		local WeatherColorCorrection = Instance.new("ColorCorrectionEffect")

		WeatherColorCorrection.Name = "WeatherColorCorrection"
		WeatherColorCorrection.Parent = Lighting
		v20 = WeatherColorCorrection
	end

	local v2 = v20
	local ColorCorrection = p1.ColorCorrection

	if ColorCorrection then
		if ColorCorrection.HueCycle then
			TweenService:Create(v2, TweenInfo.new(3, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
				Brightness = ColorCorrection.Brightness,
				Contrast = ColorCorrection.Contrast,
				Saturation = ColorCorrection.Saturation
			}):Play()

			if not v31 then
				local v3 = 0

				v31 = RunService.RenderStepped:Connect(function(p13) --[[ Line: 707 | Upvalues: v20 (ref), v3 (ref) ]]
					debug.profilebegin("UECS/WeatherEffects.HueCycle")

					local v12 = v20

					if v12 then
						v3 = v3 + p13 * 0.08
						v12.TintColor = Color3.fromHSV(v3 % 1, 0.25, 1)
					end

					debug.profileend()
				end)
			end
		else
			if v31 then
				v31:Disconnect()
				v31 = nil
			end

			TweenService:Create(v2, TweenInfo.new(3, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
				Brightness = ColorCorrection.Brightness,
				Contrast = ColorCorrection.Contrast,
				Saturation = ColorCorrection.Saturation,
				TintColor = ColorCorrection.TintColor
			}):Play()
		end
	else
		if v31 then
			v31:Disconnect()
			v31 = nil
		end

		local t2 = {
			Brightness = 0,
			Contrast = 0,
			Saturation = 0,
			TintColor = Color3.new(255/255, 255/255, 255/255)
		}

		TweenService:Create(v2, TweenInfo.new(3, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), t2):Play()
	end

	local Bloom = p1.Bloom

	if Bloom then
		if not v21 then
			local WeatherBloom = Instance.new("BloomEffect")

			WeatherBloom.Name = "WeatherBloom"
			WeatherBloom.Intensity = 0
			WeatherBloom.Parent = Lighting
			v21 = WeatherBloom
		end

		TweenService:Create(v21, TweenInfo.new(3, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
			Intensity = Bloom.Intensity * 0.5,
			Size = Bloom.Size,
			Threshold = Bloom.Threshold
		}):Play()
	elseif v21 then
		TweenService:Create(v21, TweenInfo.new(3, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
			Intensity = 0
		}):Play()
	end

	local SunRays = p1.SunRays

	if SunRays then
		local v6

		if not v22 then
			local WeatherSunRays = Instance.new("SunRaysEffect")

			WeatherSunRays.Name = "WeatherSunRays"
			WeatherSunRays.Intensity = 0
			WeatherSunRays.Parent = Lighting
			v22 = WeatherSunRays
		end

		v6 = {
			Intensity = SunRays.Intensity,
			Spread = SunRays.Spread
		}
		TweenService:Create(v22, TweenInfo.new(3, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), v6):Play()
	else
		if not v22 then
			return
		end

		TweenService:Create(v22, TweenInfo.new(3, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
			Intensity = 0
		}):Play()
	end
end

local function getFxFolder() --[[ getFxFolder | Line: 767 | Upvalues: ReplicatedStorage (copy) ]]
	local v1 = ReplicatedStorage:WaitForChild("shared", 10)
	local v2 = if v1 then v1:WaitForChild("model", 10) else v1

	return if v2 then v2:WaitForChild("fx", 10) else v2
end

local function clearSceneFX() --[[ clearSceneFX | Line: 775 | Upvalues: t4 (copy), t5 (copy), Lighting (copy), v23 (ref) ]]
	print("[WeatherEffects] clearSceneFX() called. Current sceneFxClones count:", #t4, "stashedSkies count:", #t5)

	for v1, v2 in t4 do
		print("[WeatherEffects] destroying clone:", v2.Name, "of type:", v2.ClassName)
		v2:Destroy()
	end

	table.clear(t4)

	for v3, v4 in t5 do
		print("[WeatherEffects] restoring stashed sky:", v4.Name)
		pcall(function() --[[ Line: 784 | Upvalues: v4 (copy), Lighting (ref) ]]
			v4.Parent = Lighting
		end)
	end

	table.clear(t5)
	v23 = nil
end

local function applySceneFX(p1, p2, p3, p4) --[[ applySceneFX | Line: 798 | Upvalues: v23 (ref), clearSceneFX (copy), ReplicatedStorage (copy), TweenService (copy), Lighting (copy), t5 (copy), t4 (copy) ]]
	print("[WeatherEffects] applySceneFX() called with name:", p1, "currentSceneFx:", v23, "clearTargetName:", p4)
	print("[WeatherEffects] Call stack:", debug.traceback())

	if v23 == p1 then
		print("[WeatherEffects] currentSceneFx already matches target name. Returning early.")

		return
	end

	if not p1 and (p4 and v23 ~= p4) then
		print("[WeatherEffects] Clear request for", p4, "ignored because active FX is", v23)

		return
	end

	clearSceneFX()

	if not p1 then
		print("[WeatherEffects] no SceneFX name provided. Cleared only.")

		return
	end

	local v1 = ReplicatedStorage:WaitForChild("shared", 10)
	local v2 = if v1 then v1:WaitForChild("model", 10) else v1
	local v3 = v2 and v2:WaitForChild("fx", 10)
	local v4 = if v3 then v3:WaitForChild(p1, 10) else v3

	if not v4 then
		warn((("[WeatherEffects] SceneFX \'%*\' not found in model.fx"):format(p1)))

		return
	end

	local t = {}

	if v4:IsA("PostEffect") or v4:IsA("Sky") then
		table.insert(t, v4)
	else
		for v5, v6 in v4:GetChildren() do
			table.insert(t, v6)
		end
	end

	local v7 = if p3 and p3 > 0 then p3 else nil

	for v8, v9 in t do
		if v9:IsA("PostEffect") or (v9:IsA("Sky") or v9:IsA("Atmosphere")) then
			local v10 = v9:Clone()

			if v10:IsA("BloomEffect") then
				v10.Enabled = true
				v10.Intensity = v10.Intensity * (p2 or 0.25)

				if v7 then
					local Intensity = v10.Intensity

					v10.Intensity = 0
					TweenService:Create(v10, TweenInfo.new(v7, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
						Intensity = Intensity
					}):Play()
				end
			elseif v10:IsA("BlurEffect") then
				v10.Enabled = true

				if v7 then
					local Size = v10.Size

					v10.Size = 0
					TweenService:Create(v10, TweenInfo.new(v7, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
						Size = Size
					}):Play()
				end
			elseif v10:IsA("ColorCorrectionEffect") then
				v10.Enabled = true

				if v7 then
					local Brightness = v10.Brightness
					local Contrast = v10.Contrast
					local Saturation = v10.Saturation
					local TintColor = v10.TintColor
					local v11 = Color3.new(255/255, 255/255, 255/255)

					v10.Brightness = 0
					v10.Contrast = 0
					v10.Saturation = 0
					v10.TintColor = v11
					TweenService:Create(v10, TweenInfo.new(v7, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
						Brightness = Brightness,
						Contrast = Contrast,
						Saturation = Saturation,
						TintColor = TintColor
					}):Play()
				end
			elseif v10:IsA("PostEffect") then
				v10.Enabled = true
			elseif v10:IsA("Sky") then
				for v12, v13 in Lighting:GetChildren() do
					if v13:IsA("Sky") and (v13 ~= v10 and not table.find(t5, v13)) then
						table.insert(t5, v13)
						v13.Parent = nil
					end
				end
			end

			table.insert(t4, v10)
			v10.Parent = Lighting
		end
	end

	v23 = p1
end

local function clearWorldFX() --[[ clearWorldFX | Line: 883 | Upvalues: v24 (ref), v25 (ref) ]]
	if not v24 then
		v25 = nil

		return
	end

	v24:Destroy()
	v24 = nil
	v25 = nil
end

local function applyWorldFX(p1) --[[ applyWorldFX | Line: 891 | Upvalues: v25 (ref), v24 (ref), ReplicatedStorage (copy), Workspace (copy) ]]
	if v25 == p1 then
		return
	end

	if v24 then
		v24:Destroy()
		v24 = nil
	end

	v25 = nil

	if not p1 then
		return
	end

	local v1 = ReplicatedStorage:WaitForChild("shared", 10)
	local v2 = if v1 then v1:WaitForChild("model", 10) else v1
	local v3 = v2 and v2:WaitForChild("fx", 10)
	local v4 = if v3 then v3:FindFirstChild(p1, true) else v3

	if not v4 then
		warn((("[WeatherEffects] WorldFX \'%*\' not found in model.fx"):format(p1)))

		return
	end

	local v5 = nil

	if v4:IsA("BasePart") then
		v5 = v4
	elseif v4:IsA("ParticleEmitter") and (v4.Parent and v4.Parent:IsA("BasePart")) then
		v5 = v4.Parent
	end

	if not v5 then
		warn((("[WeatherEffects] WorldFX \'%*\' has no BasePart host to anchor a position to"):format(p1)))

		return
	end

	local v6 = v5:Clone()

	v6.Anchored = true
	v6.CanCollide = false
	v6.CanQuery = false
	v6.CanTouch = false
	v6.CastShadow = false
	v6.Transparency = 1

	for v7, v8 in v6:GetDescendants() do
		if v8:IsA("ParticleEmitter") then
			v8.Enabled = true

			continue
		end

		if v8:IsA("Sound") then
			v8:Destroy()
		end
	end

	v6.CFrame = v5.CFrame
	v6.Parent = Workspace
	v24 = v6
	v25 = p1
end

local function playWaterFx(p1, p2, p3) --[[ playWaterFx | Line: 954 ]]
	local t = {}

	if p1:IsA("ParticleEmitter") then
		table.insert(t, p1)
	end

	for v1, v2 in p1:GetDescendants() do
		if v2:IsA("ParticleEmitter") then
			table.insert(t, v2)
		end
	end

	local v3 = 0

	for v4, v5 in t do
		if p3 then
			v5.Enabled = false

			local v6 = math.max(v3, v5.Lifetime.Max)

			v5:Emit(p3)
			v3 = v6

			continue
		end

		if v5.Enabled then
			v5.Rate = v5.Rate * p2

			local v8 = math.max(v3, 4 + v5.Lifetime.Max)

			task.delay(4, function() --[[ Line: 977 | Upvalues: v5 (copy) ]]
				if not v5.Parent then
					return
				end

				v5.Enabled = false
			end)
			v3 = v8

			continue
		end

		local v9 = v5:GetAttribute("EmitDelay")
		local v10 = if typeof(v9) == "number" then v9 else 0
		local v11 = v5:GetAttribute("EmitCount")
		local v12 = if typeof(v11) == "number" then v11 else 1
		local v14 = math.max(v3, v10 + v5.Lifetime.Max)

		if v10 > 0 then
			task.delay(v10, function() --[[ Line: 991 | Upvalues: v5 (copy), v12 (copy) ]]
				if not v5.Parent then
					return
				end

				v5:Emit(v12)
			end)
			v3 = v14

			continue
		end

		v5:Emit(v12)
		v3 = v14
	end

	for v15, v16 in p1:GetDescendants() do
		if v16:IsA("Trail") then
			v3 = math.max(v3, v16.Lifetime)
		end
	end

	return v3
end

local function resolveWaterFxTemplate(p1) --[[ resolveWaterFxTemplate | Line: 1014 | Upvalues: ReplicatedStorage (copy) ]]
	local v1 = ReplicatedStorage:WaitForChild("shared", 10)
	local v2 = if v1 then v1:WaitForChild("model", 10) else v1
	local v3 = v2 and v2:WaitForChild("fx", 10)
	local v4 = if v3 then v3:FindFirstChild(p1, true) else v3

	if not v4 then
		warn((("[WeatherEffects] WaterFX \'%*\' not found in model.fx"):format(p1)))

		return nil, nil
	end

	local v5 = if v4:IsA("ParticleEmitter") and (v4.Parent and v4.Parent:IsA("BasePart")) then v4.Parent else v4

	if v5:IsA("BasePart") then
		return v5, v5.Position
	end

	if v5:IsA("Model") then
		return v5, v5:GetPivot().Position
	end

	warn((("[WeatherEffects] WaterFX \'%*\' has no BasePart/Model host to read a position from"):format(p1)))

	return nil, nil
end

local function scaleNumberSequence(p1, p2) --[[ scaleNumberSequence | Line: 1034 ]]
	local t = {}

	for v1, v2 in p1.Keypoints do
		table.insert(t, NumberSequenceKeypoint.new(v2.Time, v2.Value * p2, v2.Envelope * p2))
	end

	return NumberSequence.new(t)
end

local function scaleWaterFxClone(p1, p2) --[[ scaleWaterFxClone | Line: 1045 | Upvalues: scaleNumberSequence (copy) ]]
	if p1:IsA("Model") then
		p1:ScaleTo(p2)

		return
	end

	if p1:IsA("BasePart") and (p1:IsA("MeshPart") or p1:FindFirstChildWhichIsA("SpecialMesh")) then
		p1.Size = p1.Size * p2
	end

	local t = {}

	if p1:IsA("ParticleEmitter") then
		table.insert(t, p1)
	end

	for v1, v2 in p1:GetDescendants() do
		if v2:IsA("ParticleEmitter") then
			table.insert(t, v2)
		end
	end

	for v3, v4 in t do
		v4.Size = scaleNumberSequence(v4.Size, p2)
	end
end

local function spawnWaterFx(p1, p2, p3, p4, p5, p6) --[[ spawnWaterFx | Line: 1072 | Upvalues: Workspace (copy), scaleWaterFxClone (copy), RunService (copy), playWaterFx (copy), Debris (copy) ]]
	local v1 = p1:Clone()

	if v1:IsA("BasePart") then
		v1.Anchored = true
		v1.CanCollide = false
		v1.CanQuery = false
		v1.CanTouch = false
		v1.CastShadow = false
		v1.Transparency = 1
		v1.CFrame = CFrame.new(p2) * v1.CFrame.Rotation
		v1.Parent = Workspace
	else
		for v2, v3 in v1:GetDescendants() do
			if v3:IsA("BasePart") then
				v3.Anchored = true
				v3.CanCollide = false
			end
		end

		v1.Parent = Workspace
		v1:PivotTo(CFrame.new(p2) * v1:GetPivot().Rotation)
	end

	local v4 = v1

	if p4 ~= 1 then
		scaleWaterFxClone(v4, p4)
	end

	if p5 then
		if v4:IsA("ParticleEmitter") then
			v4.Lifetime = NumberRange.new(p5)
		end

		for v5, v6 in v4:GetDescendants() do
			if v6:IsA("ParticleEmitter") then
				v6.Lifetime = NumberRange.new(p5)
			end
		end
	end

	task.spawn(function() --[[ Line: 1121 | Upvalues: RunService (ref), playWaterFx (ref), v4 (ref), p3 (copy), p6 (copy), Debris (ref) ]]
		RunService.Heartbeat:Wait()
		Debris:AddItem(v4, playWaterFx(v4, p3, p6) + 1)
	end)
end

local function stopWaterFx() --[[ stopWaterFx | Line: 1128 | Upvalues: v26 (ref), v27 (ref) ]]
	v26 = false
	v27 = v27 + 1
end

local function startWaterFx(p1) --[[ startWaterFx | Line: 1149 | Upvalues: v26 (ref), v27 (ref), resolveWaterFxTemplate (copy), spawnWaterFx (copy) ]]
	if v26 then
		return
	end

	v26 = true
	v27 = v27 + 1

	local v1 = v27

	for v2, v3 in p1 do
		task.spawn(function() --[[ Line: 1157 | Upvalues: resolveWaterFxTemplate (ref), v3 (copy), spawnWaterFx (ref), v26 (ref), v27 (ref), v1 (copy) ]]
			local v12, v2 = resolveWaterFxTemplate(v3.Name)

			if not (v12 and v2) then
				return
			end

			local v32 = v3.Count or 1
			local v4 = v3.Spread or 25
			local v5 = v3.RateMult or 2
			local ScaleMin = v3.ScaleMin
			local ScaleMax = v3.ScaleMax
			local Lifetime = v3.Lifetime
			local Burst = v3.Burst

			local function spawnOne() --[[ spawnOne | Line: 1169 | Upvalues: v4 (copy), ScaleMin (copy), ScaleMax (copy), spawnWaterFx (ref), v12 (copy), v2 (copy), v5 (copy), Lifetime (copy), Burst (copy) ]]
				local v1 = (math.random() * 2 - 1) * v4
				local v22 = (math.random() * 2 - 1) * v4
				local v3 = if ScaleMin and ScaleMax then ScaleMin + math.random() * (ScaleMax - ScaleMin) else 1

				spawnWaterFx(v12, Vector3.new(v2.X + v1, v2.Y, v2.Z + v22), v5, v3, Lifetime, Burst)
			end

			if v3.Stagger then
				local v6 = v3.Interval / v32

				while v26 and v27 == v1 do
					spawnOne()
					task.wait(v6 * (0.5 + math.random()))
				end
			else
				while v26 and v27 == v1 do
					for i = 1, v32 do
						spawnOne()
					end

					task.wait(v3.Interval)
				end
			end
		end)
	end
end

local function applyWaterFx(p1) --[[ applyWaterFx | Line: 1205 | Upvalues: startWaterFx (copy), v26 (ref), v27 (ref) ]]
	if p1 then
		startWaterFx(p1)
	else
		v26 = false
		v27 = v27 + 1
	end
end

local function propParts(p1) --[[ propParts | Line: 1214 ]]
	local t = {}

	if p1:IsA("BasePart") then
		table.insert(t, p1)
	end

	for v1, v2 in p1:GetDescendants() do
		if v2:IsA("BasePart") then
			table.insert(t, v2)
		end
	end

	return t
end

local function buildPropModel(p1) --[[ buildPropModel | Line: 1229 | Upvalues: propParts (copy) ]]
	local v1 = p1:Clone()

	for v2, v3 in propParts(v1) do
		v3.Anchored = true
		v3.CanCollide = false
	end

	local Model = Instance.new("Model")

	v1.Parent = Model
	Model.PrimaryPart = if v1:IsA("BasePart") then v1 else v1:FindFirstChildWhichIsA("BasePart", true)

	return Model
end

local function groundProp(p1, p2, p3, p4) --[[ groundProp | Line: 1243 ]]
	p1:ScaleTo(p4)
	p1:PivotTo(CFrame.new(p1:GetPivot().Position) * CFrame.Angles(0, p3, 0))

	local v1, v2 = p1:GetBoundingBox()
	local v4 = Vector3.new(v1.Position.X, v1.Position.Y - v2.Y / 2, v1.Position.Z)

	p1:PivotTo(p1:GetPivot() + (p2 - v4))
	p1.WorldPivot = CFrame.new(p2) * p1:GetPivot().Rotation
end

local function growProp(p1, p2) --[[ growProp | Line: 1255 | Upvalues: RunService (copy) ]]
	local v1 = p1:GetPivot()

	p1:ScaleTo(0.05)
	p1:PivotTo(v1 - Vector3.new(0, 4, 0))
	task.spawn(function() --[[ Line: 1259 | Upvalues: p1 (copy), RunService (ref), p2 (copy), v1 (copy) ]]
		local sum = 0

		while sum < 5 and p1.Parent do
			if p1:GetAttribute("WxShrinking") then
				break
			end

			sum = sum + RunService.Heartbeat:Wait()

			local v12 = math.min(sum / 5, 1)

			p1:ScaleTo((math.max((p2 - 0.05) * v12 + 0.05, 0.01)))
			p1:PivotTo(v1 - Vector3.new(0, (1 - v12) * 4, 0))
		end
	end)
end

local function spawnOneIceProp(p1) --[[ spawnOneIceProp | Line: 1274 | Upvalues: ReplicatedStorage (copy), v28 (ref), Workspace (copy), t6 (copy), Players (copy), buildPropModel (copy), groundProp (copy), growProp (copy) ]]
	local v1 = ReplicatedStorage:WaitForChild("shared", 10)
	local v2 = if v1 then v1:WaitForChild("model", 10) else v1
	local v3 = v2 and v2:WaitForChild("fx", 10)
	local v4 = if v3 then v3:FindFirstChild("Ice_Trail") else v3

	if not v4 then
		warn("[WeatherEffects] Ice prop template \'Ice_Trail\' not found in model.fx")

		return
	end

	if not v28 then
		local WeatherIceProps = Instance.new("Folder")

		WeatherIceProps.Name = "WeatherIceProps"
		WeatherIceProps.Parent = Workspace
		v28 = WeatherIceProps
		table.clear(t6)
	end

	local v5 = v28
	local t = { v5 }
	local Character = Players.LocalPlayer.Character

	if Character then
		table.insert(t, Character)
	end

	local v6 = RaycastParams.new()

	v6.FilterType = Enum.RaycastFilterType.Exclude
	v6.FilterDescendantsInstances = t

	local v7 = nil

	for i = 1, 14 do
		local v8 = math.random() * 2 * math.pi
		local v10 = math.sqrt((math.random())) * 104 + 16
		local v11 = p1.X + math.cos(v8) * v10
		local v12 = p1.Z + math.sin(v8) * v10
		local v13 = false

		for v14, v15 in t6 do
			local v16 = v11 - v15.X
			local v17 = v12 - v15.Z

			if v16 * v16 + v17 * v17 < 576 then
				v13 = true

				break
			end
		end

		if not v13 then
			local v19 = Workspace:Raycast(Vector3.new(v11, p1.Y + 60, v12), Vector3.new(0, -220, 0), v6)

			v7 = v19

			if v19 then
				break
			end
		end
	end

	if v7 then
		table.insert(t6, v7.Position)

		local v21 = 0.5 + math.random() * 1
		local v22 = buildPropModel(v4)

		groundProp(v22, v7.Position, math.random() * 2 * math.pi, v21)
		v22.Parent = v5
		growProp(v22, v21)
	end
end

local function shrinkAndSink(p1) --[[ shrinkAndSink | Line: 1338 | Upvalues: RunService (copy) ]]
	p1:SetAttribute("WxShrinking", true)

	local v1 = p1:GetScale()
	local v2 = p1:GetPivot()

	task.spawn(function() --[[ Line: 1342 | Upvalues: p1 (copy), RunService (ref), v1 (copy), v2 (copy) ]]
		local sum = 0

		while sum < 5 and p1.Parent do
			sum = sum + RunService.Heartbeat:Wait()

			local v12 = math.min(sum / 5, 1)

			p1:ScaleTo((math.max(v1 + (0.05 - v1) * v12, 0.01)))
			p1:PivotTo(v2 - Vector3.new(0, v12 * 4, 0))
		end

		if not p1.Parent then
			return
		end

		p1:Destroy()
	end)
end

local function stopIceProps() --[[ stopIceProps | Line: 1356 | Upvalues: v29 (ref), v30 (ref), v28 (ref), t6 (copy), shrinkAndSink (copy), Debris (copy) ]]
	v29 = false
	v30 = v30 + 1

	local v1 = v28

	v28 = nil
	table.clear(t6)

	if not v1 then
		return
	end

	for v2, v3 in v1:GetChildren() do
		if v3:IsA("Model") then
			for v4, v5 in v3:GetDescendants() do
				if v5:IsA("ParticleEmitter") or v5:IsA("Trail") then
					v5.Enabled = false
				end
			end

			shrinkAndSink(v3)
		end
	end

	Debris:AddItem(v1, 5.5)
end

local function startIceProps() --[[ startIceProps | Line: 1377 | Upvalues: v29 (ref), v30 (ref), Players (copy), Workspace (copy), spawnOneIceProp (copy) ]]
	if not v29 then
		v29 = true
		v30 = v30 + 1

		local v1 = v30

		task.spawn(function() --[[ Line: 1386 | Upvalues: Players (ref), Workspace (ref), v29 (ref), v30 (ref), v1 (copy), spawnOneIceProp (ref) ]]
			task.wait(5)

			local Character = Players.LocalPlayer.Character
			local v12 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character
			local v2

			if v12 then
				v2 = v12.Position
			else
				local CurrentCamera = Workspace.CurrentCamera

				v2 = if CurrentCamera then CurrentCamera.CFrame.Position else nil
			end

			if not v2 then
				return
			end

			for i = 1, 20 do
				if not v29 or v30 ~= v1 then
					break
				end

				spawnOneIceProp(v2)
				task.wait(1)
			end
		end)
	end
end

local function applyIceProps(p1) --[[ applyIceProps | Line: 1402 | Upvalues: v29 (ref), v30 (ref), Players (copy), Workspace (copy), spawnOneIceProp (copy), stopIceProps (copy) ]]
	if not p1 then
		stopIceProps()

		return
	end

	if not v29 then
		v29 = true
		v30 = v30 + 1

		local v1 = v30

		task.spawn(function() --[[ Line: 1386 | Upvalues: Players (ref), Workspace (ref), v29 (ref), v30 (ref), v1 (copy), spawnOneIceProp (ref) ]]
			task.wait(5)

			local Character = Players.LocalPlayer.Character
			local v12 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character
			local v2

			if v12 then
				v2 = v12.Position
			else
				local CurrentCamera = Workspace.CurrentCamera

				v2 = if CurrentCamera then CurrentCamera.CFrame.Position else nil
			end

			if not v2 then
				return
			end

			for i = 1, 20 do
				if not v29 or v30 ~= v1 then
					break
				end

				spawnOneIceProp(v2)
				task.wait(1)
			end
		end)
	end
end

local function applyWater(p1) --[[ applyWater | Line: 1411 | Upvalues: Workspace (copy), TweenService (copy), v32 (ref) ]]
	local Terrain = Workspace:FindFirstChildOfClass("Terrain")

	if not Terrain then
		return
	end

	local Water = p1.Water

	if Water then
		TweenService:Create(Terrain, TweenInfo.new(3, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
			WaterColor = Water.Color,
			WaterReflectance = Water.Reflectance,
			WaterTransparency = Water.Transparency
		}):Play()

		return
	end

	if not v32 then
		return
	end

	TweenService:Create(Terrain, TweenInfo.new(3, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
		WaterColor = v32.Color,
		WaterReflectance = v32.Reflectance,
		WaterTransparency = v32.Transparency
	}):Play()
end

local function repositionAmbient() --[[ repositionAmbient | Line: 1433 | Upvalues: v33 (ref), Players (copy), Workspace (copy) ]]
	local v1 = v33

	if not v1 then
		return
	end

	local Character = Players.LocalPlayer.Character
	local v2 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character
	local v3

	if v2 then
		v3 = v2.Position
	else
		local CurrentCamera = Workspace.CurrentCamera

		v3 = if CurrentCamera then CurrentCamera.CFrame.Position else nil
	end

	if v3 then
		v1.CFrame = CFrame.new(v3.X, v3.Y + 15, v3.Z)
	end
end

local function destroyAmbient() --[[ destroyAmbient | Line: 1445 | Upvalues: v35 (ref), v33 (ref), v34 (ref) ]]
	if v35 then
		v35:Disconnect()
		v35 = nil
	end

	if v33 then
		v33:Destroy()
		v33 = nil
	end

	v34 = nil
end

local function ensureAmbientLayer() --[[ ensureAmbientLayer | Line: 1457 | Upvalues: v34 (ref), Players (copy), Workspace (copy), v33 (ref), v35 (ref), RunService (copy) ]]
	if v34 then
		return v34
	end

	local Character = Players.LocalPlayer.Character
	local v1 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character
	local v2

	if v1 then
		v2 = v1.Position
	else
		local CurrentCamera = Workspace.CurrentCamera

		v2 = if CurrentCamera then CurrentCamera.CFrame.Position else nil
	end

	if not v2 then
		return nil
	end

	local WeatherAmbient = Instance.new("Part")

	WeatherAmbient.Name = "WeatherAmbient"
	WeatherAmbient.Anchored = true
	WeatherAmbient.CanCollide = false
	WeatherAmbient.CanQuery = false
	WeatherAmbient.CanTouch = false
	WeatherAmbient.CastShadow = false
	WeatherAmbient.Transparency = 1
	WeatherAmbient.Size = Vector3.new(120, 60, 120)

	local Ambient = Instance.new("ParticleEmitter")

	Ambient.Name = "Ambient"
	Ambient.Enabled = false
	Ambient.Parent = WeatherAmbient
	WeatherAmbient.Parent = Workspace
	v33 = WeatherAmbient
	v34 = Ambient

	local v3 = v33

	if v3 then
		local Character2 = Players.LocalPlayer.Character
		local v4 = if Character2 then Character2:FindFirstChild("HumanoidRootPart") else Character2
		local v5

		if v4 then
			v5 = v4.Position
		else
			local CurrentCamera = Workspace.CurrentCamera

			v5 = if CurrentCamera then CurrentCamera.CFrame.Position else nil
		end

		if v5 then
			v3.CFrame = CFrame.new(v5.X, v5.Y + 15, v5.Z)
		end
	end

	local v6 = 0

	v35 = RunService.Heartbeat:Connect(function(p1) --[[ Line: 1486 | Upvalues: v6 (ref), v33 (ref), Players (ref), Workspace (ref) ]]
		debug.profilebegin("UECS/WeatherEffects.AmbientFollow")
		v6 = v6 + p1

		if not (v6 < 0.1) then
			v6 = 0

			local v1 = v33

			if v1 then
				local Character = Players.LocalPlayer.Character
				local v2 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character
				local v3

				if v2 then
					v3 = v2.Position
				else
					local CurrentCamera = Workspace.CurrentCamera

					v3 = if CurrentCamera then CurrentCamera.CFrame.Position else nil
				end

				if v3 then
					v1.CFrame = CFrame.new(v3.X, v3.Y + 15, v3.Z)
				end
			end
		end

		debug.profileend()
	end)

	return Ambient
end

local function applyAmbient(p1) --[[ applyAmbient | Line: 1500 | Upvalues: v35 (ref), v33 (ref), v34 (ref), ensureAmbientLayer (copy) ]]
	local Ambient = p1.Ambient

	if Ambient then
		local v1 = ensureAmbientLayer()

		if not v1 then
			return
		end

		v1.Texture = Ambient.Texture or "rbxasset://textures/particles/sparkles_main.dds"
		v1.Color = Ambient.Color
		v1.Rate = Ambient.Rate
		v1.Lifetime = NumberRange.new(Ambient.Lifetime * 0.7, Ambient.Lifetime)
		v1.Speed = NumberRange.new((math.abs(Ambient.Drift)))
		v1.EmissionDirection = if Ambient.Drift >= 0 then Enum.NormalId.Top else Enum.NormalId.Bottom
		v1.Acceleration = Vector3.new(0, if Ambient.Drift >= 0 then 1 else -3, 0)
		v1.SpreadAngle = Vector2.new(Ambient.Spread, Ambient.Spread)
		v1.LightEmission = Ambient.LightEmission
		v1.Rotation = NumberRange.new(0, 360)
		v1.RotSpeed = if Ambient.Spin then NumberRange.new(-120, 120) else NumberRange.new(0, 0)
		v1.Size = NumberSequence.new(Ambient.Size)
		v1.Transparency = NumberSequence.new({
			NumberSequenceKeypoint.new(0, 1),
			NumberSequenceKeypoint.new(0.2, 0.1),
			NumberSequenceKeypoint.new(0.8, 0.2),
			NumberSequenceKeypoint.new(1, 1)
		})
		v1.Enabled = true
	else
		if v35 then
			v35:Disconnect()
			v35 = nil
		end

		if v33 then
			v33:Destroy()
			v33 = nil
		end

		v34 = nil
	end
end

local function buildMoteLayer(p1, p2) --[[ buildMoteLayer | Line: 1551 | Upvalues: Workspace (copy) ]]
	local v1 = p1:Clone()

	v1.Anchored = true
	v1.CanCollide = false
	v1.CanQuery = false
	v1.CanTouch = false
	v1.CastShadow = false
	v1.Transparency = 1
	v1.Size = p2

	for v2, v3 in v1:GetDescendants() do
		if v3:IsA("ParticleEmitter") then
			v3.Enabled = true
			v3.LockedToPart = false
			v3.Rate = v3.Rate * 3
			v3.EmissionDirection = Enum.NormalId.Top

			if v3.Acceleration.Y <= 0 then
				v3.Acceleration = Vector3.new(v3.Acceleration.X, 1.5, v3.Acceleration.Z)
			end

			if v3.Speed.Max <= 0 then
				v3.Speed = NumberRange.new(2)
			end

			continue
		end

		if v3:IsA("Sound") then
			v3:Destroy()
		end
	end

	v1.Parent = Workspace

	return v1
end

local function repositionMoteVolume() --[[ repositionMoteVolume | Line: 1581 | Upvalues: v36 (ref), Players (copy), Workspace (copy) ]]
	local v1 = v36

	if not v1 then
		return
	end

	local Character = Players.LocalPlayer.Character
	local v2 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character
	local v3

	if v2 then
		v3 = v2.Position
	else
		local CurrentCamera = Workspace.CurrentCamera

		v3 = if CurrentCamera then CurrentCamera.CFrame.Position else nil
	end

	if v3 then
		v1.CFrame = CFrame.new(v3.X, v3.Y + 30, v3.Z)
	end
end

local function dropNearMotes(p1) --[[ dropNearMotes | Line: 1596 | Upvalues: Workspace (copy), buildMoteLayer (copy), Debris (copy) ]]
	local CurrentCamera = Workspace.CurrentCamera

	if not CurrentCamera then
		return
	end

	local LookVector = CurrentCamera.CFrame.LookVector
	local v1 = Vector3.new(LookVector.X, 0, LookVector.Z)
	local v2 = if v1.Magnitude > 0.01 then v1.Unit else Vector3.new(0, 0, 0)
	local v3 = buildMoteLayer(p1, Vector3.new(30, 30, 30))

	v3.CFrame = CFrame.new(CurrentCamera.CFrame.Position + v2 * 14)

	local v4 = 0

	for v5, v6 in v3:GetDescendants() do
		if v6:IsA("ParticleEmitter") then
			v4 = math.max(v4, v6.Lifetime.Max)
		end
	end

	task.delay(1.2, function() --[[ Line: 1616 | Upvalues: v3 (copy) ]]
		for v1, v2 in v3:GetDescendants() do
			if v2:IsA("ParticleEmitter") then
				v2.Enabled = false
			end
		end
	end)
	Debris:AddItem(v3, v4 + 1.2 + 0.5)
end

local function stopNearMotes() --[[ stopNearMotes | Line: 1626 | Upvalues: v38 (ref), v39 (ref) ]]
	v38 = false
	v39 = v39 + 1
end

local function startNearMotes(p1) --[[ startNearMotes | Line: 1631 | Upvalues: v38 (ref), v39 (ref), dropNearMotes (copy) ]]
	if not v38 then
		v38 = true
		v39 = v39 + 1

		local v1 = v39

		task.spawn(function() --[[ Line: 1638 | Upvalues: v38 (ref), v39 (ref), v1 (copy), dropNearMotes (ref), p1 (copy) ]]
			while v38 and v39 == v1 do
				dropNearMotes(p1)
				task.wait(0.6)
			end
		end)
	end
end

local function destroyAmbientFx() --[[ destroyAmbientFx | Line: 1646 | Upvalues: v37 (ref), v36 (ref), v38 (ref), v39 (ref) ]]
	if v37 then
		v37:Disconnect()
		v37 = nil
	end

	if v36 then
		v36:Destroy()
		v36 = nil
	end

	v38 = false
	v39 = v39 + 1
end

local function applyAmbientFx(p1) --[[ applyAmbientFx | Line: 1658 | Upvalues: v40 (ref), v37 (ref), v36 (ref), v38 (ref), v39 (ref), ReplicatedStorage (copy), buildMoteLayer (copy), Players (copy), Workspace (copy), RunService (copy), dropNearMotes (copy) ]]
	if v40 == p1 then
		return
	end

	if v37 then
		v37:Disconnect()
		v37 = nil
	end

	if v36 then
		v36:Destroy()
		v36 = nil
	end

	v38 = false
	v39 = v39 + 1
	v40 = p1

	if not p1 then
		return
	end

	local v1 = ReplicatedStorage:WaitForChild("shared", 10)
	local v2 = if v1 then v1:WaitForChild("model", 10) else v1
	local v3 = if v2 then v2:WaitForChild("fx", 10) else v2
	local v4 = if v3 then v3:FindFirstChild(p1, true) else v3

	if not v4 then
		warn((("[WeatherEffects] AmbientFX \'%*\' not found in model.fx"):format(p1)))
		v40 = nil

		return
	end

	local v5 = nil

	if v4:IsA("BasePart") then
		v5 = v4
	elseif v4:IsA("ParticleEmitter") and (v4.Parent and v4.Parent:IsA("BasePart")) then
		v5 = v4.Parent
	end

	if not v5 then
		warn((("[WeatherEffects] AmbientFX \'%*\' has no BasePart host to emit motes from"):format(p1)))
		v40 = nil

		return
	end

	v36 = buildMoteLayer(v5, Vector3.new(120, 70, 120))

	local v6 = v36

	if v6 then
		local Character = Players.LocalPlayer.Character
		local v7 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character
		local v8

		if v7 then
			v8 = v7.Position
		else
			local CurrentCamera = Workspace.CurrentCamera

			v8 = if CurrentCamera then CurrentCamera.CFrame.Position else nil
		end

		if v8 then
			v6.CFrame = CFrame.new(v8.X, v8.Y + 30, v8.Z)
		end
	end

	local v9 = 0

	v37 = RunService.Heartbeat:Connect(function(p1) --[[ Line: 1695 | Upvalues: v9 (ref), v36 (ref), Players (ref), Workspace (ref) ]]
		debug.profilebegin("UECS/WeatherEffects.AmbientFxFollow")
		v9 = v9 + p1

		if v9 >= 0.1 then
			v9 = 0

			local v1 = v36

			if v1 then
				local Character = Players.LocalPlayer.Character
				local v2 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character
				local v3

				if v2 then
					v3 = v2.Position
				else
					local CurrentCamera = Workspace.CurrentCamera

					v3 = if CurrentCamera then CurrentCamera.CFrame.Position else nil
				end

				if v3 then
					v1.CFrame = CFrame.new(v3.X, v3.Y + 30, v3.Z)
				end
			end
		end

		debug.profileend()
	end)

	local v10 = v5

	if not v38 then
		v38 = true
		v39 = v39 + 1

		local v11 = v39

		task.spawn(function() --[[ Line: 1638 | Upvalues: v38 (ref), v39 (ref), v11 (copy), dropNearMotes (ref), v10 (copy) ]]
			while v38 and v39 == v11 do
				dropNearMotes(v10)
				task.wait(0.6)
			end
		end)
	end
end

local function playBreath(p1) --[[ playBreath | Line: 1711 | Upvalues: VFX (copy), Debris (copy) ]]
	local v1 = VFX.Attach("FrozenBreath_fx", p1)

	if not v1 then
		return
	end

	local t = {}

	for v2, v3 in v1:GetDescendants() do
		if v3:IsA("ParticleEmitter") then
			table.insert(t, v3)
		end
	end

	local v4 = 0.5

	for v5, v6 in t do
		local v7 = (v5 - 1) * 0.2
		local Enabled = v6.Enabled

		v6.Enabled = false

		if Enabled then
			local v9 = math.max(v4, v7 + 0.4 + v6.Lifetime.Max)

			task.delay(v7, function() --[[ Line: 1731 | Upvalues: v6 (copy) ]]
				if not v6.Parent then
					return
				end

				v6.Enabled = true
			end)
			task.delay(v7 + 0.4, function() --[[ Line: 1736 | Upvalues: v6 (copy) ]]
				if not v6.Parent then
					return
				end

				v6.Enabled = false
			end)
			v4 = v9

			continue
		end

		local v10 = v6:GetAttribute("EmitCount")
		local v11 = if typeof(v10) == "number" then v10 else 1
		local v13 = math.max(v4, v7 + v6.Lifetime.Max)

		task.delay(v7, function() --[[ Line: 1746 | Upvalues: v6 (copy), v11 (copy) ]]
			if not v6.Parent then
				return
			end

			v6:Emit(v11)
		end)
		v4 = v13
	end

	Debris:AddItem(v1, v4 + 0.5)
end

local function stopBreath() --[[ stopBreath | Line: 1760 | Upvalues: v41 (ref), v42 (ref) ]]
	v41 = false
	v42 = v42 + 1
end

local function startBreath() --[[ startBreath | Line: 1765 | Upvalues: v41 (ref), v42 (ref), Players (copy), playBreath (copy), SFX (copy) ]]
	if not v41 then
		v41 = true
		v42 = v42 + 1

		local v1 = v42

		task.spawn(function() --[[ Line: 1772 | Upvalues: v41 (ref), v42 (ref), v1 (copy), Players (ref), playBreath (ref), SFX (ref) ]]
			while v41 and v42 == v1 do
				local Character = Players.LocalPlayer.Character
				local v12 = if Character then Character:FindFirstChild("Head") else Character

				if v12 then
					playBreath(v12)

					local FrozenBreath = SFX.Sounds.FrozenBreath

					if FrozenBreath and FrozenBreath ~= "" then
						SFX.PlaySoundWithRandomPitchAtPart(FrozenBreath, v12, 0.5, 0.95, 1.05)
					end
				end

				task.wait(4)
			end
		end)
	end
end

local function applyBreath(p1) --[[ applyBreath | Line: 1788 | Upvalues: v41 (ref), v42 (ref), Players (copy), playBreath (copy), SFX (copy) ]]
	if not p1 then
		v41 = false
		v42 = v42 + 1

		return
	end

	if not v41 then
		v41 = true
		v42 = v42 + 1

		local v1 = v42

		task.spawn(function() --[[ Line: 1772 | Upvalues: v41 (ref), v42 (ref), v1 (copy), Players (ref), playBreath (ref), SFX (ref) ]]
			while v41 and v42 == v1 do
				local Character = Players.LocalPlayer.Character
				local v12 = if Character then Character:FindFirstChild("Head") else Character

				if v12 then
					playBreath(v12)

					local FrozenBreath = SFX.Sounds.FrozenBreath

					if FrozenBreath and FrozenBreath ~= "" then
						SFX.PlaySoundWithRandomPitchAtPart(FrozenBreath, v12, 0.5, 0.95, 1.05)
					end
				end

				task.wait(4)
			end
		end)
	end
end

local v46 = nil
local v47 = false
local v48 = 0
local t7 = {}

local function stopShiver() --[[ stopShiver | Line: 1811 | Upvalues: v43 (ref), v44 (ref), v47 (ref), v48 (ref), t7 (copy), v46 (ref) ]]
	v43 = false
	v44 = v44 + 1
	v47 = false
	v48 = 0
	table.clear(t7)

	if not v46 then
		return
	end

	v46:Disconnect()
	v46 = nil
end

local function startShiver() --[[ startShiver | Line: 1823 | Upvalues: v43 (ref), v44 (ref), v48 (ref), v46 (ref), RunService (copy), v47 (ref), Players (copy), t7 (copy) ]]
	if not v43 then
		v43 = true
		v44 = v44 + 1

		local v1 = v44

		v48 = 0
		v46 = RunService.Heartbeat:Connect(function(p1) --[[ Line: 1833 | Upvalues: v47 (ref), v48 (ref), Players (ref), t7 (ref) ]]
			debug.profilebegin("UECS/WeatherEffects.Shiver")

			if v47 then
				v48 = v48 + p1

				for v1, v2 in Players:GetPlayers() do
					local Character = v2.Character

					if Character then
						local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")

						if HumanoidRootPart then
							if not t7[Character] then
								t7[Character] = math.random() * math.pi * 2
							end

							HumanoidRootPart.CFrame = HumanoidRootPart.CFrame * CFrame.Angles(0, math.sin((v48 * 12 + t7[Character]) * math.pi * 2) * 0.02, 0)
						end
					end
				end
			end

			debug.profileend()
		end)
		task.spawn(function() --[[ Line: 1861 | Upvalues: v43 (ref), v44 (ref), v1 (copy), v47 (ref), v48 (ref) ]]
			while v43 and v44 == v1 do
				v47 = true
				v48 = 0
				task.wait(1.5)
				v47 = false

				if not v43 or v44 ~= v1 then
					break
				end

				task.wait(2.5)
			end

			v47 = false
		end)
	end
end

local function applyShiver(p1) --[[ applyShiver | Line: 1876 | Upvalues: startShiver (copy), v43 (ref), v44 (ref), v47 (ref), v48 (ref), t7 (copy), v46 (ref) ]]
	if p1 then
		startShiver()

		return
	end

	v43 = false
	v44 = v44 + 1
	v47 = false
	v48 = 0
	table.clear(t7)

	if not v46 then
		return
	end

	v46:Disconnect()
	v46 = nil
end

local t8 = {
	INTERVAL = 1.8,
	AREA_RADIUS = 350,
	HEIGHT = 250,
	START_SPREAD = 70,
	FALL_TIME = 6,
	SIZE = 7,
	SCALE = 2.5,
	COLOR = Color3.fromRGB(255, 238, 170),
	MODEL = "Star",
	TRAIL_LIFETIME = 0.6,
	EXPLOSION_PARTICLES = 90,
	DEBRIS_NEON_COUNT = 8,
	DEBRIS_GREEN_COUNT = 4,
	DEBRIS_BROWN_COUNT = 8,
	DEBRIS_NEON_SIZE_MIN = 0.35,
	DEBRIS_NEON_SIZE_MAX = 0.9,
	DEBRIS_PLASTIC_SIZE_MIN = 0.6,
	DEBRIS_PLASTIC_SIZE_MAX = 1.4,
	DEBRIS_BROWN_SIZE_MIN = 1,
	DEBRIS_BROWN_SIZE_MAX = 2.2,
	DEBRIS_OUT_SPEED = 28,
	DEBRIS_UP_SPEED = 72,
	DEBRIS_GRAVITY = 110,
	DEBRIS_LIFETIME = 2.2,
	DEBRIS_NEON_COLOR = Color3.fromRGB(128, 119, 85),
	DEBRIS_BROWN_COLOR = Color3.fromRGB(102, 70, 44),
	DEBRIS_PLASTIC_FALLBACK = Color3.fromRGB(86, 145, 75),
	RAY_UP = 150,
	RAY_DOWN = 500,
	TRIES = 18,
	BARRIER_X = 83.259,
	BARRIER_KEEP_ABOVE = true,
	EARLY_STOP = 1.5,
	SFX_NAME = "FallingStars",
	SFX_RANGE = 70,
	running = false,
	gen = 0,
	endTime = nil,
	getStartArea = function() --[[ getStartArea | Line: 1930 | Upvalues: Workspace (copy) ]]
		local Map = Workspace:FindFirstChild("Map")
		local v1 = if Map then Map:FindFirstChild("StartPointFish") else Map

		if v1 and v1:IsA("BasePart") then
			return v1.Position
		end

		return nil
	end
}

function t8.build() --[[ build | Line: 1942 | Upvalues: ReplicatedStorage (copy), t8 (copy) ]]
	local v1 = ReplicatedStorage:WaitForChild("shared", 10)
	local v2 = if v1 then v1:WaitForChild("model", 10) else v1
	local v3 = v2 and v2:WaitForChild("fx", 10)
	local v4 = if v3 then v3:FindFirstChild(t8.MODEL, true) else v3
	local WeatherFallingStar, v5

	if v4 and (v4:IsA("Model") or v4:IsA("BasePart")) then
		local v6 = v4:Clone()

		if v6:IsA("Model") then
			local v7 = v6.PrimaryPart or v6:FindFirstChildWhichIsA("BasePart", true)

			WeatherFallingStar = v6

			if v7 and not v6.PrimaryPart then
				v6.PrimaryPart = v7
			end

			v5 = v7
		else
			WeatherFallingStar = v6
			v5 = v6
		end
	else
		local Part = Instance.new("Part")

		Part.Shape = Enum.PartType.Ball
		Part.Size = Vector3.new(t8.SIZE, t8.SIZE, t8.SIZE)
		Part.Material = Enum.Material.Neon
		Part.Color = t8.COLOR
		WeatherFallingStar = Part
		v5 = Part
	end

	WeatherFallingStar.Name = "WeatherFallingStar"

	if WeatherFallingStar:IsA("Model") then
		WeatherFallingStar:ScaleTo(WeatherFallingStar:GetScale() * t8.SCALE)
	end

	if WeatherFallingStar:IsA("BasePart") then
		WeatherFallingStar.Anchored = true
		WeatherFallingStar.CanCollide = false
		WeatherFallingStar.CanQuery = false
		WeatherFallingStar.CanTouch = false
		WeatherFallingStar.CastShadow = false
	end

	for v8, v9 in WeatherFallingStar:GetDescendants() do
		if v9:IsA("BasePart") then
			v9.Anchored = true
			v9.CanCollide = false
			v9.CanQuery = false
			v9.CanTouch = false
			v9.CastShadow = false
		end
	end

	if WeatherFallingStar:IsA("BasePart") and WeatherFallingStar.Material == Enum.Material.Neon then
		WeatherFallingStar.Material = Enum.Material.SmoothPlastic
	end

	for v10, v11 in WeatherFallingStar:GetDescendants() do
		if v11:IsA("Light") then
			v11:Destroy()

			continue
		end

		if v11:IsA("BasePart") and v11.Material == Enum.Material.Neon then
			v11.Material = Enum.Material.SmoothPlastic

			continue
		end

		if v11:IsA("ParticleEmitter") or (v11:IsA("Trail") or v11:IsA("Beam")) then
			v11.LightEmission = 0
		end
	end

	if not v5 then
		return WeatherFallingStar
	end

	local v12 = math.max(v5.Size.X, v5.Size.Z) * 0.15
	local Attachment = Instance.new("Attachment")

	Attachment.Position = Vector3.new(v12, 0, 0)
	Attachment.Parent = v5

	local Attachment2 = Instance.new("Attachment")

	Attachment2.Position = Vector3.new(-v12, 0, 0)
	Attachment2.Parent = v5

	local Trail = Instance.new("Trail")

	Trail.Attachment0 = Attachment
	Trail.Attachment1 = Attachment2
	Trail.Lifetime = t8.TRAIL_LIFETIME
	Trail.LightEmission = 0
	Trail.FaceCamera = true
	Trail.Color = ColorSequence.new(t8.COLOR)
	Trail.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
	Trail.WidthScale = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 0) })
	Trail.Parent = v5

	return WeatherFallingStar
end
function t8.floorColor(p1) --[[ floorColor | Line: 2042 | Upvalues: Players (copy), Workspace (copy), t8 (copy) ]]
	local v1 = RaycastParams.new()

	v1.FilterType = Enum.RaycastFilterType.Exclude
	v1.IgnoreWater = true

	local Character = Players.LocalPlayer.Character

	if Character then
		v1.FilterDescendantsInstances = { Character }
	end

	local v2 = Workspace:Raycast(p1 + Vector3.new(0, 5, 0), Vector3.new(0, -20, 0), v1)

	if not (v2 and v2.Instance) then
		return t8.DEBRIS_PLASTIC_FALLBACK
	end

	local Terrain = Workspace:FindFirstChildOfClass("Terrain")

	if Terrain and v2.Instance == Terrain then
		return Terrain:GetMaterialColor(v2.Material)
	end

	if v2.Instance:IsA("BasePart") then
		return v2.Instance.Color
	end

	return t8.DEBRIS_PLASTIC_FALLBACK
end
function t8.explodeDebris(p1) --[[ explodeDebris | Line: 2065 | Upvalues: t8 (copy), Workspace (copy), RunService (copy) ]]
	local v1 = t8.floorColor(p1)
	local t = {}
	local t2 = {}

	for i = 1, t8.DEBRIS_NEON_COUNT do
		table.insert(t, "neon")
	end

	for j = 1, t8.DEBRIS_GREEN_COUNT do
		table.insert(t, "green")
	end

	for k = 1, t8.DEBRIS_BROWN_COUNT do
		table.insert(t, "brown")
	end

	for v4, v5 in t do
		local v2, v3
		local Part = Instance.new("Part")

		Part.Anchored = true
		Part.CanCollide = false
		Part.CanQuery = false
		Part.CanTouch = false
		Part.CastShadow = false

		if v5 == "neon" then
			Part.Material = Enum.Material.Neon
			Part.Color = t8.DEBRIS_NEON_COLOR
			v2 = t8.DEBRIS_NEON_SIZE_MIN
			v3 = t8.DEBRIS_NEON_SIZE_MAX
		elseif v5 == "green" then
			Part.Material = Enum.Material.Plastic
			Part.Color = v1
			v2 = t8.DEBRIS_PLASTIC_SIZE_MIN
			v3 = t8.DEBRIS_PLASTIC_SIZE_MAX
		else
			Part.Material = Enum.Material.Plastic
			Part.Color = t8.DEBRIS_BROWN_COLOR
			v2 = t8.DEBRIS_BROWN_SIZE_MIN
			v3 = t8.DEBRIS_BROWN_SIZE_MAX
		end

		local v6 = v2 + math.random() * (v3 - v2)

		Part.Size = Vector3.new(v6 * (0.8 + math.random() * 0.4), v6 * (0.8 + math.random() * 0.4), v6 * (0.8 + math.random() * 0.4))
		Part.CFrame = CFrame.new(p1)
		Part.Parent = Workspace

		local v10 = math.random() * 2 * math.pi
		local v11 = math.random() * t8.DEBRIS_OUT_SPEED
		local v15 = Vector3.new(math.cos(v10) * v11, t8.DEBRIS_UP_SPEED * (0.6 + math.random() * 0.4), math.sin(v10) * v11)
		local v16 = (math.random() * 2 - 1) * 10
		local v17 = (math.random() * 2 - 1) * 10
		local v18 = (math.random() * 2 - 1) * 10

		table.insert(t2, {
			part = Part,
			vel = v15,
			spin = Vector3.new(v16, v17, v18),
			pos = p1,
			rot = CFrame.Angles(math.random() * 6.28, math.random() * 6.28, math.random() * 6.28)
		})
	end

	task.spawn(function() --[[ Line: 2127 | Upvalues: t8 (ref), RunService (ref), t2 (copy), p1 (copy) ]]
		local v1 = t8.DEBRIS_LIFETIME - 0.35
		local sum = 0

		while sum < t8.DEBRIS_LIFETIME do
			local v2 = RunService.Heartbeat:Wait()

			sum = sum + v2

			local v3 = if v1 < sum then math.clamp((sum - v1) / 0.35, 0, 1) else 0

			for v4, v5 in t2 do
				if v5.part.Parent then
					v5.vel = Vector3.new(v5.vel.X, v5.vel.Y - t8.DEBRIS_GRAVITY * v2, v5.vel.Z)

					local v7 = v5.pos + v5.vel * v2

					if v7.Y <= p1.Y then
						local v8 = Vector3.new(v7.X, p1.Y, v7.Z)

						v5.vel = Vector3.new(v5.vel.X * 0.4, 0, v5.vel.Z * 0.4)
						v7 = v8
					end

					v5.pos = v7
					v5.rot = v5.rot * CFrame.Angles(v5.spin.X * v2, v5.spin.Y * v2, v5.spin.Z * v2)
					v5.part.CFrame = CFrame.new(v5.pos) * v5.rot
					v5.part.Transparency = v3
				end
			end
		end

		for v11, v12 in t2 do
			if v12.part.Parent then
				v12.part:Destroy()
			end
		end
	end)
end
function t8.explode(p1) --[[ explode | Line: 2159 | Upvalues: Workspace (copy), t8 (copy), TweenService (copy), Players (copy), SoundService (copy), Debris (copy) ]]
	local Part = Instance.new("Part")

	Part.Anchored = true
	Part.CanCollide = false
	Part.CanQuery = false
	Part.CanTouch = false
	Part.CastShadow = false
	Part.Transparency = 1
	Part.Size = Vector3.new(1, 1, 1)
	Part.CFrame = CFrame.new(p1)
	Part.Parent = Workspace

	local ParticleEmitter = Instance.new("ParticleEmitter")

	ParticleEmitter.Texture = "rbxasset://textures/particles/sparkles_main.dds"
	ParticleEmitter.Color = ColorSequence.new(t8.COLOR)
	ParticleEmitter.LightEmission = 1
	ParticleEmitter.Lifetime = NumberRange.new(0.5, 1)
	ParticleEmitter.Speed = NumberRange.new(20, 48)
	ParticleEmitter.SpreadAngle = Vector2.new(180, 180)
	ParticleEmitter.Acceleration = Vector3.new(0, -60, 0)
	ParticleEmitter.Rotation = NumberRange.new(0, 360)
	ParticleEmitter.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 2.6), NumberSequenceKeypoint.new(1, 0) })
	ParticleEmitter.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.8, 0.2), NumberSequenceKeypoint.new(1, 1) })
	ParticleEmitter.Enabled = false
	ParticleEmitter.Parent = Part
	ParticleEmitter:Emit(t8.EXPLOSION_PARTICLES)

	local PointLight = Instance.new("PointLight")

	PointLight.Color = t8.COLOR
	PointLight.Brightness = 18
	PointLight.Range = 30
	PointLight.Parent = Part
	TweenService:Create(PointLight, TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
		Brightness = 0
	}):Play()
	t8.explodeDebris(p1)

	local Character = Players.LocalPlayer.Character
	local v1 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character
	local v2

	if v1 then
		v2 = v1.Position
	else
		local CurrentCamera = Workspace.CurrentCamera

		v2 = if CurrentCamera then CurrentCamera.CFrame.Position else nil
	end

	if v2 and (p1 - v2).Magnitude <= t8.SFX_RANGE then
		local SFX = SoundService:FindFirstChild("SFX")
		local v3 = if SFX then SFX:FindFirstChild(t8.SFX_NAME) else SFX

		if v3 and v3:IsA("Sound") then
			local v4 = v3:Clone()

			v4.PlaybackSpeed = math.random(95, 108) / 100
			v4.PlayOnRemove = true
			v4.Parent = Part
			v4:Destroy()
		end
	end

	Debris:AddItem(Part, 1.2)
end
function t8.findImpact(p1) --[[ findImpact | Line: 2223 | Upvalues: Players (copy), t8 (copy), Workspace (copy) ]]
	local v1 = RaycastParams.new()

	v1.FilterType = Enum.RaycastFilterType.Exclude
	v1.IgnoreWater = false

	local Character = Players.LocalPlayer.Character

	if Character then
		v1.FilterDescendantsInstances = { Character }
	end

	for i = 1, t8.TRIES do
		local v2
		local v3 = math.random() * 2 * math.pi
		local v5 = math.sqrt((math.random())) * t8.AREA_RADIUS
		local v6 = p1.X + math.cos(v3) * v5
		local v7 = p1.Z + math.sin(v3) * v5

		v2 = if t8.BARRIER_KEEP_ABOVE then if t8.BARRIER_X <= v6 then true else false elseif v6 <= t8.BARRIER_X then true else false

		if v2 then
			local v12 = Workspace:Raycast(Vector3.new(v6, p1.Y + t8.RAY_UP, v7), Vector3.new(0, -t8.RAY_DOWN, 0), v1)

			if v12 and v12.Material ~= Enum.Material.Water then
				return v12.Position
			end
		end
	end

	return nil
end
function t8.spawn() --[[ spawn | Line: 2252 | Upvalues: t8 (copy), Workspace (copy), RunService (copy) ]]
	local v1 = t8.getStartArea()

	if not v1 then
		warn("[WeatherEffects] FallingStars: Map.StartPointFish not found; cannot place stars")

		return
	end

	local v2 = t8.findImpact(v1)

	if v2 then
		local v3 = math.random() * 2 * math.pi
		local v4 = math.cos(v3) * t8.START_SPREAD
		local HEIGHT = t8.HEIGHT
		local v5 = math.sin(v3) * t8.START_SPREAD
		local v6 = v2 + Vector3.new(v4, HEIGHT, v5)
		local v7 = t8.build()

		v7:PivotTo(CFrame.new(v6))
		v7.Parent = Workspace
		task.spawn(function() --[[ Line: 2276 | Upvalues: t8 (ref), RunService (ref), v7 (copy), v6 (copy), v2 (copy) ]]
			local sum = 0

			while sum < t8.FALL_TIME do
				local v1 = RunService.Heartbeat:Wait()

				if not v7.Parent then
					return
				end

				sum = sum + v1

				local v3 = math.min(sum / t8.FALL_TIME, 1)

				v7:PivotTo(CFrame.new(v6:Lerp(v2, v3 * v3)))
			end

			t8.explode(v2)
			v7:Destroy()
		end)
	end
end
function t8.stop() --[[ stop | Line: 2292 | Upvalues: t8 (copy) ]]
	t8.running = false

	local v1 = t8

	v1.gen = v1.gen + 1
end
function t8.start(p1) --[[ start | Line: 2297 | Upvalues: t8 (copy), Workspace (copy) ]]
	t8.endTime = p1

	if not t8.running then
		t8.running = true

		local v1 = t8

		v1.gen = v1.gen + 1

		local gen = t8.gen

		task.spawn(function() --[[ Line: 2305 | Upvalues: t8 (ref), gen (copy), Workspace (ref) ]]
			while t8.running and (t8.gen == gen and not (t8.endTime and Workspace:GetServerTimeNow() >= t8.endTime - (t8.FALL_TIME + t8.EARLY_STOP))) do
				t8.spawn()
				task.wait(t8.INTERVAL)
			end
		end)
	end
end
function t8.apply(p1, p2) --[[ apply | Line: 2321 | Upvalues: t8 (copy) ]]
	if p1 then
		t8.start(p2)
	else
		t8.stop()
	end
end

local t9 = {
	INTERVAL = 0.4,
	BATCH = 12,
	MAX = 1200,
	AREA_RADIUS = 350,
	RAY_UP = 150,
	RAY_DOWN = 500,
	TRIES = 8,
	BARRIER_X = 83.259,
	BARRIER_KEEP_ABOVE = true,
	RESTRICT_TO_START_SIDE = false,
	ALLOW_WATER = true,
	DIAMETER_MIN = 0.5,
	DIAMETER_MAX = 1.1,
	THICKNESS = 0.2,
	PILE_CHANCE = 0.4,
	PILE_STUDS = 7,
	PILE_RADIUS = 1.3,
	PILE_SNAP_UP = 3,
	PILE_SNAP_DOWN = 6,
	ROOF_PILE_STUDS = 18,
	ROOF_PILE_RADIUS = 3.2,
	ROOF_DIAMETER_MIN = 1,
	ROOF_DIAMETER_MAX = 2.2,
	MARKER_NAME = "Snow here",
	SNAP_UP = 5,
	SNAP_DOWN = 300,
	SHRINK_TIME = 5,
	COLOR = Color3.fromRGB(214, 221, 232),
	running = false,
	gen = 0,
	count = 0,
	folder = nil,
	markers = {},
	getStartArea = function() --[[ getStartArea | Line: 2370 | Upvalues: Workspace (copy) ]]
		local Map = Workspace:FindFirstChild("Map")
		local v1 = if Map then Map:FindFirstChild("StartPointFish") else Map

		if v1 and v1:IsA("BasePart") then
			return v1.Position
		end

		return nil
	end
}

function t9.addStud(p1, p2, p3) --[[ addStud | Line: 2381 | Upvalues: t9 (copy) ]]
	local Part = Instance.new("Part")

	Part.Shape = Enum.PartType.Block
	Part.Anchored = true
	Part.CanCollide = false
	Part.CanQuery = false
	Part.CanTouch = false
	Part.CastShadow = false
	Part.Material = Enum.Material.SmoothPlastic
	Part.Color = t9.COLOR
	Part.Size = Vector3.new(p3, t9.THICKNESS, p3)

	local Unit = p2:Cross(if math.abs(p2.Y) > 0.99 then Vector3.new(1, 0, 0) else Vector3.new(0, 1, 0)).Unit

	Part.CFrame = CFrame.fromMatrix(p1 + p2 * (t9.THICKNESS * 0.5), Unit, p2) * CFrame.Angles(0, math.random() * math.pi * 0.5, 0)
	Part.Parent = t9.folder
end
function t9.placePile(p1, p2, p3, p4, p5, p6) --[[ placePile | Line: 2404 | Upvalues: t9 (copy), Players (copy), Workspace (copy) ]]
	local Unit = p2:Cross(if math.abs(p2.Y) > 0.99 then Vector3.new(1, 0, 0) else Vector3.new(0, 1, 0)).Unit
	local Unit2 = p2:Cross(Unit).Unit
	local v2 = RaycastParams.new()

	v2.FilterType = Enum.RaycastFilterType.Exclude

	local t = {}

	for v3, v4 in t9.markers do
		table.insert(t, v4)
	end

	if t9.folder then
		table.insert(t, t9.folder)
	end

	local Character = Players.LocalPlayer.Character

	if Character then
		table.insert(t, Character)
	end

	v2.FilterDescendantsInstances = t

	local count = 0

	for i = 1, p3 do
		local v5 = math.random() * p4
		local v6 = math.random() * 2 * math.pi
		local v7 = p1 + Unit * (math.cos(v6) * v5) + Unit2 * (math.sin(v6) * v5)
		local v12 = Workspace:Raycast(Vector3.new(v7.X, p1.Y + t9.PILE_SNAP_UP, v7.Z), Vector3.new(0, -(t9.PILE_SNAP_UP + t9.PILE_SNAP_DOWN), 0), v2)

		if v12 then
			t9.addStud(v12.Position, v12.Normal, p5 + math.random() * (p6 - p5))
			count = count + 1
		end
	end

	return count
end
function t9.findSurface(p1) --[[ findSurface | Line: 2450 | Upvalues: Players (copy), t9 (copy), Workspace (copy) ]]
	local v1 = RaycastParams.new()

	v1.FilterType = Enum.RaycastFilterType.Exclude
	v1.IgnoreWater = false

	local t = {}
	local Character = Players.LocalPlayer.Character

	if Character then
		table.insert(t, Character)
	end

	if t9.folder then
		table.insert(t, t9.folder)
	end

	for v2, v3 in t9.markers do
		table.insert(t, v3)
	end

	v1.FilterDescendantsInstances = t

	for i = 1, t9.TRIES do
		local v4
		local v5 = math.random() * 2 * math.pi
		local v7 = math.sqrt((math.random())) * t9.AREA_RADIUS
		local v8 = p1.X + math.cos(v5) * v7
		local v9 = p1.Z + math.sin(v5) * v7

		if t9.RESTRICT_TO_START_SIDE then
			v4 = if t9.BARRIER_KEEP_ABOVE then t9.BARRIER_X <= v8 elseif v8 <= t9.BARRIER_X then true else false

			if not v4 then
				continue
			end
		end

		local v14 = Workspace:Raycast(Vector3.new(v8, p1.Y + t9.RAY_UP, v9), Vector3.new(0, -t9.RAY_DOWN, 0), v1)

		if v14 and (t9.ALLOW_WATER or v14.Material ~= Enum.Material.Water) then
			return v14.Position, v14.Normal
		end
	end

	return nil, nil
end
function t9.collectMarkers() --[[ collectMarkers | Line: 2490 | Upvalues: t9 (copy), Workspace (copy) ]]
	table.clear(t9.markers)

	for v1, v2 in Workspace:GetDescendants() do
		if v2.Name == t9.MARKER_NAME and v2:IsA("BasePart") then
			table.insert(t9.markers, v2)
		end
	end
end
function t9.placeRoofPiles() --[[ placeRoofPiles | Line: 2501 | Upvalues: t9 (copy), Players (copy), Workspace (copy) ]]
	if #t9.markers == 0 then
		return
	end

	local v1 = RaycastParams.new()

	v1.FilterType = Enum.RaycastFilterType.Exclude

	local t = {}

	for v2, v3 in t9.markers do
		table.insert(t, v3)
	end

	if t9.folder then
		table.insert(t, t9.folder)
	end

	local Character = Players.LocalPlayer.Character

	if Character then
		table.insert(t, Character)
	end

	v1.FilterDescendantsInstances = t

	for v4, v5 in t9.markers do
		local v9 = Workspace:Raycast(v5.Position + Vector3.new(0, t9.SNAP_UP, 0), Vector3.new(0, -t9.SNAP_DOWN, 0), v1)

		if v9 then
			local v10 = t9

			v10.count = v10.count + t9.placePile(v9.Position, v9.Normal, t9.ROOF_PILE_STUDS, t9.ROOF_PILE_RADIUS, t9.ROOF_DIAMETER_MIN, t9.ROOF_DIAMETER_MAX)
		end
	end
end
function t9.stop() --[[ stop | Line: 2541 | Upvalues: t9 (copy), RunService (copy) ]]
	t9.running = false

	local v1 = t9

	v1.gen = v1.gen + 1
	t9.count = 0
	table.clear(t9.markers)

	local folder = t9.folder

	t9.folder = nil

	if not folder then
		return
	end

	local t = {}

	for v2, v3 in folder:GetChildren() do
		if v3:IsA("BasePart") then
			table.insert(t, {
				part = v3,
				size = v3.Size
			})
		end
	end

	task.spawn(function() --[[ Line: 2560 | Upvalues: t9 (ref), RunService (ref), t (copy), folder (copy) ]]
		local sum = 0

		while sum < t9.SHRINK_TIME do
			sum = sum + RunService.Heartbeat:Wait()

			local v2 = math.max(1 - sum / t9.SHRINK_TIME, 0)

			for v3, v4 in t do
				if v4.part.Parent then
					v4.part.Size = v4.size * v2
				end
			end
		end

		folder:Destroy()
	end)
end
function t9.start() --[[ start | Line: 2575 | Upvalues: t9 (copy), Workspace (copy) ]]
	if not t9.running then
		t9.running = true

		local v1 = t9

		v1.gen = v1.gen + 1
		t9.count = 0

		local gen = t9.gen
		local WeatherSnowStuds = Instance.new("Folder")

		WeatherSnowStuds.Name = "WeatherSnowStuds"
		WeatherSnowStuds.Parent = Workspace
		t9.folder = WeatherSnowStuds
		t9.collectMarkers()
		task.spawn(function() --[[ Line: 2588 | Upvalues: t9 (ref), gen (copy) ]]
			t9.placeRoofPiles()

			while t9.running and (t9.gen == gen and t9.count < t9.MAX) do
				local v1 = t9.getStartArea()

				if v1 then
					for i = 1, t9.BATCH do
						if t9.count >= t9.MAX then
							break
						end

						local v2, v3 = t9.findSurface(v1)

						if v2 and v3 then
							if math.random() < t9.PILE_CHANCE then
								local v4 = t9

								v4.count = v4.count + t9.placePile(v2, v3, t9.PILE_STUDS, t9.PILE_RADIUS, t9.DIAMETER_MIN, t9.DIAMETER_MAX)

								continue
							end

							t9.addStud(v2, v3, t9.DIAMETER_MIN + math.random() * (t9.DIAMETER_MAX - t9.DIAMETER_MIN))

							local v6 = t9

							v6.count = v6.count + 1
						end
					end
				end

				task.wait(t9.INTERVAL)
			end
		end)
	end
end
function t9.apply(p1) --[[ apply | Line: 2623 | Upvalues: t9 (copy) ]]
	if p1 then
		t9.start()
	else
		t9.stop()
	end
end

local t10 = {
	MODEL = "Star",
	SPAWNPOINT_NAME = "StarSpawnpoints",
	FULL_SCALE = 6,
	MIN_SCALE = 0.05,
	GROW_TIME = 1.2,
	HOLD_TIME = 4,
	SHRINK_TIME = 1.2,
	SPIN_SPEED = 0.6,
	SPAWN_INTERVAL = 1.5,
	MAX_CONCURRENT = 3,
	FALLBACK_SIZE = 10,
	running = false,
	gen = 0,
	active = 0,
	occupied = {}
}

function t10.collectPoints() --[[ collectPoints | Line: 2661 | Upvalues: ReplicatedStorage (copy), t10 (copy) ]]
	local t = {}
	local v1 = ReplicatedStorage:FindFirstChild("shared")
	local v2 = if v1 then v1:FindFirstChild("model") else v1

	if not v2 then
		return t
	end

	for v3, v4 in v2:GetDescendants() do
		if v4.Name == t10.SPAWNPOINT_NAME then
			if v4:IsA("BasePart") then
				table.insert(t, v4)

				continue
			end

			for v5, v6 in v4:GetChildren() do
				if v6:IsA("BasePart") then
					table.insert(t, v6)
				end
			end
		end
	end

	return t
end
function t10.build() --[[ build | Line: 2687 | Upvalues: ReplicatedStorage (copy), t10 (copy), buildPropModel (copy), t8 (copy) ]]
	local v1 = ReplicatedStorage:WaitForChild("shared", 10)
	local v2 = if v1 then v1:WaitForChild("model", 10) else v1
	local v3 = v2 and v2:WaitForChild("fx", 10)
	local v4 = if v3 then v3:FindFirstChild(t10.MODEL, true) else v3

	if not (v4 and (v4:IsA("Model") or v4:IsA("BasePart"))) then
		local Part = Instance.new("Part")

		Part.Shape = Enum.PartType.Ball
		Part.Size = Vector3.new(t10.FALLBACK_SIZE, t10.FALLBACK_SIZE, t10.FALLBACK_SIZE)
		Part.Material = Enum.Material.Neon
		Part.Color = t8.COLOR
		Part.Anchored = true
		Part.CanCollide = false
		Part.CanQuery = false
		Part.CanTouch = false
		Part.CastShadow = false

		local Model = Instance.new("Model")

		Part.Parent = Model
		Model.PrimaryPart = Part

		return Model
	end

	return buildPropModel(v4)
end
function t10.spawnOne(p1, p2) --[[ spawnOne | Line: 2710 | Upvalues: t10 (copy), Workspace (copy), RunService (copy) ]]
	local WeatherSpawnStar = t10.build()

	WeatherSpawnStar.Name = "WeatherSpawnStar"

	local Position = p1.Position

	WeatherSpawnStar:PivotTo(CFrame.new(Position))
	WeatherSpawnStar:ScaleTo(t10.MIN_SCALE)
	WeatherSpawnStar.Parent = Workspace
	t10.occupied[p1] = true

	local v1 = t10

	v1.active = v1.active + 1
	task.spawn(function() --[[ Line: 2721 | Upvalues: t10 (ref), WeatherSpawnStar (copy), p2 (copy), RunService (ref), Position (copy), p1 (copy) ]]
		local sum = 0
		local sum2 = 0

		while sum < t10.GROW_TIME + t10.HOLD_TIME + t10.SHRINK_TIME and (WeatherSpawnStar.Parent and t10.gen == p2) do
			local v2
			local v3 = RunService.Heartbeat:Wait()

			sum = sum + v3
			sum2 = sum2 + v3 * t10.SPIN_SPEED
			v2 = if sum < t10.GROW_TIME then t10.MIN_SCALE + (t10.FULL_SCALE - t10.MIN_SCALE) * (sum / t10.GROW_TIME) elseif sum < t10.GROW_TIME + t10.HOLD_TIME then t10.FULL_SCALE else t10.FULL_SCALE + (t10.MIN_SCALE - t10.FULL_SCALE) * ((sum - t10.GROW_TIME - t10.HOLD_TIME) / t10.SHRINK_TIME)
			WeatherSpawnStar:ScaleTo((math.max(v2, 0.01)))
			WeatherSpawnStar:PivotTo(CFrame.new(Position) * CFrame.Angles(0, sum2, 0))
		end

		if WeatherSpawnStar.Parent then
			WeatherSpawnStar:Destroy()
		end

		t10.occupied[p1] = nil
		t10.active = t10.active - 1
	end)
end
function t10.stop() --[[ stop | Line: 2750 | Upvalues: t10 (copy) ]]
	t10.running = false

	local v1 = t10

	v1.gen = v1.gen + 1
end
function t10.start() --[[ start | Line: 2755 | Upvalues: t10 (copy) ]]
	if not t10.running then
		t10.running = true

		local v1 = t10

		v1.gen = v1.gen + 1

		local gen = t10.gen

		task.spawn(function() --[[ Line: 2762 | Upvalues: t10 (ref), gen (copy) ]]
			while t10.running and t10.gen == gen do
				if t10.active < t10.MAX_CONCURRENT then
					local t = {}

					for v1, v2 in t10.collectPoints() do
						if not t10.occupied[v2] then
							table.insert(t, v2)
						end
					end

					if #t > 0 then
						t10.spawnOne(t[math.random(#t)], gen)
					end
				end

				task.wait(t10.SPAWN_INTERVAL)
			end
		end)
	end
end
function t10.apply(p1) --[[ apply | Line: 2780 | Upvalues: t10 (copy) ]]
	if p1 then
		t10.start()
	else
		t10.stop()
	end
end

local t11 = {
	TWEEN_TIME = 6,
	active = {}
}

function t11.startOne(p1) --[[ startOne | Line: 2799 | Upvalues: t11 (copy), ReplicatedStorage (copy), Workspace (copy), TweenService (copy) ]]
	if t11.active[p1] then
		return
	end

	local v1 = ReplicatedStorage:WaitForChild("shared", 10)
	local v2 = if v1 then v1:WaitForChild("model", 10) else v1
	local v3 = v2 and v2:WaitForChild("fx", 10)
	local v4 = if v3 then v3:FindFirstChild(p1) else v3

	if not v4 then
		warn((("[WeatherEffects] MovingStar \'%*\' not found in model.fx"):format(p1)))

		return
	end

	local v5 = v4:Clone()

	v5.Parent = Workspace

	local t = {
		tween = nil,
		clone = v5
	}

	t11.active[p1] = t

	local MovingPart = v5:FindFirstChild("MovingPart", true)
	local Start = v5:FindFirstChild("Start", true)
	local End = v5:FindFirstChild("End", true)

	if not (MovingPart and (Start and End)) then
		warn((("[WeatherEffects] MovingStar \'%*\' needs MovingPart + Start + End parts; tween skipped"):format(p1)))

		return
	end

	for v6, v7 in v5:GetDescendants() do
		if v7:IsA("BasePart") then
			v7.Anchored = true
			v7.CanCollide = false
			v7.CanQuery = false
			v7.CanTouch = false
		end
	end

	Start.Transparency = 1
	End.Transparency = 1
	MovingPart.CFrame = Start.CFrame

	local v8 = TweenService:Create(MovingPart, TweenInfo.new(t11.TWEEN_TIME, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true), {
		CFrame = End.CFrame
	})

	v8:Play()
	t.tween = v8
end
function t11.stopOne(p1) --[[ stopOne | Line: 2843 | Upvalues: t11 (copy) ]]
	local v1 = t11.active[p1]

	if not v1 then
		return
	end

	if v1.tween then
		v1.tween:Cancel()
	end

	v1.clone:Destroy()
	t11.active[p1] = nil
end
function t11.apply(p1) --[[ apply | Line: 2857 | Upvalues: t11 (copy) ]]
	local t = {}

	if p1 then
		for v1, v2 in p1 do
			t[v2] = true
		end
	end

	for v3 in t11.active do
		if not t[v3] then
			t11.stopOne(v3)
		end
	end

	for v4 in t do
		t11.startOne(v4)
	end
end

local function captureDefaults() --[[ captureDefaults | Line: 2875 | Upvalues: v1 (ref), Lighting (copy), getTerrainClouds (copy), v2 (ref), Workspace (copy), v32 (ref) ]]
	if v1 then
		return
	end

	local Atmosphere = Lighting:FindFirstChild("Atmosphere")

	if Atmosphere then
		v1 = {
			LightingBrightness = Lighting.Brightness,
			LightingAmbient = Lighting.Ambient,
			LightingOutdoorAmbient = Lighting.OutdoorAmbient,
			AtmosphereDensity = Atmosphere.Density,
			AtmosphereOffset = Atmosphere.Offset,
			AtmosphereColor = Atmosphere.Color,
			AtmosphereGlare = Atmosphere.Glare
		}
	else
		warn("[WeatherEffects] No Atmosphere found in Lighting; weather visuals may be incomplete")
		v1 = {
			AtmosphereDensity = 0.3,
			AtmosphereOffset = 0,
			AtmosphereGlare = 1,
			LightingBrightness = Lighting.Brightness,
			LightingAmbient = Lighting.Ambient,
			LightingOutdoorAmbient = Lighting.OutdoorAmbient,
			AtmosphereColor = Color3.fromRGB(199, 220, 255)
		}
	end

	local v12 = getTerrainClouds()

	if v12 then
		v2 = {
			Cover = v12.Cover,
			Density = v12.Density,
			Color = v12.Color
		}
	end

	local Terrain = Workspace:FindFirstChildOfClass("Terrain")

	if not Terrain then
		return
	end

	v32 = {
		Color = Terrain.WaterColor,
		Reflectance = Terrain.WaterReflectance,
		Transparency = Terrain.WaterTransparency
	}
end

local function applyLighting(p1, p2) --[[ applyLighting | Line: 2927 | Upvalues: captureDefaults (copy), Lighting (copy), TweenService (copy), getTerrainClouds (copy) ]]
	captureDefaults()
	TweenService:Create(Lighting, TweenInfo.new(3, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
		Brightness = p1.Lighting.Brightness,
		Ambient = p1.Lighting.Ambient,
		OutdoorAmbient = p1.Lighting.OutdoorAmbient
	}):Play()

	local Atmosphere = Lighting:FindFirstChild("Atmosphere")

	if Atmosphere then
		TweenService:Create(Atmosphere, TweenInfo.new(3, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
			Density = p1.Atmosphere.Density,
			Offset = p1.Atmosphere.Offset,
			Color = p1.Atmosphere.Color,
			Glare = p1.Atmosphere.Glare,
			Size = p1.Atmosphere.Size
		}):Play()
	end

	local v2 = getTerrainClouds()

	if not v2 then
		return
	end

	local v3

	if p2 and p2 > 0 then
		v2.Cover = 1
		v2.Density = 1
		v3 = p2
	else
		v3 = 3
	end

	TweenService:Create(v2, TweenInfo.new(v3, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
		Cover = p1.Clouds.Cover,
		Density = p1.Clouds.Density,
		Color = p1.Clouds.Color
	}):Play()
end

local function restoreLighting() --[[ restoreLighting | Line: 2965 | Upvalues: captureDefaults (copy), v1 (ref), Lighting (copy), TweenService (copy), getTerrainClouds (copy), v2 (ref) ]]
	captureDefaults()

	if v1 then
		TweenService:Create(Lighting, TweenInfo.new(3, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
			Brightness = v1.LightingBrightness,
			Ambient = v1.LightingAmbient,
			OutdoorAmbient = v1.LightingOutdoorAmbient
		}):Play()

		local Atmosphere = Lighting:FindFirstChild("Atmosphere")

		if Atmosphere then
			TweenService:Create(Atmosphere, TweenInfo.new(3, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
				Density = v1.AtmosphereDensity,
				Offset = v1.AtmosphereOffset,
				Color = v1.AtmosphereColor,
				Glare = v1.AtmosphereGlare
			}):Play()
		end
	end

	local v22 = getTerrainClouds()

	if not (v22 and v2) then
		return
	end

	TweenService:Create(v22, TweenInfo.new(3, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
		Cover = v2.Cover,
		Density = v2.Density,
		Color = v2.Color
	}):Play()
end

local function clearPostEffects() --[[ clearPostEffects | Line: 3002 | Upvalues: v31 (ref), t (copy), v20 (ref), TweenService (copy), v21 (ref), v22 (ref) ]]
	if v31 then
		v31:Disconnect()
		v31 = nil
	end

	local v1 = t

	v1._postFxGen = v1._postFxGen + 1

	local _postFxGen = t._postFxGen

	if v20 then
		local t2 = {
			Brightness = 0,
			Contrast = 0,
			Saturation = 0,
			TintColor = Color3.new(255/255, 255/255, 255/255)
		}

		TweenService:Create(v20, TweenInfo.new(3, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), t2):Play()
	end

	if v21 then
		TweenService:Create(v21, TweenInfo.new(3, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
			Intensity = 0
		}):Play()
	end

	if v22 then
		TweenService:Create(v22, TweenInfo.new(3, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
			Intensity = 0
		}):Play()
	end

	task.delay(3, function() --[[ Line: 3019 | Upvalues: t (ref), _postFxGen (copy), v20 (ref), v21 (ref), v22 (ref) ]]
		if t._postFxGen ~= _postFxGen then
			return
		end

		if v20 then
			v20:Destroy()
			v20 = nil
		end

		if v21 then
			v21:Destroy()
			v21 = nil
		end

		if not v22 then
			return
		end

		v22:Destroy()
		v22 = nil
	end)
end

local function restoreWater() --[[ restoreWater | Line: 3038 | Upvalues: v32 (ref), Workspace (copy), TweenService (copy) ]]
	if not v32 then
		return
	end

	local Terrain = Workspace:FindFirstChildOfClass("Terrain")

	if not Terrain then
		return
	end

	TweenService:Create(Terrain, TweenInfo.new(3, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
		WaterColor = v32.Color,
		WaterReflectance = v32.Reflectance,
		WaterTransparency = v32.Transparency
	}):Play()
end

function t.ApplyLighting(p1, p2) --[[ ApplyLighting | Line: 3060 | Upvalues: applyLighting (copy) ]]
	applyLighting(p1, p2)
end
function t.RestoreLighting() --[[ RestoreLighting | Line: 3063 | Upvalues: restoreLighting (copy) ]]
	restoreLighting()
end
function t.SetPrecip(p1) --[[ SetPrecip | Line: 3066 | Upvalues: v45 (copy) ]]
	v45(p1)
end
function t.ApplyPostEffects(p1) --[[ ApplyPostEffects | Line: 3069 | Upvalues: applyPostEffects (copy) ]]
	applyPostEffects(p1)
end
function t.ClearPostEffects() --[[ ClearPostEffects | Line: 3072 | Upvalues: clearPostEffects (copy) ]]
	clearPostEffects()
end
function t.SetSceneFX(p1, p2, p3, p4) --[[ SetSceneFX | Line: 3075 | Upvalues: applySceneFX (copy) ]]
	applySceneFX(p1, p2, p3, p4)
end
function t.SetSkyOverride(p1, p2) --[[ SetSkyOverride | Line: 3091 | Upvalues: t (copy), Lighting (copy), restoreLighting (copy) ]]
	local _skyOverride = t._skyOverride

	if p1 then
		if _skyOverride.active then
			return
		end

		for v1, v2 in t._skyOverrideChannels do
			local v4 = _skyOverride.originals[v2.off or v2.name]

			if v4 then
				local ok, result = pcall(v4)

				if not ok then
					warn((("[WeatherEffects] silencing \'%*\' failed: %*"):format(v2.name, result)))
				end
			end
		end

		_skyOverride.active = true

		for v5, v6 in Lighting:GetChildren() do
			if v6:IsA("Sky") then
				table.insert(_skyOverride.parkedSkies, v6)
				v6.Parent = nil

				continue
			end

			if v6:IsA("PostEffect") and v6.Enabled then
				_skyOverride.dimmedFx[v6] = true
				v6.Enabled = false
			end
		end

		for v7, v8 in p1:GetChildren() do
			if v8:IsA("PostEffect") or (v8:IsA("Sky") or v8:IsA("Atmosphere")) then
				local v9 = v8:Clone()

				if v9:IsA("PostEffect") then
					v9.Enabled = true
				end

				if v9:IsA("Atmosphere") then
					local Atmosphere = Lighting:FindFirstChildOfClass("Atmosphere")

					if Atmosphere then
						_skyOverride.parkedAtmosphere = Atmosphere
						Atmosphere.Parent = nil
					end
				end

				table.insert(_skyOverride.clones, v9)
				v9.Parent = Lighting
			end
		end

		if not p2 then
			return
		end

		local Atmosphere = Lighting:FindFirstChildOfClass("Atmosphere")

		for v10, v11 in {
			{ Lighting, p2.Lighting },
			{ Atmosphere, p2.Atmosphere }
		} do
			local v12 = v11[1]
			local v13 = v11[2]

			if v12 and v13 then
				for v14, v15 in v13 do
					local ok, result = pcall(function() --[[ Line: 3157 | Upvalues: v12 (copy), v14 (copy), v15 (copy) ]]
						v12[v14] = v15
					end)

					if not ok then
						warn((("[WeatherEffects] sky override look: %*.%* rejected: %*"):format(v12.ClassName, v14, result)))
					end
				end
			end
		end
	else
		if not _skyOverride.active then
			return
		end

		_skyOverride.active = false

		for v16, v17 in _skyOverride.clones do
			v17:Destroy()
		end

		table.clear(_skyOverride.clones)

		for v18, v19 in _skyOverride.parkedSkies do
			pcall(function() --[[ Line: 3180 | Upvalues: v19 (copy), Lighting (ref) ]]
				v19.Parent = Lighting
			end)
		end

		table.clear(_skyOverride.parkedSkies)

		local parkedAtmosphere = _skyOverride.parkedAtmosphere

		_skyOverride.parkedAtmosphere = nil

		if parkedAtmosphere then
			pcall(function() --[[ Line: 3190 | Upvalues: parkedAtmosphere (copy), Lighting (ref) ]]
				parkedAtmosphere.Parent = Lighting
			end)
		end

		for v20, v21 in _skyOverride.dimmedFx do
			if v20.Parent and v20:IsA("PostEffect") then
				v20.Enabled = v21
			end
		end

		table.clear(_skyOverride.dimmedFx)

		for v22, v23 in t._skyOverrideChannels do
			local v24 = _skyOverride.pending[v23.name]
			local v25 = if v24 then _skyOverride.originals[v24.fn] else nil

			if v24 and v25 then
				local v27, v28 = pcall(v25, table.unpack(v24.args, 1, v24.args.n))

				if not v27 then
					warn((("[WeatherEffects] replaying \'%*\' failed: %*"):format(v24.fn, v28)))
				end
			end
		end

		if _skyOverride.pending.ApplyLighting then
			return
		end

		restoreLighting()
	end
end
function t.SetWorldFX(p1) --[[ SetWorldFX | Line: 3223 | Upvalues: applyWorldFX (copy) ]]
	applyWorldFX(p1)
end
function t.SetWaterFX(p1) --[[ SetWaterFX | Line: 3226 | Upvalues: startWaterFx (copy), v26 (ref), v27 (ref) ]]
	if p1 then
		startWaterFx(p1)
	else
		v26 = false
		v27 = v27 + 1
	end
end
function t.SetWater(p1) --[[ SetWater | Line: 3229 | Upvalues: applyWater (copy) ]]
	applyWater(p1)
end
function t.RestoreWater() --[[ RestoreWater | Line: 3232 | Upvalues: restoreWater (copy) ]]
	restoreWater()
end
function t.SetAmbient(p1) --[[ SetAmbient | Line: 3235 | Upvalues: applyAmbient (copy) ]]
	applyAmbient(p1)
end
function t.ClearAmbient() --[[ ClearAmbient | Line: 3238 | Upvalues: v35 (ref), v33 (ref), v34 (ref) ]]
	if v35 then
		v35:Disconnect()
		v35 = nil
	end

	if v33 then
		v33:Destroy()
		v33 = nil
	end

	v34 = nil
end
function t.SetAmbientFX(p1) --[[ SetAmbientFX | Line: 3241 | Upvalues: applyAmbientFx (copy) ]]
	applyAmbientFx(p1)
end
function t.SetFallingStars(p1, p2) --[[ SetFallingStars | Line: 3244 | Upvalues: t8 (copy) ]]
	t8.apply(p1, p2)
end
function t.SetSnowStuds(p1) --[[ SetSnowStuds | Line: 3247 | Upvalues: t9 (copy) ]]
	t9.apply(p1)
end
t._grass = {
	NAME = "TrawaNaMapie",
	TWEEN_TIME = 4,
	saved = {}
}
function t.SetGrassWhite(p1) --[[ SetGrassWhite | Line: 3259 | Upvalues: t (copy), TweenService (copy), Workspace (copy) ]]
	local _grass = t._grass

	if p1 then
		if #_grass.saved > 0 then
			return
		end

		local v1 = Workspace:FindFirstChild(_grass.NAME, true)

		if not v1 then
			warn((("[WeatherEffects] \'%*\' not found in workspace; grass not whitened"):format(_grass.NAME)))

			return
		end

		local v2 = Color3.new(255/255, 255/255, 255/255)
		local t2 = {}

		if v1:IsA("BasePart") then
			table.insert(t2, v1)
		end

		for v3, v4 in v1:GetDescendants() do
			if v4:IsA("BasePart") then
				table.insert(t2, v4)
			end
		end

		for v5, v6 in t2 do
			table.insert(_grass.saved, {
				part = v6,
				color = v6.Color
			})
			TweenService:Create(v6, TweenInfo.new(_grass.TWEEN_TIME, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
				Color = v2
			}):Play()
		end
	else
		for v7, v8 in _grass.saved do
			if v8.part.Parent then
				TweenService:Create(v8.part, TweenInfo.new(_grass.TWEEN_TIME, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
					Color = v8.color
				}):Play()
			end
		end

		table.clear(_grass.saved)
	end
end
t._snowFx = {
	SOURCE = "SnowFX",
	INTERVAL = 2,
	GROW_TIME = 0.6,
	RISE = 3,
	folder = nil,
	gen = 0
}
function t.SetSnowFx(p1) --[[ SetSnowFx | Line: 3305 | Upvalues: t (copy), ReplicatedStorage (copy), Workspace (copy), RunService (copy), buildPropModel (copy) ]]
	local _snowFx = t._snowFx

	if p1 then
		if _snowFx.folder then
			return
		end

		local v1 = ReplicatedStorage:WaitForChild("shared", 10)
		local v2 = v1 and v1:WaitForChild("model", 10)
		local v3 = v2 and v2:WaitForChild("fx", 10)
		local v4 = v3 and v3:FindFirstChild(_snowFx.SOURCE)

		if v4 then
			_snowFx.gen = _snowFx.gen + 1

			local gen = _snowFx.gen
			local WeatherSnowFX = Instance.new("Folder")

			WeatherSnowFX.Name = "WeatherSnowFX"
			WeatherSnowFX.Parent = Workspace
			_snowFx.folder = WeatherSnowFX

			local function easeOutBack(p1) --[[ easeOutBack | Line: 3332 ]]
				local v1 = p1 - 1

				return v1 * 2.70158 * v1 * v1 + 1 + v1 * 1.70158 * v1
			end

			local function showModel(p1) --[[ showModel | Line: 3340 | Upvalues: _snowFx (copy), WeatherSnowFX (copy), gen (copy), RunService (ref) ]]
				for v1, v2 in p1:GetDescendants() do
					if v2:IsA("BasePart") then
						v2.Anchored = true
						v2.CanCollide = false
					end
				end

				local v3 = p1:GetPivot()

				p1:ScaleTo(0.01)

				local RISE = _snowFx.RISE

				p1:PivotTo(v3 - Vector3.new(0, RISE, 0))
				p1.Parent = WeatherSnowFX
				task.spawn(function() --[[ Line: 3351 | Upvalues: _snowFx (ref), p1 (copy), gen (ref), RunService (ref), v3 (copy) ]]
					local sum = 0

					while sum < _snowFx.GROW_TIME and (p1.Parent and _snowFx.gen == gen) do
						sum = sum + RunService.Heartbeat:Wait()

						local v2 = math.min(sum / _snowFx.GROW_TIME, 1)
						local v32 = v2 - 1

						p1:ScaleTo((math.max(v32 * 2.70158 * v32 * v32 + 1 + v32 * 1.70158 * v32, 0.01)))
						p1:PivotTo(v3 - Vector3.new(0, _snowFx.RISE * (1 - v2), 0))
					end

					if not p1.Parent or _snowFx.gen ~= gen then
						return
					end

					p1:ScaleTo(1)
					p1:PivotTo(v3)
				end)
			end

			task.spawn(function() --[[ Line: 3366 | Upvalues: v4 (copy), _snowFx (copy), gen (copy), WeatherSnowFX (copy), showModel (copy), buildPropModel (ref) ]]
				for v1, v2 in v4:GetChildren() do
					if _snowFx.gen ~= gen or not WeatherSnowFX.Parent then
						break
					end

					if v2:IsA("Model") then
						showModel(v2:Clone())
					elseif v2:IsA("BasePart") then
						showModel((buildPropModel(v2)))
					end

					task.wait(_snowFx.INTERVAL)
				end
			end)
		else
			warn((("[WeatherEffects] SnowFX \'%*\' not found in model.fx"):format(_snowFx.SOURCE)))
		end
	else
		_snowFx.gen = _snowFx.gen + 1

		if not _snowFx.folder then
			return
		end

		_snowFx.folder:Destroy()
		_snowFx.folder = nil
	end
end
function t.SetSpawnpointStars(p1) --[[ SetSpawnpointStars | Line: 3380 | Upvalues: t10 (copy) ]]
	t10.apply(p1)
end
function t.SetMovingStars(p1) --[[ SetMovingStars | Line: 3383 | Upvalues: t11 (copy) ]]
	t11.apply(p1)
end
t._rainbow = {
	MODEL = "Rainbow",
	GROW_TIME = 1.5,
	START_SCALE = 0.3,
	FLOAT_AMP = 4,
	FLOAT_FREQ = 0.4,
	SPIN_SPEED = 0.25,
	part = nil,
	conn = nil
}
function t.SetRainbowMesh(p1) --[[ SetRainbowMesh | Line: 3401 | Upvalues: t (copy), ReplicatedStorage (copy), Workspace (copy), RunService (copy) ]]
	local _rainbow = t._rainbow

	if p1 then
		if _rainbow.part then
			return
		end

		local v1 = ReplicatedStorage:WaitForChild("shared", 10)
		local v2 = v1 and v1:WaitForChild("model", 10)
		local v3 = v2 and v2:WaitForChild("fx", 10)
		local v4 = if v3 then v3:FindFirstChild(_rainbow.MODEL) else v3

		if v4 and v4:IsA("BasePart") then
			local v5 = v4:Clone()

			v5.Anchored = true
			v5.CanCollide = false
			v5.CanQuery = false
			v5.CanTouch = false

			local v6 = v5.CFrame

			v5.Parent = Workspace
			_rainbow.part = v5

			local v7 = 0

			_rainbow.conn = RunService.Heartbeat:Connect(function(p1) --[[ Line: 3435 | Upvalues: v5 (copy), v7 (ref), _rainbow (copy), v6 (copy) ]]
				debug.profilebegin("UECS/WeatherEffects.RainbowFloat")

				if v5.Parent then
					v7 = v7 + p1

					local v2 = math.sin(v7 * _rainbow.FLOAT_FREQ * 2 * math.pi) * _rainbow.FLOAT_AMP

					v5.CFrame = (v6 + Vector3.new(0, v2, 0)) * CFrame.Angles(0, v7 * _rainbow.SPIN_SPEED, 0)
				end

				debug.profileend()
			end)

			return
		end

		warn((("[WeatherEffects] Rainbow mesh \'%*\' (a BasePart) not found in model.fx"):format(_rainbow.MODEL)))
	else
		if _rainbow.conn then
			_rainbow.conn:Disconnect()
			_rainbow.conn = nil
		end

		if not _rainbow.part then
			return
		end

		_rainbow.part:Destroy()
		_rainbow.part = nil
	end
end
t._worldMesh = {
	GROW_TIME = 1.2,
	START_SCALE = 0.3,
	instance = nil,
	conn = nil,
	name = nil
}
function t.SetWorldMesh(p1, p2) --[[ SetWorldMesh | Line: 3462 | Upvalues: t (copy), ReplicatedStorage (copy), Workspace (copy), RunService (copy) ]]
	local _worldMesh = t._worldMesh

	if _worldMesh.name == p1 then
		return
	end

	if _worldMesh.conn then
		_worldMesh.conn:Disconnect()
		_worldMesh.conn = nil
	end

	if _worldMesh.instance then
		_worldMesh.instance:Destroy()
		_worldMesh.instance = nil
	end

	_worldMesh.name = nil

	if not p1 then
		return
	end

	local v1 = ReplicatedStorage:WaitForChild("shared", 10)
	local v2 = if v1 then v1:WaitForChild("model", 10) else v1
	local v3 = v2 and v2:WaitForChild("fx", 10)
	local v4 = if v3 then v3:FindFirstChild(p1) else v3

	if v4 and (v4:IsA("BasePart") or v4:IsA("Model")) then
		local function lockPart(p1) --[[ lockPart | Line: 3486 ]]
			p1.Anchored = true
			p1.CanCollide = false
			p1.CanQuery = false
			p1.CanTouch = false
		end

		local v5 = if p2 then 1 else _worldMesh.START_SCALE

		if v4:IsA("BasePart") then
			local v6 = v4:Clone()

			v6.Anchored = true
			v6.CanCollide = false
			v6.CanQuery = false
			v6.CanTouch = false

			local Size = v6.Size

			v6.Size = Size * v5
			v6.Parent = Workspace
			_worldMesh.instance = v6

			local v7 = 0

			_worldMesh.conn = RunService.Heartbeat:Connect(function(p1) --[[ Line: 3504 | Upvalues: v6 (copy), v7 (ref), _worldMesh (copy), Size (copy), v5 (copy) ]]
				debug.profilebegin("UECS/WeatherEffects.WorldMeshGrowPart")

				if not v6.Parent then
					debug.profileend()

					return
				end

				v7 = v7 + p1

				local v2 = math.min(v7 / _worldMesh.GROW_TIME, 1)

				v6.Size = Size * (v5 + (1 - v5) * v2)

				if not (v2 >= 1 and _worldMesh.conn) then
					debug.profileend()

					return
				end

				_worldMesh.conn:Disconnect()
				_worldMesh.conn = nil
				debug.profileend()
			end)
		else
			local v8 = v4:Clone()

			for v9, v10 in v8:GetDescendants() do
				if v10:IsA("BasePart") then
					v10.Anchored = true
					v10.CanCollide = false
					v10.CanQuery = false
					v10.CanTouch = false
				end
			end

			local v11 = v8:GetScale()

			v8:ScaleTo(v11 * v5)
			v8.Parent = Workspace
			_worldMesh.instance = v8

			local v12 = 0

			_worldMesh.conn = RunService.Heartbeat:Connect(function(p1) --[[ Line: 3533 | Upvalues: v8 (copy), v12 (ref), _worldMesh (copy), v11 (copy), v5 (copy) ]]
				debug.profilebegin("UECS/WeatherEffects.WorldMeshGrowModel")

				if v8.Parent then
					v12 = v12 + p1

					local v2 = math.min(v12 / _worldMesh.GROW_TIME, 1)

					v8:ScaleTo(v11 * (v5 + (1 - v5) * v2))

					if v2 >= 1 and _worldMesh.conn then
						_worldMesh.conn:Disconnect()
						_worldMesh.conn = nil
					end
				end

				debug.profileend()
			end)
		end

		_worldMesh.name = p1
	else
		warn((("[WeatherEffects] WorldMesh \'%*\' (a BasePart or Model) not found in model.fx"):format(p1)))
	end
end
t._snowman = {
	SOURCE = "Snowman",
	FADE_TIME = 2,
	BOB_HEIGHT = 1,
	BOB_SPEED = 4.5,
	ROCK_ANGLE = 0.22689280275926285,
	ROCK_SPEED = 4.5,
	TWIST_ANGLE = 0.2792526803190927,
	TWIST_SPEED = 3,
	instance = nil,
	conn = nil,
	gen = 0
}
function t.SetSnowman(p1, p2) --[[ SetSnowman | Line: 3569 | Upvalues: t (copy), TweenService (copy), ReplicatedStorage (copy), Workspace (copy), RunService (copy) ]]
	local _snowman = t._snowman

	_snowman.gen = _snowman.gen + 1

	local gen = _snowman.gen
	local v1 = if p2 then p2 else _snowman.FADE_TIME

	if _snowman.conn then
		_snowman.conn:Disconnect()
		_snowman.conn = nil
	end

	if _snowman.instance then
		local instance = _snowman.instance

		_snowman.instance = nil

		for v2, v3 in instance:GetDescendants() do
			if v3:IsA("BasePart") or (v3:IsA("Decal") or v3:IsA("Texture")) then
				TweenService:Create(v3, TweenInfo.new(v1, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
					Transparency = 1
				}):Play()
			end
		end

		if instance:IsA("BasePart") then
			TweenService:Create(instance, TweenInfo.new(v1, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
				Transparency = 1
			}):Play()
		end

		task.delay(v1 + 0.1, function() --[[ Line: 3591 | Upvalues: instance (copy) ]]
			instance:Destroy()
		end)
	end

	if not p1 then
		return
	end

	local v4 = ReplicatedStorage:WaitForChild("shared", 10)
	local v5 = v4 and v4:WaitForChild("model", 10)
	local v6 = v5 and v5:WaitForChild("fx", 10)
	local v7 = if v6 then v6:FindFirstChild(_snowman.SOURCE) else v6

	if v7 and (v7:IsA("Model") or v7:IsA("BasePart")) then
		local v8 = v7:Clone()

		for v9, v10 in v8:GetDescendants() do
			if v10:IsA("Script") or (v10:IsA("LocalScript") or (v10:IsA("BodyMover") or v10:IsA("Constraint"))) then
				v10:Destroy()
			end
		end

		if v8:IsA("Model") then
			local v11, v12 = v8:GetBoundingBox()

			v8.PrimaryPart = nil
			v8.WorldPivot = CFrame.new(v11.Position - Vector3.new(0, v12.Y / 2, 0))
		end

		local v15 = v8:GetPivot()
		local SnowmanSpawn = Workspace:FindFirstChild("SnowmanSpawn", true)

		if SnowmanSpawn and SnowmanSpawn:IsA("BasePart") then
			v15 = SnowmanSpawn.CFrame
		elseif SnowmanSpawn and SnowmanSpawn:IsA("Model") then
			v15 = SnowmanSpawn:GetPivot()
		end

		local v17 = v8:GetDescendants()

		if v8:IsA("BasePart") then
			table.insert(v17, v8)
		end

		for v18, v19 in v17 do
			if v19:IsA("BasePart") then
				v19.Anchored = true
				v19.CanCollide = false
				v19.CanQuery = false
				v19.CanTouch = false
			end

			if v19:IsA("BasePart") or (v19:IsA("Decal") or v19:IsA("Texture")) then
				local Transparency = v19.Transparency

				v19.Transparency = 1
				TweenService:Create(v19, TweenInfo.new(v1, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
					Transparency = Transparency
				}):Play()
			end
		end

		v8.Parent = Workspace
		v8:PivotTo(v15)
		_snowman.instance = v8

		local v20 = v15
		local v21 = 0

		_snowman.conn = RunService.Heartbeat:Connect(function(p1) --[[ Line: 3665 | Upvalues: _snowman (copy), gen (copy), v8 (copy), v21 (ref), v20 (copy) ]]
			debug.profilebegin("UECS/WeatherEffects.DanceModel")

			if _snowman.gen == gen and v8.Parent then
				v21 = v21 + p1

				local v3 = math.abs((math.sin(v21 * _snowman.BOB_SPEED))) * _snowman.BOB_HEIGHT
				local v5 = math.sin(v21 * _snowman.ROCK_SPEED) * _snowman.ROCK_ANGLE
				local v7 = math.sin(v21 * _snowman.TWIST_SPEED) * _snowman.TWIST_ANGLE

				v8:PivotTo(v20 * CFrame.new(0, v3, 0) * CFrame.Angles(0, v7, v5))
			end

			debug.profileend()
		end)
	else
		warn((("[WeatherEffects] Snowman \'%*\' (a Model or BasePart) not found in model.fx"):format(_snowman.SOURCE)))
	end
end
t._thunder = {
	MIN_GAP = 5,
	MAX_GAP = 14,
	BOLT_NAME = "LightningBolt",
	BOLT_SCALE = 5,
	BOLT_DIST = 320,
	BOLT_SPREAD = 110,
	BOLT_HEIGHT = 140,
	BOLT_VISIBLE = 0.35,
	running = false,
	gen = 0,
	cc = nil,
	PULSE = {
		{ 0.5, 0.04 },
		{ 0.06, 0.07 },
		{ 0.8, 0.04 },
		{ 0, 0.5 }
	}
}
function t.SetThunder(p1) --[[ SetThunder | Line: 3699 | Upvalues: t (copy), Lighting (copy), ReplicatedStorage (copy), Workspace (copy), SoundService (copy), SFX (copy), TweenService (copy) ]]
	local _thunder = t._thunder

	if p1 then
		if not _thunder.running then
			_thunder.running = true
			_thunder.gen = _thunder.gen + 1

			local gen = _thunder.gen
			local ThunderFlash = Instance.new("ColorCorrectionEffect")

			ThunderFlash.Name = "ThunderFlash"
			ThunderFlash.Brightness = 0
			ThunderFlash.Parent = Lighting
			_thunder.cc = ThunderFlash
			task.spawn(function() --[[ Line: 3722 | Upvalues: _thunder (copy), gen (copy), ReplicatedStorage (ref), Workspace (ref), SoundService (ref), SFX (ref), ThunderFlash (copy), TweenService (ref) ]]
				while _thunder.running and _thunder.gen == gen do
					local v1, v2

					task.wait(math.random() * (_thunder.MAX_GAP - _thunder.MIN_GAP) + _thunder.MIN_GAP)

					if not _thunder.running or _thunder.gen ~= gen then
						break
					end

					local v3 = ReplicatedStorage:WaitForChild("shared", 10)
					local v4 = if v3 then v3:WaitForChild("model", 10) else v3

					v1 = v4 and v4:WaitForChild("fx", 10)

					if v1 then
						local v5 = ReplicatedStorage:WaitForChild("shared", 10)
						local v6 = if v5 then v5:WaitForChild("model", 10) else v5

						v2 = v6 and v6:WaitForChild("fx", 10)
						v1 = v2:FindFirstChild(_thunder.BOLT_NAME)
					end

					if v1 and (v1:IsA("Model") or v1:IsA("BasePart")) then
						local v7 = v1:Clone()
						local v8 = v7:GetDescendants()

						if v7:IsA("BasePart") then
							table.insert(v8, v7)
						end

						for v9, v10 in v8 do
							if v10:IsA("BasePart") then
								v10.Anchored = true
								v10.CanCollide = false
								v10.CanQuery = false
								v10.CanTouch = false
							end
						end

						if v7:IsA("BasePart") then
							v7.Size = v7.Size * _thunder.BOLT_SCALE
						elseif v7:IsA("Model") then
							v7:ScaleTo(_thunder.BOLT_SCALE)
						end

						local v11 = Workspace.CurrentCamera and Workspace.CurrentCamera.CFrame or CFrame.identity
						local v12 = v11.Position + v11.LookVector * _thunder.BOLT_DIST + v11.RightVector * ((math.random() * 2 - 1) * _thunder.BOLT_SPREAD)
						local v13 = v12 + Vector3.new(0, _thunder.BOLT_HEIGHT, 0)

						v7:PivotTo(CFrame.lookAt(v13, (Vector3.new(v11.X, v13.Y, v11.Z))))
						v7.Parent = Workspace
						task.delay(_thunder.BOLT_VISIBLE, function() --[[ Line: 3756 | Upvalues: v7 (copy) ]]
							v7:Destroy()
						end)
					end

					local v14 = SoundService:FindFirstChild("SFX") and SoundService.SFX:FindFirstChild("Thunders")

					if v14 then
						local v15 = v14:GetChildren()

						if #v15 > 0 then
							local v16 = v15[math.random(#v15)]

							if v16:IsA("Sound") then
								SFX.PlaySoundWithRandomPitch(v16.SoundId, 0.6, 0.85, 1.1)
							end
						end
					end

					for v17, v18 in _thunder.PULSE do
						if not _thunder.running or _thunder.gen ~= gen then
							break
						end

						TweenService:Create(ThunderFlash, TweenInfo.new(v18[2], Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
							Brightness = v18[1]
						}):Play()
						task.wait(v18[2])
					end
				end
			end)
		end
	else
		_thunder.running = false
		_thunder.gen = _thunder.gen + 1

		if not _thunder.cc then
			return
		end

		_thunder.cc:Destroy()
		_thunder.cc = nil
	end
end
t._envScale = {
	captured = nil
}
function t.SetEnvironmentScale(p1, p2) --[[ SetEnvironmentScale | Line: 3792 | Upvalues: t (copy), Lighting (copy) ]]
	local _envScale = t._envScale

	if p1 == nil and p2 == nil then
		if not _envScale.captured then
			return
		end

		Lighting.EnvironmentDiffuseScale = _envScale.captured.diffuse
		Lighting.EnvironmentSpecularScale = _envScale.captured.specular
		_envScale.captured = nil
	else
		if not _envScale.captured then
			_envScale.captured = {
				diffuse = Lighting.EnvironmentDiffuseScale,
				specular = Lighting.EnvironmentSpecularScale
			}
		end

		if p1 then
			Lighting.EnvironmentDiffuseScale = p1
		end

		if not p2 then
			return
		end

		Lighting.EnvironmentSpecularScale = p2
	end
end
function t.SetBreath(p1) --[[ SetBreath | Line: 3815 | Upvalues: v41 (ref), v42 (ref), Players (copy), playBreath (copy), SFX (copy) ]]
	if not p1 then
		v41 = false
		v42 = v42 + 1

		return
	end

	if not v41 then
		v41 = true
		v42 = v42 + 1

		local v1 = v42

		task.spawn(function() --[[ Line: 1772 | Upvalues: v41 (ref), v42 (ref), v1 (copy), Players (ref), playBreath (ref), SFX (ref) ]]
			while v41 and v42 == v1 do
				local Character = Players.LocalPlayer.Character
				local v12 = if Character then Character:FindFirstChild("Head") else Character

				if v12 then
					playBreath(v12)

					local FrozenBreath = SFX.Sounds.FrozenBreath

					if FrozenBreath and FrozenBreath ~= "" then
						SFX.PlaySoundWithRandomPitchAtPart(FrozenBreath, v12, 0.5, 0.95, 1.05)
					end
				end

				task.wait(4)
			end
		end)
	end
end
function t.SetShiver(p1) --[[ SetShiver | Line: 3818 | Upvalues: startShiver (copy), v43 (ref), v44 (ref), v47 (ref), v48 (ref), t7 (copy), v46 (ref) ]]
	if p1 then
		startShiver()

		return
	end

	v43 = false
	v44 = v44 + 1
	v47 = false
	v48 = 0
	table.clear(t7)

	if not v46 then
		return
	end

	v46:Disconnect()
	v46 = nil
end
function t.SetIceProps(p1) --[[ SetIceProps | Line: 3821 | Upvalues: v29 (ref), v30 (ref), Players (copy), Workspace (copy), spawnOneIceProp (copy), stopIceProps (copy) ]]
	if not p1 then
		stopIceProps()

		return
	end

	if not v29 then
		v29 = true
		v30 = v30 + 1

		local v1 = v30

		task.spawn(function() --[[ Line: 1386 | Upvalues: Players (ref), Workspace (ref), v29 (ref), v30 (ref), v1 (copy), spawnOneIceProp (ref) ]]
			task.wait(5)

			local Character = Players.LocalPlayer.Character
			local v12 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character
			local v2

			if v12 then
				v2 = v12.Position
			else
				local CurrentCamera = Workspace.CurrentCamera

				v2 = if CurrentCamera then CurrentCamera.CFrame.Position else nil
			end

			if not v2 then
				return
			end

			for i = 1, 20 do
				if not v29 or v30 ~= v1 then
					break
				end

				spawnOneIceProp(v2)
				task.wait(1)
			end
		end)
	end
end
function t.CaptureDefaults() --[[ CaptureDefaults | Line: 3826 | Upvalues: captureDefaults (copy) ]]
	captureDefaults()
end
t._screenRainDefaults = {
	Rate = 5,
	Size = 0.06,
	Fade = 3,
	BaseTransparency = 0.7,
	MeshId = nil,
	Tint = Color3.fromRGB(226, 244, 255),
	Material = Enum.Material.Glass
}
function t.SetScreenRain(p1, p2) --[[ SetScreenRain | Line: 3842 | Upvalues: ReplicatedStorage (copy), t (copy) ]]
	local ScreenRain = require(ReplicatedStorage.client.ScreenRain)
	local _screenRainDefaults = t._screenRainDefaults

	if p1 then
		ScreenRain:Configure(p2 or _screenRainDefaults)
		ScreenRain:Enable()
	else
		ScreenRain:Configure(_screenRainDefaults)
		ScreenRain:Disable()
	end
end
t._snowRunning = false
t._snowGen = 0
t._snowConn = nil
function t.SetScreenSnow(p1) --[[ SetScreenSnow | Line: 3860 | Upvalues: t (copy), ReplicatedStorage (copy), Workspace (copy), RunService (copy), TweenService (copy) ]]
	if p1 then
		if t._snowRunning then
			return
		end

		t._snowRunning = true

		local v1 = t

		v1._snowGen = v1._snowGen + 1

		local _snowGen = t._snowGen
		local SnowFlake = ReplicatedStorage.shared.model:FindFirstChild("SnowFlake")

		if SnowFlake then
			local CurrentCamera = Workspace.CurrentCamera
			local v2 = 0
			local ScreenSnowflakes = Instance.new("Folder")

			ScreenSnowflakes.Name = "ScreenSnowflakes"
			ScreenSnowflakes.Parent = CurrentCamera
			t._snowConn = RunService.Heartbeat:Connect(function(p1) --[[ Line: 3884 | Upvalues: t (ref), _snowGen (copy), v2 (ref), CurrentCamera (copy), SnowFlake (copy), ScreenSnowflakes (copy), TweenService (ref) ]]
				debug.profilebegin("UECS/WeatherEffects.ScreenSnow")

				if t._snowRunning and t._snowGen == _snowGen then
					v2 = v2 + p1 * 3

					local v1 = CurrentCamera.CFrame

					while v2 >= 1 do
						v2 = v2 - 1

						local v22 = SnowFlake:Clone()

						v22.Size = SnowFlake.Size * 0.01
						v22.Anchored = true
						v22.CanCollide = false
						v22.CanQuery = false
						v22.CanTouch = false
						v22.Locked = true
						v22.CastShadow = false
						v22.Transparency = 0

						local v3 = (math.random() - 0.5) * 2.4
						local v4 = (math.random() - 0.5) * 2
						local v5 = math.random() * math.pi * 2

						v22.CFrame = v1 * CFrame.new(v3, v4, -1) * CFrame.Angles(0, 0, v5)
						v22.Parent = ScreenSnowflakes

						local v6 = TweenService:Create(v22, TweenInfo.new(3, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
							Transparency = 1
						})

						v6:Play()
						v6.Completed:Once(function() --[[ Line: 3918 | Upvalues: v22 (copy) ]]
							v22:Destroy()
						end)
					end
				end

				debug.profileend()
			end)
		end
	else
		t._snowRunning = false

		local v3 = t

		v3._snowGen = v3._snowGen + 1

		if t._snowConn then
			t._snowConn:Disconnect()
			t._snowConn = nil
		end

		local v4 = Workspace.CurrentCamera and Workspace.CurrentCamera:FindFirstChild("ScreenSnowflakes")

		if not v4 then
			return
		end

		v4:Destroy()
	end
end
function t.SetClientCloudsOverride(p1, p2) --[[ SetClientCloudsOverride | Line: 3943 | Upvalues: Workspace (copy), TweenService (copy) ]]
	local ClientClouds = Workspace:FindFirstChild("ClientClouds")

	if not ClientClouds then
		return
	end

	local t = {}

	for v1, v2 in ClientClouds:GetDescendants() do
		if v2:IsA("BasePart") then
			table.insert(t, v2)
		end
	end

	if #t == 0 then
		return
	end

	if p1 then
		for v3, v4 in t do
			if v4:GetAttribute("_origColor") == nil then
				v4:SetAttribute("_origColor", v4.Color)
				v4:SetAttribute("_origTransparency", v4.Transparency)
			end

			local t2 = {
				Color = p1
			}

			t2.Transparency = if p2 then p2 else v4.Transparency
			TweenService:Create(v4, TweenInfo.new(3, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), t2):Play()
		end
	else
		for v6, v7 in t do
			local v8 = v7:GetAttribute("_origColor")
			local v9 = v7:GetAttribute("_origTransparency")

			if v8 ~= nil then
				local t2 = {
					Color = v8
				}

				t2.Transparency = if v9 == nil then v7.Transparency else v9
				TweenService:Create(v7, TweenInfo.new(3, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), t2):Play()
				task.delay(3.1, function() --[[ Line: 3978 | Upvalues: v7 (copy) ]]
					if not v7.Parent then
						return
					end

					v7:SetAttribute("_origColor", nil)
					v7:SetAttribute("_origTransparency", nil)
				end)
			end
		end
	end
end
function t.SetFreezeScreen(p1) --[[ SetFreezeScreen | Line: 3991 | Upvalues: Players (copy), TweenService (copy) ]]
	local v1 = Players.LocalPlayer and Players.LocalPlayer:FindFirstChild("PlayerGui")

	if not v1 then
		return
	end

	local FreezzeUi = v1:FindFirstChild("FreezzeUi")
	local v2 = if FreezzeUi then FreezzeUi:FindFirstChild("FreezeScreen") else FreezzeUi

	if not v2 then
		return
	end

	TweenService:Create(v2, TweenInfo.new(3, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
		ImageTransparency = if p1 then 0 else 1
	}):Play()

	if not p1 then
		return
	end

	local Freeze = v2:FindFirstChild("Freeze")

	if not Freeze then
		return
	end

	Freeze:Play()
end
Lighting.ChildAdded:Connect(function(p1) --[[ Line: 4016 | Upvalues: t (copy), t4 (copy), t5 (copy), Lighting (copy) ]]
	local _skyOverride = t._skyOverride

	if _skyOverride.active and not table.find(_skyOverride.clones, p1) then
		if p1:IsA("Sky") then
			table.insert(_skyOverride.parkedSkies, p1)
			p1.Parent = nil

			return
		end

		if p1:IsA("PostEffect") and p1.Enabled then
			_skyOverride.dimmedFx[p1] = true
			p1.Enabled = false

			return
		end
	end

	if not p1:IsA("Sky") then
		return
	end

	print("[WeatherEffects] Lighting.ChildAdded triggered for Sky:", p1.Name)

	local weathereffectsweatherskyactivestatus = false

	for v1, v2 in t4 do
		if v2:IsA("Sky") then
			weathereffectsweatherskyactivestatus = true

			break
		end
	end

	print("[WeatherEffects] weatherSkyActive status:", weathereffectsweatherskyactivestatus)

	if not weathereffectsweatherskyactivestatus then
		return
	end

	local weathereffectsistheaddedskyaweatherclone = false

	for v3, v4 in t4 do
		if v4 == p1 then
			weathereffectsistheaddedskyaweatherclone = true

			break
		end
	end

	print("[WeatherEffects] Is the added Sky a weather clone?", weathereffectsistheaddedskyaweatherclone)

	if weathereffectsistheaddedskyaweatherclone or table.find(t5, p1) then
		return
	end

	print("[WeatherEffects] Stashing non-clone Sky:", p1.Name)
	table.insert(t5, p1)
	task.defer(function() --[[ Line: 4058 | Upvalues: t4 (ref), p1 (copy), Lighting (ref) ]]
		local v1 = false

		for v2, v3 in t4 do
			if v3:IsA("Sky") then
				v1 = true

				break
			end
		end

		print("[WeatherEffects] task.defer running. stillActive:", v1, "parent matches:", p1.Parent == Lighting)

		if not v1 or p1.Parent ~= Lighting then
			return
		end

		p1.Parent = nil
		print("[WeatherEffects] Set stashed Sky parent to nil:", p1.Name)
	end)
end)

for v49, v50 in t._skyOverrideChannels do
	for v51, v52 in { v50.name, v50.off } do
		local v53 = t[v52]

		if type(v53) == "function" then
			t._skyOverride.originals[v52] = v53
			t[v52] = function(...) --[[ Line: 4097 | Upvalues: t (copy), v50 (copy), v52 (copy), v53 (copy) ]]
				t._skyOverride.pending[v50.name] = {
					fn = v52,
					args = table.pack(...)
				}

				if t._skyOverride.active then
					return
				end

				return v53(...)
			end

			continue
		end

		warn((("[WeatherEffects] sky-override channel \'%*\' is not a function \226\128\148 not wrapped"):format(v52)))
	end
end

return t