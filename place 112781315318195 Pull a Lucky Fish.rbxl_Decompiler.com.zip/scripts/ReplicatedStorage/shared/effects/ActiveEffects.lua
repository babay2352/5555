-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local HttpService = game:GetService("HttpService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local Signal = require(ReplicatedStorage.package.Signal)
local Remotes = require(ReplicatedStorage.shared.Remotes)
local EffectKinds = require(ReplicatedStorage.shared.effects.EffectKinds)
local EventsConfig = require(ReplicatedStorage.shared.config.EventsConfig)
local v1 = RunService:IsServer()
local t = {}
local v2 = Signal.new()

local function snapshotList() --[[ snapshotList | Line: 29 | Upvalues: t (copy) ]]
	local t2 = {}

	for v1, v2 in t do
		table.insert(t2, v2)
	end

	return t2
end

local function applySnapshot(p1) --[[ applySnapshot | Line: 37 | Upvalues: t (copy), v2 (copy) ]]
	table.clear(t)

	for v1, v22 in p1 do
		t[v22.Id] = v22
	end

	v2:Fire()
end

local t2 = {
	Changed = v2,
	GetActive = function() --[[ GetActive | Line: 49 | Upvalues: t (copy) ]]
		local t2 = {}

		for v1, v2 in t do
			table.insert(t2, v2)
		end

		return t2
	end,
	GetMultiplier = function(p1) --[[ GetMultiplier | Line: 53 | Upvalues: EffectKinds (copy), t (copy), EventsConfig (copy) ]]
		local v1 = EffectKinds[p1]

		if not v1 then
			return 1
		end

		local t2 = {}

		for v2, v3 in t do
			local EffectOverrides = v3.EffectOverrides

			if EffectOverrides == nil then
				local v4 = EventsConfig[v3.Name]

				EffectOverrides = if v4 then v4.Effects else v4
			end

			if EffectOverrides then
				local v6 = EffectOverrides[p1]

				if v6 then
					table.insert(t2, v6)
				end
			end
		end

		if #t2 == 0 then
			return v1.Identity
		end

		return v1.Combine(t2)
	end
}

if v1 then
	local function broadcast() --[[ broadcast | Line: 82 | Upvalues: Remotes (copy), t (copy), v2 (copy) ]]
		local t2 = {}

		for v1, v22 in t do
			table.insert(t2, v22)
		end

		Remotes.ActiveEventsReplicate:FireAll(t2)
		v2:Fire()
	end

	function t2.Start(p1, p2, p3, p4) --[[ Start | Line: 87 | Upvalues: EventsConfig (copy), HttpService (copy), t (copy), Remotes (copy), v2 (copy) ]]
		local v1 = EventsConfig[p1]

		assert(v1, (("ActiveEffects.Start: unknown event \"%*\""):format(p1)))

		local v3 = if p2 then p2 else v1.DefaultDuration
		local v4 = workspace:GetServerTimeNow()
		local v5 = HttpService:GenerateGUID(false)

		t[v5] = {
			Id = v5,
			Name = p1,
			StartedAt = v4,
			ExpiresAt = v4 + v3,
			EffectOverrides = p3,
			DisplayNameOverride = p4
		}

		local t2 = {}

		for v6, v7 in t do
			table.insert(t2, v7)
		end

		Remotes.ActiveEventsReplicate:FireAll(t2)
		v2:Fire()

		return v5
	end
	function t2.StartUnique(p1, p2) --[[ StartUnique | Line: 114 | Upvalues: EventsConfig (copy), t (copy), Remotes (copy), v2 (copy), t2 (copy) ]]
		local v1 = EventsConfig[p1]

		assert(v1, (("ActiveEffects.StartUnique: unknown event \"%*\""):format(p1)))

		local v3 = if p2 then p2 else v1.DefaultDuration
		local v4 = workspace:GetServerTimeNow()

		for v5, v6 in t do
			if v6.Name == p1 then
				v6.StartedAt = v4
				v6.ExpiresAt = v4 + v3

				local t3 = {}

				for v7, v8 in t do
					table.insert(t3, v8)
				end

				Remotes.ActiveEventsReplicate:FireAll(t3)
				v2:Fire()

				return v5
			end
		end

		return t2.Start(p1, p2)
	end
	function t2.StartOrExtend(p1, p2) --[[ StartOrExtend | Line: 135 | Upvalues: EventsConfig (copy), t (copy), Remotes (copy), v2 (copy), t2 (copy) ]]
		local v1 = EventsConfig[p1]

		assert(v1, (("ActiveEffects.StartOrExtend: unknown event \"%*\""):format(p1)))

		local v3 = if p2 then p2 else v1.DefaultDuration

		for v4, v5 in t do
			if v5.Name == p1 then
				v5.ExpiresAt = v5.ExpiresAt + v3

				local t3 = {}

				for v6, v7 in t do
					table.insert(t3, v7)
				end

				Remotes.ActiveEventsReplicate:FireAll(t3)
				v2:Fire()

				return v4
			end
		end

		return t2.Start(p1, v3)
	end
	function t2.Stop(p1) --[[ Stop | Line: 149 | Upvalues: t (copy), Remotes (copy), v2 (copy) ]]
		if not t[p1] then
			return
		end

		t[p1] = nil

		local t2 = {}

		for v1, v22 in t do
			table.insert(t2, v22)
		end

		Remotes.ActiveEventsReplicate:FireAll(t2)
		v2:Fire()
	end
	function t2.StopByName(p1) --[[ StopByName | Line: 159 | Upvalues: t (copy), Remotes (copy), v2 (copy) ]]
		local count = 0

		for v1, v22 in t do
			if v22.Name == p1 then
				t[v1] = nil
				count = count + 1
			end
		end

		if count > 0 then
			local t2 = {}

			for v3, v4 in t do
				table.insert(t2, v4)
			end

			Remotes.ActiveEventsReplicate:FireAll(t2)
			v2:Fire()
		end

		return count
	end
	function t2.StopAll() --[[ StopAll | Line: 174 | Upvalues: t (copy), Remotes (copy), v2 (copy) ]]
		local count = 0

		for v1 in t do
			t[v1] = nil
			count = count + 1
		end

		if count > 0 then
			local t2 = {}

			for v22, v3 in t do
				table.insert(t2, v3)
			end

			Remotes.ActiveEventsReplicate:FireAll(t2)
			v2:Fire()
		end

		return count
	end
	function t2.SendSnapshotTo(p1) --[[ SendSnapshotTo | Line: 186 | Upvalues: Remotes (copy), t (copy) ]]
		local t2, v1 = {}, p1

		for v2, v3 in t do
			table.insert(t2, v3)
		end

		Remotes.ActiveEventsReplicate:Fire(v1, t2)
	end
	task.spawn(function() --[[ Line: 190 | Upvalues: t (copy), Remotes (copy), v2 (copy) ]]
		while task.wait(1) do
			local v1 = workspace:GetServerTimeNow()
			local v22 = false

			for v3, v4 in t do
				if v4.ExpiresAt <= v1 then
					t[v3] = nil
					v22 = true
				end
			end

			if not v22 then
				continue
			end

			local t2 = {}

			for v5, v6 in t do
				table.insert(t2, v6)
			end

			Remotes.ActiveEventsReplicate:FireAll(t2)
			v2:Fire()
		end
	end)
else
	Remotes.ActiveEventsReplicate:On(function(p1) --[[ Line: 206 | Upvalues: t (copy), v2 (copy) ]]
		table.clear(t)

		for v1, v22 in p1 do
			t[v22.Id] = v22
		end

		v2:Fire()
	end)
end

return t2