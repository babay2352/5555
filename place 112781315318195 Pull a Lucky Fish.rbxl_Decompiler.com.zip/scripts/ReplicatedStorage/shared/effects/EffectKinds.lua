-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local function additiveBonus(p1) --[[ additiveBonus | Line: 8 ]]
	local sum = 0

	for v1, v2 in p1 do
		sum = sum + (v2 - 1)
	end

	return sum + 1
end

return {
	Luck = {
		Identity = 1,
		Combine = additiveBonus
	},
	ThrowSpeed = {
		Identity = 1,
		Combine = additiveBonus
	},
	TrainingValue = {
		Identity = 1,
		Combine = additiveBonus
	},
	FootballBeastMult = {
		Identity = 1,
		Combine = additiveBonus
	}
}