-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Digit = require(script.Parent.Digit)
local t = {}
local t2 = {
	Frame = true,
	Digits = true,
	CommaLabels = true,
	Text = true
}
local t3 = {
	Value = "number",
	Duration = "number",
	Decimals = "number",
	Prefix = "string",
	Suffix = "string",
	Commas = "boolean"
}
local t4 = {
	[Enum.TextXAlignment.Center] = Enum.HorizontalAlignment.Center,
	[Enum.TextXAlignment.Left] = Enum.HorizontalAlignment.Left,
	[Enum.TextXAlignment.Right] = Enum.HorizontalAlignment.Right
}
local Frame = Instance.new("Frame")
local TextLabel = Instance.new("TextLabel")

TextLabel.TextSize = 25
TextLabel.TextColor3 = Color3.fromRGB(250, 250, 255)
TextLabel.FontFace = Font.new("SourceSans")

local function newSpinner() --[[ newSpinner | Line: 31 | Upvalues: Frame (copy), TextLabel (copy), t2 (copy), t4 (copy), t3 (copy), Digit (copy) ]]
	local t = {
		Value = 0,
		Duration = 0.3,
		Decimals = 2,
		Prefix = "$",
		Suffix = "",
		Commas = false,
		Frame = nil,
		Layout = nil,
		PrefixLabel = nil,
		SuffixLabel = nil,
		DecimalLabel = nil,
		NegativeLabel = nil,
		Digits = {
			Whole = table.create(3),
			Decimal = table.create(2)
		},
		CommaLabels = table.create(2)
	}
	local t5 = {
		__index = function(p1, p2) --[[ __index | Line: 58 | Upvalues: t (copy), Frame (ref), TextLabel (ref) ]]
			local v1 = t[p2]

			if v1 then
				return v1
			end

			if pcall(function() --[[ Line: 64 | Upvalues: Frame (ref), p2 (copy) ]]
				local _ = Frame[p2]
			end) then
				return t.Frame[p2]
			end

			local ok, result = pcall(function() --[[ Line: 71 | Upvalues: TextLabel (ref), p2 (copy) ]]
				return TextLabel[p2]
			end)

			if not ok then
				return nil
			end

			local v2 = t.Digits.Whole[1]

			if v2 then
				return v2[p2]
			end

			return result
		end,
		__newindex = function(p1, p2, p3) --[[ __newindex | Line: 86 | Upvalues: t2 (ref), Frame (ref), t (copy), t4 (ref), TextLabel (ref), t3 (ref) ]]
			if t2[p2] then
				warn("Attempted to set read-only value Spinner." .. p2)

				return
			end

			if pcall(function() --[[ Line: 93 | Upvalues: Frame (ref), p2 (copy) ]]
				local _ = Frame[p2]
			end) then
				local v2 = typeof(Frame[p2])

				if v2 ~= "nil" and v2 ~= typeof(p3) then
					warn("Attempted to set Spinner." .. p2 .. " to invalid value (" .. tostring(p3) .. ")")

					return
				end

				t.Frame[p2] = p3
			else
				if p2 == "TextXAlignment" then
					t.Layout.HorizontalAlignment = t4[p3]

					return
				end

				if pcall(function() --[[ Line: 113 | Upvalues: TextLabel (ref), p2 (copy) ]]
					local _ = TextLabel[p2]
				end) then
					local v4 = typeof(TextLabel[p2])

					if v4 ~= "nil" and v4 ~= typeof(p3) then
						warn("Attempted to set Spinner." .. p2 .. " to invalid value (" .. tostring(p3) .. ")")

						return
					end

					for k, v in pairs(t.Digits.Whole) do
						v[p2] = p3
					end

					for k, v in pairs(t.Digits.Decimal) do
						v[p2] = p3
					end

					for k, v in pairs(t.CommaLabels) do
						v[p2] = p3
					end

					t.PrefixLabel[p2] = p3
					t.SuffixLabel[p2] = p3
					t.DecimalLabel[p2] = p3
					t.NegativeLabel[p2] = p3
				else
					if not t3[p2] then
						return
					end

					if typeof(p3) == t3[p2] then
						t[p2] = p3
						t:Update(p2, p3)
					else
						warn("Attempted to set Spinner." .. p2 .. " to invalid value (" .. tostring(p3) .. ")")
					end
				end
			end
		end
	}
	local v1 = setmetatable({}, t5)

	function t.Destroy(p1) --[[ Destroy | Line: 151 ]]
		p1.Frame:Destroy()
		table.clear(p1)
	end
	function t.Update(p1, p2) --[[ Update | Line: 156 | Upvalues: t (copy), Digit (ref), v1 (copy) ]]
		if p2 == "Prefix" then
			t.PrefixLabel.Text = t.Prefix

			return
		end

		if p2 == "Suffix" then
			t.SuffixLabel.Text = t.Suffix

			return
		end

		local v2 = math.abs(t.Value)
		local v3 = t.Value < 0

		if t.NegativeLabel then
			t.NegativeLabel.Visible = v3
		end

		local v5 = string.split(t.Decimals > 0 and string.format("%." .. t.Decimals .. "f", v2) or string.format("%d", v2), ".")
		local v6 = v5[1]
		local v7 = v5[2]

		if not v6 then
			return
		end

		local v8 = #v6

		for i = 1, v8 do
			local v9 = t.Digits.Whole[i]

			if v9 then
				v9.Duration = t.Duration
				v9.Value = tonumber((string.sub(v6, i, i)))

				continue
			end

			t.Digits.Whole[i] = Digit.new(v1, i * 2 - 900, (tonumber((string.sub(v6, i, i)))))
		end

		for j = v8 + 1, #t.Digits.Whole do
			local v15 = t.Digits.Whole[j]

			if v15 then
				v15:Destroy()
				t.Digits.Whole[j] = nil
			end
		end

		if t.Commas then
			local count = 0
			local v18 = v8 * 2 - 900

			for k = 0, #string.format("%d", (math.floor((math.abs(t.Value))))) - 1, 3 do
				if k ~= 0 then
					count = count + 1

					local v19 = t.CommaLabels[count]

					if not v19 then
						local Comma = Instance.new("TextLabel")

						Comma.Name = "Comma"
						Comma.BackgroundTransparency = 1
						Comma.Size = UDim2.new(0, 0, 1, 0)
						Comma.FontFace = v1.FontFace
						Comma.TextSize = v1.TextSize
						Comma.TextColor3 = v1.TextColor3
						Comma.Text = ","
						Comma.AutomaticSize = Enum.AutomaticSize.X
						Comma.Parent = t.Frame
						t.CommaLabels[count] = Comma
						v19 = Comma
					end

					v19.LayoutOrder = v18 - (k - 1) * 2 - 1
				end
			end

			for n = count + 1, #t.CommaLabels do
				t.CommaLabels[n]:Destroy()
				t.CommaLabels[n] = nil
			end
		end

		if v7 then
			if t.DecimalLabel then
				t.DecimalLabel.Visible = true
			end

			for m = 1, #v7 do
				local v20 = t.Digits.Decimal[m]

				if v20 then
					v20.Duration = t.Duration
					v20.Value = tonumber((string.sub(v7, m, m)))

					continue
				end

				t.Digits.Decimal[m] = Digit.new(v1, m, (tonumber((string.sub(v7, m, m)))))
			end

			for i = #v7 + 1, #t.Digits.Decimal do
				local v26 = t.Digits.Decimal[i]

				if v26 then
					v26:Destroy()
					t.Digits.Decimal[i] = nil
				end
			end
		else
			if t.DecimalLabel then
				t.DecimalLabel.Visible = false
			end

			for i, v in ipairs(t.Digits.Decimal) do
				v:Destroy()
			end

			table.clear(t.Digits.Decimal)
		end
	end

	return v1, t
end

function t.new() --[[ new | Line: 271 | Upvalues: newSpinner (copy) ]]
	local v1, v2 = newSpinner()
	local Frame = Instance.new("Frame")

	Frame.BackgroundTransparency = 1
	Frame.ClipsDescendants = true
	Frame.Size = UDim2.new(0, 200, 0, 50)
	Frame.Position = UDim2.new(0, 0, 0, 0)

	local UIListLayout = Instance.new("UIListLayout")

	UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder
	UIListLayout.FillDirection = Enum.FillDirection.Horizontal
	UIListLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center
	UIListLayout.VerticalAlignment = Enum.VerticalAlignment.Center
	UIListLayout.Padding = UDim.new(0, 0)
	UIListLayout.Parent = Frame

	local Prefix = Instance.new("TextLabel")

	Prefix.Name = "Prefix"
	Prefix.LayoutOrder = -1000
	Prefix.BackgroundTransparency = 1
	Prefix.Size = UDim2.new(0, 0, 1, 0)
	Prefix.FontFace = v1.FontFace
	Prefix.TextSize = v1.TextSize
	Prefix.TextColor3 = v1.TextColor3
	Prefix.Text = v1.Prefix
	Prefix.AutomaticSize = Enum.AutomaticSize.X
	Prefix.Parent = Frame

	local Suffix = Instance.new("TextLabel")

	Suffix.Name = "Suffix"
	Suffix.LayoutOrder = 1000
	Suffix.BackgroundTransparency = 1
	Suffix.Size = UDim2.new(0, 0, 1, 0)
	Suffix.FontFace = v1.FontFace
	Suffix.TextSize = v1.TextSize
	Suffix.TextColor3 = v1.TextColor3
	Suffix.Text = v1.Suffix
	Suffix.AutomaticSize = Enum.AutomaticSize.X
	Suffix.Parent = Frame

	local Decimal = Instance.new("TextLabel")

	Decimal.Name = "Decimal"
	Decimal.LayoutOrder = 0
	Decimal.BackgroundTransparency = 1
	Decimal.Size = UDim2.new(0, 0, 1, 0)
	Decimal.FontFace = v1.FontFace
	Decimal.TextSize = v1.TextSize
	Decimal.TextColor3 = v1.TextColor3
	Decimal.Text = "."
	Decimal.AutomaticSize = Enum.AutomaticSize.X
	Decimal.Parent = Frame

	local Negative = Instance.new("TextLabel")

	Negative.Name = "Negative"
	Negative.LayoutOrder = -999
	Negative.BackgroundTransparency = 1
	Negative.Size = UDim2.new(0, 0, 1, 0)
	Negative.FontFace = v1.FontFace
	Negative.TextSize = v1.TextSize
	Negative.TextColor3 = v1.TextColor3
	Negative.Text = "-"
	Negative.AutomaticSize = Enum.AutomaticSize.X
	Negative.Parent = Frame
	v2.Frame = Frame
	v2.Layout = UIListLayout
	v2.PrefixLabel = Prefix
	v2.SuffixLabel = Suffix
	v2.DecimalLabel = Decimal
	v2.NegativeLabel = Negative
	v1.Instance = Frame
	v1:Update()

	return v1
end
function t.fromGuiObject(p1) --[[ fromGuiObject | Line: 349 | Upvalues: t (copy), t4 (copy) ]]
	if typeof(p1) ~= "Instance" then
		return
	end

	if not p1:IsA("GuiObject") then
		return
	end

	local v1 = t.new()

	v1.Name = "Spinner_" .. p1.Name
	v1.SizeConstraint = p1.SizeConstraint
	v1.Size = p1.Size
	v1.Position = p1.Position
	v1.AnchorPoint = p1.AnchorPoint
	v1.Rotation = p1.Rotation
	v1.LayoutOrder = p1.LayoutOrder
	v1.ZIndex = p1.ZIndex
	v1.Visible = p1.Visible
	v1.BackgroundColor3 = p1.BackgroundColor3
	v1.BorderColor3 = p1.BorderColor3
	v1.BorderSizePixel = p1.BorderSizePixel
	v1.BackgroundTransparency = p1.BackgroundTransparency

	if p1:IsA("TextLabel") or (p1:IsA("TextButton") or p1:IsA("TextBox")) then
		v1.FontFace = p1.FontFace
		v1.TextSize = p1.TextSize
		v1.TextColor3 = p1.TextColor3
		v1.TextTransparency = p1.TextTransparency
		v1.TextStrokeColor3 = p1.TextStrokeColor3
		v1.TextStrokeTransparency = p1.TextStrokeTransparency
		v1.Layout.HorizontalAlignment = t4[p1.TextXAlignment]
	end

	v1.Parent = p1.Parent
	p1.Visible = false

	return v1
end

return t