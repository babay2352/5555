-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local TextService = game:GetService("TextService")
local TweenService = game:GetService("TweenService")
local v1 = TweenInfo.new(0.15)

return {
	new = function(p1, p2, p3) --[[ new | Line: 8 | Upvalues: TweenService (copy), TextService (copy), v1 (copy) ]]
		local t = {
			Duration = p1.Duration,
			Value = p3,
			Labels = table.create(10),
			CanvasTweens = table.create(10)
		}
		local v12 = TweenInfo.new(p1.Duration)
		local digit = Instance.new("Frame")

		digit.Name = "digit"
		digit.LayoutOrder = p2
		digit.BackgroundTransparency = 1
		digit.Size = UDim2.new(0, 0, 0, p1.TextSize + 6)
		digit.ClipsDescendants = true

		local canvas = Instance.new("Frame")

		canvas.Name = "canvas"
		canvas.Size = UDim2.new(1, 0, 10, 0)
		canvas.BackgroundTransparency = 1
		canvas.Parent = digit
		canvas.Position = UDim2.new(0, 0, -t.Value, 0)

		for i = 0, 9 do
			local TextLabel = Instance.new("TextLabel")

			TextLabel.Name = "n_" .. i
			TextLabel.BackgroundTransparency = 1
			TextLabel.TextSize = p1.TextSize
			TextLabel.TextColor3 = p1.TextColor3
			TextLabel.FontFace = p1.FontFace
			TextLabel.Text = i
			TextLabel.Size = UDim2.new(1, 0, 0.1, 0)
			TextLabel.Position = UDim2.new(0, 0, i * 0.1, 0)
			TextLabel.Parent = canvas
			t.Labels[i] = TextLabel
			t.CanvasTweens[i] = TweenService:Create(canvas, v12, {
				Position = UDim2.new(0, 0, -i, 0)
			})
		end

		digit.Parent = p1.Frame

		local GetTextBoundsParams = Instance.new("GetTextBoundsParams")

		local function updateSize(p12) --[[ updateSize | Line: 52 | Upvalues: GetTextBoundsParams (copy), p1 (copy), TextService (ref), TweenService (ref), digit (copy), v1 (ref), t (copy) ]]
			task.spawn(function() --[[ Line: 53 | Upvalues: GetTextBoundsParams (ref), p1 (ref), TextService (ref), TweenService (ref), digit (ref), v1 (ref), p12 (copy), t (ref) ]]
				GetTextBoundsParams.Text = "8"
				GetTextBoundsParams.Font = p1.FontFace
				GetTextBoundsParams.Size = p1.TextSize
				GetTextBoundsParams.Width = p1.TextSize

				local ok, result = pcall(TextService.GetTextBoundsAsync, TextService, GetTextBoundsParams)

				if not ok then
					return
				end

				local v22 = digit
				local t2 = {}
				local v4 = UDim2.new
				local v6 = if p12 then 0 else result.X + 1

				t2.Size = v4(0, v6, 0, result.Y + 10)

				local v7 = TweenService:Create(v22, v1, t2)

				v7.Completed:Connect(function() --[[ Line: 67 | Upvalues: p12 (ref), digit (ref), t (ref), v7 (copy) ]]
					if p12 then
						digit:Destroy()
						table.clear(t)
					end

					v7:Destroy()
				end)
				v7:Play()
			end)
		end

		local v2 = nil

		task.spawn(function() --[[ Line: 53 | Upvalues: GetTextBoundsParams (copy), p1 (copy), TextService (ref), TweenService (ref), digit (copy), v1 (ref), v2 (copy), t (copy) ]]
			GetTextBoundsParams.Text = "8"
			GetTextBoundsParams.Font = p1.FontFace
			GetTextBoundsParams.Size = p1.TextSize
			GetTextBoundsParams.Width = p1.TextSize

			local ok, result = pcall(TextService.GetTextBoundsAsync, TextService, GetTextBoundsParams)

			if not ok then
				return
			end

			local v22 = digit
			local t2 = {}
			local v4 = UDim2.new
			local v6 = if v2 then 0 else result.X + 1

			t2.Size = v4(0, v6, 0, result.Y + 10)

			local v7 = TweenService:Create(v22, v1, t2)

			v7.Completed:Connect(function() --[[ Line: 67 | Upvalues: v2 (ref), digit (ref), t (ref), v7 (copy) ]]
				if p12 then
					digit:Destroy()
					table.clear(t)
				end

				v7:Destroy()
			end)
			v7:Play()
		end)

		local v3 = setmetatable({}, {
			__index = function(p1, p2) --[[ __index | Line: 82 | Upvalues: t (copy) ]]
				local v1 = t[p2]

				if v1 then
					return v1
				end

				if pcall(function() --[[ Line: 88 | Upvalues: t (ref), p2 (copy) ]]
					local _ = t.Labels[1][p2]
				end) then
					return t.Labels[1][p2]
				end

				return nil
			end,
			__newindex = function(p1, p2, p3) --[[ __newindex | Line: 97 | Upvalues: t (copy) ]]
				if t[p2] then
					t[p2] = p3
					t:Update(p2, p3)

					return
				end

				if not pcall(function() --[[ Line: 105 | Upvalues: t (ref), p2 (copy) ]]
					local _ = t.Labels[1][p2]
				end) then
					return
				end

				t.Labels[0][p2] = p3
				t.Labels[1][p2] = p3
				t.Labels[2][p2] = p3
				t.Labels[3][p2] = p3
				t.Labels[4][p2] = p3
				t.Labels[5][p2] = p3
				t.Labels[6][p2] = p3
				t.Labels[7][p2] = p3
				t.Labels[8][p2] = p3
				t.Labels[9][p2] = p3
				t:Update(p2, p3)
			end
		})

		function t.Destroy(p12) --[[ Destroy | Line: 117 | Upvalues: GetTextBoundsParams (copy), p1 (copy), TextService (ref), TweenService (ref), digit (copy), v1 (ref), t (copy) ]]
			local v12 = true

			task.spawn(function() --[[ Line: 53 | Upvalues: GetTextBoundsParams (ref), p1 (ref), TextService (ref), TweenService (ref), digit (ref), v1 (ref), v12 (copy), t (ref) ]]
				GetTextBoundsParams.Text = "8"
				GetTextBoundsParams.Font = p1.FontFace
				GetTextBoundsParams.Size = p1.TextSize
				GetTextBoundsParams.Width = p1.TextSize

				local ok, result = pcall(TextService.GetTextBoundsAsync, TextService, GetTextBoundsParams)

				if not ok then
					return
				end

				local v22 = digit
				local t2 = {}
				local v4 = UDim2.new
				local v6 = if v12 then 0 else result.X + 1

				t2.Size = v4(0, v6, 0, result.Y + 10)

				local v7 = TweenService:Create(v22, v1, t2)

				v7.Completed:Connect(function() --[[ Line: 67 | Upvalues: v12 (ref), digit (ref), t (ref), v7 (copy) ]]
					if p12 then
						digit:Destroy()
						table.clear(t)
					end

					v7:Destroy()
				end)
				v7:Play()
			end)
		end
		function t.Update(p12, p2, p3) --[[ Update | Line: 121 | Upvalues: v12 (ref), t (copy), TweenService (ref), canvas (copy), GetTextBoundsParams (copy), p1 (copy), TextService (ref), digit (copy), v1 (ref) ]]
			if p2 == "Duration" then
				v12 = TweenInfo.new(p3)

				for i = 0, 9 do
					t.CanvasTweens[i] = TweenService:Create(canvas, v12, {
						Position = UDim2.new(0, 0, -i, 0)
					})
				end
			else
				if p2 == "Value" then
					t.CanvasTweens[p3]:Play()

					return
				end

				if p2 ~= "TextSize" and p2 ~= "FontFace" then
					return
				end

				local v13 = nil

				task.spawn(function() --[[ Line: 53 | Upvalues: GetTextBoundsParams (ref), p1 (ref), TextService (ref), TweenService (ref), digit (ref), v1 (ref), v13 (copy), t (ref) ]]
					GetTextBoundsParams.Text = "8"
					GetTextBoundsParams.Font = p1.FontFace
					GetTextBoundsParams.Size = p1.TextSize
					GetTextBoundsParams.Width = p1.TextSize

					local ok, result = pcall(TextService.GetTextBoundsAsync, TextService, GetTextBoundsParams)

					if not ok then
						return
					end

					local v22 = digit
					local t2 = {}
					local v4 = UDim2.new
					local v6 = if v13 then 0 else result.X + 1

					t2.Size = v4(0, v6, 0, result.Y + 10)

					local v7 = TweenService:Create(v22, v1, t2)

					v7.Completed:Connect(function() --[[ Line: 67 | Upvalues: v13 (ref), digit (ref), t (ref), v7 (copy) ]]
						if p12 then
							digit:Destroy()
							table.clear(t)
						end

						v7:Destroy()
					end)
					v7:Play()
				end)
			end
		end

		return v3
	end
}