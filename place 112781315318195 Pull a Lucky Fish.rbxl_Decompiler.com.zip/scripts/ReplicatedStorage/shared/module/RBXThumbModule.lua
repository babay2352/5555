-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Players = game:GetService("Players")
local t = {}
local t2 = {}

function t.GetAvatarHeadshotUri(p1, p2) --[[ GetAvatarHeadshotUri | Line: 7 | Upvalues: t2 (copy), Players (copy) ]]
	local v1 = tonumber(p2) or 0

	if t2[v1] then
		return t2[v1]
	end

	local ok, result = pcall(function() --[[ Line: 13 | Upvalues: Players (ref), v1 (copy) ]]
		return Players:GetUserThumbnailAsync(v1, Enum.ThumbnailType.HeadShot, Enum.ThumbnailSize.Size150x150)
	end)

	if ok and result then
		t2[v1] = result

		return result
	end

	return ""
end

return t