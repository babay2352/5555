-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local FishConfig = require(ReplicatedStorage.shared.config.FishConfig)
local LuckyblockConfig = require(ReplicatedStorage.shared.config.LuckyblockConfig)
local MountConfig = require(ReplicatedStorage.shared.config.MountConfig)
local Worlds = require(ReplicatedStorage.shared.util.Worlds)
local ConvertValue = require(ReplicatedStorage.shared.util.ConvertValue)
local RollClass = require(ReplicatedStorage.shared.util.RollClass)
local Rotate360 = require(ReplicatedStorage.shared.module.UIVFX.Effects.Rotate360)
local SFX = require(ReplicatedStorage.client.SFX)

local function isFishNew(p1) --[[ isFishNew | Line: 24 | Upvalues: ClientPlayerData (copy) ]]
	local serverProfile = ClientPlayerData.serverProfile

	if not serverProfile then
		return false
	end

	return not (serverProfile:getState().index or {})[p1]
end

local t = {}

local function oddsLabel(p1, p2) --[[ oddsLabel | Line: 39 | Upvalues: FishConfig (copy), ConvertValue (copy), Worlds (copy), RollClass (copy) ]]
	local v1 = FishConfig[p1]

	if v1 and (v1.Beast and v1.BeastChance) then
		return ("1 in %*"):format((ConvertValue.suffixformat(v1.BeastChance)))
	end

	if not p2 then
		return nil
	end

	local v2 = Worlds.GetBiomeById(p2)

	if not v2 then
		return nil
	end

	local v3 = RollClass.fishOdds(p1, v2)

	if v3 and not (v3 <= 0) then
		return ("1 in %*"):format((ConvertValue.suffixformat((math.floor(1 / v3 + 0.5)))))
	end

	return nil
end

function t.fillCard(p1, p2, p3, p4, p5) --[[ fillCard | Line: 66 | Upvalues: LuckyblockConfig (copy), MountConfig (copy), FishConfig (copy), ConvertValue (copy), oddsLabel (copy), ClientPlayerData (copy) ]]
	local v1 = if LuckyblockConfig[p2] == nil then false else true
	local v2 = not v1 and (if MountConfig[p2] == nil then false else true)
	local v3 = if v1 then LuckyblockConfig[p2] elseif v2 then MountConfig[p2] else FishConfig[p2]

	if not v3 then
		return
	end

	local Fish = p1:FindFirstChild("Fish")

	if Fish then
		Fish.Image = if v2 then v3.Icon else v3.Image
	end

	local DisplayName = p1:FindFirstChild("DisplayName")

	if DisplayName then
		DisplayName.Text = if v1 then p2:gsub("_", " ") else v3.DisplayName
	end

	local Rarity = p1:FindFirstChild("Rarity")

	if Rarity and v1 then
		Rarity.Text = ("1 in %*"):format((ConvertValue.suffixformat(LuckyblockConfig.CatchChance or 2500)))
		Rarity.TextColor3 = Color3.fromRGB(255, 60, 0)
	elseif Rarity then
		if v2 then
			Rarity.Text = v3.Rarity.displayName
		else
			Rarity.Text = oddsLabel(p2, p3) or v3.Rarity.displayName
		end

		Rarity.TextColor3 = v3.Rarity.rarityColor
	end

	local NewIndicator = p1:FindFirstChild("NewIndicator")

	if NewIndicator then
		local v7

		if p4 == false then
			v7 = false
		else
			v7 = not v1

			if v7 then
				v7 = not v2

				if v7 then
					local serverProfile = ClientPlayerData.serverProfile

					v7 = if serverProfile then not (serverProfile:getState().index or {})[p2] else false
				end
			end
		end

		NewIndicator.Visible = v7
	end

	local DuplicatedIndicator = p1:FindFirstChild("DuplicatedIndicator")

	if p5 and not DuplicatedIndicator then
		local DuplicatedIndicator2 = Instance.new("TextLabel")

		DuplicatedIndicator2.Name = "DuplicatedIndicator"
		DuplicatedIndicator2.BackgroundTransparency = 1
		DuplicatedIndicator2.AnchorPoint = Vector2.new(0.5, 0.5)
		DuplicatedIndicator2.Position = UDim2.fromScale(0.5, 0.45)
		DuplicatedIndicator2.Size = UDim2.fromScale(0.95, 0.18)
		DuplicatedIndicator2.ZIndex = 10
		DuplicatedIndicator2.Rotation = -12
		DuplicatedIndicator2.Font = Enum.Font.GothamBlack
		DuplicatedIndicator2.TextScaled = true
		DuplicatedIndicator2.Text = "DUPLICATED"
		DuplicatedIndicator2.TextColor3 = Color3.fromRGB(255, 200, 40)

		local UIStroke = Instance.new("UIStroke")

		UIStroke.Thickness = 2
		UIStroke.Color = Color3.fromRGB(70, 40, 0)
		UIStroke.Parent = DuplicatedIndicator2
		DuplicatedIndicator2.Parent = p1
		DuplicatedIndicator = DuplicatedIndicator2
	end

	if not DuplicatedIndicator then
		return
	end

	DuplicatedIndicator.Visible = p5 == true
end

local fillCard = t.fillCard

function t.playMultiple(p1, p2, p3) --[[ playMultiple | Line: 148 | Upvalues: Players (copy), fillCard (copy), Rotate360 (copy), SFX (copy), TweenService (copy) ]]
	if #p1 ~= 0 then
		task.spawn(function() --[[ Line: 150 | Upvalues: Players (ref), p1 (copy), fillCard (ref), p2 (copy), p3 (copy), Rotate360 (ref), SFX (ref), TweenService (ref) ]]
			local CollectFish = Players.LocalPlayer.PlayerGui:WaitForChild("MainUI"):WaitForChild("CollectFish")
			local Fish = CollectFish:FindFirstChild("Fish")

			if not Fish then
				return
			end

			Fish.Visible = false

			local t = {}
			local t2 = {}

			for v1, v2 in p1 do
				local v3 = Fish:Clone()

				fillCard(v3, v2, p2, nil, p3 and p3[v2])
				v3.Name = "FishCard_" .. v2
				v3.Visible = true
				v3.Parent = CollectFish
				table.insert(t, v3)

				local SunRay = v3:FindFirstChild("SunRay")

				if SunRay then
					table.insert(t2, (Rotate360.Apply(SunRay)))
				end
			end

			CollectFish.Visible = true
			SFX.new("rbxassetid://112533303080427", 1)
			TweenService:Create(CollectFish, TweenInfo.new(0.2, Enum.EasingStyle.Bounce), {
				Position = UDim2.fromScale(0.5, 0)
			}):Play()

			for v9, v10 in t do
				local Fish2 = v10:FindFirstChild("Fish")

				if Fish2 and Fish2:IsA("ImageLabel") then
					TweenService:Create(Fish2, TweenInfo.new(1, Enum.EasingStyle.Linear, Enum.EasingDirection.In, 0, true), {
						Rotation = -16,
						Size = UDim2.fromScale(1, 1)
					}):Play()
				end
			end

			task.wait(3)
			TweenService:Create(CollectFish, TweenInfo.new(0.2), {
				Position = UDim2.fromScale(0.5, -0.15)
			}):Play()
			task.wait(0.19)
			CollectFish.Visible = false

			for v11, v12 in t2 do
				v12()
			end

			for v13, v14 in t do
				v14:Destroy()
			end
		end)
	end
end
function t.play(p1, p2) --[[ play | Line: 216 | Upvalues: t (copy) ]]
	t.playMultiple({ p1 }, p2)
end

return t