-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ContentProvider = game:GetService("ContentProvider")
local Debris = game:GetService("Debris")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local SoundService = game:GetService("SoundService")
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")
local BossFishConfig = require(ReplicatedStorage.shared.config.BossFishConfig)
local ClientPlayerData = require(ReplicatedStorage.client.ClientPlayerData)
local FishConfig = require(ReplicatedStorage.shared.config.FishConfig)
local SFX = require(ReplicatedStorage.client.SFX)
local Signal = require(ReplicatedStorage.package.Signal)
local SignalBag = require(ReplicatedStorage.client.SignalBag)
local UIVFX = require(ReplicatedStorage.shared.module.UIVFX)
local VFX = require(ReplicatedStorage.client.VFX)
local createAnimationInstance = require(ReplicatedStorage.shared.util.createAnimationInstance)
local t = {}
local BossFishModels = ReplicatedStorage.shared.model.BossFishModels
local CurrentCamera = workspace.CurrentCamera
local t2 = {
	Shark_Boss = {
		Idle = createAnimationInstance("rbxassetid://133906755639040"),
		ShowUp = createAnimationInstance("rbxassetid://72748484860570"),
		Defeat = createAnimationInstance("rbxassetid://137466534630455")
	},
	boss_world2 = {
		Idle = createAnimationInstance("rbxassetid://78351535303382"),
		ShowUp = createAnimationInstance("rbxassetid://101154884563365"),
		Defeat = createAnimationInstance("rbxassetid://102036861411433")
	}
}
local v1 = SoundService:QueryDescendants("Sound#BossFightTheme")[1]
local v2 = SoundService:QueryDescendants("SoundGroup#SFX > Sound#BossRollSound")[1]
local t3 = { Color3.fromHex("#aa0000"), Color3.fromHex("#facb31"), Color3.fromHex("#00d60b") }

local function createVFXHost(p1) --[[ createVFXHost | Line: 89 | Upvalues: Debris (copy) ]]
	local Part = Instance.new("Part")

	Part.Anchored = true
	Part.CanCollide = false
	Part.CanQuery = false
	Part.CanTouch = false
	Part.Transparency = 1
	Part.Size = Vector3.new(0.1, 0.1, 0.1)
	Part.CFrame = CFrame.new(p1)
	Part.Parent = workspace
	Debris:AddItem(Part, 3)

	return Part
end

function t.SetupMinigame(p1, p2) --[[ SetupMinigame | Line: 103 | Upvalues: Players (copy), RunService (copy), UIVFX (copy), TweenService (copy), t3 (copy), SignalBag (copy), v1 (copy), ClientPlayerData (copy), Signal (copy), BossFishConfig (copy), FishConfig (copy), SFX (copy), UserInputService (copy), v2 (copy) ]]
	local BossFightUI = Players.LocalPlayer.PlayerGui:WaitForChild("BossFightUI")

	BossFightUI.PullProgress.Visible = false

	local v12 = 0
	local v22 = RunService.RenderStepped:Connect(function(p1) --[[ Line: 109 | Upvalues: v12 (ref), BossFightUI (copy) ]]
		v12 = v12 + p1

		if v12 >= 6.283185307179586 then
			v12 = v12 - 6.283185307179586
		end

		BossFightUI.Countdown.ShadowCountdownLabel.UIShadow.Transparency = math.sin(v12) * 0.075 + 0.675
	end)

	BossFightUI.Countdown.Visible = true
	BossFightUI.Enabled = true
	UIVFX.BossVignette.Start(Color3.fromHex("#000000"))

	local v3 = TweenService:Create(BossFightUI.Countdown.Number, TweenInfo.new(0.8), {
		Position = UDim2.fromScale(0.5, 0.5)
	})

	for i = 3, 1, -1 do
		BossFightUI.Countdown.Number.Position = UDim2.fromScale(0.5, -2)
		v3:Play()
		BossFightUI.Countdown.Number.Text = tostring(i)
		BossFightUI.Countdown.Number.TextColor3 = t3[i] or t3[1]
		SignalBag.PlaySoundByName:Fire("BossCountdown")
		task.wait(1)
	end

	UIVFX.BossVignette.Stop()
	BossFightUI.Countdown.Visible = false
	v22:Disconnect()

	if v1 and (ClientPlayerData.serverProfile:getState().settings.musicEnabled and not v1.IsPlaying) then
		v1:Play()
	end

	local v5 = Signal.new()
	local v6 = false
	local v7 = Instance.new("NumberValue")

	v7.Changed:Connect(function(p1) --[[ Line: 149 | Upvalues: BossFightUI (copy) ]]
		local v1 = math.clamp(p1 / 100, 0, 1)

		BossFightUI.PullProgress.ProgressBar.Progress.Size = UDim2.fromScale(v1, 1)
		BossFightUI.PullProgress.ProgressBar.Progress.BackgroundColor3 = Color3.fromHex("#dd0000"):Lerp(Color3.fromHex("#00dd00"), v1)
	end)
	v7.Value = BossFishConfig.START_PROGRESS

	local fromScale = UDim2.fromScale
	local v8 = BossFishConfig.START_PROGRESS / 100

	BossFightUI.PullProgress.ProgressBar.Progress.Size = fromScale(math.clamp(v8, 0, 1), 1)

	local v9 = 0
	local v10 = -1
	local TargetFrame = BossFightUI.PullProgress.PullMinigameFrame.TargetFrame
	local Indicator = BossFightUI.PullProgress.PullMinigameFrame.Indicator
	local FleeBar = BossFightUI.PullProgress.FleeBar
	local FleeLabel = BossFightUI.PullProgress.FleeLabel

	TargetFrame.FishIcon.Image = if FishConfig[p2] then FishConfig[p2].Image else ""

	local fromScale2 = UDim2.fromScale
	local Min = BossFishConfig.TARGET_SIZE_RANGE.Min
	local Max = BossFishConfig.TARGET_SIZE_RANGE.Max

	TargetFrame.Size = fromScale2(math.lerp(Min, Max, Random.new():NextNumber()), 1)

	local v13 = Random.new(os.clock())
	local v15 = math.lerp(0, 1 - TargetFrame.Size.X.Scale, v13:NextNumber())

	Indicator.Position = UDim2.fromScale(0.5, 0.5)

	local v16 = Instance.new("BoolValue")
	local v17 = nil

	v16.Changed:Connect(function(p1) --[[ Line: 181 | Upvalues: v17 (ref), UIVFX (ref), SFX (ref) ]]
		if v17 and typeof(v17) == "function" then
			pcall(v17)
			v17 = nil
		end

		if p1 then
			UIVFX.BossVignette.Start(Color3.fromHex("#ff0000"))
			v17 = SFX.NewLooped(SFX.Sounds.Alarm, 0.45, 0)
		else
			UIVFX.BossVignette.Stop()
		end
	end)

	local t = {}

	local function adjustTooltip() --[[ adjustTooltip | Line: 196 | Upvalues: UserInputService (ref), BossFightUI (copy) ]]
		local PreferredInput = UserInputService.PreferredInput

		if PreferredInput == Enum.PreferredInput.KeyboardAndMouse then
			BossFightUI.PullProgress.TipLabelFrame.TipText.Text = "Click & Hold to pull"

			return
		end

		if PreferredInput == Enum.PreferredInput.Touch then
			BossFightUI.PullProgress.TipLabelFrame.TipText.Text = "Tap & Hold to pull"

			return
		end

		if PreferredInput ~= Enum.PreferredInput.Gamepad then
			return
		end

		BossFightUI.PullProgress.TipLabelFrame.TipText.Text = "Hold to pull"
	end

	adjustTooltip()

	local v18 = UserInputService:GetPropertyChangedSignal("PreferredInput"):Connect(adjustTooltip)
	local v19 = UserInputService.TouchStarted:Connect(function(p1) --[[ Line: 210 | Upvalues: t (copy) ]]
		if table.find(t, p1) then
			return
		end

		table.insert(t, p1)
	end)
	local v20 = UserInputService.TouchEnded:Connect(function(p1) --[[ Line: 216 | Upvalues: t (copy) ]]
		local v1 = table.find(t, p1)

		if not v1 then
			return
		end

		table.remove(t, v1)
	end)
	local v21 = UserInputService.InputChanged:Connect(function(p1) --[[ Line: 223 | Upvalues: v10 (ref) ]]
		if p1.KeyCode ~= Enum.KeyCode.ButtonR2 then
			return
		end

		v10 = math.lerp(-1, 1, p1.Position.Z)
	end)
	local v222 = RunService.RenderStepped:Connect(function(p1) --[[ Line: 229 | Upvalues: UserInputService (ref), t (copy), v10 (ref), Indicator (copy), TargetFrame (copy), v2 (ref), v7 (copy), BossFishConfig (ref), v9 (ref), v16 (copy), FleeBar (copy), FleeLabel (copy), v6 (ref), v5 (copy), v15 (ref), v13 (copy) ]]
		if UserInputService:IsMouseButtonPressed(Enum.UserInputType.MouseButton1) or #t ~= 0 then
			v10 = 1
		elseif UserInputService.PreferredInput == Enum.PreferredInput.KeyboardAndMouse or UserInputService.PreferredInput == Enum.PreferredInput.Touch and #t == 0 then
			v10 = -1
		end

		local v22 = if math.clamp(Indicator.AbsolutePosition.X, TargetFrame.AbsolutePosition.X, TargetFrame.AbsolutePosition.X + TargetFrame.AbsoluteSize.X) == Indicator.AbsolutePosition.X then true else false

		if v2 and (v22 and not v2.IsPlaying) then
			v2:Play()
		elseif v2 and (not v22 and v2.IsPlaying) then
			v2:Stop()
		end

		v7.Value = math.clamp(v7.Value + (if v22 then 1 else -1) * p1 * BossFishConfig.PROGRESS_GAIN, 0, 100)

		if v7.Value == 0 and v9 == 0 then
			v9 = os.clock()
		elseif v7.Value ~= 0 then
			v9 = 0
		end

		v16.Value = if v9 == 0 then false else true
		FleeBar.Visible = if v9 == 0 then false else true
		FleeLabel.Visible = if v9 == 0 then false else true

		local v132 = v9 ~= 0 and os.clock() - v9 or 0

		FleeBar.Progress.Size = UDim2.fromScale(math.clamp(1 - v132 / BossFishConfig.FAIL_IMMUNITY_WINDOW, 0, 1), 1)
		FleeBar.TimeLeft.Text = ("%*s"):format((string.format("%.1f", BossFishConfig.FAIL_IMMUNITY_WINDOW - v132)))

		if v7.Value == 0 and (v9 ~= 0 and BossFishConfig.FAIL_IMMUNITY_WINDOW < v132) then
			v6 = false
			v5:Fire()

			return
		end

		if v7.Value == 100 then
			v6 = true
			v5:Fire()

			return
		end

		Indicator.Position = UDim2.fromScale(math.clamp(Indicator.Position.X.Scale + v10 * p1 * BossFishConfig.INDICATOR_SPEED, 0, 1), 0.5)

		local v18 = math.sign(v10)

		Indicator.ArrowLeft.Visible = v18 == 1
		Indicator.ArrowRight.Visible = if v18 == -1 then true else false

		if math.abs(TargetFrame.Position.X.Scale - v15) < 0.01 then
			v15 = math.lerp(0, 1 - TargetFrame.Size.X.Scale, v13:NextNumber())
		end

		local v24 = 1

		for v25, v26 in BossFishConfig.TARGET_MULTIPLIER_TRESHOLDS do
			if BossFishConfig.TARGET_SPEED_MULTIPLIERS[v25] and v26 <= v7.Value then
				v24 = BossFishConfig.TARGET_SPEED_MULTIPLIERS[v25]
			end
		end

		TargetFrame.Position = UDim2.fromScale(math.clamp(TargetFrame.Position.X.Scale + (if v15 < TargetFrame.Position.X.Scale then -1 else 1) * p1 * (BossFishConfig.TARGET_SPEED * v24), 0, 1 - TargetFrame.Size.X.Scale), 0.5)
	end)

	BossFightUI.PullProgress.Visible = true
	v5:Wait()
	v222:Disconnect()
	v20:Disconnect()
	v19:Disconnect()
	v5:Destroy()
	v7:Destroy()
	v16:Destroy()
	v21:Disconnect()
	v18:Disconnect()
	UIVFX.BossVignette.Stop()

	if v2 then
		v2:Stop()
	end

	if not v17 then
		BossFightUI.PullProgress.Visible = false
		BossFightUI.Enabled = false

		return v6
	end

	local v23 = v17

	if typeof(v23) ~= "function" then
		BossFightUI.PullProgress.Visible = false
		BossFightUI.Enabled = false

		return v6
	end

	pcall(v17)
	v17 = nil
	BossFightUI.PullProgress.Visible = false
	BossFightUI.Enabled = false

	return v6
end
function t.GetAnimationTracks(p1, p2, p3) --[[ GetAnimationTracks | Line: 340 | Upvalues: t2 (copy), ContentProvider (copy) ]]
	if not t2[p3] then
		return {}
	end

	local v1 = p2:QueryDescendants("Animator")[1]

	if not v1 then
		return {}
	end

	local t = {}
	local t3 = {}

	for v2, v3 in t2[p3] do
		t[v2] = v1:LoadAnimation(v3)
		table.insert(t3, v3)
	end

	ContentProvider:PreloadAsync(t3)

	return t
end
function t.InitBossSequence(p1, p2, p3, p4) --[[ InitBossSequence | Line: 362 | Upvalues: BossFishModels (copy), t2 (copy), CurrentCamera (copy), t (copy), VFX (copy), Debris (copy), SignalBag (copy), TweenService (copy), RunService (copy), v1 (copy) ]]
	local v12 = BossFishModels:FindFirstChild(p2)

	if not (v12 and v12:IsA("Model")) then
		error((("No boss model for %*"):format(p2)))
	end

	if not t2[p2] then
		error((("No animation set for %*"):format(p2)))
	end

	local v2 = -CurrentCamera.CFrame.LookVector * Vector3.new(1, 0, 1)
	local v3 = CFrame.lookAlong(p3.CFrame.Position - Vector3.new(0, 20, 0), v2, Vector3.new(0, 1, 0))
	local v4 = v12:Clone()

	v4:PivotTo(v3)
	v4.Parent = workspace.CurrentCamera
	CurrentCamera.CFrame = CFrame.lookAt(v3.Position + Vector3.new(0, 30, 0) + v2 * 60, v3.Position)

	local CFrameValue = Instance.new("CFrameValue")

	CFrameValue.Value = v3
	CFrameValue.Changed:Connect(function(p1) --[[ Line: 382 | Upvalues: v4 (copy), CurrentCamera (ref), v3 (copy), v2 (copy) ]]
		v4:PivotTo(p1)
		CurrentCamera.CFrame = CFrame.lookAt(v3.Position + Vector3.new(0, 30, 0) + v2 * 60, p1.Position)
	end)

	if p4 then
		for v5, v6 in p4:GetDescendants() do
			if v6:IsA("BasePart") then
				v6.LocalTransparencyModifier = 1
			end
		end
	end

	local v7 = t:GetAnimationTracks(v4, p2)
	local v8 = v4:QueryDescendants("Attachment#NoseTip")[1]
	local v9 = (-1 / 0)

	local function playBossSplash(p1) --[[ playBossSplash | Line: 401 | Upvalues: v9 (ref), VFX (ref), Debris (ref) ]]
		local v1 = os.clock()

		if not (v1 - v9 < 0.25) then
			v9 = v1

			local Part = Instance.new("Part")

			Part.Anchored = true
			Part.CanCollide = false
			Part.CanQuery = false
			Part.CanTouch = false
			Part.Transparency = 1
			Part.Size = Vector3.new(0.1, 0.1, 0.1)
			Part.CFrame = CFrame.new(p1)
			Part.Parent = workspace
			Debris:AddItem(Part, 3)
			VFX.new("BossSplash", Part)
		end
	end

	for v10, v11 in v7 do
		v11:GetMarkerReachedSignal("WaterSplash"):Connect(function() --[[ Line: 411 | Upvalues: SignalBag (ref), VFX (ref), v4 (copy), v9 (ref), Debris (ref) ]]
			SignalBag.PlaySoundByName:Fire("BossWaterSplash")
			VFX.new("BossWaterSplash", v4.PrimaryPart)

			local Position = v4:GetPivot().Position
			local v1 = os.clock()

			if not (v1 - v9 < 0.25) then
				v9 = v1

				local Part = Instance.new("Part")

				Part.Anchored = true
				Part.CanCollide = false
				Part.CanQuery = false
				Part.CanTouch = false
				Part.Transparency = 1
				Part.Size = Vector3.new(0.1, 0.1, 0.1)
				Part.CFrame = CFrame.new(Position)
				Part.Parent = workspace
				Debris:AddItem(Part, 3)
				VFX.new("BossSplash", Part)
			end
		end)
		v11:GetMarkerReachedSignal("Bite"):Connect(function() --[[ Line: 417 | Upvalues: SignalBag (ref), CurrentCamera (ref), TweenService (ref), v8 (copy), v4 (copy), VFX (ref), v2 (copy), Debris (ref) ]]
			SignalBag.PlaySoundByName:Fire("BossBite")
			CurrentCamera.FieldOfView = 65

			local v1 = TweenService:Create(CurrentCamera, TweenInfo.new(0.5), {
				FieldOfView = 70
			})

			v1.Completed:Once(function() --[[ Line: 421 | Upvalues: v1 (copy) ]]
				v1:Destroy()
			end)
			v1:Play()

			local v22 = if v8 then v8.WorldPosition else v4:GetPivot().Position
			local Part = Instance.new("Part")

			Part.Anchored = true
			Part.CanCollide = false
			Part.CanQuery = false
			Part.CanTouch = false
			Part.Transparency = 1
			Part.Size = Vector3.new(0.1, 0.1, 0.1)
			Part.CFrame = CFrame.new(v22 + v2 * 8)
			Part.Parent = workspace
			Debris:AddItem(Part, 3)
			VFX.new("BossAttack", Part)
		end)
	end

	if v7.Idle then
		v7.Idle:Play(0, 10)
	end

	local v122 = v4:QueryDescendants("Bone.AttachBone")[1]
	local v13 = RunService.RenderStepped:Connect(function() --[[ Line: 437 | Upvalues: v122 (copy), p4 (copy) ]]
		if not (v122 and p4) then
			return
		end

		p4:PivotTo(CFrame.lookAlong(v122.TransformedWorldCFrame.Position, p4:GetPivot().LookVector))
	end)

	if v7.ShowUp then
		v7.ShowUp.Looped = false

		local v14 = TweenService:Create(CFrameValue, TweenInfo.new(3), {
			Value = v3 * CFrame.new(0, 27, 0)
		})

		v14:Play()
		v14.Completed:Once(function() --[[ Line: 450 | Upvalues: v14 (copy) ]]
			v14:Destroy()
		end)
		v7.ShowUp:Play(0, 100)
		v7.ShowUp.Ended:Wait()
	end

	local v15 = RunService.RenderStepped:Connect(function() --[[ Line: 462 | Upvalues: v8 (copy), CurrentCamera (ref) ]]
		if not v8 then
			return
		end

		local Position = CurrentCamera.CFrame.Position
		local v1 = (v8.WorldPosition - Position) * Vector3.new(1, 0, 1)

		if not (v1.Magnitude < 0.001) then
			CurrentCamera.CFrame = CFrame.lookAlong(Position, v1, Vector3.new(0, 1, 0))
		end
	end)
	local v16 = t:SetupMinigame(p2)

	v15:Disconnect()

	if v7.Idle then
		v7.Idle:Stop(0)
	end

	if v16 then
		SignalBag.PlaySoundByName:Fire("BossDefeat")

		local Position = v4:GetPivot().Position
		local v17 = Vector3.new(Position.X, p3.CFrame.Position.Y, Position.Z)
		local v18 = os.clock()

		if not (v18 - v9 < 0.25) then
			v9 = v18

			local Part = Instance.new("Part")

			Part.Anchored = true
			Part.CanCollide = false
			Part.CanQuery = false
			Part.CanTouch = false
			Part.Transparency = 1
			Part.Size = Vector3.new(0.1, 0.1, 0.1)
			Part.CFrame = CFrame.new(v17)
			Part.Parent = workspace
			Debris:AddItem(Part, 3)
			VFX.new("BossSplash", Part)
		end

		if v7.Defeat then
			v7.Defeat.Looped = false

			local v20 = TweenService:Create(CFrameValue, TweenInfo.new(3), {
				Value = v3
			})

			v20:Play()
			v20.Completed:Once(function() --[[ Line: 494 | Upvalues: v20 (copy) ]]
				v20:Destroy()
			end)
			v7.Defeat:Play(0, 100)
			v7.Defeat.Ended:Wait()
			task.wait(0.5)
		end
	end

	if not v1 then
		CFrameValue:Destroy()
		v4:Destroy()
		v13:Disconnect()

		return v16
	end

	v1:Stop()
	CFrameValue:Destroy()
	v4:Destroy()
	v13:Disconnect()

	return v16
end

return t