-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local t = {}
local v1 = nil
local v2 = Instance.new("BindableEvent")

t.Changed = v2.Event
function t.Set(p1) --[[ Set | Line: 22 | Upvalues: v1 (ref), v2 (copy) ]]
	if v1 ~= p1 then
		v1 = p1
		v2:Fire(p1)
	end
end
function t.Get() --[[ Get | Line: 30 | Upvalues: v1 (ref) ]]
	if not v1 or v1.Parent then
		return v1
	end

	v1 = nil

	return v1
end

return t