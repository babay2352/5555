-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local RunService = game:GetService("RunService")
local t = {}
local t2 = {}
local v1 = nil

local function ensureLoop() --[[ ensureLoop | Line: 20 | Upvalues: v1 (ref), RunService (copy), t2 (copy) ]]
	if not v1 then
		v1 = RunService.RenderStepped:Connect(function() --[[ Line: 24 | Upvalues: t2 (ref), v1 (ref) ]]
			debug.profilebegin("UIVFX.Shake")

			local v12 = os.clock()

			for v2, v3 in t2 do
				if v2.Parent then
					local v4 = v3.endsAt - v12

					if v4 <= 0 then
						v2.Rotation = 0
						t2[v2] = nil

						continue
					end

					local v6 = math.clamp(v4 / v3.duration, 0, 1)

					v2.Rotation = (math.random() - 0.5) * 2 * v3.amplitude * v6

					continue
				end

				t2[v2] = nil
			end

			if next(t2) == nil and v1 then
				v1:Disconnect()
				v1 = nil
			end

			debug.profileend()
		end)
	end
end

function t.Shake(p1, p2, p3) --[[ Shake | Line: 52 | Upvalues: t2 (copy), v1 (ref), RunService (copy) ]]
	if not p1:IsA("GuiObject") then
		return
	end

	local v12 = p3 or 0.35

	if (p2 or 2) <= 0 then
		return
	end

	t2[p1] = {
		amplitude = p2 or 2,
		endsAt = os.clock() + v12,
		duration = v12
	}

	if not v1 then
		v1 = RunService.RenderStepped:Connect(function() --[[ Line: 24 | Upvalues: t2 (ref), v1 (ref) ]]
			debug.profilebegin("UIVFX.Shake")

			local v12 = os.clock()

			for v2, v3 in t2 do
				if v2.Parent then
					local v4 = v3.endsAt - v12

					if v4 <= 0 then
						v2.Rotation = 0
						t2[v2] = nil

						continue
					end

					local v6 = math.clamp(v4 / v3.duration, 0, 1)

					v2.Rotation = (math.random() - 0.5) * 2 * v3.amplitude * v6

					continue
				end

				t2[v2] = nil
			end

			if next(t2) == nil and v1 then
				v1:Disconnect()
				v1 = nil
			end

			debug.profileend()
		end)
	end
end

return t