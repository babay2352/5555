-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Players = game:GetService("Players")
local TweenService = game:GetService("TweenService")
local v1 = TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true, 0)
local t = {}
local v2 = nil

local function findVignette() --[[ findVignette | Line: 25 | Upvalues: Players (copy) ]]
	local PlayerGui = Players.LocalPlayer:FindFirstChildOfClass("PlayerGui")
	local v1 = if PlayerGui then PlayerGui:FindFirstChild("MainUI") else PlayerGui
	local v2 = if v1 then v1:FindFirstChild("Effects") else v1
	local v3 = if v2 then v2:FindFirstChild("Vignette") else v2

	if v3 and v3:IsA("ImageLabel") then
		return v3
	end

	return nil
end

function t.Start(p1) --[[ Start | Line: 35 | Upvalues: findVignette (copy), v2 (ref), TweenService (copy), v1 (copy) ]]
	local v12 = findVignette()

	if not v12 then
		warn("[UIVFX.Vignette] PlayerGui.MainUI.Effects.Vignette ImageLabel not found")

		return
	end

	if p1 then
		v12.ImageColor3 = p1
	end

	v12.Visible = true
	v12.ImageTransparency = 1

	if v2 then
		v2:Cancel()
	end

	v2 = TweenService:Create(v12, v1, {
		ImageTransparency = 0.5
	})
	v2:Play()
end
function t.Stop() --[[ Stop | Line: 55 | Upvalues: v2 (ref), findVignette (copy) ]]
	if v2 then
		v2:Cancel()
		v2 = nil
	end

	local v1 = findVignette()

	if not v1 then
		return
	end

	v1.ImageTransparency = 1
	v1.Visible = false
end

return t