-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local TweenService = game:GetService("TweenService")
local v1 = TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local v2 = TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local t = {}
local t2 = {}

local function ensureScale(p1) --[[ ensureScale | Line: 12 ]]
	local VFX_PulseScale = p1:FindFirstChild("VFX_PulseScale")

	if VFX_PulseScale and VFX_PulseScale:IsA("UIScale") then
		return VFX_PulseScale
	end

	local VFX_PulseScale2 = Instance.new("UIScale")

	VFX_PulseScale2.Name = "VFX_PulseScale"
	VFX_PulseScale2.Parent = p1

	return VFX_PulseScale2
end

function t.Pulse(p1, p2) --[[ Pulse | Line: 23 | Upvalues: t2 (copy), TweenService (copy), v1 (copy), v2 (copy) ]]
	if not p1:IsA("GuiObject") then
		return
	end

	local VFX_PulseScale = p1:FindFirstChild("VFX_PulseScale")
	local v12

	if VFX_PulseScale and VFX_PulseScale:IsA("UIScale") then
		v12 = VFX_PulseScale
	else
		local VFX_PulseScale2 = Instance.new("UIScale")

		VFX_PulseScale2.Name = "VFX_PulseScale"
		VFX_PulseScale2.Parent = p1
		v12 = VFX_PulseScale2
	end

	if t2[v12] then
		t2[v12]:Cancel()
	end

	v12.Scale = 1

	local v3 = TweenService:Create(v12, v1, {
		Scale = p2 or 1.2
	})

	t2[v12] = v3
	v3.Completed:Connect(function(p1) --[[ Line: 37 | Upvalues: t2 (ref), v12 (copy), v3 (copy), TweenService (ref), v2 (ref) ]]
		if p1 == Enum.PlaybackState.Completed and t2[v12] == v3 then
			local v1 = TweenService:Create(v12, v2, {
				Scale = 1
			})

			t2[v12] = v1
			v1.Completed:Connect(function() --[[ Line: 43 | Upvalues: t2 (ref), v12 (ref), v1 (copy) ]]
				if t2[v12] ~= v1 then
					return
				end

				t2[v12] = nil
			end)
			v1:Play()
		end
	end)
	v3:Play()
end

return t