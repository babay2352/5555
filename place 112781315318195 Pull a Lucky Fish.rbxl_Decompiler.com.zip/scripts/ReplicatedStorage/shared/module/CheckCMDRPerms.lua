-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local EnvironmentConfig = require(ReplicatedStorage.shared.config.EnvironmentConfig)
local t = {}
local t2 = {
	53448130,
	4559632742,
	928935651,
	7265249267,
	10336180008,
	73900036,
	257500145,
	1527756610,
	2648293631
}
local t3 = {}

local function isGroupTester(p1) --[[ isGroupTester | Line: 18 | Upvalues: t3 (copy), EnvironmentConfig (copy) ]]
	local v1 = t3[p1.UserId]

	if v1 and os.clock() < v1.expires then
		return v1.isTester
	end

	local ok, result = pcall(p1.GetRoleInGroup, p1, EnvironmentConfig.TESTER_GROUP_ID)
	local v2 = if ok then table.find(EnvironmentConfig.TESTER_ROLE_NAMES, result) ~= nil else ok
	local t = {
		isTester = v2
	}

	t.expires = os.clock() + (if ok then 300 else 15)
	t3[p1.UserId] = t

	return v2
end

local v1, v2

if not RunService:IsServer() then
	v1 = {
		{
			Name = "BuyAdmin",
			CheckFunction = function(p13) --[[ CheckFunction | Line: 44 ]]
				return false
			end
		},
		{
			Name = "Influ",
			CheckFunction = function(p13) --[[ CheckFunction | Line: 50 | Upvalues: t (copy) ]]
				return table.find(t, p13.UserId) ~= nil
			end
		},
		{
			Name = "Tester",
			CheckFunction = function(p13) --[[ CheckFunction | Line: 56 | Upvalues: EnvironmentConfig (copy), isGroupTester (copy) ]]
				return EnvironmentConfig.isTestUniverse() and isGroupTester(p13)
			end
		},
		{
			Name = "Admin",
			CheckFunction = function(p13) --[[ CheckFunction | Line: 63 | Upvalues: t2 (copy) ]]
				return table.find(t2, p13.UserId) ~= nil
			end
		}
	}
	v2 = #v1

	return {
		Ranks = v1,
		CommandPermissionLevel = {
			BuyAdmin = 1,
			Influ = 2,
			Tester = 3,
			Admin = 4
		},
		CheckPlayerPermissionLevel = function(p13) --[[ CheckPlayerPermissionLevel | Line: 79 | Upvalues: RunService (copy), v2 (copy), v1 (copy) ]]
			if RunService:IsStudio() then
				return v2
			end

			local v12 = 0

			for v22, v3 in v1 do
				if v3.CheckFunction(p13) then
					v12 = v22
				end
			end

			return v12
		end,
		MAX_LEVEL = v2,
		CoolDowns = {
			Fire = {
				[1] = 60,
				[3] = 100
			},
			Police = { 60 },
			Freeze = { 60 },
			Airstrike = {
				[2] = 120
			},
			Legendary = {
				[2] = 120
			},
			Kick = {
				[2] = 1800
			},
			Open = { 120, 120 }
		}
	}
end

Players.PlayerRemoving:Connect(function(p1) --[[ Line: 34 | Upvalues: t3 (copy) ]]
	t3[p1.UserId] = nil
end)
v1 = {
	{
		Name = "BuyAdmin",
		CheckFunction = function(p13) --[[ CheckFunction | Line: 44 ]]
			return false
		end
	},
	{
		Name = "Influ",
		CheckFunction = function(p13) --[[ CheckFunction | Line: 50 | Upvalues: t (copy) ]]
			return table.find(t, p13.UserId) ~= nil
		end
	},
	{
		Name = "Tester",
		CheckFunction = function(p13) --[[ CheckFunction | Line: 56 | Upvalues: EnvironmentConfig (copy), isGroupTester (copy) ]]
			return EnvironmentConfig.isTestUniverse() and isGroupTester(p13)
		end
	},
	{
		Name = "Admin",
		CheckFunction = function(p13) --[[ CheckFunction | Line: 63 | Upvalues: t2 (copy) ]]
			return table.find(t2, p13.UserId) ~= nil
		end
	}
}
v2 = #v1

return {
	Ranks = v1,
	CommandPermissionLevel = {
		BuyAdmin = 1,
		Influ = 2,
		Tester = 3,
		Admin = 4
	},
	CheckPlayerPermissionLevel = function(p13) --[[ CheckPlayerPermissionLevel | Line: 79 | Upvalues: RunService (copy), v2 (copy), v1 (copy) ]]
		if RunService:IsStudio() then
			return v2
		end

		local v12 = 0

		for v22, v3 in v1 do
			if v3.CheckFunction(p13) then
				v12 = v22
			end
		end

		return v12
	end,
	MAX_LEVEL = v2,
	CoolDowns = {
		Fire = {
			[1] = 60,
			[3] = 100
		},
		Police = { 60 },
		Freeze = { 60 },
		Airstrike = {
			[2] = 120
		},
		Legendary = {
			[2] = 120
		},
		Kick = {
			[2] = 1800
		},
		Open = { 120, 120 }
	}
}