-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local v1 = nil
local t = {}

return {
	register = function(p1, p2) --[[ register | Line: 32 | Upvalues: t (copy) ]]
		t[p1] = p2
	end,
	claim = function(p1) --[[ claim | Line: 36 | Upvalues: v1 (ref), t (copy) ]]
		if v1 == p1 then
			return
		end

		local v12 = v1

		v1 = p1

		if not v12 then
			return
		end

		local v2 = t[v12]

		if not v2 then
			return
		end

		v2()
	end,
	tryClaim = function(p1) --[[ tryClaim | Line: 50 | Upvalues: v1 (ref) ]]
		if v1 ~= nil and v1 ~= p1 then
			return false
		end

		v1 = p1

		return true
	end,
	release = function(p1) --[[ release | Line: 58 | Upvalues: v1 (ref) ]]
		if v1 ~= p1 then
			return
		end

		v1 = nil
	end
}