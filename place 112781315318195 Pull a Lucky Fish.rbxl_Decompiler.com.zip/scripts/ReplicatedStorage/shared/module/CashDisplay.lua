-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TextService = game:GetService("TextService")
local CashFormat = require(ReplicatedStorage.shared.util.CashFormat)
local CashTierConfig = require(ReplicatedStorage.shared.config.CashTierConfig)
local ConvertValue = require(ReplicatedStorage.shared.util.ConvertValue)
local t = {}
local t2 = {}
local t3 = {}
local v1 = nil

local function trackHost(p1) --[[ trackHost | Line: 73 | Upvalues: t2 (copy), t3 (copy) ]]
	p1.Destroying:Once(function() --[[ Line: 74 | Upvalues: t2 (ref), p1 (copy), t3 (ref) ]]
		t2[p1] = nil
		t3[p1] = nil
	end)
end

local v2 = nil

local function getTemplateMaster() --[[ getTemplateMaster | Line: 88 | Upvalues: v2 (ref), Players (copy) ]]
	if v2 then
		return v2
	end

	local v1 = Players.LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("MainUI"):WaitForChild("HUD"):WaitForChild("Counters"):WaitForChild("Cash"):WaitForChild("UIListLayout"):WaitForChild("CashFrameTemplate"):Clone()

	v1.Visible = true
	v2 = v1

	return v1
end

function t.render(p1, p2, p3) --[[ render | Line: 108 | Upvalues: CashFormat (copy), t2 (copy), t3 (copy), getTemplateMaster (copy), v1 (ref) ]]
	local v12 = if CashFormat.iconsEnabled() or not (p3 and p3.SuffixIcon) then CashFormat.segments(p2, if p3 then p3.MaxSegments else p3) else { CashFormat.suffixSegment(p2, true) }
	local v4 = t2[p1]

	if not v4 then
		local t = {
			kind = "render",
			frames = {},
			lastIcon = {},
			lastText = {}
		}

		t2[p1] = t
		p1.Destroying:Once(function() --[[ Line: 74 | Upvalues: t2 (ref), p1 (copy), t3 (ref) ]]
			t2[p1] = nil
			t3[p1] = nil
		end)
		v4 = t

		for v5, v6 in p1:GetChildren() do
			if v6.Name:match("^CashSeg%d+$") then
				v6:Destroy()

				continue
			end

			if (v6.Name == "Icon" or v6.Name == "Counter") and v6:IsA("GuiObject") then
				v6.Visible = false
			end
		end
	end

	v4.lastValue = p2
	v4.lastOpts = p3

	local v7 = getTemplateMaster()

	for v8, v9 in v12 do
		local v10 = v4.frames[v8]

		if not (v10 and v10.Parent) then
			local v11 = v7:Clone()

			v11.Name = ("CashSeg%*"):format(v8)
			v11.LayoutOrder = v8
			v11.Parent = p1
			v4.frames[v8] = v11
			v4.lastIcon[v8] = nil
			v4.lastText[v8] = nil

			if t3[p1] then
				v1(v11)
			end

			v10 = v11
		end

		v10.Visible = true

		if v4.lastIcon[v8] ~= v9.Icon then
			v4.lastIcon[v8] = v9.Icon

			local Icon = v10.Icon

			Icon.Image = v9.Icon
			Icon.Visible = v9.Icon ~= ""
			v10:SetAttribute("TierIndex", if v9.TierIndex >= 1 then v9.TierIndex else nil)
		end

		if v4.lastText[v8] ~= v9.Text then
			v4.lastText[v8] = v9.Text
			v10.Counter.Text = v9.Text
		end
	end

	for i = #v12 + 1, #v4.frames do
		if v4.frames[i].Parent then
			v4.frames[i].Visible = false
		end
	end
end

local t4 = {}

local function fontKey(p1) --[[ fontKey | Line: 198 ]]
	return ("%*|%*|%*"):format(p1.Family, p1.Weight.Value, p1.Style.Value)
end

local function estimateAspect(p1) --[[ estimateAspect | Line: 204 ]]
	return math.max(0.25, (utf8.len(p1) or #p1) * 0.62) * 1.06
end

local function measureAspect(p1, p2, p3, p4) --[[ measureAspect | Line: 209 | Upvalues: t4 (copy), TextService (copy) ]]
	local v1 = ("%*|%*|%*"):format(p2.Family, p2.Weight.Value, p2.Style.Value) .. "|" .. tostring(p3) .. "|" .. p1
	local v2 = t4[v1]

	if v2 then
		p4(v2)
	else
		task.spawn(function() --[[ Line: 216 | Upvalues: p1 (copy), p2 (copy), p3 (copy), TextService (ref), t4 (ref), v1 (copy), p4 (copy) ]]
			local GetTextBoundsParams = Instance.new("GetTextBoundsParams")

			GetTextBoundsParams.Text = p1
			GetTextBoundsParams.Font = p2
			GetTextBoundsParams.Size = 100
			GetTextBoundsParams.Width = 1000000
			GetTextBoundsParams.RichText = p3

			local ok, result = pcall(TextService.GetTextBoundsAsync, TextService, GetTextBoundsParams)

			if ok and (typeof(result) == "Vector2" and not (result.Y <= 0)) then
				local v12 = result.X / result.Y * 1.06

				t4[v1] = v12
				p4(v12)
			end
		end)
	end
end

local function applyRowAspect(p1) --[[ applyRowAspect | Line: 234 ]]
	local sum = 0

	for v1, v2 in p1.items do
		sum = sum + (v2.aspect or 1)
	end

	local v3 = math.max(sum, 0.01)

	p1.totalAspect = v3

	if p1.rowAspect.AspectRatio ~= v3 then
		p1.rowAspect.AspectRatio = v3
	end

	if not p1.updateCap then
		return
	end

	p1.updateCap()
end

local function setPartAspect(p1, p2) --[[ setPartAspect | Line: 249 ]]
	p1.aspect = p2

	local Aspect = p1.instance:FindFirstChild("Aspect")

	if not Aspect or Aspect.AspectRatio == p2 then
		return
	end

	Aspect.AspectRatio = p2
end

local function refreshBillboardAspect(p1, p2, p3) --[[ refreshBillboardAspect | Line: 259 | Upvalues: measureAspect (copy), applyRowAspect (copy) ]]
	local value = p2.value
	local v2 = math.max(0.25, (utf8.len(value) or #value) * 0.62) * 1.06

	p2.aspect = v2

	local Aspect = p2.instance:FindFirstChild("Aspect")

	if Aspect and Aspect.AspectRatio ~= v2 then
		Aspect.AspectRatio = v2
	end

	measureAspect(value, p3.FontFace, p3.RichText, function(p1) --[[ Line: 262 | Upvalues: p2 (copy), value (copy), applyRowAspect (ref), p1 (copy) ]]
		if p2.value ~= value or not p2.instance.Parent then
			return
		end

		local v12 = p2

		v12.aspect = p1

		local Aspect = v12.instance:FindFirstChild("Aspect")

		if Aspect and Aspect.AspectRatio ~= p1 then
			Aspect.AspectRatio = p1
		end

		applyRowAspect(p1)
	end)
end

local function alignmentFor(p1) --[[ alignmentFor | Line: 271 ]]
	if p1 == Enum.TextXAlignment.Left then
		return Enum.HorizontalAlignment.Left
	end

	if p1 == Enum.TextXAlignment.Right then
		return Enum.HorizontalAlignment.Right
	end

	return Enum.HorizontalAlignment.Center
end

local function syncTextStyle(p1, p2) --[[ syncTextStyle | Line: 284 ]]
	if not p2.TextScaled and p1.TextSize ~= p2.TextSize then
		p1.TextSize = p2.TextSize
	end

	if p1.ZIndex ~= p2.ZIndex then
		p1.ZIndex = p2.ZIndex
	end

	if p1.FontFace ~= p2.FontFace then
		p1.FontFace = p2.FontFace
	end

	if p1.TextColor3 ~= p2.TextColor3 then
		p1.TextColor3 = p2.TextColor3
	end

	if p1.TextTransparency ~= p2.TextTransparency then
		p1.TextTransparency = p2.TextTransparency
	end

	if p1.TextStrokeColor3 ~= p2.TextStrokeColor3 then
		p1.TextStrokeColor3 = p2.TextStrokeColor3
	end

	if p1.TextStrokeTransparency ~= p2.TextStrokeTransparency then
		p1.TextStrokeTransparency = p2.TextStrokeTransparency
	end

	if p1.RichText ~= p2.RichText then
		p1.RichText = p2.RichText
	end

	for v1, v2 in { "UIStroke", "UIGradient" } do
		local v3 = p2:FindFirstChildOfClass(v2)
		local v4 = p1:FindFirstChildOfClass(v2)

		if v3 then
			if v4 then
				if v4.Color ~= v3.Color then
					v4.Color = v3.Color
				end

				if v4.Transparency ~= v3.Transparency then
					v4.Transparency = v3.Transparency
				end

				if v2 == "UIStroke" and v4.Thickness ~= v3.Thickness then
					v4.Thickness = v3.Thickness
				end

				continue
			end

			v3:Clone().Parent = p1

			continue
		end

		if v4 then
			v4:Destroy()
		end
	end
end

local function makeTextPart(p1, p2) --[[ makeTextPart | Line: 334 | Upvalues: syncTextStyle (copy) ]]
	local CashText = Instance.new("TextLabel")

	CashText.Name = "CashText"
	CashText.BackgroundTransparency = 1
	CashText.AutoLocalize = false
	CashText.TextWrapped = false

	if p2 then
		CashText.Size = UDim2.fromScale(1, 1)
		CashText.TextScaled = true

		local Aspect = Instance.new("UIAspectRatioConstraint")

		Aspect.Name = "Aspect"
		Aspect.AspectType = Enum.AspectType.FitWithinMaxSize
		Aspect.AspectRatio = 1
		Aspect.Parent = CashText
	elseif p1.TextScaled then
		CashText.Size = UDim2.fromScale(0, 1)
		CashText.AutomaticSize = Enum.AutomaticSize.X
		CashText.TextScaled = true
	else
		CashText.Size = UDim2.fromScale(0, 1)
		CashText.AutomaticSize = Enum.AutomaticSize.X
		CashText.TextSize = p1.TextSize
	end

	syncTextStyle(CashText, p1)

	return CashText
end

local function makeIconPart(p1, p2) --[[ makeIconPart | Line: 368 ]]
	local CashIcon = Instance.new("ImageLabel")

	CashIcon.Name = "CashIcon"
	CashIcon.BackgroundTransparency = 1
	CashIcon.ScaleType = Enum.ScaleType.Fit
	CashIcon.ZIndex = p1.ZIndex

	if p2 or p1.TextScaled then
		CashIcon.Size = UDim2.fromScale(1, 1)

		local UIAspectRatioConstraint = Instance.new("UIAspectRatioConstraint")

		UIAspectRatioConstraint.AspectRatio = 1
		UIAspectRatioConstraint.AspectType = Enum.AspectType.FitWithinMaxSize
		UIAspectRatioConstraint.DominantAxis = Enum.DominantAxis.Height
		UIAspectRatioConstraint.Parent = CashIcon
	else
		local v3 = math.max(8, (math.round(p1.TextSize * 1.25)))

		CashIcon.Size = UDim2.fromOffset(v3, v3)
	end

	return CashIcon
end

local function ensureOverlay(p1) --[[ ensureOverlay | Line: 390 | Upvalues: t2 (copy), t3 (copy) ]]
	local v1 = t2[p1]

	if v1 and (v1.kind == "overlay" and v1.overlay.Parent == p1) then
		return v1
	end

	for v2, v3 in p1:GetChildren() do
		if v3.Name == "CashSegments" then
			v3:Destroy()
		end
	end

	local CashSegments = Instance.new("Frame")

	CashSegments.Name = "CashSegments"
	CashSegments.BackgroundTransparency = 1
	CashSegments.AutoLocalize = false
	CashSegments.ZIndex = p1.ZIndex

	local UIListLayout = Instance.new("UIListLayout")

	UIListLayout.FillDirection = Enum.FillDirection.Horizontal
	UIListLayout.VerticalAlignment = Enum.VerticalAlignment.Center

	local TextXAlignment = p1.TextXAlignment

	UIListLayout.HorizontalAlignment = if TextXAlignment == Enum.TextXAlignment.Left then Enum.HorizontalAlignment.Left elseif TextXAlignment == Enum.TextXAlignment.Right then Enum.HorizontalAlignment.Right else Enum.HorizontalAlignment.Center
	UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder
	UIListLayout.Padding = UDim.new(0, 2)
	UIListLayout.Parent = CashSegments

	if p1.TextScaled and (if p1.AutomaticSize == Enum.AutomaticSize.None then if p1:FindFirstAncestorWhichIsA("BillboardGui") == nil then false else true else false) then
		UIListLayout.Padding = UDim.new(0, 0)
		CashSegments.Size = UDim2.fromScale(1, 1)

		if p1.TextXAlignment == Enum.TextXAlignment.Right then
			CashSegments.AnchorPoint = Vector2.new(1, 0.5)
			CashSegments.Position = UDim2.fromScale(1, 0.5)
		elseif p1.TextXAlignment == Enum.TextXAlignment.Left then
			CashSegments.AnchorPoint = Vector2.new(0, 0.5)
			CashSegments.Position = UDim2.fromScale(0, 0.5)
		else
			CashSegments.AnchorPoint = Vector2.new(0.5, 0.5)
			CashSegments.Position = UDim2.fromScale(0.5, 0.5)
		end

		local RowAspect = Instance.new("UIAspectRatioConstraint")

		RowAspect.Name = "RowAspect"
		RowAspect.AspectType = Enum.AspectType.FitWithinMaxSize
		RowAspect.AspectRatio = 1
		RowAspect.Parent = CashSegments

		local CapScale = Instance.new("UIScale")

		CapScale.Name = "CapScale"
		CapScale.Parent = CashSegments
		CashSegments.Parent = p1

		local t = {
			kind = "overlay",
			billboard = true,
			totalAspect = 1,
			overlay = CashSegments,
			items = {},
			rowAspect = RowAspect
		}

		local function updateCap() --[[ updateCap | Line: 462 | Upvalues: p1 (copy), t (ref), CapScale (copy) ]]
			local AbsoluteSize = p1.AbsoluteSize

			if AbsoluteSize.X < 1 or AbsoluteSize.Y < 1 then
				return
			end

			local v3 = math.clamp(100 / math.min(AbsoluteSize.Y, AbsoluteSize.X / math.max(t.totalAspect, 0.01)), 0.05, 1)

			if not (math.abs(CapScale.Scale - v3) > 0.001) then
				return
			end

			CapScale.Scale = v3
		end

		t.updateCap = updateCap
		p1:GetPropertyChangedSignal("AbsoluteSize"):Connect(updateCap)

		local AbsoluteSize = p1.AbsoluteSize

		if not (AbsoluteSize.X < 1 or AbsoluteSize.Y < 1) then
			local v8 = math.clamp(100 / math.min(AbsoluteSize.Y, AbsoluteSize.X / math.max(t.totalAspect, 0.01)), 0.05, 1)

			if math.abs(CapScale.Scale - v8) > 0.001 then
				CapScale.Scale = v8
			end
		end

		t2[p1] = t

		return t
	end

	if p1.AutomaticSize == Enum.AutomaticSize.X or p1.AutomaticSize == Enum.AutomaticSize.XY then
		CashSegments.Size = UDim2.fromScale(0, 1)
		CashSegments.AutomaticSize = Enum.AutomaticSize.X
		CashSegments.Parent = p1

		local t = {
			kind = "overlay",
			overlay = CashSegments,
			items = {}
		}

		t2[p1] = t
		p1.Destroying:Once(function() --[[ Line: 74 | Upvalues: t2 (ref), p1 (copy), t3 (ref) ]]
			t2[p1] = nil
			t3[p1] = nil
		end)

		return t
	end

	CashSegments.Size = UDim2.fromScale(1, 1)

	if p1.TextXAlignment == Enum.TextXAlignment.Right then
		CashSegments.AnchorPoint = Vector2.new(1, 0.5)
		CashSegments.Position = UDim2.fromScale(1, 0.5)
	elseif p1.TextXAlignment == Enum.TextXAlignment.Left then
		CashSegments.AnchorPoint = Vector2.new(0, 0.5)
		CashSegments.Position = UDim2.fromScale(0, 0.5)
	else
		CashSegments.AnchorPoint = Vector2.new(0.5, 0.5)
		CashSegments.Position = UDim2.fromScale(0.5, 0.5)
	end

	local UIScale = Instance.new("UIScale")

	UIScale.Parent = CashSegments

	local v10 = nil
	local v11 = nil
	local v12 = false
	local v13 = (-1 / 0)

	local function applyTarget() --[[ applyTarget | Line: 528 | Upvalues: p1 (copy), v11 (ref), UIScale (copy) ]]
		local X = p1.AbsoluteSize.X

		if not (X < 1) and (v11 and not (v11 < 1)) then
			UIScale.Scale = math.clamp(X / v11, 0.05, 1)
		end
	end

	local function updateFitNow() --[[ updateFitNow | Line: 542 | Upvalues: CashSegments (copy), v10 (ref), UIListLayout (copy), v12 (ref), v11 (ref), p1 (copy), UIScale (copy), v13 (ref) ]]
		if CashSegments.Parent then
			local X = UIListLayout.AbsoluteContentSize.X

			if v12 then
				v12 = false
				v11 = X

				local X2 = p1.AbsoluteSize.X

				if X2 < 1 or not X then
					return
				end

				if X < 1 then
					return
				end

				UIScale.Scale = math.clamp(X2 / X, 0.05, 1)
			else
				if v11 and math.abs(X - v11 * UIScale.Scale) <= 2 + v11 * 0.02 then
					local X2 = p1.AbsoluteSize.X

					if X2 < 1 or not v11 then
						return
					end

					if v11 < 1 then
						return
					end

					UIScale.Scale = math.clamp(X2 / v11, 0.05, 1)

					return
				end

				if os.clock() - v13 < 0.25 then
					local X2 = p1.AbsoluteSize.X

					if X2 < 1 or not v11 then
						return
					end

					if v11 < 1 then
						return
					end

					UIScale.Scale = math.clamp(X2 / v11, 0.05, 1)
				else
					v13 = os.clock()

					if UIScale.Scale ~= 1 then
						v12 = true
						UIScale.Scale = 1

						return
					end

					v11 = X

					local X2 = p1.AbsoluteSize.X

					if X2 < 1 or not X then
						return
					end

					if X < 1 then
						return
					end

					UIScale.Scale = math.clamp(X2 / X, 0.05, 1)
				end
			end
		else
			if not v10 then
				return
			end

			v10:Disconnect()
			v10 = nil
		end
	end

	local v14 = false

	local function updateFit() --[[ updateFit | Line: 587 | Upvalues: v14 (ref), updateFitNow (copy) ]]
		if not v14 then
			v14 = true
			task.defer(function() --[[ Line: 592 | Upvalues: v14 (ref), updateFitNow (ref) ]]
				v14 = false
				updateFitNow()
			end)
		end
	end

	UIListLayout:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(updateFit)
	v10 = p1:GetPropertyChangedSignal("AbsoluteSize"):Connect(updateFit)

	local v15

	if v14 then
		CashSegments.Parent = p1
		v15 = {
			kind = "overlay",
			overlay = CashSegments,
			items = {},
			updateFit = updateFit
		}
		t2[p1] = v15
		p1.Destroying:Once(function() --[[ Line: 74 | Upvalues: t2 (ref), p1 (copy), t3 (ref) ]]
			t2[p1] = nil
			t3[p1] = nil
		end)

		return v15
	end

	v14 = true
	task.defer(function() --[[ Line: 592 | Upvalues: v14 (ref), updateFitNow (copy) ]]
		v14 = false
		updateFitNow()
	end)
	CashSegments.Parent = p1
	v15 = {
		kind = "overlay",
		overlay = CashSegments,
		items = {},
		updateFit = updateFit
	}
	t2[p1] = v15
	p1.Destroying:Once(function() --[[ Line: 74 | Upvalues: t2 (ref), p1 (copy), t3 (ref) ]]
		t2[p1] = nil
		t3[p1] = nil
	end)

	return v15
end

function t.applyParts(p1, p2, p3) --[[ applyParts | Line: 615 | Upvalues: ensureOverlay (copy), CashFormat (copy), makeIconPart (copy), makeTextPart (copy), syncTextStyle (copy), measureAspect (copy), applyRowAspect (copy) ]]
	local v1 = ensureOverlay(p1)

	if p1.Text ~= "" then
		p1.Text = ""
	end

	v1.overlay.Visible = true
	v1.lastParts = p2
	v1.lastOpts = p3

	local t = {}

	for v3, v4 in p2 do
		local v2

		if type(v4) == "string" then
			if v4 ~= "" then
				table.insert(t, {
					kind = "text",
					value = v4
				})
			end

			continue
		end

		if type(v4) == "table" then
			v2 = if CashFormat.iconsEnabled() or not (p3 and p3.SuffixIcon) then if v4.Compact or p3 and p3.Compact then { CashFormat.compact(v4.Value) } else CashFormat.segments(v4.Value, v4.MaxSegments or p3 and p3.MaxSegments) else { CashFormat.suffixSegment(v4.Value, true) }

			local v8 = v4.Color or (if p3 then p3.AmountColor else p3)

			for v9, v10 in v2 do
				if v10.Icon ~= "" then
					table.insert(t, {
						kind = "icon",
						value = v10.Icon
					})
				end

				table.insert(t, {
					kind = "text",
					value = v10.Text,
					color = v8
				})
			end
		end
	end

	local items = v1.items
	local v11 = if #items == #t then true else false

	if v11 then
		for v12, v13 in t do
			if items[v12].kind ~= v13.kind then
				v11 = false

				break
			end
		end
	end

	if not v11 then
		for v14, v15 in items do
			v15.instance:Destroy()
		end

		items = {}
		v1.items = items

		for v16, v17 in t do
			local v18 = if v17.kind == "icon" then makeIconPart(p1, v1.billboard) else makeTextPart(p1, v1.billboard)

			v18.LayoutOrder = v16
			v18.Parent = v1.overlay

			local t2 = {
				value = nil,
				kind = v17.kind,
				instance = v18
			}

			t2.aspect = if v17.kind == "icon" then 1 else nil
			items[v16] = t2
		end
	end

	for v20, v21 in t do
		local v22 = items[v20]

		if v22.kind == "text" then
			syncTextStyle(v22.instance, p1)

			if v21.color and v22.instance.TextColor3 ~= v21.color then
				v22.instance.TextColor3 = v21.color
			end

			if v22.value ~= v21.value then
				v22.value = v21.value
				v22.instance.Text = v21.value

				if v1.billboard then
					local value = v22.value
					local v24 = math.max(0.25, (utf8.len(value) or #value) * 0.62) * 1.06

					v22.aspect = v24

					local Aspect = v22.instance:FindFirstChild("Aspect")

					if Aspect and Aspect.AspectRatio ~= v24 then
						Aspect.AspectRatio = v24
					end

					measureAspect(value, p1.FontFace, p1.RichText, function(p1) --[[ Line: 262 | Upvalues: v22 (copy), value (copy), applyRowAspect (ref), v1 (copy) ]]
						if v22.value ~= value or not v22.instance.Parent then
							return
						end

						local v12 = v22

						v12.aspect = p1

						local Aspect = v12.instance:FindFirstChild("Aspect")

						if Aspect and Aspect.AspectRatio ~= p1 then
							Aspect.AspectRatio = p1
						end

						applyRowAspect(v1)
					end)
				end
			end

			continue
		end

		if v22.instance.ZIndex ~= p1.ZIndex then
			v22.instance.ZIndex = p1.ZIndex
		end

		if v22.value ~= v21.value then
			v22.value = v21.value
			v22.instance.Image = v21.value
		end
	end

	if v1.billboard then
		applyRowAspect(v1)
	end

	if not v1.updateFit then
		return
	end

	task.defer(v1.updateFit)
end
function t.applyToLabel(p1, p2, p3) --[[ applyToLabel | Line: 721 | Upvalues: t (copy) ]]
	local t2 = {}

	if p3 and p3.Prefix then
		table.insert(t2, p3.Prefix)
	end

	table.insert(t2, {
		Value = tonumber(p2) or 0
	})

	if p3 and p3.Suffix then
		table.insert(t2, p3.Suffix)
	end

	t.applyParts(p1, t2, p3)
end
function t.applyTokens(p1, p2, p3) --[[ applyTokens | Line: 733 | Upvalues: CashFormat (copy), t (copy) ]]
	if CashFormat.hasToken(p2) then
		t.applyParts(p1, CashFormat.splitTokens(p2), p3)
	else
		t.setPlainText(p1, p2)
	end
end
function t.setPlainText(p1, p2) --[[ setPlainText | Line: 741 | Upvalues: t2 (copy) ]]
	local v1 = t2[p1]

	if v1 and (v1.kind == "overlay" and v1.overlay.Parent) then
		v1.overlay.Visible = false
		v1.lastParts = nil
	end

	p1.Text = p2
end
function t.setIconsEnabled(p1) --[[ setIconsEnabled | Line: 754 | Upvalues: CashFormat (copy), t2 (copy), t3 (copy), t (copy) ]]
	if CashFormat.iconsEnabled() == p1 then
		return
	end

	CashFormat.setIconsEnabled(p1)

	local t4 = {}

	for v1 in t2 do
		table.insert(t4, v1)
	end

	for v2, v3 in t4 do
		local v4 = t2[v3]

		if v4 then
			if v3:IsDescendantOf(game) then
				if v4.kind == "render" then
					t.render(v3, v4.lastValue, v4.lastOpts)

					continue
				end

				if v4.kind == "overlay" and v4.lastParts then
					t.applyParts(v3, v4.lastParts, v4.lastOpts)
				end

				continue
			end

			t2[v3] = nil
			t3[v3] = nil
		end
	end
end

local t5 = {
	RowHeight = 84,
	IconSize = 60,
	TextSize = 52,
	BackgroundTransparency = 0.35,
	AutoHideSeconds = 4,
	Background = Color3.fromRGB(33, 33, 33),
	StrokeColor = Color3.fromRGB(0, 0, 0),
	TextColor = Color3.fromRGB(255, 255, 255)
}
local v3 = nil
local v4 = 0

local function projectFont() --[[ projectFont | Line: 813 | Upvalues: getTemplateMaster (copy) ]]
	local ok, result = pcall(function() --[[ Line: 814 | Upvalues: getTemplateMaster (ref) ]]
		return getTemplateMaster().Counter.FontFace
	end)

	if ok and typeof(result) == "Font" then
		return result
	end

	return Font.fromEnum(Enum.Font.GothamBold)
end

local function buildTooltip() --[[ buildTooltip | Line: 823 | Upvalues: v3 (ref), Players (copy), t5 (copy), getTemplateMaster (copy) ]]
	if v3 and v3.frame.Parent then
		return v3
	end

	local PlayerGui = Players.LocalPlayer:WaitForChild("PlayerGui")
	local CashTierTooltip = Instance.new("ScreenGui")

	CashTierTooltip.Name = "CashTierTooltip"
	CashTierTooltip.ResetOnSpawn = false
	CashTierTooltip.DisplayOrder = 50
	CashTierTooltip.IgnoreGuiInset = false

	local Tooltip = Instance.new("Frame")

	Tooltip.Name = "Tooltip"
	Tooltip.BackgroundColor3 = t5.Background
	Tooltip.BackgroundTransparency = t5.BackgroundTransparency
	Tooltip.BorderSizePixel = 0
	Tooltip.Size = UDim2.fromOffset(0, t5.RowHeight)
	Tooltip.AutomaticSize = Enum.AutomaticSize.X
	Tooltip.Visible = false
	Tooltip.AutoLocalize = false

	local UIStroke = Instance.new("UIStroke")

	UIStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual
	UIStroke.Color = t5.StrokeColor
	UIStroke.LineJoinMode = Enum.LineJoinMode.Round
	UIStroke.Transparency = 0

	if not pcall(function() --[[ Line: 853 | Upvalues: UIStroke (copy) ]]
		UIStroke.StrokeSizingMode = Enum.StrokeSizingMode.ScaledSize
		UIStroke.Thickness = 0.07
	end) then
		UIStroke.Thickness = 3
	end

	UIStroke.Parent = Tooltip

	local ScreenScale = Instance.new("UIScale")

	ScreenScale.Name = "ScreenScale"
	ScreenScale.Parent = Tooltip

	local UIPadding = Instance.new("UIPadding")

	UIPadding.PaddingTop = UDim.new(0, 12)
	UIPadding.PaddingBottom = UDim.new(0, 12)
	UIPadding.PaddingLeft = UDim.new(0, 20)
	UIPadding.PaddingRight = UDim.new(0, 20)
	UIPadding.Parent = Tooltip

	local UIListLayout = Instance.new("UIListLayout")

	UIListLayout.FillDirection = Enum.FillDirection.Horizontal
	UIListLayout.VerticalAlignment = Enum.VerticalAlignment.Center
	UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder
	UIListLayout.Padding = UDim.new(0, 10)
	UIListLayout.Parent = Tooltip

	local ok, result = pcall(function() --[[ Line: 814 | Upvalues: getTemplateMaster (ref) ]]
		return getTemplateMaster().Counter.FontFace
	end)
	local v1 = if ok and typeof(result) == "Font" then result else Font.fromEnum(Enum.Font.GothamBold)

	local function addText(p1) --[[ addText | Line: 884 | Upvalues: v1 (copy), t5 (ref), Tooltip (copy) ]]
		local TextLabel = Instance.new("TextLabel")

		TextLabel.BackgroundTransparency = 1
		TextLabel.Size = UDim2.fromScale(0, 1)
		TextLabel.AutomaticSize = Enum.AutomaticSize.X
		TextLabel.FontFace = v1
		TextLabel.TextSize = t5.TextSize
		TextLabel.TextColor3 = t5.TextColor
		TextLabel.AutoLocalize = false
		TextLabel.LayoutOrder = p1

		local UIStroke = Instance.new("UIStroke")

		UIStroke.Color = t5.StrokeColor
		UIStroke.Thickness = 2
		UIStroke.Parent = TextLabel
		TextLabel.Parent = Tooltip

		return TextLabel
	end

	local function addIcon(p1) --[[ addIcon | Line: 902 | Upvalues: t5 (ref), Tooltip (copy) ]]
		local ImageLabel = Instance.new("ImageLabel")

		ImageLabel.BackgroundTransparency = 1
		ImageLabel.Size = UDim2.fromOffset(t5.IconSize, t5.IconSize)
		ImageLabel.ScaleType = Enum.ScaleType.Fit
		ImageLabel.LayoutOrder = p1
		ImageLabel.Parent = Tooltip

		return ImageLabel
	end

	local t = {
		frame = Tooltip,
		leftValue = addText(1)
	}
	local ImageLabel = Instance.new("ImageLabel")

	ImageLabel.BackgroundTransparency = 1
	ImageLabel.Size = UDim2.fromOffset(t5.IconSize, t5.IconSize)
	ImageLabel.ScaleType = Enum.ScaleType.Fit
	ImageLabel.LayoutOrder = 2
	ImageLabel.Parent = Tooltip
	t.leftIcon = ImageLabel
	t.equals = addText(3)

	local ImageLabel2 = Instance.new("ImageLabel")

	ImageLabel2.BackgroundTransparency = 1
	ImageLabel2.Size = UDim2.fromOffset(t5.IconSize, t5.IconSize)
	ImageLabel2.ScaleType = Enum.ScaleType.Fit
	ImageLabel2.LayoutOrder = 4
	ImageLabel2.Parent = Tooltip
	t.rightIcon = ImageLabel2
	Tooltip.Parent = CashTierTooltip
	CashTierTooltip.Parent = PlayerGui
	v3 = t

	return t
end

local function showTierTooltip(p1, p2) --[[ showTierTooltip | Line: 926 | Upvalues: CashTierConfig (copy), buildTooltip (copy), v4 (ref), ConvertValue (copy), t5 (copy) ]]
	local v1 = CashTierConfig.Tiers[p2]

	if not v1 then
		return
	end

	local v2 = buildTooltip()

	v4 = v4 + 1
	v2.leftValue.Text = "1"
	v2.leftIcon.Image = v1.Icon

	if p2 <= 1 then
		v2.equals.Text = "= 1"
		v2.rightIcon.Visible = false
	else
		local v3 = CashTierConfig.Tiers[p2 - 1]

		v2.equals.Text = ("= %*"):format((ConvertValue.suffixformat(v1.Threshold / v3.Threshold)))
		v2.rightIcon.Image = v3.Icon
		v2.rightIcon.Visible = true
	end

	v2.frame.Visible = true

	local function place() --[[ place | Line: 951 | Upvalues: v2 (copy), p1 (copy), t5 (ref) ]]
		local CurrentCamera = workspace.CurrentCamera
		local v1 = workspace.CurrentCamera and CurrentCamera.ViewportSize or Vector2.new(1920, 1080)
		local ScreenScale = v2.frame:FindFirstChild("ScreenScale")
		local v22, v3, v4, v5, v6, v7, v8

		if not (ScreenScale and p1.AbsoluteSize.Y > 0) then
			v22 = v2.frame.AbsoluteSize.X
			v3 = p1.AbsolutePosition.X + p1.AbsoluteSize.X / 2 - v22 / 2
			v4 = v1.X - v22 - 4
			v5 = math.max(4, v4)
			v6 = math.clamp(v3, 4, v5)
			v7 = p1.AbsolutePosition.Y - v2.frame.AbsoluteSize.Y - 6
			v8 = math.max(4, v7)
			v2.frame.Position = UDim2.fromOffset(v6, v8)

			return
		end

		ScreenScale.Scale = math.clamp(p1.AbsoluteSize.Y * 0.8 / t5.RowHeight, 0.4, 3)
		v22 = v2.frame.AbsoluteSize.X
		v3 = p1.AbsolutePosition.X + p1.AbsoluteSize.X / 2 - v22 / 2
		v4 = v1.X - v22 - 4
		v5 = math.max(4, v4)
		v6 = math.clamp(v3, 4, v5)
		v7 = p1.AbsolutePosition.Y - v2.frame.AbsoluteSize.Y - 6
		v8 = math.max(4, v7)
		v2.frame.Position = UDim2.fromOffset(v6, v8)
	end

	place()

	local v42 = v4

	task.defer(function() --[[ Line: 970 | Upvalues: v42 (copy), v4 (ref), v2 (copy), place (copy) ]]
		if v42 ~= v4 or not v2.frame.Visible then
			return
		end

		place()
	end)
end

local function hideTierTooltip() --[[ hideTierTooltip | Line: 977 | Upvalues: v4 (ref), v3 (ref) ]]
	v4 = v4 + 1

	if not (v3 and v3.frame.Parent) then
		return
	end

	v3.frame.Visible = false
end

v1 = function(p1) --[[ Line: 985 | Upvalues: showTierTooltip (copy), hideTierTooltip (copy), v3 (ref), v4 (ref), t5 (copy) ]]
	p1.MouseEnter:Connect(function() --[[ Line: 986 | Upvalues: p1 (copy), showTierTooltip (ref) ]]
		local v1 = p1:GetAttribute("TierIndex")

		if typeof(v1) ~= "number" then
			return
		end

		showTierTooltip(p1, v1)
	end)
	p1.MouseLeave:Connect(hideTierTooltip)
	p1.InputBegan:Connect(function(p12) --[[ Line: 993 | Upvalues: v3 (ref), v4 (ref), p1 (copy), showTierTooltip (ref), t5 (ref) ]]
		if p12.UserInputType ~= Enum.UserInputType.Touch then
			return
		end

		if v3 and v3.frame.Visible then
			v4 = v4 + 1

			if v3 and v3.frame.Parent then
				v3.frame.Visible = false
			end
		else
			local v1 = p1:GetAttribute("TierIndex")

			if typeof(v1) ~= "number" then
				return
			end

			showTierTooltip(p1, v1)

			local v2 = v4

			task.delay(t5.AutoHideSeconds, function() --[[ Line: 1007 | Upvalues: v2 (copy), v4 (ref), v3 (ref) ]]
				if v2 ~= v4 then
					return
				end

				v4 = v4 + 1

				if not (v3 and v3.frame.Parent) then
					return
				end

				v3.frame.Visible = false
			end)
		end
	end)
end
function t.attachTierTooltip(p1) --[[ attachTierTooltip | Line: 1016 | Upvalues: RunService (copy), t3 (copy), t2 (copy) ]]
	assert(RunService:IsClient(), "attachTierTooltip is client-only")
	t3[p1] = true
	p1.Destroying:Once(function() --[[ Line: 74 | Upvalues: t2 (ref), p1 (copy), t3 (ref) ]]
		t2[p1] = nil
		t3[p1] = nil
	end)
end

return t