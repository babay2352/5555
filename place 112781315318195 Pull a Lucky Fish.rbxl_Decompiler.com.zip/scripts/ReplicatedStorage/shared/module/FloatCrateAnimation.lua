-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ContentProvider = game:GetService("ContentProvider")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local FloatLootboxConfig = require(ReplicatedStorage.shared.config.FloatLootboxConfig)
local createAnimationInstance = require(ReplicatedStorage.shared.util.createAnimationInstance)
local t = {}
local v1 = setmetatable({}, {
	__mode = "k"
})
local v2 = setmetatable({}, {
	__mode = "k"
})
local v3 = false
local v4 = false
local t2 = {}

local function entryFor(p1) --[[ entryFor | Line: 63 | Upvalues: FloatLootboxConfig (copy) ]]
	if type(p1) == "string" then
		return FloatLootboxConfig.Lootboxes[p1]
	end

	return nil
end

function t.getAnimationId(p1) --[[ getAnimationId | Line: 71 | Upvalues: FloatLootboxConfig (copy) ]]
	local v1 = if type(p1) == "string" then FloatLootboxConfig.Lootboxes[p1] else nil

	return if v1 then v1.OpenAnimationId else v1
end

local function idlePauseFor(p1) --[[ idlePauseFor | Line: 76 | Upvalues: FloatLootboxConfig (copy) ]]
	local v1 = if type(p1) == "string" then FloatLootboxConfig.Lootboxes[p1] else nil

	return if v1 then v1.IdlePauseTime or 0.1 else 0.1
end

local function waitFor(p1) --[[ waitFor | Line: 81 ]]
	local sum = 0

	while sum < 3 do
		local v1 = p1()

		if v1 then
			return v1
		end

		task.wait(0.05)
		sum = sum + 0.05
	end

	return p1()
end

local function loadTrack(p1, p2, p3) --[[ loadTrack | Line: 94 | Upvalues: waitFor (copy), t2 (copy), createAnimationInstance (copy) ]]
	local v1 = waitFor(function() --[[ Line: 95 | Upvalues: p1 (copy) ]]
		return p1:FindFirstChildWhichIsA("AnimationController", true)
	end)

	if v1 then
		return (v1:FindFirstChildWhichIsA("Animator") or v1):LoadAnimation(createAnimationInstance(p3))
	end

	local v2 = p2 or "?"

	if t2[v2] then
		return nil
	end

	t2[v2] = true
	warn(("[FloatCrateAnimation] \"%*\" declares OpenAnimationId but its rig has no "):format(v2) .. "AnimationController \226\128\148 nothing to pose. Add one to the template under shared.model.FloatLootboxes.")

	return nil
end

function t.pose(p1, p2) --[[ pose | Line: 118 | Upvalues: v1 (copy), v2 (copy), t (copy), loadTrack (copy), waitFor (copy), FloatLootboxConfig (copy) ]]
	local v12 = v1[p1]

	if v12 then
		return v12.track
	end

	if v2[p1] then
		return nil
	end

	local v22 = t.getAnimationId(p2)

	if not v22 then
		return nil
	end

	v2[p1] = true

	local v3 = loadTrack(p1, p2, v22)

	v2[p1] = nil

	if v3 then
		v3.Looped = false
		v3:Play(0)
		v3:AdjustSpeed(0)

		local t2 = {
			resumed = false,
			track = v3
		}

		v1[p1] = t2
		task.spawn(function() --[[ Line: 149 | Upvalues: waitFor (ref), v3 (copy), t2 (copy), v1 (ref), p1 (copy), p2 (copy), FloatLootboxConfig (ref) ]]
			local v12 = waitFor(function() --[[ Line: 150 | Upvalues: v3 (ref) ]]
				if v3.Length > 0 then
					return v3.Length
				end

				return nil
			end)

			if not v12 or (t2.resumed or v1[p1] ~= t2) then
				return
			end

			local v2 = v3
			local v32 = p2
			local v4 = if type(v32) == "string" then FloatLootboxConfig.Lootboxes[v32] else nil

			v2.TimePosition = math.clamp(v4 and v4.IdlePauseTime or 0.1, 0, v12)
		end)

		return v3
	end

	return nil
end
function t.resume(p1, p2) --[[ resume | Line: 164 | Upvalues: v2 (copy), waitFor (copy), v1 (copy), t (copy), loadTrack (copy), FloatLootboxConfig (copy) ]]
	if v2[p1] then
		waitFor(function() --[[ Line: 166 | Upvalues: v1 (ref), p1 (copy) ]]
			return v1[p1]
		end)
	end

	local v12 = v1[p1]

	if not v12 then
		local v22 = t.getAnimationId(p2)

		if not v22 then
			return nil
		end

		local v3 = loadTrack(p1, p2, v22)

		if not v3 then
			return nil
		end

		v3.Looped = false
		v3:Play(0)

		local v4 = if type(p2) == "string" then FloatLootboxConfig.Lootboxes[p2] else nil

		v3.TimePosition = v4 and v4.IdlePauseTime or 0.1

		local t2 = {
			resumed = true,
			track = v3
		}

		v1[p1] = t2
		v12 = t2
	end

	v12.resumed = true
	v12.track:AdjustSpeed(1)

	return v12.track
end

local function poseFromAttribute(p1, p2) --[[ poseFromAttribute | Line: 199 | Upvalues: waitFor (copy), t (copy) ]]
	task.spawn(function() --[[ Line: 200 | Upvalues: waitFor (ref), p1 (copy), p2 (copy), t (ref) ]]
		local v12 = waitFor(function() --[[ Line: 201 | Upvalues: p1 (ref), p2 (ref) ]]
			return p1:GetAttribute(p2)
		end)

		if type(v12) ~= "string" then
			return
		end

		t.pose(p1, v12)
	end)
end

function t.watchPlacedCrates() --[[ watchPlacedCrates | Line: 212 | Upvalues: v3 (ref), waitFor (copy), t (copy) ]]
	if v3 then
		return
	end

	v3 = true

	local function consider(p1) --[[ consider | Line: 218 | Upvalues: waitFor (ref), t (ref) ]]
		if not p1:IsA("Model") then
			return
		end

		if string.sub(p1.Name, 1, 14) == "PlacedLootbox_" then
			local v2 = "ConfigName"

			task.spawn(function() --[[ Line: 200 | Upvalues: waitFor (ref), p1 (copy), v2 (copy), t (ref) ]]
				local v12 = waitFor(function() --[[ Line: 201 | Upvalues: p1 (ref), v2 (ref) ]]
					return p1:GetAttribute(p2)
				end)

				if type(v12) ~= "string" then
					return
				end

				t.pose(p1, v12)
			end)
		end
	end

	workspace.ChildAdded:Connect(consider)

	for v1, v2 in workspace:GetChildren() do
		if v2:IsA("Model") and string.sub(v2.Name, 1, 14) == "PlacedLootbox_" then
			local v4 = "ConfigName"

			task.spawn(function() --[[ Line: 200 | Upvalues: waitFor (ref), v2 (copy), v4 (copy), t (ref) ]]
				local v12 = waitFor(function() --[[ Line: 201 | Upvalues: v2 (ref), v4 (ref) ]]
					return p1:GetAttribute(p2)
				end)

				if type(v12) ~= "string" then
					return
				end

				t.pose(v2, v12)
			end)
		end
	end
end
function t.watchCrateTools() --[[ watchCrateTools | Line: 236 | Upvalues: v4 (ref), waitFor (copy), t (copy), Players (copy) ]]
	if v4 then
		return
	end

	v4 = true

	local function consider(p1) --[[ consider | Line: 242 | Upvalues: waitFor (ref), t (ref) ]]
		if not p1:IsA("Tool") then
			return
		end

		if p1.Name ~= "FloatLootbox" and not p1:GetAttribute("IsFloatLootbox") then
			return
		end

		local v1 = "LootboxConfigName"

		task.spawn(function() --[[ Line: 200 | Upvalues: waitFor (ref), p1 (copy), v1 (copy), t (ref) ]]
			local v12 = waitFor(function() --[[ Line: 201 | Upvalues: p1 (ref), v1 (ref) ]]
				return p1:GetAttribute(p2)
			end)

			if type(v12) ~= "string" then
				return
			end

			t.pose(p1, v12)
		end)
	end

	local function watchCharacter(p1) --[[ watchCharacter | Line: 252 | Upvalues: consider (copy), waitFor (ref), t (ref) ]]
		p1.ChildAdded:Connect(consider)

		for v1, v2 in p1:GetChildren() do
			if v2:IsA("Tool") and (v2.Name == "FloatLootbox" or v2:GetAttribute("IsFloatLootbox")) then
				local v3 = "LootboxConfigName"

				task.spawn(function() --[[ Line: 200 | Upvalues: waitFor (ref), v2 (copy), v3 (copy), t (ref) ]]
					local v12 = waitFor(function() --[[ Line: 201 | Upvalues: v2 (ref), v3 (ref) ]]
						return p1:GetAttribute(p2)
					end)

					if type(v12) ~= "string" then
						return
					end

					t.pose(v2, v12)
				end)
			end
		end
	end

	local function watchPlayer(p1) --[[ watchPlayer | Line: 259 | Upvalues: watchCharacter (copy), consider (copy), waitFor (ref), t (ref) ]]
		p1.CharacterAdded:Connect(watchCharacter)

		if not p1.Character then
			return
		end

		local Character = p1.Character

		Character.ChildAdded:Connect(consider)

		for v1, v2 in Character:GetChildren() do
			if v2:IsA("Tool") and (v2.Name == "FloatLootbox" or v2:GetAttribute("IsFloatLootbox")) then
				local v3 = "LootboxConfigName"

				task.spawn(function() --[[ Line: 200 | Upvalues: waitFor (ref), v2 (copy), v3 (copy), t (ref) ]]
					local v12 = waitFor(function() --[[ Line: 201 | Upvalues: v2 (ref), v3 (ref) ]]
						return p1:GetAttribute(p2)
					end)

					if type(v12) ~= "string" then
						return
					end

					t.pose(v2, v12)
				end)
			end
		end
	end

	Players.PlayerAdded:Connect(watchPlayer)

	for v1, v2 in Players:GetPlayers() do
		v2.CharacterAdded:Connect(watchCharacter)

		if v2.Character then
			local Character = v2.Character

			Character.ChildAdded:Connect(consider)

			for v3, v42 in Character:GetChildren() do
				if v42:IsA("Tool") and (v42.Name == "FloatLootbox" or v42:GetAttribute("IsFloatLootbox")) then
					local v5 = "LootboxConfigName"

					task.spawn(function() --[[ Line: 200 | Upvalues: waitFor (ref), v42 (copy), v5 (copy), t (ref) ]]
						local v12 = waitFor(function() --[[ Line: 201 | Upvalues: v42 (ref), v5 (ref) ]]
							return p1:GetAttribute(p2)
						end)

						if type(v12) ~= "string" then
							return
						end

						t.pose(v42, v12)
					end)
				end
			end
		end
	end
end
task.spawn(function() --[[ Line: 272 | Upvalues: FloatLootboxConfig (copy), createAnimationInstance (copy), ContentProvider (copy) ]]
	local t = {}

	for v1, v2 in FloatLootboxConfig.Lootboxes do
		if v2.OpenAnimationId then
			table.insert(t, createAnimationInstance(v2.OpenAnimationId))
		end
	end

	if not (#t > 0) then
		return
	end

	ContentProvider:PreloadAsync(t)

	for v4, v5 in t do
		v5:Destroy()
	end
end)

return t