-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local CashDisplay = require(ReplicatedStorage.shared.module.CashDisplay)
local FishEarnings = require(ReplicatedStorage.shared.util.FishEarnings)
local Maid = require(ReplicatedStorage.shared.class.Maid)
local luckyblockDropOdds = require(ReplicatedStorage.shared.util.luckyblockDropOdds)

local function formatOneInN(p1) --[[ formatOneInN | Line: 65 ]]
	local format = string.format

	return format("1/%d", (math.max(1, (math.round(p1)))))
end

local function v1(p1, p2) --[[ findDescendantNamed | Line: 69 | Upvalues: v1 (copy) ]]
	if p1.Name == p2 then
		return p1
	end

	for v12, v2 in p1:GetChildren() do
		local v3 = v1(v2, p2)

		if v3 then
			return v3
		end
	end

	return nil
end

local function ensureItemNameLabel(p1) --[[ ensureItemNameLabel | Line: 87 | Upvalues: v1 (copy) ]]
	if v1(p1, "ItemName") then
		return
	end

	local DisplayName = p1:FindFirstChild("DisplayName", true)

	if DisplayName and DisplayName:IsA("TextLabel") then
		local ItemName = DisplayName:Clone()

		ItemName.Name = "ItemName"
		ItemName.Position = UDim2.fromScale(0.041782, 0.733258)
		ItemName.Size = UDim2.fromScale(0.958218, 0.380351)
		ItemName.ZIndex = 6
		ItemName.TextXAlignment = Enum.TextXAlignment.Center
		ItemName.Text = ""
		ItemName.Parent = DisplayName.Parent
	end
end

local function setLabels(p1, p2, p3) --[[ setLabels | Line: 106 ]]
	for v1, v2 in p1:GetDescendants() do
		if v2.Name == p2 and v2:IsA("TextLabel") then
			v2.Text = p3
		end
	end
end

local function buildReelPool(p1) --[[ buildReelPool | Line: 120 | Upvalues: luckyblockDropOdds (copy) ]]
	local t = {}

	for v1, v2 in luckyblockDropOdds(p1) do
		local t2 = {
			name = v2.name,
			chance = v2.chance,
			image = v2.image
		}

		t2.itemLabel = if v2.isMount then v2.displayName else nil
		table.insert(t, t2)
	end

	return t
end

local function applyReelDrop(p1, p2) --[[ applyReelDrop | Line: 142 | Upvalues: setLabels (copy), FishEarnings (copy), Players (copy), CashDisplay (copy), formatOneInN (copy) ]]
	local Icon = p1:FindFirstChild("Icon")

	if Icon and Icon:IsA("ImageLabel") then
		Icon.Image = p2.image
	end

	if p2.itemLabel then
		setLabels(p1, "ItemName", p2.itemLabel)
	else
		local v1 = FishEarnings.perFish(Players.LocalPlayer, p2.name, false, 1, nil)

		for v2, v3 in p1:GetDescendants() do
			if v3.Name == "ItemName" and v3:IsA("TextLabel") then
				CashDisplay.applyToLabel(v3, v1, {
					Suffix = "/s",
					Compact = true
				})
			end
		end
	end

	setLabels(p1, "DisplayName", formatOneInN(100 / p2.chance))
end

local function startWithPool(p1, p2, p3) --[[ startWithPool | Line: 166 | Upvalues: v1 (copy), ensureItemNameLabel (copy), Maid (copy), applyReelDrop (copy), TweenService (copy) ]]
	local v12 = v1(p1, p2)
	local v2 = if v12 then v1(v12, "FishList") else v12

	if not v2 or #p3 == 0 then
		return nil
	end

	local v3 = nil
	local v4 = nil

	for v5, v6 in v2:GetChildren() do
		if v6:IsA("ImageLabel") then
			if not v3 then
				local v7 = v6:Clone()
				local AbsoluteSize = v2.AbsoluteSize
				local AbsoluteSize2 = v6.AbsoluteSize

				if AbsoluteSize.X > 0 and (AbsoluteSize.Y > 0 and (AbsoluteSize2.X > 0 and AbsoluteSize2.Y > 0)) then
					v3, v4 = v7, UDim2.fromScale(AbsoluteSize2.X / AbsoluteSize.X, AbsoluteSize2.Y / AbsoluteSize.Y)
				else
					v3 = v7
				end
			end

			v6.Visible = false
		end
	end

	if not v3 then
		return nil
	end

	local v9 = v3

	v9.Visible = true
	ensureItemNameLabel(v9)

	local v10 = if v4 then v4 else v9.Size
	local v122 = math.min(1.2, 1 / math.max(v10.Y.Scale, 0.001))
	local v13 = UDim2.fromScale(v10.X.Scale * v122, v10.Y.Scale * v122)
	local v14 = 1 / v122
	local v15 = math.min(0.05, (1 - v14) / 2 * 0.9)
	local v16 = v13.X.Scale / 2
	local v17 = math.min(v16, 0.5)
	local v18 = math.max(1 - v16, 0.5)
	local v21 = math.clamp(7 * (1.5 * v13.X.Scale) / math.max(v18 - v17, 0.01), 0.8, 3)
	local v22 = Maid.new()
	local DropReel = Instance.new("Frame")

	DropReel.Name = "DropReel"
	DropReel.BackgroundTransparency = 1
	DropReel.Size = UDim2.fromScale(1, 1)
	DropReel.Position = UDim2.fromScale(0, 0)
	DropReel.ZIndex = v9.ZIndex
	DropReel.ClipsDescendants = true
	DropReel.Parent = v2
	v22:GiveTask(DropReel)
	v22:GiveTask(function() --[[ Line: 236 | Upvalues: v9 (copy) ]]
		v9:Destroy()
	end)

	local t = {}

	v22:GiveTask(function() --[[ Line: 243 | Upvalues: t (copy) ]]
		for v1, v2 in t do
			v2:Cancel()
			v2:Destroy()
		end

		table.clear(t)
	end)

	local function track(p1) --[[ track | Line: 251 | Upvalues: t (copy) ]]
		local v1 = t

		table.insert(v1, p1)
		p1.Completed:Once(function() --[[ Line: 253 | Upvalues: t (ref), p1 (copy) ]]
			local v12 = table.find(t, p1)

			if not v12 then
				return
			end

			table.remove(t, v12)
			p1:Destroy()
		end)
		p1:Play()
	end

	local v23 = 0

	v22:GiveTask(task.spawn(function() --[[ Line: 264 | Upvalues: v23 (ref), p3 (copy), v13 (copy), v17 (copy), v9 (copy), DropReel (copy), v14 (copy), applyReelDrop (ref), TweenService (ref), v18 (copy), t (copy), v15 (copy), v21 (copy) ]]
		while true do
			v23 = v23 % #p3 + 1

			local ReelItem = Instance.new("CanvasGroup")

			ReelItem.Name = "ReelItem"
			ReelItem.BackgroundTransparency = 1
			ReelItem.AnchorPoint = Vector2.new(0.5, 0.5)
			ReelItem.Size = v13
			ReelItem.Position = UDim2.fromScale(v17, 0.5)
			ReelItem.GroupTransparency = 1
			ReelItem.ZIndex = v9.ZIndex
			ReelItem.Parent = DropReel

			local v2 = v9:Clone()

			v2.AnchorPoint = Vector2.new(0.5, 0.5)
			v2.Position = UDim2.fromScale(0.5, 0.5)
			v2.Size = UDim2.fromScale(v14, v14)
			applyReelDrop(v2, p3[v23])
			v2.Parent = ReelItem

			local v3 = TweenService:Create(ReelItem, TweenInfo.new(7, Enum.EasingStyle.Linear), {
				Position = UDim2.fromScale(v18, 0.5)
			})
			local v4 = t

			table.insert(v4, v3)
			v3.Completed:Once(function() --[[ Line: 253 | Upvalues: t (ref), v3 (copy) ]]
				local v12 = table.find(t, v3)

				if not v12 then
					return
				end

				table.remove(t, v12)
				v3:Destroy()
			end)
			v3:Play()

			local v5 = 0.9 + (math.random() - 0.5) * 0.4
			local v6 = (math.random() * 2 - 1) * v15

			v2.Position = UDim2.fromScale(0.5, 0.5 + v6)

			local v7 = TweenService:Create(v2, TweenInfo.new(v5, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true), {
				Position = UDim2.fromScale(0.5, 0.5 - v6)
			})
			local v8 = t

			table.insert(v8, v7)
			v7.Completed:Once(function() --[[ Line: 253 | Upvalues: t (ref), v7 (copy) ]]
				local v12 = table.find(t, v7)

				if not v12 then
					return
				end

				table.remove(t, v12)
				v7:Destroy()
			end)
			v7:Play()

			local v92 = TweenService:Create(ReelItem, TweenInfo.new(1.26), {
				GroupTransparency = 0
			})
			local v10 = t

			table.insert(v10, v92)
			v92.Completed:Once(function() --[[ Line: 253 | Upvalues: t (ref), v92 (copy) ]]
				local v12 = table.find(t, v92)

				if not v12 then
					return
				end

				table.remove(t, v12)
				v92:Destroy()
			end)
			v92:Play()
			task.delay(5.74, function() --[[ Line: 313 | Upvalues: ReelItem (copy), TweenService (ref), t (ref) ]]
				if not ReelItem.Parent then
					return
				end

				local v1 = TweenService:Create(ReelItem, TweenInfo.new(1.26), {
					GroupTransparency = 1
				})
				local v2 = t

				table.insert(v2, v1)
				v1.Completed:Once(function() --[[ Line: 253 | Upvalues: t (ref), v1 (copy) ]]
					local v12 = table.find(t, v1)

					if not v12 then
						return
					end

					table.remove(t, v12)
					v1:Destroy()
				end)
				v1:Play()
			end)
			task.delay(7.1, function() --[[ Line: 319 | Upvalues: ReelItem (copy) ]]
				ReelItem:Destroy()
			end)
			task.wait(v21)
		end
	end))

	return v22
end

return {
	start = function(p1, p2, p3) --[[ start | Line: 331 | Upvalues: startWithPool (copy), buildReelPool (copy) ]]
		return startWithPool(p1, p2, (buildReelPool(p3)))
	end,
	startWithPool = startWithPool
}