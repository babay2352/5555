-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local Remotes = require(ReplicatedStorage.shared.Remotes)
local t = {
	ColorText = function(p1, p2) --[[ ColorText | Line: 7 ]]
		return ("<font color=\"rgb(%*,%*,%*)\">%*</font>"):format(math.floor(p2.R * 255 + 0.5), math.floor(p2.G * 255 + 0.5), math.floor(p2.B * 255 + 0.5), p1)
	end
}

if RunService:IsClient() then
	local SignalBag = require(ReplicatedStorage.client.SignalBag)

	function t.Send(p1, p2, p3) --[[ Send | Line: 19 | Upvalues: SignalBag (copy) ]]
		SignalBag.Notification:Fire(p2, p3)
	end
else
	function t.Send(p1, p2, p3, p4) --[[ Send | Line: 23 | Upvalues: Remotes (copy) ]]
		Remotes.Notification:Fire(p2, p3, p4)
	end
	function t.Broadcast(p1, p2, p3) --[[ Broadcast | Line: 26 | Upvalues: Players (copy), Remotes (copy) ]]
		for v1, v2 in Players:GetPlayers() do
			Remotes.Notification:Fire(v2, p2, p3)
		end
	end
end

return t