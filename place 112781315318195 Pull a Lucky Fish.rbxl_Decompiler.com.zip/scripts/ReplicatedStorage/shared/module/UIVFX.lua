-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local t = {
	FrameOpenClose = require(script.FrameOpenClose),
	PulseScale = require(script.PulseScale),
	Shake = require(script.Shake),
	Vignette = require(script.Vignette),
	BossVignette = require(script.BossVignette)
}
local t2 = {}
local t3 = {}
local t4 = {}

local function applyEffect(p1, p2) --[[ applyEffect | Line: 19 | Upvalues: t2 (copy), t3 (copy) ]]
	local v1 = t2[p1]

	if not v1 then
		return
	end

	local v2 = t3[p2]

	if not v2 then
		v2 = {}
		t3[p2] = v2
	end

	if v2[p1] then
		return
	end

	local ok, result = pcall(v1.Apply, p2)

	if not ok then
		warn((("[UIVFX] effect \"%*\" failed: %*"):format(p1, result)))

		return
	end

	v2[p1] = if result then result else function() --[[ Line: 37 ]] end
end

local function removeEffect(p1, p2) --[[ removeEffect | Line: 40 | Upvalues: t3 (copy) ]]
	local v1 = t3[p2]

	if not v1 then
		return
	end

	local v2 = v1[p1]

	if v2 then
		local ok, result = pcall(v2)

		if not ok then
			warn((("[UIVFX] cleanup for \"%*\" failed: %*"):format(p1, result)))
		end

		v1[p1] = nil
	end

	if next(v1) ~= nil then
		return
	end

	t3[p2] = nil
end

function t.Register(p1) --[[ Register | Line: 58 | Upvalues: t4 (copy), t2 (copy), CollectionService (copy), applyEffect (copy), removeEffect (copy) ]]
	local Tag = p1.Tag

	if t4[Tag] then
		return
	end

	t4[Tag] = true
	t2[Tag] = p1

	for v1, v2 in CollectionService:GetTagged(Tag) do
		applyEffect(Tag, v2)
	end

	CollectionService:GetInstanceAddedSignal(Tag):Connect(function(p1) --[[ Line: 69 | Upvalues: applyEffect (ref), Tag (copy) ]]
		applyEffect(Tag, p1)
	end)
	CollectionService:GetInstanceRemovedSignal(Tag):Connect(function(p1) --[[ Line: 72 | Upvalues: removeEffect (ref), Tag (copy) ]]
		removeEffect(Tag, p1)
	end)
end
function t.Init() --[[ Init | Line: 77 | Upvalues: t (copy) ]]
	for v1, v2 in script.Effects:GetChildren() do
		if v2:IsA("ModuleScript") then
			t.Register((require(v2)))
		end
	end
end

return t