-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local t = {
	PRIMARY_LABEL = 1,
	SECONDARY_LABEL = 2,
	RARITY_LABEL = 3,
	DIVIDER = 4,
	COINS_MULTIPLIER = 5,
	TAIL_MULTIPLIER = 6,
	RANGE_INCREASE = 7,
	ROLL_CHANCES = 8
}

return table.freeze({
	entryEnum = t,
	labelBased = { t.PRIMARY_LABEL, t.SECONDARY_LABEL, t.RARITY_LABEL }
})