-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local AlienEventConfig = require(ReplicatedStorage.shared.config.AlienEventConfig)
local AlienResearch = require(ReplicatedStorage.shared.util.AlienResearch)
local AuctionHouseConfig = require(ReplicatedStorage.shared.config.AuctionHouseConfig)
local AuctionRotation = require(ReplicatedStorage.shared.util.AuctionRotation)
local CurrenciesConfig = require(ReplicatedStorage.shared.config.CurrenciesConfig)
local DailyQuestConfig = require(ReplicatedStorage.shared.config.DailyQuestConfig)
local DecorationConfig = require(ReplicatedStorage.shared.config.DecorationConfig)
local EnchantConfig = require(ReplicatedStorage.shared.config.EnchantConfig)
local EquipBestConfig = require(ReplicatedStorage.shared.config.EquipBestConfig)
local EventConfig = require(ReplicatedStorage.shared.config.EventConfig)
local FishConfig = require(ReplicatedStorage.shared.config.FishConfig)
local FishingFloatsConfig = require(ReplicatedStorage.shared.config.FishingFloatsConfig)
local FloatRecycleMachineConfig = require(ReplicatedStorage.shared.config.FloatRecycleMachineConfig)
local GardenConfig = require(ReplicatedStorage.shared.config.GardenConfig)
local IndexMilestoneConfig = require(ReplicatedStorage.shared.config.IndexMilestoneConfig)
local IndexRewardConfig = require(ReplicatedStorage.shared.config.IndexRewardConfig)
local LiveEventRegistry = require(ReplicatedStorage.shared.config.LiveEventRegistry)
local MutationList = require(ReplicatedStorage.shared.util.MutationList)
local PurchaseLog = require(ReplicatedStorage.shared.util.PurchaseLog)
local QuestConfig = require(ReplicatedStorage.shared.config.QuestConfig)
local RebirthConfig = require(ReplicatedStorage.shared.config.RebirthConfig)
local Reflex = require(ReplicatedStorage.package.Reflex)
local TransferLog = require(ReplicatedStorage.shared.util.TransferLog)
local VaultConfig = require(ReplicatedStorage.shared.config.VaultConfig)
local WorldsConfig = require(ReplicatedStorage.shared.config.WorldsConfig)
local buildInventoryKey = require(ReplicatedStorage.shared.util.buildInventoryKey)
local favoriteCount = require(ReplicatedStorage.shared.util.favoriteCount)
local gardenGrid = require(ReplicatedStorage.shared.util.gardenGrid)
local getAvilibleBaseSlotsNames = require(ReplicatedStorage.shared.util.getAvilibleBaseSlotsNames)
local pullSpeedUpgradeCost = require(ReplicatedStorage.shared.util.pullSpeedUpgradeCost)
local rollSpeedUpgradeCost = require(ReplicatedStorage.shared.util.rollSpeedUpgradeCost)
local throwSpeedUpgradeCost = require(ReplicatedStorage.shared.util.throwSpeedUpgradeCost)
local tradeLockCount = require(ReplicatedStorage.shared.util.tradeLockCount)
local paidCopyCount = require(ReplicatedStorage.shared.util.paidCopyCount)
local t = {
	equippedFloats = {},
	boughtSlots = { 1 },
	fishingFloats = {
		Common = {},
		Rare = {},
		Epic = {},
		Legendary = {},
		Mythic = {},
		Godly = {}
	},
	money = 1000,
	rollSpeed = 0,
	offlineMoney = 0,
	strength = 0,
	trainingTool = "",
	fishRod = "FISHROD1",
	pullSpeed = 0,
	throwSpeed = 120,
	tycoonLevel = 1,
	rebirthLevel = 0,
	freeGiftClaimed = false,
	inventory = {},
	favorites = {},
	tradeLocks = {},
	paidCopies = {},
	index = {},
	claimedIndexRewards = {},
	claimedIndexMilestones = {},
	baseSlots = {},
	lastGameEnter = os.time(),
	referredBy = 0,
	referredAt = 0,
	tutorialInfo = {
		tutorialStep = 1
	},
	stats = {
		fishCaught = 0,
		footballFishCaught = 0,
		moonFishCaught = 0,
		totalCash = 0,
		gemsEarned = 0,
		dailyQuestsCompleted = 0,
		rarityFishCaught = {}
	},
	freeRevives = 1,
	hasSendFeedback = false,
	seenAuctionHouse = false,
	seenEnchantStone = false,
	unlockedFishingVillage = false,
	vault = {
		fish = {}
	},
	deepsGear = {
		fins = "",
		tank = "",
		bag = "",
		owned = {}
	},
	deeps = {
		bag = {}
	},
	adminCoolDowns = {},
	version = "",
	gems = 0,
	enchantStones = 0,
	rodEnchants = {},
	catCoins = 0,
	totalCatCoins = 0,
	catEventRewardClaimed = false,
	events = {},
	dailyQuests = {},
	dailyLastReset = 0,
	claimedDailyRewards = {},
	quests = {
		LastReset = 0,
		Completed = 0,
		TrackProgress = 0,
		Milestones = 0,
		Active = {}
	},
	totalPlayTime = 0,
	equippedBaseSkin = "",
	unlockedBaseSkins = {},
	lastMountId = "",
	activePotions = {},
	dailyLoginDay = 1,
	dailyLoginLastClaim = 0,
	hasAutoCollect = false,
	hasAutoSell = false,
	hasEquipBest = false,
	garden = {
		bought = false,
		upgrades = {},
		items = {}
	},
	placedLootboxes = {},
	lootboxShopWindow = 0,
	lootboxShopSoldSlots = {},
	lootboxShopForcedItems = nil,
	lootboxShopItems = nil,
	decorationsStoreWindow = 0,
	decorationsStoreStock = {},
	eventStoreWindow = 0,
	eventStoreStock = {},
	purchasedEventItems = {},
	catMachineFedCount = 0,
	mutationMachinePendingMutationId = nil,
	mutationMachinePendingEndsAt = nil,
	mutationMachinePendingFishConfigName = nil,
	mutationMachinePendingFishLevel = nil,
	mutationMachinePendingFishMutation = nil,
	mutationMachinePendingFishScanned = nil,
	mutationMachinePendingFishUntradable = nil,
	mutationMachinePendingFishPaid = nil,
	npcTrade = {
		count = 0,
		lastArrival = 0,
		pendingOffer = nil
	},
	cookingPoints = 0,
	cookingState = "idle",
	cookingStartTime = 0,
	redeemedPromocodes = {},
	milestones = {
		totals = {},
		claimed = {},
		maxClaimable = {}
	},
	luckyblockPity = {},
	contributedExistCounts = {},
	autoSellRarities = {},
	autoSellMinEarnings = 0,
	rewardPopup = {
		gotPopUp = false,
		content = {}
	},
	auctionRewardPopup = {
		gotPopUp = false,
		content = {}
	},
	settings = {
		musicEnabled = true,
		giftsEnabled = true,
		tradesEnabled = true,
		chaseMusicEnabled = true,
		otherPlayersFishingEnabled = true,
		cashIconsEnabled = false,
		baseMutationVfxEnabled = true
	},
	currentWorldId = WorldsConfig.DefaultWorldId,
	rarityCatchBackfilled = false,
	gemsEarnedBackfilled = false,
	unlockedWorlds = {},
	purchaseIdLog = {},
	transferLog = {},
	auctionEscrow = {},
	auctionPurchases = {}
}

local function defaultEventData() --[[ defaultEventData | Line: 1194 ]]
	return {
		coins = 0,
		totalCoins = 0,
		machineFedCount = 0,
		cookingPoints = 0,
		cookingState = "idle",
		cookingStartTime = 0,
		storeWindow = 0,
		fuel = 0,
		storeStock = {},
		storePurchases = {},
		upgrades = {},
		research = {}
	}
end

local function withEventData(p1, p2) --[[ withEventData | Line: 1217 | Upvalues: defaultEventData (copy) ]]
	local v1 = table.clone(p1)
	local v3 = table.clone(v1.events or {})
	local v4 = v3[p2]
	local v5 = if v4 then table.clone(v4) else defaultEventData()

	v5.fuel = v5.fuel or 0
	v5.upgrades = v5.upgrades or {}
	v5.research = v5.research or {}
	v3[p2] = v5
	v1.events = v3

	return v1, v5
end

local function withDeeps(p1) --[[ withDeeps | Line: 1236 ]]
	local v1 = table.clone(p1)
	local deeps = p1.deeps
	local v2 = if deeps then table.clone(deeps) else {
	bag = {}
}

	v2.bag = v2.bag or {}
	v1.deeps = v2

	return v1, v2
end

local function withDeepsGear(p1) --[[ withDeepsGear | Line: 1246 ]]
	local v1 = table.clone(p1)
	local deepsGear = p1.deepsGear
	local t = {}

	t.owned = table.clone(deepsGear and deepsGear.owned or {})
	t.fins = deepsGear and deepsGear.fins or ""
	t.tank = deepsGear and deepsGear.tank or ""
	t.bag = deepsGear and deepsGear.bag or ""
	v1.deepsGear = t

	return v1, t
end

local t2 = {
	fins = true,
	tank = true,
	bag = true
}

local function withGarden(p1) --[[ withGarden | Line: 1263 ]]
	local v1 = table.clone(p1)
	local garden = p1.garden
	local t = {}

	t.bought = if garden == nil then false elseif garden.bought == true then true else false

	local clone = table.clone

	t.upgrades = clone(garden and garden.upgrades or {})

	local clone2 = table.clone

	t.items = clone2(garden and garden.items or {})
	v1.garden = t

	return v1, t
end

local function withGardenGrant(p1) --[[ withGardenGrant | Line: 1288 | Upvalues: GardenConfig (copy), withGarden (copy) ]]
	if (p1.rebirthLevel or 0) < GardenConfig.Unlock.RebirthLevel then
		return p1
	end

	local garden = p1.garden

	if garden and garden.bought then
		return p1
	end

	local v1, v2 = withGarden(p1)

	v2.bought = true

	return v1
end

local function withVault(p1) --[[ withVault | Line: 1303 ]]
	local v1 = table.clone(p1)
	local vault = p1.vault
	local t = {}
	local clone = table.clone

	t.fish = clone(if vault then vault.fish or {} else {})
	v1.vault = t

	return v1, t
end

local function refundDisplayFish(p1, p2) --[[ refundDisplayFish | Line: 1313 | Upvalues: buildInventoryKey (copy) ]]
	local v1 = buildInventoryKey(p2.ConfigName, p2.Level, p2.Mutation, p2.Scanned, p2.Untradable, p2.Paid)

	p1.inventory = table.clone(p1.inventory)

	local v2 = p1.inventory[v1]

	if v2 then
		local v3 = table.clone(v2)

		v3.Stack = (v2.Stack or 0) + 1
		p1.inventory[v1] = v3
	else
		p1.inventory[v1] = {
			Category = "Fish",
			Stack = 1,
			ConfigName = p2.ConfigName,
			ExtraInfo = {
				Level = p2.Level,
				Mutation = p2.Mutation,
				Scanned = p2.Scanned,
				Untradable = p2.Untradable,
				Paid = p2.Paid
			}
		}
	end
end

local function clampFavorite(p1, p2) --[[ clampFavorite | Line: 1341 | Upvalues: favoriteCount (copy) ]]
	local v1 = favoriteCount(p1.favorites, p2)

	if v1 == 0 then
		return
	end

	local v2 = p1.inventory[p2]
	local v4 = math.min(v1, if v2 then v2.Stack else 0)

	if v4 == v1 then
		return
	end

	p1.favorites = table.clone(p1.favorites or {})

	if v4 > 0 then
		p1.favorites[p2] = v4
	else
		p1.favorites[p2] = nil
	end
end

local function clampTradeLock(p1, p2) --[[ clampTradeLock | Line: 1363 | Upvalues: tradeLockCount (copy) ]]
	local v1 = tradeLockCount(p1.tradeLocks, p2)

	if v1 == 0 then
		return
	end

	local v2 = p1.inventory[p2]
	local v4 = math.min(v1, if v2 then v2.Stack else 0)

	if v4 == v1 then
		return
	end

	p1.tradeLocks = table.clone(p1.tradeLocks or {})

	if v4 > 0 then
		p1.tradeLocks[p2] = v4
	else
		p1.tradeLocks[p2] = nil
	end
end

local function clampPaidCopies(p1, p2) --[[ clampPaidCopies | Line: 1386 | Upvalues: paidCopyCount (copy) ]]
	local v1 = paidCopyCount(p1.paidCopies, p2)

	if v1 == 0 then
		return
	end

	local v2 = p1.inventory[p2]
	local v4 = math.min(v1, if v2 then v2.Stack else 0)

	if v4 == v1 then
		return
	end

	p1.paidCopies = table.clone(p1.paidCopies or {})

	if v4 > 0 then
		p1.paidCopies[p2] = v4
	else
		p1.paidCopies[p2] = nil
	end
end

local function markPaidInState(p1, p2, p3) --[[ markPaidInState | Line: 1406 | Upvalues: paidCopyCount (copy) ]]
	local v1 = p1.inventory[p2]

	if not v1 or p3 < 1 then
		return
	end

	local v4 = math.min(paidCopyCount(p1.paidCopies, p2) + math.floor(p3), v1.Stack or 1)

	p1.paidCopies = table.clone(p1.paidCopies or {})
	p1.paidCopies[p2] = v4
end

local function lockOneInState(p1, p2) --[[ lockOneInState | Line: 1418 | Upvalues: tradeLockCount (copy) ]]
	local v1 = p1.inventory[p2]

	if not v1 then
		return
	end

	local v4 = math.min(tradeLockCount(p1.tradeLocks, p2) + 1, v1.Stack or 1)

	p1.tradeLocks = table.clone(p1.tradeLocks or {})
	p1.tradeLocks[p2] = v4
end

local function grantItemInState(p1, p2, p3) --[[ grantItemInState | Line: 1432 | Upvalues: AlienResearch (copy), buildInventoryKey (copy) ]]
	p1.inventory = table.clone(p1.inventory)

	local v1, v2, v3, v4, v5

	if p2.Category == "Fish" then
		local v6 = p3 and p3.Level or 1
		local v7 = if p3 then p3.Mutation else p3
		local v8 = if p3 then p3.Scanned else p3

		if p3 and p3.Untradable == true then
			v1 = v8
			v2 = v6
			v3 = v7
			v4 = true
		else
			v2 = v6
			v3 = v7
			v1 = v8
			v4 = nil
		end

		v5 = if p3 and p3.Paid == true then true else nil

		if v1 == nil then
			v1 = AlienResearch.initialFor(p2.ConfigName)
		end
	else
		v2 = nil
		v3 = nil
		v1 = nil
		v4 = nil
		v5 = nil
	end

	local v10 = buildInventoryKey(p2.ConfigName, v2, v3, v1, v4, v5)
	local v11 = p1.inventory[v10]

	if v11 then
		local v12 = table.clone(v11)

		v12.Stack = v11.Stack + 1
		p1.inventory[v10] = v12
	else
		local t = {
			Stack = 1,
			Category = p2.Category,
			ConfigName = p2.ConfigName
		}

		if p2.Category == "Fish" then
			t.ExtraInfo = {
				Level = v2,
				Mutation = v3,
				Scanned = v1,
				Untradable = v4,
				Paid = v5
			}
		end

		p1.inventory[v10] = t
	end

	if p2.Category ~= "Fish" or p1.index[p2.ConfigName] then
		return v10
	end

	p1.index = table.clone(p1.index)
	p1.index[p2.ConfigName] = true

	return v10
end

local function grantFloatInState(p1, p2, p3) --[[ grantFloatInState | Line: 1478 ]]
	p1.fishingFloats = table.clone(p1.fishingFloats)

	local clone = table.clone

	p1.fishingFloats[p3] = clone(p1.fishingFloats[p3] or {})
	p1.fishingFloats[p3][p2] = (p1.fishingFloats[p3][p2] or 0) + 1
end

function CreateProducer(p1) --[[ CreateProducer | Line: 1492 | Upvalues: Reflex (copy), FishingFloatsConfig (copy), rollSpeedUpgradeCost (copy), pullSpeedUpgradeCost (copy), throwSpeedUpgradeCost (copy), RebirthConfig (copy), GardenConfig (copy), withGarden (copy), AlienResearch (copy), buildInventoryKey (copy), markPaidInState (copy), PurchaseLog (copy), TransferLog (copy), clampFavorite (copy), clampTradeLock (copy), clampPaidCopies (copy), CurrenciesConfig (copy), withEventData (copy), MutationList (copy), getAvilibleBaseSlotsNames (copy), FishConfig (copy), WorldsConfig (copy), EnchantConfig (copy), EventConfig (copy), LiveEventRegistry (copy), AlienEventConfig (copy), t2 (copy), withDeepsGear (copy), withDeeps (copy), QuestConfig (copy), DailyQuestConfig (copy), IndexRewardConfig (copy), IndexMilestoneConfig (copy), EquipBestConfig (copy), VaultConfig (copy), gardenGrid (copy), tradeLockCount (copy), DecorationConfig (copy), lockOneInState (copy), refundDisplayFish (copy), favoriteCount (copy), withVault (copy), FloatRecycleMachineConfig (copy), t (copy), paidCopyCount (copy), AuctionHouseConfig (copy), grantItemInState (copy), AuctionRotation (copy), grantFloatInState (copy) ]]
	return Reflex.createProducer(p1, {
		secureEquipFloat = function(p1, p2, p3, p4) --[[ secureEquipFloat | Line: 1495 ]]
			if not table.find(p1.boughtSlots, p4) then
				return p1
			end

			local v1 = p1.fishingFloats[p3]

			if not v1 or (not v1[p2] or v1[p2] <= 0) then
				return p1
			end

			local v2 = table.clone(p1)

			v2.fishingFloats = table.clone(v2.fishingFloats)
			v2.equippedFloats = table.clone(v2.equippedFloats)

			local v3 = tostring(p4)
			local v4 = v2.equippedFloats[v3]

			if v4 then
				local tier = v4.tier

				v2.fishingFloats[tier] = table.clone(v2.fishingFloats[tier] or {})
				v2.fishingFloats[tier][v4.name] = (v2.fishingFloats[tier][v4.name] or 0) + 1
			end

			local clone = table.clone

			v2.fishingFloats[p3] = clone(v2.fishingFloats[p3] or {})

			local v7 = (v2.fishingFloats[p3][p2] or 0) - 1

			if v7 <= 0 then
				v2.fishingFloats[p3][p2] = nil
			else
				v2.fishingFloats[p3][p2] = v7
			end

			v2.equippedFloats[v3] = {
				name = p2,
				tier = p3
			}

			return v2
		end,
		secureUnequipFloat = function(p1, p2) --[[ secureUnequipFloat | Line: 1540 ]]
			local v1 = table.clone(p1)

			v1.fishingFloats = table.clone(v1.fishingFloats)
			v1.equippedFloats = table.clone(v1.equippedFloats)

			local v2 = tostring(p2)
			local v3 = v1.equippedFloats[v2]

			if v3 then
				local tier = v3.tier

				v1.fishingFloats[tier] = table.clone(v1.fishingFloats[tier] or {})
				v1.fishingFloats[tier][v3.name] = (v1.fishingFloats[tier][v3.name] or 0) + 1
			end

			v1.equippedFloats[v2] = nil

			return v1
		end,
		secureBuySlot = function(p1, p2) --[[ secureBuySlot | Line: 1563 | Upvalues: FishingFloatsConfig (ref) ]]
			local v1 = FishingFloatsConfig.FloatSlots[p2]

			if not v1 then
				return p1
			end

			if v1.Premium then
				return p1
			end

			if table.find(p1.boughtSlots, p2) then
				return p1
			end

			if p1.rebirthLevel < v1.RebirthRequired then
				return p1
			end

			if p1.money < v1.Price then
				return p1
			end

			local v2 = table.clone(p1)

			v2.boughtSlots = table.clone(v2.boughtSlots)
			table.insert(v2.boughtSlots, p2)
			v2.money = v2.money - v1.Price

			return v2
		end,
		secureBuySlotWithGems = function(p1, p2) --[[ secureBuySlotWithGems | Line: 1589 | Upvalues: FishingFloatsConfig (ref) ]]
			local v1 = FishingFloatsConfig.FloatSlots[p2]

			if v1 and v1.Premium then
				if table.find(p1.boughtSlots, p2) then
					return p1
				end

				local GemPrice = v1.GemPrice

				if GemPrice and not (p1.gems < GemPrice) then
					local v2 = table.clone(p1)

					v2.boughtSlots = table.clone(v2.boughtSlots)
					table.insert(v2.boughtSlots, p2)
					v2.gems = v2.gems - GemPrice

					return v2
				end
			end

			return p1
		end,
		secureBuySlotPremium = function(p1, p2) --[[ secureBuySlotPremium | Line: 1610 | Upvalues: FishingFloatsConfig (ref) ]]
			local v1 = FishingFloatsConfig.FloatSlots[p2]

			if v1 and v1.Premium then
				if table.find(p1.boughtSlots, p2) then
					return p1
				end

				local v2 = table.clone(p1)

				v2.boughtSlots = table.clone(v2.boughtSlots)
				table.insert(v2.boughtSlots, p2)

				return v2
			end

			return p1
		end,
		secureChangeMoney = function(p1, p2) --[[ secureChangeMoney | Line: 1625 ]]
			local v1 = table.clone(p1)

			v1.stats = table.clone(v1.stats)
			v1.money = math.max(0, (math.floor(v1.money + p2)))

			if p2 > 0 then
				local v4 = v1.stats

				v4.totalCash = v4.totalCash + p2
			end

			return v1
		end,
		secureChangeOfflineMoney = function(p1, p2) --[[ secureChangeOfflineMoney | Line: 1638 ]]
			local v1 = table.clone(p1)

			v1.offlineMoney = math.max(0, (math.floor(v1.offlineMoney + p2)))

			return v1
		end,
		secureChangeStrength = function(p1, p2) --[[ secureChangeStrength | Line: 1645 ]]
			local v1 = table.clone(p1)

			v1.strength = math.max(0, (math.floor(v1.strength + p2)))

			return v1
		end,
		secureChangeTrainingTool = function(p1, p2) --[[ secureChangeTrainingTool | Line: 1656 ]]
			local v1 = table.clone(p1)

			if v1.trainingTool == p2 then
				return v1
			end

			v1.inventory = table.clone(v1.inventory)

			local trainingTool = v1.trainingTool

			if trainingTool ~= "" and (trainingTool ~= p2 and not v1.inventory[trainingTool]) then
				v1.inventory[trainingTool] = {
					Category = "TrainingTool",
					Stack = 1,
					ConfigName = trainingTool
				}
			end

			v1.inventory[p2] = nil
			v1.trainingTool = p2

			return v1
		end,
		secureChangeFishRod = function(p1, p2) --[[ secureChangeFishRod | Line: 1677 ]]
			local v1 = table.clone(p1)

			if v1.fishRod == p2 then
				return v1
			end

			v1.inventory = table.clone(v1.inventory)

			local fishRod = v1.fishRod

			if fishRod ~= "" and (fishRod ~= p2 and not v1.inventory[fishRod]) then
				v1.inventory[fishRod] = {
					Category = "FishRod",
					Stack = 1,
					ConfigName = fishRod
				}
			end

			v1.inventory[p2] = nil
			v1.fishRod = p2

			return v1
		end,
		secureUpgradeRollSpeed = function(p1) --[[ secureUpgradeRollSpeed | Line: 1703 | Upvalues: rollSpeedUpgradeCost (ref) ]]
			local v1 = rollSpeedUpgradeCost(p1.rollSpeed)

			if v1 == nil then
				return p1
			end

			if p1.money < v1 then
				return p1
			end

			local v2 = table.clone(p1)

			v2.money = v2.money - v1
			v2.rollSpeed = p1.rollSpeed + 1

			return v2
		end,
		secureUpgradePullSpeed = function(p1) --[[ secureUpgradePullSpeed | Line: 1716 | Upvalues: pullSpeedUpgradeCost (ref) ]]
			local v1 = pullSpeedUpgradeCost(p1.pullSpeed)

			if v1 == nil then
				return p1
			end

			if p1.money < v1 then
				return p1
			end

			local v2 = table.clone(p1)

			v2.money = v2.money - v1
			v2.pullSpeed = p1.pullSpeed + 1

			return v2
		end,
		secureUpgradeThrowSpeed = function(p1) --[[ secureUpgradeThrowSpeed | Line: 1730 | Upvalues: throwSpeedUpgradeCost (ref) ]]
			local v1 = throwSpeedUpgradeCost(p1.throwSpeed)

			if v1 == nil then
				return p1
			end

			if p1.money < v1 then
				return p1
			end

			local v2 = table.clone(p1)

			v2.money = v2.money - v1
			v2.throwSpeed = p1.throwSpeed + 1

			return v2
		end,
		secureChangeTycoonLevel = function(p1, p2) --[[ secureChangeTycoonLevel | Line: 1744 ]]
			local v1 = table.clone(p1)

			v1.tycoonLevel = math.max(1, (math.floor(p2)))

			return v1
		end,
		secureRebirth = function(p1) --[[ secureRebirth | Line: 1754 | Upvalues: RebirthConfig (ref), GardenConfig (ref), withGarden (ref) ]]
			local v1 = p1.rebirthLevel + 1
			local v2 = RebirthConfig.Config[v1]

			if v2 and not (p1.strength < v2.RequiredStrength) then
				local v3 = table.clone(p1)

				v3.rebirthLevel = v1
				v3.strength = 0

				if (v3.rebirthLevel or 0) < GardenConfig.Unlock.RebirthLevel then
					return v3
				end

				local garden = v3.garden

				if garden and garden.bought then
					return v3
				end

				local v4, v5 = withGarden(v3)

				v5.bought = true

				return v4
			end

			return p1
		end,
		secureRebirthKeepStrength = function(p1) --[[ secureRebirthKeepStrength | Line: 1769 | Upvalues: RebirthConfig (ref), GardenConfig (ref), withGarden (ref) ]]
			local v1 = p1.rebirthLevel + 1

			if not RebirthConfig.Config[v1] then
				return p1
			end

			local v2 = table.clone(p1)

			v2.rebirthLevel = v1

			if (v2.rebirthLevel or 0) < GardenConfig.Unlock.RebirthLevel then
				return v2
			end

			local garden = v2.garden

			if garden and garden.bought then
				return v2
			end

			local v3, v4 = withGarden(v2)

			v4.bought = true

			return v3
		end,
		secureSetRebirthLevel = function(p1, p2) --[[ secureSetRebirthLevel | Line: 1783 | Upvalues: RebirthConfig (ref), GardenConfig (ref), withGarden (ref) ]]
			local v1 = table.clone(p1)

			v1.rebirthLevel = math.clamp(math.floor(p2), 0, #RebirthConfig.Config)

			if (v1.rebirthLevel or 0) < GardenConfig.Unlock.RebirthLevel then
				return v1
			end

			local garden = v1.garden

			if garden and garden.bought then
				return v1
			end

			local v4, v5 = withGarden(v1)

			v5.bought = true

			return v4
		end,
		secureClaimFreeGift = function(p1) --[[ secureClaimFreeGift | Line: 1796 ]]
			if p1.freeGiftClaimed then
				return p1
			end

			local v1 = table.clone(p1)

			v1.freeGiftClaimed = true

			return v1
		end,
		secureAddItem = function(p1, p2, p3, p4, p5) --[[ secureAddItem | Line: 1812 | Upvalues: AlienResearch (ref), buildInventoryKey (ref), markPaidInState (ref) ]]
			local v1 = table.clone(p1)

			v1.inventory = table.clone(v1.inventory)

			local v2, v3, v4, v5, v6

			if p2.Category == "Fish" then
				local v7 = p4 and p4.Level or 1
				local v8 = if p4 then p4.Mutation else p4
				local v9 = if p4 then p4.Scanned else p4

				if p4 and p4.Untradable == true then
					v2 = true
					v3 = v9
					v4 = v7
					v5 = v8
				else
					v4 = v7
					v5 = v8
					v2 = nil
					v3 = v9
				end

				v6 = if p4 and p4.Paid == true then true else nil

				if v3 == nil then
					v3 = AlienResearch.initialFor(p2.ConfigName)
				end
			else
				v4 = nil
				v5 = nil
				v3 = nil
				v2 = nil
				v6 = nil
			end

			local v11 = buildInventoryKey(p2.ConfigName, v4, v5, v3, v2, v6)
			local v12 = v1.inventory[v11]

			if v12 then
				local v13 = table.clone(v12)

				v13.Stack = v12.Stack + p3
				v1.inventory[v11] = v13
			else
				local t = {
					Category = p2.Category,
					ConfigName = p2.ConfigName,
					Stack = p3
				}

				if p2.Category == "Fish" then
					t.ExtraInfo = {
						Level = v4,
						Mutation = v5,
						Scanned = v3,
						Untradable = v2,
						Paid = v6
					}
				end

				v1.inventory[v11] = t
			end

			if p5 == true and p2.Category ~= "Fish" then
				markPaidInState(v1, v11, p3)
			end

			if p2.Category == "Fish" and not v1.index[p2.ConfigName] then
				v1.index = table.clone(v1.index)
				v1.index[p2.ConfigName] = true
			end

			return v1
		end,
		secureLogPurchaseId = function(p1, p2, p3, p4, p5) --[[ secureLogPurchaseId | Line: 1885 | Upvalues: PurchaseLog (ref) ]]
			local v1 = PurchaseLog.Normalize(p1.purchaseIdLog)
			local v2 = v1[p2]

			if v2 and (v2.ok and p4) then
				return p1
			end

			local v3 = table.clone(v1)
			local t = {
				t = os.time(),
				ok = p4,
				p = p3
			}

			t.n = if v2 then (v2.n or 1) + 1 else nil
			t.e = if p4 then nil else p5
			v3[p2] = t
			PurchaseLog.Prune(v3)

			local v6 = table.clone(p1)

			v6.purchaseIdLog = v3

			return v6
		end,
		secureLogTransfer = function(p1, p2) --[[ secureLogTransfer | Line: 1916 | Upvalues: TransferLog (ref) ]]
			local v2 = table.clone(p1.transferLog or {})

			table.insert(v2, {
				k = p2.k,
				t = os.time(),
				o = p2.o,
				on = p2.on,
				g = p2.g,
				r = p2.r
			})

			local v3 = table.clone(p1)

			v3.transferLog = TransferLog.Prune(v2, os.time())

			return v3
		end,
		secureRemoveItem = function(p1, p2, p3) --[[ secureRemoveItem | Line: 1934 | Upvalues: clampFavorite (ref), clampTradeLock (ref), clampPaidCopies (ref) ]]
			local v1 = table.clone(p1)

			v1.inventory = table.clone(v1.inventory)

			local v2 = v1.inventory[p2]

			if not v2 then
				return v1
			end

			local v3 = v2.Stack - p3

			if v3 <= 0 then
				v1.inventory[p2] = nil
			else
				local v4 = table.clone(v2)

				v4.Stack = v3
				v1.inventory[p2] = v4
			end

			clampFavorite(v1, p2)
			clampTradeLock(v1, p2)
			clampPaidCopies(v1, p2)

			return v1
		end,
		secureModifyInventory = function(p1, p2, p3) --[[ secureModifyInventory | Line: 1955 | Upvalues: clampFavorite (ref), clampTradeLock (ref), clampPaidCopies (ref), buildInventoryKey (ref), markPaidInState (ref) ]]
			local v1 = table.clone(p1)

			v1.inventory = table.clone(v1.inventory)

			for v2, v3 in p3 do
				local v4 = v1.inventory[v2]

				if v4 then
					local v6 = v4.Stack - (if v3.stackIds then #v3.stackIds or 1 else 1)

					if v6 <= 0 then
						v1.inventory[v2] = nil
					else
						local v7 = table.clone(v4)

						v7.Stack = v6
						v1.inventory[v2] = v7
					end

					clampFavorite(v1, v2)
					clampTradeLock(v1, v2)
					clampPaidCopies(v1, v2)
				end
			end

			for v13, v14 in p2 do
				local v8, v9, v10, v11, v12

				if v14.Category == "Fish" then
					local v15 = v14.ExtraInfo and v14.ExtraInfo.Level or 1
					local v16 = v14.ExtraInfo and v14.ExtraInfo.Mutation
					local v17 = v14.ExtraInfo and v14.ExtraInfo.Scanned

					if v14.ExtraInfo and v14.ExtraInfo.Untradable == true then
						v8 = v17
						v9 = true
						v10 = v15
						v11 = v16
					else
						v10 = v15
						v11 = v16
						v8 = v17
						v9 = nil
					end

					v12 = if v14.ExtraInfo and v14.ExtraInfo.Paid == true then true else nil
				else
					v9 = nil
					v12 = nil
					v10 = nil
					v11 = nil
					v8 = nil
				end

				if v14.Category == "Fish" and not v1.index[v14.ConfigName] then
					v1.index = table.clone(v1.index)
					v1.index[v14.ConfigName] = true
				end

				local v18 = buildInventoryKey(v14.ConfigName, v10, v11, v8, v9, v12)
				local v19 = v1.inventory[v18]

				if v19 then
					local v20 = table.clone(v19)

					v20.Stack = v19.Stack + (v14.stackIds and #v14.stackIds or 1)
					v1.inventory[v18] = v20
				else
					local t = {
						Category = v14.Category,
						ConfigName = v14.ConfigName
					}

					t.Stack = v14.stackIds and #v14.stackIds or 1

					if v14.Category == "Fish" then
						t.ExtraInfo = {
							Level = v10,
							Mutation = v11,
							Scanned = v8,
							Untradable = v9,
							Paid = v12
						}
					end

					v1.inventory[v18] = t
				end

				if v14.Category ~= "Fish" and (type(v14.paidCopies) == "number" and v14.paidCopies > 0) then
					markPaidInState(v1, v18, v14.paidCopies)
				end
			end

			return v1
		end,
		secureModifyCurrencies = function(p1, p2, p3) --[[ secureModifyCurrencies | Line: 2040 | Upvalues: CurrenciesConfig (ref), withEventData (ref) ]]
			local v1 = table.clone(p1)

			local function applyDelta(p1, p2) --[[ applyDelta | Line: 2051 | Upvalues: CurrenciesConfig (ref), withEventData (ref), v1 (ref) ]]
				local v12 = CurrenciesConfig[p1]

				if not v12 then
					return
				end

				if v12.eventCoinsId then
					local v2, v3 = withEventData(v1, v12.eventCoinsId)

					v3.coins = math.max(0, v3.coins + p2)
					v1 = v2

					return
				end

				if not v12.adjust then
					return
				end

				v12.adjust(v1, p2)
			end

			for v2, v3 in p2 do
				local v4 = CurrenciesConfig[v2]

				if v4 then
					if v4.eventCoinsId then
						local v5, v6 = withEventData(v1, v4.eventCoinsId)

						v6.coins = math.max(0, v6.coins + v3)
						v1 = v5

						continue
					end

					if v4.adjust then
						v4.adjust(v1, v3)
					end
				end
			end

			for v8, v9 in p3 do
				local v10 = -v9
				local v11 = CurrenciesConfig[v8]

				if v11 then
					if v11.eventCoinsId then
						local v12, v13 = withEventData(v1, v11.eventCoinsId)

						v13.coins = math.max(0, v13.coins + v10)
						v1 = v12

						continue
					end

					if v11.adjust then
						v11.adjust(v1, v10)
					end
				end
			end

			return v1
		end,
		secureMutateFishStacks = function(p1, p2) --[[ secureMutateFishStacks | Line: 2088 | Upvalues: MutationList (ref), clampFavorite (ref), clampTradeLock (ref), buildInventoryKey (ref) ]]
			local v1 = table.clone(p1)

			v1.inventory = table.clone(v1.inventory)

			for v2, v3 in p2 do
				local v4 = v1.inventory[v3.fromKey]

				if v4 and (v4.Category == "Fish" and (v3.count > 0 and v4.Stack >= v3.count)) then
					local v5 = v4.ExtraInfo or {}
					local v6 = v5.Level or 1
					local Mutation = v5.Mutation
					local Scanned = v5.Scanned
					local v7 = if v5.Untradable == true then true else nil
					local v8 = if v5.Paid == true then true else nil
					local v9 = MutationList.parse(Mutation)

					table.insert(v9, v3.mutation)

					local v10 = MutationList.format(v9)

					if v10 ~= Mutation then
						local v11 = v4.Stack - v3.count

						if v11 <= 0 then
							v1.inventory[v3.fromKey] = nil
						else
							local v12 = table.clone(v4)

							v12.Stack = v11
							v1.inventory[v3.fromKey] = v12
						end

						clampFavorite(v1, v3.fromKey)
						clampTradeLock(v1, v3.fromKey)

						local v13 = buildInventoryKey(v4.ConfigName, v6, v10, Scanned, v7, v8)
						local v14 = v1.inventory[v13]

						if v14 then
							local v15 = table.clone(v14)

							v15.Stack = v14.Stack + v3.count
							v1.inventory[v13] = v15

							continue
						end

						v1.inventory[v13] = {
							Category = "Fish",
							ConfigName = v4.ConfigName,
							Stack = v3.count,
							ExtraInfo = {
								Level = v6,
								Mutation = v10,
								Scanned = Scanned,
								Untradable = v7,
								Paid = v8
							}
						}
					end
				end
			end

			return v1
		end,
		securePlaceFish = function(p1, p2, p3, p4, p5, p6, p7, p8) --[[ securePlaceFish | Line: 2161 | Upvalues: buildInventoryKey (ref), getAvilibleBaseSlotsNames (ref) ]]
			local v1 = p4 or 1
			local v2 = table.clone(p1)

			v2.baseSlots = table.clone(v2.baseSlots)

			if p6 == false then
				return v2
			end

			if not v2.inventory[buildInventoryKey(p2, v1, p5, p6, p7, p8)] then
				return v2
			end

			if v2.baseSlots[p3] then
				return v2
			end

			if not table.find(getAvilibleBaseSlotsNames(v2.tycoonLevel), p3) then
				return v2
			end

			local t = {
				Earnings = 0,
				FishPlaced = p2,
				Level = v1,
				Mutation = p5,
				Scanned = p6
			}

			t.Untradable = if p7 == true then true else nil
			t.Paid = if p8 == true then true else nil
			v2.baseSlots[p3] = t

			return v2
		end,
		secureRemoveFish = function(p1, p2) --[[ secureRemoveFish | Line: 2209 ]]
			local v1 = table.clone(p1)

			v1.baseSlots = table.clone(v1.baseSlots)

			if v1.baseSlots[p2] then
				v1.baseSlots[p2] = nil
			end

			return v1
		end,
		secureAddFishEarnings = function(p1, p2) --[[ secureAddFishEarnings | Line: 2222 ]]
			local v1 = table.clone(p1)

			v1.baseSlots = table.clone(v1.baseSlots)

			for v2, v3 in p2 do
				if v1.baseSlots[v2] then
					v1.baseSlots[v2].Earnings = v3
				end
			end

			return v1
		end,
		secureUpdateLastGameEnter = function(p1, p2) --[[ secureUpdateLastGameEnter | Line: 2235 ]]
			local v1 = table.clone(p1)

			v1.lastGameEnter = p2

			return v1
		end,
		sendFeedback = function(p1) --[[ sendFeedback | Line: 2242 ]]
			local v1 = table.clone(p1)

			v1.hasSendFeedback = true

			return v1
		end,
		setTutorialInfo = function(p1, p2) --[[ setTutorialInfo | Line: 2249 ]]
			local v1 = table.clone(p1)

			v1.tutorialInfo = p2

			return v1
		end,
		consumeFreeRevive = function(p1) --[[ consumeFreeRevive | Line: 2257 ]]
			local v1 = table.clone(p1)

			v1.freeRevives = math.max((p1.freeRevives or 0) - 1, 0)

			return v1
		end,
		secureIncrementFishCaught = function(p1, p2, p3, p4) --[[ secureIncrementFishCaught | Line: 2263 ]]
			local v1 = table.clone(p1)
			local v2 = v1.stats or {
				fishCaught = 0,
				footballFishCaught = 0
			}

			v1.stats = table.clone(v2)
			v1.stats.fishCaught = (v2.fishCaught or 0) + 1

			if p2 then
				v1.stats.footballFishCaught = (v2.footballFishCaught or 0) + 1
			end

			if p3 then
				v1.stats.moonFishCaught = (v2.moonFishCaught or 0) + 1
			end

			if p4 then
				local v4 = table.clone(v2.rarityFishCaught or {})

				v4[p4] = (v4[p4] or 0) + 1
				v1.stats.rarityFishCaught = v4
			end

			return v1
		end,
		secureSetRarityCaught = function(p1, p2, p3) --[[ secureSetRarityCaught | Line: 2296 ]]
			local v1 = table.clone(p1)
			local v2 = v1.stats or {
				fishCaught = 0,
				footballFishCaught = 0
			}

			v1.stats = table.clone(v2)

			local v4 = table.clone(v2.rarityFishCaught or {})

			v4[p2] = math.max(0, (math.floor(p3)))
			v1.stats.rarityFishCaught = v4

			return v1
		end,
		secureBackfillRarityCaught = function(p1) --[[ secureBackfillRarityCaught | Line: 2322 | Upvalues: FishConfig (ref) ]]
			if p1.rarityCatchBackfilled then
				return p1
			end

			local t = {}

			local function credit(p1, p2) --[[ credit | Line: 2328 | Upvalues: FishConfig (ref), t (copy) ]]
				local v1 = if type(p1) == "string" then FishConfig[p1] else nil
				local v2 = if v1 then v1.Rarity and v1.Rarity.id else v1

				if type(v2) == "string" and not (p2 <= 0) then
					t[v2] = (t[v2] or 0) + p2
				end
			end

			for v2, v3 in p1.inventory or {} do
				if v3.Category == "Fish" then
					local ConfigName = v3.ConfigName
					local v6 = math.max(1, (math.floor(tonumber(v3.Stack) or 1)))
					local v7 = if type(ConfigName) == "string" then FishConfig[ConfigName] else nil
					local v8 = if v7 then v7.Rarity and v7.Rarity.id else v7

					if type(v8) == "string" and not (v6 <= 0) then
						t[v8] = (t[v8] or 0) + v6
					end
				end
			end

			for v10, v11 in p1.baseSlots or {} do
				local FishPlaced = v11.FishPlaced
				local v12 = if type(FishPlaced) == "string" then FishConfig[FishPlaced] else nil
				local v13 = if v12 then v12.Rarity and v12.Rarity.id else v12

				if type(v13) == "string" then
					t[v13] = (t[v13] or 0) + 1
				end
			end

			local v14 = p1.garden and p1.garden.items

			for v16, v17 in if v14 then v14 else {} do
				local Fish = v17.Fish

				if Fish then
					local ConfigName = Fish.ConfigName
					local v18 = if type(ConfigName) == "string" then FishConfig[ConfigName] else nil
					local v19 = if v18 then v18.Rarity and v18.Rarity.id else v18

					if type(v19) == "string" then
						t[v19] = (t[v19] or 0) + 1
					end
				end
			end

			local v20 = table.clone(p1)

			v20.rarityCatchBackfilled = true

			local v21 = v20.stats or {
				fishCaught = 0,
				footballFishCaught = 0
			}

			v20.stats = table.clone(v21)

			local v23 = table.clone(v21.rarityFishCaught or {})

			for v24, v25 in t do
				v23[v24] = math.max(v23[v24] or 0, v25)
			end

			v20.stats.rarityFishCaught = v23

			return v20
		end,
		secureUpgradeFish = function(p1, p2) --[[ secureUpgradeFish | Line: 2377 | Upvalues: FishConfig (ref) ]]
			local v1 = p1.baseSlots[p2]

			if not v1 then
				return p1
			end

			local v2 = v1.Level or 1

			if v2 >= 75 then
				return p1
			end

			local v3 = FishConfig[v1.FishPlaced]

			if not v3 then
				return p1
			end

			local v5 = math.floor(v3.Earnings * 1.5 ^ v2)

			if p1.money < v5 then
				return p1
			end

			local v6 = table.clone(p1)

			v6.money = v6.money - v5
			v6.baseSlots = table.clone(v6.baseSlots)

			local v7 = table.clone(v1)

			v7.Level = v2 + 1
			v6.baseSlots[p2] = v7

			return v6
		end,
		secureAddPlacedFishMutation = function(p1, p2, p3) --[[ secureAddPlacedFishMutation | Line: 2409 | Upvalues: MutationList (ref) ]]
			local v1 = p1.baseSlots[p2]

			if not v1 then
				return p1
			end

			local v2 = MutationList.parse(v1.Mutation)

			if table.find(v2, p3) then
				return p1
			end

			table.insert(v2, p3)

			local v3 = MutationList.format(v2)

			if v3 == MutationList.canonical(v1.Mutation) then
				return p1
			end

			local v4 = table.clone(p1)

			v4.baseSlots = table.clone(v4.baseSlots)

			local v5 = table.clone(v1)

			v5.Mutation = v3
			v4.baseSlots[p2] = v5

			return v4
		end,
		secureAddPlacedFishLevel = function(p1, p2, p3) --[[ secureAddPlacedFishLevel | Line: 2436 ]]
			local v1 = p1.baseSlots[p2]

			if not v1 then
				return p1
			end

			local v2 = v1.Level or 1

			if v2 >= 75 then
				return p1
			end

			local v3 = math.min(v2 + p3, 75)

			if v3 == v2 then
				return p1
			end

			local v4 = table.clone(p1)

			v4.baseSlots = table.clone(v4.baseSlots)

			local v5 = table.clone(v1)

			v5.Level = v3
			v4.baseSlots[p2] = v5

			return v4
		end,
		secureSetCoolDown = function(p1, p2, p3) --[[ secureSetCoolDown | Line: 2458 ]]
			local v1 = table.clone(p1)

			v1.adminCoolDowns = table.clone(v1.adminCoolDowns)
			v1.adminCoolDowns[p2] = p3

			return v1
		end,
		setVersion = function(p1, p2) --[[ setVersion | Line: 2470 ]]
			local v1 = table.clone(p1)

			v1.version = p2

			return v1
		end,
		secureUnlockFishingVillage = function(p1) --[[ secureUnlockFishingVillage | Line: 2480 | Upvalues: WorldsConfig (ref) ]]
			if p1.unlockedFishingVillage then
				return p1
			end

			local Unlock = WorldsConfig.FishingVillage.Unlock

			if WorldsConfig.GetUnlockProgress(p1, Unlock).MeetsAll then
				local v2 = table.clone(p1)

				v2.money = v2.money - (Unlock.CashCost or 0)
				v2.unlockedFishingVillage = true

				return v2
			end

			return p1
		end,
		secureLockFishingVillage = function(p1) --[[ secureLockFishingVillage | Line: 2500 ]]
			if p1.unlockedFishingVillage then
				local v1 = table.clone(p1)

				v1.unlockedFishingVillage = false

				return v1
			end

			return p1
		end,
		secureAddGems = function(p1, p2) --[[ secureAddGems | Line: 2509 ]]
			local v1 = table.clone(p1)

			v1.gems = math.max(0, v1.gems + p2)

			if p2 > 0 then
				v1.stats = table.clone(v1.stats)
				v1.stats.gemsEarned = (v1.stats.gemsEarned or 0) + p2
			end

			return v1
		end,
		secureChargeEnchantAttempt = function(p1, p2, p3) --[[ secureChargeEnchantAttempt | Line: 2528 | Upvalues: EnchantConfig (ref) ]]
			local v1 = EnchantConfig.Enchants[p2]

			if not v1 then
				return p1
			end

			local v2, v3 = EnchantConfig.GetAttemptCost(v1, p3)
			local StoneConfigName = EnchantConfig.StoneConfigName
			local v4 = p1.inventory[StoneConfigName]
			local v5 = v4 and v4.Stack or 0

			if p1.gems < v2 or v5 < v3 then
				return p1
			end

			local v6 = table.clone(p1)

			v6.gems = v6.gems - v2
			v6.inventory = table.clone(v6.inventory)

			local v7 = v5 - v3

			if v7 > 0 then
				local v8 = table.clone(v4)

				v8.Stack = v7
				v6.inventory[StoneConfigName] = v8
			else
				v6.inventory[StoneConfigName] = nil
			end

			return v6
		end,
		secureSetRodEnchant = function(p1, p2, p3, p4) --[[ secureSetRodEnchant | Line: 2567 ]]
			local v1 = table.clone(p1)

			v1.rodEnchants = table.clone(v1.rodEnchants or {})

			local v4 = table.clone(v1.rodEnchants[p2] or {})

			v4[p3] = if p4 > 0 then p4 else nil

			if next(v4) == nil then
				v1.rodEnchants[p2] = nil
			else
				v1.rodEnchants[p2] = v4
			end

			return v1
		end,
		secureApplyRodEnchant = function(p1, p2, p3, p4) --[[ secureApplyRodEnchant | Line: 2580 | Upvalues: EnchantConfig (ref) ]]
			if not EnchantConfig.Tiers[p4] then
				return p1
			end

			local v1 = p1.rodEnchants and p1.rodEnchants[p2]

			if v1 and p4 <= (v1[p3] or 0) then
				return p1
			end

			local v2 = table.clone(p1)

			v2.rodEnchants = table.clone(v2.rodEnchants or {})

			local v5 = table.clone(v2.rodEnchants[p2] or {})

			v5[p3] = p4
			v2.rodEnchants[p2] = v5

			return v2
		end,
		secureAddCatCoins = function(p1, p2) --[[ secureAddCatCoins | Line: 2598 ]]
			local v1 = table.clone(p1)

			v1.catCoins = math.max(0, v1.catCoins + p2)

			if p2 > 0 then
				v1.totalCatCoins = (v1.totalCatCoins or 0) + p2
			end

			return v1
		end,
		secureSetCatEventRewardClaimed = function(p1, p2) --[[ secureSetCatEventRewardClaimed | Line: 2608 ]]
			local v1 = table.clone(p1)

			v1.catEventRewardClaimed = p2

			return v1
		end,
		secureAddEventCoins = function(p1, p2, p3) --[[ secureAddEventCoins | Line: 2619 | Upvalues: withEventData (ref) ]]
			local v1, v2 = withEventData(p1, p2)

			v2.coins = math.max(0, v2.coins + p3)

			if not (p3 > 0) then
				return v1
			end

			v2.totalCoins = v2.totalCoins + p3

			return v1
		end,
		secureSetEventMachineFedCount = function(p1, p2, p3) --[[ secureSetEventMachineFedCount | Line: 2628 | Upvalues: withEventData (ref) ]]
			local v1, v2 = withEventData(p1, p2)

			v2.machineFedCount = p3

			return v1
		end,
		secureSetEventRewardPaid = function(p1, p2) --[[ secureSetEventRewardPaid | Line: 2637 ]]
			local v1 = p1.events and p1.events[p2]

			if v1 then
				local v2 = table.clone(p1)

				v2.events = table.clone(v2.events)

				local v3 = table.clone(v1)

				v3.rewardPaid = true
				v2.events[p2] = v3

				return v2
			end

			return p1
		end,
		secureClearEventData = function(p1, p2) --[[ secureClearEventData | Line: 2651 ]]
			if p1.events ~= nil and p1.events[p2] ~= nil then
				local v1 = table.clone(p1)

				v1.events = table.clone(v1.events)
				v1.events[p2] = nil

				return v1
			end

			return p1
		end,
		securePruneStaleEventData = function(p1) --[[ securePruneStaleEventData | Line: 2666 | Upvalues: EventConfig (ref), LiveEventRegistry (ref) ]]
			local events = p1.events

			if events == nil then
				return p1
			end

			local function isProtected(p1) --[[ isProtected | Line: 2671 | Upvalues: EventConfig (ref), LiveEventRegistry (ref) ]]
				return if p1 == EventConfig.Event.Id then true else LiveEventRegistry.Events[p1] ~= nil
			end

			local v1 = false

			for v2 in events do
				if not (if v2 == EventConfig.Event.Id then true else LiveEventRegistry.Events[v2] ~= nil) then
					v1 = true

					break
				end
			end

			if not v1 then
				return p1
			end

			local v4 = table.clone(p1)
			local t = {}

			for v5, v6 in events do
				if if v5 == EventConfig.Event.Id then true elseif LiveEventRegistry.Events[v5] == nil then false else true then
					t[v5] = v6
				end
			end

			v4.events = t

			return v4
		end,
		secureSetReferredBy = function(p1, p2, p3) --[[ secureSetReferredBy | Line: 2700 ]]
			if p1.referredBy ~= 0 then
				return p1
			end

			if type(p2) == "number" and (not (p2 <= 0) and p2 % 1 == 0) then
				local v1 = table.clone(p1)

				v1.referredBy = p2
				v1.referredAt = p3

				return v1
			end

			return p1
		end,
		secureCreditEventReferral = function(p1, p2, p3) --[[ secureCreditEventReferral | Line: 2717 | Upvalues: withEventData (ref) ]]
			local v1, v2 = withEventData(p1, p2)

			v2.referralCount = (v2.referralCount or 0) + 1

			if v2.referralDay == p3 then
				v2.referralDayCount = (v2.referralDayCount or 0) + 1
			else
				v2.referralDay = p3
				v2.referralDayCount = 1
			end

			return v1
		end,
		secureAddAlienFuel = function(p1, p2, p3, p4) --[[ secureAddAlienFuel | Line: 2739 | Upvalues: withEventData (ref) ]]
			local v1, v2 = withEventData(p1, p2)

			v2.fuel = math.clamp(v2.fuel + p3, 0, (math.max(p4, 0)))

			return v1
		end,
		secureMarkAlienRefuelled = function(p1, p2) --[[ secureMarkAlienRefuelled | Line: 2747 | Upvalues: withEventData (ref) ]]
			local v1, v2 = withEventData(p1, p2)

			v2.refueledShipAtLeastOnce = true

			return v1
		end,
		secureMarkAlienFlown = function(p1, p2) --[[ secureMarkAlienFlown | Line: 2756 | Upvalues: withEventData (ref) ]]
			local v1, v2 = withEventData(p1, p2)

			v2.flewShipAtLeastOnce = true

			return v1
		end,
		secureStartAlienResearch = function(p1, p2, p3, p4, p5, p6, p7, p8, p9) --[[ secureStartAlienResearch | Line: 2766 | Upvalues: AlienEventConfig (ref), withEventData (ref) ]]
			local v1 = tonumber(p3)

			if not v1 or (v1 ~= math.floor(v1) or (v1 < 1 or AlienEventConfig.Laboratory.CapsuleCount < v1)) then
				return p1
			end

			local v2 = p1.events and p1.events[p2]

			if v2 and (v2.research and v2.research[p3]) then
				return p1
			end

			local v3, v4 = withEventData(p1, p2)
			local v6 = table.clone(v4.research or {})
			local t = {
				kind = p4,
				level = p5,
				mutation = p6
			}

			t.untradable = if p7 == true then true else nil
			t.paid = if p8 == true then true else nil
			t.startedAt = p9
			v6[p3] = t
			v4.research = v6

			return v3
		end,
		secureClearAlienResearch = function(p1, p2, p3) --[[ secureClearAlienResearch | Line: 2801 | Upvalues: withEventData (ref) ]]
			local v1 = p1.events and p1.events[p2]

			if v1 and (v1.research and v1.research[p3]) then
				local v2, v3 = withEventData(p1, p2)
				local v5 = table.clone(v3.research or {})

				v5[p3] = nil
				v3.research = v5

				return v2
			end

			return p1
		end,
		secureSetAlienUpgradeStage = function(p1, p2, p3, p4) --[[ secureSetAlienUpgradeStage | Line: 2816 | Upvalues: AlienEventConfig (ref), withEventData (ref) ]]
			local v1 = AlienEventConfig.GetMaxStage(p3)

			if v1 == 0 then
				return p1
			end

			local v2, v3 = withEventData(p1, p2)

			v3.upgrades = table.clone(v3.upgrades)
			v3.upgrades[p3] = math.clamp(math.floor(p4), 0, v1)

			return v2
		end,
		secureStartAlienFlight = function(p1, p2, p3, p4) --[[ secureStartAlienFlight | Line: 2835 | Upvalues: withEventData (ref) ]]
			local v1 = p1.events and p1.events[p2]

			if v1 and v1.flight then
				return p1
			end

			local v2, v3 = withEventData(p1, p2)
			local v4 = math.clamp(p4, 0, v3.fuel)

			if v4 <= 0 then
				return p1
			end

			v3.fuel = v3.fuel - v4
			v3.flight = {
				startedAt = p3,
				fuelAtStart = v4,
				lastSeenAt = p3
			}

			return v2
		end,
		secureTouchAlienFlight = function(p1, p2, p3) --[[ secureTouchAlienFlight | Line: 2860 | Upvalues: withEventData (ref) ]]
			local v1 = p1.events and p1.events[p2]
			local v2 = if v1 then v1.flight else v1

			if v2 and not (p3 <= (v2.lastSeenAt or v2.startedAt)) then
				local v4, v5 = withEventData(p1, p2)

				v5.flight = {
					startedAt = v2.startedAt,
					fuelAtStart = v2.fuelAtStart,
					lastSeenAt = p3
				}

				return v4
			end

			return p1
		end,
		secureCreditAlienFlightTime = function(p1, p2, p3, p4) --[[ secureCreditAlienFlightTime | Line: 2882 | Upvalues: withEventData (ref) ]]
			local v1 = p1.events and p1.events[p2]
			local v2 = if v1 then v1.flight else v1

			if not v2 then
				return p1
			end

			local v4 = math.clamp(p3, 0, (math.max(p4, 0)))

			if v4 <= 0 then
				return p1
			end

			local v5, v6 = withEventData(p1, p2)

			v6.flight = {
				startedAt = v2.startedAt + v4,
				fuelAtStart = v2.fuelAtStart,
				lastSeenAt = v2.lastSeenAt
			}

			return v5
		end,
		secureEndAlienFlight = function(p1, p2, p3, p4) --[[ secureEndAlienFlight | Line: 2909 | Upvalues: withEventData (ref) ]]
			local v1 = p1.events and p1.events[p2]

			if v1 and v1.flight then
				local v2, v3 = withEventData(p1, p2)

				v3.flight = nil

				local v4 = v3.fuel + math.max(p3, 0)

				v3.fuel = math.clamp(v4, 0, (math.max(p4, 0)))

				return v2
			end

			return p1
		end,
		secureAddAlienCargo = function(p1, p2, p3, p4) --[[ secureAddAlienCargo | Line: 2923 | Upvalues: withEventData (ref) ]]
			local v1 = p1.events and p1.events[p2]
			local v2 = v1 and v1.cargo or {}

			if #v2 >= math.max(p4, 0) then
				return p1
			end

			local v3, v4 = withEventData(p1, p2)
			local v5 = table.clone(v2)

			table.insert(v5, p3)
			v4.cargo = v5

			return v3
		end,
		secureClearAlienCargo = function(p1, p2) --[[ secureClearAlienCargo | Line: 2938 | Upvalues: withEventData (ref) ]]
			local v1 = p1.events and p1.events[p2]

			if v1 and (v1.cargo and #v1.cargo ~= 0) then
				local v2, v3 = withEventData(p1, p2)

				v3.cargo = {}

				return v2
			end

			return p1
		end,
		secureAddDeepsGear = function(p1, p2, p3) --[[ secureAddDeepsGear | Line: 2953 | Upvalues: t2 (ref), withDeepsGear (ref) ]]
			if t2[p2] and p3 ~= "" then
				local v1, v2 = withDeepsGear(p1)

				v2.owned[p3] = true
				v2[p2] = p3

				return v1
			end

			return p1
		end,
		secureEquipDeepsGear = function(p1, p2, p3) --[[ secureEquipDeepsGear | Line: 2965 | Upvalues: t2 (ref), withDeepsGear (ref) ]]
			if not t2[p2] then
				return p1
			end

			local deepsGear = p1.deepsGear

			if p3 ~= "" and not (deepsGear and (deepsGear.owned and deepsGear.owned[p3])) then
				return p1
			end

			local v1, v2 = withDeepsGear(p1)

			v2[p2] = p3

			return v1
		end,
		secureAddDeepsBag = function(p1, p2, p3, p4) --[[ secureAddDeepsBag | Line: 2983 | Upvalues: withDeeps (ref) ]]
			if p2 ~= "Fish" and p2 ~= "Item" then
				return p1
			end

			local v1 = p1.deeps and p1.deeps.bag or {}

			if #v1 >= math.max(p4, 0) then
				return p1
			end

			local v2, v3 = withDeeps(p1)
			local v4 = table.clone(v1)

			table.insert(v4, {
				Type = p2,
				Name = p3
			})
			v3.bag = v4

			return v2
		end,
		secureClearDeepsBag = function(p1) --[[ secureClearDeepsBag | Line: 3000 | Upvalues: withDeeps (ref) ]]
			local deeps = p1.deeps

			if deeps and (deeps.bag and #deeps.bag ~= 0) then
				local v1, v2 = withDeeps(p1)

				v2.bag = {}

				return v1
			end

			return p1
		end,
		secureFailDeepsBag = function(p1) --[[ secureFailDeepsBag | Line: 3014 | Upvalues: withDeeps (ref) ]]
			local deeps = p1.deeps

			if not deeps or (not deeps.bag or #deeps.bag == 0) then
				return p1
			end

			local v1, v2 = withDeeps(p1)
			local v4 = table.clone(v2.pendingRecovery or {})

			for v5, v6 in v2.bag do
				table.insert(v4, v6)
			end

			v2.pendingRecovery = v4
			v2.bag = {}

			return v1
		end,
		secureClearDeepsRecovery = function(p1) --[[ secureClearDeepsRecovery | Line: 3031 | Upvalues: withDeeps (ref) ]]
			local deeps = p1.deeps

			if deeps and deeps.pendingRecovery then
				local v1, v2 = withDeeps(p1)

				v2.pendingRecovery = nil

				return v1
			end

			return p1
		end,
		secureClearDeepsProcessing = function(p1) --[[ secureClearDeepsProcessing | Line: 3044 | Upvalues: withDeeps (ref) ]]
			local deeps = p1.deeps

			if deeps and (deeps.processingEndsAt or deeps.processingItem) then
				local v1, v2 = withDeeps(p1)

				v2.processingStones = nil
				v2.processingEndsAt = nil
				v2.processingItem = nil

				return v1
			end

			return p1
		end,
		secureResetQuests = function(p1, p2, p3) --[[ secureResetQuests | Line: 3068 ]]
			local quests = p1.quests
			local v1 = table.clone(p1)
			local t = {
				Completed = 0,
				Active = p2,
				LastReset = p3
			}

			t.TrackProgress = quests and quests.TrackProgress or 0
			t.Milestones = quests and quests.Milestones or 0
			v1.quests = t

			return v1
		end,
		secureAdvanceQuest = function(p1, p2, p3) --[[ secureAdvanceQuest | Line: 3084 | Upvalues: QuestConfig (ref) ]]
			local quests = p1.quests

			if not quests then
				return p1
			end

			local v1 = QuestConfig.QuestById[p2]

			if not v1 then
				return p1
			end

			local v2 = table.clone(quests.Active)

			for v3, v4 in v2 do
				if v4.Id == p2 then
					if v4.Claimed then
						break
					end

					local v6 = math.min(math.max(p3, v4.Progress), v1.Goal)
					local v7 = if v1.Goal <= v6 then true else false

					if v6 == v4.Progress and v7 == v4.Done then
						break
					end

					v2[v3] = {
						Claimed = false,
						Id = v4.Id,
						Progress = v6,
						Done = v7
					}

					local v8 = table.clone(p1)

					v8.quests = table.clone(quests)
					v8.quests.Active = v2

					return v8
				end
			end

			return p1
		end,
		secureClaimQuest = function(p1, p2) --[[ secureClaimQuest | Line: 3123 | Upvalues: QuestConfig (ref) ]]
			local quests = p1.quests

			if not quests then
				return p1
			end

			local v1 = QuestConfig.QuestById[p2]

			if not v1 then
				return p1
			end

			local v2 = table.clone(quests.Active)

			for v3, v4 in v2 do
				if v4.Id == p2 then
					if v4.Claimed or not (v4.Done or v4.Progress >= v1.Goal) then
						break
					end

					v2[v3] = {
						Done = true,
						Claimed = true,
						Id = v4.Id,
						Progress = v4.Progress
					}

					local v5 = table.clone(p1)

					v5.quests = table.clone(quests)
					v5.quests.Active = v2
					v5.quests.Completed = (quests.Completed or 0) + 1
					v5.quests.TrackProgress = (quests.TrackProgress or 0) + 1
					v5.stats = table.clone(v5.stats or {})
					v5.stats.dailyQuestsCompleted = (v5.stats.dailyQuestsCompleted or 0) + 1

					return v5
				end
			end

			return p1
		end,
		secureAwardQuestMilestones = function(p1, p2) --[[ secureAwardQuestMilestones | Line: 3156 ]]
			local quests = p1.quests

			if quests and not (p2 <= (quests.Milestones or 0)) then
				local v1 = table.clone(p1)

				v1.quests = table.clone(quests)
				v1.quests.Milestones = p2

				return v1
			end

			return p1
		end,
		secureResetQuestTrack = function(p1) --[[ secureResetQuestTrack | Line: 3170 ]]
			local quests = p1.quests

			if not quests then
				return p1
			end

			if (quests.TrackProgress or 0) == 0 and (quests.Milestones or 0) == 0 then
				return p1
			end

			local v1 = table.clone(p1)

			v1.quests = table.clone(quests)
			v1.quests.TrackProgress = 0
			v1.quests.Milestones = 0

			return v1
		end,
		secureFallbackQuestTrack = function(p1) --[[ secureFallbackQuestTrack | Line: 3191 | Upvalues: QuestConfig (ref) ]]
			local quests = p1.quests

			if not quests then
				return p1
			end

			local v1 = quests.TrackProgress or 0
			local v2 = 0

			for v3, v4 in QuestConfig.Milestones do
				if v4.Goal <= v1 then
					v2 = v4.Goal
				end
			end

			if v1 <= v2 then
				return p1
			end

			local v5 = table.clone(p1)

			v5.quests = table.clone(quests)
			v5.quests.TrackProgress = v2

			return v5
		end,
		securePurchaseDailyReward = function(p1, p2) --[[ securePurchaseDailyReward | Line: 3212 | Upvalues: DailyQuestConfig (ref) ]]
			local v1 = DailyQuestConfig.RewardById[p2]

			if not v1 then
				return p1
			end

			if p1.gems < v1.Cost then
				return p1
			end

			if v1.Type == "Permanent" and p1.claimedDailyRewards[p2] then
				return p1
			end

			local v2 = table.clone(p1)

			v2.gems = v2.gems - v1.Cost

			if v1.Type == "Permanent" then
				v2.claimedDailyRewards = table.clone(v2.claimedDailyRewards)
				v2.claimedDailyRewards[p2] = true
			end

			return v2
		end,
		secureClaimIndexReward = function(p1, p2) --[[ secureClaimIndexReward | Line: 3232 | Upvalues: IndexRewardConfig (ref) ]]
			if not p1.index[p2] then
				return p1
			end

			if p1.claimedIndexRewards[p2] then
				return p1
			end

			local v1 = IndexRewardConfig.getRewardForFish(p2)

			if v1 <= 0 then
				return p1
			end

			local v2 = table.clone(p1)

			v2.gems = v2.gems + v1
			v2.stats = table.clone(v2.stats)
			v2.stats.gemsEarned = (v2.stats.gemsEarned or 0) + v1
			v2.claimedIndexRewards = table.clone(v2.claimedIndexRewards)
			v2.claimedIndexRewards[p2] = true

			return v2
		end,
		secureClaimIndexMilestone = function(p1, p2) --[[ secureClaimIndexMilestone | Line: 3254 | Upvalues: IndexMilestoneConfig (ref) ]]
			local v1 = IndexMilestoneConfig.getById(p2)

			if not v1 then
				return p1
			end

			local v2 = p1.claimedIndexMilestones or {}

			if v2[p2] then
				return p1
			end

			if not IndexMilestoneConfig.isReached(p1.index, v1) then
				return p1
			end

			local v3 = table.clone(p1)
			local reward = v1.reward

			if reward.type == "gems" then
				v3.gems = v3.gems + (reward.amount or 0)
				v3.stats = table.clone(v3.stats)
				v3.stats.gemsEarned = (v3.stats.gemsEarned or 0) + (reward.amount or 0)
			elseif reward.type == "baseSkin" and reward.skinName then
				local v4 = p1.unlockedBaseSkins or {}

				if not v4[reward.skinName] then
					v3.unlockedBaseSkins = table.clone(v4)
					v3.unlockedBaseSkins[reward.skinName] = true
				end
			end

			v3.claimedIndexMilestones = table.clone(v2)
			v3.claimedIndexMilestones[p2] = true

			return v3
		end,
		secureDebugRevealIndexFish = function(p1, p2) --[[ secureDebugRevealIndexFish | Line: 3286 | Upvalues: FishConfig (ref) ]]
			local v1 = table.clone(p1)
			local v2 = table.clone(p1.index)

			for v3, v4 in p2 do
				if FishConfig[v4] then
					v2[v4] = true
				end
			end

			v1.index = v2

			return v1
		end,
		secureDiscoverFish = function(p1, p2) --[[ secureDiscoverFish | Line: 3298 ]]
			local v1 = table.clone(p1)

			if not v1.index[p2] then
				v1.index = table.clone(v1.index)
				v1.index[p2] = true
			end

			return v1
		end,
		secureSetTotalPlayTime = function(p1, p2) --[[ secureSetTotalPlayTime | Line: 3307 ]]
			local v1 = table.clone(p1)

			v1.totalPlayTime = p2

			return v1
		end,
		secureUnlockBaseSkin = function(p1, p2) --[[ secureUnlockBaseSkin | Line: 3313 ]]
			if p1.unlockedBaseSkins[p2] then
				return p1
			end

			local v1 = table.clone(p1)

			v1.unlockedBaseSkins = table.clone(v1.unlockedBaseSkins)
			v1.unlockedBaseSkins[p2] = true

			return v1
		end,
		secureEquipBaseSkin = function(p1, p2) --[[ secureEquipBaseSkin | Line: 3323 ]]
			local v1 = table.clone(p1)

			v1.equippedBaseSkin = p2

			return v1
		end,
		secureSetLastMount = function(p1, p2) --[[ secureSetLastMount | Line: 3329 ]]
			if p1.lastMountId == p2 then
				return p1
			end

			local v1 = table.clone(p1)

			v1.lastMountId = p2

			return v1
		end,
		secureActivatePotion = function(p1, p2, p3, p4, p5) --[[ secureActivatePotion | Line: 3339 ]]
			local v1 = table.clone(p1)

			v1.activePotions = table.clone(v1.activePotions)
			v1.activePotions[p2] = {
				ConfigName = p3,
				RemainingSeconds = p4,
				ActivatedAt = p5
			}

			return v1
		end,
		secureDeactivatePotion = function(p1, p2) --[[ secureDeactivatePotion | Line: 3357 ]]
			if p1.activePotions[p2] then
				local v1 = table.clone(p1)

				v1.activePotions = table.clone(v1.activePotions)
				v1.activePotions[p2] = nil

				return v1
			end

			return p1
		end,
		secureSetActivePotions = function(p1, p2) --[[ secureSetActivePotions | Line: 3368 ]]
			local v1 = table.clone(p1)

			v1.activePotions = p2

			return v1
		end,
		secureClaimDailyLogin = function(p1, p2, p3) --[[ secureClaimDailyLogin | Line: 3375 ]]
			local v1 = table.clone(p1)

			v1.dailyLoginDay = if p2 >= 7 then 1 else p2 + 1
			v1.dailyLoginLastClaim = p3

			return v1
		end,
		secureSetAutoCollect = function(p1, p2) --[[ secureSetAutoCollect | Line: 3383 ]]
			local v1 = table.clone(p1)

			v1.hasAutoCollect = p2

			return v1
		end,
		secureSetAutoSell = function(p1, p2) --[[ secureSetAutoSell | Line: 3389 ]]
			local v1 = table.clone(p1)

			v1.hasAutoSell = p2

			return v1
		end,
		secureBuyEquipBest = function(p1) --[[ secureBuyEquipBest | Line: 3398 | Upvalues: EquipBestConfig (ref) ]]
			if p1.hasEquipBest then
				return p1
			end

			if p1.money < EquipBestConfig.Cost then
				return p1
			end

			local v1 = table.clone(p1)

			v1.money = v1.money - EquipBestConfig.Cost
			v1.hasEquipBest = true

			return v1
		end,
		secureSetCurrentWorld = function(p1, p2) --[[ secureSetCurrentWorld | Line: 3415 ]]
			local v1 = table.clone(p1)

			v1.currentWorldId = p2

			return v1
		end,
		secureUnlockWorld = function(p1, p2) --[[ secureUnlockWorld | Line: 3424 | Upvalues: WorldsConfig (ref) ]]
			local v1 = WorldsConfig.Get(p2)

			if not v1 then
				return p1
			end

			local v2 = p1.unlockedWorlds or {}

			if table.find(v2, p2) then
				return p1
			end

			if not WorldsConfig.GetUnlockProgress(p1, v1.Unlock).MeetsAll then
				return p1
			end

			local v3 = if v1.Unlock then v1.Unlock.CashCost or 0 else 0
			local v4 = table.clone(p1)

			v4.money = v4.money - v3
			v4.unlockedWorlds = table.clone(v2)
			table.insert(v4.unlockedWorlds, p2)

			return v4
		end,
		secureLockWorld = function(p1, p2) --[[ secureLockWorld | Line: 3454 | Upvalues: WorldsConfig (ref) ]]
			local v1 = p1.unlockedWorlds or {}
			local v2 = table.find(v1, p2)

			if not v2 then
				return p1
			end

			local v3 = table.clone(p1)

			v3.unlockedWorlds = table.clone(v1)
			table.remove(v3.unlockedWorlds, v2)

			if v3.currentWorldId == p2 then
				v3.currentWorldId = WorldsConfig.DefaultWorldId
			end

			return v3
		end,
		securePlaceLootbox = function(p1, p2, p3, p4, p5, p6, p7, p8) --[[ securePlaceLootbox | Line: 3470 ]]
			local v1 = table.clone(p1)

			v1.placedLootboxes = table.clone(v1.placedLootboxes)
			v1.placedLootboxes[p2] = {
				Relative = true,
				ConfigName = p3,
				PlacedAt = p4,
				OpenTime = p5,
				PosX = p6,
				PosY = p7,
				PosZ = p8
			}

			return v1
		end,
		secureRemovePlacedLootbox = function(p1, p2) --[[ secureRemovePlacedLootbox | Line: 3495 ]]
			if p1.placedLootboxes[p2] then
				local v1 = table.clone(p1)

				v1.placedLootboxes = table.clone(v1.placedLootboxes)
				v1.placedLootboxes[p2] = nil

				return v1
			end

			return p1
		end,
		secureGrantGardenForRebirth = function(p1) --[[ secureGrantGardenForRebirth | Line: 3512 | Upvalues: GardenConfig (ref), withGarden (ref) ]]
			if (p1.rebirthLevel or 0) < GardenConfig.Unlock.RebirthLevel then
				return p1
			end

			local garden = p1.garden

			if garden and garden.bought then
				return p1
			end

			local v1, v2 = withGarden(p1)

			v2.bought = true

			return v1
		end,
		secureUpgradeGardenSection = function(p1, p2) --[[ secureUpgradeGardenSection | Line: 3516 | Upvalues: GardenConfig (ref), withGarden (ref) ]]
			local v1 = GardenConfig.GetSection(p2)

			if not v1 then
				return p1
			end

			local garden = p1.garden

			if not (garden and garden.bought) then
				return p1
			end

			if (garden.upgrades or {})[p2] then
				return p1
			end

			if p1.money < v1.Cost then
				return p1
			end

			local v3, v4 = withGarden(p1)

			v3.money = v3.money - v1.Cost
			v4.upgrades[p2] = true

			return v3
		end,
		secureSetGardenBought = function(p1, p2) --[[ secureSetGardenBought | Line: 3537 | Upvalues: withGarden (ref) ]]
			local garden = p1.garden

			if garden and garden.bought == p2 then
				return p1
			end

			local v1, v2 = withGarden(p1)

			v2.bought = p2

			if p2 then
				return v1
			end

			v2.upgrades = {}
			v2.items = {}

			return v1
		end,
		securePlaceGardenItem = function(p1, p2, p3, p4, p5, p6, p7, p8) --[[ securePlaceGardenItem | Line: 3551 | Upvalues: GardenConfig (ref), VaultConfig (ref), gardenGrid (ref), buildInventoryKey (ref), tradeLockCount (ref), withGarden (ref), clampFavorite (ref), clampTradeLock (ref), clampPaidCopies (ref), DecorationConfig (ref) ]]
			local garden = p1.garden

			if not (garden or p8) then
				return p1
			end

			if garden and not (garden.bought or p8) then
				return p1
			end

			local v1 = garden and garden.items or {}

			if v1[p2] then
				return p1
			end

			local count = 0

			for v2 in v1 do
				count = count + 1
			end

			if GardenConfig.GetMaxPlacedItems(garden) <= count then
				return p1
			end

			if VaultConfig.isVault(p3) and VaultConfig.countPlaced(garden) >= VaultConfig.MaxPlaced then
				return p1
			end

			if not gardenGrid.canPlace(garden, p3, p4, p5, p6, p8) then
				return p1
			end

			local v3 = buildInventoryKey(p3)
			local v4 = p1.inventory[v3]

			if not v4 or (v4.Stack or 0) < 1 then
				return p1
			end

			local v5 = if (v4.Stack or 0) - tradeLockCount(p1.tradeLocks, v3) < 1 then true else false
			local v6, v7 = withGarden(p1)

			v6.inventory = table.clone(v6.inventory)

			local v8 = v4.Stack - 1

			if v8 <= 0 then
				v6.inventory[v3] = nil
			else
				local v9 = table.clone(v4)

				v9.Stack = v8
				v6.inventory[v3] = v9
			end

			clampFavorite(v6, v3)
			clampTradeLock(v6, v3)
			clampPaidCopies(v6, v3)

			local t = {
				ConfigName = p3,
				CellX = p4,
				CellZ = p5,
				Rot = p6 % 4
			}

			if v5 then
				t.TradeLocked = true
			end

			local v10 = DecorationConfig[p3]

			if v10 and v10.ProduceSeconds then
				t.ProduceStartedAt = p7
			end

			v7.items[p2] = t

			return v6
		end,
		secureRemoveGardenItem = function(p1, p2) --[[ secureRemoveGardenItem | Line: 3636 | Upvalues: DecorationConfig (ref), withGarden (ref), buildInventoryKey (ref), lockOneInState (ref), refundDisplayFish (ref) ]]
			local garden = p1.garden

			if not (garden and (garden.items and garden.items[p2])) then
				return p1
			end

			local v1 = garden.items[p2]
			local v2 = DecorationConfig[v1.ConfigName]
			local v3, v4 = withGarden(p1)

			v4.items[p2] = nil

			if v2 then
				local v5 = buildInventoryKey(v1.ConfigName)

				v3.inventory = table.clone(v3.inventory)

				local v6 = v3.inventory[v5]

				if v6 then
					local v7 = table.clone(v6)

					v7.Stack = (v6.Stack or 0) + 1
					v3.inventory[v5] = v7
				else
					v3.inventory[v5] = {
						Stack = 1,
						Category = v2.Category,
						ConfigName = v2.ConfigName
					}
				end

				if v1.TradeLocked then
					lockOneInState(v3, v5)
				end
			end

			if v1.Fish then
				refundDisplayFish(v3, v1.Fish)
			end

			return v3
		end,
		secureSetGardenDisplayFish = function(p1, p2, p3, p4, p5, p6, p7, p8) --[[ secureSetGardenDisplayFish | Line: 3672 | Upvalues: DecorationConfig (ref), FishConfig (ref), buildInventoryKey (ref), withGarden (ref), clampFavorite (ref), clampTradeLock (ref) ]]
			local garden = p1.garden
			local v1 = if garden then garden.items and garden.items[p2] else garden

			if not v1 or v1.Fish then
				return p1
			end

			local v2 = DecorationConfig[v1.ConfigName]

			if not v2 or v2.Functional ~= "FishDisplay" then
				return p1
			end

			if not FishConfig[p3] then
				return p1
			end

			local v3 = buildInventoryKey(p3, p4, p5, p6, p7, p8)
			local v4 = p1.inventory[v3]

			if not v4 or (v4.Stack or 0) < 1 then
				return p1
			end

			local v5, v6 = withGarden(p1)

			v5.inventory = table.clone(v5.inventory)

			local v7 = v4.Stack - 1

			if v7 <= 0 then
				v5.inventory[v3] = nil
			else
				local v8 = table.clone(v4)

				v8.Stack = v7
				v5.inventory[v3] = v8
			end

			clampFavorite(v5, v3)
			clampTradeLock(v5, v3)

			local v9 = table.clone(v1)
			local t = {
				ConfigName = p3,
				Level = p4,
				Mutation = p5,
				Scanned = p6
			}

			t.Untradable = if p7 == true then true else nil
			t.Paid = if p8 == true then true else nil
			v9.Fish = t
			v6.items[p2] = v9

			return v5
		end,
		secureRestartGardenProduction = function(p1, p2, p3) --[[ secureRestartGardenProduction | Line: 3727 | Upvalues: DecorationConfig (ref), withGarden (ref) ]]
			local garden = p1.garden
			local v1 = if garden then garden.items and garden.items[p2] else garden

			if not v1 then
				return p1
			end

			local v2 = DecorationConfig[v1.ConfigName]

			if v2 and v2.ProduceSeconds then
				local v3, v4 = withGarden(p1)
				local v5 = table.clone(v1)

				v5.ProduceStartedAt = p3
				v4.items[p2] = v5

				return v3
			end

			return p1
		end,
		secureStartAlchemyProcess = function(p1, p2, p3, p4, p5, p6, p7, p8, p9, p10) --[[ secureStartAlchemyProcess | Line: 3748 | Upvalues: DecorationConfig (ref), FishConfig (ref), buildInventoryKey (ref), favoriteCount (ref), withGarden (ref), clampFavorite (ref), clampTradeLock (ref) ]]
			local garden = p1.garden
			local v1 = if garden then garden.items and garden.items[p2] else garden

			if not v1 or v1.AlchemyStartedAt then
				return p1
			end

			local v2 = DecorationConfig[v1.ConfigName]

			if not v2 or v2.Functional ~= "AlchemyTable" then
				return p1
			end

			if not FishConfig[p3] then
				return p1
			end

			local v3 = buildInventoryKey(p3, p4, p5, p6, p7, p8)
			local v4 = p1.inventory[v3]

			if not v4 or (v4.Stack or 0) < 1 then
				return p1
			end

			if (v4.Stack or 1) - favoriteCount(p1.favorites, v3) <= 0 then
				return p1
			end

			local v5, v6 = withGarden(p1)

			v5.inventory = table.clone(v5.inventory)

			local v7 = v4.Stack - 1

			if v7 <= 0 then
				v5.inventory[v3] = nil
			else
				local v8 = table.clone(v4)

				v8.Stack = v7
				v5.inventory[v3] = v8
			end

			clampFavorite(v5, v3)
			clampTradeLock(v5, v3)

			local v9 = table.clone(v1)

			v9.AlchemyStartedAt = p10
			v9.AlchemyRewardConfigName = p9
			v6.items[p2] = v9

			return v5
		end,
		secureClearAlchemyProcess = function(p1, p2) --[[ secureClearAlchemyProcess | Line: 3807 | Upvalues: withGarden (ref) ]]
			local garden = p1.garden
			local v1 = if garden then garden.items and garden.items[p2] else garden

			if v1 and v1.AlchemyStartedAt then
				local v2, v3 = withGarden(p1)
				local v4 = table.clone(v1)

				v4.AlchemyStartedAt = nil
				v4.AlchemyRewardConfigName = nil
				v3.items[p2] = v4

				return v2
			end

			return p1
		end,
		secureDepositVaultFish = function(p1, p2, p3) --[[ secureDepositVaultFish | Line: 3836 | Upvalues: FishConfig (ref), VaultConfig (ref), buildInventoryKey (ref), withVault (ref), favoriteCount (ref), clampFavorite (ref), clampTradeLock (ref) ]]
			if typeof(p2) ~= "string" or (typeof(p3) ~= "number" or p3 ~= p3) then
				return p1
			end

			local v1 = p1.inventory[p2]

			if not v1 or v1.Category ~= "Fish" then
				return p1
			end

			if not FishConfig[v1.ConfigName] then
				return p1
			end

			local v3 = math.floor(v1.Stack or 0)
			local v5 = math.min(math.floor(p3), v3)

			if v5 < 1 then
				return p1
			end

			local v7 = math.min(v5, VaultConfig.capacityFor(p1.garden) - VaultConfig.countStored(p1.vault))

			if v7 < 1 then
				return p1
			end

			local v8 = v1.ExtraInfo or {}
			local v9 = buildInventoryKey(v1.ConfigName, v8.Level, v8.Mutation, v8.Scanned, v8.Untradable, v8.Paid)

			if v9 ~= p2 then
				return p1
			end

			local v10, v11 = withVault(p1)

			v10.inventory = table.clone(v10.inventory)

			local v12 = v3 - v7

			if v12 <= 0 then
				v10.inventory[v9] = nil
			else
				local v13 = table.clone(v1)

				v13.Stack = v12
				v10.inventory[v9] = v13
			end

			local v15 = math.max(0, v7 - (v3 - favoriteCount(v10.favorites, v9)))

			clampFavorite(v10, v9)
			clampTradeLock(v10, v9)

			local v16 = v11.fish[v9]

			if v16 then
				local v17 = table.clone(v16)

				v17.Stack = math.floor(v16.Stack or 0) + v7

				local v19 = (v16.Favorited or 0) + v15

				v17.Favorited = if v19 > 0 then v19 else nil
				v11.fish[v9] = v17
			else
				local t = {
					ConfigName = v1.ConfigName,
					Stack = v7
				}

				t.Favorited = if v15 > 0 then v15 else nil

				local t2 = {
					Level = v8.Level,
					Mutation = v8.Mutation,
					Scanned = v8.Scanned
				}

				t2.Untradable = if v8.Untradable == true then true else nil
				t2.Paid = if v8.Paid == true then true else nil
				t.ExtraInfo = t2
				v11.fish[v9] = t
			end

			return v10
		end,
		secureWithdrawVaultFish = function(p1, p2, p3) --[[ secureWithdrawVaultFish | Line: 3931 | Upvalues: buildInventoryKey (ref), withVault (ref), favoriteCount (ref) ]]
			if typeof(p2) ~= "string" or (typeof(p3) ~= "number" or p3 ~= p3) then
				return p1
			end

			local v1 = p1.vault and (p1.vault.fish and p1.vault.fish[p2])

			if not v1 then
				return p1
			end

			local v3 = math.floor(v1.Stack or 0)
			local v5 = math.min(math.floor(p3), v3)

			if v5 < 1 then
				return p1
			end

			local v6 = v1.ExtraInfo or {}
			local v7 = buildInventoryKey(v1.ConfigName, v6.Level, v6.Mutation, v6.Scanned, v6.Untradable, v6.Paid)
			local v8, v9 = withVault(p1)
			local v10 = v3 - v5
			local v13 = math.max(0, (math.floor(v1.Favorited or 0)))
			local v14 = math.max(0, v5 - (v3 - v13))

			if v10 <= 0 then
				v9.fish[p2] = nil
			else
				local v15 = table.clone(v1)

				v15.Stack = v10

				local v16 = v13 - v14

				v15.Favorited = if v16 > 0 then v16 else nil
				v9.fish[p2] = v15
			end

			v8.inventory = table.clone(v8.inventory)

			local v18 = v8.inventory[v7]

			if v18 then
				local v19 = table.clone(v18)

				v19.Stack = (v18.Stack or 0) + v5
				v8.inventory[v7] = v19
			else
				local t = {
					Category = "Fish",
					ConfigName = v1.ConfigName,
					Stack = v5
				}
				local t2 = {
					Level = v6.Level,
					Mutation = v6.Mutation,
					Scanned = v6.Scanned
				}

				t2.Untradable = if v6.Untradable == true then true else nil
				t2.Paid = if v6.Paid == true then true else nil
				t.ExtraInfo = t2
				v8.inventory[v7] = t
			end

			if v14 > 0 then
				local clone = table.clone

				v8.favorites = clone(v8.favorites or {})
				v8.favorites[v7] = favoriteCount(v8.favorites, v7) + v14
			end

			if not v8.index[v1.ConfigName] then
				v8.index = table.clone(v8.index)
				v8.index[v1.ConfigName] = true
			end

			return v8
		end,
		secureClearGardenDisplayFish = function(p1, p2) --[[ secureClearGardenDisplayFish | Line: 4011 | Upvalues: withGarden (ref), refundDisplayFish (ref) ]]
			local garden = p1.garden
			local v1 = if garden then garden.items and garden.items[p2] else garden

			if v1 and v1.Fish then
				local v2, v3 = withGarden(p1)
				local v4 = table.clone(v1)

				v4.Fish = nil
				v3.items[p2] = v4
				refundDisplayFish(v2, v1.Fish)

				return v2
			end

			return p1
		end,
		secureBuyLootboxShopSlot = function(p1, p2, p3) --[[ secureBuyLootboxShopSlot | Line: 4026 ]]
			local v1 = table.clone(p1)

			if v1.lootboxShopWindow == p2 then
				v1.lootboxShopSoldSlots = table.clone(v1.lootboxShopSoldSlots)
				v1.lootboxShopSoldSlots[p3] = true
			else
				v1.lootboxShopWindow = p2
				v1.lootboxShopSoldSlots = {
					[p3] = true
				}
			end

			return v1
		end,
		secureSetLootboxShopItems = function(p1, p2, p3) --[[ secureSetLootboxShopItems | Line: 4040 ]]
			local v1 = table.clone(p1)

			v1.lootboxShopWindow = p2
			v1.lootboxShopForcedItems = p3
			v1.lootboxShopSoldSlots = {}

			return v1
		end,
		secureSaveLootboxShopItems = function(p1, p2, p3) --[[ secureSaveLootboxShopItems | Line: 4048 ]]
			local v1 = table.clone(p1)

			v1.lootboxShopWindow = p2
			v1.lootboxShopItems = p3

			if p1.lootboxShopWindow ~= p2 then
				v1.lootboxShopSoldSlots = {}
				v1.lootboxShopForcedItems = nil
			end

			return v1
		end,
		secureForceRestockShop = function(p1, p2, p3) --[[ secureForceRestockShop | Line: 4059 ]]
			local v1 = table.clone(p1)

			v1.lootboxShopWindow = p2
			v1.lootboxShopItems = p3
			v1.lootboxShopSoldSlots = {}
			v1.lootboxShopForcedItems = nil

			return v1
		end,
		secureSaveEventStoreStock = function(p1, p2, p3, p4) --[[ secureSaveEventStoreStock | Line: 4069 | Upvalues: withEventData (ref) ]]
			local v1, v2 = withEventData(p1, p2)

			v2.storeWindow = p3
			v2.storeStock = p4

			return v1
		end,
		secureBuyEventStoreStockItem = function(p1, p2, p3) --[[ secureBuyEventStoreStockItem | Line: 4084 | Upvalues: withEventData (ref) ]]
			local v1 = p1.events and p1.events[p2]
			local v2 = if v1 then v1.storeStock[p3] else v1

			if v2 and not (v2 <= 0) then
				local v3, v4 = withEventData(p1, p2)

				v4.storeStock = table.clone(v4.storeStock)
				v4.storeStock[p3] = v2 - 1

				return v3
			end

			return p1
		end,
		securePurchaseOneTimeEventItem = function(p1, p2, p3) --[[ securePurchaseOneTimeEventItem | Line: 4099 | Upvalues: withEventData (ref) ]]
			local v1 = p1.events and p1.events[p2]

			if v1 and v1.storePurchases[p3] then
				return p1
			end

			local v2, v3 = withEventData(p1, p2)

			v3.storePurchases = table.clone(v3.storePurchases)
			v3.storePurchases[p3] = true

			return v2
		end,
		secureSaveDecorationsStoreStock = function(p1, p2, p3) --[[ secureSaveDecorationsStoreStock | Line: 4113 ]]
			local v1 = table.clone(p1)

			v1.decorationsStoreWindow = p2
			v1.decorationsStoreStock = p3

			return v1
		end,
		secureBuyDecorationsStoreItem = function(p1, p2, p3) --[[ secureBuyDecorationsStoreItem | Line: 4128 ]]
			if p1.decorationsStoreWindow ~= p2 then
				return p1
			end

			local v1 = p1.decorationsStoreStock[p3]

			if v1 and not (v1 <= 0) then
				local v2 = table.clone(p1)

				v2.decorationsStoreStock = table.clone(v2.decorationsStoreStock)
				v2.decorationsStoreStock[p3] = v1 - 1

				return v2
			end

			return p1
		end,
		secureAddFloat = function(p1, p2, p3) --[[ secureAddFloat | Line: 4143 ]]
			local v1 = table.clone(p1)

			v1.fishingFloats = table.clone(v1.fishingFloats)

			local clone = table.clone

			v1.fishingFloats[p3] = clone(v1.fishingFloats[p3] or {})
			v1.fishingFloats[p3][p2] = (v1.fishingFloats[p3][p2] or 0) + 1

			return v1
		end,
		secureRecycleFloats = function(p1, p2, p3) --[[ secureRecycleFloats | Line: 4151 | Upvalues: FloatRecycleMachineConfig (ref) ]]
			if not FloatRecycleMachineConfig.isRecyclable(p2) then
				return p1
			end

			local v1 = p1.fishingFloats[p2]

			if not v1 then
				return p1
			end

			local sum = 0

			for v2, v3 in p3 do
				if typeof(v2) ~= "string" or typeof(v3) ~= "number" then
					return p1
				end

				if v3 <= 0 or v3 % 1 ~= 0 then
					return p1
				end

				if (v1[v2] or 0) < v3 then
					return p1
				end

				sum = sum + v3
			end

			if sum ~= FloatRecycleMachineConfig.RequiredFloats then
				return p1
			end

			local v4 = table.clone(p1)

			v4.fishingFloats = table.clone(v4.fishingFloats)

			local v5 = table.clone(v1)

			for v6, v7 in p3 do
				local v8 = v5[v6] - v7

				if v8 <= 0 then
					v5[v6] = nil

					continue
				end

				v5[v6] = v8
			end

			v4.fishingFloats[p2] = v5

			return v4
		end,
		secureSkipLootboxTimer = function(p1, p2) --[[ secureSkipLootboxTimer | Line: 4195 ]]
			local v1 = p1.placedLootboxes[p2]

			if v1 then
				local v2 = table.clone(p1)

				v2.placedLootboxes = table.clone(v2.placedLootboxes)

				local v3 = table.clone(v1)

				v3.PlacedAt = os.time() - v3.OpenTime
				v2.placedLootboxes[p2] = v3

				return v2
			end

			return p1
		end,
		secureSetCatMachineFedCount = function(p1, p2) --[[ secureSetCatMachineFedCount | Line: 4211 ]]
			local v1 = table.clone(p1)

			v1.catMachineFedCount = p2

			return v1
		end,
		secureSetMutationMachinePending = function(p1, p2, p3, p4, p5, p6, p7, p8, p9) --[[ secureSetMutationMachinePending | Line: 4217 ]]
			local v1 = table.clone(p1)

			v1.mutationMachinePendingMutationId = p2
			v1.mutationMachinePendingEndsAt = p3
			v1.mutationMachinePendingFishConfigName = p4
			v1.mutationMachinePendingFishLevel = p5
			v1.mutationMachinePendingFishMutation = p6
			v1.mutationMachinePendingFishScanned = p7
			v1.mutationMachinePendingFishUntradable = p8
			v1.mutationMachinePendingFishPaid = p9

			return v1
		end,
		secureSetNpcTradeState = function(p1, p2, p3) --[[ secureSetNpcTradeState | Line: 4240 ]]
			local v1 = table.clone(p1)

			v1.npcTrade = {
				count = p2,
				lastArrival = p3,
				pendingOffer = p1.npcTrade.pendingOffer
			}

			return v1
		end,
		secureSetNpcTradePendingOffer = function(p1, p2) --[[ secureSetNpcTradePendingOffer | Line: 4249 ]]
			local v1 = table.clone(p1)

			v1.npcTrade = table.clone(v1.npcTrade)
			v1.npcTrade.pendingOffer = p2

			return v1
		end,
		secureAddCookingPoints = function(p1, p2, p3) --[[ secureAddCookingPoints | Line: 4256 | Upvalues: withEventData (ref) ]]
			local v1, v2 = withEventData(p1, p2)

			v2.cookingPoints = math.max(0, v2.cookingPoints + p3)

			return v1
		end,
		secureStartCooking = function(p1, p2, p3) --[[ secureStartCooking | Line: 4262 | Upvalues: withEventData (ref) ]]
			local v1, v2 = withEventData(p1, p2)

			v2.cookingState = "cooking"
			v2.cookingStartTime = p3

			return v1
		end,
		secureResetCooking = function(p1, p2) --[[ secureResetCooking | Line: 4269 | Upvalues: withEventData (ref) ]]
			local v1, v2 = withEventData(p1, p2)

			v2.cookingPoints = 0
			v2.cookingState = "idle"
			v2.cookingStartTime = 0

			return v1
		end,
		secureAddRedeemedPromocode = function(p1, p2) --[[ secureAddRedeemedPromocode | Line: 4277 ]]
			if table.find(p1.redeemedPromocodes, p2) then
				return p1
			end

			local v1 = table.clone(p1)

			v1.redeemedPromocodes = table.clone(p1.redeemedPromocodes)
			table.insert(v1.redeemedPromocodes, p2)

			return v1
		end,
		secureIncrementMilestoneTotal = function(p1, p2, p3) --[[ secureIncrementMilestoneTotal | Line: 4287 ]]
			local v1 = math.floor(p3 or 1)

			if v1 == 0 then
				return p1
			end

			local v2 = p1.milestones or {
				totals = {},
				claimed = {},
				maxClaimable = {}
			}
			local v3 = table.clone(p1)

			v3.milestones = table.clone(v2)
			v3.milestones.totals = table.clone(v2.totals or {})
			v3.milestones.totals[p2] = math.max(0, (v3.milestones.totals[p2] or 0) + v1)

			return v3
		end,
		secureSetMilestoneMaxClaimable = function(p1, p2, p3) --[[ secureSetMilestoneMaxClaimable | Line: 4300 ]]
			local v1 = math.floor(p3)
			local v2 = p1.milestones or {
				totals = {},
				claimed = {},
				maxClaimable = {}
			}
			local v3 = v2.maxClaimable or {}

			if v1 <= (v3[p2] or 0) then
				return p1
			end

			local v4 = table.clone(p1)

			v4.milestones = table.clone(v2)
			v4.milestones.maxClaimable = table.clone(v3)
			v4.milestones.maxClaimable[p2] = v1

			return v4
		end,
		secureClaimMilestoneLevel = function(p1, p2, p3) --[[ secureClaimMilestoneLevel | Line: 4314 ]]
			local v1 = math.floor(p3)
			local v2 = p1.milestones or {
				totals = {},
				claimed = {},
				maxClaimable = {}
			}
			local v3 = v2.claimed or {}

			if v1 <= (v3[p2] or 0) then
				return p1
			end

			if ((v2.maxClaimable or {})[p2] or 0) < v1 then
				return p1
			end

			local v5 = table.clone(p1)

			v5.milestones = table.clone(v2)
			v5.milestones.claimed = table.clone(v3)
			v5.milestones.claimed[p2] = v1

			return v5
		end,
		secureIncrementLuckyblockPity = function(p1, p2) --[[ secureIncrementLuckyblockPity | Line: 4331 ]]
			local v1 = table.clone(p1)
			local clone = table.clone

			v1.luckyblockPity = clone(v1.luckyblockPity or {})
			v1.luckyblockPity[p2] = (v1.luckyblockPity[p2] or 0) + 1

			return v1
		end,
		secureResetLuckyblockPity = function(p1, p2) --[[ secureResetLuckyblockPity | Line: 4338 ]]
			local v1 = table.clone(p1)
			local clone = table.clone

			v1.luckyblockPity = clone(v1.luckyblockPity or {})
			v1.luckyblockPity[p2] = 0

			return v1
		end,
		secureSetContributedExistCounts = function(p1, p2) --[[ secureSetContributedExistCounts | Line: 4345 ]]
			local v1 = table.clone(p1)

			v1.contributedExistCounts = p2

			return v1
		end,
		secureSetAutoSellRarity = function(p1, p2, p3) --[[ secureSetAutoSellRarity | Line: 4351 ]]
			local v1 = table.clone(p1)
			local clone = table.clone

			v1.autoSellRarities = clone(v1.autoSellRarities or {})

			if p3 then
				v1.autoSellRarities[p2] = true
			else
				v1.autoSellRarities[p2] = nil
			end

			return v1
		end,
		secureSetFavorite = function(p1, p2, p3) --[[ secureSetFavorite | Line: 4365 | Upvalues: favoriteCount (ref) ]]
			local v1 = p1.inventory[p2]
			local v5 = math.clamp(math.floor(p3), 0, if v1 then v1.Stack else 0)

			if v5 == favoriteCount(p1.favorites, p2) then
				return p1
			end

			local v6 = table.clone(p1)

			v6.favorites = table.clone(v6.favorites or {})

			if v5 > 0 then
				v6.favorites[p2] = v5
			else
				v6.favorites[p2] = nil
			end

			return v6
		end,
		secureSetAutoSellMinEarnings = function(p1, p2) --[[ secureSetAutoSellMinEarnings | Line: 4381 ]]
			local v1 = table.clone(p1)

			v1.autoSellMinEarnings = p2

			return v1
		end,
		secureSetSetting = function(p1, p2, p3) --[[ secureSetSetting | Line: 4389 | Upvalues: t (ref) ]]
			if t.settings[p2] == nil then
				return p1
			end

			local v1 = table.clone(p1)
			local v2 = table.clone(v1.settings)

			v2[p2] = p3
			v1.settings = v2

			return v1
		end,
		secureQueueRewardPopup = function(p1, p2, p3) --[[ secureQueueRewardPopup | Line: 4405 ]]
			local v1 = table.clone(p1)
			local rewardPopup = v1.rewardPopup
			local v2 = if rewardPopup and rewardPopup.gotPopUp then table.clone(rewardPopup.content) else {}

			for v3, v4 in p2 do
				table.insert(v2, v4)
			end

			v1.rewardPopup = {
				gotPopUp = true,
				content = v2,
				message = if p3 == nil then if rewardPopup and rewardPopup.gotPopUp then rewardPopup.message else nil else p3
			}

			return v1
		end,
		secureClearRewardPopup = function(p1) --[[ secureClearRewardPopup | Line: 4424 ]]
			local v1 = table.clone(p1)

			v1.rewardPopup = {
				gotPopUp = false,
				content = {}
			}

			return v1
		end,
		secureMarkAuctionHouseSeen = function(p1) --[[ secureMarkAuctionHouseSeen | Line: 4440 ]]
			if p1.seenAuctionHouse then
				return p1
			end

			local v1 = table.clone(p1)

			v1.seenAuctionHouse = true

			return v1
		end,
		secureMarkEnchantStoneSeen = function(p1) --[[ secureMarkEnchantStoneSeen | Line: 4453 ]]
			if p1.seenEnchantStone then
				return p1
			end

			local v1 = table.clone(p1)

			v1.seenEnchantStone = true

			return v1
		end,
		secureSetTradeLock = function(p1, p2, p3) --[[ secureSetTradeLock | Line: 4462 | Upvalues: tradeLockCount (ref) ]]
			local v1 = p1.inventory[p2]
			local v5 = math.clamp(math.floor(p3), 0, if v1 then v1.Stack else 0)

			if v5 == tradeLockCount(p1.tradeLocks, p2) then
				return p1
			end

			local v6 = table.clone(p1)

			v6.tradeLocks = table.clone(v6.tradeLocks or {})

			if v5 > 0 then
				v6.tradeLocks[p2] = v5
			else
				v6.tradeLocks[p2] = nil
			end

			return v6
		end,
		secureSetPaidCopies = function(p1, p2, p3) --[[ secureSetPaidCopies | Line: 4481 | Upvalues: paidCopyCount (ref) ]]
			local v1 = p1.inventory[p2]
			local v5 = math.clamp(math.floor(p3), 0, if v1 then v1.Stack else 0)

			if v5 == paidCopyCount(p1.paidCopies, p2) then
				return p1
			end

			local v6 = table.clone(p1)

			v6.paidCopies = table.clone(v6.paidCopies or {})

			if v5 > 0 then
				v6.paidCopies[p2] = v5
			else
				v6.paidCopies[p2] = nil
			end

			return v6
		end,
		secureQueueAuctionRewardPopup = function(p1, p2) --[[ secureQueueAuctionRewardPopup | Line: 4497 ]]
			if #p2 == 0 then
				return p1
			end

			local v1 = table.clone(p1)
			local auctionRewardPopup = v1.auctionRewardPopup
			local v2 = if auctionRewardPopup and auctionRewardPopup.gotPopUp then table.clone(auctionRewardPopup.content) else {}

			for v3, v4 in p2 do
				table.insert(v2, v4)
			end

			v1.auctionRewardPopup = {
				gotPopUp = true,
				content = v2
			}

			return v1
		end,
		secureClearAuctionRewardPopup = function(p1) --[[ secureClearAuctionRewardPopup | Line: 4513 ]]
			local v1 = table.clone(p1)

			v1.auctionRewardPopup = {
				gotPopUp = false,
				content = {}
			}

			return v1
		end,
		secureAuctionEscrowSet = function(p1, p2, p3) --[[ secureAuctionEscrowSet | Line: 4526 ]]
			if typeof(p2) ~= "string" or p2 == "" then
				return p1
			end

			local v1 = p1.auctionEscrow or {}
			local v2 = v1[p2]
			local v3 = if v2 then v2.a else 0
			local v5 = math.max(0, (math.floor(p3)))
			local v6 = v5 - v3

			if v6 == 0 then
				return p1
			end

			if v6 > 0 and p1.money < v6 then
				return p1
			end

			local v7 = table.clone(p1)

			v7.auctionEscrow = table.clone(v1)
			v7.money = math.max(0, (math.floor(v7.money - v6)))

			if v5 > 0 then
				v7.auctionEscrow[p2] = {
					a = v5,
					t = os.time()
				}
			else
				v7.auctionEscrow[p2] = nil
			end

			return v7
		end,
		secureSettleAuctionWin = function(p1, p2, p3, p4, p5, p6) --[[ secureSettleAuctionWin | Line: 4571 | Upvalues: AuctionHouseConfig (ref), grantItemInState (ref), lockOneInState (ref) ]]
			local v1 = p1.auctionEscrow or {}

			if not v1[p2] then
				return p1
			end

			local v2 = AuctionHouseConfig.resolveItem(p3, p4)

			if not v2 then
				return p1
			end

			local v3 = table.clone(p1)

			v3.auctionEscrow = table.clone(v1)
			v3.auctionEscrow[p2] = nil

			if p3 == "BaseSkin" then
				v3.unlockedBaseSkins = table.clone(v3.unlockedBaseSkins)
				v3.unlockedBaseSkins[p4] = true

				return v3
			end

			local v5 = grantItemInState(v3, v2, if p3 == "Fish" then {
	Untradable = true,
	Level = p5 or 1,
	Mutation = p6
} else nil)

			if p3 ~= "Fish" and not v2.Untradeable then
				lockOneInState(v3, v5)
			end

			return v3
		end,
		secureBuyAuctionItem = function(p1, p2, p3, p4) --[[ secureBuyAuctionItem | Line: 4619 | Upvalues: AuctionRotation (ref), AuctionHouseConfig (ref), grantFloatInState (ref), grantItemInState (ref) ]]
			local v1 = AuctionRotation.rotationFor(p2).ClassicBySlot[p3]

			if not v1 then
				return p1
			end

			if typeof(p4) ~= "number" or p4 ~= p4 then
				return p1
			end

			local v2 = math.floor(p4)

			if v2 < v1.Entry.MinPrice or v1.Entry.MaxPrice < v2 then
				return p1
			end

			if p1.money < v2 then
				return p1
			end

			local v3 = AuctionHouseConfig.resolveItem(v1.Entry.Category, v1.Entry.ConfigName)

			if not v3 then
				return p1
			end

			local v4 = AuctionRotation.auctionId(p2, p3)
			local v5 = p1.auctionPurchases or {}
			local v6 = v5[v4] or 0

			if AuctionHouseConfig.PurchaseLimitPerSlot <= v6 then
				return p1
			end

			local v7 = table.clone(p1)
			local v8 = ("%*:"):format(p2)
			local t, v9 = {}, v2

			for v10, v11 in v5 do
				if string.sub(v10, 1, #v8) == v8 then
					t[v10] = v11
				end
			end

			t[v4] = v6 + 1
			v7.auctionPurchases = t
			v7.money = math.max(0, (math.floor(v7.money - v9)))

			if v1.Entry.Category == "Float" then
				grantFloatInState(v7, v1.Entry.ConfigName, v1.Entry.Tier or "Common")
			else
				grantItemInState(v7, v3, nil)
			end

			return v7
		end,
		__TEMPLATE = function(p1) --[[ __TEMPLATE | Line: 4671 ]]
			return table.clone(p1)
		end
	})
end

return {
	CreateProducer = CreateProducer,
	SAVE_EXCEPTIONS = { "sessionValue", "pickupAreasData", "freeGiftsTimestamp", "claimedGiftsIds", "ownedPasses" },
	DEFAULT_STATE = t
}