-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Reflex = require(ReplicatedStorage.package.Reflex)

function CreateProducer(p1) --[[ CreateProducer | Line: 19 | Upvalues: Reflex (copy) ]]
	return Reflex.createProducer(p1, {
		__TEMPLATE = function(p1) --[[ __TEMPLATE | Line: 22 ]]
			local v1 = table.clone(p1)

			v1._TEMPLATE = not v1._TEMPLATE

			return v1
		end
	})
end

return {
	CreateProducer = CreateProducer,
	DEFAULT_STATE = {
		_TEMPLATE = false
	}
}