-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Reflex = require(ReplicatedStorage.package.Reflex)

function CreateProducer(p1) --[[ CreateProducer | Line: 36 | Upvalues: Reflex (copy) ]]
	return Reflex.createProducer(p1, {
		increment = function(p1) --[[ increment | Line: 38 ]]
			local v1 = table.clone(p1)

			v1.clientValue = v1.clientValue + 1

			return v1
		end,
		setAutoWalkEnabled = function(p1, p2) --[[ setAutoWalkEnabled | Line: 45 ]]
			local v1 = table.clone(p1)

			v1.autoWalkEnabled = p2

			return v1
		end,
		setDoubleTailSuggestionEnabled = function(p1, p2) --[[ setDoubleTailSuggestionEnabled | Line: 52 ]]
			local v1 = table.clone(p1)

			v1.doubleTailShown = p2

			return v1
		end,
		setAutoSellEnabled = function(p1, p2) --[[ setAutoSellEnabled | Line: 59 ]]
			local v1 = table.clone(p1)

			v1.autoSellEnabled = p2

			return v1
		end,
		setAutoRebirthEnabled = function(p1, p2) --[[ setAutoRebirthEnabled | Line: 66 ]]
			local v1 = table.clone(p1)

			v1.autoRebirthEnabled = p2

			return v1
		end,
		setActiveUI = function(p1, p2, p3) --[[ setActiveUI | Line: 73 ]]
			local v1 = table.clone(p1)

			v1.activeUI = if p2 == v1.activeUI and not p3 then "" else p2

			return v1
		end
	})
end

return {
	CreateProducer = CreateProducer,
	DEFAULT_STATE = {
		clientValue = 1,
		autoSellEnabled = false,
		autoWalkEnabled = false,
		autoRebirthEnabled = false,
		activeUI = "",
		doubleTailShown = false
	}
}