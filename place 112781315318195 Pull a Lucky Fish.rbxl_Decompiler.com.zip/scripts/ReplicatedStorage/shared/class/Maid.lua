-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local t = {}

t.__index = t
function t.new() --[[ new | Line: 13 | Upvalues: t (copy) ]]
	return setmetatable({
		_tasks = {}
	}, t)
end
function t.GiveTask(p1, p2) --[[ GiveTask | Line: 17 ]]
	table.insert(p1._tasks, p2)

	return p2
end
function t.GivePromise(p1, p2) --[[ GivePromise | Line: 22 ]]
	p1:GiveTask(function() --[[ Line: 23 | Upvalues: p2 (copy) ]]
		p2:cancel()
	end)

	return p2
end
function t.DoCleaning(p1) --[[ DoCleaning | Line: 29 ]]
	local _tasks = p1._tasks

	p1._tasks = {}

	for i = #_tasks, 1, -1 do
		local v1 = _tasks[i]
		local v2 = typeof(v1)

		if v2 == "function" then
			v1()

			continue
		end

		if v2 == "thread" then
			pcall(task.cancel, v1)

			continue
		end

		if v2 == "RBXScriptConnection" then
			v1:Disconnect()

			continue
		end

		if v2 == "Instance" then
			v1:Destroy()

			continue
		end

		if v2 == "table" then
			if typeof(v1.Disconnect) == "function" then
				v1:Disconnect()

				continue
			end

			if typeof(v1.Destroy) == "function" then
				v1:Destroy()

				continue
			end

			if typeof(v1.DoCleaning) == "function" then
				v1:DoCleaning()
			end
		end
	end
end
t.Destroy = t.DoCleaning

return t