-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local AssetService = game:GetService("AssetService")
local t = {}

t.__index = t
t.Shader = nil
t.mat3 = require(script.Mat3).mat3
t.mat2 = require(script.Mat2).mat2
t.Vector4 = require(script.Vector4).new

local function GetNext(p1) --[[ GetNext | Line: 21 ]]
	return SharedTable.size(p1) + 1
end

function t.wrap(p1) --[[ wrap | Line: 25 | Upvalues: t (copy) ]]
	local v2 = setmetatable({}, t)

	v2.Shader = p1
	p1.Vertices = p1.Vertices or {}
	p1.Triangles = p1.Triangles or {}
	p1.Camera = p1.Camera or {
		Position = Vector3.new(0, 0, 0),
		LookAt = Vector3.new(0, 0, -1),
		Up = Vector3.new(0, 1, 0),
		FOV = 1.2217304763960306,
		Aspect = 1,
		Near = 0.1,
		Far = 1000
	}
	p1.ColorBuffer = nil
	p1.DepthBuffer = nil
	v2.ScreenVertices = {}
	v2.TriangleBounds = {}

	return v2
end
function t.AddVertex(p1, p2, p3, p4) --[[ AddVertex | Line: 54 ]]
	local Vertices = p1.Shader.Vertices
	local v1 = SharedTable.size(Vertices) + 1

	Vertices[v1] = {
		Position = p2,
		Color = p3,
		Data = p4,
		ID = v1
	}

	return v1
end
function t.RemoveVertex(p1, p2) --[[ RemoveVertex | Line: 66 ]]
	p1.Shader.Vertices[p2] = nil
end
function t.GetVertex(p1, p2) --[[ GetVertex | Line: 70 ]]
	return p1.Shader.Vertices[p2]
end
function t.AddTriangle(p1, p2, p3, p4, p5) --[[ AddTriangle | Line: 75 ]]
	local Triangles = p1.Shader.Triangles
	local v1 = SharedTable.size(Triangles) + 1

	Triangles[v1] = {
		Vertex1 = p2,
		Vertex2 = p3,
		Vertex3 = p4,
		Data = p5,
		ID = v1
	}

	return v1
end
function t.RemoveTriangle(p1, p2) --[[ RemoveTriangle | Line: 88 ]]
	p1.Shader.Triangles[p2] = nil
end
function t.GetTriangle(p1, p2) --[[ GetTriangle | Line: 92 ]]
	return p1.Shader.Triangles[p2]
end
function t.GetTriangleVertices(p1, p2) --[[ GetTriangleVertices | Line: 96 ]]
	local v1 = p1:GetTriangle(p2)

	if v1 then
		return p1:GetVertex(v1.Vertex1), p1:GetVertex(v1.Vertex2), p1:GetVertex(v1.Vertex3)
	end

	return nil
end
function t.SetCamera(p1, p2, p3, p4, p5, p6, p7, p8) --[[ SetCamera | Line: 103 ]]
	local Camera = p1.Shader.Camera

	Camera.Position = p2
	Camera.LookAt = p3
	Camera.Up = p4

	if p5 then
		Camera.FOV = math.rad(p5)
	end

	if p6 then
		Camera.Aspect = p6
	end

	if p7 then
		Camera.Near = p7
	end

	if not p8 then
		return
	end

	Camera.Far = p8
end
function t.WorldToScreen(p1, p2) --[[ WorldToScreen | Line: 114 ]]
	local Shader = p1.Shader
	local v1 = Shader.Size or Vector2.zero
	local Camera = Shader.Camera
	local Unit = (Camera.LookAt - Camera.Position).Unit
	local Unit2 = Unit:Cross(Camera.Up).Unit
	local v2 = Unit2:Cross(Unit)
	local v3 = p2 - Camera.Position
	local v4 = v3:Dot(Unit2)
	local v5 = v3:Dot(v2)
	local v6 = v3:Dot(Unit)

	if v6 <= 0 then
		return nil
	end

	local v8 = 1 / math.tan(Camera.FOV / 2)

	return Vector2.new((v4 / v6 * v8 * Camera.Aspect * 0.5 + 0.5) * v1.X, (1 - (v5 / v6 * v8 * 0.5 + 0.5)) * v1.Y)
end
function t.Update(p1) --[[ Update | Line: 141 ]]
	local Vertices = p1.Shader.Vertices
	local Triangles = p1.Shader.Triangles

	p1.ScreenVertices = {}

	for i = 1, SharedTable.size(Vertices) do
		local v1 = p1:GetVertex(i)

		if v1 then
			local v2 = p1:WorldToScreen(v1.Position)

			if v2 then
				p1.ScreenVertices[i] = v2
			end
		end
	end

	p1.Shader.ScreenVertices = p1.ScreenVertices
	p1.TriangleBounds = {}

	for j = 1, SharedTable.size(Triangles) do
		local v3 = p1:GetTriangle(j)

		if v3 then
			local v4 = p1.ScreenVertices[v3.Vertex1]
			local v5 = p1.ScreenVertices[v3.Vertex2]
			local v6 = p1.ScreenVertices[v3.Vertex3]

			if v4 and (v5 and v6) then
				local t = {}

				t.minX = math.min(v4.X, v5.X, v6.X)
				t.maxX = math.max(v4.X, v5.X, v6.X)
				t.minY = math.min(v4.Y, v5.Y, v6.Y)
				t.maxY = math.max(v4.Y, v5.Y, v6.Y)
				p1.TriangleBounds[j] = t
			end
		end
	end

	p1.Shader.TriangleBounds = p1.TriangleBounds
end
function t.IsInVertex(p1, p2, p3, p4) --[[ IsInVertex | Line: 178 ]]
	local v1 = p1.ScreenVertices[p3]

	if not v1 then
		return false
	end

	return (v1 - p2).Magnitude <= p4
end
function t.IsInLine(p1, p2, p3, p4, p5) --[[ IsInLine | Line: 184 ]]
	local v1 = p1.ScreenVertices[p3]
	local v2 = p1.ScreenVertices[p4]

	if not (v1 and v2) then
		return false
	end

	local v3 = v2.X - v1.X
	local v4 = v2.Y - v1.Y
	local v5 = v3 * v3 + v4 * v4

	if v5 == 0 then
		local v6 = p2.X - v1.X
		local v7 = p2.Y - v1.Y

		return v6 * v6 + v7 * v7 <= p5 * p5
	end

	local v10 = math.clamp(((p2.X - v1.X) * v3 + (p2.Y - v1.Y) * v4) / v5, 0, 1)
	local v13 = p2.X - (v1.X + v10 * v3)
	local v14 = p2.Y - (v1.Y + v10 * v4)

	return v13 * v13 + v14 * v14 <= p5 * p5
end
function t.IsInFace(p1, p2, p3) --[[ IsInFace | Line: 201 ]]
	local v1 = p1.Shader.Triangles[p3]

	if not v1 then
		return false
	end

	local v2 = p1.ScreenVertices[v1.Vertex1]
	local v3 = p1.ScreenVertices[v1.Vertex2]
	local v4 = p1.ScreenVertices[v1.Vertex3]

	if not (v2 and (v3 and v4)) then
		return false
	end

	local v5 = math.min(v2.X, v3.X, v4.X)
	local v6 = math.max(v2.X, v3.X, v4.X)
	local v7 = math.min(v2.Y, v3.Y, v4.Y)

	if p2.X < v5 or (v6 < p2.X or (p2.Y < v7 or math.max(v2.Y, v3.Y, v4.Y) < p2.Y)) then
		return false
	end

	local v9 = (v3.Y - v4.Y) * (v2.X - v4.X) + (v4.X - v3.X) * (v2.Y - v4.Y)

	if v9 == 0 then
		return false
	end

	local v10 = ((v3.Y - v4.Y) * (p2.X - v4.X) + (v4.X - v3.X) * (p2.Y - v4.Y)) / v9
	local v11 = ((v4.Y - v2.Y) * (p2.X - v4.X) + (v2.X - v4.X) * (p2.Y - v4.Y)) / v9
	local v12 = 1 - v10 - v11

	return if v10 >= 0 and v11 >= 0 then if v12 >= 0 then true else false else false, v10, v11, v12
end
function t.GetVertexDepth(p1, p2) --[[ GetVertexDepth | Line: 225 ]]
	local v1 = p1:GetVertex(p2)

	if v1 then
		local Camera = p1.Shader.Camera

		return -CFrame.lookAt(Camera.Position, Camera.LookAt):ToObjectSpace(CFrame.new(v1.Position)).Z
	end
end
function t.Interpolate(p1, p2, p3, p4, p5, p6, p7) --[[ Interpolate | Line: 233 ]]
	if typeof(p5) ~= "table" then
		return p2 * p5 + p3 * p6 + p4 * p7
	end

	local t = {}

	for i = 1, #p5 do
		t[i] = p2 * p5[i] + p3 * p6[i] + p4 * p7[i]
	end

	return t
end
function t.CreateBuffer(p1, p2, p3) --[[ CreateBuffer | Line: 246 ]]
	return buffer.create(p2.X * p2.Y * p3)
end
function t.SetColorBuffer(p1, p2, p3, p4, p5, p6) --[[ SetColorBuffer | Line: 250 ]]
	local v1 = (p4 * p5.X + p3) * 4

	buffer.writeu8(p2, v1 + 1 - 1, p6[1])
	buffer.writeu8(p2, v1 + 2 - 1, p6[2])
	buffer.writeu8(p2, v1 + 3 - 1, p6[3])
	buffer.writeu8(p2, v1 + 4 - 1, p6[4])

	return true
end
function t.GetColorBuffer(p1, p2, p3, p4, p5) --[[ GetColorBuffer | Line: 258 ]]
	local v1 = (p4 * p5.X + p3) * 4

	return {
		buffer.readu8(p2, v1),
		buffer.readu8(p2, v1 + 1),
		buffer.readu8(p2, v1 + 2),
		(buffer.readu8(p2, v1 + 3))
	}
end
function t.SetDepthBuffer(p1, p2, p3, p4, p5, p6) --[[ SetDepthBuffer | Line: 268 ]]
	buffer.writef32(p2, (p4 * p5.X + p3) * 4, p6)

	return true
end
function t.GetDepthBuffer(p1, p2, p3, p4, p5) --[[ GetDepthBuffer | Line: 273 ]]
	return buffer.readf32(p2, (p4 * p5.X + p3) * 4)
end
function t.ClearBufferU8(p1, p2, p3) --[[ ClearBufferU8 | Line: 277 ]]
	for i = 0, buffer.len(p2) - 1 do
		buffer.writeu8(p2, i, p3)
	end
end
function t.ClearBufferF32(p1, p2, p3) --[[ ClearBufferF32 | Line: 282 ]]
	for i = 0, buffer.len(p2) / 4 - 1 do
		buffer.writef32(p2, i * 4, p3)
	end
end
function t.ImportMesh(p1, p2) --[[ ImportMesh | Line: 288 | Upvalues: AssetService (copy) ]]
	local v1 = AssetService:CreateEditableMeshAsync(p2)

	for k, v in pairs(v1:GetFaces()) do
		local v2 = v1:GetFaceVertices(v)
		local v3 = v1:GetFaceUVs(v)
		local v4 = nil
		local v5 = nil
		local v6 = nil

		for k2, v7 in pairs(v2) do
			local v72 = p1:AddVertex(v1:GetPosition(v7), Color3.new(math.random(), math.random(), math.random()), {})

			p1:SetUV(v72, (v1:GetUV(v3[k2])))

			if k2 == 1 then
				v4 = v72

				continue
			end

			if k2 == 2 then
				v5 = v72

				continue
			end

			if k2 == 3 then
				v6 = v72
			end
		end

		if v4 and (v5 and v6) then
			p1:AddTriangle(v4, v5, v6, {})
		end
	end

	return true
end
function t.ImportImageData(p1, p2) --[[ ImportImageData | Line: 307 | Upvalues: AssetService (copy) ]]
	return AssetService:CreateEditableImageAsync(p2)
end
function t.ImageDataToBuffer(p1, p2) --[[ ImageDataToBuffer | Line: 311 ]]
	return p2:ReadPixelsBuffer(Vector2.zero, p2.Size - Vector2.one), p2.Size
end
function t.BufferToTable(p1, p2, p3) --[[ BufferToTable | Line: 315 ]]
	local t = {}

	for i = 0, buffer.len(p2) - 1 do
		t[i] = buffer.readu8(p2, i)
	end

	return t
end
function t.SetUV(p1, p2, p3) --[[ SetUV | Line: 322 ]]
	p1.Shader.Vertices[p2].UV = p3
end
function t.GetUV(p1, p2) --[[ GetUV | Line: 326 ]]
	return p1:GetVertex(p2).UV or Vector2.zero
end
function t.GetTextureColor(p1, p2, p3, p4) --[[ GetTextureColor | Line: 332 ]]
	local v1 = math.clamp(p2.X, 0, 1)
	local v2 = math.clamp(p2.Y, 0, 1)
	local v4 = math.floor(v1 * (p4.X - 1))
	local v6 = (math.floor((1 - v2) * (p4.Y - 1)) * p4.X + v4) * 4

	return Color3.fromRGB(p3[v6], p3[v6 + 1], p3[v6 + 2])
end
function t.reflect(p1, p2, p3) --[[ reflect | Line: 345 ]]
	return p2 - p3 * (2 * p2:Dot(p3))
end
function t.texture(p1, p2, p3, p4) --[[ texture | Line: 349 ]]
	local v1 = math.clamp(p2.X, 0, 1)
	local v2 = math.clamp(p2.Y, 0, 1)
	local v4 = math.floor(v1 * p4.X)
	local v6 = (math.floor(v2 * p4.Y) * p4.X + v4) * 4

	return Color3.fromRGB(p3[v6], p3[v6 + 1], p3[v6 + 2])
end
function t.IsTriangleInFrustum(p1, p2, p3, p4, p5) --[[ IsTriangleInFrustum | Line: 361 ]]
	for k, v in pairs(p5) do
		local Position = v.Position
		local Normal = v.Normal
		local count = 0

		if (p2 - Position):Dot(Normal) < 0 then
			count = count + 1
		end

		if (p3 - Position):Dot(Normal) < 0 then
			count = count + 1
		end

		if (p4 - Position):Dot(Normal) < 0 then
			count = count + 1
		end

		if count == 3 then
			return false
		end
	end

	return true
end
function t.fract(p1, p2) --[[ fract | Line: 377 ]]
	return p2 - math.floor(p2)
end
function t.mix(p1, p2, p3, p4) --[[ mix | Line: 381 ]]
	return p2 * (1 - p4) + p3 * p4
end
function t.smoothstep(p1, p2, p3, p4) --[[ smoothstep | Line: 385 ]]
	local v1 = math.clamp((p4 - p2) / (p3 - p2), 0, 1)

	return v1 * v1 * (3 - v1 * 2)
end
function t.length2(p1, p2) --[[ length2 | Line: 390 ]]
	return math.sqrt(p2.X ^ 2 + p2.Y ^ 2)
end
function t.length3(p1, p2) --[[ length3 | Line: 394 ]]
	return math.sqrt(p2.X ^ 2 + p2.Y ^ 2 + p2.Z ^ 2)
end
function t.hash(p1, p2) --[[ hash | Line: 398 ]]
	return p1:fract(math.sin(p2.X * 127.1 + p2.Y * 311.7) * 43758.5453123)
end
function t.noise(p1, p2) --[[ noise | Line: 402 ]]
	local v3 = Vector2.new(math.floor(p2.X), (math.floor(p2.Y)))
	local v4 = Vector2.new(p1:fract(p2.X), p1:fract(p2.Y))
	local v5 = Vector2.new(v4.X * v4.X * (3 - 2 * v4.X), v4.Y * v4.Y * (3 - 2 * v4.Y))
	local v6 = p1:hash(v3)
	local v7 = p1:hash(Vector2.new(v3.X + 1, v3.Y))
	local v8 = p1:hash(Vector2.new(v3.X, v3.Y + 1))
	local v9 = p1:hash(Vector2.new(v3.X + 1, v3.Y + 1))

	return p1:mix(p1:mix(v6, v7, v5.X), p1:mix(v8, v9, v5.X), v5.Y)
end
function t.fbm(p1, p2, p3) --[[ fbm | Line: 415 ]]
	local v1 = 0.5
	local sum = 0

	for i = 1, p3 or 6 do
		sum = sum + v1 * p1:noise(p2)
		p2 = p2 * 2
		v1 = v1 * 0.5
	end

	return sum
end
function t.ridged(p1, p2) --[[ ridged | Line: 426 ]]
	return 1 - math.abs(p1:fbm(p2) * 2 - 1)
end
function t.turbulence(p1, p2, p3) --[[ turbulence | Line: 430 ]]
	return Vector2.new(p1:fbm(p2 * 2 + Vector2.new(0, p3 * 1.5)), p1:fbm(p2 * 2 + Vector2.new(1.3, p3 * 1.1))) * 0.2
end
function t.mix3(p1, p2, p3, p4) --[[ mix3 | Line: 437 ]]
	return Vector3.new(p1:mix(p2.X, p3.X, p4), p1:mix(p2.Y, p3.Y, p4), p1:mix(p2.Z, p3.Z, p4))
end
function t.mulcol(p1, p2, p3) --[[ mulcol | Line: 445 ]]
	return Color3.new(p2.R * p3, p2.G * p3, p2.B * p3)
end
function t.addcol(p1, p2, p3) --[[ addcol | Line: 453 ]]
	return Color3.new(p2.R + p3.R, p2.G + p3.G, p2.B + p3.B)
end
function t.mod(p1, p2, p3) --[[ mod | Line: 461 ]]
	return p2 - p3 * math.floor(p2 / p3)
end
function t.mod2(p1, p2, p3) --[[ mod2 | Line: 465 ]]
	return Vector2.new(p1:mod(p2.X, p3.X), p1:mod(p2.Y, p3.Y))
end
function t.mod3(p1, p2, p3) --[[ mod3 | Line: 472 ]]
	return Vector3.new(p1:mod(p2.X, p3.X), p1:mod(p2.Y, p3.Y), p1:mod(p2.Z, p3.Z))
end

return t