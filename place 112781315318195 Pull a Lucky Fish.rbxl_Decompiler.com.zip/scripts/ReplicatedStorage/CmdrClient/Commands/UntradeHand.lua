-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "UntradeHand",
	Description = "Lock the fish you\'re holding so it can\'t be traded or gifted",
	Group = "Tester",
	Aliases = { "untradehand", "uth" },
	Args = {}
}