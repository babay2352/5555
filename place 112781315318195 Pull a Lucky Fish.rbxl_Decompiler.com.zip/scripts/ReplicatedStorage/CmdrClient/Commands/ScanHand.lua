-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "ScanHand",
	Description = "Set the Alien Event research state of the fish you\'re holding (stand-in for the lab)",
	Group = "Tester",
	Aliases = { "scanhand", "scan" },
	Args = {
		{
			Type = "string",
			Name = "state",
			Description = "scanned | unscanned",
			Default = "scanned"
		}
	}
}