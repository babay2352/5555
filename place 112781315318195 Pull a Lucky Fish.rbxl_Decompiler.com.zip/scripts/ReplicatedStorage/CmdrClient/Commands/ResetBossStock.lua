-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "ResetBossStock",
	Description = "Set boss fish stock to 0. Omit the fish to clear every boss at once.",
	Group = "Tester",
	Aliases = { "resetbossstock", "clearfishstock", "rbs" },
	Args = {
		{
			Type = "fish",
			Name = "fish",
			Description = "Boss fish to clear (autocomplete). Leave empty to clear ALL boss fish.",
			Optional = true
		}
	}
}