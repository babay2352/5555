-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "SetRarityCaught",
	Description = "Sets how many fish of a rarity a player has caught (the World 2 unlock gate)",
	Group = "Tester",
	Aliases = { "setraritycaught", "setcaught" },
	Args = {
		{
			Type = "rarity",
			Name = "rarity",
			Description = "Which rarity\'s catch counter to set (e.g. Celestial)"
		},
		{
			Type = "number",
			Name = "count",
			Description = "Catches to record (0 clears it)"
		},
		{
			Type = "player",
			Name = "target",
			Description = "Player to set the counter for (defaults to you)",
			Optional = true
		}
	}
}