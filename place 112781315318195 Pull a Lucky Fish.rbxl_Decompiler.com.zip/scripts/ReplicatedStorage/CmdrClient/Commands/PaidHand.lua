-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "PaidHand",
	Description = "Marks the held item as bought with Robux (policy-gated trading). Fish: toggles the flag. Non-fish: sets how many copies are marked (omit = whole stack, 0 = clear).",
	Group = "Tester",
	Aliases = { "paidhand", "markpaid" },
	Args = {
		{
			Type = "number",
			Name = "count",
			Description = "Non-fish only: how many copies to mark. Omit to mark the whole stack, 0 to clear.",
			Optional = true
		}
	}
}