-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "MutateHand",
	Description = "Add a mutation to the fish you\'re holding in your hand",
	Group = "Tester",
	Aliases = { "mutatehand", "mh" },
	Args = {
		{
			Type = "mutation",
			Name = "mutation",
			Description = "Mutation to add (autocomplete)"
		}
	}
}