-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "GiveAllFloats",
	Description = "Give a player every fishing float in every available tier",
	Group = "Tester",
	Aliases = { "gaf", "allfloats" },
	Args = {
		{
			Type = "player",
			Name = "target",
			Description = "Player to give the floats to (default: you)",
			Optional = true
		},
		{
			Type = "number",
			Name = "amount",
			Description = "Copies of each float+tier to give (default 1)",
			Optional = true
		}
	}
}