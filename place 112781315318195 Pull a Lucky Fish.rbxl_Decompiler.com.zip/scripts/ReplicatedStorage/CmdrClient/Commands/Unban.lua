-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "unban",
	Description = "Unbans a player by UserId",
	Group = "Admin",
	Aliases = {},
	Args = {
		{
			Name = "userId",
			Type = "number",
			Description = "Player ID to ban",
			Optional = false
		}
	}
}