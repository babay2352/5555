-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "GiveLevelWorm",
	Description = "Give a Level Worm tool to a player (admin testing)",
	Group = "Tester",
	Aliases = { "glw", "givelevelworm", "giveworm" },
	Args = {
		{
			Type = "player",
			Name = "target",
			Description = "Player to give the Level Worm to"
		},
		{
			Type = "number",
			Name = "amount",
			Description = "Number of worms to give (default 1)",
			Optional = true
		}
	}
}