-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "StopAllEvents",
	Description = "Stop all active weather/events (optionally on all servers)",
	Group = "Tester",
	Aliases = { "stopallevents", "StopAllEvents", "clearevents" },
	Args = {
		{
			Name = "global",
			Type = "boolean",
			Description = "If true, stop on ALL servers; if false, only this server",
			Optional = true,
			Default = true
		}
	}
}