-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "DailyQuestReset",
	Description = "Force-reset daily quests (re-rolls quest selection)",
	Group = "Tester",
	Aliases = { "questreset", "resetquests" },
	Args = {}
}