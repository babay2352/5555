-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "SpawnMiniGym",
	Description = "Spawn a time-limited mini gym where you stand (training multiplier), optionally on all servers",
	Group = "Tester",
	Aliases = { "spawnminigym", "minigym" },
	Args = {
		{
			Name = "minutes",
			Type = "number",
			Description = "How long it stays, in minutes (fractions ok: 0.5 = 30s). Defaults to the configured lifetime.",
			Optional = true
		},
		{
			Name = "global",
			Type = "boolean",
			Description = "If true, spawn on ALL servers; if false, only this server. Defaults to true.",
			Optional = true,
			Default = true
		}
	}
}