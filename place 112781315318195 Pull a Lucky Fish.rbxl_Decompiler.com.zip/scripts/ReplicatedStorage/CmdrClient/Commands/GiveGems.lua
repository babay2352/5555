-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "GiveGems",
	Description = "Give gems to a player",
	Group = "Tester",
	Aliases = { "gems", "addgems" },
	Args = {
		{
			Type = "number",
			Name = "amount",
			Description = "Number of gems to add"
		},
		{
			Type = "player",
			Name = "target",
			Description = "Player to add gems to",
			Optional = true
		}
	}
}