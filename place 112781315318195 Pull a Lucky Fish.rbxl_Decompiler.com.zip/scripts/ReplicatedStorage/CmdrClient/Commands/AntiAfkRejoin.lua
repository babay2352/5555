-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "AntiAfkRejoin",
	Description = "Run the anti-AFK same-server rejoin now, without waiting out the 19-minute idle timer",
	Group = "Tester",
	Aliases = { "rejoin" },
	Args = {
		{
			Type = "player",
			Name = "target",
			Description = "Who to bounce (defaults to you)",
			Optional = true
		}
	}
}