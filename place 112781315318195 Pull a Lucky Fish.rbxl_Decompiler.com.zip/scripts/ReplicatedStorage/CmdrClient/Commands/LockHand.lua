-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "LockHand",
	Description = "Trade-lock copies of the held NON-FISH item (0 clears). Fish use untradehand.",
	Group = "Tester",
	Aliases = { "lockhand", "tradelock" },
	Args = {
		{
			Type = "number",
			Name = "count",
			Description = "How many copies to lock. Omit to lock the whole stack, 0 to clear.",
			Optional = true
		}
	}
}