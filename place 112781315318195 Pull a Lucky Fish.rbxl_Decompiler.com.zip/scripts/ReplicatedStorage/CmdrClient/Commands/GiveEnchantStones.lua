-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "GiveEnchantStones",
	Description = "Give Enchanting Stones to a player",
	Group = "Tester",
	Aliases = { "stones", "enchantstones" },
	Args = {
		{
			Type = "number",
			Name = "amount",
			Description = "Number of Enchanting Stones to add"
		},
		{
			Type = "player",
			Name = "target",
			Description = "Player to add Enchanting Stones to",
			Optional = true
		}
	}
}