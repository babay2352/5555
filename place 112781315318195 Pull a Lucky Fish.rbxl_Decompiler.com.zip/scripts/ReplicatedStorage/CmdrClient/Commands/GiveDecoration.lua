-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "GiveDecoration",
	Description = "Give a decoration to a player (with autocomplete)",
	Group = "Tester",
	Aliases = { "gd", "givedecoration" },
	Args = {
		{
			Type = "player",
			Name = "target",
			Description = "Player to give the decoration to"
		},
		{
			Type = "decoration",
			Name = "decoration",
			Description = "Decoration config name (autocomplete)"
		},
		{
			Type = "integer",
			Name = "amount",
			Description = "How many to give (default 1)",
			Optional = true
		}
	}
}