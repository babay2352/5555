-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "ban",
	Description = "Bans a player by UserId",
	Group = "Admin",
	Aliases = {},
	Args = {
		{
			Name = "userId",
			Type = "number",
			Description = "Player ID to ban",
			Optional = false
		},
		{
			Name = "reason",
			Type = "string",
			Description = "Ban reason",
			Optional = false
		}
	}
}