-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "ResetDailyRewards",
	Description = "Reset daily login rewards back to Day 1",
	Group = "Tester",
	Aliases = { "resetdaily", "dailyreset" },
	Args = {}
}