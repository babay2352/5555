-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "DeepsSpawnFish",
	Description = "Drops ONE giant copy of a fish somewhere in the Deeps pond on ALL servers and tells everyone to go find it",
	Group = "Tester",
	Aliases = { "deepsspawn", "deepsfish" },
	Args = {
		{
			Type = "fish",
			Name = "fish",
			Description = "Fish name (autocomplete) \226\128\148 any FishConfig fish"
		}
	}
}