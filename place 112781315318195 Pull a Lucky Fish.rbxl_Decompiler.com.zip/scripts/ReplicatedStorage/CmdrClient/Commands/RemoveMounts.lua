-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "RemoveMounts",
	Description = "Remove ALL mounts from a player\'s inventory",
	Group = "Tester",
	Aliases = { "removemounts", "clearmounts" },
	Args = {
		{
			Type = "player",
			Name = "target",
			Description = "Player to strip of mounts (defaults to you)",
			Optional = true
		}
	}
}