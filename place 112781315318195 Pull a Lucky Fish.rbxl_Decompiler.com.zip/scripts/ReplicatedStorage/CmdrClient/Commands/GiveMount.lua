-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "GiveMount",
	Description = "Give a mount to a player (with autocomplete)",
	Group = "Tester",
	Aliases = { "gm", "givemount" },
	Args = {
		{
			Type = "player",
			Name = "target",
			Description = "Player to give the mount to"
		},
		{
			Type = "mount",
			Name = "mount",
			Description = "Mount config name (autocomplete)"
		},
		{
			Type = "integer",
			Name = "amount",
			Description = "How many to give (default 1)",
			Optional = true
		}
	}
}