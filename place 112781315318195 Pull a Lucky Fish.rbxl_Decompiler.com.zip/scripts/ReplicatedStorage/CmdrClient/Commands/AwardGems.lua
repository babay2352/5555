-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "AwardGems",
	Description = "Award gems by userId - works even when the player is offline (they get a gift popup)",
	Group = "Tester",
	Aliases = { "awardgems" },
	Args = {
		{
			Type = "number",
			Name = "userId",
			Description = "UserId of the player to award"
		},
		{
			Type = "number",
			Name = "amount",
			Description = "Number of gems to award"
		}
	}
}