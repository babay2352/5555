-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "Enchant",
	Description = "Enchant the currently equipped rod or barbells (admin testing). Tier 0 removes it.",
	Group = "Tester",
	Aliases = { "enchant", "giveenchant" },
	Args = {
		{
			Type = "string",
			Name = "stat",
			Description = "Enchant stat id: Luck, Fortune, FastHook, QuickReel, Duplicator, EventHunter, BossHunter, PerfectCatcher, FasterRolling, Heavy, GymBuddy, FasterCombo, Explosive, ComboMaster, AutoClicker"
		},
		{
			Type = "number",
			Name = "tier",
			Description = "Tier 1-4, or 0 to remove the enchant"
		},
		{
			Type = "player",
			Name = "target",
			Description = "Player to enchant for (defaults to you)",
			Optional = true
		}
	}
}