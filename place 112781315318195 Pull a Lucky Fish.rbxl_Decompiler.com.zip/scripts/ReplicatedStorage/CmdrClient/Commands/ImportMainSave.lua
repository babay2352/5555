-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "ImportMainSave",
	Description = "TEST ONLY: overwrite your save here with your save from the MAIN game, then rejoin",
	Group = "Tester",
	Aliases = { "importsave", "copydb", "pulldb" },
	Args = {}
}