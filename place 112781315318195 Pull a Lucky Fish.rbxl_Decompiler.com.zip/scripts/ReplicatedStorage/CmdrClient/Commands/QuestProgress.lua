-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "QuestProgress",
	Description = "Add progress to every active quest on a tracker (QuestConfig.Trackers key)",
	Group = "Tester",
	Aliases = { "questprog", "questadd" },
	Args = {
		{
			Type = "string",
			Name = "tracker",
			Description = "Tracker key: FishCaught, CashEarned, Playtime, MutatedFishCaught, FishCollected"
		},
		{
			Type = "number",
			Name = "amount",
			Description = "How much progress to add"
		}
	}
}