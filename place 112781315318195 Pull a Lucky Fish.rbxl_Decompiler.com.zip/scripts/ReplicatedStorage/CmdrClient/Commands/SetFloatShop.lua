-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "SetFloatShop",
	Description = "Force-refresh float lootbox shop for ALL players. Use isGlobal=true for cross-server.",
	Group = "Tester",
	Aliases = { "sfs", "setfloatshop", "forcedshop" },
	Args = {
		{
			Type = "floatlootbox",
			Name = "slot1",
			Description = "Lootbox for slot 1 (autocomplete)"
		},
		{
			Type = "floatlootbox",
			Name = "slot2",
			Description = "Lootbox for slot 2 (defaults to slot1)",
			Optional = true
		},
		{
			Type = "floatlootbox",
			Name = "slot3",
			Description = "Lootbox for slot 3 (defaults to slot2)",
			Optional = true
		},
		{
			Type = "boolean",
			Name = "isGlobal",
			Description = "If true, applies to ALL servers (default false)",
			Optional = true
		}
	}
}