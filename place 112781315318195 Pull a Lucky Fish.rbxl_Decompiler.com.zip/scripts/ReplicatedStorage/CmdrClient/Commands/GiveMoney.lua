-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "GiveMoney",
	Description = "Give money (cash) to a player",
	Group = "Tester",
	Aliases = { "money", "addmoney", "cash", "givecash" },
	Args = {
		{
			Type = "number",
			Name = "amount",
			Description = "Amount of money to add"
		},
		{
			Type = "player",
			Name = "target",
			Description = "Player to add money to",
			Optional = true
		}
	}
}