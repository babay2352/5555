-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "SetLimitedStock",
	Description = "Set the GLOBAL remaining stock of a Limited Shop item (applies to ALL servers).",
	Group = "Tester",
	Aliases = { "limitedstock", "setlimitedstock" },
	Args = {
		{
			Type = "string",
			Name = "itemId",
			Description = "LimitedShopConfig item id = fish name; quote names with spaces (e.g. \"Void Squid\")"
		},
		{
			Type = "number",
			Name = "amount",
			Description = "New remaining stock (>= 0; 0 = sold out)"
		}
	}
}