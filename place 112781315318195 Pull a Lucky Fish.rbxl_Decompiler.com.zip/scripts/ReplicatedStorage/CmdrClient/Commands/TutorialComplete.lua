-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "TutorialComplete",
	Description = "Marks the whole tutorial as finished for a player",
	Group = "Tester",
	Aliases = { "finishtutorial", "skiptutorial" },
	Args = {
		{
			Type = "player",
			Name = "target",
			Description = "Player to finish the tutorial for",
			Optional = true
		}
	}
}