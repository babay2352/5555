-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "TradeHand",
	Description = "Unlock the fish you\'re holding so it can be traded and gifted again",
	Group = "Tester",
	Aliases = { "tradehand" },
	Args = {}
}