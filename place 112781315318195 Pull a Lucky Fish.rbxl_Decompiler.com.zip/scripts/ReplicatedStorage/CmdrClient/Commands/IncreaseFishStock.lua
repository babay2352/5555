-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "IncreaseFishStock",
	Description = "Increase Boss Fish Stock. Does nothing on non-boss fishes.",
	Group = "Tester",
	Aliases = { "fishstock", "fs" },
	Args = {
		{
			Type = "fish",
			Name = "fish",
			Description = "Fish name (autocomplete)"
		},
		{
			Type = "number",
			Name = "amount",
			Description = "Number of fish to add to stock (default 1)",
			Optional = true
		}
	}
}