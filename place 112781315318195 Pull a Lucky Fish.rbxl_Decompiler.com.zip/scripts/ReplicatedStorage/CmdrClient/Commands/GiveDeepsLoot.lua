-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "GiveDeepsLoot",
	Description = "Give a player every deeps loot item \226\128\148 the junk the processing machine turns into Enchant Stones",
	Group = "Tester",
	Aliases = { "deepsloot", "gdl" },
	Args = {
		{
			Type = "player",
			Name = "target",
			Description = "Player to give the loot to (default: you)",
			Optional = true
		},
		{
			Type = "number",
			Name = "amount",
			Description = "Copies of each item to give (default 1)",
			Optional = true
		}
	}
}