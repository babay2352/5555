-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local AlienEventConfig = require(ReplicatedStorage.shared.config.AlienEventConfig)
local GymEventConfig = require(ReplicatedStorage.shared.config.GymEventConfig)
local t = {
	pool = true,
	setpool = true,
	addpool = true,
	cycle = true,
	opengym = true,
	closegym = true,
	usegym = true
}
local t2 = {
	givecoins = "Coins to add \226\128\148 negative subtracts",
	givefuel = "Fuel to add to the ship\'s ground reserve",
	setupgrade = "Stage to set the upgrade track to",
	setpool = "Value to write straight into the server pool",
	addpool = "Points to add to the server pool",
	usegym = "Uses to burn off the gym\'s shared budget (walks stage promotions)"
}
local t3 = {
	[AlienEventConfig.EventId] = "info | givecoins | givefuel | setupgrade | endflight",
	[GymEventConfig.EventId] = "info | givecoins | pool | setpool | addpool | cycle (grade + RESET pool) | opengym (open now, keep pool) | closegym | usegym"
}

local function argValue(p1, p2) --[[ argValue | Line: 48 ]]
	local v1 = p1:GetArgument(p2)

	if v1 and v1:Validate() ~= false then
		return v1:GetValue()
	end

	return nil
end

return {
	Name = "Event",
	Description = "Admin actions for a live event (pick the event, then the action)",
	Group = "Tester",
	Aliases = { "event" },
	Args = {
		{
			Type = "liveEvent",
			Name = "event",
			Description = "Which event to act on"
		},
		function(p1) --[[ Line: 70 | Upvalues: AlienEventConfig (copy), GymEventConfig (copy), t3 (copy) ]]
			local v1 = p1:GetArgument(1)
			local v2 = if v1 and v1:Validate() ~= false then v1:GetValue() else nil
			local v4 = "commonEventAction"

			if v2 == AlienEventConfig.EventId then
				v4 = "alienEventAction"
			elseif v2 == GymEventConfig.EventId then
				v4 = "gymEventAction"
			end

			local t = {
				Name = "action",
				Type = v4
			}

			t.Description = if v2 then t3[v2] or "info | givecoins" else "info | givecoins"

			return t
		end,
		function(p1) --[[ Line: 85 | Upvalues: t2 (copy) ]]
			local v1 = p1:GetArgument(2)
			local v2 = if v1 and v1:Validate() ~= false then v1:GetValue() else nil
			local v4 = if v2 then t2[v2] else v2
			local t = {
				Type = "number",
				Name = "amount",
				Optional = true
			}

			t.Description = if v4 then v4 elseif v2 then ("Not used by \"%*\""):format(v2) else "Depends on the action"

			return t
		end,
		function(p1) --[[ Line: 96 | Upvalues: t (copy) ]]
			local v1 = p1:GetArgument(2)
			local v2 = if v1 and v1:Validate() ~= false then v1:GetValue() else nil
			local v4 = if v2 == nil then false else t[v2]
			local t2 = {
				Type = "player",
				Name = "target",
				Optional = true
			}

			t2.Description = if v4 then ("Not used \226\128\148 \"%*\" acts on the whole server"):format(v2) else "Player to act on (defaults to you)"

			return t2
		end,
		function(p1) --[[ Line: 112 ]]
			local v1 = p1:GetArgument(2)

			if (if v1 and v1:Validate() ~= false then v1:GetValue() else nil) == "setupgrade" then
				return {
					Type = "alienUpgrade",
					Name = "upgrade",
					Description = "Which upgrade track \226\128\148 pass the target AFTER amount, then this",
					Optional = true
				}
			end

			return nil
		end
	}
}