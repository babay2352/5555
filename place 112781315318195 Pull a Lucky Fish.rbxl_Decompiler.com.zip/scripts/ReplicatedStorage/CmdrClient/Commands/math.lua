-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "math",
	Description = "Perform a math operation on 2 values.",
	Group = "DefaultUtil",
	Aliases = {},
	AutoExec = { "alias \"+|Perform an addition.\" math + $1{number|Number} $2{number|Number}", "alias \"-|Perform a subtraction.\" math - $1{number|Number} $2{number|Number}", "alias \"*|Perform a multiplication.\" math * $1{number|Number} $2{number|Number}", "alias \"/|Perform a division.\" math / $1{number|Number} $2{number|Number}", "alias \"**|Perform an exponentiation.\" math ** $1{number|Number} $2{number|Number}", "alias \"%|Perform a modulus.\" math % $1{number|Number} $2{number|Number}" },
	Args = {
		{
			Type = "mathOperator",
			Name = "Operation",
			Description = "A math operation."
		},
		{
			Type = "number",
			Name = "Value",
			Description = "A number value."
		},
		{
			Type = "number",
			Name = "Value",
			Description = "A number value."
		}
	},
	ClientRun = function(p1, p2, p3, p4) --[[ ClientRun | Line: 32 ]]
		return p2.Perform(p3, p4)
	end
}