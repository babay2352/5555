-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "UnlockNextDay",
	Description = "Unlock the next daily login reward (resets claim timer)",
	Group = "Tester",
	Aliases = { "nextday", "dailynext" },
	Args = {}
}