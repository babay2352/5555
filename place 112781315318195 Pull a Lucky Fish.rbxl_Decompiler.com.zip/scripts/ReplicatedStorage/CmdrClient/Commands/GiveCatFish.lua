-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "GiveCatFish",
	Description = "Give yourself 10 Legendary Cat-mutated fish + 1 Rare Cat-mutated fish (test)",
	Group = "Tester",
	Aliases = { "gcf", "givecatfish" },
	Args = {}
}