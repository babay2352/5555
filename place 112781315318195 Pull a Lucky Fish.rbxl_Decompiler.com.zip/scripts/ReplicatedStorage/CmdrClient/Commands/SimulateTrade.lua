-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "SimulateTrade",
	Description = "Deliver a fish through the real p2p trade path (secureModifyInventory) with no second player needed",
	Group = "Tester",
	Aliases = { "simulatetrade", "testtrade" },
	Args = {
		{
			Type = "player",
			Name = "target",
			Description = "Player who receives the fish (pick yourself to test it)"
		},
		{
			Type = "fish",
			Name = "fish",
			Description = "Fish to receive (default: the lowest-rarity fish)",
			Optional = true
		},
		{
			Type = "mutation",
			Name = "mutation",
			Description = "Mutation name (optional)",
			Optional = true
		},
		{
			Type = "number",
			Name = "level",
			Description = "Fish level (default 1)",
			Optional = true
		}
	}
}