-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "LockWorld",
	Description = "Re-locks a bought world unlock (undoes the World 2 board purchase; rejoin to see the board again)",
	Group = "Tester",
	Aliases = { "lockworld2", "resetworldunlock" },
	Args = {
		{
			Type = "number",
			Name = "worldId",
			Description = "World id to lock again (default 2)",
			Optional = true
		},
		{
			Type = "player",
			Name = "target",
			Description = "Player to lock the world for",
			Optional = true
		}
	}
}