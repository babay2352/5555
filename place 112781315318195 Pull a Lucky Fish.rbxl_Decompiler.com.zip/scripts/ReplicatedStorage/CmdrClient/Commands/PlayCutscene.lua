-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "PlayCutscene",
	Description = "Play the tutorial intro cutscene for a player (admin testing)",
	Group = "Tester",
	Aliases = { "cutscene", "playcutscene" },
	Args = {
		{
			Type = "player",
			Name = "target",
			Description = "Player to play the cutscene for (defaults to you)",
			Optional = true
		},
		{
			Type = "integer",
			Name = "scene",
			Description = "Scene number to start from (defaults to the first)",
			Optional = true
		}
	}
}