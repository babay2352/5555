-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "GiveFish",
	Description = "Give a fish to a player (with autocomplete)",
	Group = "Tester",
	Aliases = { "gf", "givefish" },
	Args = {
		{
			Type = "player",
			Name = "target",
			Description = "Player to give the fish to"
		},
		{
			Type = "fish",
			Name = "fish",
			Description = "Fish name (autocomplete)"
		},
		{
			Type = "number",
			Name = "amount",
			Description = "Number of fish to give (default 1)",
			Optional = true
		},
		{
			Type = "mutation",
			Name = "mutation",
			Description = "Mutation name (optional)",
			Optional = true
		}
	}
}