-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "LockVillage",
	Description = "Re-locks the fishing village board purchase (rejoin to see the board and ropes again)",
	Group = "Tester",
	Aliases = { "lockfishingvillage", "resetvillageunlock" },
	Args = {
		{
			Type = "player",
			Name = "target",
			Description = "Player to lock the village for",
			Optional = true
		}
	}
}