-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "StartEvent",
	Description = "Start a weather event for everyone",
	Group = "Tester",
	Aliases = { "startevent", "StartEvent", "weather" },
	Args = {
		{
			Name = "weather",
			Type = "weather",
			Description = "Which weather to start",
			Optional = false
		},
		{
			Name = "duration",
			Type = "number",
			Description = "Override duration in seconds (defaults to the weather\'s BasicDuration)",
			Optional = true
		}
	}
}