-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "Luck",
	Description = "Activate a server-wide Luck boost for a set duration (broadcast to every running server)",
	Group = "Tester",
	Aliases = { "luck", "Luck", "GiveLuck" },
	Args = {
		{
			Name = "luckLevel",
			Type = "number",
			Description = "Luck multiplier (e.g. 2, 5, 10). Stacks additively with golden / gamepass / event luck.",
			Optional = false
		},
		{
			Name = "luckDuration",
			Type = "number",
			Description = "Duration in seconds the luck lasts",
			Optional = false
		}
	}
}