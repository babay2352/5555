-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "AdminMessage",
	Description = "Send global notification",
	Group = "Admin",
	Aliases = { "msg", "Msg", "Amsg" },
	Args = {
		{
			Name = "msg",
			Type = "strings",
			Description = "What MSG you want to send",
			Optional = false
		}
	}
}