-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "Purchases",
	Description = "Show a player\'s logged Robux receipts (newest first)",
	Group = "Tester",
	Aliases = { "purchases", "receipts" },
	Args = {
		{
			Type = "player",
			Name = "target",
			Description = "Player whose receipt log to read"
		}
	}
}