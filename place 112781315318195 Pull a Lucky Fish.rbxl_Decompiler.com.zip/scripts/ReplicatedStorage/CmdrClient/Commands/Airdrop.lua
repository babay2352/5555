-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "Airdrop",
	Description = "Launches the airdrop on ALL servers: announcement toast, then plane fly-over + cutscene, one-time chest on DropZone",
	Group = "Tester",
	Aliases = { "airdrop", "startairdrop" },
	Args = {
		{
			Type = "string",
			Name = "loot",
			Description = "What the chest holds: money, gems, fish, stones \226\128\148 or \'clear\' to remove the active airdrop"
		},
		{
			Type = "string",
			Name = "value",
			Description = "money/gems/stones: the amount. fish: the fish name",
			Optional = true
		},
		{
			Type = "number",
			Name = "amount",
			Description = "fish only: how many (default 1)",
			Optional = true
		},
		{
			Type = "string",
			Name = "mutation",
			Description = "fish only: mutation name (optional)",
			Optional = true
		}
	}
}