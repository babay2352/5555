-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "StopLuck",
	Description = "End any active admin Luck early (broadcast to every running server)",
	Group = "Tester",
	Aliases = { "stopluck", "StopLuck", "EndLuck" },
	Args = {}
}