-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "ForceRestockShop",
	Description = "Force restock the float lootbox shop. Use isGlobal=true for cross-server.",
	Group = "Tester",
	Aliases = { "restock", "forcerestock", "restockshop" },
	Args = {
		{
			Type = "boolean",
			Name = "isGlobal",
			Description = "If true, restocks on ALL servers (default false)",
			Optional = true
		}
	}
}