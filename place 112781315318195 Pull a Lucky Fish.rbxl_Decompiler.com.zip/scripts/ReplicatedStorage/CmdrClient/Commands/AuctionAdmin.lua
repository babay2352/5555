-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "AuctionAdmin",
	Description = "Auction House admin: info | settle | setstock <slot> <amount> | refundcheck <player>",
	Group = "Tester",
	Aliases = { "auction", "ah" },
	Args = {
		{
			Type = "string",
			Name = "action",
			Description = "info | settle | setstock | refundcheck"
		},
		{
			Type = "string",
			Name = "slot",
			Description = "setstock: classic slot id (e.g. C1)",
			Optional = true
		},
		{
			Type = "number",
			Name = "amount",
			Description = "setstock: absolute remaining stock",
			Optional = true
		},
		{
			Type = "player",
			Name = "target",
			Description = "refundcheck: player to reconcile",
			Optional = true
		}
	}
}