-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "RefuelAllPlayers",
	Description = "Fill every player\'s Alien Event fuel reserve to max (optionally on all servers)",
	Group = "Tester",
	Aliases = { "refuelallplayers", "refuelall" },
	Args = {
		{
			Name = "global",
			Type = "boolean",
			Description = "If true, refuel on ALL servers; if false, only this server",
			Optional = true,
			Default = true
		}
	}
}