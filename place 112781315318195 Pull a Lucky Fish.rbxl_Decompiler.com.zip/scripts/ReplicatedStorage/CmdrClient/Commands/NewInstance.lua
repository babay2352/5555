-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "NewInstance",
	Description = "Teleport yourself into a brand-new reserved server instance (cross-server testing).",
	Group = "Tester",
	Aliases = { "newserver", "ns", "newinstance" },
	Args = {}
}