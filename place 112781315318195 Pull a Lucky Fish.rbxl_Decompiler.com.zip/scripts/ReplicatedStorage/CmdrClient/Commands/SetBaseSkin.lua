-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "SetBaseSkin",
	Description = "Unlock and equip a base skin on a player (use \'default\' to remove it)",
	Group = "Tester",
	Aliases = { "sbs", "setbaseskin", "baseskin" },
	Args = {
		{
			Type = "player",
			Name = "target",
			Description = "Player whose base skin to set"
		},
		{
			Type = "baseSkin",
			Name = "skin",
			Description = "Base skin config name, or \'default\' to go back to the plain base"
		}
	}
}