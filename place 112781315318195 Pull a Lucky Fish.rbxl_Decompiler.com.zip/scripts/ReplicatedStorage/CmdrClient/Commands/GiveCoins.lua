-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "GiveCoins",
	Description = "Give event coins to a player (current event unless one is named)",
	Group = "Tester",
	Aliases = { "coins", "addcoins", "catcoins" },
	Args = {
		{
			Type = "number",
			Name = "amount",
			Description = "Coins to add \226\128\148 negative subtracts"
		},
		{
			Type = "player",
			Name = "target",
			Description = "Player to add coins to (defaults to you)",
			Optional = true
		},
		{
			Type = "liveEvent",
			Name = "event",
			Description = "Which event\'s coins (defaults to the current EventConfig event)",
			Optional = true
		}
	}
}