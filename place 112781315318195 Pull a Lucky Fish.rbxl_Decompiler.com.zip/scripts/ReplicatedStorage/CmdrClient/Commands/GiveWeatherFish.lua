-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "GiveWeatherFish",
	Description = "Give yourself all fish required by every weather in the Weather Machine",
	Group = "Tester",
	Aliases = { "gwf", "giveweatherfish" },
	Args = {}
}