-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "SimulateGift",
	Description = "Put a fake gift offer on a player\'s screen \226\128\148 the real popup, GiftId and accept path, with no second player needed",
	Group = "Tester",
	Aliases = { "simulategift", "testgift" },
	Args = {
		{
			Type = "player",
			Name = "target",
			Description = "Player who gets the offer popup (pick yourself to test it)"
		},
		{
			Type = "fish",
			Name = "fish",
			Description = "Fish to offer (default: the lowest-rarity fish)",
			Optional = true
		},
		{
			Type = "mutation",
			Name = "mutation",
			Description = "Mutation name (optional)",
			Optional = true
		},
		{
			Type = "string",
			Name = "from",
			Description = "Name the popup credits the gift to (default: you)",
			Optional = true
		}
	}
}