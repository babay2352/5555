-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "GiveFishRod",
	Description = "Give a fishing rod to a player (with autocomplete), bypassing shop cost/Premium",
	Group = "Tester",
	Aliases = { "gfr", "givefishrod", "giverod" },
	Args = {
		{
			Type = "player",
			Name = "target",
			Description = "Player to give the rod to"
		},
		{
			Type = "fishrod",
			Name = "fishRod",
			Description = "Fish rod config name (autocomplete)"
		},
		{
			Type = "boolean",
			Name = "equip",
			Description = "Equip it immediately (default true)",
			Optional = true
		}
	}
}