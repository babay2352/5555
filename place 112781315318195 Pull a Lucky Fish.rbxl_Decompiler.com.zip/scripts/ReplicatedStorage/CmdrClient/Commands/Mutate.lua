-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "Mutate",
	Description = "Throw a mutation grenade for everyone (cross-server). Announces the admin and plays the throw ceremony.",
	Group = "Tester",
	Aliases = { "mutate", "Mutate", "MutationThrow" },
	Args = {
		{
			Name = "mutation",
			Type = "mutation",
			Description = "Which mutation to throw",
			Optional = false
		},
		{
			Name = "chance",
			Type = "number",
			Description = "Chance for the mutation to roll, 0-1 (e.g. 0.25 = 25%)",
			Optional = false
		}
	}
}