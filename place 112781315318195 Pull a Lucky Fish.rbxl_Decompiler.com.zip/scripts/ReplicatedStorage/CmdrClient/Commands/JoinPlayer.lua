-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "JoinPlayer",
	Description = "Teleport yourself to any player in the game (username or userId)",
	Group = "Tester",
	Aliases = { "joinplayer", "jp", "goto" },
	Args = {
		{
			Type = "string",
			Name = "user",
			Description = "Username or userId of the player to join"
		}
	}
}