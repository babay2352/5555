-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "SetRebirth",
	Description = "Sets a player\'s rebirth level (clamped to the configured range)",
	Group = "Tester",
	Aliases = { "rebirth", "setrebirthlevel" },
	Args = {
		{
			Type = "number",
			Name = "level",
			Description = "Rebirth level to set"
		},
		{
			Type = "player",
			Name = "target",
			Description = "Player to set the rebirth level for",
			Optional = true
		}
	}
}