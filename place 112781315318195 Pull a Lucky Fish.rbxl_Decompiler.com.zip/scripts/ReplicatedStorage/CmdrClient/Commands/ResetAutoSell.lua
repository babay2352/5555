-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "ResetAutoSell",
	Description = "Reset player\'s Auto Sell status (locks it again)",
	Group = "Tester",
	Aliases = { "removeautosell", "lockautosell" },
	Args = {
		{
			Type = "player",
			Name = "target",
			Description = "Player to reset Auto Sell for",
			Optional = true
		}
	}
}