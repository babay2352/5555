-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "fetch",
	Description = "Fetch a value from the Internet",
	Group = "DefaultDebug",
	Aliases = {},
	Args = {
		{
			Type = "url",
			Name = "URL",
			Description = "The URL to fetch."
		}
	}
}