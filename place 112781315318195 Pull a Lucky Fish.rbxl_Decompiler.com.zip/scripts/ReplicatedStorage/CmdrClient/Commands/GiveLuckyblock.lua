-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "GiveLuckyblock",
	Description = "Give a luckyblock to a player (with autocomplete)",
	Group = "Tester",
	Aliases = { "glb", "givelb", "givelucky" },
	Args = {
		{
			Type = "player",
			Name = "target",
			Description = "Player to give the luckyblock to"
		},
		{
			Type = "luckyblock",
			Name = "luckyblock",
			Description = "Luckyblock config name (autocomplete)"
		},
		{
			Type = "number",
			Name = "amount",
			Description = "Number of luckyblocks to give (default 1)",
			Optional = true
		}
	}
}