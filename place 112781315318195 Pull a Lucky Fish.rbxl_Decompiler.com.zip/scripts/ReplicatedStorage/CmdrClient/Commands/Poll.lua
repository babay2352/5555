-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "Poll",
	Description = "Start a server-wide two-option poll (broadcast to every running server)",
	Group = "Admin",
	Aliases = { "poll", "vote" },
	Args = {
		{
			Name = "question",
			Type = "string",
			Description = "The question shown at the top of the poll",
			Optional = false
		},
		{
			Name = "option1",
			Type = "string",
			Description = "Text for the first option",
			Optional = false
		},
		{
			Name = "option2",
			Type = "string",
			Description = "Text for the second option",
			Optional = false
		}
	}
}