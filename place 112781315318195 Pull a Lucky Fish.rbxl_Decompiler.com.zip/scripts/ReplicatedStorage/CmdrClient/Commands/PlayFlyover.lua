-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "PlayFlyover",
	Description = "Replays the fishing village fly-by (camera only \226\128\148 nothing is bought, unlocked or destroyed)",
	Group = "Tester",
	Aliases = { "flyover", "playvillageflyover" },
	Args = {
		{
			Type = "player",
			Name = "target",
			Description = "Player to play the fly-by for",
			Optional = true
		}
	}
}