-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "DeepsSpawnItem",
	Description = "Drops ONE extra copy of a deeps loot item in the pond on ALL servers \226\128\148 outside the item limit \226\128\148 and tells everyone to go grab it",
	Group = "Tester",
	Aliases = { "deepsspawnitem", "deepsitem" },
	Args = {
		{
			Type = "deepsLoot",
			Name = "item",
			Description = "Loot item key (autocomplete) \226\128\148 any DeepsLootConfig item"
		},
		{
			Type = "deepsZone",
			Name = "zone",
			Description = "Dive zone to drop it in (default: a random spot anywhere in the pond)",
			Optional = true
		}
	}
}