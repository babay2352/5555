-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "uptime",
	Description = "Returns the amount of time the server has been running.",
	Group = "DefaultDebug",
	Aliases = {},
	Args = {}
}