-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "SetPaidTrading",
	Description = "Overrides PolicyService IsPaidItemTradingAllowed for a player on this server (testing). true/false to force, clear to use the real policy again.",
	Group = "Tester",
	Aliases = { "setpaidtrading", "paidtrading" },
	Args = {
		{
			Type = "string",
			Name = "allowed",
			Description = "true, false, or clear"
		},
		{
			Type = "player",
			Name = "target",
			Description = "Player to override. Defaults to you.",
			Optional = true
		}
	}
}