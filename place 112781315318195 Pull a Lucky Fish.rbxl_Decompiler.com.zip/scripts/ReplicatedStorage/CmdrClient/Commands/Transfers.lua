-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "Transfers",
	Description = "Show a player\'s logged trades and gifts (newest first)",
	Group = "Tester",
	Aliases = { "transfers", "tradelog" },
	Args = {
		{
			Type = "player",
			Name = "target",
			Description = "Player whose transfer log to read"
		}
	}
}