-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "SetStrength",
	Description = "Set the strength of a player",
	Group = "Tester",
	Aliases = { "strength", "setstr", "setstrength" },
	Args = {
		{
			Type = "number",
			Name = "amount",
			Description = "The strength value to set"
		},
		{
			Type = "player",
			Name = "target",
			Description = "Player to set strength for",
			Optional = true
		}
	}
}