-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "AwardFish",
	Description = "Award fish by userId - works even when the player is offline (they get a gift popup)",
	Group = "Tester",
	Aliases = { "awardfish" },
	Args = {
		{
			Type = "number",
			Name = "userId",
			Description = "UserId of the player to award"
		},
		{
			Type = "fish",
			Name = "fish",
			Description = "Fish name (autocomplete)"
		},
		{
			Type = "number",
			Name = "amount",
			Description = "Number of fish to award (default 1)",
			Optional = true
		},
		{
			Type = "mutation",
			Name = "mutation",
			Description = "Mutation name (optional)",
			Optional = true
		}
	}
}