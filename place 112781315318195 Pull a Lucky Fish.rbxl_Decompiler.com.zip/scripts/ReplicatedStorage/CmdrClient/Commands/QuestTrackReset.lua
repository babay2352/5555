-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "QuestTrackReset",
	Description = "Send the quest milestone track (CollectBar) back to zero, leaving today\'s quests alone",
	Group = "Tester",
	Aliases = { "trackreset", "resettrack" },
	Args = {}
}