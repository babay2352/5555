-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "DailyQuestComplete",
	Description = "Auto-complete all active daily quests",
	Group = "Tester",
	Aliases = { "completeall", "finishquests" },
	Args = {}
}