-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
return {
	Name = "GiveLootbox",
	Description = "Give a float lootbox to a player, or ALL players (isGlobal=true)",
	Group = "Tester",
	Aliases = { "gl", "givelootbox", "givecrate" },
	Args = {
		{
			Type = "floatlootbox",
			Name = "lootbox",
			Description = "Lootbox config name (autocomplete)"
		},
		{
			Type = "player",
			Name = "target",
			Description = "Player to give to (ignored when isGlobal=true)",
			Optional = true
		},
		{
			Type = "number",
			Name = "amount",
			Description = "Number of lootboxes to give (default 1)",
			Optional = true
		},
		{
			Type = "boolean",
			Name = "isGlobal",
			Description = "If true, gives to ALL players on ALL servers (default false)",
			Optional = true
		}
	}
}