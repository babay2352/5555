-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local BaseSkinConfig = require(ReplicatedStorage.shared.config.BaseSkinConfig)

return function(p1) --[[ Line: 4 | Upvalues: BaseSkinConfig (copy) ]]
	local t = { "default" }

	for v1 in BaseSkinConfig.Config do
		table.insert(t, v1)
	end

	p1:RegisterType("baseSkin", p1.Cmdr.Util.MakeEnumType("baseSkin", t))
end