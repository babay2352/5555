-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local ServerScriptService = game:GetService("ServerScriptService")
local CheckCMDRPerms = require(ReplicatedStorage.shared.module.CheckCMDRPerms)
local v1 = if RunService:IsServer() then require(ServerScriptService.module.ServerPlayerData) else require(ReplicatedStorage.client.ClientPlayerData)
local CommandPermissionLevel = CheckCMDRPerms.CommandPermissionLevel
local t = {
	Help = 0,
	DefaultAdmin = CommandPermissionLevel.Admin,
	DefaultDebug = CommandPermissionLevel.Admin,
	UserAlias = CommandPermissionLevel.Admin,
	DefaultUtil = CommandPermissionLevel.Tester
}

return function(p1) --[[ Line: 29 | Upvalues: t (copy), CommandPermissionLevel (copy), CheckCMDRPerms (copy), RunService (copy), v1 (ref) ]]
	p1:RegisterHook("BeforeRun", function(p1) --[[ Line: 30 | Upvalues: t (ref), CommandPermissionLevel (ref), CheckCMDRPerms (ref), RunService (ref), v1 (ref) ]]
		if CheckCMDRPerms.CheckPlayerPermissionLevel(p1.Executor) < (t[p1.Group] or (CommandPermissionLevel[p1.Group] or CommandPermissionLevel.Admin)) then
			return "You don\'t have permission to run this command!"
		end

		local v2 = if RunService:IsClient() then v1.serverProfile:getState() else v1.GetPlayerProfile(p1.Executor).producer:getState()

		if v2.adminCoolDowns[p1.Name] and v2.adminCoolDowns[p1.Name] > workspace:GetServerTimeNow() then
			return ("Command is on %* cooldown"):format(v2.adminCoolDowns[p1.Name] - workspace:GetServerTimeNow())
		end

		return
	end)
end