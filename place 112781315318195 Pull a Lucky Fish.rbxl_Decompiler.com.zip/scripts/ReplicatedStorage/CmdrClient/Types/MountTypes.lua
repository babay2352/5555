-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local MountConfig = require(ReplicatedStorage.shared.config.MountConfig)

return function(p1) --[[ Line: 4 | Upvalues: MountConfig (copy) ]]
	local t = {}

	for k, v in pairs(MountConfig) do
		table.insert(t, k)
	end

	p1:RegisterType("mount", p1.Cmdr.Util.MakeEnumType("mount", t))
end