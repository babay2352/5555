-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local WeatherRegistry = require(ReplicatedStorage.shared.weather.WeatherRegistry)

return function(p1) --[[ Line: 4 | Upvalues: WeatherRegistry (copy) ]]
	local t = {}

	for v1 in WeatherRegistry.Modules do
		table.insert(t, v1)
	end

	p1:RegisterType("weather", p1.Cmdr.Util.MakeEnumType("weather", t))
end