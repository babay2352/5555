-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local FishRodConfig = require(ReplicatedStorage.shared.config.FishRodConfig)

return function(p1) --[[ Line: 4 | Upvalues: FishRodConfig (copy) ]]
	local t = {}

	for k, v in pairs(FishRodConfig) do
		table.insert(t, k)
	end

	p1:RegisterType("fishrod", p1.Cmdr.Util.MakeEnumType("fishrod", t))
end