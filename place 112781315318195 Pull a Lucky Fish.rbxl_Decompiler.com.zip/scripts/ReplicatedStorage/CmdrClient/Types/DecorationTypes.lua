-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local DecorationConfig = require(ReplicatedStorage.shared.config.DecorationConfig)

return function(p1) --[[ Line: 7 | Upvalues: DecorationConfig (copy) ]]
	local t = {}

	for k in pairs(DecorationConfig) do
		table.insert(t, k)
	end

	table.sort(t)
	p1:RegisterType("decoration", p1.Cmdr.Util.MakeEnumType("decoration", t))
end