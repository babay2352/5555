-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local AlienEventConfig = require(ReplicatedStorage.shared.config.AlienEventConfig)
local EventConfig = require(ReplicatedStorage.shared.config.EventConfig)
local LiveEventRegistry = require(ReplicatedStorage.shared.config.LiveEventRegistry)

return function(p1) --[[ Line: 9 | Upvalues: LiveEventRegistry (copy), EventConfig (copy), AlienEventConfig (copy) ]]
	local t = {}
	local t2 = {}

	for v1 in LiveEventRegistry.Events do
		t[v1] = true
		table.insert(t2, v1)
	end

	if not t[EventConfig.Event.Id] then
		table.insert(t2, EventConfig.Event.Id)
	end

	table.sort(t2)
	p1:RegisterType("liveEvent", p1.Cmdr.Util.MakeEnumType("liveEvent", t2))

	local t3 = { "info", "givecoins" }

	local function withCommon(p1) --[[ withCommon | Line: 32 | Upvalues: t3 (copy) ]]
		local v1 = table.clone(t3)

		for v2, v3 in p1 do
			table.insert(v1, v3)
		end

		return v1
	end

	p1:RegisterType("commonEventAction", p1.Cmdr.Util.MakeEnumType("commonEventAction", t3))

	local v2 = table.clone(t3)

	for v5, v6 in { "givefuel", "setupgrade", "endflight" } do
		table.insert(v2, v6)
	end

	p1:RegisterType("alienEventAction", p1.Cmdr.Util.MakeEnumType("alienEventAction", v2))

	local v7 = table.clone(t3)

	for v10, v11 in { "pool", "setpool", "addpool", "cycle", "opengym", "closegym", "usegym" } do
		table.insert(v7, v11)
	end

	p1:RegisterType("gymEventAction", p1.Cmdr.Util.MakeEnumType("gymEventAction", v7))

	local t4 = {}

	for v12 in AlienEventConfig.Upgrades do
		table.insert(t4, v12)
	end

	table.sort(t4)
	p1:RegisterType("alienUpgrade", p1.Cmdr.Util.MakeEnumType("alienUpgrade", t4))
end