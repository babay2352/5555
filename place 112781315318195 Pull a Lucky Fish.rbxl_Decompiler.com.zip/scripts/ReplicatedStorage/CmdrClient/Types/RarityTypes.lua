-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local rarityConfig = require(ReplicatedStorage.shared.config.rarityConfig)

return function(p1) --[[ Line: 7 | Upvalues: rarityConfig (copy) ]]
	local t = {}

	for v1 in rarityConfig do
		table.insert(t, v1)
	end

	table.sort(t)
	p1:RegisterType("rarity", p1.Cmdr.Util.MakeEnumType("rarity", t))
end