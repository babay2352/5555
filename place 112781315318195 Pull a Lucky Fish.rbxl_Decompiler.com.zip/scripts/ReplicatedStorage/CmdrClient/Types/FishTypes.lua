-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local FishConfig = require(ReplicatedStorage.shared.config.FishConfig)

return function(p1) --[[ Line: 8 | Upvalues: FishConfig (copy) ]]
	local t = {}

	for k, v in pairs(FishConfig) do
		table.insert(t, k)
	end

	p1:RegisterType("fish", p1.Cmdr.Util.MakeEnumType("fish", t))
end