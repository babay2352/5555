-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local DeepsConfig = require(ReplicatedStorage.shared.config.DeepsConfig)
local DeepsLootConfig = require(ReplicatedStorage.shared.config.DeepsLootConfig)

return function(p1) --[[ Line: 8 | Upvalues: DeepsLootConfig (copy), DeepsConfig (copy) ]]
	local t = {}

	for k in pairs(DeepsLootConfig.Items) do
		table.insert(t, k)
	end

	table.sort(t)
	p1:RegisterType("deepsLoot", p1.Cmdr.Util.MakeEnumType("deepsLoot", t))

	local t2 = {}

	for i, v in ipairs(DeepsConfig.Zones) do
		table.insert(t2, v.DisplayName)
	end

	p1:RegisterType("deepsZone", p1.Cmdr.Util.MakeEnumType("deepsZone", t2))
end