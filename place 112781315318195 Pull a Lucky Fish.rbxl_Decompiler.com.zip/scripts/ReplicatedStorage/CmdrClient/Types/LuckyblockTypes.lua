-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local LuckyblockConfig = require(ReplicatedStorage.shared.config.LuckyblockConfig)

return function(p1) --[[ Line: 4 | Upvalues: LuckyblockConfig (copy) ]]
	local t = {}

	for k, v in pairs(LuckyblockConfig) do
		if typeof(v) == "table" then
			table.insert(t, k)
		end
	end

	p1:RegisterType("luckyblock", p1.Cmdr.Util.MakeEnumType("luckyblock", t))
end