-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local ServerScriptService = game:GetService("ServerScriptService")
local CheckCMDRPerms = require(ReplicatedStorage.shared.module.CheckCMDRPerms)
local v1 = if RunService:IsServer() then require(ServerScriptService.module.ServerPlayerData) else require(ReplicatedStorage.client.ClientPlayerData)

return function(p1) --[[ Line: 18 | Upvalues: CheckCMDRPerms (copy), RunService (copy), v1 (ref) ]]
	p1:RegisterHook("AfterRun", function(p1) --[[ Line: 19 | Upvalues: CheckCMDRPerms (ref), RunService (ref), v1 (ref) ]]
		local v12 = CheckCMDRPerms.CheckPlayerPermissionLevel(p1.Executor)
		local v2 = if CheckCMDRPerms.CoolDowns[p1.Name] and CheckCMDRPerms.CoolDowns[p1.Name][v12] then CheckCMDRPerms.CoolDowns[p1.Name][v12] else 0
		local v3

		if RunService:IsClient() then
			v3 = v1.serverProfile
		else
			local v4 = v1.GetPlayerProfile(p1.Executor)

			if not v4 then
				return
			end

			v3 = v4.producer
		end

		v3.secureSetCoolDown(p1.Name, workspace:GetServerTimeNow() + v2)
	end)
end