-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local MutationConfig = require(ReplicatedStorage.shared.config.MutationConfig)

return function(p1) --[[ Line: 4 | Upvalues: MutationConfig (copy) ]]
	local t = {}

	for k in pairs(MutationConfig.Mutations) do
		table.insert(t, k)
	end

	p1:RegisterType("mutation", p1.Cmdr.Util.MakeEnumType("mutation", t))
end