-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local FloatLootboxConfig = require(ReplicatedStorage.shared.config.FloatLootboxConfig)

return function(p1) --[[ Line: 4 | Upvalues: FloatLootboxConfig (copy) ]]
	local t = {}

	for k, v in pairs(FloatLootboxConfig.Lootboxes) do
		table.insert(t, k)
	end

	p1:RegisterType("floatlootbox", p1.Cmdr.Util.MakeEnumType("floatlootbox", t))
end