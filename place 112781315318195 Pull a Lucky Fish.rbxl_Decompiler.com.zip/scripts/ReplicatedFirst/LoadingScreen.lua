-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- https://lua.expert/
local ContentProvider = game:GetService("ContentProvider")
local Lighting = game:GetService("Lighting")
local Players = game:GetService("Players")
local ReplicatedFirst = game:GetService("ReplicatedFirst")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local SoundService = game:GetService("SoundService")
local StarterGui = game:GetService("StarterGui")
local TweenService = game:GetService("TweenService")
local t = {
	MinimumTime = 6,
	FillSpeed = 0.35,
	WaitingCap = 0.45,
	WaitingSpeed = 0.1,
	PreloadBatchSize = 30,
	PreloadTimeout = 30,
	CameraPanDegrees = 30,
	PulseScale = 1.15,
	PulseTime = 0.18,
	PulseSound = "rbxassetid://127206638613979",
	PulseSoundVolume = 0.15,
	PulseSoundPitchStep = 0.13,
	CastShotSound = "rbxassetid://140530009847955",
	CastShotVolume = 0.2,
	CastReleaseSound = "rbxassetid://119135010875996",
	CastReleaseVolume = 0.28,
	CastReleaseStart = 0.4,
	CastReleaseDelay = 0.8,
	SplashSound = "rbxassetid://83673781452193",
	SplashVolume = 0.3,
	SplashLead = 0.1,
	FadeOutTime = 0.4,
	BlurSize = 24,
	CameraPartName = "LoadingScreenCameraPos",
	ReplicatedFirstTimeout = 3,
	Milestones = {
		{
			progress = 0.25,
			image = "rbxassetid://84283602331558"
		},
		{
			progress = 0.5,
			image = "rbxassetid://132455876009105"
		},
		{
			progress = 0.75,
			image = "rbxassetid://135899470608336"
		}
	}
}
local LocalPlayer = Players.LocalPlayer

if RunService:IsStudio() then
	LocalPlayer:SetAttribute("LoadingScreenFinished", true)

	return
end

local PlayerGui = LocalPlayer:WaitForChild("PlayerGui")

local function findFallbackCopy(p1) --[[ findFallbackCopy | Line: 84 | Upvalues: ReplicatedStorage (copy) ]]
	local v1 = ReplicatedStorage:WaitForChild("shared", 10)
	local v2 = if v1 then v1:WaitForChild("model", 10) else v1
	local v3 = if v2 then v2:WaitForChild("LoadingScreenFallbackCopy", 10) else v2
	local v4 = if v3 then v3:WaitForChild(p1, 10) else v3

	if not v4 then
		return v4
	end

	warn((("LoadingScreen: \"%*\" missing in ReplicatedFirst, using fallback copy from ReplicatedStorage"):format(p1)))

	return v4
end

local LoadingScreen = ReplicatedFirst:WaitForChild("LoadingScreen", t.ReplicatedFirstTimeout)

if not LoadingScreen then
	local v1 = findFallbackCopy("LoadingScreen")

	LoadingScreen = v1 and v1:Clone()
end

if not LoadingScreen then
	warn("LoadingScreen: no gui found in ReplicatedFirst or the fallback copy, aborting")
	LocalPlayer:SetAttribute("LoadingScreenFinished", true)

	return
end

local v3 = LoadingScreen
local Frame = v3:WaitForChild("Frame")
local BarFrame = Frame:WaitForChild("BarFrame")
local FillerBar = BarFrame:WaitForChild("FillerBar")
local HookImage = Frame:WaitForChild("HookImage")
local Size = HookImage.Size
local Y = HookImage.Position.Y

v3.ResetOnSpawn = false
v3.IgnoreGuiInset = true
v3.DisplayOrder = 1000
HookImage.ZIndex = 5
FillerBar.Size = UDim2.fromScale(0, 1)
v3.Parent = PlayerGui
ReplicatedFirst:RemoveDefaultLoadingScreen()

local LoadingScreenBlur = Instance.new("BlurEffect")

LoadingScreenBlur.Name = "LoadingScreenBlur"
LoadingScreenBlur.Size = t.BlurSize
LoadingScreenBlur.Parent = Lighting

local t2 = {}

local function hideOtherGui(p1) --[[ hideOtherGui | Line: 134 | Upvalues: v3 (copy), t2 (copy) ]]
	if not p1:IsA("ScreenGui") then
		return
	end

	if p1 == v3 or not p1.Enabled then
		return
	end

	p1.Enabled = false
	t2[p1] = true
end

local function sweepOtherGuis() --[[ sweepOtherGuis | Line: 147 | Upvalues: PlayerGui (copy), v3 (copy), t2 (copy) ]]
	for v1, v2 in PlayerGui:GetChildren() do
		if v2:IsA("ScreenGui") and (v2 ~= v3 and v2.Enabled) then
			v2.Enabled = false
			t2[v2] = true
		end
	end
end

for v4, v5 in PlayerGui:GetChildren() do
	if v5:IsA("ScreenGui") and (v5 ~= v3 and v5.Enabled) then
		v5.Enabled = false
		t2[v5] = true
	end
end

local v6 = PlayerGui.ChildAdded:Connect(hideOtherGui)
local t3 = {}

for v7, v8 in Enum.CoreGuiType:GetEnumItems() do
	if v8 ~= Enum.CoreGuiType.All then
		pcall(function() --[[ Line: 160 | Upvalues: t3 (copy), v8 (copy), StarterGui (copy) ]]
			t3[v8] = StarterGui:GetCoreGuiEnabled(v8)
			StarterGui:SetCoreGuiEnabled(v8, false)
		end)
	end
end

t3[Enum.CoreGuiType.Backpack] = false

local v9 = nil

local function applyLoadingCamera(p1) --[[ applyLoadingCamera | Line: 177 | Upvalues: v9 (ref), t (copy) ]]
	local CurrentCamera = workspace.CurrentCamera
	local v1 = v9

	if not (CurrentCamera and v1) then
		return
	end

	CurrentCamera.CameraType = Enum.CameraType.Scriptable

	local v2 = math.rad(t.CameraPanDegrees) * (p1 or 0)

	CurrentCamera.CFrame = CFrame.new(v1.Position) * CFrame.Angles(0, v2, 0) * v1.Rotation
end

task.spawn(function() --[[ Line: 186 | Upvalues: ReplicatedFirst (copy), t (copy), findFallbackCopy (copy), v9 (ref), applyLoadingCamera (copy) ]]
	local v1 = ReplicatedFirst:WaitForChild(t.CameraPartName, t.ReplicatedFirstTimeout) or (workspace:FindFirstChild(t.CameraPartName) or findFallbackCopy(t.CameraPartName))

	if not (v1 and v1:IsA("BasePart")) then
		return
	end

	v9 = v1.CFrame
	applyLoadingCamera()
end)
task.spawn(function() --[[ Line: 198 | Upvalues: v3 (copy), t (copy), ContentProvider (copy) ]]
	local t2 = { v3 }

	for v1, v2 in t.Milestones do
		table.insert(t2, v2.image)
	end

	table.insert(t2, t.PulseSound)
	table.insert(t2, t.CastShotSound)
	table.insert(t2, t.CastReleaseSound)
	table.insert(t2, t.SplashSound)
	pcall(function() --[[ Line: 207 | Upvalues: ContentProvider (ref), t2 (copy) ]]
		ContentProvider:PreloadAsync(t2)
	end)
end)

local ImageWarmup = Instance.new("Folder")

ImageWarmup.Name = "ImageWarmup"

for v10, v11 in t.Milestones do
	local ImageLabel = Instance.new("ImageLabel")

	ImageLabel.Name = "Warmup" .. v10
	ImageLabel.BackgroundTransparency = 1
	ImageLabel.ImageTransparency = 0.99
	ImageLabel.Size = UDim2.fromOffset(1, 1)
	ImageLabel.Position = UDim2.fromOffset(0, 0)
	ImageLabel.Image = v11.image
	ImageLabel.Parent = ImageWarmup
end

ImageWarmup.Parent = v3

local function updateVisuals(p1) --[[ updateVisuals | Line: 233 | Upvalues: FillerBar (copy), BarFrame (copy), HookImage (copy), Y (copy) ]]
	FillerBar.Size = UDim2.fromScale(p1, 1)
	HookImage.Position = UDim2.new(BarFrame.Position.X.Scale - BarFrame.AnchorPoint.X * BarFrame.Size.X.Scale + BarFrame.Size.X.Scale * p1, 0, Y.Scale, Y.Offset)
end

local PulseSound = Instance.new("Sound")

PulseSound.Name = "PulseSound"
PulseSound.SoundId = t.PulseSound
PulseSound.Volume = t.PulseSoundVolume
PulseSound.Parent = v3
task.spawn(function() --[[ Line: 250 | Upvalues: t (copy), v3 (copy) ]]
	local CastShotSound = Instance.new("Sound")

	CastShotSound.Name = "CastShotSound"
	CastShotSound.SoundId = t.CastShotSound
	CastShotSound.Volume = t.CastShotVolume
	CastShotSound.Parent = v3
	CastShotSound:Play()
	task.wait(t.CastReleaseDelay)

	local CastReleaseSound = Instance.new("Sound")

	CastReleaseSound.Name = "CastReleaseSound"
	CastReleaseSound.SoundId = t.CastReleaseSound
	CastReleaseSound.Volume = t.CastReleaseVolume
	CastReleaseSound.TimePosition = t.CastReleaseStart
	CastReleaseSound.Parent = v3
	CastReleaseSound:Play()
end)

local v12 = nil

local function pulseHook(p1, p2) --[[ pulseHook | Line: 269 | Upvalues: HookImage (copy), PulseSound (copy), t (copy), v12 (ref), Size (copy), TweenService (copy) ]]
	HookImage.Image = p1
	PulseSound.PlaybackSpeed = 1 + (p2 - 1) * t.PulseSoundPitchStep
	PulseSound.TimePosition = 0
	PulseSound:Play()

	local v1, v2

	if v12 then
		v12:Cancel()
		HookImage.Size = Size
	end

	v1 = UDim2.new(Size.X.Scale * t.PulseScale, 0, Size.Y.Scale * t.PulseScale, 0)
	v2 = TweenService:Create(HookImage, TweenInfo.new(t.PulseTime, Enum.EasingStyle.Back, Enum.EasingDirection.Out, 0, true), {
		Size = v1
	})
	v12 = v2
	v2.Completed:Once(function() --[[ Line: 288 | Upvalues: v12 (ref), v2 (copy), HookImage (ref), Size (ref) ]]
		if v12 ~= v2 then
			return
		end

		v12 = nil
		HookImage.Size = Size
	end)
	v2:Play()
end

local v13 = false

local function playSplashSound() --[[ playSplashSound | Line: 301 | Upvalues: v13 (ref), t (copy), SoundService (copy) ]]
	if not v13 then
		v13 = true

		local LoadingSplashSound = Instance.new("Sound")

		LoadingSplashSound.Name = "LoadingSplashSound"
		LoadingSplashSound.SoundId = t.SplashSound
		LoadingSplashSound.Volume = t.SplashVolume
		LoadingSplashSound.Parent = SoundService
		LoadingSplashSound.Ended:Once(function() --[[ Line: 311 | Upvalues: LoadingSplashSound (copy) ]]
			LoadingSplashSound:Destroy()
		end)
		LoadingSplashSound:Play()
	end
end

local function fadeOutAndDestroy() --[[ fadeOutAndDestroy | Line: 317 | Upvalues: LocalPlayer (copy), playSplashSound (copy), t (copy), BarFrame (copy), TweenService (copy), HookImage (copy), Frame (copy), LoadingScreenBlur (copy), v6 (copy), t2 (copy), t3 (copy), StarterGui (copy), v3 (copy) ]]
	LocalPlayer:SetAttribute("LoadingScreenFinished", true)
	playSplashSound()

	local v1 = TweenInfo.new(t.FadeOutTime, Enum.EasingStyle.Back, Enum.EasingDirection.In)

	TweenService:Create(BarFrame, v1, {
		Position = UDim2.fromScale(BarFrame.Position.X.Scale, 1.3)
	}):Play()
	TweenService:Create(HookImage, v1, {
		Position = UDim2.fromScale(HookImage.Position.X.Scale, HookImage.Position.Y.Scale + (1.3 - BarFrame.Position.Y.Scale))
	}):Play()

	local LogoImage = Frame:FindFirstChild("LogoImage")

	if LogoImage and LogoImage:IsA("GuiObject") then
		TweenService:Create(LogoImage, v1, {
			Position = UDim2.fromScale(LogoImage.Position.X.Scale, -(LogoImage.AnchorPoint.Y * LogoImage.Size.Y.Scale + LogoImage.Size.Y.Scale + 0.05))
		}):Play()
	end

	TweenService:Create(LoadingScreenBlur, TweenInfo.new(t.FadeOutTime, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
		Size = 0
	}):Play()
	v6:Disconnect()

	for v4 in t2 do
		if v4.Parent then
			v4.Enabled = true
		end
	end

	for v5, v62 in t3 do
		pcall(function() --[[ Line: 356 | Upvalues: StarterGui (ref), v5 (copy), v62 (copy) ]]
			StarterGui:SetCoreGuiEnabled(v5, v62)
		end)
	end

	local CurrentCamera = workspace.CurrentCamera

	if CurrentCamera and CurrentCamera.CameraType == Enum.CameraType.Scriptable then
		CurrentCamera.CameraType = Enum.CameraType.Custom

		local Character = LocalPlayer.Character
		local v7 = if Character then Character:FindFirstChildOfClass("Humanoid") else Character

		if v7 then
			CurrentCamera.CameraSubject = v7
		end
	end

	task.delay(t.FadeOutTime, function() --[[ Line: 370 | Upvalues: LoadingScreenBlur (ref), v3 (ref) ]]
		LoadingScreenBlur:Destroy()
		v3:Destroy()
	end)
end

local v14 = 0
local v15 = 0
local v16 = 0
local v17 = 1

task.spawn(function() --[[ Line: 384 | Upvalues: v15 (ref), LocalPlayer (copy), PlayerGui (copy), StarterGui (copy), ReplicatedStorage (copy), t (copy), ContentProvider (copy) ]]
	if not game:IsLoaded() then
		game.Loaded:Wait()
	end

	v15 = math.max(v15, 0.5)

	if not LocalPlayer.Character then
		LocalPlayer.CharacterAdded:Wait()
	end

	v15 = math.max(v15, 0.6)

	local t2 = {}
	local t3 = {}

	local function addId(p1) --[[ addId | Line: 402 | Upvalues: t2 (copy), t3 (copy) ]]
		if not p1 or (p1 == "" or t2[p1]) then
			return
		end

		t2[p1] = true
		table.insert(t3, p1)
	end

	for v3, v4 in { PlayerGui, StarterGui, ReplicatedStorage } do
		for v5, v6 in v4:GetDescendants() do
			if v6:IsA("ImageLabel") then
				local Image = v6.Image

				if Image and (Image ~= "" and not t2[Image]) then
					t2[Image] = true
					table.insert(t3, Image)
				end

				continue
			end

			if v6:IsA("ImageButton") then
				local Image = v6.Image

				if Image and (Image ~= "" and not t2[Image]) then
					t2[Image] = true
					table.insert(t3, Image)
				end

				local HoverImage = v6.HoverImage

				if HoverImage and (HoverImage ~= "" and not t2[HoverImage]) then
					t2[HoverImage] = true
					table.insert(t3, HoverImage)
				end

				local PressedImage = v6.PressedImage

				if PressedImage and (PressedImage ~= "" and not t2[PressedImage]) then
					t2[PressedImage] = true
					table.insert(t3, PressedImage)
				end

				continue
			end

			if v6:IsA("Decal") then
				local Texture = v6.Texture

				if Texture and (Texture ~= "" and not t2[Texture]) then
					t2[Texture] = true
					table.insert(t3, Texture)
				end

				continue
			end

			if v6:IsA("Sound") then
				local SoundId = v6.SoundId

				if SoundId and (SoundId ~= "" and not t2[SoundId]) then
					t2[SoundId] = true
					table.insert(t3, SoundId)
				end
			end
		end
	end

	local v7 = os.clock()
	local PreloadBatchSize = t.PreloadBatchSize

	for i = 1, #t3, PreloadBatchSize do
		local v8 = math.min(i + PreloadBatchSize - 1, #t3)
		local v9 = table.move(t3, i, v8, 1, {})

		pcall(function() --[[ Line: 428 | Upvalues: ContentProvider (ref), v9 (copy) ]]
			ContentProvider:PreloadAsync(v9)
		end)
		v15 = math.max(v15, v8 / #t3 * 0.4 + 0.6)

		if os.clock() - v7 > t.PreloadTimeout then
			warn("LoadingScreen: asset preload hit the time cap, continuing without the rest")

			break
		end
	end

	v15 = 1
end)

local v18 = nil

v18 = RunService.RenderStepped:Connect(function(p1) --[[ Line: 441 | Upvalues: applyLoadingCamera (copy), v14 (ref), PlayerGui (copy), v3 (copy), t2 (copy), v15 (ref), t (copy), v16 (ref), updateVisuals (copy), v13 (ref), playSplashSound (copy), v17 (ref), pulseHook (copy), v18 (ref), fadeOutAndDestroy (copy) ]]
	applyLoadingCamera(v14)

	for v1, v2 in PlayerGui:GetChildren() do
		if v2:IsA("ScreenGui") and (v2 ~= v3 and v2.Enabled) then
			v2.Enabled = false
			t2[v2] = true
		end
	end

	if v15 < t.WaitingCap then
		v15 = math.min(v15 + t.WaitingSpeed * p1, t.WaitingCap)
	end

	v16 = v16 + p1

	local v4 = v14

	v14 = math.min(v14 + t.FillSpeed * p1, v15, v16 / t.MinimumTime)
	updateVisuals(v14)

	local v8 = (v14 - v4) / p1

	if not v13 and (v14 < 1 and (v8 > 0 and v14 + v8 * t.SplashLead >= 1)) then
		playSplashSound()
	end

	local v9 = t.Milestones[v17]

	if v9 and v14 >= v9.progress then
		local v10 = v17

		v17 = v17 + 1
		pulseHook(v9.image, v10)
	end

	if not (v14 >= 1) then
		return
	end

	v18:Disconnect()
	fadeOutAndDestroy()
end)